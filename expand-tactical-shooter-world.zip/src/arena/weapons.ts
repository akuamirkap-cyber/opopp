import type { SfxName } from "../game/audio";
import type { WeaponId } from "../game/defs";
import { TEAM_PAL, WBARREL, WPIVOT, fromMap, initSprites, mk, whiten } from "../game/sprites";

/** the arena arsenal: what each weapon does, how it sounds, and its sprite (the game's own where it has one) */
export type AW = "pistol" | "uzi" | "shotgun" | "rifle" | "e11" | "magnum" | "sniper" | "saw" | "flame" | "rpg" | "saber";
export interface AWDef {
  id: AW; name: string; desc: string; kind: "bullet" | "laser" | "rocket" | "flame" | "saw" | "saber";
  dmg: number; head: number; cd: number; mag: number; ammo: number; reload: number; speed: number; spread: number; bloom: number;
  pellets: number; life: number; auto: boolean; kick: number; shake: number; snd: SfxName | null; pitch: number; vol: number;
  tracer: string; pierce: boolean; rank: number; range: number; sprite: WeaponId | "uzi" | "flame" | "saw" | "e11" | "saber";
}

/** the light of each team: lightsaber blades and blaster bolts glow in it */
export const BEAM = [
  { col: "#ffc82a", hot: "#fff4c2" },
  { col: "#ff2a40", hot: "#ffd0d6" },
];
/** how long the blade of a lightsaber is, and how far its cut reaches from the hand */
export const SABER_L = 19;

const base = { head: 1.7, bloom: 0.1, pellets: 1, life: 0.6, auto: false, pitch: 1, vol: 0.8, tracer: "#ffe9a0", pierce: false };
export const AWEP: Record<AW, AWDef> = {
  pistol: { ...base, id: "pistol", name: "PISTOL", desc: "Selalu dibawa. Akurat & cepat dikokang.", kind: "bullet", dmg: 22, head: 1.8, cd: 0.26, mag: 12, ammo: 60, reload: 1.0, speed: 950, spread: 0.025, bloom: 0.25, kick: 10, shake: 1, snd: "pistol", rank: 1, range: 300, sprite: "pistol" },
  uzi: { ...base, id: "uzi", name: "UZI", desc: "Semburan peluru jarak dekat-menengah.", kind: "bullet", dmg: 10, head: 1.6, cd: 0.065, mag: 32, ammo: 128, reload: 1.3, speed: 900, spread: 0.1, bloom: 0.08, auto: true, kick: 6, shake: 1, snd: "ak47", pitch: 1.35, vol: 0.5, rank: 3, range: 220, sprite: "uzi" },
  shotgun: { ...base, id: "shotgun", name: "SHOTGUN", desc: "8 peluru sekaligus. Mematikan dari dekat.", kind: "bullet", dmg: 12, head: 1.3, cd: 0.75, mag: 6, ammo: 24, reload: 1.7, speed: 760, spread: 0.2, bloom: 0, pellets: 8, life: 0.24, kick: 90, shake: 4, snd: "shotgun", rank: 4, range: 120, sprite: "shotgun" },
  rifle: { ...base, id: "rifle", name: "AK-47", desc: "Senapan serbu otomatis andalan.", kind: "bullet", dmg: 16, cd: 0.1, mag: 30, ammo: 120, reload: 1.5, speed: 1150, spread: 0.045, bloom: 0.06, auto: true, kick: 12, shake: 1.5, snd: "ak47", rank: 6, range: 330, sprite: "ak47" },
  e11: { ...base, id: "e11", name: "BLASTER E-11", desc: "Senapan blaster stormtrooper - baut laser bercahaya warna tim.", kind: "laser", dmg: 19, head: 1.7, cd: 0.15, mag: 30, ammo: 120, reload: 1.4, speed: 760, spread: 0.035, bloom: 0.07, life: 0.95, auto: true, kick: 8, shake: 1.2, snd: "blaster", vol: 0.6, rank: 6, range: 340, sprite: "e11" },
  magnum: { ...base, id: "magnum", name: "DEAGLE EMAS", desc: "Pistol raksasa. 2 tembakan = tumbang.", kind: "bullet", dmg: 56, head: 1.8, cd: 0.5, mag: 7, ammo: 28, reload: 1.3, speed: 1500, spread: 0.012, bloom: 0.4, kick: 40, shake: 3, snd: "goldgun", vol: 0.75, tracer: "#fff3a0", rank: 6, range: 340, sprite: "goldgun" },
  sniper: { ...base, id: "sniper", name: "SNIPER", desc: "Laser bidik, tembus badan. Headshot = mati.", kind: "bullet", dmg: 85, head: 1.6, cd: 1.1, mag: 5, ammo: 20, reload: 2.0, speed: 2600, spread: 0.002, bloom: 0, life: 0.5, kick: 60, shake: 4, snd: "sniper", tracer: "#ffffff", pierce: true, rank: 7, range: 520, sprite: "sniper" },
  saw: { ...base, id: "saw", name: "GERGAJI", desc: "Mata gergaji yang memantul di dinding.", kind: "saw", dmg: 40, head: 1, cd: 0.55, mag: 5, ammo: 20, reload: 1.6, speed: 430, spread: 0.02, life: 2.4, kick: 20, shake: 1, snd: "whoosh", pitch: 1.5, rank: 5, range: 260, sprite: "saw" },
  flame: { ...base, id: "flame", name: "PENYEMBUR API", desc: "Membakar musuh - apinya terus melukai.", kind: "flame", dmg: 3, head: 1, cd: 0.045, mag: 120, ammo: 240, reload: 2.0, speed: 250, spread: 0.16, life: 0.4, auto: true, kick: 2, shake: 0.5, snd: null, rank: 4, range: 95, sprite: "flame" },
  rpg: { ...base, id: "rpg", name: "BAZOOKA", desc: "Roket meledak. Bisa dipakai lompat roket!", kind: "rocket", dmg: 110, head: 1, cd: 0.9, mag: 1, ammo: 5, reload: 1.6, speed: 300, spread: 0.01, life: 2.5, kick: 70, shake: 3, snd: "bazooka", rank: 8, range: 360, sprite: "bazooka" },
  saber: { ...base, id: "saber", name: "LIGHTSABER", desc: "Pedang cahaya warna tim: 3 kombo tebasan, dan pantulkan peluru & laser yang datang!", kind: "saber", dmg: 62, head: 1, cd: 0.3, mag: 1, ammo: 0, reload: 0, speed: 0, spread: 0, bloom: 0, life: 0, auto: true, kick: 0, shake: 2, snd: null, rank: 9, range: 34, sprite: "saber" },
};
export const AW_ORDER: AW[] = ["pistol", "uzi", "shotgun", "rifle", "e11", "magnum", "sniper", "saw", "flame", "rpg", "saber"];

const CUSTOM: Record<"uzi" | "flame" | "saw" | "e11" | "saber", { rows: string[]; pivot: [number, number]; bar: number }> = {
  uzi: {
    rows: ["..KKKKKKKKKK..", ".KGGGGGGGLLLLK", "KKGgGGGGGGKKK.", "KGGKKGGKK.....", ".KK.KAAK......", "....KGGK......", "....KGGK......", ".....KK......."],
    pivot: [5, 3], bar: -2,
  },
  flame: {
    rows: ["..KKK...............", ".KRRRK..KKKKKKKKKK..", ".KRrRKKKGGGGGGGGLLKK", ".KRRRKGGGgGGGGGGLLLK", ".KRRRKKKGGKKKKKKKKK.", ".KRrRK.KAAK.........", "..KKK..KGGK.........", ".......KKK.........."],
    pivot: [8, 4], bar: -1,
  },
  saw: {
    rows: ["........KKKK....", "KKKKKKKKSSSSK...", "KGGGGGGKSssSSK..", "KGgGGGGKSsKsSK..", "KGGKKGGKSssSSK..", "KKK.KAAKKSSSK...", "....KGGK.KKK....", "....KKKK........"],
    pivot: [5, 5], bar: -2,
  },
  // the E-11: a scope on top, the perforated shroud over the barrel, a stripe and a glowing emitter in the team's colour
  e11: {
    rows: [
      "......KKKKKKK.........",
      ".....KLLLLLLLK........",
      "......KKgKKgK.........",
      "KK..KKKKKKKKKKKKKKKKK.",
      "KAKKKGGGGGGGGGKgKgKgVK",
      "KAAAAAAAAGGGGGGGGGGGGK",
      "KKKKKGGKKKGGGKKKKKKKK.",
      ".....KGGK.KAAK........",
      ".....KGGK..KK.........",
      "......KK..............",
    ],
    pivot: [6, 5], bar: -1,
  },
  // a lightsaber hilt: grip ridges, the activation stud in the team's colour, the emitter shroud
  saber: {
    rows: [".KKKKKKKKK.", "KSKSKSKSSAK", "KsKsKsKssLK", ".KKKKKKKKK."],
    pivot: [3, 2], bar: 0,
  },
};

export interface WSpr { c: HTMLCanvasElement; w: HTMLCanvasElement; px: number; py: number; bar: number; len: number }
const sprCache: Record<string, WSpr> = {};
/** a weapon sprite (pointing right) with its grip point, barrel line and length to the muzzle */
export function wspr(team: number, id: AW): WSpr {
  const key = `${team}${id}`;
  if (sprCache[key]) return sprCache[key];
  const d = AWEP[id];
  let r: WSpr;
  if (d.sprite === "uzi" || d.sprite === "flame" || d.sprite === "saw" || d.sprite === "e11" || d.sprite === "saber") {
    const cu = CUSTOM[d.sprite], P = TEAM_PAL[team], wd = Math.max(...cu.rows.map((q) => q.length));
    const c = fromMap(cu.rows.map((q) => q.padEnd(wd, ".")), {
      K: "#0a0a0f", G: "#2a2d38", g: "#4a5064", L: "#8a93a8", S: "#dfe4ec", s: "#9aa3b5", R: "#e0483e", r: "#a8302a", A: P.A, a: P.a, V: BEAM[team].hot,
    });
    r = { c, w: whiten(c), px: cu.pivot[0], py: cu.pivot[1], bar: cu.bar, len: c.width - cu.pivot[0] };
    if (id === "saber") r.len = c.width - cu.pivot[0];
  } else {
    const c = initSprites().weapon[team][d.sprite], [px, py] = WPIVOT[d.sprite];
    r = { c, w: whiten(c), px, py, bar: WBARREL[d.sprite], len: c.width - px };
  }
  sprCache[key] = r;
  return r;
}

const iconCache: Record<string, string> = {};
/** data-URL of a weapon sprite, for the HUD and the lobby (the lightsaber is shown lit) */
export function awIcon(id: AW, team = 0): string {
  const key = id + team;
  if (!iconCache[key]) {
    const s = wspr(team, id);
    if (id === "saber") {
      const B = BEAM[team], [c, g] = mk(s.c.width + 22, 6);
      g.drawImage(s.c, 0, 1);
      g.fillStyle = B.col; g.fillRect(s.c.width, 1, 20, 4);
      g.fillStyle = B.hot; g.fillRect(s.c.width, 2, 21, 2);
      g.fillStyle = "#ffffff"; g.fillRect(s.c.width, 2, 19, 1);
      iconCache[key] = c.toDataURL();
    } else iconCache[key] = s.c.toDataURL();
  }
  return iconCache[key];
}

let nade: HTMLCanvasElement | null = null, med: HTMLCanvasElement | null = null;
export function nadeSpr(): HTMLCanvasElement {
  if (!nade) nade = fromMap([".KKK.", "KYKK.", "KGgGK", "KGGGK", "KGgGK", ".KKK."], { K: "#0a0a0f", G: "#3f5a34", g: "#5c7c4a", Y: "#c9cdd9" });
  return nade;
}
export function medSpr(): HTMLCanvasElement {
  if (!med) {
    const [c, g] = mk(11, 9);
    const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
    R("#0a0a0f", 0, 1, 11, 8); R("#f2f2f2", 1, 2, 9, 6); R("#c9cdd9", 1, 7, 9, 1); R("#e0483e", 4, 3, 3, 4); R("#e0483e", 3, 4, 5, 2); R("#0a0a0f", 4, 0, 3, 2);
    med = c;
  }
  return med;
}

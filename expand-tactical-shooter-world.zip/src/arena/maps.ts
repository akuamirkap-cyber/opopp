import { mk } from "../game/sprites";

/**
 * The arenas of the side-view team deathmatch: tile maps built from a few primitives on the left half and mirrored,
 * so both teams get exactly the same ground. Also: painting the terrain pixel by pixel (sand ripples, sandstone strata,
 * crystal veins), a light layer for everything that glows, the parallax backdrops, the minimap, and the navigation grid
 * + pathfinding the bots fly by.
 */
export const AT = 8;
export const AIR = 0;
export const DIRT = 1;
export const ROCK = 2;
export const PLAT = 3;
export const solidT = (t: number) => t === DIRT || t === ROCK;

export type PickKind = "uzi" | "shotgun" | "rifle" | "sniper" | "rpg" | "flame" | "saw" | "magnum" | "e11" | "saber" | "health" | "nades";

export interface Theme {
  id: string; name: string; sub: string;
  sky: [string, string, string];
  far: string; mid: string; near: string;
  dirt: [string, string, string];
  top: [string, string];
  rock: [string, string, string];
  plank: [string, string];
  wall: [string, string];
  cave: [string, string];
  dark: number; rain: number; fog: number; sun: boolean;
  decor: "desert" | "city" | "cave";
  weather: "sand" | "rain" | "spores";
  amb: { wind: number; birds: number; night: number; drone: number; water: number };
}
export interface Decor { x: number; y: number; k: string; v: number; h: number }
/** things that move: flags in the wind, swinging lanterns, the waterfall */
export interface Dyn { k: "flag" | "lantern" | "fall"; x: number; y: number; h: number; t: number; v: number }
export interface Light { x: number; y: number; r: number; col: string; pulse: number }
export interface ArenaMap {
  id: number; theme: Theme; w: number; h: number; grid: Uint8Array; bg: Uint8Array;
  spawns: { x: number; y: number }[][];
  picks: { x: number; y: number; kind: PickKind }[];
  lights: Light[]; decor: Decor[]; dyn: Dyn[];
  nav: Uint8Array; nw: number; nh: number;
}

export const hsh = (x: number, y: number, s = 0) => {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
/** smooth value noise */
function vn(x: number, y: number, s: number) {
  const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  const a = hsh(xi, yi, s), b = hsh(xi + 1, yi, s), c = hsh(xi, yi + 1, s), d = hsh(xi + 1, yi + 1, s);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
const ss = (a: number, b: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const rgb = (h: string): number[] => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mixc = (a: number[], b: number[], k: number) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const haloC: Record<string, HTMLCanvasElement> = {};
/** a soft round glow of one colour */
export function halo(col: string): HTMLCanvasElement {
  if (!haloC[col]) {
    const [c, g] = mk(32, 32), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, col);
    gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 32, 32);
    haloC[col] = c;
  }
  return haloC[col];
}

const THEMES: Theme[] = [
  {
    id: "desert", name: "GURUN BADAI", sub: "Badai pasir, bunker berkarung pasir, reruntuhan kuno & menara tengah",
    sky: ["#a5653c", "#dc9a5c", "#f4d29a"], far: "#c48452", mid: "#d29b64", near: "#b77846",
    dirt: ["#d8a35c", "#c58d4a", "#7a4c26"], top: ["#efc27c", "#ffe2ac"], rock: ["#b47a48", "#cf9660", "#6e4222"],
    plank: ["#9a6a3a", "#5e3e20"], wall: ["#7c6b58", "#665646"], cave: ["#6a4a2e", "#56402a"],
    dark: 0, rain: 0, fog: 0, sun: true, decor: "desert", weather: "sand",
    amb: { wind: 0.85, birds: 0.08, night: 0, drone: 0, water: 0 },
  },
  {
    id: "city", name: "KOTA RUNTUH", sub: "Gedung hancur, jalan layang & kereta bawah tanah",
    sky: ["#231d3a", "#5e4466", "#e6865a"], far: "#3b3150", mid: "#2b2338", near: "#1d1828",
    dirt: ["#4b4549", "#58525a", "#211d26"], top: ["#77777e", "#9a9aa2"], rock: ["#7b7473", "#968f8b", "#3d3939"],
    plank: ["#8f5e3c", "#5a3a24"], wall: ["#3b3539", "#322c30"], cave: ["#2b2830", "#35313a"],
    dark: 0.32, rain: 1, fog: 0.25, sun: false, decor: "city", weather: "rain",
    amb: { wind: 0.45, birds: 0, night: 0.3, drone: 0.2, water: 0 },
  },
  {
    id: "cave", name: "GOA KRISTAL", sub: "Air terjun bawah tanah, rel tambang & kristal yang berdenyut cahaya",
    sky: ["#06040d", "#0e0a1c", "#191230"], far: "#1d1631", mid: "#140f23", near: "#0c0916",
    dirt: ["#4e4064", "#5e4f77", "#241c33"], top: ["#4f9a6c", "#88d2a2"], rock: ["#5e5e74", "#78788f", "#2c2c3a"],
    plank: ["#9a7448", "#5e452a"], wall: ["#241d2e", "#1d1826"], cave: ["#1d1628", "#272033"],
    dark: 0.6, rain: 0, fog: 0, sun: false, decor: "cave", weather: "spores",
    amb: { wind: 0.12, birds: 0, night: 0, drone: 0.5, water: 0.55 },
  },
];
export const MAP_INFO = THEMES.map((t) => ({ name: t.name, sub: t.sub }));

class Bld {
  g: Uint8Array;
  bg: Uint8Array;
  picks: [number, number, PickKind][] = [];
  cpicks: [number, PickKind][] = [];
  spawns: [number, number][] = [];
  lights: [number, number, number, string, number][] = [];
  decs: [number, number, string][] = [];
  dyns: [number, number, Dyn["k"]][] = [];
  constructor(public w: number, public h: number) {
    this.g = new Uint8Array(w * h);
    this.bg = new Uint8Array(w * h);
  }
  in(x: number, y: number) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  set(x: number, y: number, t: number) { if (this.in(x, y)) this.g[y * this.w + x] = t; }
  get(x: number, y: number) { return this.in(x, y) ? this.g[y * this.w + x] : ROCK; }
  rect(x: number, y: number, w: number, h: number, t: number) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) this.set(xx, yy, t); }
  carve(x: number, y: number, w: number, h: number) { this.rect(x, y, w, h, AIR); }
  wall(x: number, y: number, w: number, h: number, v = 1) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (this.in(xx, yy)) this.bg[yy * this.w + xx] = v; }
  plat(x: number, y: number, w: number) { for (let xx = x; xx < x + w; xx++) if (this.get(xx, y) === AIR) this.set(xx, y, PLAT); }
  ell(cx: number, cy: number, rx: number, ry: number, t: number) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.set(x, y, t);
      }
  }
  line(x0: number, y0: number, x1: number, y1: number, r: number, t: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2) + 1;
    for (let i = 0; i <= n; i++) { const k = i / n; this.ell(x0 + (x1 - x0) * k, y0 + (y1 - y0) * k, r, r, t); }
  }
  ground(f: (x: number) => number, x0: number, x1: number) { for (let x = x0; x < x1; x++) for (let y = Math.max(0, f(x)); y < this.h; y++) this.set(x, y, DIRT); }
  pick(x: number, y: number, k: PickKind) { this.picks.push([x, y, k]); }
  /** one pick in the very middle of the map (not mirrored): the prize both teams fight over */
  pickC(y: number, k: PickKind) { this.cpicks.push([y, k]); }
  spawn(x: number, y: number) { this.spawns.push([x, y]); }
  light(x: number, y: number, r: number, col: string, pulse = 0.04) { this.lights.push([x, y, r, col, pulse]); }
  dec(x: number, y: number, k: string) { this.decs.push([x, y, k]); }
  dyn(x: number, y: number, k: Dyn["k"]) { this.dyns.push([x, y, k]); }
  mirror() {
    const W = this.w;
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < W >> 1; x++) {
        this.g[y * W + W - 1 - x] = this.g[y * W + x];
        this.bg[y * W + W - 1 - x] = this.bg[y * W + x];
      }
  }
}

/** desert outpost in a sandstorm: a sandbagged bunker each side, a tunnel all the way across under the dunes, ruins, a fortified tower */
function desert(): Bld {
  const b = new Bld(200, 90);
  const hgt = (x: number) => {
    const w = ss(30, 40, x) * (1 - ss(74, 84, x));
    return Math.round(62 - 2 * ss(30, 84, x) + w * (2 * Math.sin((x - 30) * 0.17) - 2.4 * Math.sin((x - 30) * 0.06 + 0.8)));
  };
  b.ground(hgt, 0, 100);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  // the bunker: roof, front wall with a door and a slit, a gallery inside
  b.rect(2, 44, 26, 2, ROCK);
  b.rect(26, 44, 2, 12, ROCK);
  b.rect(2, 41, 2, 3, ROCK);
  b.rect(23, 41, 5, 3, ROCK);
  b.carve(2, 46, 24, 16);
  b.wall(2, 46, 24, 16);
  b.plat(2, 53, 17);
  b.carve(26, 48, 2, 5);
  // the tunnel: down through the bunker floor, all the way to the other side
  b.carve(8, 62, 4, 4);
  b.wall(8, 62, 4, 4, 2);
  b.carve(4, 66, 96, 6);
  b.wall(4, 66, 96, 6, 2);
  for (const sx of [44, 72]) {
    const top = hgt(sx) - 1;
    b.carve(sx, top, 4, 66 - top);
    b.wall(sx, top + 1, 4, 65 - top, 2);
  }
  // a floating rock and scaffolding over the dunes
  b.ell(60, 34, 9, 2.6, ROCK);
  b.ell(60, 33, 7, 1.6, DIRT);
  b.plat(46, 46, 8);
  b.plat(68, 48, 8);
  b.plat(80, 38, 9);
  b.plat(32, 52, 6);
  // the tower in the middle: two floors, doors on both sides, a window you can step out of
  b.rect(92, 26, 8, 36, ROCK);
  b.carve(94, 30, 6, 30);
  b.wall(94, 30, 6, 30);
  b.carve(92, 52, 2, 8);
  b.carve(92, 39, 2, 6);
  b.plat(94, 45, 6);
  b.rect(92, 23, 2, 3, ROCK);
  b.rect(96, 23, 2, 3, ROCK);
  // sandbags on the bunker roof and the team's flag, crates and barrels, palms, the columns of an older city
  for (const x of [6, 12, 18]) b.dec(x, 44, "sandbag");
  b.dyn(25, 41, "flag");
  b.dec(15, 62, "crate"); b.dec(21, 62, "barrel"); b.dec(23, 62, "barrel"); b.dec(5, 53, "crate");
  b.dec(36, hgt(36), "palm"); b.dec(65, hgt(65), "palm"); b.dec(39, hgt(39), "sandbag");
  b.dec(54, hgt(54), "pillar"); b.dec(57, hgt(57), "pillar"); b.dec(79, hgt(79), "pillar");
  b.dec(58, 32, "pillar");
  b.dec(84, hgt(84), "crate"); b.dec(88, hgt(88), "sandbag");
  b.pick(60, 26, "sniper"); b.pick(97, 40, "rpg"); b.pick(84, 30, "magnum"); b.pick(50, 40, "rifle"); b.pick(72, 42, "shotgun");
  b.pick(38, 40, "uzi"); b.pick(56, 66, "health"); b.pick(30, 40, "nades"); b.pick(12, 48, "flame"); b.pick(84, 66, "saw"); b.pick(30, 66, "e11");
  b.pickC(24, "saber");
  for (const x of [5, 9, 13, 17]) b.spawn(x, 47);
  for (const x of [6, 15, 21]) b.spawn(x, 56);
  return b;
}

/** ruined city at dusk, in the rain: a house each side, a bombed-out block, an overpass, the subway underneath */
function city(): Bld {
  const b = new Bld(200, 90);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  b.rect(2, 64, 98, 22, DIRT);
  b.carve(2, 70, 98, 6);
  b.wall(2, 70, 98, 6);
  for (const x of [30, 66]) { b.carve(x, 64, 4, 6); b.wall(x, 64, 4, 6); b.plat(x, 67, 4); }
  b.rect(2, 40, 20, 2, ROCK);
  b.rect(20, 42, 2, 12, ROCK);
  b.carve(2, 42, 18, 22);
  b.wall(2, 42, 18, 22);
  b.rect(2, 52, 13, 1, ROCK);
  b.plat(15, 52, 5);
  b.carve(20, 47, 2, 5);
  b.rect(2, 37, 2, 3, ROCK);
  b.rect(17, 37, 5, 3, ROCK);
  b.rect(36, 30, 2, 26, ROCK);
  b.rect(36, 30, 9, 2, ROCK);
  b.rect(50, 38, 2, 16, ROCK);
  b.wall(38, 32, 12, 32);
  b.rect(38, 44, 9, 1, ROCK);
  b.plat(47, 44, 3);
  b.plat(38, 54, 12);
  b.carve(36, 39, 2, 5);
  b.plat(56, 46, 44);
  b.rect(68, 47, 2, 17, ROCK);
  b.rect(86, 47, 2, 17, ROCK);
  b.plat(74, 34, 8);
  b.rect(77, 35, 1, 11, ROCK);
  b.rect(96, 60, 4, 4, ROCK);
  b.ell(57, 64, 4, 1.6, DIRT);
  b.ell(80, 64, 3, 1.3, DIRT);
  b.dyn(18, 37, "flag");
  for (const [x, y] of [[26, 64], [58, 64], [92, 64]]) { b.dec(x, y, "lamp"); b.light(x + 0.5, y - 3.6, 66, "#ffd98a"); }
  b.light(10, 45, 52, "#ffcf7a"); b.light(10, 56, 52, "#ffcf7a"); b.light(44, 48, 44, "#ff9a5a");
  for (const x of [20, 50, 80]) b.light(x, 72, 56, "#bfe0ff");
  b.pick(64, 40, "rifle"); b.pick(77, 28, "sniper"); b.pick(97, 72, "rpg"); b.pick(44, 50, "shotgun"); b.pick(26, 58, "uzi");
  b.pick(48, 72, "health"); b.pick(90, 40, "nades"); b.pick(44, 36, "flame"); b.pick(98, 54, "magnum"); b.pick(16, 72, "saw"); b.pick(82, 58, "e11");
  b.pickC(58, "saber");
  for (const x of [5, 9, 13]) b.spawn(x, 44);
  b.spawn(17, 44);
  for (const x of [6, 12, 18]) b.spawn(x, 56);
  return b;
}

/** a crystal cave: chambers joined by tunnels, a mine railway, scaffolds, a waterfall in the great hall */
function cave(): Bld {
  const b = new Bld(200, 90);
  b.rect(0, 0, 100, 90, DIRT);
  b.ell(14, 56, 12, 8, AIR);
  b.rect(2, 63, 24, 4, DIRT);
  b.ell(46, 50, 17, 11, AIR);
  b.ell(76, 26, 17, 8, AIR);
  b.ell(100, 52, 15, 15, AIR);
  b.line(24, 58, 27, 71, 2.6, AIR);
  b.line(27, 71, 100, 72, 3, AIR);
  b.line(98, 62, 98, 72, 2.6, AIR);
  b.line(22, 54, 32, 50, 3.2, AIR);
  b.line(56, 42, 66, 30, 3.2, AIR);
  b.line(86, 30, 94, 42, 3.2, AIR);
  b.line(60, 56, 88, 56, 3, AIR);
  // seams of hard rock through the earth
  b.ell(46, 63, 9, 2, ROCK);
  b.ell(76, 36, 8, 1.6, ROCK);
  b.ell(30, 40, 5, 3, ROCK);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  b.plat(34, 52, 10);
  b.plat(50, 44, 8);
  b.plat(68, 30, 10);
  b.plat(90, 46, 10);
  b.plat(88, 60, 6);
  // lanterns hanging over every scaffold
  for (const [x, y] of [[38, 49], [53, 41], [72, 27], [94, 43], [10, 51]]) { b.dyn(x, y, "lantern"); b.light(x, y, 58, "#ffc46a", 0.08); }
  b.pick(72, 24, "sniper"); b.pick(97, 40, "rpg"); b.pick(54, 38, "magnum"); b.pick(46, 52, "rifle"); b.pick(60, 69, "shotgun");
  b.pick(20, 55, "uzi"); b.pick(80, 69, "health"); b.pick(38, 46, "nades"); b.pick(90, 56, "flame"); b.pick(62, 22, "saw"); b.pick(40, 69, "e11");
  b.pickC(44, "saber");
  for (const x of [5, 8, 11, 14, 17]) b.spawn(x, 52);
  b.spawn(20, 52);
  return b;
}

const BUILDERS = [desert, city, cave];
const cache: ArenaMap[] = [];

export function getMap(id: number): ArenaMap {
  if (cache[id]) return cache[id];
  const b = BUILDERS[id](), theme = THEMES[id];
  b.mirror();
  const W = b.w, H = b.h, g = b.g;
  const tile = (x: number, y: number) => (x < 0 || y < 0 || x >= W || y >= H ? ROCK : g[y * W + x]);
  if (theme.decor === "cave") {
    // the back wall only hugs the rock: the big chambers open onto the deep cave behind them
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (solidT(tile(x, y))) continue;
        let near = false;
        for (let j = -3; j <= 3 && !near; j++) for (let i = -3; i <= 3; i++) if (solidT(tile(x + i, y + j))) { near = true; break; }
        b.bg[y * W + x] = near ? 2 : 0;
      }
  }
  const land = (tx: number, ty: number) => {
    for (let y = Math.max(0, ty); y < H - 1; y++) {
      const d = tile(tx, y + 1);
      if (tile(tx, y) === AIR && (solidT(d) || d === PLAT)) return (y + 1) * AT;
    }
    return ty * AT;
  };
  const mx = (x: number) => W - 1 - x;
  const picks: ArenaMap["picks"] = [];
  for (const [x, y, k] of b.picks) for (const xx of [x, mx(x)]) picks.push({ x: (xx + 0.5) * AT, y: land(xx, y), kind: k });
  for (const [y, k] of b.cpicks) picks.push({ x: (W >> 1) * AT, y: land(W >> 1, y), kind: k });
  const spawns: ArenaMap["spawns"] = [[], []];
  for (const [x, y] of b.spawns) {
    spawns[0].push({ x: (x + 0.5) * AT, y: land(x, y) });
    spawns[1].push({ x: (mx(x) + 0.5) * AT, y: land(mx(x), y) });
  }
  const lights: Light[] = [];
  for (const [x, y, r, col, pulse] of b.lights) for (const xx of [x, W - x]) lights.push({ x: xx * AT, y: y * AT, r, col, pulse });
  const decor: Decor[] = [], dyn: Dyn[] = [];
  for (const [x, y, k] of b.decs) for (const xx of [x, mx(x)]) decor.push({ x: (xx + 0.5) * AT, y: y * AT, k, v: hsh(xx, y, 9), h: 0 });
  for (const [x, y, k] of b.dyns) for (const xx of [x, mx(x)]) dyn.push({ k, x: (xx + 0.5) * AT, y: y * AT, h: 0, t: xx < W / 2 ? 0 : 1, v: hsh(xx, y, 4) });
  if (theme.decor === "cave") {
    // the mine railway along the floor of the deep tunnel, its timber props, a cart full of crystals
    const floorAt = (x: number, y0: number) => { for (let y = y0; y < H - 1; y++) if (!solidT(tile(x, y)) && solidT(tile(x, y + 1))) return y + 1; return -1; };
    for (let x = 28; x < W - 28; x++) { const f = floorAt(x, 68); if (f > 0 && f < 80) decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "rail", v: 0, h: 0 }); }
    for (const x0 of [36, 52, 84]) for (const x of [x0, mx(x0)]) {
      const f = floorAt(x, 68);
      if (f < 0) continue;
      let c = f - 1;
      while (c > 0 && !solidT(tile(x, c))) c--;
      decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "beam", v: 0, h: (f - c - 1) * AT });
    }
    for (const x of [62, mx(62)]) { const f = floorAt(x, 68); if (f > 0) decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "cart", v: hsh(x, f, 3), h: 0 }); }
    // the waterfall: out of a crack in the roof of the great hall, all the way down into the dark
    const cx = W >> 1;
    let y0 = 25;
    while (y0 < H && solidT(tile(cx, y0))) y0++;
    let y1 = y0;
    while (y1 < H && !solidT(tile(cx, y1))) y1++;
    dyn.push({ k: "fall", x: cx * AT, y: y0 * AT, h: (y1 - y0) * AT, t: 0, v: 0 });
    for (let k = 0; k < 4; k++) lights.push({ x: cx * AT, y: y0 * AT + ((y1 - y0) * AT * (k + 0.5)) / 4, r: 48, col: "#6fd2ff", pulse: 0.12 });
  }
  // scattered props on the surfaces (and, in the cave, crystals that light it up and rock hanging from the ceilings)
  for (let y = 1; y < H - 2; y++)
    for (let x = 3; x < W - 3; x++) {
      const t = tile(x, y), dn = tile(x, y + 1), up = tile(x, y - 1), q = hsh(x, y, 77);
      if (t === AIR && solidT(dn) && !solidT(tile(x - 1, y)) && !solidT(tile(x + 1, y)) && solidT(tile(x - 1, y + 1)) && solidT(tile(x + 1, y + 1))) {
        if (decor.some((d) => d.k !== "rail" && Math.abs(d.x - (x + 0.5) * AT) < 12 && Math.abs(d.y - (y + 1) * AT) < 12)) continue;
        const k = hsh(x, y, 78);
        if (theme.decor === "desert" && q < 0.17) decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: k < 0.28 ? "cactus" : k < 0.5 ? "rock" : k < 0.64 ? "bones" : "tuft", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "city" && q < 0.12) decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: k < 0.4 ? "rubble" : k < 0.6 ? "cone" : k < 0.8 ? "tire" : "weed", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "cave" && q < 0.16) {
          const crystal = k < 0.42, v = hsh(x, y, 5);
          decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: crystal ? "crystal" : k < 0.74 ? "shroom" : "rock", v, h: 0 });
          if (crystal) lights.push({ x: (x + 0.5) * AT, y: (y + 1) * AT - 6, r: v > 0.5 ? 54 : 40, col: ["#5ff0e0", "#d07aff", "#7dff9a", "#ffcf5a"][(v * 4) | 0], pulse: 0.16 });
        }
      }
      if (theme.decor === "cave" && t === AIR && solidT(up) && q > 0.9 && !solidT(dn)) decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "stalag", v: hsh(x, y, 6), h: 0 });
    }
  // navigation: 16px cells where a soldier fits standing (the cell and the one above it are clear)
  const nw = W >> 1, nh = H >> 1, open = new Uint8Array(nw * nh), nav = new Uint8Array(nw * nh);
  for (let cy = 0; cy < nh; cy++)
    for (let cx = 0; cx < nw; cx++) {
      let ok = 1;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) if (solidT(tile(cx * 2 + dx, cy * 2 + dy))) ok = 0;
      open[cy * nw + cx] = ok;
    }
  for (let cy = 1; cy < nh; cy++) for (let cx = 0; cx < nw; cx++) nav[cy * nw + cx] = open[cy * nw + cx] && open[(cy - 1) * nw + cx] ? 1 : 0;
  const m: ArenaMap = { id, theme, w: W, h: H, grid: g, bg: b.bg, spawns, picks, lights, decor, dyn, nav, nw, nh };
  cache[id] = m;
  return m;
}

export const tileAt = (m: ArenaMap, tx: number, ty: number) => (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h ? ROCK : m.grid[ty * m.w + tx]);
export const solidPx = (m: ArenaMap, x: number, y: number) => solidT(tileAt(m, Math.floor(x / AT), Math.floor(y / AT)));

// ───────────── pathfinding (BFS over the nav cells, then pulled tight) ─────────────
let prev = new Int32Array(0);
let queue = new Int32Array(0);
const D8 = [1, 0, -1, 0, 0, 1, 0, -1, 1, 1, -1, 1, 1, -1, -1, -1];

function navCell(m: ArenaMap, x: number, y: number): number {
  const cx = Math.max(0, Math.min(m.nw - 1, Math.floor(x / 16))), cy = Math.max(0, Math.min(m.nh - 1, Math.floor((y - 4) / 16)));
  if (m.nav[cy * m.nw + cx]) return cy * m.nw + cx;
  for (let r = 1; r <= 4; r++)
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x2 = cx + dx, y2 = cy + dy;
        if (x2 >= 0 && y2 >= 0 && x2 < m.nw && y2 < m.nh && m.nav[y2 * m.nw + x2]) return y2 * m.nw + x2;
      }
  return -1;
}
function segClear(m: ArenaMap, x0: number, y0: number, x1: number, y1: number) {
  const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 6);
  for (let i = 1; i < n; i++) {
    const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n;
    const cx = Math.floor(x / 16), cy = Math.floor((y - 4) / 16);
    if (cx < 0 || cy < 0 || cx >= m.nw || cy >= m.nh || !m.nav[cy * m.nw + cx]) return false;
  }
  return true;
}
/** a path for a flying soldier from feet (sx, sy) to (gx, gy): flat [x, y, x, y, ...] of feet positions, start excluded */
export function findPath(m: ArenaMap, sx: number, sy: number, gx: number, gy: number): number[] {
  const nw = m.nw, N = nw * m.nh, nav = m.nav;
  if (prev.length < N) { prev = new Int32Array(N); queue = new Int32Array(N); }
  const s = navCell(m, sx, sy), goal = navCell(m, gx, gy);
  if (s < 0 || goal < 0) return [];
  if (s === goal) return [gx, gy];
  prev.fill(-1, 0, N);
  let head = 0, tail = 0;
  queue[tail++] = s;
  prev[s] = s;
  let found = false;
  while (head < tail) {
    const cur = queue[head++];
    if (cur === goal) { found = true; break; }
    const cx = cur % nw, cy = (cur / nw) | 0;
    for (let d = 0; d < 16; d += 2) {
      const dx = D8[d], dy = D8[d + 1], nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= nw || ny >= m.nh) continue;
      const ni = ny * nw + nx;
      if (!nav[ni] || prev[ni] !== -1) continue;
      if (dx && dy && (!nav[cy * nw + nx] || !nav[ny * nw + cx])) continue;
      prev[ni] = cur;
      queue[tail++] = ni;
    }
  }
  if (!found) return [];
  const cells: number[] = [];
  for (let c = goal; c !== s; c = prev[c]) cells.push(c);
  cells.reverse();
  const pts: number[] = [];
  for (const c of cells) pts.push(((c % nw) + 0.5) * 16, (((c / nw) | 0) + 1) * 16 - 1);
  pts[pts.length - 2] = gx;
  pts[pts.length - 1] = gy;
  const out: number[] = [];
  let ax = sx, ay = sy, i = 0;
  while (i < pts.length) {
    let j = pts.length - 2;
    while (j > i && !segClear(m, ax, ay, pts[j], pts[j + 1])) j -= 2;
    out.push(pts[j], pts[j + 1]);
    ax = pts[j];
    ay = pts[j + 1];
    i = j + 2;
  }
  return out;
}

// ───────────── painting ─────────────
const CRYS = [
  ["#5ff0e0", "#d2fff9", "#1e7f80", "#3ad8c8"],
  ["#d07aff", "#f4d4ff", "#64289a", "#b050ff"],
  ["#7dff9a", "#dcffe4", "#2a8048", "#4ee070"],
  ["#ffcf5a", "#fff2c4", "#94621a", "#ffb030"],
];
type Ctx = CanvasRenderingContext2D;

/** one crystal: a pointed prism, lit from the left, glowing from inside */
function shard(g: Ctx, eg: Ctx | null, bx: number, by: number, h: number, tilt: number, pal: string[]) {
  const row = (i: number) => ({ w: Math.max(1, Math.round(4 * (1 - i / h)) + (i < h * 0.3 ? 1 : 0)), cx: Math.round(bx + tilt * i) });
  g.fillStyle = "#120c18";
  for (let i = 0; i <= h; i++) { const r = row(i); g.fillRect(r.cx - (r.w >> 1) - 1, by - i - 1, r.w + 2, 1); }
  for (let i = 0; i < h; i++) {
    const r = row(i), x0 = r.cx - (r.w >> 1);
    g.fillStyle = pal[0]; g.fillRect(x0, by - i - 1, r.w, 1);
    g.fillStyle = pal[1]; g.fillRect(x0, by - i - 1, Math.max(1, r.w >> 1), 1);
    if (r.w > 2) { g.fillStyle = pal[2]; g.fillRect(x0 + r.w - 1, by - i - 1, 1, 1); }
    if (eg) { eg.fillStyle = pal[3]; eg.globalAlpha = 0.7; eg.fillRect(x0, by - i - 1, r.w, 1); eg.globalAlpha = 1; }
  }
  if (eg) { eg.globalAlpha = 0.55; eg.drawImage(halo(pal[3]), bx - h, by - h * 1.4, h * 2, h * 2); eg.globalAlpha = 1; }
}

function decorDraw(g: Ctx, eg: Ctx | null, d: Decor, T: Theme) {
  const R = (c: string, x: number, y: number, w: number, h: number) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  const x = Math.round(d.x), y = Math.round(d.y), K = "#16121a";
  switch (d.k) {
    case "cactus": {
      const h = 9 + Math.round(d.v * 7);
      R(K, x - 2, y - h - 1, 5, h + 1); R("#3f7a3a", x - 1, y - h, 3, h); R("#5a9a4a", x - 1, y - h, 1, h); R("#2a5a2a", x + 1, y - h, 1, h);
      R(K, x - 5, y - h + 3, 4, 5); R("#3f7a3a", x - 4, y - h + 4, 2, 3); R(K, x + 2, y - h + 5, 4, 4); R("#3f7a3a", x + 3, y - h + 5, 2, 2);
      for (let i = 2; i < h; i += 3) R("#e9e2c8", x + (i % 2 ? -2 : 2), y - i, 1, 1);
      if (d.v > 0.55) { R("#ff6b8a", x, y - h - 2, 1, 2); R("#ffd84a", x, y - h - 1, 1, 1); }
      break;
    }
    case "rock": R(K, x - 5, y - 5, 10, 5); R(T.decor === "cave" ? "#6a6280" : "#a8885e", x - 4, y - 4, 8, 4); R(T.decor === "cave" ? "#8a82a0" : "#c9a676", x - 4, y - 4, 4, 1); R(T.decor === "cave" ? "#4a4258" : "#7a5c38", x + 1, y - 2, 3, 2); break;
    case "bones":
      R("#0a0a0f", x - 5, y - 4, 11, 4); R("#e9e2c8", x - 4, y - 3, 6, 2); R("#c9c0a0", x - 4, y - 2, 6, 1); R("#0a0a0f", x - 2, y - 3, 1, 1); R("#0a0a0f", x, y - 3, 1, 1);
      R("#e9e2c8", x - 6, y - 6, 2, 3); R("#e9e2c8", x + 2, y - 6, 2, 3); R("#e9e2c8", x + 3, y - 2, 3, 1);
      break;
    case "tuft": for (let i = 0; i < 5; i++) R(i % 2 ? "#b8a050" : "#d8c070", x - 2 + i, y - 2 - (i % 3), 1, 2 + (i % 3)); break;
    case "palm": {
      const h = 24 + Math.round(d.v * 10), lean = Math.round((d.v - 0.5) * 12), at = (i: number) => x + Math.round(lean * (i / h) * (i / h));
      for (let i = 0; i < h; i++) R(K, at(i) - 2, y - i - 1, 5, 1);
      for (let i = 0; i < h; i++) { const xx = at(i); R(i % 4 === 0 ? "#6a4826" : "#8e6438", xx - 1, y - i - 1, 3, 1); R("#b08452", xx - 1, y - i - 1, 1, 1); }
      const tx = at(h), ty = y - h;
      const fr: [number, number][] = [[-2.5, 1.1], [-1.9, 1.2], [-1.2, 0.8], [-0.45, 0.5], [0.45, 0.5], [1.2, 0.8], [1.9, 1.2], [2.5, 1.1]];
      for (const pass of [0, 1])
        for (const [a, dr] of fr)
          for (let j = 0; j < 12; j++) {
            const r = j * 1.2, fx = tx + Math.sin(a) * r, fy = ty - Math.cos(a) * r * 0.55 + j * j * 0.07 * dr;
            if (pass === 0) R(K, fx - 1, fy - 1, 3, 3);
            else R(j % 3 === 0 ? "#2c7231" : j % 3 === 1 ? "#4fa046" : "#6cc05a", fx, fy, j < 9 ? 2 : 1, 1);
          }
      R("#0a0a0f", tx - 3, ty, 7, 4); R("#5a3a1a", tx - 2, ty + 1, 2, 2); R("#6a4422", tx + 1, ty + 1, 2, 2);
      break;
    }
    case "sandbag":
      for (let r = 0; r < 2; r++)
        for (let k = 0; k < 3 - r; k++) {
          const bx = x - 9 + k * 6 + r * 3, by = y - 4 - r * 3;
          R(K, bx, by - 1, 7, 5); R("#c9aa76", bx + 1, by, 5, 3); R("#e4cb98", bx + 1, by, 5, 1); R("#9a7e52", bx + 1, by + 2, 5, 1); R("#9a7e52", bx + 3, by, 1, 3);
        }
      break;
    case "crate":
      R(K, x - 6, y - 11, 12, 11); R("#a87a48", x - 5, y - 10, 10, 9); R("#c8965a", x - 5, y - 10, 10, 1); R("#6e4c2a", x - 5, y - 2, 10, 1);
      for (let i = 0; i < 8; i++) R("#7a5430", x - 5 + i + 1, y - 9 + i, 1, 1);
      R("#7a5430", x - 5, y - 10, 1, 9); R("#7a5430", x + 4, y - 10, 1, 9);
      break;
    case "barrel":
      R(K, x - 4, y - 11, 9, 11); R("#5a6a7a", x - 3, y - 10, 7, 9); R("#8a9aaa", x - 2, y - 10, 1, 9); R("#2e3a46", x - 3, y - 8, 7, 1); R("#2e3a46", x - 3, y - 4, 7, 1);
      R("#9a5a2a", x + 1, y - 7, 2, 2); R("#e0483e", x - 1, y - 10, 3, 1);
      break;
    case "pillar": {
      const h = 12 + Math.round(d.v * 12);
      R(K, x - 5, y - 3, 11, 3); R(T.rock[1], x - 4, y - 2, 9, 2);
      R(K, x - 4, y - h, 9, h - 2); R(T.rock[0], x - 3, y - h + 1, 7, h - 3); R(T.rock[1], x - 3, y - h + 1, 1, h - 3); R(T.rock[2], x - 1, y - h + 1, 1, h - 3); R(T.rock[2], x + 2, y - h + 1, 1, h - 3);
      R(K, x - 4, y - h - 2, 3, 3); R(T.rock[0], x - 3, y - h - 1, 2, 2); R(K, x + 1, y - h - 1, 3, 2); R(T.rock[0], x + 2, y - h, 1, 1);
      break;
    }
    case "rubble": R(K, x - 4, y - 3, 9, 3); R("#7a7473", x - 3, y - 2, 3, 2); R("#968f8b", x, y - 3, 3, 3); R("#5a5458", x + 2, y - 1, 2, 1); break;
    case "cone": R(K, x - 3, y - 7, 6, 7); R("#f08a3c", x - 2, y - 6, 4, 6); R("#ffffff", x - 2, y - 4, 4, 1); R(K, x - 4, y - 1, 8, 1); break;
    case "tire": R(K, x - 4, y - 5, 8, 5); R("#2a2a30", x - 3, y - 4, 6, 3); R("#46464e", x - 1, y - 3, 2, 1); break;
    case "weed": for (let i = 0; i < 3; i++) R("#4a6a3a", x - 1 + i, y - 2 - i, 1, 2 + i); break;
    case "lamp":
      R(K, x - 1, y - 30, 3, 30); R("#4a4e5a", x, y - 30, 1, 30); R(K, x - 1, y - 31, 7, 3); R("#4a4e5a", x, y - 30, 5, 1); R("#ffe9a0", x + 3, y - 29, 3, 1);
      if (eg) { eg.fillStyle = "#ffe9a0"; eg.fillRect(x + 3, y - 29, 3, 1); eg.globalAlpha = 0.45; eg.drawImage(halo("#ffd98a"), x - 6, y - 38, 20, 20); eg.globalAlpha = 1; }
      break;
    case "crystal": {
      const pal = CRYS[(d.v * 4) | 0], big = d.v > 0.5;
      const sh: [number, number, number][] = big ? [[-7, 6, -0.55], [7, 7, 0.5], [-4, 10, -0.3], [4, 11, 0.28], [0, 15, 0.02]] : [[-3, 6, -0.3], [3, 7, 0.35], [0, 10, 0.04]];
      for (const [ox, h, tilt] of sh) shard(g, eg, x + ox, y, h, tilt, pal);
      R("#120c18", x - (big ? 9 : 5), y - 1, big ? 19 : 11, 1);
      break;
    }
    case "shroom": {
      const cap = d.v < 0.5 ? "#5ad0b0" : "#e06aa8", hi = d.v < 0.5 ? "#b8fff0" : "#ffc8e4", h = 3 + Math.round(d.v * 4);
      R("#0a0a0f", x - 1, y - h, 3, h); R("#e9e2c8", x, y - h, 1, h);
      R(K, x - 4, y - h - 3, 9, 4); R(cap, x - 3, y - h - 2, 7, 2); R(hi, x - 2, y - h - 2, 2, 1); R("#ffffff", x + 1, y - h - 2, 1, 1);
      if (eg) { eg.fillStyle = cap; eg.fillRect(x - 3, y - h - 2, 7, 2); eg.globalAlpha = 0.5; eg.drawImage(halo(cap), x - 10, y - h - 12, 20, 20); eg.globalAlpha = 1; }
      break;
    }
    case "stalag": { const h = 4 + Math.round(d.v * 7); for (let i = 0; i < h; i++) R(i < h - 1 ? T.dirt[2] : "#16121a", x - Math.max(0, 2 - ((i * 3) / h) | 0), y + i, Math.max(1, 5 - ((i * 5) / h) | 0), 1); break; }
    case "rail":
      R("#2a1e14", x - 4, y - 2, 3, 2); R("#2a1e14", x, y - 2, 3, 2);
      R("#1a1a22", x - 4, y - 4, 8, 2); R("#9a9eb0", x - 4, y - 4, 8, 1);
      break;
    case "beam": {
      const h = d.h;
      R(K, x - 2, y - h, 5, h); R(T.plank[0], x - 1, y - h, 3, h); R(T.plank[1], x + 1, y - h, 1, h);
      R(K, x - 10, y - h, 21, 5); R(T.plank[0], x - 9, y - h + 1, 19, 3); R("rgba(255,255,255,0.15)", x - 9, y - h + 1, 19, 1);
      R("#9a9eb0", x - 7, y - h + 2, 1, 1); R("#9a9eb0", x + 7, y - h + 2, 1, 1);
      break;
    }
    case "cart": {
      const pal = CRYS[(d.v * 4) | 0];
      for (let i = 0; i < 6; i++) { const ox = -6 + i * 2.4, h = 3 + ((i * 7) % 4); R("#120c18", x + ox - 1, y - 16 - h, 4, h + 1); R(pal[i % 2], x + ox, y - 15 - h, 2, h); if (eg) { eg.fillStyle = pal[3]; eg.fillRect(Math.round(x + ox), y - 15 - h, 2, h); } }
      R(K, x - 9, y - 15, 19, 11); R("#4a4e5c", x - 8, y - 14, 17, 9); R("#6a7084", x - 8, y - 14, 17, 1); R("#2e3240", x - 8, y - 7, 17, 1);
      for (const rx of [-6, -1, 4]) R("#9a9eb0", x + rx, y - 12, 1, 1);
      for (const wx of [-6, 3]) { R(K, x + wx, y - 5, 5, 5); R("#3a3a44", x + wx + 1, y - 4, 3, 3); R("#9a9eb0", x + wx + 2, y - 3, 1, 1); }
      if (eg) { eg.globalAlpha = 0.5; eg.drawImage(halo(pal[3]), x - 14, y - 32, 28, 28); eg.globalAlpha = 1; }
      break;
    }
  }
}

/** the whole arena on one canvas - painted pixel by pixel - and a second one with everything that gives off its own light */
export function paintTerrain(m: ArenaMap): { terr: HTMLCanvasElement; emis: HTMLCanvasElement | null } {
  const T = m.theme, TW = m.w, TH = m.h, W = TW * AT, H = TH * AT, desert = T.decor === "desert", cave = T.decor === "cave", city = T.decor === "city";
  const [c, g] = mk(W, H), img = g.createImageData(W, H), d = img.data;
  let ec: HTMLCanvasElement | null = null, eg: Ctx | null = null;
  if (!desert) [ec, eg] = mk(W, H);
  const eimg = eg ? eg.createImageData(W, H) : null, e = eimg ? eimg.data : null;
  const sol = (x: number, y: number) => solidT(tileAt(m, x, y));
  const depth = new Uint16Array(TW * TH);
  for (let x = 0; x < TW; x++) { let n = 0; for (let y = 0; y < TH; y++) { const i = y * TW + x; n = solidT(m.grid[i]) ? n + 1 : 0; depth[i] = n; } }
  const D0 = rgb(T.dirt[0]), D1 = rgb(T.dirt[1]), D2 = rgb(T.dirt[2]), T0 = rgb(T.top[0]), T1 = rgb(T.top[1]);
  const R0 = rgb(T.rock[0]), R1 = rgb(T.rock[1]), R2 = rgb(T.rock[2]), W0 = rgb(T.wall[0]), W1 = rgb(T.wall[1]), C0 = rgb(T.cave[0]), C1 = rgb(T.cave[1]);
  const BLK = [8, 6, 14], CY = [90, 240, 224], MG = [214, 128, 255], WIN = rgb("#ffcf7a"), WOFF = rgb("#232030"), WFR = rgb("#15131c");
  const glow = (o: number, col: number[], k: number) => { if (e) { e[o] = col[0] * k; e[o + 1] = col[1] * k; e[o + 2] = col[2] * k; e[o + 3] = 255; } };
  for (let py = 0; py < H; py++) {
    const ty = py >> 3, iy = py & 7;
    for (let px = 0; px < W; px++) {
      const tx = px >> 3, ix = px & 7, ti = ty * TW + tx, t = m.grid[ti], o = (py * W + px) * 4;
      let col: number[] | null = null;
      if (solidT(t)) {
        const sd = (depth[ti] - 1) * AT + iy;
        const edge = (ix === 0 && !sol(tx - 1, ty)) || (ix === 7 && !sol(tx + 1, ty)) || (iy === 7 && !sol(tx, ty + 1));
        if (t === DIRT) {
          if (desert) {
            // sand: wind ripples, a bright crust on top, darker and more packed the deeper it goes
            const n = vn(px * 0.045, py * 0.045, 1);
            col = mixc(D0, D1, n);
            const rip = Math.sin(px * 0.4 + py * 1.3 + n * 7);
            if (rip > 0.87) col = mixc(col, T0, 0.6); else if (rip < -0.9) col = mixc(col, D2, 0.25);
            col = mixc(col, D2, Math.min(1, sd / 120) * 0.55);
            if (sd < 2) col = T1; else if (sd < 4) col = T0; else if (sd < 6 && hsh(px, py, 3) < 0.45) col = T0;
            if (hsh(px, py, 4) < 0.004) col = mixc(col, D2, 0.7);
          } else if (cave) {
            // cave rock: mottled, moss on top - and veins of crystal running through it that glow in the dark
            const n = vn(px * 0.06, py * 0.06, 3), n2 = vn(px * 0.19, py * 0.19, 4);
            col = mixc(D0, D1, n * 0.75 + n2 * 0.25);
            if (n2 > 0.8) col = mixc(col, D2, 0.45);
            col = mixc(col, D2, Math.min(1, sd / 90) * 0.5);
            if (sd < 2) col = T1; else if (sd < 4) col = T0; else if (sd < 6 && hsh(px, py, 6) < 0.4) col = T0;
            else if (sd > 6 && sd < 90) {
              // (only in patches: short seams of crystal, not lines across the whole rock)
              const vv = Math.abs(Math.sin(px * 0.055 + py * 0.032 + vn(px * 0.014, py * 0.014, 5) * 9));
              if (vv < 0.03 && vn(px * 0.022, py * 0.022, 16) > 0.6) { const vc = vn(px * 0.01, py * 0.01, 7) < 0.5 ? CY : MG; col = mixc(col, vc, 0.7); glow(o, vc, 0.36); }
            }
          } else {
            const n = vn(px * 0.08, py * 0.08, 8);
            col = mixc(D0, D1, n);
            if (hsh(px, py, 9) < 0.01) col = mixc(col, D2, 0.6);
            if (sd < 3) col = sd < 1 ? T1 : T0;
            col = mixc(col, D2, Math.min(1, sd / 100) * 0.4);
          }
        } else if (desert) {
          // sandstone: layered bands, pitted by the wind
          const n = vn(px * 0.03, py * 0.11, 2), bk = (((py + n * 5) / 3) | 0) % 5;
          col = bk === 0 ? R1 : bk === 2 ? mixc(R0, R2, 0.3) : bk === 4 ? mixc(R1, T0, 0.35) : R0;
          if (hsh(px >> 1, py, 5) < 0.03) col = mixc(col, R2, 0.55);
          if (sd < 2) col = mixc(R1, T1, 0.45);
        } else if (cave) {
          // cobbles of hard rock
          const row = (py / 5) | 0, off = (row & 1) * 3, mortar = py % 5 === 0 || (px + off) % 6 === 0;
          col = mortar ? R2 : mixc(R0, R1, hsh(((px + off) / 6) | 0, row, 7) * 0.8);
          if (!mortar && py % 5 === 1) col = mixc(col, R1, 0.45);
        } else {
          const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
          col = mortar ? R2 : mixc(R0, R1, hsh(((px + off) / 8) | 0, row, 10) * 0.6);
        }
        if (edge) col = mixc(col, BLK, 0.45);
      } else if (m.bg[ti]) {
        const v = m.bg[ti];
        let k = 0;
        if (sol(tx, ty - 1)) k = Math.max(k, (1 - iy / 8) * 0.55);
        if (sol(tx - 1, ty)) k = Math.max(k, (1 - ix / 8) * 0.4);
        if (sol(tx + 1, ty)) k = Math.max(k, (ix / 8) * 0.4);
        if (sol(tx, ty + 1)) k = Math.max(k, (iy / 8) * 0.25);
        if (v === 1) {
          if (city) {
            const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
            col = mortar ? W1 : mixc(W0, W1, hsh(((px + off) / 8) | 0, row, 11) * 0.5);
            for (const wx of [tx, tx - 1])
              for (const wy of [ty, ty - 1]) {
                if (wx % 4 !== 1 || wy % 5 !== 1 || hsh(wx, wy, 3) >= 0.55) continue;
                const lx = px - (wx * 8 + 1), ly = py - (wy * 8 + 2);
                if (lx < 0 || ly < 0 || lx >= 10 || ly >= 10) continue;
                const lit = hsh(wx, wy, 4) < 0.25, fr = lx === 0 || ly === 0 || lx === 9 || ly === 9;
                col = fr ? WFR : lit ? WIN : WOFF;
                if (lit && !fr) glow(o, WIN, 0.35);
              }
          } else {
            // the bunker's concrete: panels, seams, stains
            col = px % 16 === 0 || py % 12 === 0 ? W1 : mixc(W0, W1, vn(px * 0.1, py * 0.1, 12) * 0.5);
            if (vn(px * 0.05, py * 0.2, 13) > 0.74) col = mixc(col, BLK, 0.18);
          }
        } else {
          // the back of the tunnels and caves
          const n = vn(px * 0.07, py * 0.07, 14), n2 = vn(px * 0.2, py * 0.2, 15);
          col = mixc(C0, C1, n * 0.7 + n2 * 0.3);
          if (desert && (py + ((n * 4) | 0)) % 6 === 0) col = mixc(col, BLK, 0.15);
          if (cave && n2 > 0.82) col = mixc(col, BLK, 0.25);
        }
        col = mixc(col, BLK, k);
      }
      if (col) { d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = 255; }
    }
  }
  g.putImageData(img, 0, 0);
  if (eg && eimg) eg.putImageData(eimg, 0, 0);
  const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  const at = (x: number, y: number) => tileAt(m, x, y);
  for (let y = 0; y < TH; y++)
    for (let x = 0; x < TW; x++) {
      const t = m.grid[y * TW + x], px = x * AT, py = y * AT;
      if (t === PLAT) {
        R("#16121a", px, py, AT, 4);
        R(T.plank[0], px, py, AT, 3);
        R(T.plank[1], px, py + 2, AT, 1);
        R("rgba(255,255,255,0.18)", px, py, AT, 1);
        if (x % 2 === 0) R("#16121a", px + 1, py + 1, 1, 1);
        R("rgba(0,0,0,0.22)", px, py + 4, AT, 1);
        if (at(x - 1, y) !== PLAT || at(x + 1, y) !== PLAT) { R("#16121a", px + 3, py + 3, 2, 4); R(T.plank[1], px + 3, py + 3, 1, 3); }
      } else if (t === AIR && solidT(at(x, y - 1))) {
        R("rgba(0,0,0,0.24)", px, py, AT, 2);
        R("rgba(0,0,0,0.12)", px, py + 2, AT, 3);
        // moss and roots hang from the cave roof, some of them tipped with light
        if (cave) {
          const q = hsh(x, y, 91);
          if (q < 0.4) {
            const sx = px + ((hsh(x, y, 92) * 7) | 0), len = 2 + ((hsh(x, y, 93) * 6) | 0);
            R(q < 0.22 ? T.top[0] : "#4a3a2a", sx, py, 1, len);
            if (q < 0.08 && eg) { R("#7dff9a", sx, py + len, 1, 1); eg.fillStyle = "#7dff9a"; eg.fillRect(sx, py + len, 1, 1); }
          }
        }
      }
    }
  for (const dd of m.decor) decorDraw(g, eg, dd, T);
  return { terr: c, emis: ec };
}

/** the minimap: one pixel per two tiles */
export function paintMini(m: ArenaMap): HTMLCanvasElement {
  const [c, g] = mk(m.w >> 1, m.h >> 1), T = m.theme;
  g.fillStyle = "rgba(10,10,18,0.72)";
  g.fillRect(0, 0, c.width, c.height);
  for (let y = 0; y < c.height; y++)
    for (let x = 0; x < c.width; x++) {
      const t = tileAt(m, x * 2, y * 2), t2 = tileAt(m, x * 2 + 1, y * 2 + 1);
      if (solidT(t) || solidT(t2)) { g.fillStyle = t === ROCK ? T.rock[1] : T.dirt[0]; g.fillRect(x, y, 1, 1); }
      else if (t === PLAT) { g.fillStyle = T.plank[0]; g.fillRect(x, y, 1, 1); }
    }
  return c;
}

/** a preview of the arena for the lobby */
export function mapPreview(id: number): string {
  const m = getMap(id), T = m.theme, [c, g] = mk(m.w, m.h);
  const grd = g.createLinearGradient(0, 0, 0, m.h);
  grd.addColorStop(0, T.sky[0]); grd.addColorStop(0.6, T.sky[1]); grd.addColorStop(1, T.sky[2]);
  g.fillStyle = grd;
  g.fillRect(0, 0, m.w, m.h);
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const t = m.grid[y * m.w + x];
      const col = t === DIRT ? (tileAt(m, x, y - 1) === DIRT ? T.dirt[0] : T.top[0]) : t === ROCK ? T.rock[0] : t === PLAT ? T.plank[0] : m.bg[y * m.w + x] ? (m.bg[y * m.w + x] === 1 ? T.wall[0] : T.cave[0]) : "";
      if (col) { g.fillStyle = col; g.fillRect(x, y, 1, 1); }
    }
  for (const dd of m.dyn) if (dd.k === "fall") { g.fillStyle = "#6fd2ff"; g.fillRect(Math.floor(dd.x / AT), Math.floor(dd.y / AT), 1, Math.ceil(dd.h / AT)); }
  for (const dd of m.decor) if (dd.k === "crystal") { g.fillStyle = CRYS[(dd.v * 4) | 0][0]; g.fillRect(Math.floor(dd.x / AT), Math.floor(dd.y / AT) - 1, 1, 1); }
  for (const p of m.picks) { g.fillStyle = p.kind === "saber" ? "#9ae8ff" : p.kind === "health" ? "#ff6b7a" : p.kind === "nades" ? "#7dff9a" : "#ffe14a"; g.fillRect(Math.floor(p.x / AT), Math.floor(p.y / AT) - 1, 1, 1); }
  for (let t = 0; t < 2; t++) for (const s of m.spawns[t]) { g.fillStyle = t ? "#ff4d5e" : "#f5c542"; g.fillRect(Math.floor(s.x / AT), Math.floor(s.y / AT) - 2, 1, 2); }
  return c.toDataURL();
}

export interface Backdrop { far: HTMLCanvasElement | null; mid: HTMLCanvasElement | null; near: HTMLCanvasElement | null; clouds: HTMLCanvasElement[]; tile: boolean }

/** a horizontal band of the far landscape (960 wide, tileable) */
function band(draw: (g: Ctx, x0: number) => void): HTMLCanvasElement {
  const [c, g] = mk(960, 230);
  for (const x0 of [-960, 0, 960]) draw(g, x0);
  return c;
}
/** one layer of the deep cave behind the chambers: hanging rock, rising rock, columns, the faint light of crystals (tileable both ways) */
function caveLayer(col: string, rim: string, seed: number, glow: boolean): HTMLCanvasElement {
  const W = 480, H = 300, [c, g] = mk(W, H);
  g.fillStyle = col;
  const each = (fn: (dx: number) => void) => { for (const dx of [-W, 0, W]) fn(dx); };
  g.fillRect(0, 0, W, 16);
  g.fillRect(0, H - 18, W, 18);
  for (let i = 0; i < 16; i++) {
    const x = hsh(i, seed, 1) * W, w = 8 + hsh(i, seed, 2) * 22, len = 20 + hsh(i, seed, 3) * 70;
    each((dx) => { g.beginPath(); g.moveTo(x + dx - w, 14); g.lineTo(x + dx + w, 14); g.lineTo(x + dx + w * 0.15, 14 + len); g.closePath(); g.fill(); });
    const x2 = hsh(i, seed, 4) * W, w2 = 8 + hsh(i, seed, 5) * 20, len2 = 16 + hsh(i, seed, 6) * 56;
    each((dx) => { g.beginPath(); g.moveTo(x2 + dx - w2, H - 16); g.lineTo(x2 + dx + w2, H - 16); g.lineTo(x2 + dx - w2 * 0.1, H - 16 - len2); g.closePath(); g.fill(); });
  }
  for (let i = 0; i < 3; i++) {
    const x = (i + 0.3 + hsh(i, seed, 7) * 0.4) * (W / 3), w = 14 + hsh(i, seed, 8) * 18;
    each((dx) => {
      g.beginPath();
      g.moveTo(x + dx - w * 1.6, 0);
      for (let y = 0; y <= H; y += 20) g.lineTo(x + dx - w * (0.75 + 0.35 * Math.sin(y * 0.03 + i * 2 + seed)), y);
      for (let y = H; y >= 0; y -= 20) g.lineTo(x + dx + w * (0.75 + 0.35 * Math.cos(y * 0.027 + i + seed)), y);
      g.closePath();
      g.fill();
    });
  }
  // a little light catches the edges
  g.globalCompositeOperation = "source-atop";
  g.fillStyle = rim;
  for (let i = 0; i < 260; i++) g.fillRect(Math.floor(hsh(i, seed, 9) * W), Math.floor(hsh(i, seed, 10) * H), 2, 1);
  g.globalCompositeOperation = "source-over";
  if (glow) for (let i = 0; i < 26; i++) {
    const x = hsh(i, seed, 11) * W, y = H - 18 - hsh(i, seed, 12) * 40, pal = CRYS[i % 4];
    g.globalAlpha = 0.4; g.drawImage(halo(pal[3]), x - 9, y - 12, 18, 18); g.globalAlpha = 1;
    g.fillStyle = pal[0]; g.fillRect(Math.floor(x), Math.floor(y) - 3, 1, 4); g.fillRect(Math.floor(x) + 1, Math.floor(y) - 1, 1, 2);
  }
  return c;
}

/** the parallax layers behind the arena: a skyline, the desert in a storm, or the depths of the cave */
export function paintBackdrop(T: Theme): Backdrop {
  if (T.decor === "cave") return { far: caveLayer(T.far, "#2c2246", 3, true), mid: caveLayer(T.mid, "#3a2e5a", 7, true), near: null, clouds: [], tile: true };
  if (T.decor === "desert") {
    const lift = (hex: string, k: number) => { const c = rgb(hex); return `rgb(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0})`; };
    // far: flat-topped mesas and two pyramids, their sunny faces lighter
    const far = band((g, x0) => {
      for (let i = 0; i < 6; i++) {
        const x = x0 + i * 165 + hsh(i, 1, 1) * 50, w = 70 + hsh(i, 2, 1) * 60, h = 46 + hsh(i, 3, 1) * 46;
        g.fillStyle = T.far;
        g.beginPath(); g.moveTo(x, 230); g.lineTo(x + 10, 230 - h); g.lineTo(x + w - 14, 230 - h); g.lineTo(x + w, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.08); g.fillRect(x + 10, 230 - h, w - 24, 3);
      }
      for (const [px, pw, ph] of [[300, 130, 78], [690, 96, 56]]) {
        const x = x0 + px;
        g.fillStyle = lift(T.far, 0.94); g.beginPath(); g.moveTo(x - pw / 2, 230); g.lineTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.1); g.beginPath(); g.moveTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.lineTo(x + pw * 0.1, 230); g.closePath(); g.fill();
      }
    });
    const dunes = (col: string, hgt: number, seed: number, ruins: boolean) => band((g, x0) => {
      g.fillStyle = col;
      g.beginPath();
      g.moveTo(x0, 230);
      for (let x = 0; x <= 960; x += 4) { const k = (x / 960) * Math.PI * 2; g.lineTo(x0 + x, 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))); }
      g.lineTo(x0 + 960, 230);
      g.fill();
      // the wind has drawn a bright line along every ridge
      g.fillStyle = lift(col, 1.12);
      for (let x = 0; x <= 960; x += 2) { const k = (x / 960) * Math.PI * 2; g.fillRect(x0 + x, Math.round(230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))), 2, 1); }
      if (ruins) {
        g.fillStyle = lift(col, 0.82);
        for (const [rx, n] of [[140, 4], [520, 3], [800, 2]]) for (let i = 0; i < n; i++) {
          const x = x0 + rx + i * 22, k = ((rx + i * 22) / 960) * Math.PI * 2, base = 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2)) + 4, h = 26 + ((i * 13 + rx) % 20);
          g.fillRect(x, base - h, 7, h); g.fillRect(x - 2, base - h - 3, 11, 3);
          if (i < n - 1 && i % 2 === 0) g.fillRect(x, base - h - 6, 29, 3);
        }
      }
    });
    const clouds: HTMLCanvasElement[] = [];
    for (let i = 0; i < 4; i++) {
      const [c, g] = mk(120, 36);
      g.fillStyle = "rgba(240,196,140,0.5)";
      for (let k = 0; k < 7; k++) { g.beginPath(); g.ellipse(18 + k * 14 + hsh(i, k, 1) * 6, 20 - hsh(i, k, 2) * 8, 14 + hsh(i, k, 3) * 6, 8 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
      clouds.push(c);
    }
    return { far, mid: dunes(T.mid, 92, 3, false), near: dunes(T.near, 120, 5, true), clouds, tile: false };
  }
  const strip = (col: string, hgt: number, seed: number): HTMLCanvasElement => {
    const [c, g] = mk(960, 220);
    g.fillStyle = col;
    let x = 0;
    while (x < 960) {
      const w = 18 + Math.floor(hsh(x, seed, 1) * 34), h = hgt * (0.35 + hsh(x, seed, 2) * 0.65), broken = hsh(x, seed, 3) < 0.35;
      g.fillRect(x, 220 - h, w, h);
      if (broken) { g.clearRect(x + w * 0.5, 220 - h, w * 0.5, h * 0.18); g.fillRect(x + w * 0.55, 220 - h * 0.86, 2, -h * 0.12); }
      if (seed > 2) {
        g.fillStyle = "rgba(255,200,120,0.5)";
        for (let wy = 220 - h + 6; wy < 214; wy += 7) for (let wx = x + 3; wx < x + w - 3; wx += 5) if (hsh(wx, wy, seed) < 0.1) g.fillRect(wx, wy, 2, 2);
        g.fillStyle = col;
      }
      x += w + Math.floor(hsh(x, seed, 4) * 6);
    }
    return c;
  };
  const clouds: HTMLCanvasElement[] = [];
  for (let i = 0; i < 4; i++) {
    const [c, g] = mk(90, 30);
    g.fillStyle = "rgba(70,56,86,0.85)";
    for (let k = 0; k < 6; k++) { g.beginPath(); g.ellipse(18 + k * 11 + hsh(i, k, 1) * 6, 18 - hsh(i, k, 2) * 8, 12 + hsh(i, k, 3) * 6, 7 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
    clouds.push(c);
  }
  return { far: strip(T.far, 150, 1), mid: strip(T.mid, 120, 3), near: null, clouds, tile: false };
}

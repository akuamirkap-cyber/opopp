import { SKINS } from "../game/defs";
import { LOOK_PAL, TEAM_PAL, fromMap, initSprites, mk, portrait, whiten } from "../game/sprites";
import { hsh } from "./maps";

/**
 * The operators of the arena: the five of the menu, and the stormtrooper - white armour, black lenses, the frown of the
 * breathing grille, a stripe and a shoulder pauldron in the colour of the team.
 */
export const TROOPER = 5;
export const ARENA_SKINS = [...SKINS, "TROOPER"];
export const SKIN_TAGS = ["NINJA", "TANK", "VISOR", "TENGKORAK", "BAYANGAN", "IMPERIAL"];

const T_HEAD = [
  "....KKKKKK....",
  "..KKWWWWWWKK..",
  ".KWWWWWWWWWSK.",
  ".KWWWAAAAWWSK.",
  "KWWWWWWWWWWWSK",
  "KWMMMWWWWMMMSK",
  "KWMMMMWWMMMMSK",
  "KSWMMSGGSMMWsK",
  ".KSWGMGGMGWsK.",
  "..KKKKKKKKKK..",
];
const T_TORSO = [
  "..KAAWWWWSSK..",
  ".KAaWWMMWWSSK.",
  ".KWMWWWWWWMSK.",
  ".KWMSWBBWSMSK.",
  "..KKGGWWGGKK..",
  "...KWBKKBWK...",
];
const tpal = (team: number): Record<string, string> => ({
  K: "#0a0a0f", W: "#f2f5f9", S: "#cdd5df", s: "#98a2b0", M: "#15171e", G: "#5c6473", B: "#1c1f27", A: TEAM_PAL[team].A, a: TEAM_PAL[team].a,
});
const cache: Record<string, HTMLCanvasElement> = {};
const trooperSpr = (key: string, rows: string[], team: number, white: boolean) => {
  const k = key + team + (white ? "w" : "");
  if (!cache[k]) { const c = fromMap(rows, tpal(team)); cache[k] = white ? whiten(c) : c; }
  return cache[k];
};

export function opHead(team: number, skin: number, white = false): HTMLCanvasElement {
  if (skin === TROOPER) return trooperSpr("h", T_HEAD, team, white);
  const sp = initSprites();
  return (white ? sp.headW : sp.head)[team][skin] ?? sp.head[team][0];
}
export function opTorso(team: number, skin: number, white = false): HTMLCanvasElement {
  if (skin === TROOPER) return trooperSpr("t", T_TORSO, team, white);
  const sp = initSprites();
  return (white ? sp.torsoW : sp.torso)[team][skin] ?? sp.torso[team][0];
}

/** the colours a body is drawn with: legs, boots, sleeves, hands, the scarf (if any), and what the face is made of */
export interface OpPal { K: string; legs: string; boots: string; arm: string; hand: string; scarf: string; scarf2: string; lid: string; glow: string; skull: string; accent: string }
const palCache: Record<string, OpPal> = {};
export function opPal(team: number, skin: number): OpPal {
  const key = `${team}${skin}`;
  if (palCache[key]) return palCache[key];
  initSprites();
  const tp = TEAM_PAL[team], lp = LOOK_PAL[team][Math.min(skin, 4)];
  const p: OpPal = skin === TROOPER
    ? { K: "#0a0a0f", legs: "#e6ebf1", boots: "#1c1f27", arm: "#e6ebf1", hand: "#1c1f27", scarf: "", scarf2: "", lid: "#15171e", glow: "#ffffff", skull: "#f2f5f9", accent: tp.A }
    : { K: lp.K, legs: lp.D, boots: tp.K, arm: lp.B, hand: lp.F, scarf: lp.A, scarf2: lp.a, lid: skin <= 1 ? tp.F : skin === 3 ? tp.S : tp.D, glow: tp.V, skull: tp.S, accent: tp.A };
  palCache[key] = p;
  return p;
}

/**
 * Where the eyes are on each head (top-left of a 14x10 head, facing right) and what they are made of:
 * 0 eyes with whites (a white pixel, then the pupil), 1 a glowing visor, 2 the sockets of a skull, 3 a trooper's lenses.
 * [x, y, width]
 */
export interface EyeDef { kind: 0 | 1 | 2 | 3; e: number[][] }
export const EYES: EyeDef[] = [
  { kind: 0, e: [[5, 6], [9, 6]] },
  { kind: 0, e: [[4, 5], [9, 5]] },
  { kind: 1, e: [[3, 6, 2], [10, 6, 2], [6, 6, 3]] },
  { kind: 2, e: [[4, 5], [9, 5]] },
  { kind: 1, e: [[4, 6, 2], [8, 6, 2]] },
  { kind: 3, e: [[2, 5], [9, 5]] },
];

const urls: Record<number, string> = {};
/** a portrait of an operator for the menus (the gold team's colours) */
export function opPortrait(skin: number): string {
  if (skin !== TROOPER) return portrait(skin, 0);
  if (!urls[skin]) {
    const [c, x] = mk(16, 22);
    x.fillStyle = "rgba(0,0,0,0.35)";
    x.fillRect(3, 19, 10, 2);
    x.fillStyle = "#e6ebf1";
    x.fillRect(5, 17, 2, 3);
    x.fillRect(9, 17, 2, 3);
    x.fillStyle = "#1c1f27";
    x.fillRect(5, 19, 2, 1);
    x.fillRect(9, 19, 2, 1);
    x.drawImage(opTorso(0, TROOPER), 1, 11);
    x.drawImage(opHead(0, TROOPER), 1, 1);
    urls[skin] = c.toDataURL();
  }
  return urls[skin];
}

let tumble: HTMLCanvasElement | null = null, blob: HTMLCanvasElement | null = null;
/** a tumbleweed: a ball of dry tangled twigs */
export function tumbleSpr(): HTMLCanvasElement {
  if (!tumble) {
    const [c, g] = mk(15, 15);
    const cols = ["#8a6a3a", "#a8844a", "#6a4e2a", "#c4a060"];
    for (let i = 0; i < 90; i++) {
      const a = hsh(i, 1, 21) * Math.PI * 2, r = 2 + hsh(i, 2, 21) * 5;
      g.fillStyle = cols[i % 4];
      g.fillRect(Math.round(7 + Math.cos(a) * r), Math.round(7 + Math.sin(a) * r), 1, 1);
    }
    g.strokeStyle = "#7a5a30";
    g.lineWidth = 1;
    for (let i = 0; i < 6; i++) {
      const a = hsh(i, 3, 21) * Math.PI * 2, b = a + 1.5 + hsh(i, 4, 21) * 2;
      g.beginPath(); g.moveTo(7.5 + Math.cos(a) * 6, 7.5 + Math.sin(a) * 6); g.lineTo(7.5 + Math.cos(b) * 6, 7.5 + Math.sin(b) * 6); g.stroke();
    }
    tumble = c;
  }
  return tumble;
}
/** a soft cloud of blowing sand */
export function blobSpr(): HTMLCanvasElement {
  if (!blob) {
    const [c, g] = mk(64, 64), gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, "rgba(232,182,118,0.9)");
    gr.addColorStop(0.5, "rgba(222,168,104,0.45)");
    gr.addColorStop(1, "rgba(210,150,90,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 64, 64);
    blob = c;
  }
  return blob;
}

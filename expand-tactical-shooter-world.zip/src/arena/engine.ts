import { audio } from "../game/audio";
import type { SfxName } from "../game/audio";
import { DIFFS, TEAMS } from "../game/defs";
import type { DiffId } from "../game/defs";
import { drawText, initSprites, mk } from "../game/sprites";
import { AT, PLAT, findPath, getMap, paintBackdrop, paintMini, paintTerrain, solidPx, solidT, tileAt } from "./maps";
import type { ArenaMap, Backdrop, Decor, PickKind } from "./maps";
import { AWEP, BEAM, SABER_L, medSpr, nadeSpr, wspr } from "./weapons";
import type { AW, AWDef } from "./weapons";
import { ARENA_SKINS, EYES, TROOPER, blobSpr, opHead, opPal, opTorso, tumbleSpr } from "./skins";

/**
 * The side-view team deathmatch: jetpacks, 360° aim, weapons lying around the arena (a lightsaber that turns bullets
 * back, a stormtrooper's blaster), grenades, a punch, respawns, and bots that fly the maps by a navigation grid.
 * The soldiers move, feel and fire like the survivors of the zombie city: the same bodies, the same gaits and faces,
 * the same muzzle stars, rings, sparks and tracers.
 */
export interface ArenaConfig { map: number; size: number; kills: number; time: number; diff: DiffId; skin: number }
export interface FeedItem { id: number; k: string; kt: number; v: string; vt: number; w: string; head: boolean; me: boolean; t: number }
export interface ArenaRow { name: string; team: number; k: number; d: number; dmg: number; me: boolean }
export interface SlotHud { id: AW; name: string; mag: number; ammo: number; max: number }
export interface ArenaHud {
  phase: "count" | "live" | "end"; time: number; score: [number, number]; target: number; myTeam: number;
  hp: number; fuel: number; nades: number; alive: boolean; respawn: number; shield: boolean;
  slots: (SlotHud | null)[]; cur: number; reload: number;
  feed: FeedItem[]; banner: { id: number; text: string; sub: string; color: string } | null;
  near: string; rows: ArenaRow[]; killer: string; streak: number; music: boolean;
}
export interface ArenaResult { win: number; myTeam: number; score: [number, number]; rows: ArenaRow[]; mvp: string; mvpTeam: number }
export interface ArenaCb { hud(h: ArenaHud): void; end(r: ArenaResult): void }

interface Slot { id: AW; mag: number; ammo: number }
interface Ctl { mx: number; jet: boolean; drop: boolean; fire: boolean; aim: number; nade: boolean; melee: boolean; reload: boolean; swap: boolean; pick: boolean }
interface Bot {
  path: number[]; pi: number; pathT: number; pgx: number; pgy: number; gx: number; gy: number;
  target: Sol | null; react: number; lock: number; err: number; errT: number;
  firing: boolean; burstT: number; strafe: number; strafeT: number; hop: number; hopT: number;
  lx: number; ly: number; stuckT: number; unstuck: number; nadeCd: number; think: number; swapCd: number;
  seen: { x: number; y: number; t: number } | null;
}
interface Sol {
  id: number; name: string; team: number; skin: number; me: boolean; bot: Bot | null;
  x: number; y: number; vx: number; vy: number; ground: boolean; face: number; aim: number;
  hp: number; alive: boolean; respawn: number; shield: number; hurtT: number;
  fuel: number; jet: boolean; wasJet: boolean; fuelWait: number; jetK: number; burst: number; sputT: number;
  slots: (Slot | null)[]; cur: number; nades: number; nadeCd: number;
  fireCd: number; reload: number; reloadMax: number; trig: boolean; recoil: number; bloom: number; loud: number;
  melee: number; meleeCd: number;
  /** the lightsaber: the swing in progress, the combo, who it has already cut, the blade lit 0..1, where the blade points (now and last frame), its trail */
  swingT: number; swingDur: number; swingKind: number; swingDir: number; combo: number; lastSwing: number; swingHit: number[];
  saberOn: number; blade: number; bladePrev: number; trail: number[]; tip: number[] | null;
  kills: number; deaths: number; dmg: number; streak: number; multi: number; lastKill: number;
  /** how the body moves: stride, running, squash on landing, tilt from a hit; muzzle flash and its shape; the shotgun's pump */
  walkT: number; runK: number; squash: number; tilt: number; flash: number; flashT: number; seed: number; pump: number;
  burn: number; burnBy: Sol | null; burnT: number; lastBy: Sol | null; lastByT: number;
  drop: number; rot: number; vrot: number; headless: boolean; stepT: number; scarf: number[];
  /** what shows on the face and over the head, and what they shout */
  ouch: number; joy: number; alert: number; dizzy: number; mad: number; say: string; sayT: number; sayCd: number; lowSaid: boolean;
  ctl: Ctl;
}
interface Shot { x: number; y: number; px: number; py: number; vx: number; vy: number; life: number; by: Sol; w: AW; kind: AWDef["kind"]; dmg: number; hit: number[]; tried: number[]; bounce: number; r: number; spin: number; dist: number }
interface Nade { x: number; y: number; vx: number; vy: number; fuse: number; by: Sol; rot: number; beep: boolean }
interface Pick { x: number; y: number; vx: number; vy: number; kind: PickKind; spot: boolean; t: number; mag: number; ammo: number; life: number; bob: number }
interface Part { x: number; y: number; vx: number; vy: number; life: number; max: number; size: number; col: string; grav: number; drag: number; kind: number; rot: number; vr: number; spr: HTMLCanvasElement | null; n: number }
interface Txt { x: number; y: number; text: string; col: string; life: number; vy: number }
interface Flash { x: number; y: number; r: number; life: number; max: number; col: string }
interface Ring { x: number; y: number; r: number; life: number; max: number; col: string }
interface Star { x: number; y: number; life: number; col: string }
interface HitFx { x: number; y: number; ang: number; r: number; kind: number; life: number; max: number; col: string }
interface Burst { x: number; y: number; ang: number; r: number; life: number; max: number; seed: number }
interface Scorch { x: number; y: number; life: number; col: string }
interface Tumble { x: number; y: number; vx: number; vy: number; rot: number; life: number; s: number }

const GRAV = 720, JET = 1480, MAXUP = 235, MAXFALL = 440, WALK = 92, AIRSPD = 118;
const HW = 4, HH = 19, RESPAWN = 3.5, SHIELD = 2.2, NADE_V = 310, NADE_G = 640, SABER_R = 34;
const rand = Math.random;
const PI2 = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => { let d = (b - a) % PI2; if (d > Math.PI) d -= PI2; if (d < -Math.PI) d += PI2; return d; };
const smooth = (k: number) => { const q = clamp(k, 0, 1); return q * q * (3 - 2 * q); };
const easeOut = (k: number) => { const q = clamp(k, 0, 1); return 1 - (1 - q) * (1 - q); };
const pickOne = <T>(a: T[]): T => a[(rand() * a.length) | 0];
const NAMES = ["RAJAWALI", "GARUDA", "KOBRA", "MACAN", "ELANG", "BADAK", "HIU", "SERIGALA", "KOMODO", "BANTENG", "PETIR", "TOPAN", "BAJA", "GERHANA", "KILAT", "BADAI", "RAZOR", "MAMBA", "HYENA", "JACKAL"];
const STARTERS: AW[] = ["uzi", "shotgun", "rifle", "e11"];
export const PICK_NAME: Record<PickKind, string> = { uzi: "UZI", shotgun: "SHOTGUN", rifle: "AK-47", sniper: "SNIPER", rpg: "BAZOOKA", flame: "PENYEMBUR API", saw: "GERGAJI", magnum: "DEAGLE EMAS", e11: "BLASTER E-11", saber: "LIGHTSABER", health: "MEDKIT +60", nades: "GRANAT +2" };
const RESPAWN_T: Partial<Record<PickKind, number>> = { health: 16, nades: 14, saber: 30 };
const BLOOD = ["#a8202c", "#7a1420", "#d04a4a"];
const FIRE = ["#fff3a0", "#ffd23a", "#ff9a2a", "#ff5a2a"];
const SMOKE = ["#5a5660", "#77727c", "#45414b"];
const DMG_MUL: Record<DiffId, number> = { easy: 0.55, normal: 0.8, hard: 1 };
const LINES: Record<string, string[]> = {
  kill: ["MAMPUS!", "SATU LAGI!", "GG!", "EZ!", "HAHA!", "KENA KAU!", "TUMBANG!"],
  trooper: ["UNTUK KEKAISARAN!", "TARGET HANCUR!", "HAHAHA!"],
  hurt: ["ADUH!", "SAKIT!", "ARGH!", "UGH!"],
  nade: ["GRANAT!", "AWAS!", "TIARAP!"],
  reload: ["RELOAD!", "TUTUP AKU!"],
  low: ["TOLONG!", "BUTUH MEDIS!", "SEKARAT!"],
  saber: ["WUSSS!", "MAY THE FORCE...", "RASAKAN INI!"],
  deflect: ["TANGKIS!", "HA!", "PERCUMA!"],
  back: ["AKU KEMBALI!", "BALAS DENDAM!", "AYO LAGI!"],
};

export class ArenaGame {
  W = 480;
  H = 270;
  scale = 2;
  joyL = { x: 0, y: 0, on: false };
  joyR = { x: 0, y: 0, on: false };
  touch = false;
  paused = false;
  private cv: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private cb: ArenaCb;
  private map!: ArenaMap;
  private terr!: HTMLCanvasElement;
  private tg!: CanvasRenderingContext2D;
  private emis: HTMLCanvasElement | null = null;
  private mini!: HTMLCanvasElement;
  private back!: Backdrop;
  private dark: HTMLCanvasElement;
  private dg: CanvasRenderingContext2D;
  private glow: HTMLCanvasElement;
  private glowC: Record<string, HTMLCanvasElement> = {};
  private cfg: ArenaConfig | null = null;
  private sol: Sol[] = [];
  private me!: Sol;
  private shots: Shot[] = [];
  private nades: Nade[] = [];
  private picks: Pick[] = [];
  private parts: Part[] = [];
  private texts: Txt[] = [];
  private flashes: Flash[] = [];
  private rings: Ring[] = [];
  private stars: Star[] = [];
  private hitfx: HitFx[] = [];
  private bursts: Burst[] = [];
  private scorch: Scorch[] = [];
  private tumbles: Tumble[] = [];
  private stalags: Decor[] = [];
  private sand: number[] = [];
  private dust: number[] = [];
  private spores: number[] = [];
  private gust = 0.5;
  private tumbleT = 2;
  private dripT = 0.5;
  private score: [number, number] = [0, 0];
  private phase: "count" | "live" | "end" = "count";
  private phaseT = 3.2;
  private timeLeft = 300;
  private t = 0;
  private endT = 0;
  private slow = 0;
  private hitStop = 0;
  private cam = { x: 0, y: 0, shake: 0, kx: 0, ky: 0 };
  private cl = 0;
  private ct = 0;
  private mouse = { x: 240, y: 135, down: false };
  private keys = new Set<string>();
  private once = { nade: false, melee: false, reload: false, swap: false, pick: false, slot: -1 };
  private feed: FeedItem[] = [];
  private banner: ArenaHud["banner"] = null;
  private bannerT = 0;
  private ids = 1;
  private hitMark = 0;
  private killMark = 0;
  private hurtFx = 0;
  private hudT = 0;
  private lastSec = 99;
  private warned = false;
  private killer: Sol | null = null;
  private tension = 0;
  private combat = 0;
  private humRate = 0;
  private rain: number[] = [];
  private raf = 0;
  private last = 0;
  private abort = new AbortController();
  private ended = false;
  private shellT = 0;

  constructor(cv: HTMLCanvasElement, cb: ArenaCb) {
    this.cv = cv;
    this.cb = cb;
    this.ctx = cv.getContext("2d")!;
    initSprites();
    const [d, dg] = mk(8, 8);
    this.dark = d;
    this.dg = dg;
    const [gc, gg] = mk(64, 64), grd = gg.createRadialGradient(32, 32, 0, 32, 32, 32);
    grd.addColorStop(0, "rgba(255,255,255,1)");
    grd.addColorStop(0.45, "rgba(255,255,255,0.65)");
    grd.addColorStop(1, "rgba(255,255,255,0)");
    gg.fillStyle = grd;
    gg.fillRect(0, 0, 64, 64);
    this.glow = gc;
    const o = { signal: this.abort.signal };
    window.addEventListener("resize", () => this.resize(), o);
    window.addEventListener("keydown", (e) => this.onKey(e, true), o);
    window.addEventListener("keyup", (e) => this.onKey(e, false), o);
    window.addEventListener("blur", () => { this.keys.clear(); this.mouse.down = false; }, o);
    window.addEventListener("mousemove", (e) => this.onMouse(e), o);
    window.addEventListener("mousedown", (e) => {
      if (this.touch || (e.target as HTMLElement | null)?.tagName !== "CANVAS") return;
      this.onMouse(e);
      if (e.button === 0) this.mouse.down = true;
      if (e.button === 2) this.once.nade = true;
    }, o);
    window.addEventListener("mouseup", (e) => { if (e.button === 0) this.mouse.down = false; }, o);
    window.addEventListener("contextmenu", (e) => { if ((e.target as HTMLElement | null)?.tagName === "CANVAS") e.preventDefault(); }, o);
    window.addEventListener("wheel", (e) => { if (!this.touch && (e.target as HTMLElement | null)?.tagName === "CANVAS" && Math.abs(e.deltaY) > 4) this.once.swap = true; }, { ...o, passive: true });
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.loop);
  }

  destroy() {
    this.abort.abort();
    cancelAnimationFrame(this.raf);
    audio.hush();
    for (const id of ["jet", "flame", "saber"] as const) audio.loop(id, 0);
  }

  resize() {
    const iw = window.innerWidth, ih = window.innerHeight;
    let s = Math.min(Math.max(iw, ih) / 420, Math.min(iw, ih) / 236);
    s = s >= 2 ? Math.floor(s) : Math.max(1, s);
    this.scale = s;
    this.W = Math.ceil(iw / s);
    this.H = Math.ceil(ih / s);
    this.cv.width = this.W;
    this.cv.height = this.H;
    this.cv.style.width = `${this.W * s}px`;
    this.cv.style.height = `${this.H * s}px`;
    this.ctx.imageSmoothingEnabled = false;
    this.dark.width = this.W;
    this.dark.height = this.H;
  }

  private onKey(e: KeyboardEvent, down: boolean) {
    const c = e.code;
    if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(c)) e.preventDefault();
    if (!down) { this.keys.delete(c); return; }
    if (e.repeat) return;
    this.keys.add(c);
    if (c === "KeyG") this.once.nade = true;
    else if (c === "KeyF" || c === "KeyV") this.once.melee = true;
    else if (c === "KeyR") this.once.reload = true;
    else if (c === "KeyQ") this.once.swap = true;
    else if (c === "KeyE") this.once.pick = true;
    else if (c === "Digit1") this.once.slot = 0;
    else if (c === "Digit2") this.once.slot = 1;
    else if (c === "KeyN") audio.setMusic(!audio.musicOn);
  }
  private onMouse(e: MouseEvent) {
    if (this.touch) return;
    const r = this.cv.getBoundingClientRect();
    this.mouse.x = ((e.clientX - r.left) / Math.max(1, r.width)) * this.W;
    this.mouse.y = ((e.clientY - r.top) / Math.max(1, r.height)) * this.H;
  }
  /** a button on the touch screen */
  act(a: "nade" | "melee" | "reload" | "swap" | "pick") { this.once[a] = true; }

  // ───────────── the match ─────────────
  start(cfg: ArenaConfig) {
    this.cfg = cfg;
    this.map = getMap(cfg.map);
    const P = paintTerrain(this.map);
    this.terr = P.terr;
    this.emis = P.emis;
    this.tg = this.terr.getContext("2d")!;
    this.mini = paintMini(this.map);
    this.back = paintBackdrop(this.map.theme);
    this.stalags = this.map.decor.filter((d) => d.k === "stalag");
    this.sol = []; this.shots = []; this.nades = []; this.parts = []; this.texts = []; this.flashes = []; this.feed = [];
    this.rings = []; this.stars = []; this.hitfx = []; this.bursts = []; this.scorch = []; this.tumbles = [];
    this.score = [0, 0]; this.phase = "count"; this.phaseT = 3.2; this.timeLeft = cfg.time * 60; this.t = 0; this.endT = 0; this.slow = 0; this.hitStop = 0;
    this.ended = false; this.warned = false; this.lastSec = 99; this.killer = null; this.banner = null;
    this.picks = this.map.picks.map((p) => ({ x: p.x, y: p.y, vx: 0, vy: 0, kind: p.kind, spot: true, t: 0, mag: 0, ammo: 0, life: 0, bob: rand() * 6 }));
    const names = NAMES.slice().sort(() => rand() - 0.5);
    for (let team = 0; team < 2; team++)
      for (let i = 0; i < cfg.size; i++) {
        const me = team === 0 && i === 0;
        const skin = me ? cfg.skin : rand() < 0.22 ? TROOPER : (rand() * 5) | 0;
        const s = this.mkSol(me ? ARENA_SKINS[cfg.skin] ?? "KAMU" : names.pop() ?? `BOT${team}${i}`, team, skin, me);
        this.sol.push(s);
        if (me) this.me = s;
      }
    for (const s of this.sol) this.respawn(s, true);
    this.rain = [];
    for (let i = 0; i < 160; i++) this.rain.push(rand() * 2000, rand() * 1200);
    this.sand = [];
    for (let i = 0; i < 170; i++) this.sand.push(rand() * 2000, rand() * 1200, 0.5 + rand(), 2 + rand() * 7);
    this.dust = [];
    for (let i = 0; i < 7; i++) this.dust.push(rand() * 1000, rand() * 700, 50 + rand() * 80, rand() * 6);
    this.spores = [];
    for (let i = 0; i < 80; i++) this.spores.push(rand() * 2000, rand() * 1200, rand() * 6, (rand() * 3) | 0);
    this.gust = 0.5; this.tumbleT = 2; this.dripT = 0.5;
    this.cam.x = this.me.x;
    this.cam.y = this.me.y - 30;
    this.cam.kx = this.cam.ky = 0;
    audio.unlock();
  }

  private mkSol(name: string, team: number, skin: number, me: boolean): Sol {
    const bot: Bot | null = me ? null : {
      path: [], pi: 0, pathT: 0, pgx: 0, pgy: 0, gx: 0, gy: 0, target: null, react: 0, lock: 0, err: 0, errT: 0,
      firing: false, burstT: 0, strafe: 1, strafeT: 0, hop: 0, hopT: rand() * 2, lx: 0, ly: 0, stuckT: 1, unstuck: 0, nadeCd: 3 + rand() * 5, think: rand() * 0.2, swapCd: 0, seen: null,
    };
    return {
      id: this.ids++, name, team, skin, me, bot, x: 0, y: 0, vx: 0, vy: 0, ground: false, face: team ? -1 : 1, aim: team ? Math.PI : 0,
      hp: 100, alive: true, respawn: 0, shield: 0, hurtT: 9,
      fuel: 1, jet: false, wasJet: false, fuelWait: 0, jetK: 0, burst: 0, sputT: 0,
      slots: [null, null], cur: 0, nades: 2, nadeCd: 0, fireCd: 0, reload: 0, reloadMax: 1, trig: false, recoil: 0, bloom: 0, loud: 0, melee: 0, meleeCd: 0,
      swingT: 0, swingDur: 0.3, swingKind: 0, swingDir: 1, combo: 0, lastSwing: -9, swingHit: [], saberOn: 0, blade: 0, bladePrev: 0, trail: [], tip: null,
      kills: 0, deaths: 0, dmg: 0, streak: 0, multi: 0, lastKill: -9,
      walkT: 0, runK: 0, squash: 0, tilt: 0, flash: 0, flashT: 0, seed: 0.5, pump: 0,
      burn: 0, burnBy: null, burnT: 0, lastBy: null, lastByT: -9, drop: 0, rot: 0, vrot: 0, headless: false, stepT: 0, scarf: [0, 0, 0, 0, 0, 0],
      ouch: 0, joy: 0, alert: 0, dizzy: 0, mad: 0, say: "", sayT: 0, sayCd: 0, lowSaid: false,
      ctl: { mx: 0, jet: false, drop: false, fire: false, aim: team ? Math.PI : 0, nade: false, melee: false, reload: false, swap: false, pick: false },
    };
  }
  private slot(id: AW): Slot { return { id, mag: AWEP[id].mag, ammo: AWEP[id].ammo }; }

  /** back in: at the team's spawn that is furthest from the enemy */
  private respawn(s: Sol, first = false) {
    const pts = this.map.spawns[s.team];
    let best = pts[0], bs = -1e9;
    for (const p of pts) {
      let near = 600;
      for (const e of this.sol) if (e.alive && e.team !== s.team && !first) near = Math.min(near, Math.hypot(e.x - p.x, e.y - p.y));
      let busy = 0;
      for (const o of this.sol) if (o !== s && o.alive && (o.x || o.y) && Math.abs(o.x - p.x) < 9 && Math.abs(o.y - p.y) < 14) busy++;
      const sc = near - busy * 220 + rand() * 50;
      if (sc > bs) { bs = sc; best = p; }
    }
    s.x = best.x; s.y = best.y;
    s.vx = s.vy = 0; s.alive = true; s.hp = 100; s.fuel = 1; s.fuelWait = 0; s.shield = first ? 0 : SHIELD; s.hurtT = 9;
    s.slots = [this.slot(s.skin === TROOPER ? "e11" : pickOne(STARTERS)), this.slot("pistol")]; s.cur = 0; s.nades = 2; s.nadeCd = 0;
    s.fireCd = 0.3; s.reload = 0; s.recoil = 0; s.bloom = 0; s.melee = 0; s.burn = 0; s.rot = 0; s.vrot = 0; s.headless = false; s.lastBy = null;
    s.swingT = 0; s.combo = 0; s.saberOn = 0; s.trail = []; s.tip = null; s.jet = s.wasJet = false; s.jetK = 0; s.burst = 0; s.squash = 0; s.tilt = 0;
    s.ouch = s.joy = s.alert = s.dizzy = s.mad = 0; s.sayT = 0; s.lowSaid = false;
    s.face = s.team ? -1 : 1; s.aim = s.team ? Math.PI : 0; s.ctl.aim = s.aim; s.ground = false; s.drop = 0;
    s.scarf = [s.x, s.y - 11, s.x, s.y - 11, s.x, s.y - 11];
    if (s.bot) { s.bot.path = []; s.bot.target = null; s.bot.seen = null; s.bot.pathT = 0; }
    if (!first) {
      for (let i = 0; i < 10; i++) this.part(s.x + (rand() - 0.5) * 12, s.y - rand() * 20, (rand() - 0.5) * 40, -30 - rand() * 50, 0.5, 2, TEAMS[s.team].color, -40, 2, 0);
      this.rings.push({ x: s.x, y: s.y - 9, r: 18, life: 0, max: 0.4, col: TEAMS[s.team].color });
      if (s.me) { this.sfx("ping", s.x, s.y, 0.6); this.killer = null; }
      if (rand() < 0.3) this.callout(s, "back");
    }
  }

  private loop = (now: number) => {
    this.raf = requestAnimationFrame(this.loop);
    const rdt = clamp((now - this.last) / 1000, 0, 0.05);
    this.last = now;
    if (!this.cfg) return;
    if (!this.paused) this.update(rdt);
    this.render();
    this.hudT -= rdt;
    if (this.hudT <= 0) { this.hudT = 0.1; this.cb.hud(this.hudState()); }
  };

  /** run the game by hand (tests): dt seconds at a time */
  step(dt: number) { if (this.cfg) { this.update(dt); this.render(); } }

  private say(text: string, sub: string, color: string, dur: number) {
    this.banner = { id: this.ids++, text, sub, color };
    this.bannerT = dur;
  }
  /** a speech bubble over somebody's head */
  private callout(s: Sol, key: string) {
    if (s.sayCd > 0 || !s.alive) return;
    let n = 0;
    for (const q of this.sol) if (q.sayT > 0) n++;
    if (n >= 4) return;
    s.say = pickOne(key === "kill" && s.skin === TROOPER ? LINES.trooper : LINES[key]);
    s.sayT = 1.7;
    s.sayCd = 3.5 + rand() * 3;
  }

  private update(rdt: number) {
    if (this.hitStop > 0) { this.hitStop -= rdt; this.camera(rdt); return; }
    const dt = rdt * (this.slow > 0 ? 0.3 : 1), cfg = this.cfg!;
    this.slow -= rdt;
    this.t += dt;
    if (this.phase === "count") {
      this.phaseT -= rdt;
      const n = Math.ceil(this.phaseT);
      if (n !== this.lastSec && n > 0 && n <= 3) { this.lastSec = n; this.say(String(n), "BERSIAP...", "#f5c542", 0.9); audio.play("tick", 0.8); }
      if (this.phaseT <= 0) { this.phase = "live"; this.say("SERBU!", `${cfg.kills} KILL UNTUK MENANG`, "#7dff9a", 1.6); audio.play("start", 0.8); }
    } else if (this.phase === "live") {
      this.timeLeft -= dt;
      if (!this.warned && this.timeLeft <= 60 && cfg.time > 1) { this.warned = true; this.say("1 MENIT LAGI!", "Kejar skornya!", "#ffb347", 2); audio.play("alarm", 0.4); }
      if (this.timeLeft <= 0) { this.timeLeft = 0; this.finish(); }
    } else {
      this.endT += rdt;
      if (this.endT > 2.4 && !this.ended) { this.ended = true; this.cb.end(this.result()); }
    }
    this.ambient(dt);
    this.playerCtl();
    for (const s of this.sol) if (s.bot && s.alive) this.botThink(s, dt);
    for (const s of this.sol) this.tickSol(s, dt);
    this.updShots(dt);
    this.updNades(dt);
    this.updPicks(dt);
    this.updParts(dt);
    for (let i = this.texts.length - 1; i >= 0; i--) { const q = this.texts[i]; q.life -= rdt; q.y += q.vy * rdt; if (q.life <= 0) this.texts.splice(i, 1); }
    for (let i = this.flashes.length - 1; i >= 0; i--) if ((this.flashes[i].life -= rdt) <= 0) this.flashes.splice(i, 1);
    for (let i = this.rings.length - 1; i >= 0; i--) if ((this.rings[i].life += rdt) >= this.rings[i].max) this.rings.splice(i, 1);
    for (let i = this.stars.length - 1; i >= 0; i--) if ((this.stars[i].life -= rdt) <= 0) this.stars.splice(i, 1);
    for (let i = this.hitfx.length - 1; i >= 0; i--) if ((this.hitfx[i].life += rdt) >= this.hitfx[i].max) this.hitfx.splice(i, 1);
    for (let i = this.bursts.length - 1; i >= 0; i--) if ((this.bursts[i].life += rdt) >= this.bursts[i].max) this.bursts.splice(i, 1);
    for (let i = this.scorch.length - 1; i >= 0; i--) if ((this.scorch[i].life -= rdt) <= 0) this.scorch.splice(i, 1);
    this.feed = this.feed.filter((f) => this.t - f.t < 7);
    if ((this.bannerT -= rdt) <= 0) this.banner = null;
    this.hitMark -= rdt; this.killMark -= rdt; this.hurtFx = Math.max(0, this.hurtFx - rdt * 1.4); this.shellT -= rdt;
    if (this.map.theme.rain) for (let i = 0; i < this.rain.length; i += 2) { this.rain[i] -= 70 * rdt; this.rain[i + 1] += 430 * rdt; }
    this.camera(rdt);
    this.sound(rdt);
  }

  /** the weather of each arena: a sandstorm with tumbleweeds, spores drifting in the cave, water dripping */
  private ambient(dt: number) {
    const T = this.map.theme, W = this.W, H = this.H;
    if (T.weather === "sand") {
      const t = this.t;
      this.gust = clamp(0.45 + 0.28 * Math.sin(t * 0.23) + 0.2 * Math.sin(t * 0.61 + 2) + 0.1 * Math.sin(t * 1.7), 0, 1);
      const sp = 180 + this.gust * 320;
      for (let i = 0; i < this.sand.length; i += 4) { this.sand[i] += sp * this.sand[i + 2] * dt; this.sand[i + 1] += Math.sin(t * 2 + i) * 9 * dt; }
      for (let i = 0; i < this.dust.length; i += 4) this.dust[i] += (40 + this.gust * 120) * dt;
      if ((this.tumbleT -= dt) <= 0 && this.tumbles.length < 3) {
        this.tumbleT = 3 + rand() * 6;
        const x = this.cl - 16, y0 = this.ct + 20 + rand() * H * 0.5;
        for (let y = y0; y < y0 + 260; y += 4) if (solidPx(this.map, x + 8, y)) { if (y > y0 + 4) this.tumbles.push({ x, y: y - 7, vx: 40 + this.gust * 60, vy: 0, rot: 0, life: 0, s: 0.8 + rand() * 0.5 }); break; }
      }
      for (let i = this.tumbles.length - 1; i >= 0; i--) {
        const q = this.tumbles[i];
        q.life += dt;
        q.vx += (50 + this.gust * 120 - q.vx) * Math.min(1, dt * 1.2);
        q.vy = Math.min(300, q.vy + 500 * dt);
        const nx = q.x + q.vx * dt;
        if (solidPx(this.map, nx + 6, q.y)) { q.vy = -150 - rand() * 60; q.vx *= 0.5; } else q.x = nx;
        const ny = q.y + q.vy * dt;
        if (solidPx(this.map, q.x, ny + 6)) q.vy = q.vy > 90 ? -q.vy * 0.45 : -50 - rand() * 90 * this.gust;
        else q.y = ny;
        q.rot += (q.vx * dt) / 7;
        if (q.x > this.cl + W + 40 || q.life > 30 || q.y > this.map.h * AT) this.tumbles.splice(i, 1);
      }
    } else if (T.weather === "spores") {
      for (let i = 0; i < this.spores.length; i += 4) { this.spores[i] += Math.sin(this.t * 0.5 + this.spores[i + 2]) * 7 * dt; this.spores[i + 1] -= (3 + (i % 7)) * dt; }
      if ((this.dripT -= dt) <= 0 && this.stalags.length) {
        this.dripT = 0.18 + rand() * 0.4;
        const d = this.stalags[(rand() * this.stalags.length) | 0];
        if (Math.abs(d.x - this.cam.x) < W * 0.7 && Math.abs(d.y - this.cam.y) < H * 0.7) this.part(d.x, d.y + 8, 0, 10, 4, 1, "#9ad8ff", 400, 0, 8);
      }
    }
  }

  private playerCtl() {
    const s = this.me, c = s.ctl, k = this.keys, o = this.once;
    c.nade = o.nade; c.melee = o.melee; c.reload = o.reload; c.swap = o.swap; c.pick = o.pick;
    if (o.slot >= 0 && s.slots[o.slot] && s.cur !== o.slot && s.alive) { s.cur = o.slot; s.reload = 0; s.fireCd = Math.max(s.fireCd, 0.15); this.sfx("rack", s.x, s.y, 0.4); }
    this.once = { nade: false, melee: false, reload: false, swap: false, pick: false, slot: -1 };
    let mx = (k.has("KeyD") || k.has("ArrowRight") ? 1 : 0) - (k.has("KeyA") || k.has("ArrowLeft") ? 1 : 0);
    let jet = k.has("KeyW") || k.has("ArrowUp") || k.has("Space"), drop = k.has("KeyS") || k.has("ArrowDown"), fire = this.mouse.down;
    let aim = Math.atan2(this.mouse.y + this.ct - (s.y - 5), this.mouse.x + this.cl - s.x);
    if (this.joyL.on) {
      mx = Math.abs(this.joyL.x) > 0.22 ? Math.sign(this.joyL.x) * Math.min(1, Math.abs(this.joyL.x) * 1.4) : 0;
      jet = this.joyL.y < -0.42;
      drop = this.joyL.y > 0.6;
    }
    if (this.touch) {
      const m = Math.hypot(this.joyR.x, this.joyR.y);
      if (this.joyR.on && m > 0.18) { aim = Math.atan2(this.joyR.y, this.joyR.x); fire = m > 0.62; }
      else { aim = s.aim; fire = false; }
    }
    c.mx = mx; c.jet = jet; c.drop = drop; c.fire = fire; c.aim = aim;
  }

  // ───────────── soldiers ─────────────
  private hit(s: Sol, x: number, y: number, down: boolean): boolean {
    const m = this.map, x0 = Math.floor((x - HW) / AT), x1 = Math.floor((x + HW - 0.01) / AT), y0 = Math.floor((y - HH) / AT), y1 = Math.floor((y - 0.01) / AT);
    for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) if (solidT(tileAt(m, tx, ty))) return true;
    if (down && s.drop <= 0) {
      const r = Math.floor((y - 0.01) / AT);
      if (y - r * AT <= 1.01) for (let tx = x0; tx <= x1; tx++) if (tileAt(m, tx, r) === PLAT) return true;
    }
    return false;
  }
  private onPlat(s: Sol) { return tileAt(this.map, Math.floor(s.x / AT), Math.floor((s.y + 1) / AT)) === PLAT; }
  private blockedAhead(s: Sol, dir: number) { return this.hit(s, s.x + dir * 5, s.y - 9, false); }
  private dustCol() { return this.map.theme.decor === "desert" ? pickOne(["#e8c08a", "#d8a868", "#f2d4a0"]) : this.map.theme.decor === "cave" ? pickOne(["#6a5a7e", "#58496c"]) : pickOne(["#9a96a0", "#7a7680"]); }

  private move(s: Sol, dx: number, dy: number) {
    const was = s.ground;
    let n = Math.ceil(Math.abs(dx));
    const sx = n ? dx / n : 0;
    for (let i = 0; i < n; i++) {
      const nx = s.x + sx;
      if (!this.hit(s, nx, s.y, false)) { s.x = nx; continue; }
      if (was || s.ground) {
        let up = 0;
        for (let k = 1; k <= 9; k++) if (!this.hit(s, nx, s.y - k, false)) { up = k; break; }
        if (up) { s.x = nx; s.y -= up; continue; }
      }
      s.vx = 0;
      break;
    }
    n = Math.ceil(Math.abs(dy));
    const sy = n ? dy / n : 0;
    s.ground = false;
    for (let i = 0; i < n; i++) {
      const ny = s.y + sy;
      if (!this.hit(s, s.x, ny, sy > 0)) { s.y = ny; continue; }
      if (sy > 0) {
        s.ground = true;
        if (s.vy > 170) s.squash = Math.min(0.16, 0.05 + s.vy / 2600);
        if (s.vy > 330) {
          for (let k = 0; k < 8; k++) this.part(s.x + (rand() - 0.5) * 8, s.y - 1, (rand() - 0.5) * 90, -rand() * 40, 0.45, 2, this.dustCol(), 60, 3, 1);
          if (s.me) this.sfx("thunk", s.x, s.y, 0.25, 0.8);
        }
      }
      s.vy = 0;
      break;
    }
    if (!s.ground && s.vy >= 0) {
      if (this.hit(s, s.x, s.y + 1, true)) s.ground = true;
      else if (was && !s.jet) for (let k = 1; k <= 8; k++) if (this.hit(s, s.x, s.y + k + 1, true)) { s.y += k; s.ground = true; break; }
    }
  }

  private tickSol(s: Sol, dt: number) {
    if (!s.alive) { this.ragdoll(s, dt); return; }
    const c = s.ctl, frozen = this.phase !== "live";
    s.fireCd -= dt; s.recoil = Math.max(0, s.recoil - dt * 7); s.bloom = Math.max(0, s.bloom - dt * 2.2); s.loud -= dt;
    s.meleeCd -= dt; s.flash -= dt; s.flashT -= dt; s.shield -= dt; s.hurtT += dt; s.nadeCd -= dt; s.drop = c.drop ? 0.2 : Math.max(0, s.drop - dt);
    s.ouch -= dt; s.joy -= dt; s.alert -= dt; s.dizzy -= dt; s.mad -= dt; s.sayT -= dt; s.sayCd -= dt;
    s.burst = Math.max(0, s.burst - dt); s.squash = Math.max(0, s.squash - dt); s.pump = Math.max(0, s.pump - dt);
    s.tilt *= Math.exp(-dt * 8);
    s.aim = c.aim;
    s.face = Math.cos(s.aim) >= 0 ? 1 : -1;
    if (s.hurtT > 5 && s.hp < 100) s.hp = Math.min(100, s.hp + 14 * dt);
    if (s.hp < 30 && !s.lowSaid) { s.lowSaid = true; if (rand() < 0.6) this.callout(s, "low"); }
    if (s.hp > 60) s.lowSaid = false;
    if (s.burn > 0) {
      s.burn -= dt;
      if ((s.burnT -= dt) <= 0) { s.burnT = 0.25; this.hurt(s, 2, s.burnBy, "flame", -Math.PI / 2, 0, false); }
      if (rand() < dt * 30) this.part(s.x + (rand() - 0.5) * 8, s.y - rand() * 17, (rand() - 0.5) * 20, -30 - rand() * 30, 0.35, 3, pickOne(FIRE), -60, 1, 5);
      if (!s.alive) return;
    }
    // walking and flying
    const mx = frozen ? 0 : c.mx, want = !frozen && c.jet;
    const sp = s.jet ? AIRSPD : WALK, rate = s.ground ? 1100 : mx ? 560 : 140;
    s.vx += clamp(mx * sp - s.vx, -rate * dt, rate * dt);
    s.jet = false;
    if (want && s.fuel > 0.01 && s.fuelWait <= 0) {
      s.jet = true;
      if (!s.wasJet) this.ignite(s);
      let thrust = JET;
      if (s.fuel < 0.16) {
        // running dry: the jet coughs and sputters
        thrust *= 0.55 + 0.45 * Math.abs(Math.sin(this.t * 31 + s.id));
        if ((s.sputT -= dt) <= 0) { s.sputT = 0.12 + rand() * 0.2; this.sparks(s.x - s.face * 8, s.y, 3, ["#ffd23a", "#ff7a2a"]); if (s.me || rand() < 0.3) this.sfx("sputter", s.x, s.y, s.me ? 0.55 : 0.3); }
      }
      s.vy -= thrust * dt;
      s.fuel = Math.max(0, s.fuel - 0.5 * dt);
      if (s.fuel <= 0.01) s.fuelWait = 0.7;
      this.jetFx(s, dt);
    } else {
      if (s.fuelWait > 0) s.fuelWait -= dt;
      s.fuel = Math.min(1, s.fuel + (s.ground ? 0.65 : 0.12) * dt);
    }
    s.wasJet = s.jet;
    s.jetK += ((s.jet ? 1 : 0) - s.jetK) * Math.min(1, dt * (s.jet ? 22 : 10));
    s.vy += GRAV * dt;
    if (s.jet && s.vy < -MAXUP) s.vy = -MAXUP;
    if (s.vy > MAXFALL) s.vy = MAXFALL;
    if (!s.ground && !mx) s.vx *= Math.exp(-dt * 0.6);
    if (!s.ground && this.map.theme.weather === "sand") s.vx += this.gust * 14 * dt; // the storm pushes whoever is in the air
    this.move(s, s.vx * dt, s.vy * dt);
    if (s.y > this.map.h * AT + 40) { this.hurt(s, 999, null, "fall", 0, 0, false); return; }
    const moving = s.ground && Math.abs(s.vx) > 12;
    if (moving) {
      s.walkT += dt;
      if (s.me && (s.stepT -= dt) <= 0) { s.stepT = 0.26; this.sfx("step", s.x, s.y, 0.35); }
    }
    s.runK += ((moving && Math.abs(s.vx) > 70 ? 1 : 0) - s.runK) * Math.min(1, dt * 6);
    this.scarfTick(s, dt);
    if (frozen) return;
    // weapons
    if (c.swap) this.swap(s);
    if (c.reload) this.reloadStart(s);
    if (c.pick) this.tryPick(s, true);
    if (c.nade) this.throwNade(s);
    if (c.melee) this.meleeStart(s);
    this.tryPick(s, false);
    const sl = s.slots[s.cur], saber = !!sl && sl.id === "saber";
    if (saber) {
      if (s.saberOn <= 0) this.sfx("saberon", s.x, s.y, s.me ? 0.7 : 0.4);
      s.saberOn = Math.min(1, s.saberOn + dt / 0.2);
    } else if (s.saberOn > 0) { this.sfx("saberoff", s.x, s.y, s.me ? 0.6 : 0.3); s.saberOn = 0; s.swingT = 0; }
    this.swingTick(s, dt);
    if (s.reload > 0 && sl && !saber) {
      const w = AWEP[sl.id], before = s.reload;
      s.reload -= dt;
      const k0 = 1 - before / s.reloadMax, k1 = 1 - s.reload / s.reloadMax;
      if (k0 < 0.55 && k1 >= 0.55) this.sfx(w.id === "shotgun" ? "shellin" : "magin", s.x, s.y, s.me ? 0.6 : 0.3);
      if (s.reload <= 0) {
        const take = Math.min(w.mag - sl.mag, sl.ammo);
        sl.mag += take;
        sl.ammo -= take;
        this.sfx(w.id === "shotgun" ? "pump" : "rack", s.x, s.y, s.me ? 0.6 : 0.3);
        if (w.id === "shotgun") s.pump = 0.34;
      }
    }
    if (sl) {
      const w = AWEP[sl.id];
      if (c.fire && s.melee <= 0 && (w.auto || !s.trig)) this.fire(s, sl, w);
      if (!saber && sl.mag <= 0 && sl.ammo > 0 && s.reload <= 0 && !c.fire) this.reloadStart(s);
    }
    s.trig = c.fire;
    if (s.melee > 0) {
      const before = s.melee;
      s.melee -= dt;
      if (before > 0.14 && s.melee <= 0.14) this.meleeHit(s);
    }
  }

  /** the scarf trails out behind: three links that follow each other with a little lag, fluttering in the wind */
  private scarfTick(s: Sol, dt: number) {
    let qx = s.x - s.face * 3, qy = s.y - 11;
    const wind = this.map.theme.weather === "sand" ? this.gust * 2.2 : 0, fast = Math.abs(s.vx) + Math.abs(s.vy) > 60;
    for (let i = 0; i < 6; i += 2) {
      const tx = qx - s.face * 3.2 - s.vx * 0.018 + wind, ty = qy + 1.3 - s.vy * 0.012 + Math.sin(this.t * 13 + s.id + i) * (fast ? 1 : 0.35);
      s.scarf[i] += (tx - s.scarf[i]) * Math.min(1, dt * 16);
      s.scarf[i + 1] += (ty - s.scarf[i + 1]) * Math.min(1, dt * 16);
      const dx = s.scarf[i] - qx, dy = s.scarf[i + 1] - qy, l = Math.hypot(dx, dy);
      if (l > 4.2) { s.scarf[i] = qx + (dx / l) * 4.2; s.scarf[i + 1] = qy + (dy / l) * 4.2; }
      qx = s.scarf[i]; qy = s.scarf[i + 1];
    }
  }

  private groundBelow(x: number, y: number, max: number) {
    for (let d = 0; d <= max; d += 2) {
      const yy = y + d;
      if (solidPx(this.map, x, yy) || tileAt(this.map, Math.floor(x / AT), Math.floor(yy / AT)) === PLAT) return yy;
    }
    return -1;
  }
  /** the jetpack lights: a kick, a flash, a ring of fire and smoke, the ground below blasted outwards */
  private ignite(s: Sol) {
    s.burst = 0.22;
    s.vy = Math.min(s.vy, 0) - 70;
    const nx = s.x - s.face * 8, ny = s.y - 2;
    this.flashes.push({ x: nx, y: ny + 4, r: 34, life: 0.12, max: 0.12, col: "#ffb35a" });
    this.rings.push({ x: nx, y: ny + 3, r: 16, life: 0, max: 0.26, col: "#ffd27a" });
    for (let i = 0; i < 9; i++) { const a = Math.PI * 0.5 + (rand() - 0.5) * 2.4; this.part(nx, ny + 2, Math.cos(a) * (60 + rand() * 80), Math.sin(a) * (40 + rand() * 60), 0.5 + rand() * 0.4, 3 + ((rand() * 2) | 0), pickOne(SMOKE), -30, 2.2, 1); }
    for (let i = 0; i < 7; i++) this.part(nx, ny + 2, (rand() - 0.5) * 120, 60 + rand() * 120, 0.25, 2, pickOne(FIRE), 0, 2, 5);
    const gy = this.groundBelow(nx, ny, 30);
    if (gy >= 0) for (let i = 0; i < 12; i++) { const sd = i % 2 ? 1 : -1; this.part(nx + sd * rand() * 4, gy - 1, sd * (80 + rand() * 120), -10 - rand() * 50, 0.6 + rand() * 0.4, 2 + ((rand() * 2) | 0), this.dustCol(), 40, 2.5, 1); }
    this.sfx("jetburst", nx, ny, s.me ? 0.8 : 0.45, 0.9 + rand() * 0.2);
  }
  /** while the jet burns: embers, smoke, and dust blown off the ground below */
  private jetFx(s: Sol, dt: number) {
    const nx = s.x - s.face * 8, ny = s.y - 1, k = s.fuel < 0.16 ? 0.5 : 1;
    if (rand() < dt * 70 * k) this.part(nx + (rand() - 0.5) * 2, ny + 2, (rand() - 0.5) * 30 + s.vx * 0.2, 90 + rand() * 70, 0.16 + rand() * 0.1, 2, pickOne(FIRE), 0, 1, 5);
    if (rand() < dt * 34) this.part(nx, ny + 5, (rand() - 0.5) * 26 + s.vx * 0.1, 40 + rand() * 30, 0.7 + rand() * 0.5, 2, pickOne(SMOKE), -36, 2, 1);
    const gy = this.groundBelow(nx, ny, 40);
    if (gy >= 0 && rand() < dt * 50 * (1 - (gy - ny) / 40)) { const sd = rand() < 0.5 ? -1 : 1; this.part(nx + sd * 3, gy - 1, sd * (70 + rand() * 90), -rand() * 40, 0.45 + rand() * 0.3, 2, this.dustCol(), 50, 3, 1); }
  }

  private ragdoll(s: Sol, dt: number) {
    s.respawn -= dt;
    s.vy = Math.min(MAXFALL, s.vy + GRAV * dt);
    const nx = s.x + s.vx * dt;
    if (solidPx(this.map, nx, s.y - 4)) s.vx = -s.vx * 0.3; else s.x = nx;
    const ny = s.y + s.vy * dt, r = Math.floor(ny / AT);
    const land = solidPx(this.map, s.x, ny) || (s.vy > 0 && tileAt(this.map, Math.floor(s.x / AT), r) === PLAT && s.y <= r * AT + 0.5);
    if (land && s.vy > 0) {
      s.y = solidPx(this.map, s.x, ny) ? Math.floor(ny / AT) * AT : r * AT;
      s.vy = s.vy > 140 ? -s.vy * 0.3 : 0;
      s.vx *= 0.55;
      s.vrot *= 0.5;
      const tgt = (s.rot >= 0 ? 1 : -1) * Math.PI * 0.5;
      s.rot += (tgt - s.rot) * Math.min(1, dt * 10);
    } else {
      if (solidPx(this.map, s.x, ny - 18) && s.vy < 0) s.vy = 0;
      else s.y = ny;
      s.rot += s.vrot * dt;
    }
    if (s.respawn <= 0 && this.phase !== "end") this.respawn(s);
  }

  /** where the hands hold the weapon: waist high, a little forward, like the survivors */
  private pivot(s: Sol) { return { x: s.x + Math.round(Math.cos(s.aim) * 2), y: s.y - 5 }; }
  private muzzle(s: Sol) {
    const sl = s.slots[s.cur], W = wspr(s.team, sl ? sl.id : "pistol"), ca = Math.cos(s.aim), sa = Math.sin(s.aim), p = this.pivot(s), fy = ca < 0 ? -1 : 1;
    const m = W.c.width - W.px + 2, by = (W.bar + 0.5) * fy;
    return { x: p.x + ca * m - sa * by, y: p.y + sa * m + ca * by };
  }
  private clear(x0: number, y0: number, x1: number, y1: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 4);
    for (let i = 1; i < n; i++) if (solidPx(this.map, x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n)) return false;
    return true;
  }

  private fire(s: Sol, sl: Slot, w: AWDef) {
    if (w.kind === "saber") { this.startSwing(s); return; }
    if (s.fireCd > 0 || s.reload > 0) return;
    if (sl.mag <= 0) {
      if (sl.ammo > 0) this.reloadStart(s);
      else { s.fireCd = 0.35; if (s.me) audio.play("click", 0.6); }
      return;
    }
    sl.mag--;
    s.fireCd = w.cd;
    s.shield = 0;
    s.loud = 1.4;
    s.flashT = 0.06;
    s.seed = rand();
    const a0 = s.aim, ca = Math.cos(a0), sa = Math.sin(a0), pv = this.pivot(s), mz = this.muzzle(s);
    const ok = this.clear(pv.x, pv.y, mz.x, mz.y), ox = ok ? mz.x : pv.x, oy = ok ? mz.y : pv.y;
    const spread = w.spread * (s.ground ? 1 : 1.35) * (1 + s.bloom) * (s.bot ? 1.15 : 1), laser = w.kind === "laser", B = BEAM[s.team];
    if (w.kind === "flame") {
      for (let i = 0; i < 2; i++) this.shots.push(this.mkShot(s, w, ox, oy, a0 + (rand() - 0.5) * 2 * spread, w.speed * (0.8 + rand() * 0.4), w.life * (0.7 + rand() * 0.5)));
    } else {
      for (let p = 0; p < w.pellets; p++) {
        const a = a0 + (w.pellets > 1 ? (rand() - 0.5) * 2 * spread : (rand() + rand() - 1) * spread);
        this.shots.push(this.mkShot(s, w, ox, oy, a, w.speed * (w.pellets > 1 ? 0.85 + rand() * 0.3 : 1), w.life));
      }
      // at the muzzle: a flash of light, a ring, a star, sparks spat down the line of fire, a puff of smoke
      this.flashes.push({ x: mz.x, y: mz.y, r: w.kind === "rocket" ? 46 : laser ? 26 : w.id === "pistol" ? 20 : 28, life: 0.07, max: 0.07, col: laser ? B.col : "#ffd27a" });
      this.rings.push({ x: mz.x + ca * 4, y: mz.y + sa * 4, r: w.id === "shotgun" ? 20 : w.id === "sniper" ? 16 : laser ? 9 : 11, life: 0, max: 0.2, col: laser ? B.col : "#ffb347" });
      this.stars.push({ x: mz.x + ca * 2, y: mz.y + sa * 2, life: 0.06, col: laser ? B.hot : "#ffffff" });
      for (let i = 0; i < (w.id === "shotgun" ? 8 : 4); i++) this.part(mz.x, mz.y, ca * (120 + rand() * 160) + (rand() - 0.5) * 50, sa * (120 + rand() * 160) + (rand() - 0.5) * 50, 0.1 + rand() * 0.06, 1, laser ? pickOne([B.col, B.hot, "#ffffff"]) : pickOne(["#ffffff", "#ffe45c", "#ffb347"]), 0, 7, 5);
      if (!laser) for (let i = 0; i < (w.id === "shotgun" ? 5 : 2); i++) this.part(mz.x + ca * 3, mz.y + sa * 3, ca * 26 + (rand() - 0.5) * 16, sa * 26 - 10 + (rand() - 0.5) * 10, 0.6 + rand() * 0.4, 2, pickOne(["#e9e2d2", "#b9b3a8", "#8a8478"]), -18, 3, 1);
      if (w.id === "magnum") for (let i = 0; i < 8; i++) this.part(mz.x, mz.y, ca * 100 + (rand() - 0.5) * 90, sa * 100 - 20 + (rand() - 0.5) * 90, 0.45, 1, pickOne(["#fff6c0", "#ffd700", "#f5c542"]), 60, 4, 5);
      if (w.kind === "rocket") for (let i = 0; i < 9; i++) this.part(pv.x - ca * 10, pv.y - sa * 10, -ca * (80 + rand() * 60) + (rand() - 0.5) * 40, -sa * (80 + rand() * 60) + (rand() - 0.5) * 40, 0.5, 3, pickOne(["#ffffff", "#ffd27a", "#ff9a3c", "#b9b3a8"]), -12, 3, i < 4 ? 5 : 1);
    }
    if (w.kind === "bullet") this.shell(s, w.id === "shotgun" ? "#e0524a" : "#f1cf6a");
    s.bloom = Math.min(1.6, s.bloom + w.bloom);
    s.recoil = 1;
    s.vx -= ca * w.kick * (s.ground ? 0.3 : 1);
    if (!s.ground) s.vy -= sa * w.kick * 0.7;
    if (w.snd) this.sfx(w.snd, mz.x, mz.y, w.vol, w.pitch * (0.97 + rand() * 0.06));
    if (s === this.focus()) {
      this.cam.kx -= ca * Math.min(5, w.kick * 0.06 + 0.6);
      this.cam.ky -= sa * Math.min(5, w.kick * 0.06 + 0.6);
      this.cam.shake = Math.max(this.cam.shake, w.shake);
    }
    if (s.me) {
      this.combat = 1;
      if (w.id === "shotgun" || w.id === "sniper" || w.id === "magnum") this.hitStop = Math.max(this.hitStop, w.id === "sniper" ? 0.03 : 0.018);
    }
  }
  private mkShot(s: Sol, w: AWDef, x: number, y: number, a: number, v: number, life: number): Shot {
    return { x, y, px: x, py: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life, by: s, w: w.id, kind: w.kind, dmg: w.dmg, hit: [], tried: [], bounce: w.kind === "saw" ? 3 : 0, r: w.kind === "flame" ? 2 : 3, spin: 0, dist: 0 };
  }
  /** a spent case spins out of the gun, glinting, and bounces on the ground */
  private shell(s: Sol, col: string) {
    const pv = this.pivot(s);
    this.part(pv.x + Math.cos(s.aim) * 4, pv.y + Math.sin(s.aim) * 4 - 1, -s.face * (30 + rand() * 40), -90 - rand() * 60, 2.5, 2, col, 520, 0.5, 3);
  }

  // ───────────── the lightsaber ─────────────
  private startSwing(s: Sol) {
    if (s.swingT > 0 || s.fireCd > 0 || s.saberOn < 0.6) return;
    s.combo = this.t - s.lastSwing < 0.6 ? (s.combo + 1) % 3 : 0;
    s.swingKind = s.combo;
    s.swingDur = s.combo === 2 ? 0.46 : 0.3;
    s.swingT = s.swingDur;
    s.swingDir = s.face;
    s.swingHit = [];
    s.fireCd = s.swingDur + 0.03;
    s.lastSwing = this.t + s.swingDur;
    s.shield = 0;
    s.vx += s.face * (s.ground ? 70 : 40);
    if (s.combo === 2 && !s.ground) s.vy -= 40;
    this.sfx("saberswing", s.x, s.y, s.me ? 0.75 : 0.45, s.combo === 2 ? 0.85 : 0.95 + rand() * 0.15);
    if (s.me) this.combat = 1;
  }
  /** where the blade points: raised in guard, or somewhere along a forehand, a backhand or a full spin */
  private bladeAng(s: Sol) {
    const f = s.face, g0 = s.aim - f * 0.95;
    if (s.swingT <= 0) return g0 + Math.sin(this.t * 2.2 + s.id) * 0.05;
    const p = 1 - s.swingT / s.swingDur;
    let sw: number;
    if (s.swingKind === 0) sw = p < 0.28 ? -1.3 * easeOut(p / 0.28) : p < 0.7 ? -1.3 + 3.95 * smooth((p - 0.28) / 0.42) : 2.65 * (1 - smooth((p - 0.7) / 0.3));
    else if (s.swingKind === 1) sw = p < 0.25 ? 2.65 * easeOut(p / 0.25) : p < 0.68 ? 2.65 - 3.95 * smooth((p - 0.25) / 0.43) : -1.3 * (1 - smooth((p - 0.68) / 0.32));
    else sw = PI2 * smooth(p);
    return g0 + f * sw;
  }
  private swingTick(s: Sol, dt: number) {
    if (s.saberOn <= 0) { s.trail.length = 0; return; }
    if (s.swingT > 0) s.swingT -= dt;
    s.bladePrev = s.blade;
    s.blade = this.bladeAng(s);
    s.trail.unshift(s.blade);
    if (s.trail.length > 7) s.trail.length = 7;
    if (s.swingT <= 0) return;
    const p = 1 - s.swingT / s.swingDur, k = s.swingKind;
    const cut = k === 0 ? p > 0.26 && p < 0.74 : k === 1 ? p > 0.23 && p < 0.72 : p > 0.08 && p < 0.94;
    if (!cut) return;
    const pv = this.pivot(s);
    for (const e of this.sol) {
      if (!e.alive || e.team === s.team || s.swingHit.includes(e.id)) continue;
      const ex = e.x, ey = e.y - 9, d = Math.hypot(ex - pv.x, ey - pv.y);
      if (d > SABER_R) continue;
      const ea = Math.atan2(ey - pv.y, ex - pv.x), d0 = angDiff(s.bladePrev, ea), d1 = angDiff(s.blade, ea);
      const crossed = ((d0 <= 0 && d1 >= 0) || (d0 >= 0 && d1 <= 0)) && Math.abs(d0) + Math.abs(d1) < Math.PI;
      if (!crossed && Math.abs(d1) > 0.4 && d > 12) continue;
      s.swingHit.push(e.id);
      const es = e.slots[e.cur];
      if (es && es.id === "saber" && e.saberOn > 0.6 && e.swingT > 0 && rand() < 0.6) { this.clash(s, e); continue; }
      if (e.shield > 0) continue;
      const tang = s.blade + s.swingDir * Math.PI * 0.5;
      this.hurt(e, AWEP.saber.dmg * (k === 2 ? 0.8 : 1), s, "saber", tang, 230, false);
      this.sfx("saberclash", ex, ey, 0.6, 0.7);
      if (s.me) this.hitStop = Math.max(this.hitStop, 0.035);
    }
  }
  /** two blades meet: they lock, flash and throw each other apart */
  private clash(a: Sol, b: Sol) {
    const x = (a.x + b.x) / 2, y = (a.y + b.y) / 2 - 10, dir = b.x >= a.x ? 1 : -1;
    a.vx -= dir * 170; b.vx += dir * 170; a.swingT = 0; b.swingT = 0; a.fireCd = b.fireCd = 0.3;
    this.flashes.push({ x, y, r: 60, life: 0.16, max: 0.16, col: "#ffffff" });
    this.rings.push({ x, y, r: 26, life: 0, max: 0.3, col: "#ffffff" });
    this.hitfx.push({ x, y, ang: rand() * PI2, r: 16, kind: 1, life: 0, max: 0.18, col: "" });
    for (const s of [a, b]) for (let i = 0; i < 9; i++) this.part(x, y, (rand() - 0.5) * 240, (rand() - 0.5) * 200 - 40, 0.3 + rand() * 0.3, 1, pickOne([BEAM[s.team].col, BEAM[s.team].hot, "#ffffff"]), 260, 1.5, 5);
    this.sfx("saberclash", x, y, 1, 0.9);
    this.cam.shake = Math.max(this.cam.shake, 4);
    if (a.me || b.me) this.hitStop = Math.max(this.hitStop, 0.05);
  }
  /** a bullet or a bolt meets a blade held towards it: it goes back where it came from - or where you point it */
  private deflect(b: Shot, e: Sol) {
    const sp = Math.hypot(b.vx, b.vy);
    let a: number;
    if (e.me) a = e.aim + (rand() - 0.5) * 0.08;
    else { const o = b.by; a = Math.atan2(o.y - 9 - b.y, o.x - b.x) + (rand() - 0.5) * 0.3; }
    b.vx = Math.cos(a) * sp; b.vy = Math.sin(a) * sp; b.by = e; b.hit = []; b.tried = []; b.life = Math.max(b.life, 0.6); b.dist = 0; b.px = b.x; b.py = b.y;
    const B = BEAM[e.team];
    this.hitfx.push({ x: b.x, y: b.y, ang: a, r: 9, kind: 2, life: 0, max: 0.14, col: B.col });
    this.flashes.push({ x: b.x, y: b.y, r: 30, life: 0.1, max: 0.1, col: B.col });
    for (let i = 0; i < 7; i++) this.part(b.x, b.y, Math.cos(a) * 60 + (rand() - 0.5) * 160, Math.sin(a) * 60 + (rand() - 0.5) * 160 - 30, 0.25 + rand() * 0.2, 1, pickOne([B.col, B.hot, "#ffffff"]), 260, 1.5, 5);
    this.sfx("saberclash", b.x, b.y, 0.7, 1.1 + rand() * 0.2);
    e.recoil = 0.6;
    if (e.me) this.texts.push({ x: e.x, y: e.y - 30, text: "TANGKIS!", col: B.col, life: 0.8, vy: -20 });
    else if (rand() < 0.15) this.callout(e, "deflect");
  }

  private reloadStart(s: Sol) {
    const sl = s.slots[s.cur];
    if (!sl || s.reload > 0 || sl.mag >= AWEP[sl.id].mag || sl.ammo <= 0) return;
    s.reload = s.reloadMax = AWEP[sl.id].reload;
    this.sfx("magout", s.x, s.y, s.me ? 0.6 : 0.3);
    if (s.bot && rand() < 0.25) this.callout(s, "reload");
  }
  private swap(s: Sol) {
    const o = s.slots[1 - s.cur];
    if (!o) return;
    s.cur = 1 - s.cur;
    s.reload = 0;
    s.fireCd = Math.max(s.fireCd, 0.2);
    if (s.me) this.sfx("rack", s.x, s.y, 0.4);
  }
  private throwNade(s: Sol) {
    if (s.nades <= 0 || s.nadeCd > 0) return;
    s.nades--;
    s.nadeCd = 0.7;
    const a = s.aim, pv = this.pivot(s);
    this.nades.push({ x: pv.x + Math.cos(a) * 4, y: pv.y - 4 + Math.sin(a) * 4, vx: Math.cos(a) * NADE_V + s.vx * 0.4, vy: Math.sin(a) * NADE_V + s.vy * 0.3, fuse: 2.2, by: s, rot: 0, beep: false });
    this.sfx("whoosh", s.x, s.y, 0.6);
    if (rand() < 0.5) this.callout(s, "nade");
  }
  private meleeStart(s: Sol) {
    const sl = s.slots[s.cur];
    if (sl && sl.id === "saber") { this.startSwing(s); return; }
    if (s.meleeCd > 0 || s.reload > 0) return;
    s.melee = 0.28;
    s.meleeCd = 0.55;
    this.sfx("whoosh", s.x, s.y, 0.5, 1.3);
  }
  private meleeHit(s: Sol) {
    let hit = false;
    for (const e of this.sol) {
      if (!e.alive || e.team === s.team || e.shield > 0) continue;
      const dx = e.x - s.x, dy = e.y - s.y;
      if (Math.abs(dy) < 16 && dx * s.face > -3 && Math.abs(dx) < 20) {
        this.hurt(e, e.face === s.face ? 70 : 45, s, "melee", s.face > 0 ? -0.35 : Math.PI + 0.35, 260, false);
        hit = true;
      }
    }
    if (hit) this.sfx("thunk", s.x, s.y, 0.8);
  }

  private tryPick(s: Sol, manual: boolean) {
    let best: Pick | null = null, bd = 1e9;
    for (const p of this.picks) {
      if (p.spot && p.t > 0) continue;
      const dx = Math.abs(p.x - s.x), dy = Math.abs(p.y - 4 - (s.y - 9));
      if (dx > 12 || dy > 16) continue;
      const util = p.kind === "health" || p.kind === "nades";
      if (manual && util) continue;
      if (!manual) {
        const auto = p.kind === "health" ? s.hp < 100 : p.kind === "nades" ? s.nades < 4 : !s.slots[0] || !s.slots[1] || s.slots.some((q) => q && q.id === p.kind);
        if (!auto) continue;
      }
      if (dx + dy < bd) { bd = dx + dy; best = p; }
    }
    if (!best) return;
    const p = best;
    if (p.kind === "health") { s.hp = Math.min(100, s.hp + 60); if (s.me) this.texts.push({ x: s.x, y: s.y - 30, text: "+60", col: "#7dff9a", life: 1, vy: -18 }); }
    else if (p.kind === "nades") s.nades = Math.min(4, s.nades + 2);
    else {
      const id = p.kind as AW, d = AWEP[id], mag = p.spot ? d.mag : p.mag, ammo = p.spot ? d.ammo : p.ammo;
      const own = s.slots.findIndex((q) => q && q.id === id);
      if (own >= 0) { const q = s.slots[own]!; q.ammo = Math.min(d.ammo * 2, q.ammo + mag + ammo); }
      else {
        const empty = s.slots.findIndex((q) => !q), at = empty >= 0 ? empty : s.cur, old = s.slots[at];
        if (old && old.id !== "pistol" && (old.mag > 0 || old.ammo > 0 || old.id === "saber")) this.picks.push({ x: s.x, y: s.y, vx: s.face * 40, vy: -90, kind: old.id as PickKind, spot: false, t: 0, mag: old.mag, ammo: old.ammo, life: 14, bob: 0 });
        s.slots[at] = { id, mag, ammo };
        s.cur = at;
        s.reload = 0;
      }
      if (id === "saber") this.callout(s, "saber");
    }
    if (p.spot) p.t = RESPAWN_T[p.kind] ?? 20;
    else this.picks.splice(this.picks.indexOf(p), 1);
    this.sfx("pick", s.x, s.y, s.me ? 0.7 : 0.25);
    if (s.me && p.kind !== "health") this.texts.push({ x: s.x, y: s.y - 30, text: PICK_NAME[p.kind], col: "#7dff9a", life: 1, vy: -18 });
  }

  // ───────────── damage ─────────────
  private hurt(v: Sol, dmg: number, by: Sol | null, w: string, ang: number, knock: number, head: boolean) {
    if (!v.alive || this.phase === "end" || v.shield > 0) return;
    if (by && by !== v && by.team === v.team) return;
    if (by && by.bot && by.team !== this.me.team) dmg *= DMG_MUL[this.cfg!.diff];
    dmg = Math.max(1, Math.round(dmg));
    v.hp -= dmg;
    v.hurtT = 0;
    v.flash = 0.07;
    v.ouch = 0.35;
    v.tilt = clamp(v.tilt + (Math.cos(ang) >= 0 ? 1 : -1) * (0.2 + Math.min(0.45, dmg / 90)), -0.9, 0.9);
    if (by && by !== v) { v.lastBy = by; v.lastByT = this.t; by.dmg += dmg; }
    if (knock) { v.vx += Math.cos(ang) * knock; v.vy += Math.sin(ang) * knock * 0.5; }
    const hy = v.y - (head ? 14 : 8);
    if (w === "saber") {
      // a lightsaber cauterises: no blood - sparks, embers and a wisp of smoke
      const B = BEAM[by ? by.team : 0];
      for (let i = 0; i < 10; i++) this.part(v.x, hy, Math.cos(ang) * (40 + rand() * 120) + (rand() - 0.5) * 80, Math.sin(ang) * (40 + rand() * 120) - 40 - rand() * 60, 0.3 + rand() * 0.3, 1, pickOne([B.col, B.hot, "#ffffff", "#ff9a3c"]), 300, 1.5, 5);
      this.part(v.x, hy, 0, -20, 0.9, 3, pickOne(SMOKE), -30, 2, 1);
      this.hitfx.push({ x: v.x, y: hy, ang, r: 12, kind: 2, life: 0, max: 0.15, col: B.col });
    } else if (w !== "flame" && w !== "fall") {
      const n = Math.min(10, 2 + ((dmg / 8) | 0)) + (head ? 4 : 0);
      for (let i = 0; i < n; i++) this.part(v.x, hy, Math.cos(ang) * (40 + rand() * 90) + (rand() - 0.5) * 60, Math.sin(ang) * (40 + rand() * 90) - 30 - rand() * 50, 0.7, 1 + (rand() < 0.4 ? 1 : 0), pickOne(BLOOD), 520, 0.5, 4);
      if (this.bursts.length < 40) this.bursts.push({ x: v.x, y: hy, ang, r: head ? 14 : 8 + Math.min(7, dmg / 9), life: 0, max: 0.17, seed: rand() * 100 });
      if (this.hitfx.length < 40) this.hitfx.push({ x: v.x - Math.cos(ang) * 2, y: hy, ang: ang + Math.PI, r: head ? 11 : 7, kind: head ? 1 : 0, life: 0, max: head ? 0.14 : 0.1, col: "" });
    }
    if (w === "nade" || w === "rpg") v.dizzy = 0.9;
    if (by && by.me && v !== by) {
      this.hitMark = 0.14;
      this.texts.push({ x: v.x + (rand() - 0.5) * 6, y: v.y - 24, text: String(dmg), col: head ? "#ff5a6a" : "#fff3b0", life: 0.8, vy: -26 });
      if (head) { this.texts.push({ x: v.x, y: v.y - 34, text: "HEADSHOT!", col: "#ff5a6a", life: 1, vy: -14 }); audio.play("headshot", 0.75); }
      else audio.play("hit", 0.32);
    }
    if (v.me) { this.hurtFx = Math.min(1, this.hurtFx + dmg / 40); this.cam.shake = Math.max(this.cam.shake, 2 + dmg / 20); audio.play("hurt", 0.45); this.combat = 1; }
    if (v.bot && by && by !== v && !v.bot.target) v.bot.seen = { x: by.x, y: by.y, t: this.t };
    if (v.hp <= 0) this.kill(v, by, w, head);
    else if (dmg >= 30 && rand() < 0.4) this.callout(v, "hurt");
  }

  private kill(v: Sol, by: Sol | null, w: string, head: boolean) {
    v.alive = false; v.hp = 0; v.respawn = RESPAWN; v.deaths++; v.streak = 0; v.burn = 0; v.reload = 0; v.jet = false; v.melee = 0; v.swingT = 0; v.sayT = 0;
    v.vrot = (rand() - 0.5) * 12 + v.face * 3;
    v.vy = Math.min(v.vy, -80) - rand() * 80;
    v.rot = 0;
    if ((head && (w === "sniper" || w === "magnum" || w === "shotgun")) || (w === "saber" && rand() < 0.4)) {
      v.headless = true;
      this.parts.push({ x: v.x, y: v.y - 14, vx: v.vx + (rand() - 0.5) * 120, vy: -160 - rand() * 80, life: 3, max: 3, size: 1, col: "", grav: 600, drag: 0.4, kind: 7, rot: 0, vr: (rand() - 0.5) * 20, spr: opHead(v.team, v.skin), n: 0 });
    }
    if (w === "saber") for (let i = 0; i < 6; i++) this.part(v.x, v.y - 9, (rand() - 0.5) * 60, -20 - rand() * 40, 1 + rand(), 3, pickOne(SMOKE), -30, 2, 1);
    else if (w !== "flame") for (let i = 0; i < 14; i++) this.part(v.x, v.y - 9, (rand() - 0.5) * 200, -rand() * 160, 0.9, 1 + (rand() < 0.5 ? 1 : 0), pickOne(BLOOD), 520, 0.5, 4);
    const sl = v.slots[v.cur];
    if (sl && sl.id !== "pistol" && (sl.mag > 0 || sl.ammo > 0 || sl.id === "saber")) this.picks.push({ x: v.x, y: v.y - 6, vx: v.vx * 0.3, vy: -80, kind: sl.id as PickKind, spot: false, t: 0, mag: sl.mag, ammo: sl.ammo, life: 14, bob: 0 });
    v.saberOn = 0;
    this.sfx("hurt", v.x, v.y, 0.8, 0.7);
    let k = by && by !== v ? by : null;
    if (!k && v.lastBy && v.lastBy !== v && this.t - v.lastByT < 4) k = v.lastBy;
    if (k && k.team !== v.team) {
      this.score[k.team]++;
      k.kills++;
      k.streak++;
      k.multi = this.t - k.lastKill < 3.5 ? k.multi + 1 : 1;
      k.lastKill = this.t;
      k.joy = 1.4;
      if (rand() < 0.5) this.callout(k, "kill");
      if (k.me) { this.killMark = 0.3; this.announce(k); }
    }
    for (const o of this.sol) if (o !== v && o.alive && o.team === v.team && Math.hypot(o.x - v.x, o.y - v.y) < 160) o.mad = 2.5;
    this.feed.push({ id: this.ids++, k: k ? k.name : "", kt: k ? k.team : -1, v: v.name, vt: v.team, w: k ? w : "suicide", head, me: !!(k && k.me) || v.me, t: this.t });
    if (this.feed.length > 5) this.feed.shift();
    if (v.me) {
      this.killer = k;
      this.say("TUMBANG!", k ? `Dihabisi ${k.name}` : "Kecelakaan kerja...", "#ff4d5e", 2.2);
      audio.play("ko", 0.7);
    }
    if (k && this.score[k.team] >= this.cfg!.kills) this.finish();
  }
  private announce(k: Sol) {
    const multi = ["", "", "DOUBLE KILL!", "TRIPLE KILL!", "MULTI KILL!"][Math.min(4, k.multi)];
    const streak = k.streak === 5 ? "MEMBANTAI!" : k.streak === 8 ? "TAK TERHENTIKAN!" : k.streak === 12 ? "DEWA PERANG!" : "";
    if (streak) { this.say(streak, `${k.streak} kill tanpa mati`, "#ff9df0", 2); audio.play("jingle", 0.6); }
    else if (multi) { this.say(multi, "", "#ffe14a", 1.6); audio.play("chime", 0.6); }
  }

  private finish() {
    if (this.phase === "end") return;
    this.phase = "end";
    this.endT = 0;
    this.slow = 1.3;
    const win = this.score[0] === this.score[1] ? -1 : this.score[0] > this.score[1] ? 0 : 1, mine = win === this.me.team;
    this.say(win < 0 ? "SERI!" : mine ? "MENANG!" : "KALAH!", win < 0 ? "Skor imbang" : `TIM ${TEAMS[win].name} JUARA`, win < 0 ? "#ffffff" : TEAMS[win].color, 4);
    audio.stinger(win < 0 ? "found" : mine ? "win" : "lose");
  }
  private rows(): ArenaRow[] {
    return this.sol.map((s) => ({ name: s.name, team: s.team, k: s.kills, d: s.deaths, dmg: Math.round(s.dmg), me: s.me })).sort((a, b) => b.k - a.k || a.d - b.d || b.dmg - a.dmg);
  }
  private result(): ArenaResult {
    const win = this.score[0] === this.score[1] ? -1 : this.score[0] > this.score[1] ? 0 : 1;
    const mvp = this.sol.slice().sort((a, b) => b.kills * 100 + b.dmg - b.deaths * 30 - (a.kills * 100 + a.dmg - a.deaths * 30))[0];
    return { win, myTeam: this.me.team, score: [this.score[0], this.score[1]], rows: this.rows(), mvp: mvp.name, mvpTeam: mvp.team };
  }

  // ───────────── projectiles ─────────────
  private updShots(dt: number) {
    const m = this.map, sabers = this.sol.filter((e) => e.alive && e.saberOn > 0.8 && e.slots[e.cur]?.id === "saber");
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const b = this.shots[i];
      b.px = b.x; b.py = b.y;
      b.life -= dt;
      let dead = b.life <= 0;
      if (b.kind === "rocket") {
        const sp = Math.hypot(b.vx, b.vy), ns = Math.min(560, sp + 520 * dt);
        b.vx *= ns / sp; b.vy *= ns / sp;
        if (rand() < dt * 70) this.part(b.x, b.y, (rand() - 0.5) * 20, (rand() - 0.5) * 20 - 10, 0.7, 2, pickOne(SMOKE), -25, 2, 1);
        if (rand() < dt * 50) this.part(b.x, b.y, -b.vx * 0.1, -b.vy * 0.1, 0.12, 2, pickOne(FIRE), 0, 2, 5);
      } else if (b.kind === "flame") {
        b.vx *= Math.exp(-dt * 2.6);
        b.vy = b.vy * Math.exp(-dt * 2.6) - 70 * dt;
        b.r = Math.min(8, b.r + dt * 16);
      } else if (b.kind === "saw") b.spin += dt * 30;
      if (dead) {
        if (b.kind === "rocket") this.explode(b.x, b.y, 46, AWEP.rpg.dmg, b.by, "rpg");
        this.shots.splice(i, 1);
        continue;
      }
      const steps = Math.max(1, Math.ceil((Math.hypot(b.vx, b.vy) * dt) / 3)), sx = (b.vx * dt) / steps, sy = (b.vy * dt) / steps;
      const turnable = sabers.length > 0 && (b.kind === "bullet" || b.kind === "laser" || b.kind === "saw");
      for (let k = 0; k < steps && !dead; k++) {
        const nx = b.x + sx, ny = b.y + sy;
        if (solidPx(m, nx, ny)) {
          if (b.kind === "saw" && b.bounce > 0) {
            b.bounce--;
            const hx = solidPx(m, nx, b.y), hy = solidPx(m, b.x, ny);
            if (hx || !hy) b.vx = -b.vx;
            if (hy || !hx) b.vy = -b.vy;
            this.sparks(b.x, b.y, 5);
            this.sfx("wall", b.x, b.y, 0.5, 1.4);
            break;
          }
          this.impact(b, nx, ny);
          dead = true;
          break;
        }
        b.x = nx; b.y = ny; b.dist += 3;
        if (turnable) {
          let turned = false;
          for (const e of sabers) {
            if (e.team === b.by.team || b.tried.includes(e.id)) continue;
            if (Math.abs(b.x - e.x) > 15 || Math.abs(b.y - (e.y - 8)) > 15) continue;
            b.tried.push(e.id);
            const inc = Math.atan2(-b.vy, -b.vx);
            if (Math.abs(angDiff(e.aim, inc)) > (e.swingT > 0 ? 2.1 : 1.2) || rand() > (e.me ? 1 : 0.6)) continue;
            this.deflect(b, e);
            turned = true;
            break;
          }
          if (turned) break;
        }
        for (const e of this.sol) {
          if (!e.alive || e === b.by || e.team === b.by.team || b.hit.includes(e.id)) continue;
          if (b.kind === "flame") {
            if (Math.abs(b.x - e.x) < b.r + 4 && b.y > e.y - HH - b.r && b.y < e.y + b.r) {
              b.hit.push(e.id);
              if (e.shield > 0) continue;
              this.hurt(e, b.dmg, b.by, "flame", Math.atan2(b.vy, b.vx), 8, false);
              e.burn = 2.6; e.burnBy = b.by;
            }
            continue;
          }
          const dx = b.x - e.x, hy = b.y - (e.y - 14), head = dx * dx + hy * hy < 28, body = Math.abs(dx) < 5 && b.y > e.y - 10 && b.y < e.y + 1;
          if (!head && !body) continue;
          b.hit.push(e.id);
          if (e.shield > 0) { this.sparks(b.x, b.y, 4); if (!AWEP[b.w].pierce) { dead = true; break; } continue; }
          if (b.kind === "rocket") { this.explode(b.x, b.y, 46, AWEP.rpg.dmg, b.by, "rpg"); dead = true; break; }
          const w = AWEP[b.w];
          let dmg = b.dmg * (head ? w.head : 1);
          if (w.pellets > 1 || w.id === "uzi") dmg *= clamp(1.15 - (b.dist / w.range) * 0.6, 0.45, 1.1);
          this.hurt(e, dmg, b.by, b.w, Math.atan2(b.vy, b.vx), w.kind === "saw" ? 120 : w.pellets > 1 ? 30 : 18, head);
          if (b.kind === "laser") { const B = BEAM[b.by.team]; for (let q = 0; q < 4; q++) this.part(b.x, b.y, (rand() - 0.5) * 100, -rand() * 80, 0.25, 1, pickOne([B.col, B.hot]), 300, 1, 5); }
          if (!w.pierce) { dead = true; break; }
        }
      }
      if (dead) this.shots.splice(i, 1);
    }
  }
  private impact(b: Shot, x: number, y: number) {
    if (b.kind === "rocket") { this.explode(b.px, b.py, 46, AWEP.rpg.dmg, b.by, "rpg"); return; }
    if (b.kind === "flame") { if (rand() < 0.3) this.part(b.x, b.y, 0, -20, 0.5, 3, pickOne(SMOKE), -30, 2, 1); return; }
    const back = Math.atan2(-b.vy, -b.vx);
    if (b.kind === "laser") {
      // a blaster bolt burns a glowing scar into whatever it hits
      const B = BEAM[b.by.team];
      if (this.scorch.length < 60) this.scorch.push({ x, y, life: 1.4, col: B.col });
      this.hitfx.push({ x: b.x, y: b.y, ang: back, r: 6, kind: 2, life: 0, max: 0.12, col: B.col });
      for (let i = 0; i < 5; i++) this.part(b.x, b.y, Math.cos(back) * 60 + (rand() - 0.5) * 100, Math.sin(back) * 60 - rand() * 60, 0.3, 1, pickOne([B.col, B.hot]), 300, 1, 5);
      this.part(b.x, b.y, 0, -15, 0.8, 2, pickOne(SMOKE), -20, 2, 1);
      this.tg.fillStyle = "rgba(14,8,6,0.65)";
      this.tg.fillRect(Math.floor(x) - 1, Math.floor(y) - 1, 3, 2);
      if (rand() < 0.4) this.sfx("wall", x, y, 0.25, 1.6);
      return;
    }
    this.stars.push({ x: b.x, y: b.y, life: 0.07, col: "#ffffff" });
    this.hitfx.push({ x: b.x, y: b.y, ang: back, r: b.kind === "saw" ? 8 : 5, kind: 0, life: 0, max: 0.1, col: "" });
    this.sparks(b.x, b.y, b.kind === "saw" ? 8 : 3);
    for (let i = 0; i < 3; i++) this.part(b.x, b.y, -b.vx * 0.04 + (rand() - 0.5) * 30, -b.vy * 0.04 - rand() * 30, 0.35, 2, this.dustCol(), 300, 2, 6);
    this.tg.fillStyle = "rgba(20,16,12,0.55)";
    this.tg.fillRect(Math.floor(x) - 1, Math.floor(y) - 1, 2, 2);
    if (rand() < 0.35) this.sfx("wall", x, y, 0.35);
  }
  private sparks(x: number, y: number, n: number, cols = ["#fff3a0", "#ffd23a"]) {
    for (let i = 0; i < n; i++) this.part(x, y, (rand() - 0.5) * 160, (rand() - 0.5) * 160 - 30, 0.15 + rand() * 0.15, 1, pickOne(cols), 200, 1, 2);
  }
  private explode(x: number, y: number, r: number, dmg: number, by: Sol, w: string) {
    this.flashes.push({ x, y, r: r * 2.6, life: 0.28, max: 0.28, col: "#ffb35a" });
    this.rings.push({ x, y, r: r * 1.15, life: 0, max: 0.35, col: "#ffb347" });
    this.hitfx.push({ x, y, ang: rand() * Math.PI, r: 18, kind: 1, life: 0, max: 0.16, col: "" });
    for (let i = 0; i < 18; i++) { const a = rand() * PI2, v = 30 + rand() * 140; this.part(x, y, Math.cos(a) * v, Math.sin(a) * v - 40, 0.3 + rand() * 0.35, 3 + ((rand() * 3) | 0), pickOne(FIRE), -60, 3, 5); }
    for (let i = 0; i < 14; i++) { const a = rand() * PI2, v = 10 + rand() * 60; this.part(x + Math.cos(a) * 6, y + Math.sin(a) * 6, Math.cos(a) * v, Math.sin(a) * v - 30, 1 + rand() * 1.2, 3 + ((rand() * 3) | 0), pickOne(SMOKE), -30, 1.5, 1); }
    for (let i = 0; i < 10; i++) this.part(x, y, (rand() - 0.5) * 260, -rand() * 220, 1.4, 2, pickOne([this.map.theme.dirt[0], this.map.theme.rock[0], "#3a3236"]), 600, 0.4, 6);
    this.sparks(x, y, 10);
    this.tg.fillStyle = "rgba(18,12,10,0.32)";
    for (let k = 0; k < 46; k++) {
      const a = rand() * PI2, d = Math.sqrt(rand()) * r * 0.6, px = x + Math.cos(a) * d, py = y + Math.sin(a) * d;
      if (solidPx(this.map, px, py)) this.tg.fillRect(Math.floor(px), Math.floor(py), 2, 2);
    }
    for (const e of this.sol) {
      if (!e.alive || (e !== by && e.team === by.team)) continue;
      const cx = e.x, cy = e.y - 9, d = Math.hypot(cx - x, cy - y);
      if (d > r + 8 || !this.clear(x, y, cx, cy)) continue;
      const f = clamp(1 - d / (r + 8), 0, 1), ang = Math.atan2(cy - y, cx - x), kb = 120 + 360 * f;
      if (e.shield <= 0) { e.vx += Math.cos(ang) * kb; e.vy += Math.sin(ang) * kb - 90 * f; }
      this.hurt(e, dmg * (0.2 + 0.8 * f) * (e === by ? 0.45 : 1), by, w, ang, 0, false);
    }
    const d = Math.hypot(x - this.cam.x, y - this.cam.y);
    this.cam.shake = Math.max(this.cam.shake, clamp(9 - d / 50, 0, 9));
    this.sfx("boom", x, y, 1.1);
  }
  private updNades(dt: number) {
    const m = this.map;
    for (let i = this.nades.length - 1; i >= 0; i--) {
      const n = this.nades[i];
      n.fuse -= dt;
      n.vy += NADE_G * dt;
      if (m.theme.weather === "sand") n.vx += this.gust * 10 * dt;
      const steps = Math.max(1, Math.ceil((Math.hypot(n.vx, n.vy) * dt) / 2));
      for (let k = 0; k < steps; k++) {
        const nx = n.x + (n.vx * dt) / steps;
        if (solidPx(m, nx, n.y - 2)) { if (Math.abs(n.vx) > 60) this.sfx("thunk", n.x, n.y, 0.25, 1.6); n.vx = -n.vx * 0.5; } else n.x = nx;
        const ny = n.y + (n.vy * dt) / steps, r = Math.floor(ny / AT);
        const plat = n.vy > 0 && tileAt(m, Math.floor(n.x / AT), r) === PLAT && n.y <= r * AT + 0.5;
        if (solidPx(m, n.x, ny) || plat) {
          if (n.vy > 0) { if (n.vy > 90) this.sfx("thunk", n.x, n.y, 0.25, 1.6); n.vy = -n.vy * 0.42; n.vx *= 0.75; if (Math.abs(n.vy) < 30) n.vy = 0; }
          else n.vy = -n.vy * 0.5;
        } else n.y = ny;
      }
      n.rot += n.vx * dt * 0.25;
      if (!n.beep && n.fuse < 0.5) { n.beep = true; this.sfx("beep", n.x, n.y, 0.7); }
      if (n.fuse <= 0) { this.explode(n.x, n.y - 3, 54, 105, n.by, "nade"); this.nades.splice(i, 1); }
    }
  }
  private updPicks(dt: number) {
    for (let i = this.picks.length - 1; i >= 0; i--) {
      const p = this.picks[i];
      p.bob += dt;
      if (p.spot) { if (p.t > 0) p.t -= dt; continue; }
      if ((p.life -= dt) <= 0) { this.picks.splice(i, 1); continue; }
      p.vy = Math.min(400, p.vy + GRAV * dt);
      const nx = p.x + p.vx * dt;
      if (!solidPx(this.map, nx, p.y - 3)) p.x = nx; else p.vx = 0;
      const ny = p.y + p.vy * dt, r = Math.floor(ny / AT);
      if (p.vy > 0 && (solidPx(this.map, p.x, ny) || (tileAt(this.map, Math.floor(p.x / AT), r) === PLAT && p.y <= r * AT + 0.5))) { p.y = r * AT; p.vy = 0; p.vx *= 0.5; }
      else p.y = ny;
    }
  }

  // ───────────── particles ─────────────
  /** kinds: 0 plain, 1 smoke, 2 spark streak, 3 spent case, 4 blood, 5 fire and glowing embers, 6 debris, 7 a head, 8 a drop of water */
  private part(x: number, y: number, vx: number, vy: number, life: number, size: number, col: string, grav: number, drag: number, kind: number) {
    if (this.parts.length > 1400) return;
    this.parts.push({ x, y, vx, vy, life, max: life, size, col, grav, drag, kind, rot: 0, vr: kind === 3 ? (rand() - 0.5) * 30 : 0, spr: null, n: 0 });
  }
  private updParts(dt: number) {
    const m = this.map;
    for (let i = this.parts.length - 1; i >= 0; i--) {
      const p = this.parts[i];
      p.life -= dt;
      if (p.life <= 0) { this.parts.splice(i, 1); continue; }
      p.vy += p.grav * dt;
      const k = Math.exp(-p.drag * dt);
      p.vx *= k; p.vy *= k;
      const nx = p.x + p.vx * dt, ny = p.y + p.vy * dt;
      if (p.kind === 3 || p.kind === 6 || p.kind === 7) {
        if (solidPx(m, nx, p.y)) p.vx = -p.vx * 0.4; else p.x = nx;
        if (solidPx(m, p.x, ny)) {
          if (p.kind === 3 && p.n === 0 && this.shellT <= 0 && Math.abs(p.vy) > 80) { this.shellT = 0.07; this.sfx("shell", p.x, p.y, 0.25); }
          p.n++;
          p.vy = Math.abs(p.vy) > 60 ? -p.vy * 0.35 : 0;
          p.vx *= 0.6;
          p.vr *= 0.6;
        } else p.y = ny;
        p.rot += p.vr * dt;
      } else if (p.kind === 4) {
        if (solidPx(m, nx, ny)) { this.tg.fillStyle = p.col; this.tg.fillRect(Math.floor(nx), Math.floor(ny), p.size, p.size); this.parts.splice(i, 1); continue; }
        p.x = nx; p.y = ny;
      } else if (p.kind === 8) {
        if (solidPx(m, nx, ny) || tileAt(m, Math.floor(nx / AT), Math.floor(ny / AT)) === PLAT) {
          for (let q = 0; q < 3; q++) this.part(nx, ny - 1, (rand() - 0.5) * 40, -30 - rand() * 40, 0.3, 1, "#bfe8ff", 300, 1, 0);
          if (Math.abs(nx - this.cam.x) < 200 && Math.abs(ny - this.cam.y) < 150) this.sfx("drip", nx, ny, 0.35, 0.9 + rand() * 0.3);
          this.parts.splice(i, 1);
          continue;
        }
        p.x = nx; p.y = ny;
      } else { p.x = nx; p.y = ny; }
    }
  }

  // ───────────── the bots ─────────────
  private prm(s: Sol) {
    const d = DIFFS[s.team === this.me.team ? "normal" : this.cfg!.diff];
    return { react: d.react, err: d.aimErr, dodge: d.dodge, turn: d.id === "hard" ? 11 : d.id === "easy" ? 5.5 : 8 };
  }
  private lob(s: Sol, tx: number, ty: number) {
    const pv = this.pivot(s), sy0 = pv.y - 4, dx = tx - pv.x, X = Math.max(8, Math.abs(dx)), Y = -(ty - sy0), v2 = NADE_V * NADE_V, g = NADE_G;
    const disc = v2 * v2 - g * (g * X * X + 2 * Y * v2);
    const th = disc < 0 ? Math.PI / 4 : Math.atan((v2 - Math.sqrt(disc)) / (g * X));
    return dx >= 0 ? -th : Math.PI + th;
  }
  private rankOf(q: Slot | null) { return q ? AWEP[q.id].rank : 0; }
  private botThink(s: Sol, dt: number) {
    const b = s.bot!, c = s.ctl, P = this.prm(s);
    c.fire = false; c.nade = false; c.melee = false; c.reload = false; c.swap = false; c.pick = false; c.drop = false; c.jet = false; c.mx = 0;
    b.react -= dt; b.errT -= dt; b.burstT -= dt; b.strafeT -= dt; b.hopT -= dt; b.pathT -= dt; b.nadeCd -= dt; b.swapCd -= dt; b.unstuck -= dt;
    if (this.phase !== "live") { c.aim = s.aim; return; }
    const sl = s.slots[s.cur], w = AWEP[sl ? sl.id : "pistol"], sab = w.kind === "saber";
    if ((b.think -= dt) <= 0) {
      b.think = 0.12 + rand() * 0.1;
      let best: Sol | null = null, bd = 1e9;
      for (const e of this.sol) {
        if (!e.alive || e.team === s.team) continue;
        const d = Math.hypot(e.x - s.x, e.y - s.y);
        if (d > 430 || !this.clear(s.x, s.y - 10, e.x, e.y - 10)) continue;
        const sc = d - (e === b.target ? 80 : 0) + (e.shield > 0 ? 200 : 0);
        if (sc < bd) { bd = sc; best = e; }
      }
      if (best && best !== b.target) { b.react = P.react * (0.6 + rand() * 0.8); b.lock = 0; s.alert = 0.7; }
      b.target = best;
      if (best) b.seen = { x: best.x, y: best.y, t: this.t };
      const o = s.slots[1 - s.cur];
      if (o && b.swapCd <= 0) {
        const d = best ? Math.hypot(best.x - s.x, best.y - s.y) : 200;
        const val = (q: Slot | null) => {
          if (!q || (q.mag <= 0 && q.ammo <= 0)) return -99;
          const wd = AWEP[q.id];
          if (wd.kind === "saber") return 95 - Math.max(0, d - 160) * 0.3;
          return wd.rank * 10 - Math.max(0, d - wd.range) * 0.4 - (wd.kind === "rocket" && d < 70 ? 60 : 0) - (q.mag <= 0 ? 15 : 0);
        };
        if (val(o) > val(sl) + 8) { c.swap = true; b.swapCd = 1.5; }
      }
      if (!best) {
        let gx = this.map.w * AT * 0.5, gy = s.y, set = false, pd = 380;
        const worst = Math.min(this.rankOf(s.slots[0]), this.rankOf(s.slots[1]));
        for (const p of this.picks) {
          if (p.spot && p.t > 0) continue;
          const want = p.kind === "health" ? s.hp < 55 : p.kind === "nades" ? s.nades < 2 : AWEP[p.kind as AW].rank > worst + 1 && !s.slots.some((q) => q && q.id === p.kind);
          if (!want) continue;
          const d = Math.hypot(p.x - s.x, p.y - s.y) - (p.kind === "health" ? 150 : 0);
          if (d < pd) { pd = d; gx = p.x; gy = p.y; set = true; }
        }
        if (!set && b.seen && this.t - b.seen.t < 6) { gx = b.seen.x; gy = b.seen.y; set = true; if (Math.hypot(gx - s.x, gy - s.y) < 24) b.seen = null; }
        if (!set) {
          let ed = 1e9;
          for (const e of this.sol) if (e.alive && e.team !== s.team) { const d = Math.hypot(e.x - s.x, e.y - s.y); if (d < ed) { ed = d; gx = e.x; gy = e.y; } }
        }
        b.gx = gx; b.gy = gy;
        if (sl && !sab && sl.mag < AWEP[sl.id].mag * 0.5 && sl.ammo > 0) c.reload = true;
      }
      for (const p of this.picks) {
        if ((p.spot && p.t > 0) || p.kind === "health" || p.kind === "nades" || Math.abs(p.x - s.x) > 12 || Math.abs(p.y - s.y) > 14) continue;
        const worst = Math.min(this.rankOf(s.slots[0]), this.rankOf(s.slots[1]));
        if (AWEP[p.kind as AW].rank > worst || s.slots.some((q) => q && q.id === p.kind)) {
          const wi = s.slots.findIndex((q) => !q || AWEP[q.id].rank === worst);
          if (wi >= 0 && !s.slots.some((q) => q && q.id === p.kind)) s.cur = wi;
          c.pick = true;
          break;
        }
      }
    }
    const t = b.target && b.target.alive ? b.target : null;
    let want = s.aim;
    if (t) {
      const d = Math.hypot(t.x - s.x, t.y - s.y), lead = w.kind === "bullet" || w.kind === "laser" ? d / w.speed : w.kind === "rocket" ? d / 430 : 0.1;
      const tx = t.x + t.vx * lead * 0.8, ty = t.y - 9 + t.vy * lead * 0.4 + (w.kind === "rocket" ? 9 : 0);
      if (b.errT <= 0) { b.errT = 0.25 + rand() * 0.35; b.err = (rand() * 2 - 1) * P.err * (1 + Math.min(1, Math.hypot(t.vx, t.vy) / 150)); }
      want = Math.atan2(ty - (s.y - 5), tx - s.x) + (sab ? 0 : b.err * Math.max(0.3, 1 - b.lock * 0.5));
      b.lock += dt;
    } else if (b.seen && this.t - b.seen.t < 3) want = Math.atan2(b.seen.y - s.y, b.seen.x - s.x);
    else if (Math.abs(s.vx) > 20) want = s.vx > 0 ? 0.12 : Math.PI - 0.12;
    s.aim += clamp(angDiff(s.aim, want), -P.turn * dt, P.turn * dt);
    c.aim = s.aim;
    if (t) {
      const dx = t.x - s.x, d = Math.hypot(dx, t.y - s.y), off = Math.abs(angDiff(s.aim, want));
      if (sab) {
        // with a lightsaber: straight at them, blade first, and cut when close
        if (d < SABER_R - 2 && b.react <= 0) c.fire = true;
        if (d > 20) this.follow(s, t.x, t.y);
        else c.mx = Math.sign(dx);
        if (t.y < s.y - 24 && s.fuel > 0.2) c.jet = true;
      } else {
        if (b.react <= 0 && d < w.range * 1.1) {
          let ok = off < (w.pellets > 1 || w.kind === "flame" ? 0.28 : 0.12);
          if (w.id === "sniper" && b.lock < 0.45) ok = false;
          if (w.kind === "rocket" && d < 55) ok = false;
          if (ok) {
            if (w.auto) {
              if (b.burstT <= 0) { b.firing = !b.firing; b.burstT = b.firing ? 0.3 + rand() * 0.6 : (0.12 + rand() * 0.3) * (1.4 - P.dodge * 0.6); }
              c.fire = b.firing;
            } else c.fire = !s.trig && s.fireCd <= 0 && rand() < 0.7;
          }
        }
        if (d < 20) c.melee = true;
        if (s.nades > 0 && b.nadeCd <= 0 && d > 70 && d < 230 && rand() < dt * 0.5) { c.aim = s.aim = this.lob(s, t.x, t.y - 4); c.nade = true; b.nadeCd = 5 + rand() * 6; }
        const pref = w.kind === "flame" ? 45 : w.pellets > 1 ? 70 : w.id === "sniper" ? 260 : w.kind === "rocket" ? 170 : w.id === "uzi" ? 110 : 150;
        if (b.strafeT <= 0) { b.strafeT = 0.5 + rand() * 1.1; b.strafe = rand() < 0.5 ? -1 : 1; }
        if (d > pref + 60) this.follow(s, t.x, t.y);
        else {
          c.mx = d < pref - 40 ? (dx >= 0 ? -1 : 1) : b.strafe * 0.8;
          if (c.mx && this.blockedAhead(s, Math.sign(c.mx))) c.mx = -c.mx;
        }
        if (b.hopT <= 0) { b.hopT = (1.7 - P.dodge * 0.9) * (0.5 + rand()); b.hop = rand() < 0.35 + P.dodge * 0.5 ? 0.15 + rand() * 0.35 : 0; }
        if (b.hop > 0) { b.hop -= dt; if (s.fuel > 0.25) c.jet = true; }
        if (t.y < s.y - 48 && s.fuel > 0.3) c.jet = true;
      }
    } else this.follow(s, b.gx, b.gy);
    if (!s.ground && s.vy > 230 && s.fuel > 0.08) c.jet = true;
    if ((b.stuckT -= dt) <= 0) {
      b.stuckT = 1.1;
      if (Math.abs(s.x - b.lx) + Math.abs(s.y - b.ly) < 6 && (c.mx !== 0 || c.jet)) { b.pathT = 0; b.unstuck = 0.5; b.strafe = -b.strafe; }
      b.lx = s.x; b.ly = s.y;
    }
    if (b.unstuck > 0) { c.mx = b.strafe; c.jet = s.fuel > 0.15; }
  }
  private follow(s: Sol, gx: number, gy: number) {
    const b = s.bot!, c = s.ctl;
    if (b.pathT <= 0 || Math.abs(b.pgx - gx) + Math.abs(b.pgy - gy) > 64 || b.pi >= b.path.length) {
      b.path = findPath(this.map, s.x, s.y, gx, gy);
      b.pi = 0; b.pathT = 0.7 + rand() * 0.5; b.pgx = gx; b.pgy = gy;
    }
    while (b.pi < b.path.length && Math.abs(b.path[b.pi] - s.x) < 7 && Math.abs(b.path[b.pi + 1] - s.y) < 12) b.pi += 2;
    const wx = b.pi < b.path.length ? b.path[b.pi] : gx, wy = b.pi < b.path.length ? b.path[b.pi + 1] : gy;
    const dx = wx - s.x, dy = wy - s.y;
    c.mx = Math.abs(dx) > 4 ? Math.sign(dx) : 0;
    c.jet = dy < -6 || (c.mx !== 0 && this.blockedAhead(s, c.mx)) || (!s.ground && dy < 4 && s.vy > 60);
    if (dy > 10 && s.ground && this.onPlat(s)) c.drop = true;
    if (s.ground && dy < -30 && s.fuel < 0.3 && !b.target) { c.jet = false; c.mx = 0; }
    if (c.jet && s.fuel < 0.05) c.jet = false;
  }

  // ───────────── camera, sound ─────────────
  private focus(): Sol {
    if (this.me.alive) return this.me;
    if (this.killer && this.killer.alive) return this.killer;
    return this.me;
  }
  private camera(rdt: number) {
    const f = this.focus(), W = this.W, H = this.H;
    let lx = 0, ly = 0;
    if (f === this.me && this.me.alive) {
      const sl = this.me.slots[this.me.cur], k = sl && sl.id === "sniper" ? 0.62 : 0.3;
      if (this.touch) { if (this.joyR.on) { lx = this.joyR.x * W * k * 0.8; ly = this.joyR.y * H * k * 0.8; } }
      else { lx = (this.mouse.x - W / 2) * k; ly = (this.mouse.y - H / 2) * k; }
    }
    const a = 1 - Math.exp(-rdt * 7);
    this.cam.x += (f.x + lx - this.cam.x) * a;
    this.cam.y += (f.y - 16 + ly - this.cam.y) * a;
    const mw = this.map.w * AT, mh = this.map.h * AT;
    this.cam.x = clamp(this.cam.x, W / 2, Math.max(W / 2, mw - W / 2));
    this.cam.y = clamp(this.cam.y, H / 2, Math.max(H / 2, mh - H / 2));
    this.cam.shake = Math.max(0, this.cam.shake - rdt * 18);
    this.cam.kx *= Math.exp(-rdt * 12);
    this.cam.ky *= Math.exp(-rdt * 12);
    const sh = this.cam.shake;
    this.cl = Math.round(this.cam.x - W / 2 + (rand() - 0.5) * sh + this.cam.kx);
    this.ct = Math.round(this.cam.y - H / 2 + (rand() - 0.5) * sh + this.cam.ky);
  }
  private sfx(n: SfxName, x: number, y: number, v = 1, pitch = 1) {
    const dx = x - this.cam.x, d = Math.hypot(dx, y - this.cam.y), vol = v * clamp(1.25 - d / 520, 0, 1);
    if (vol < 0.03) return;
    audio.play(n, vol, { pan: clamp(dx / (this.W * 0.6), -1, 1), far: clamp((d - 100) / 320, 0, 1), pitch });
  }
  private sound(rdt: number) {
    const me = this.me, T = this.map.theme;
    let jet = me.alive && me.jet ? 0.8 : 0, flame = 0, near = 0, hum = 0, rate = 0;
    for (const s of this.sol) {
      if (!s.alive) continue;
      const d = Math.hypot(s.x - this.cam.x, s.y - this.cam.y);
      if (s.saberOn > 0) { const v = s.saberOn * (s.me ? 0.6 : 0.45) * clamp(1.2 - d / 300, 0, 1); if (v > hum) { hum = v; rate = clamp(Math.abs(angDiff(s.bladePrev, s.blade)) * 6, 0, 1); } }
      if (s === me) continue;
      if (s.jet && d < 260) jet = Math.max(jet, 0.4 * (1 - d / 260));
      if (s.team !== me.team && d < 300) near++;
    }
    for (const b of this.shots) if (b.kind === "flame" && Math.abs(b.x - this.cam.x) < 240 && Math.abs(b.y - this.cam.y) < 160) flame = Math.min(0.9, flame + 0.03);
    this.humRate += (rate - this.humRate) * Math.min(1, rdt * 12);
    audio.loop("jet", this.paused ? 0 : jet, me.jet ? 0.4 + me.fuel * 0.6 : 0.3);
    audio.loop("flame", this.paused ? 0 : flame, 0.5);
    audio.loop("saber", this.paused ? 0 : Math.min(0.9, hum + this.humRate * 0.25), this.humRate * 0.5);
    const want = this.phase === "live" ? clamp(0.18 + near * 0.16 + this.combat * 0.45, 0, 1) : 0.08;
    this.tension += (want - this.tension) * Math.min(1, rdt * 1.4);
    this.combat = Math.max(0, this.combat - rdt * 0.25);
    audio.music(this.paused ? 0 : this.tension);
    audio.city({ wind: T.amb.wind * (T.weather === "sand" ? 0.45 + this.gust * 0.8 : 1), birds: T.amb.birds, night: T.amb.night, drone: T.amb.drone, water: T.amb.water, rain: T.rain });
  }

  // ───────────── HUD ─────────────
  private hudState(): ArenaHud {
    const me = this.me, cfg = this.cfg!;
    let near = "";
    if (me.alive) {
      let bd = 1e9;
      for (const p of this.picks) {
        if ((p.spot && p.t > 0) || p.kind === "health" || p.kind === "nades") continue;
        const dx = Math.abs(p.x - me.x), dy = Math.abs(p.y - 4 - (me.y - 9));
        if (dx <= 12 && dy <= 16 && dx + dy < bd) { bd = dx + dy; near = PICK_NAME[p.kind]; }
      }
    }
    return {
      phase: this.phase, time: Math.max(0, Math.ceil(this.timeLeft)), score: [this.score[0], this.score[1]], target: cfg.kills, myTeam: me.team,
      hp: Math.max(0, Math.ceil(me.hp)), fuel: me.fuel, nades: me.nades, alive: me.alive, respawn: Math.max(0, Math.ceil(me.respawn)), shield: me.alive && me.shield > 0,
      slots: me.slots.map((q) => (q ? { id: q.id, name: AWEP[q.id].name, mag: q.mag, ammo: q.ammo, max: AWEP[q.id].mag } : null)), cur: me.cur,
      reload: me.reload > 0 ? 1 - me.reload / me.reloadMax : -1,
      feed: this.feed.slice(), banner: this.banner, near, rows: this.rows(), killer: this.killer ? this.killer.name : "", streak: me.streak, music: audio.musicOn,
    };
  }

  // ───────────── drawing ─────────────
  private glowCol(col: string) {
    if (!this.glowC[col]) {
      const [c, g] = mk(64, 64), grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      grd.addColorStop(0, col);
      grd.addColorStop(1, "rgba(0,0,0,0)");
      g.fillStyle = grd;
      g.fillRect(0, 0, 64, 64);
      this.glowC[col] = c;
    }
    return this.glowC[col];
  }
  private R(c: string, x: number, y: number, w: number, h: number) { this.ctx.fillStyle = c; this.ctx.fillRect(x, y, w, h); }

  private render() {
    const ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, T = this.map.theme;
    this.sky();
    this.waterfall();
    ctx.drawImage(this.terr, cl, ct, W, H, 0, 0, W, H);
    this.dynDecor();
    // pickups
    for (const p of this.picks) {
      const x = Math.round(p.x) - cl, y = Math.round(p.y) - ct;
      if (x < -20 || x > W + 20 || y < -20 || y > H + 20) continue;
      if (p.spot && p.t > 0) { this.R("rgba(255,255,255,0.18)", x - 5, y - 1, 10, 1); continue; }
      const bob = p.spot ? Math.round(Math.sin(p.bob * 3) * 1.5) : 0;
      if (p.spot) { ctx.globalAlpha = p.kind === "saber" ? 0.55 + 0.25 * Math.sin(this.t * 4) : 0.35; ctx.drawImage(this.glowCol(p.kind === "saber" ? "#9ae8ff" : p.kind === "health" ? "#ff5a6a" : p.kind === "nades" ? "#7dff9a" : "#ffe14a"), x - (p.kind === "saber" ? 18 : 12), y - (p.kind === "saber" ? 24 : 18), p.kind === "saber" ? 36 : 24, p.kind === "saber" ? 36 : 24); ctx.globalAlpha = 1; }
      if (!p.spot && p.life < 3 && Math.sin(this.t * 20) > 0) continue;
      this.R("rgba(0,0,0,0.3)", x - 5, y - 1, 10, 2);
      if (p.kind === "health") ctx.drawImage(medSpr(), x - 5, y - 10 + bob);
      else if (p.kind === "nades") { const n = nadeSpr(); ctx.drawImage(n, x - 6, y - 7 + bob); ctx.drawImage(n, x + 1, y - 7 + bob); }
      else { const s = wspr(0, p.kind as AW); ctx.drawImage(s.c, x - (s.c.width >> 1), y - s.c.height - 2 + bob); }
    }
    const ns = nadeSpr();
    for (const n of this.nades) {
      const x = Math.round(n.x) - cl, y = Math.round(n.y) - ct;
      ctx.save(); ctx.translate(x, y - 3); ctx.rotate(n.rot); ctx.drawImage(ns, -2, -3); ctx.restore();
      if (n.fuse < 0.6 && Math.sin(this.t * 40) > 0) this.R("#ff4d5e", x - 1, y - 7, 2, 2);
    }
    if (this.tumbles.length) {
      const ts = tumbleSpr();
      for (const q of this.tumbles) { ctx.save(); ctx.translate(Math.round(q.x - cl), Math.round(q.y - ct)); ctx.rotate(q.rot); ctx.scale(q.s, q.s); ctx.drawImage(ts, -7, -7); ctx.restore(); }
    }
    // soldiers: the fallen first, you last
    for (const s of this.sol) if (!s.alive) this.drawSol(s);
    for (const s of this.sol) if (s.alive && !s.me) this.drawSol(s);
    if (this.me.alive) this.drawSol(this.me);
    // rockets, saws, flames
    for (const b of this.shots) {
      const x = b.x - cl, y = b.y - ct;
      if (x < -30 || x > W + 30 || y < -30 || y > H + 30) continue;
      if (b.kind === "rocket") {
        ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(Math.atan2(b.vy, b.vx));
        this.R(Math.sin(this.t * 70) > 0 ? "#ffe45c" : "#ff9a3c", -11, -1, 5, 3); this.R("#0a0a0f", -6, -3, 12, 7); this.R("#d9dee8", -5, -2, 7, 5); this.R("#9aa3b5", -5, 1, 7, 2);
        this.R(TEAMS[b.by.team].color, -2, -2, 2, 5); this.R("#e0483e", 2, -2, 3, 5); this.R("#ff8a80", 2, -2, 2, 1);
        ctx.restore();
      } else if (b.kind === "saw") {
        ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(b.spin);
        this.R("#0a0a0f", -4, -4, 8, 8); this.R("#c9d6e0", -3, -3, 6, 6); this.R("#ffffff", -4, -1, 1, 2); this.R("#ffffff", 3, -1, 1, 2); this.R("#ffffff", -1, -4, 2, 1); this.R("#ffffff", -1, 3, 2, 1); this.R("#5a6070", -1, -1, 2, 2);
        ctx.restore();
      } else if (b.kind === "flame") {
        const k = b.life / 0.45;
        ctx.globalAlpha = clamp(k, 0, 0.9);
        ctx.fillStyle = k > 0.6 ? "#fff3a0" : k > 0.35 ? "#ffb03a" : "#ff5a2a";
        ctx.fillRect(Math.round(x - b.r / 2), Math.round(y - b.r / 2), Math.ceil(b.r), Math.ceil(b.r));
        ctx.globalAlpha = 1;
      }
    }
    // particles (the glowing ones come later, over the dark)
    for (const p of this.parts) {
      if (p.kind === 5) continue;
      const x = p.x - cl, y = p.y - ct;
      if (x < -10 || x > W + 10 || y < -10 || y > H + 10) continue;
      const k = p.life / p.max;
      if (p.kind === 7 && p.spr) { ctx.save(); ctx.translate(Math.round(x), Math.round(y)); ctx.rotate(p.rot); ctx.drawImage(p.spr, -7, -5); ctx.restore(); continue; }
      if (p.kind === 1) { ctx.globalAlpha = k * 0.6; const s = Math.round(p.size + (1 - k) * 5); this.R(p.col, Math.round(x - s / 2), Math.round(y - s / 2), s, s); ctx.globalAlpha = 1; continue; }
      if (p.kind === 2) { ctx.strokeStyle = p.col; ctx.globalAlpha = k; ctx.lineWidth = 1; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - p.vx * 0.02, y - p.vy * 0.02); ctx.stroke(); ctx.globalAlpha = 1; continue; }
      if (p.kind === 3) {
        // a case tumbling through the air: it glints as it turns
        const fl = ((p.life * 22) | 0) & 1, px = Math.round(x), py = Math.round(y);
        if (p.life < 0.6) ctx.globalAlpha = p.life / 0.6;
        this.R(p.col, px - 1, py, p.n > 1 ? 2 : fl ? 3 : 1, p.n > 1 ? 1 : fl ? 1 : 3);
        if (fl && p.n < 2) this.R("#ffffff", px, py, 1, 1);
        ctx.globalAlpha = 1;
        continue;
      }
      if (p.kind === 8) { this.R(p.col, Math.round(x), Math.round(y) - 1, 1, 2); continue; }
      this.R(p.col, Math.round(x), Math.round(y), p.size, p.size);
    }
    this.drawBursts();
    this.lights();
    if (this.emis) {
      // what glows by itself shines through the dark
      ctx.globalCompositeOperation = "lighter";
      ctx.globalAlpha = 0.72 + 0.28 * Math.sin(this.t * 1.7);
      ctx.drawImage(this.emis, cl, ct, W, H, 0, 0, W, H);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
    this.glowPass();
    this.weather();
    if (T.fog) { const fg = ctx.createLinearGradient(0, H * 0.4, 0, H); fg.addColorStop(0, "rgba(120,100,130,0)"); fg.addColorStop(1, `rgba(120,100,130,${T.fog})`); ctx.fillStyle = fg; ctx.fillRect(0, 0, W, H); }
    // names, health, speech, what is over their heads
    for (const s of this.sol) {
      if (!s.alive) continue;
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      if (x < -30 || x > W + 30 || y < -50 || y > H + 10) continue;
      if (s.me) { const b = Math.round(Math.sin(this.t * 5) * 1); this.R("#0a0a0f", x - 2, y - 29 + b, 5, 3); this.R("#ffffff", x - 1, y - 29 + b, 3, 2); }
      else {
        drawText(ctx, s.name, x, y - 31, TEAMS[s.team].color);
        if (s.hp < 100) { this.R("#0a0a0f", x - 7, y - 25, 14, 3); this.R(s.team === this.me.team ? "#7dff9a" : "#ff4d5e", x - 6, y - 24, Math.max(1, Math.round((s.hp / 100) * 12)), 1); }
      }
      this.emotes(s, x, y);
      if (s.sayT > 0 && s.say) {
        const by = y - (s.me ? 40 : 45), w = s.say.length * 4 + 5, bx = clamp(x - (w >> 1), 1, W - w - 1);
        this.R("#0a0a0f", bx - 1, by - 1, w + 2, 9); this.R("#ffffff", bx, by, w, 7); this.R("#0a0a0f", x - 1, by + 7, 3, 2); this.R("#ffffff", x, by + 7, 1, 1);
        drawText(ctx, s.say, bx + w / 2, by + 1, "#1b1b26", "#ffffff");
      }
    }
    for (const q of this.texts) { ctx.globalAlpha = Math.min(1, q.life * 2.5); drawText(ctx, q.text, Math.round(q.x - cl), Math.round(q.y - ct), q.col); ctx.globalAlpha = 1; }
    // laser sights
    for (const s of this.sol) {
      const sl = s.slots[s.cur];
      if (!s.alive || !sl || sl.id !== "sniper" || s.reload > 0) continue;
      const m = this.muzzle(s), ca = Math.cos(s.aim), sa = Math.sin(s.aim);
      let ex = m.x, ey = m.y;
      for (let d = 0; d < 520; d += 4) {
        ex = m.x + ca * d; ey = m.y + sa * d;
        if (solidPx(this.map, ex, ey)) break;
        let hitS = false;
        for (const e of this.sol) if (e !== s && e.alive && Math.abs(ex - e.x) < 5 && ey > e.y - 19 && ey < e.y) { hitS = true; break; }
        if (hitS) break;
      }
      ctx.strokeStyle = s.team === this.me.team ? "rgba(255,80,96,0.45)" : "rgba(255,40,60,0.6)";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(m.x - cl, m.y - ct); ctx.lineTo(ex - cl, ey - ct); ctx.stroke();
      this.R("#ff3a4a", Math.round(ex - cl) - 1, Math.round(ey - ct) - 1, 2, 2);
    }
    this.drawMini();
    const me = this.me;
    if (me.alive && this.phase !== "end") {
      let cx = this.mouse.x, cy = this.mouse.y;
      if (this.touch) { cx = me.x - cl + Math.cos(me.aim) * 46; cy = me.y - 5 - ct + Math.sin(me.aim) * 46; }
      const sl = me.slots[me.cur], w = AWEP[sl ? sl.id : "pistol"], gap = Math.round(3 + me.bloom * 3 + w.spread * 30 + me.recoil * 2);
      let over = false;
      for (const e of this.sol) if (e.alive && e.team !== me.team && Math.abs(cx + cl - e.x) < 7 && cy + ct > e.y - 21 && cy + ct < e.y + 2) over = true;
      const col = over ? "#ff4d5e" : "#ffffff";
      for (const [dx, dy, w2, h2] of [[-gap - 3, 0, 3, 1], [gap + 1, 0, 3, 1], [0, -gap - 3, 1, 3], [0, gap + 1, 1, 3]]) { this.R("#0a0a0f", Math.round(cx + dx) - 1, Math.round(cy + dy) - 1, w2 + 2, h2 + 2); this.R(col, Math.round(cx + dx), Math.round(cy + dy), w2, h2); }
      this.R(col, Math.round(cx), Math.round(cy), 1, 1);
      if (this.hitMark > 0) {
        const c2 = this.killMark > 0 ? "#ff4d5e" : "#ffffff";
        for (let i = 2; i < 5; i++) { this.R(c2, Math.round(cx) - i, Math.round(cy) - i, 1, 1); this.R(c2, Math.round(cx) + i, Math.round(cy) - i, 1, 1); this.R(c2, Math.round(cx) - i, Math.round(cy) + i, 1, 1); this.R(c2, Math.round(cx) + i, Math.round(cy) + i, 1, 1); }
      }
    }
    const low = me.alive && me.hp < 30 ? 0.18 + Math.sin(this.t * 6) * 0.08 : 0;
    const red = Math.max(this.hurtFx * 0.45, low);
    if (red > 0.01) {
      ctx.strokeStyle = `rgba(210,20,40,${red.toFixed(3)})`;
      for (let i = 0; i < 4; i++) { ctx.lineWidth = 10 - i * 2; ctx.strokeRect(5 + i * 3, 5 + i * 3, W - 10 - i * 6, H - 10 - i * 6); }
    }
    if (!me.alive && this.phase !== "end") { ctx.fillStyle = "rgba(20,0,8,0.22)"; ctx.fillRect(0, 0, W, H); }
  }

  /** the sky, the sun through the haze, and the parallax layers of whatever lies behind the arena */
  private sky() {
    const ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, T = this.map.theme, B = this.back;
    const grd = ctx.createLinearGradient(0, 0, 0, H);
    grd.addColorStop(0, T.sky[0]); grd.addColorStop(0.55, T.sky[1]); grd.addColorStop(1, T.sky[2]);
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, W, H);
    if (T.sun) {
      const sx = W * 0.74 - cl * 0.02, sy = 38 - ct * 0.03;
      ctx.globalAlpha = 0.35; ctx.drawImage(this.glowCol("#fff0c8"), sx - 90, sy - 90, 180, 180);
      ctx.globalAlpha = 0.6; ctx.drawImage(this.glowCol("#fff6dc"), sx - 34, sy - 34, 68, 68); ctx.globalAlpha = 1;
      ctx.fillStyle = "#fff8e4"; ctx.beginPath(); ctx.arc(sx, sy, 12, 0, PI2); ctx.fill();
    }
    if (B.tile) {
      for (const [img, p] of [[B.far, 0.18], [B.mid, 0.4]] as [HTMLCanvasElement | null, number][]) {
        if (!img) continue;
        const iw = img.width, ih = img.height, ox = ((-cl * p) % iw + iw) % iw, oy = ((-ct * p) % ih + ih) % ih;
        for (let y = oy - ih; y < H; y += ih) for (let x = ox - iw; x < W; x += iw) ctx.drawImage(img, Math.round(x), Math.round(y));
      }
      return;
    }
    const horizon = (T.decor === "city" ? 64 : 60) * AT;
    const strip = (img: HTMLCanvasElement | null, p: number) => {
      if (!img) return;
      const yb = Math.round(H * 0.82 + (horizon - ct - H * 0.82) * p), off = (((-cl * p) % 960) + 960) % 960;
      for (let x = off - 960; x < W; x += 960) ctx.drawImage(img, Math.round(x), yb - img.height);
    };
    B.clouds.forEach((c, i) => {
      const sp = T.weather === "sand" ? 14 + i * 5 + this.gust * 20 : 5 + i * 2;
      const x = ((((i * 270 + this.t * sp - cl * 0.08) % (W + 160)) + W + 160) % (W + 160)) - 130;
      ctx.drawImage(c, Math.round(x), Math.round(14 + i * 15 - ct * 0.04));
    });
    strip(B.far, 0.15);
    strip(B.mid, 0.3);
    strip(B.near, 0.48);
    if (T.weather === "sand") {
      // the storm thickens towards the horizon
      const hz = ctx.createLinearGradient(0, H * 0.35, 0, H);
      hz.addColorStop(0, "rgba(232,176,112,0)");
      hz.addColorStop(1, `rgba(232,176,112,${(0.18 + this.gust * 0.22).toFixed(3)})`);
      ctx.fillStyle = hz;
      ctx.fillRect(0, 0, W, H);
    }
  }

  /** the waterfall of the crystal cave: drawn behind the rock, so it pours out of the roof and past the platforms */
  private waterfall() {
    const ctx = this.ctx, W = this.W, H = this.H;
    for (const d of this.map.dyn) {
      if (d.k !== "fall") continue;
      const x = d.x - this.cl, y0 = d.y - this.ct, y1 = y0 + d.h;
      if (x < -20 || x > W + 20 || y1 < 0 || y0 > H) continue;
      const top = Math.max(0, Math.floor(y0)), bot = Math.min(H, Math.ceil(y1));
      for (let i = -6; i <= 5; i++) {
        const edge = Math.abs(i + 0.5) / 6;
        for (let yy = top; yy < bot; yy += 2) {
          const ph = (((yy - y0 + this.t * 150 + i * 13 + i * i * 7) % 22) + 22) % 22;
          ctx.fillStyle = ph < 3 ? "#e8fbff" : ph < 10 ? "#8fd8ff" : "#4a9ad8";
          ctx.globalAlpha = 0.8 - edge * 0.5;
          ctx.fillRect(Math.round(x + i), yy, 1, 2);
        }
      }
      ctx.globalAlpha = 1;
      for (let i = 0; i < 8; i++) { const k = (this.t * 2 + i * 0.37) % 1; this.R("#ffffff", Math.round(x - 7 + ((i * 5) % 14)), Math.round(y0 + k * 4), 1, 1); }
    }
  }

  /** flags in the wind and lanterns on their chains */
  private dynDecor() {
    const W = this.W, H = this.H, t = this.t;
    for (const d of this.map.dyn) {
      const x = Math.round(d.x - this.cl), y = Math.round(d.y - this.ct);
      if (x < -30 || x > W + 30 || y < -40 || y > H + 20) continue;
      if (d.k === "flag") {
        const wind = this.map.theme.weather === "sand" ? 0.6 + this.gust : 0.7, team = TEAMS[d.t];
        this.R("#0a0a0f", x - 1, y - 25, 3, 25); this.R("#c9cdd9", x, y - 25, 1, 25); this.R("#f5c542", x - 1, y - 27, 3, 2);
        for (let i = 0; i < 14; i++) {
          const k = i / 13, wave = Math.round(Math.sin(t * (5 + wind * 4) - i * 0.6 + d.x) * (0.6 + k * 2) * Math.min(1.2, wind));
          this.R("#0a0a0f", x + 1 + i, y - 25 + wave, 1, 10);
          this.R(i % 5 === 2 ? team.dark : team.color, x + 1 + i, y - 24 + wave, 1, 8);
          if (i >= 5 && i <= 7) this.R("#ffffff", x + 1 + i, y - 21 + wave, 1, 2);
        }
      } else if (d.k === "lantern") {
        const sw = Math.sin(t * 1.6 + d.v * 6) * 1.5, fl = Math.sin(t * 13 + d.v * 9) > 0.7;
        for (let k = 0; k < 5; k++) this.R("#3a3a44", x + Math.round((sw * k) / 5), y - 13 + k * 2, 1, 1);
        const bx = x + Math.round(sw) - 2, by = y - 4;
        this.R("#0a0a0f", bx - 1, by - 1, 6, 8); this.R("#5a4a2a", bx, by, 4, 1); this.R(fl ? "#ffe9a0" : "#ffd27a", bx, by + 1, 4, 4); this.R("#fff6d8", bx + 1, by + 2, 1, 2); this.R("#5a4a2a", bx, by + 5, 4, 1);
      }
    }
  }

  private drawBursts() {
    const ctx = this.ctx;
    for (const b of this.bursts) {
      // blood burst: a fan of jets from the wound - mostly forwards, a little back - each ending in a fat drop
      const k = b.life / b.max, x = b.x - this.cl, y = b.y - this.ct, hv = (i: number) => Math.abs(Math.sin(b.seed + i * 12.9898) * 43758.5453) % 1;
      ctx.globalAlpha = 1 - k * k * 0.8;
      for (let i = 0; i < 9; i++) {
        const back = i >= 7, a = b.ang + (back ? Math.PI : 0) + (hv(i) - 0.5) * (back ? 1.2 : 1.5);
        const L = b.r * (back ? 0.45 : 0.55 + hv(i + 20) * 0.75) * (0.35 + 0.65 * Math.sqrt(k)), L0 = L * Math.max(0, k * 1.5 - 0.5);
        const ca = Math.cos(a), sa = Math.sin(a) * 0.8;
        ctx.strokeStyle = i % 3 === 0 ? "#e2404a" : i % 3 === 1 ? "#b01c2a" : "#7a0e1a";
        ctx.lineWidth = Math.max(1, (i % 3 === 0 ? 3 : 2) * (1 - k));
        ctx.beginPath(); ctx.moveTo(x + ca * L0, y + sa * L0); ctx.lineTo(x + ca * L, y + sa * L); ctx.stroke();
        const d = k < 0.6 ? 2 : 1;
        ctx.fillStyle = "#c8202e";
        ctx.fillRect(Math.round(x + ca * L) - (d >> 1), Math.round(y + sa * L) - (d >> 1), d, d);
      }
      if (k < 0.5) { ctx.fillStyle = "#ff6a6a"; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); }
    }
    ctx.globalAlpha = 1;
  }

  /** darkness with holes for every light, then the coloured glow of the lights on top */
  private lights() {
    const T = this.map.theme, ctx = this.ctx, W = this.W, H = this.H, cl = this.cl, ct = this.ct, t = this.t;
    if (T.dark > 0) {
      const dg = this.dg;
      dg.globalCompositeOperation = "source-over";
      dg.clearRect(0, 0, W, H);
      dg.fillStyle = `rgba(4,3,12,${T.dark})`;
      dg.fillRect(0, 0, W, H);
      dg.globalCompositeOperation = "destination-out";
      const hole = (x: number, y: number, r: number, a: number) => {
        if (x + r < 0 || x - r > W || y + r < 0 || y - r > H) return;
        dg.globalAlpha = a;
        dg.drawImage(this.glow, x - r, y - r, r * 2, r * 2);
      };
      for (const l of this.map.lights) hole(l.x - cl, l.y - ct, l.r * (1 + l.pulse * Math.sin(t * 2.2 + l.x * 0.05)), 1);
      for (const s of this.sol) {
        if (!s.alive) continue;
        hole(s.x - cl, s.y - 10 - ct, s.me ? 70 : 40, s.me ? 0.9 : 0.7);
        if (s.jetK > 0.2) hole(s.x - s.face * 8 - cl, s.y + 4 - ct, 34 * s.jetK, 0.8);
        if (s.saberOn > 0 && s.tip) hole(s.tip[0] + Math.cos(s.tip[2]) * (s.tip[3] + 10), s.tip[1] + Math.sin(s.tip[2]) * (s.tip[3] + 10), 62 * s.saberOn, 1);
      }
      for (const f of this.flashes) hole(f.x - cl, f.y - ct, f.r * (f.life / f.max) * 1.4, 1);
      for (const b of this.shots) if (b.kind !== "bullet") hole(b.x - cl, b.y - ct, b.kind === "flame" ? 20 : b.kind === "laser" ? 22 : 30, 0.6);
      for (const s of this.scorch) hole(s.x - cl, s.y - ct, 10, s.life / 1.4);
      for (let i = 0; i < this.parts.length; i += 3) { const p = this.parts[i]; if (p.kind === 5) hole(p.x - cl, p.y - ct, 12, 0.5); }
      dg.globalAlpha = 1;
      dg.globalCompositeOperation = "source-over";
      ctx.drawImage(this.dark, 0, 0);
      ctx.globalCompositeOperation = "lighter";
      for (const l of this.map.lights) {
        const x = l.x - cl, y = l.y - ct, r = l.r * (1 + l.pulse * Math.sin(t * 2.2 + l.x * 0.05));
        if (x < -r || x > W + r || y < -r || y > H + r) continue;
        ctx.globalAlpha = 0.17;
        ctx.drawImage(this.glowCol(l.col), x - r * 0.7, y - r * 0.7, r * 1.4, r * 1.4);
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
    ctx.globalCompositeOperation = "lighter";
    for (const f of this.flashes) {
      const k = f.life / f.max, r = f.r * (0.6 + 0.4 * k);
      ctx.globalAlpha = 0.55 * k;
      ctx.drawImage(this.glowCol(f.col), f.x - cl - r, f.y - ct - r, r * 2, r * 2);
    }
    for (const s of this.sol) if (s.alive && s.jetK > 0.2) {
      const r = 16 + s.burst * 60;
      ctx.globalAlpha = 0.45 * s.jetK; ctx.drawImage(this.glowCol("#ff9a3c"), s.x - s.face * 8 - cl - r, s.y + 5 - ct - r, r * 2, r * 2);
      ctx.globalAlpha = 0.5 * s.jetK; ctx.drawImage(this.glowCol("#fff2c0"), s.x - s.face * 8 - cl - 5, s.y + 2 - ct - 5, 10, 10);
    }
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  /** what burns bright, drawn over the dark: tracers, blaster bolts, lightsabers, embers, scorch marks, impact flashes */
  private glowPass() {
    const ctx = this.ctx, cl = this.cl, ct = this.ct, W = this.W, H = this.H;
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.lineCap = "round";
    const seg = (x0: number, y0: number, x1: number, y1: number, w: number, col: string, a: number) => { ctx.strokeStyle = col; ctx.globalAlpha = a; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); };
    for (const b of this.shots) {
      if (b.kind !== "bullet" && b.kind !== "laser") continue;
      const x = b.x - cl, y = b.y - ct;
      if (x < -60 || x > W + 60 || y < -60 || y > H + 60) continue;
      const sp = Math.hypot(b.vx, b.vy) || 1, dx = b.vx / sp, dy = b.vy / sp;
      if (b.kind === "bullet") {
        // a hot tracer in the shooter's colour, with a white core and a white-hot head
        const wd = AWEP[b.w], L = Math.min(wd.id === "sniper" ? 26 : 14, b.dist + 2);
        seg(x - dx * L, y - dy * L, x, y, wd.id === "sniper" || wd.id === "magnum" ? 3 : 2, TEAMS[b.by.team].bullet, 0.45);
        seg(x - dx * L * 0.55, y - dy * L * 0.55, x, y, 1, "#fff8dc", 1);
        ctx.globalAlpha = 1; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 2, 2);
      } else {
        // a blaster bolt: a long glowing streak in the team's colour around a white core
        const B = BEAM[b.by.team], L = Math.min(12, b.dist + 3);
        seg(x - dx * L, y - dy * L, x, y, 6, B.col, 0.16);
        seg(x - dx * L, y - dy * L, x, y, 3.2, B.col, 0.6);
        seg(x - dx * L * 0.85, y - dy * L * 0.85, x, y, 1.6, B.hot, 0.95);
        seg(x - dx * L * 0.7, y - dy * L * 0.7, x, y, 0.8, "#ffffff", 1);
        ctx.globalAlpha = 0.3; ctx.drawImage(this.glowCol(B.col), x - 10, y - 10, 20, 20);
      }
    }
    this.blades();
    for (const p of this.parts) {
      if (p.kind !== 5) continue;
      const x = p.x - cl, y = p.y - ct;
      if (x < -10 || x > W + 10 || y < -10 || y > H + 10) continue;
      ctx.globalAlpha = Math.min(1, (p.life / p.max) * 1.5);
      ctx.fillStyle = p.col;
      ctx.fillRect(Math.round(x), Math.round(y), p.size, p.size);
    }
    for (const s of this.scorch) {
      const k = s.life / 1.4, x = s.x - cl, y = s.y - ct;
      ctx.globalAlpha = k * 0.75; ctx.drawImage(this.glowCol(s.col), x - 6, y - 6, 12, 12);
      if (k > 0.6) { ctx.globalAlpha = (k - 0.6) * 2.5; ctx.fillStyle = "#ffffff"; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); }
    }
    for (const h of this.hitfx) {
      // impact flashes: a diamond of white light and rays, burnt onto the picture
      const k = h.life / h.max, x = h.x - cl, y = h.y - ct, r = h.r * (0.55 + 0.75 * k), n = h.kind === 1 ? 8 : h.kind === 2 ? 5 : 4;
      ctx.globalAlpha = 1 - k;
      ctx.fillStyle = "#ffffff";
      ctx.beginPath(); ctx.moveTo(x - r * 0.45, y); ctx.lineTo(x, y - r * 0.45); ctx.lineTo(x + r * 0.45, y); ctx.lineTo(x, y + r * 0.45); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = h.kind === 2 ? h.col || "#8af0ff" : h.kind === 1 ? "#ffe45c" : "#ffd27a";
      ctx.lineWidth = h.kind === 1 ? 2 : 1;
      ctx.beginPath();
      for (let i = 0; i < n; i++) {
        const a = h.ang + (i * PI2) / n, L = r * (h.kind === 2 ? 2.2 : i % 2 ? 1 : 1.8);
        ctx.moveTo(x + Math.cos(a) * r * 0.3, y + Math.sin(a) * r * 0.3);
        ctx.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L);
      }
      ctx.stroke();
    }
    for (const r of this.rings) {
      const p = r.life / r.max;
      ctx.globalAlpha = 1 - p;
      ctx.strokeStyle = p < 0.35 ? "#ffffff" : r.col;
      ctx.lineWidth = Math.max(1, (r.r > 20 ? 3 : 2) - p * 2);
      ctx.beginPath();
      ctx.arc(r.x - cl, r.y - ct, r.r * (0.2 + p * 0.9), 0, PI2);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
    for (const s of this.stars) {
      // a little white cross of light
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct, n = s.life > 0.04 ? 4 : 2;
      ctx.fillStyle = s.col;
      ctx.fillRect(x - n, y, n * 2 + 1, 1);
      ctx.fillRect(x, y - n, 1, n * 2 + 1);
      ctx.fillRect(x - 1, y - 1, 3, 3);
    }
    ctx.restore();
  }

  /** lightsabers: a fan of fading light behind every swing, then the blade - a wide soft glow, a coloured body, a white-hot core */
  private blades() {
    const ctx = this.ctx;
    for (const s of this.sol) {
      if (!s.alive || s.saberOn <= 0 || !s.tip) continue;
      const B = BEAM[s.team], [hx, hy, a, u] = s.tip, L = SABER_L * s.saberOn * (0.97 + 0.03 * Math.sin(this.t * 60 + s.id));
      const x0 = hx + Math.cos(a) * u, y0 = hy + Math.sin(a) * u, x1 = hx + Math.cos(a) * (u + L), y1 = hy + Math.sin(a) * (u + L);
      const tr = s.trail, r0 = u, r1 = u + L;
      for (let i = 0; i < tr.length - 1; i++) {
        const a0 = tr[i], a1 = tr[i + 1];
        if (Math.abs(angDiff(a0, a1)) < 0.03) continue;
        const k = 1 - i / tr.length;
        ctx.globalAlpha = 0.34 * k;
        ctx.fillStyle = B.col;
        ctx.beginPath();
        ctx.moveTo(hx + Math.cos(a0) * r0, hy + Math.sin(a0) * r0); ctx.lineTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1);
        ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.lineTo(hx + Math.cos(a1) * r0, hy + Math.sin(a1) * r0);
        ctx.closePath();
        ctx.fill();
        ctx.globalAlpha = 0.55 * k;
        ctx.strokeStyle = B.hot;
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(hx + Math.cos(a0) * r1, hy + Math.sin(a0) * r1); ctx.lineTo(hx + Math.cos(a1) * r1, hy + Math.sin(a1) * r1); ctx.stroke();
      }
      const line = (w: number, col: string, al: number) => { ctx.strokeStyle = col; ctx.globalAlpha = al; ctx.lineWidth = w; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke(); };
      line(13, B.col, 0.07); line(9, B.col, 0.13); line(5.5, B.col, 0.3); line(3.2, B.col, 0.75); line(1.8, B.hot, 0.95); line(0.9, "#ffffff", 1);
      const g = this.glowCol(B.col);
      ctx.globalAlpha = 0.3; ctx.drawImage(g, (x0 + x1) / 2 - 36, (y0 + y1) / 2 - 36, 72, 72);
      ctx.globalAlpha = 0.6; ctx.drawImage(g, x0 - 5, y0 - 5, 10, 10);
      ctx.globalAlpha = 0.5; ctx.drawImage(this.glowCol(B.hot), x1 - 3, y1 - 3, 6, 6);
    }
    ctx.globalAlpha = 1;
  }

  /** sand blowing through in a storm, the rain of the ruined city, spores drifting in the cave */
  private weather() {
    const ctx = this.ctx, T = this.map.theme, W = this.W, H = this.H, cl = this.cl, ct = this.ct;
    if (T.rain) {
      ctx.strokeStyle = "rgba(180,196,236,0.42)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < this.rain.length; i += 2) {
        const x = ((((this.rain[i] - cl * 0.6) % (W + 40)) + W + 40) % (W + 40)) - 20, y = ((((this.rain[i + 1] - ct * 0.6) % (H + 40)) + H + 40) % (H + 40)) - 20;
        ctx.moveTo(x, y); ctx.lineTo(x - 2, y + 7);
      }
      ctx.stroke();
    }
    if (T.weather === "sand") {
      const g = this.gust, blob = blobSpr();
      ctx.fillStyle = `rgba(226,170,104,${(0.04 + g * 0.1).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
      for (let i = 0; i < this.dust.length; i += 4) {
        const span = W + 300, x = ((((this.dust[i] - cl * 0.7) % span) + span) % span) - 150, y = ((((this.dust[i + 1] - ct * 0.5) % (H + 120)) + H + 120) % (H + 120)) - 60, s = this.dust[i + 2];
        ctx.globalAlpha = 0.1 + g * 0.24;
        ctx.drawImage(blob, x - s, y - s * 0.55, s * 2, s * 1.1);
      }
      ctx.globalAlpha = 1;
      ctx.strokeStyle = `rgba(255,228,176,${(0.35 + g * 0.35).toFixed(3)})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (let i = 0; i < this.sand.length; i += 4) {
        const x = ((((this.sand[i] - cl) % (W + 60)) + W + 60) % (W + 60)) - 30, y = ((((this.sand[i + 1] - ct) % (H + 40)) + H + 40) % (H + 40)) - 20, L = this.sand[i + 3] * (0.6 + g);
        ctx.moveTo(x, y); ctx.lineTo(x - L, y - L * 0.1);
      }
      ctx.stroke();
    } else if (T.weather === "spores") {
      const cols = ["#7dff9a", "#5ff0e0", "#d07aff"];
      ctx.globalCompositeOperation = "lighter";
      for (let i = 0; i < this.spores.length; i += 4) {
        const x = ((((this.spores[i] - cl * 0.9) % (W + 40)) + W + 40) % (W + 40)) - 20, y = ((((this.spores[i + 1] - ct * 0.9) % (H + 40)) + H + 40) % (H + 40)) - 20;
        const fl = 0.4 + 0.6 * Math.abs(Math.sin(this.t * 2 + this.spores[i + 2]));
        ctx.fillStyle = cols[this.spores[i + 3]];
        ctx.globalAlpha = fl * 0.85;
        ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
        if (fl > 0.85) { ctx.globalAlpha = 0.22; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); }
      }
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = "source-over";
    }
  }

  private drawMini() {
    const ctx = this.ctx, m = this.mini, x0 = 5, y0 = this.H - m.height - 5, me = this.me;
    ctx.globalAlpha = 0.88;
    this.R("#0a0a0f", x0 - 1, y0 - 1, m.width + 2, m.height + 2);
    ctx.drawImage(m, x0, y0);
    ctx.globalAlpha = 1;
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x0 + Math.round(this.cl / 16) + 0.5, y0 + Math.round(this.ct / 16) + 0.5, Math.round(this.W / 16), Math.round(this.H / 16));
    for (const p of this.picks) if (p.kind === "saber" && !(p.spot && p.t > 0) && Math.sin(this.t * 6) > 0) this.R("#9ae8ff", x0 + Math.floor(p.x / 16), y0 + Math.floor(p.y / 16) - 1, 1, 1);
    for (const s of this.sol) {
      if (!s.alive || s.me) continue;
      if (s.team !== me.team && s.loud <= 0 && s.saberOn <= 0) continue;
      this.R(s.team === me.team ? TEAMS[s.team].color : "#ff4d5e", x0 + Math.floor(s.x / 16) - 1, y0 + Math.floor((s.y - 9) / 16) - 1, 2, 2);
    }
    if (me.alive && Math.sin(this.t * 8) > -0.4) this.R("#ffffff", x0 + Math.floor(me.x / 16) - 1, y0 + Math.floor((me.y - 9) / 16) - 1, 3, 3);
  }

  // ───────────── a soldier ─────────────
  private drawSol(s: Sol) {
    const ctx = this.ctx, X0 = Math.round(s.x) - this.cl, Y0 = Math.round(s.y) - this.ct;
    if (X0 < -40 || X0 > this.W + 40 || Y0 < -50 || Y0 > this.H + 50) { s.tip = null; return; }
    if (!s.alive) {
      s.tip = null;
      ctx.globalAlpha = s.respawn < 0.6 ? Math.max(0, s.respawn / 0.6) : 1;
      ctx.save();
      ctx.translate(X0, Y0 - 8);
      ctx.rotate(s.rot);
      ctx.translate(0, 8);
      ctx.scale(s.face, 1);
      this.body(s, 0, 0, false, true);
      ctx.restore();
      ctx.globalAlpha = 1;
      return;
    }
    // the gait: every body moves its own way - a bouncy jog, a heavy stomp, a low prowl, an easy swagger
    const moving = s.ground && Math.abs(s.vx) > 12, step = moving ? Math.sin(s.walkT * 22) : 0;
    let bob = moving ? (Math.abs(step) > 0.55 ? 1 : 0) : Math.sin(this.t * 2.6 + s.id) > 0.55 ? 1 : 0;
    let rot = s.tilt, hop = 0, lx = 0, ly = 0, sx = 1, sy = 1;
    if (moving) {
      const ph = s.walkT * 22, air = Math.abs(Math.sin(ph)), gait = s.id % 4, rk = s.runK, dir = s.vx >= 0 ? 1 : -1;
      hop += air * (1 + rk * 1.3);
      rot += dir * (0.05 + 0.08 * rk);
      sy *= 1 + 0.06 * air * rk;
      sx *= 1 - 0.04 * air * rk;
      if (gait === 1) { ly += (1 - air) * 0.8; sx *= 1 + 0.04 * (1 - air); rot += Math.sin(ph) * 0.04; }
      else if (gait === 2) { ly += 0.6; sy *= 0.96; }
      else if (gait === 3) rot += Math.sin(ph) * 0.04;
    } else if (!s.ground) {
      rot += clamp(s.vx / AIRSPD, -1, 1) * 0.22;
      if (s.jet) { sy *= 1.05; sx *= 0.96; }
      bob = 0;
    } else {
      // standing: breathing, and now and then a stretch up on the toes
      sy *= 1 + Math.sin(this.t * 2.6 + s.id) * 0.018;
      const idle = (this.t * 0.31 + s.id * 0.77) % 6;
      if (idle < 0.5) { const k = Math.sin((idle / 0.5) * Math.PI); sy *= 1 + 0.06 * k; hop += k * 1.1; }
    }
    if (s.squash > 0) { const k = Math.min(1, s.squash / 0.14); sy *= 1 - 0.24 * k; sx *= 1 + 0.2 * k; }
    if (s.burst > 0.1) { sy *= 1.1; sx *= 0.93; }
    lx -= Math.cos(s.aim) * s.recoil * 1.4;
    ly -= Math.sin(s.aim) * s.recoil * 0.9;
    if (s.swingT > 0) { const p = 1 - s.swingT / s.swingDur; lx += s.face * 2.5 * Math.sin(p * Math.PI); rot += s.face * 0.12 * Math.sin(p * Math.PI) * (s.swingKind === 1 ? -1 : 1); }
    if (s.ground) this.R("rgba(0,0,0,0.28)", X0 - 5, Y0 - 1, 10, 2);
    this.scarfDraw(s);
    const X = X0 + Math.round(lx), Y = Y0 - Math.round(hop) + Math.round(ly), white = s.flash > 0;
    ctx.save();
    ctx.translate(X, Y);
    if (rot) ctx.rotate(rot);
    ctx.scale(s.face * sx, sy);
    this.body(s, bob, step, white, false);
    ctx.restore();
    this.gun(s, X, Y, white);
    if (s.shield > 0) {
      ctx.strokeStyle = TEAMS[s.team].color;
      ctx.globalAlpha = 0.35 + 0.3 * Math.sin(this.t * 12);
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(X0 + 0.5, Y0 - 9.5, 14, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
    }
  }

  /** the scarf: links that trail out behind the neck - a ribbon of dark squares with colour on top */
  private scarfDraw(s: Sol) {
    const P = opPal(s.team, s.skin);
    if (!P.scarf) return;
    const ctx = this.ctx, sc = s.scarf, pts: number[] = [];
    let qx = s.x - s.face * 3, qy = s.y - 11;
    for (let i = 0; i < 6; i += 2) {
      for (let k = 1; k <= 3; k++) pts.push(Math.round(qx + ((sc[i] - qx) * k) / 3) - this.cl, Math.round(qy + ((sc[i + 1] - qy) * k) / 3) - this.ct);
      qx = sc[i]; qy = sc[i + 1];
    }
    ctx.fillStyle = "#0a0a0f";
    for (let i = 0; i < pts.length; i += 2) ctx.fillRect(pts[i] - 2, pts[i + 1] - 2, 4, 4);
    for (let i = pts.length - 2; i >= 0; i -= 2) { ctx.fillStyle = i >= 12 ? P.scarf2 : P.scarf; ctx.fillRect(pts[i] - 1, pts[i + 1] - 1, 2, 2); }
  }

  /** the body in a frame whose origin is the feet (already flipped to face the aim): jetpack, legs, torso, head, face */
  private body(s: Sol, bob: number, step: number, white: boolean, dead: boolean) {
    const ctx = this.ctx, P = opPal(s.team, s.skin);
    const R = (c: string, x: number, y: number, w: number, h: number) => { ctx.fillStyle = white ? "#ffffff" : c; ctx.fillRect(x, y, w, h); };
    // the jetpack on the back
    R(P.K, -11, -12 + bob, 6, 10); R("#5d6474", -10, -11 + bob, 4, 8); R("#8e97aa", -10, -11 + bob, 1, 7); R(P.accent, -9, -8 + bob, 2, 2); R("#2a2e38", -10, -4 + bob, 4, 1);
    R(P.K, -10, -2 + bob, 4, 2); R("#3a3f4a", -9, -2 + bob, 2, 1);
    if (!dead && s.jetK > 0.05) this.flame(s, -8, bob);
    // legs: a stride when walking, tucked under while flying, apart when falling
    const run = s.runK, lx = Math.round(step * (1.5 + 1.3 * run)), lift = run > 0.4 ? 2 : 1;
    let l1x = -3 + lx, l2x = 1 - lx, l1y = step > 0.4 ? -lift : 0, l2y = step < -0.4 ? -lift : 0;
    if (dead) { l1x = -3; l2x = 1; l1y = l2y = 0; }
    else if (!s.ground) { if (s.jet) { l1x = -2; l2x = 0; l1y = -1; l2y = 0; } else { l1x = -4; l2x = 2; l1y = 0; l2y = -1; } }
    R(P.legs, l1x, -3 + l1y, 2, 3); R(P.legs, l2x, -3 + l2y, 2, 3);
    R(P.boots, l1x, -1 + l1y, 2, 1); R(P.boots, l2x, -1 + l2y, 2, 1);
    ctx.drawImage(opTorso(s.team, s.skin, white), -7, -9 + bob);
    // the head leads the body: it snaps back with the recoil, dips over a reload and ducks when hurt
    if (!s.headless) {
      const hx = s.recoil > 0.5 ? -1 : 0, hy = -19 + bob + (s.reload > 0 ? 1 : 0) + (s.ouch > 0.2 ? 1 : 0);
      ctx.drawImage(opHead(s.team, s.skin, white), -7 + hx, hy);
      if (!white) this.face(s, -7 + hx, hy, dead);
    } else { R("#7a1420", -2, -10 + bob, 4, 2); R("#d04a4a", -1, -10 + bob, 2, 1); }
  }

  /** the jet: a flickering cone of fire out of the nozzle - white at the root, then yellow, then orange - huge for a moment as it lights */
  private flame(s: Sol, nx: number, bob: number) {
    const ctx = this.ctx, fl = Math.sin(this.t * 47 + s.id * 3) * 0.5 + 0.5, sput = s.fuel < 0.16 && Math.sin(this.t * 31 + s.id) < 0 ? 0.35 : 1;
    const L = Math.round((8 + fl * 4 + s.burst * 30) * s.jetK * sput);
    const y0 = bob, big = s.burst > 0.05;
    for (let i = 0; i < L; i++) {
      const q = i / L, w = Math.max(1, Math.round((big ? 7 : 5) * (1 - q * 0.8))), wob = q > 0.5 && Math.sin(this.t * 60 + i + s.id) > 0.6 ? 1 : 0;
      ctx.fillStyle = q < 0.65 ? "#ff5a1e" : "#b8361a";
      ctx.fillRect(nx - (w >> 1) + wob, y0 + i, w, 1);
      if (w > 2) { ctx.fillStyle = q < 0.5 ? "#ffc23a" : "#ff9a2a"; ctx.fillRect(nx - ((w - 2) >> 1) + wob, y0 + i, w - 2, 1); }
      if (w > 4) { ctx.fillStyle = "#ffe98a"; ctx.fillRect(nx - ((w - 4) >> 1), y0 + i, w - 4, 1); }
      if (q < 0.4) { ctx.fillStyle = "#fffaf0"; ctx.fillRect(nx, y0 + i, 1, 1); }
    }
    // shock diamonds: little white-hot knots strung down the core of the jet
    if (L > 6) for (const k of [0.22, 0.44, 0.66]) if (Math.sin(this.t * 38 + k * 20 + s.id) > -0.2) { ctx.fillStyle = "#ffffff"; ctx.fillRect(nx - 1, y0 + Math.round(L * k), 2, 1); ctx.fillRect(nx, y0 + Math.round(L * k) - 1, 1, 3); }
  }

  /**
   * Faces: eyes shut when hurt, narrowed when firing, wide when nearly dead, squeezed into a grin after a kill,
   * spinning when dizzy, X'd out when dead - and on visors, skulls and trooper lenses, the light does it instead.
   */
  private face(s: Sol, ox: number, oy: number, dead: boolean) {
    const E = EYES[s.skin] ?? EYES[0], P = opPal(s.team, s.skin), ctx = this.ctx, t = this.t, dark = "#1a1014";
    const Px = (c: string, x: number, y: number, w = 1, h = 1) => { ctx.fillStyle = c; ctx.fillRect(ox + x, oy + y, w, h); };
    // 7 dead, 1 hurt, 8 dizzy, 4 happy, 2 effort, 3 scared, 6 angry
    const mood = dead ? 7 : s.ouch > 0 ? 1 : s.dizzy > 0 ? 8 : s.joy > 0.3 ? 4 : s.recoil > 0.25 || s.swingT > 0 ? 2 : s.hp < 35 ? 3 : s.mad > 0 ? 6 : 0;
    const blink = mood === 0 && (t * 0.6 + s.id * 0.37) % 1 > 0.955;
    E.e.forEach((e, idx) => {
      const ex = e[0], ey = e[1], ew = e[2] ?? 2;
      if (E.kind === 0) {
        if (mood === 7) { Px(P.lid, ex, ey, 2, 1); Px(dark, ex - 1, ey - 1); Px(dark, ex + 1, ey - 1); Px(dark, ex, ey); Px(dark, ex - 1, ey + 1); Px(dark, ex + 1, ey + 1); }
        else if (mood === 1 || blink) { Px(P.lid, ex, ey, 2, 1); Px(dark, ex, ey, 2, 1); if (mood === 1) Px(dark, idx ? ex : ex + 1, ey - 1); }
        else if (mood === 4) { Px(P.lid, ex, ey, 2, 1); Px(dark, idx ? ex : ex + 1, ey - 1); Px(dark, idx ? ex + 1 : ex, ey); }
        else if (mood === 2 || mood === 6) { Px(P.lid, ex, ey); Px(dark, idx ? ex + 1 : ex - 1, ey - 1); Px(dark, ex, ey - 1); }
        else if (mood === 3) { Px("#ffffff", ex, ey, 2, 1); Px(dark, ex + (Math.sin(t * 20 + s.id) > 0 ? 1 : 0), ey); }
        else if (mood === 8) { Px("#ffffff", ex, ey, 2, 1); Px(dark, ex + (((t * 12) | 0) % 2), ey); }
      } else if (E.kind === 1) {
        if (mood === 7 || blink) Px(P.lid, ex, ey, ew, 1);
        else if (mood === 1) Px(Math.sin(t * 50) > 0 ? P.lid : "#ff6b6b", ex, ey, ew, 1);
        else if (mood === 4) { Px(P.lid, ex, ey, ew, 1); Px(P.glow, ex, ey - 1, ew, 1); }
        else if (mood === 2 || mood === 6) { Px("#ffffff", ex, ey, ew, 1); Px(P.accent, idx === 0 ? ex : ex + ew - 1, ey); }
        else if (mood === 3) { Px(P.lid, ex, ey, ew, 1); Px("#ffffff", ex + (ew >> 1), ey); }
        else if (mood === 8) { Px(P.lid, ex, ey, ew, 1); Px(P.glow, ex + (((t * 10) | 0) % ew), ey); }
      } else if (E.kind === 2) {
        if (mood === 7) { Px(P.skull, ex, ey); Px(P.skull, ex + 1, ey + 1); }
        else if (mood === 1) Px("#ff3a4a", ex, ey, 2, 2);
        else if (mood === 4) Px(P.skull, ex, ey + 1, 2, 1);
        else if (mood === 2 || mood === 6) Px(P.accent, idx ? ex : ex + 1, ey + 1);
        else if (mood === 3) Px("#ffffff", ex + 1, ey);
        else if (mood === 8) Px(P.accent, ex + (((t * 10) | 0) % 2), ey + (((t * 10 + 1) | 0) % 2));
      } else {
        if (mood === 7) { Px("#ffffff", ex + 2, ey); Px("#ffffff", ex + 1, ey + 1); Px("#ffffff", ex, ey + 2); }
        else if (mood === 1) Px("#ffffff", ex, ey, 3, 1);
        else if (mood === 2 || mood === 6) Px(P.accent, ex, ey + 1, 3, 1);
        else if (mood === 4) Px("#9fb4cc", ex, ey, 3, 1);
        else if (mood === 3) Px("#ffffff", ex + 1, ey + 1);
        else Px("#3c4860", ex + 1, ey);
      }
    });
    if (mood === 3 && !dead) {
      // a drop of sweat runs down the temple
      const k = (t * 1.6 + s.id * 0.3) % 1;
      Px("#8fd0ff", 12, 2 + Math.round(k * 5), 1, 2);
      Px("#ffffff", 12, 2 + Math.round(k * 5));
    }
  }

  /** the weapon in the hands - the survivors' way: recoil and muzzle climb, a reload you can see, the support hand, a star of fire at the muzzle */
  private gun(s: Sol, X: number, Y: number, white: boolean) {
    const sl = s.slots[s.cur];
    if (!sl) return;
    const ctx = this.ctx, w = AWEP[sl.id], W = wspr(s.team, sl.id), img = white ? W.w : W.c, P = opPal(s.team, s.skin);
    const left = Math.cos(s.aim) < 0, sgn = left ? -1 : 1, saber = w.kind === "saber", small = sl.id === "pistol" || sl.id === "magnum";
    let ang = s.aim, ext = 0, magX = 0, magY = 0, magK = 0;
    let rc = Math.round(s.recoil * (w.kind === "rocket" ? 7 : sl.id === "sniper" ? 6 : sl.id === "shotgun" ? 7 : sl.id === "magnum" ? 5 : 3));
    if (saber) {
      ang = this.bladeAng(s);
      ext = s.swingT > 0 ? 2 + 5 * Math.sin((1 - s.swingT / s.swingDur) * Math.PI) : 2;
      rc = 0;
    } else if (s.reload > 0) {
      const p = 1 - s.reload / s.reloadMax, k = p < 0.15 ? p / 0.15 : p > 0.85 ? (1 - p) / 0.15 : 1;
      ang += sgn * (small ? -0.6 : 0.7) * k;
      if (sl.id === "magnum" && p > 0.86) ang += ((p - 0.86) / 0.14) * PI2 * sgn;
      if (sl.id === "shotgun") { if (p < 0.9) { magX = 6; magY = 3 + (1 - Math.min(1, ((p * 6.6) % 1) * 2.4)) * 5; magK = 1; } else rc += Math.round(3 * Math.sin(((p - 0.9) / 0.1) * Math.PI)); }
      else if (w.kind === "rocket") { if (p > 0.2 && p < 0.75) { magX = -4 - (1 - Math.min(1, (p - 0.2) / 0.4)) * 10; magY = -2; magK = 2; } }
      else {
        if (p > 0.3 && p < 0.72) { magX = sl.id === "rifle" ? 6 : sl.id === "e11" ? 7 : sl.id === "sniper" ? 5 : 1; magY = 3 + (1 - Math.min(1, (p - 0.3) / 0.3)) * 7; magK = sl.id === "rifle" ? 4 : sl.id === "e11" ? 5 : 3; }
        if (p > 0.72 && p < 0.8) rc -= 1;
        if (p > 0.86) rc += Math.round(3 * Math.sin(((p - 0.86) / 0.14) * Math.PI));
      }
    } else ang -= sgn * s.recoil * (small ? 0.5 : sl.id === "shotgun" ? 0.34 : 0.22);
    const px = X + Math.round(Math.cos(s.aim) * 2), py = Y - 5;
    ctx.save();
    ctx.translate(px, py);
    ctx.rotate(ang);
    if (saber) {
      // the arm reaches out to the hilt: the blade never floats away from the body
      const al = Math.round(ext) + 1;
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-1, -2, al + 2, 4);
      ctx.fillStyle = white ? "#ffffff" : P.arm; ctx.fillRect(0, -1, al, 2);
      ctx.translate(Math.round(ext), 0);
      s.tip = [px, py, ang, Math.round(ext) + W.c.width - W.px + 2];
    }
    if (left) ctx.scale(1, -1);
    ctx.drawImage(img, -W.px + 2 - rc, -W.py);
    const hand = white ? "#ffffff" : P.hand;
    ctx.fillStyle = "#0a0a0f"; ctx.fillRect(-rc, -1, 4, 4);
    ctx.fillStyle = hand; ctx.fillRect(1 - rc, 0, 2, 2);
    if (saber) { ctx.fillStyle = "#0a0a0f"; ctx.fillRect(3, -1, 4, 4); ctx.fillStyle = hand; ctx.fillRect(4, 0, 2, 2); }
    if (magK) {
      const mx = Math.round(magX) - rc, my = Math.round(magY), hy = magK === 2 || magK === 1 ? 2 : 4;
      ctx.fillStyle = "#0a0a0f";
      if (magK === 1) { ctx.fillRect(mx - 1, my - 1, 5, 4); ctx.fillStyle = "#e0524a"; ctx.fillRect(mx, my, 3, 2); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 1, 2); }
      else if (magK === 2) { ctx.fillRect(mx - 1, my - 1, 9, 5); ctx.fillStyle = "#566b3e"; ctx.fillRect(mx, my, 6, 3); ctx.fillStyle = "#e0483e"; ctx.fillRect(mx + 5, my, 2, 3); }
      else if (magK === 5) { ctx.fillRect(mx - 1, my - 1, 5, 7); ctx.fillStyle = "#2a2d38"; ctx.fillRect(mx, my, 3, 5); ctx.fillStyle = BEAM[s.team].col; ctx.fillRect(mx + 1, my + 1, 1, 3); }
      else { ctx.fillRect(mx - 1, my - 1, 5, 7); ctx.fillStyle = magK === 4 ? "#7a4a28" : "#3a3f4a"; ctx.fillRect(mx, my, 3, 5); ctx.fillStyle = "#f1cf6a"; ctx.fillRect(mx, my, 3, 1); }
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(mx - 1, my + hy, 4, 3);
      ctx.fillStyle = hand; ctx.fillRect(mx, my + hy, 2, 2);
    }
    if (!magK && !saber && !small) {
      const hx = s.reload > 0 ? 4 : 8 - (sl.id === "shotgun" && s.pump > 0 ? Math.round(Math.sin((1 - s.pump / 0.34) * Math.PI) * 3) : 0), hy = s.reload > 0 ? 1 : -1;
      ctx.fillStyle = "#0a0a0f"; ctx.fillRect(hx - rc, hy, 4, 3);
      ctx.fillStyle = hand; ctx.fillRect(hx + 1 - rc, hy, 2, 2);
    }
    if (w.kind === "flame" && !white) {
      // the pilot light
      const m = W.c.width - W.px + 2 - rc;
      ctx.fillStyle = Math.sin(this.t * 30 + s.id) > 0 ? "#5fb8ff" : "#9ad8ff";
      ctx.fillRect(m, W.bar, 1, 1);
    }
    if (s.flashT > 0 && !saber && w.kind !== "flame") {
      // muzzle flash: a different star every shot (in the team's light for a blaster)
      const m = W.c.width - W.px + 2 - rc, by = W.bar + 0.5, k = s.flashT / 0.06, sd = s.seed, laser = w.kind === "laser", B = BEAM[s.team];
      const L = (sl.id === "sniper" ? 22 : sl.id === "shotgun" ? 20 : w.kind === "rocket" || sl.id === "rifle" ? 13 : sl.id === "magnum" ? 15 : laser ? 11 : 9) * (0.75 + 0.5 * sd) * (0.45 + 0.55 * k);
      const Wd = (sl.id === "shotgun" ? 13 : sl.id === "sniper" ? 6 : w.kind === "rocket" ? 8 : 4.5) * (1.2 - 0.4 * sd);
      const star = (l: number, wd: number) => {
        ctx.beginPath();
        ctx.moveTo(m, by - wd * 0.3); ctx.lineTo(m + l * 0.3, by - wd); ctx.lineTo(m + l * 0.42, by - wd * 0.28); ctx.lineTo(m + l, by);
        ctx.lineTo(m + l * 0.42, by + wd * 0.28); ctx.lineTo(m + l * 0.3, by + wd); ctx.lineTo(m, by + wd * 0.3);
        ctx.closePath();
        ctx.fill();
      };
      ctx.fillStyle = laser ? B.col : "#ff9a3c"; star(L, Wd);
      ctx.fillStyle = laser ? B.hot : "#ffe45c"; star(L * 0.75, Wd * 0.7);
      ctx.fillStyle = "#ffffff"; star(L * 0.45, Wd * 0.4);
      if (w.kind === "rocket") { ctx.fillStyle = "#ffd75e"; ctx.fillRect(-W.px - 7 - rc, by - 3.5, 9, 7); }
    }
    ctx.restore();
  }

  /** over the head: "!" when they spot you, stars when dazed, sparkles after a kill, an angry vein, a panting breath, speed lines */
  private emotes(s: Sol, x: number, y: number) {
    const ctx = this.ctx, t = this.t;
    const P = (c: string, px: number, py: number, w = 1, h = 1) => this.R(c, px, py, w, h);
    const top = y - 38;
    if (s.alert > 0) { const b = Math.round(Math.abs(Math.sin(t * 14)) * 2); P("#0a0a0f", x - 2, top - 3 - b, 4, 9); P("#ffe45c", x - 1, top - 2 - b, 2, 4); P("#ffe45c", x - 1, top + 3 - b, 2, 2); }
    else if (s.dizzy > 0) for (let i = 0; i < 3; i++) { const a = t * 7 + i * 2.094; P(i ? "#ffe45c" : "#ffffff", x + Math.round(Math.cos(a) * 7), y - 21 + Math.round(Math.sin(a) * 2.5), 2, 2); }
    else if (s.joy > 0.3)
      for (let i = 0; i < 2; i++) {
        const k = (t * 2.2 + i * 0.5) % 1, sd = i ? 1 : -1;
        ctx.globalAlpha = 1 - k;
        P("#ffe45c", x + sd * (9 + Math.round(k * 4)), y - 16 - Math.round(k * 6), 2, 1);
        P("#ffe45c", x + sd * (10 + Math.round(k * 4)) - (sd > 0 ? 1 : 0), y - 17 - Math.round(k * 6), 1, 3);
        ctx.globalAlpha = 1;
      }
    if (s.mad > 0 && Math.sin(t * 14) > -0.3) { P("#ff3040", x + 5, y - 22, 1, 3); P("#ff3040", x + 4, y - 21, 3, 1); }
    if (s.hp < 30) { const k = (t * 1.5 + s.id * 0.37) % 1; ctx.globalAlpha = (1 - k) * 0.7; P("#ffffff", x + s.face * (7 + Math.round(k * 5)), y - 9 - Math.round(k * 3), 2 + Math.round(k * 2), 2); ctx.globalAlpha = 1; }
    if (!s.ground && Math.hypot(s.vx, s.vy) > 150) {
      ctx.globalAlpha = 0.45;
      const dir = s.vx >= 0 ? -1 : 1;
      for (let i = 0; i < 2; i++) { const k = (t * 5 + i * 0.5) % 1; P("#ffffff", x + dir * (8 + Math.round(k * 8)), y - 12 + i * 6, 4 - Math.round(k * 3), 1); }
      ctx.globalAlpha = 1;
    }
  }
}

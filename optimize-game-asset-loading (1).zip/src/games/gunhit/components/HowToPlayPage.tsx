import { useEffect, useState, type CSSProperties } from 'react';
import { t, tList } from '../../../i18n/catalog';
import { useLanguage } from '../../../i18n/useLanguage';

type Props = {
  onClose: () => void;
  /** First run gets the "new player" badge instead of the settings hint. */
  firstRun?: boolean;
};

const ICONS = ['🎯', '⬆️', '👆', '🏆'];
const ACCENTS = [
  'from-amber-400/20 to-amber-400/5 border-amber-300/40',
  'from-sky-400/20 to-sky-400/5 border-sky-300/40',
  'from-fuchsia-400/20 to-fuchsia-400/5 border-fuchsia-300/40',
  'from-emerald-400/20 to-emerald-400/5 border-emerald-300/40',
];

/** Compact 4-step coach card: goal, aim, shoot, win — with a live wheel demo. */
export default function HowToPlayPage({ onClose, firstRun = false }: Props) {
  const [language] = useLanguage();
  const titles = tList(language, 'help.stepTitles');
  const steps = tList(language, 'help.steps');
  const total = Math.min(4, steps.length);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault();
        onClose();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  // Slowly walk the highlight through all four steps so the popup teaches itself.
  useEffect(() => {
    if (total <= 1) return;
    const timer = window.setInterval(() => setActive((v) => (v + 1) % total), 1900);
    return () => window.clearInterval(timer);
  }, [total]);

  return (
    <div
      className="absolute inset-0 z-[80] flex items-center justify-center bg-[#05070d]/85 p-3 text-slate-100 backdrop-blur-md sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-label={t(language, 'help.title')}
    >
      <div className="tut-shell relative flex max-h-[94%] w-full max-w-[390px] flex-col overflow-hidden rounded-[26px] border border-white/15 bg-gradient-to-b from-[#161a2e] via-[#101323] to-[#0a0c16] shadow-[0_28px_80px_rgba(0,0,0,.75),0_0_0_1px_rgba(255,255,255,.05)">
        {/* animated top glow */}
        <div className="tut-glow pointer-events-none absolute -top-20 left-1/2 h-40 w-64 -translate-x-1/2 rounded-full bg-amber-400/25 blur-3xl" />

        <header className="relative z-10 flex shrink-0 items-start gap-3 border-b border-white/10 px-4 py-3">
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="rounded-full bg-amber-300 px-2 py-0.5 text-[9px] font-black tracking-[0.18em] text-[#1b1205]">4 LANGKAH</span>
              <span className="text-[10px] font-bold tracking-[0.14em] text-white/45">{t(language, 'help.subtitle')}</span>
            </div>
            <h2 className="mt-1 text-xl font-black leading-tight tracking-wide text-white">
              {t(language, 'help.title')}
            </h2>
            <p className="mt-0.5 text-[10px] font-semibold text-amber-200/80">
              {firstRun ? t(language, 'help.firstRun') : t(language, 'help.tip')}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label={t(language, 'common.close')}
            className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/15 bg-white/10 text-sm font-black text-white transition hover:bg-white/20 active:scale-95"
          >
            ✕
          </button>
        </header>

        {/* Live mini demo: spinning wheel + straight shot + tap ripple */}
        <div className="relative z-10 shrink-0 border-b border-white/10 bg-black/20 px-4 pt-2">
          <svg viewBox="0 0 320 158" className="mx-auto h-[126px] w-full" aria-hidden="true">
            <defs>
              <radialGradient id="tut-wheel-fill">
                <stop offset="0" stopColor="#fde68a" stopOpacity=".9" />
                <stop offset="1" stopColor="#f59e0b" stopOpacity=".25" />
              </radialGradient>
              <linearGradient id="tut-gun" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0" stopColor="#e2e8f0" />
                <stop offset="1" stopColor="#64748b" />
              </linearGradient>
            </defs>

            {/* soft aura */}
            <circle className="tut-glow" cx="160" cy="55" r="50" fill="#fbbf24" opacity=".16" />

            {/* counter-rotating dashed halo */}
            <g className="tut-wheel-rev">
              <circle cx="160" cy="55" r="50" fill="none" stroke="#fcd34d" strokeWidth="1" strokeDasharray="4 9" opacity=".55" />
            </g>

            {/* wheel */}
            <g className="tut-wheel">
              <circle cx="160" cy="55" r="40" fill="url(#tut-wheel-fill)" stroke="#fbbf24" strokeWidth="4" />
              <circle cx="160" cy="55" r="27" fill="none" stroke="#fff7d6" strokeWidth="2" strokeDasharray="3 7" opacity=".8" />
              {[0, 60, 120, 180, 240, 300].map((a) => {
                const r = (a * Math.PI) / 180;
                const x = 160 + Math.cos(r) * 40;
                const y = 55 + Math.sin(r) * 40;
                return <circle key={a} cx={x} cy={y} r="3.2" fill="#fff7d6" />;
              })}
              <path d="M160 20 L160 90 M125 55 L195 55" stroke="#fff7d6" strokeWidth="1.4" opacity=".65" />
              <circle cx="160" cy="55" r="5" fill="#fff" />
            </g>

            {/* aim guide */}
            <path className="tut-arrow" d="M160 104 L160 128" stroke="#7dd3fc" strokeWidth="2" strokeDasharray="4 5" strokeLinecap="round" fill="none" />

            {/* flying round */}
            <g transform="translate(160 134)">
              <g className="tut-bullet">
                <rect x="-3" y="-12" width="6" height="14" rx="2" fill="#ffffff" />
                <path d="M-3 -12 L0 -18 L3 -12 Z" fill="#fde68a" />
              </g>
            </g>

            {/* gun */}
            <g transform="translate(160 140)">
              <path d="M-20 8 L-8 8 L-8 -4 L10 -4 L10 2 L24 2 L24 8 Z" fill="url(#tut-gun)" stroke="#0f172a" strokeWidth="1.5" />
              <rect x="-3" y="-9" width="6" height="8" rx="1.5" fill="#fbbf24" />
              <circle className="tut-tap" cx="0" cy="4" r="12" fill="none" stroke="#fcd34d" strokeWidth="2.5" />
            </g>
          </svg>

          {/* 4-step progress */}
          <div className="mx-auto mb-2 flex w-full max-w-[260px] items-center gap-1.5">
            {Array.from({ length: total }, (_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActive(i)}
                aria-label={`${titles[i] ?? i + 1}`}
                className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${
                  i === active ? 'bg-amber-300 shadow-[0_0_10px_rgba(252,211,77,.8)' : 'bg-white/15 hover:bg-white/30'}
                `}
              />
            ))}
          </div>
          <div className="absolute bottom-2 left-0 h-[2px] w-full bg-white/5">
            <div className="tut-progress h-full w-full bg-gradient-to-r from-amber-300/0 via-amber-300/70 to-emerald-300/0" />
          </div>
        </div>

        {/* 4 concise cards */}
        <div className="relative z-10 min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-3">
          {steps.slice(0, total).map((step, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setActive(i)}
              className={`tut-card flex w-full items-start gap-3 rounded-2xl border bg-gradient-to-r p-2.5 text-left transition-transform duration-300 hover:scale-[1.015] ${ACCENTS[i % ACCENTS.length]} ${i === active ? 'is-active scale-[1.015] ring-1 ring-amber-200/50' : 'opacity-85'}
              `}
              style={{ animationDelay: `${i * 110}ms` } as CSSProperties}
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/15 bg-black/30 text-lg shadow-inner">
                {ICONS[i % ICONS.length]}
              </span>
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="text-[9px] font-black tracking-[0.16em] text-amber-200/90">
                    0{i + 1} · {titles[i] ?? ''}
                  </span>
                  {i === active && <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-emerald-300" />}
                </span>
                <span className="mt-0.5 block text-[11px] font-semibold leading-snug text-white/85">{step}</span>
              </span>
            </button>
          ))}
        </div>

        <footer className="relative z-10 shrink-0 border-t border-white/10 px-3 py-3">
          <p className="mb-2 text-center text-[10px] font-semibold text-sky-200/80">{t(language, 'help.tip')}</p>
          <button
            type="button"
            onClick={onClose}
            autoFocus
            className="w-full rounded-2xl border-2 border-emerald-300/50 bg-gradient-to-b from-emerald-400 to-emerald-600 py-2.5 text-[13px] font-black tracking-wide text-white shadow-[0_8px_24px_rgba(16,185,129,.3)] transition active:scale-[0.98] hover:brightness-110"
          >
            ▶ {t(language, 'help.start')}
          </button>
        </footer>
      </div>
    </div>
  );
}

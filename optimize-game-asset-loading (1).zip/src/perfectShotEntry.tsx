import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import './fonts.css';
import './index.css';
import './shell.css';
import './games/perfect-shot/index.css';
import PerfectShotApp from './PerfectShotApp';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <PerfectShotApp />
  </StrictMode>,
);

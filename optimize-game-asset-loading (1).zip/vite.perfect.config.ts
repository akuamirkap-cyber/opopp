import path from 'path';
import { fileURLToPath } from 'url';
import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/** Standalone single-file build of the original Perfect Shot screen. */
export default defineConfig({
  root: __dirname,
  base: './',
  publicDir: false,
  plugins: [react(), tailwindcss(), viteSingleFile()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },
  build: {
    outDir: path.resolve(__dirname, 'public/games/_perfect_tmp'),
    emptyOutDir: true,
    rollupOptions: {
      input: path.resolve(__dirname, 'perfect-shot.html'),
    },
  },
});

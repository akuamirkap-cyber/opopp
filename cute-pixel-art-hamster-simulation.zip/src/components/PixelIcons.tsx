import React from 'react';

interface IconProps {
  className?: string;
}

export const PixelHeartIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M3 2h3v1h1v1h2V3h1V2h3v1h1v1h1v4h-1v2h-1v1h-2v1h-1v1H9v1H7v-1H6v-1H4v-1H3v-1H2V8H1V4h1V3h1V2z" />
    <path fill="#FF6B93" d="M3 3h3v1h1v1h2V4h1V3h3v1h1v4h-1v2h-2v1H9v1H7v-1H5v-1H3V8H2V4h1V3z" />
    <rect x="3" y="4" width="2" height="2" fill="#FFC2D4" />
  </svg>
);

export const PixelSeedIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M7 2h3v1h2v2h1v4h-1v2h-1v1h-2v1H6v-1H4v-2H3V7h1V5h1V3h2V2z" />
    <path fill="#4F3C35" d="M7 3h3v1h1v1h1v4h-1v2H9v1H6v-1H4V7h1V5h2V3z" />
    <path fill="#EAE0D5" d="M8 3h1v8H8V3zM6 5h1v5H6V5zm4 1h1v4h-1V6z" />
  </svg>
);

export const PixelBerryIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M6 1h4v2h2v2h1v4h-1v3h-2v2H6v-2H4V9H3V5h1V3h2V1z" />
    <path fill="#6BD472" d="M6 2h4v1h1v2H5V3h1V2z" />
    <path fill="#FF5478" d="M4 5h8v4h-1v3H9v1H7v-1H5V9H4V5z" />
    <rect x="6" y="7" width="1" height="1" fill="#FFE8A3" />
    <rect x="9" y="8" width="1" height="1" fill="#FFE8A3" />
    <rect x="7" y="10" width="1" height="1" fill="#FFE8A3" />
  </svg>
);

export const PixelCornIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M5 2h6v1h1v6h-1v2h-1v2H6v-2H5V9H4V3h1V2z" />
    <path fill="#FFD54F" d="M5 3h6v5H5V3z" />
    <rect x="6" y="4" width="2" height="2" fill="#FFF3B0" />
    <path fill="#7AD474" d="M4 8h2v3h4V8h2v2h-1v3H5v-3H4V8z" />
  </svg>
);

export const PixelHandIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M6 2h2v4h1V2h2v4h1V3h2v7h-1v3h-2v1H6v-1H4v-2H3V7h2v2h1V2z" />
    <path fill="#FFD4BC" d="M6 3h1v5h2V3h1v5h2V4h1v6h-1v2h-1v1H6v-1H5v-2H4V8h2V3z" />
    <rect x="7" y="9" width="3" height="2" fill="#FF9CB2" />
  </svg>
);

export const PixelWheelIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M5 2h6v1h2v2h1v6h-1v2h-2v1H5v-1H3v-2H2V5h1V3h2V2z" />
    <path fill="#FFE0A3" d="M5 3h6v1h2v6h-1v2h-1v1H5v-1H4v-2H3V5h1V4h1V3z" />
    <rect x="5" y="5" width="6" height="6" fill="#FFF7E6" />
    <rect x="7" y="4" width="2" height="8" fill="#E0A96D" />
    <rect x="4" y="7" width="8" height="2" fill="#E0A96D" />
    <rect x="7" y="7" width="2" height="2" fill="#FF8FA8" />
  </svg>
);

export const PixelSparkleIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M7 1h2v4h4v2H9v4H7V7H3V5h4V1z" />
    <path fill="#FFE066" d="M7 2h2v4h3v1H9v4H7V7H4V6h3V2z" />
    <rect x="7" y="5" width="2" height="2" fill="#FFFFFF" />
    <rect x="12" y="10" width="2" height="2" fill="#FFE066" />
  </svg>
);

export const PixelCameraIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M5 3h6v1h3v8H2V4h3V3z" />
    <rect x="3" y="5" width="10" height="6" fill="#FFD1DC" />
    <rect x="6" y="4" width="4" height="1" fill="#FFD1DC" />
    <rect x="6" y="6" width="4" height="4" fill="#5A392C" />
    <rect x="7" y="7" width="2" height="2" fill="#9CE5FF" />
    <rect x="10" y="6" width="2" height="1" fill="#FFF7B2" />
  </svg>
);

export const PixelBowlIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <rect x="4" y="4" width="2" height="2" fill="#4F3C35" />
    <rect x="7" y="3" width="2" height="2" fill="#FFD54F" />
    <rect x="10" y="4" width="2" height="2" fill="#E6DDD5" />
    <path fill="#5A392C" d="M2 6h12v5h-1v2H3v-2H2V6z" />
    <rect x="3" y="7" width="10" height="4" fill="#FF9EBB" />
    <rect x="3" y="7" width="10" height="1" fill="#FFC9D9" />
  </svg>
);

export const PixelBoltIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M8 1h4v2h-2v3h3v3h-2v3H9v3H6v-4H4V8h2V5h2V1z" />
    <path fill="#FFE066" d="M8 2h2v4h2v2H9v4H7V8H5V6h3V2z" />
  </svg>
);

export const PixelMoonSunIcon: React.FC<{ night: boolean; className?: string }> = ({
  night,
  className = 'w-5 h-5',
}) =>
  night ? (
    <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
      <path fill="#5A392C" d="M6 2h5v2H9v2H8v4h2v2h2v2H6v-1H4v-2H3V6h1V4h2V2z" />
      <path fill="#FFE680" d="M6 3h3v2H7v5h2v2H6v-1H4V6h2V3z" />
    </svg>
  ) : (
    <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
      <rect x="7" y="1" width="2" height="2" fill="#FFAE42" />
      <rect x="7" y="13" width="2" height="2" fill="#FFAE42" />
      <rect x="1" y="7" width="2" height="2" fill="#FFAE42" />
      <rect x="13" y="7" width="2" height="2" fill="#FFAE42" />
      <rect x="4" y="4" width="8" height="8" fill="#5A392C" />
      <rect x="5" y="5" width="6" height="6" fill="#FFD95E" />
    </svg>
  );

export const PixelSoundIcon: React.FC<{ enabled: boolean; className?: string }> = ({
  enabled,
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M2 5h3l4-3h1v12H9l-4-3H2V5z" />
    <path fill="#FFE3B3" d="M3 6h2l3-2v8L5 10H3V6z" />
    {enabled ? (
      <>
        <rect x="11" y="5" width="1" height="6" fill="#5A392C" />
        <rect x="13" y="3" width="1" height="10" fill="#5A392C" />
      </>
    ) : (
      <>
        <rect x="11" y="5" width="2" height="2" fill="#FF6B8B" />
        <rect x="13" y="7" width="2" height="2" fill="#FF6B8B" />
        <rect x="11" y="9" width="2" height="2" fill="#FF6B8B" />
      </>
    )}
  </svg>
);

export const PixelRainIcon: React.FC<{ raining: boolean; className?: string }> = ({
  raining,
  className = 'w-5 h-5',
}) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path
      fill="#5A392C"
      d="M5 3h5v1h2v2h2v4h-1v1H3v-1H2V6h2V4h1V3z"
    />
    <path
      fill={raining ? '#B7CEE8' : '#FFFFFF'}
      d="M5 4h5v1h2v2h1v3H3V7h1V5h1V4z"
    />
    {raining && (
      <>
        <rect x="4" y="12" width="1" height="2" fill="#6EC1FF" />
        <rect x="8" y="11" width="1" height="2" fill="#6EC1FF" />
        <rect x="11" y="12" width="1" height="2" fill="#6EC1FF" />
      </>
    )}
  </svg>
);

export const PixelPlusHamIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M6 2h4v4h4v4h-4v4H6v-4H2V6h4V2z" />
    <path fill="#95E8B6" d="M7 3h2v4h4v2H9v4H7V9H3V7h4V3z" />
  </svg>
);

export const PixelChubbyIcon: React.FC<IconProps> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 16 16" className={className} shapeRendering="crispEdges">
    <path fill="#5A392C" d="M4 3h8v1h2v2h1v5h-1v2h-2v1H4v-1H2v-2H1V6h1V4h2V3z" />
    <path fill="#F9CE9C" d="M4 4h8v1h2v5h-1v2H3v-2H2V5h2V4z" />
    <rect x="5" y="9" width="6" height="3" fill="#FFF7EB" />
    <rect x="4" y="6" width="2" height="2" fill="#2E1B16" />
    <rect x="10" y="6" width="2" height="2" fill="#2E1B16" />
    <rect x="3" y="8" width="2" height="1" fill="#FF8FA8" />
    <rect x="11" y="8" width="2" height="1" fill="#FF8FA8" />
  </svg>
);

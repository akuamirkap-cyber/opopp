import React, { useEffect, useImperativeHandle, useRef } from 'react';
import { HAMSTER_COATS } from '../data/hamsterCoats';
import {
  applySquishImpulse,
  createInitialWorld,
  cycleChubbyMode,
  getSelectedHamster,
  SimWorld,
  spawnExtraHamster,
  spawnParticle,
  stepSimulation,
} from '../engine/hamsterAI';
import { drawHamster } from '../engine/hamsterRenderer';
import {
  drawParticles,
  drawTerrariumBack,
  drawTerrariumForeground,
  drawWheelSpokes,
  FLOOR_BOTTOM_Y,
  FLOOR_TOP_Y,
  PROP_POS,
  VIRTUAL_H,
  VIRTUAL_W,
} from '../engine/terrariumRenderer';
import {
  ChubbyLevel,
  HamsterEntity,
  HamsterState,
  HamsterStats,
  HamsterSummary,
  ToolMode,
} from '../types/hamster';
import { pixelSound } from '../utils/pixelSound';

export interface HudSnapshot {
  selectedId: number;
  selectedName: string;
  selectedCoatId: string;
  selectedChubby: ChubbyLevel;
  selectedState: HamsterState;
  selectedPouchCount: number;
  stats: HamsterStats;
  statusText: string;
  iglooStashCount: number;
  hamsters: HamsterSummary[];
}

export interface TerrariumHandle {
  dropTreat: (type: 'seed' | 'strawberry' | 'corn', x?: number, y?: number) => void;
  sendToWheel: () => void;
  sendToNap: () => void;
  refillBowlAndWater: () => void;
  cleanBedding: () => void;
  petNow: () => void;
  toggleChubby: () => void;
  spawnHamster: () => void;
  selectHamster: (id: number) => void;
  removeHamster: (id: number) => void;
  setSelectedCoat: (coatId: string) => void;
  setSelectedName: (name: string) => void;
  capturePng: () => string | null;
}

interface TerrariumCanvasProps {
  nightMode: boolean;
  rainMode: boolean;
  toolMode: ToolMode;
  onHudUpdate: (snapshot: HudSnapshot) => void;
}

export const TerrariumCanvas = React.forwardRef<TerrariumHandle, TerrariumCanvasProps>(
  ({ nightMode, rainMode, toolMode, onHudUpdate }, ref) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const worldRef = useRef<SimWorld>(
      createInitialWorld('Mochi', HAMSTER_COATS[0].id)
    );
    const toolRef = useRef<ToolMode>(toolMode);
    const isPointerDownRef = useRef(false);
    const lastPetTimeRef = useRef(0);
    const lastPointerXRef = useRef<number | null>(null);
    const pettingHamsterIdRef = useRef<number | null>(null);

    useEffect(() => {
      toolRef.current = toolMode;
    }, [toolMode]);

    useEffect(() => {
      worldRef.current.nightMode = nightMode;
    }, [nightMode]);

    useEffect(() => {
      worldRef.current.rainMode = rainMode;
      pixelSound.setRainAmbience(rainMode);
    }, [rainMode]);

    const pushHudNow = () => {
      const world = worldRef.current;
      const sel = getSelectedHamster(world);
      onHudUpdate({
        selectedId: sel.id,
        selectedName: sel.name,
        selectedCoatId: sel.coatId,
        selectedChubby: sel.chubbyLevel,
        selectedState: sel.state,
        selectedPouchCount: sel.storedPouch.length,
        stats: { ...sel.stats, cleanliness: world.cleanliness },
        statusText: world.globalStatusText || sel.statusText,
        iglooStashCount: world.iglooStash.length,
        hamsters: world.hamsters.map((h) => ({
          id: h.id,
          name: h.name,
          coatId: h.coatId,
          chubbyLevel: h.chubbyLevel,
          state: h.state,
          pouchCount: h.storedPouch.length,
        })),
      });
    };

    const triggerPetOn = (hamster: HamsterEntity, strokeDx = 0) => {
      const world = worldRef.current;
      world.selectedHamsterId = hamster.id;

      applySquishImpulse(hamster, 3.8, Math.max(-14, Math.min(14, strokeDx * 4.2)));

      const now = performance.now();
      if (now - lastPetTimeRef.current < 210) return;
      lastPetTimeRef.current = now;

      if (hamster.state === 'sleep') {
        hamster.state = 'stretch';
        hamster.stateTimer = 1.1;
        hamster.statusText = `${hamster.name} menggeliat manja saat dibangunkan elusanmu~`;
        world.globalStatusText = hamster.statusText;
        pixelSound.playSqueak();
        return;
      }

      if (hamster.state === 'run_wheel') {
        hamster.wheelPhase = 'none';
        hamster.y = FLOOR_TOP_Y + 14;
      }

      hamster.state = 'petted';
      hamster.stateTimer = 1.35;
      hamster.squish = 1;
      hamster.targetX = null;
      hamster.targetY = null;
      hamster.targetTreatId = null;
      hamster.statusText = `${hamster.name} memejamkan mata menikmati elusan lembutmu~`;
      world.globalStatusText = hamster.statusText;

      hamster.stats.happiness = Math.min(100, hamster.stats.happiness + 7);
      hamster.stats.affection += 2;

      spawnParticle(world, 'heart', hamster.x - 4, hamster.y - 24, '#FF6B93', -6, -16, 1.1);
      spawnParticle(world, 'heart', hamster.x + 5, hamster.y - 26, '#FF8FA8', 6, -18, 1.2);
      spawnParticle(
        world,
        'sparkle',
        hamster.x + (Math.random() * 14 - 7),
        hamster.y - 16,
        '#FFE066',
        0,
        -10,
        0.6
      );
      pixelSound.playSqueak();
    };

    const dropTreatAt = (type: 'seed' | 'strawberry' | 'corn', x?: number, y?: number) => {
      const world = worldRef.current;
      if (world.treats.length >= 8) {
        world.treats.shift();
      }
      const tx = Math.max(36, Math.min(VIRTUAL_W - 42, x ?? 85 + Math.random() * 120));
      const ty = Math.max(40, Math.min(FLOOR_BOTTOM_Y - 10, y ?? 70));
      world.treats.push({
        id: world.nextId++,
        type,
        x: tx,
        y: ty,
        vy: 0,
        landed: ty >= FLOOR_TOP_Y + 14,
        bitesLeft: 1,
      });
      pixelSound.playDrop();
    };

    useImperativeHandle(ref, () => ({
      dropTreat: (type, x, y) => dropTreatAt(type, x, y),
      sendToWheel: () => {
        const world = worldRef.current;
        const hamster = getSelectedHamster(world);
        hamster.targetTreatId = null;
        hamster.targetX = PROP_POS.wheel.x;
        hamster.targetY = PROP_POS.wheel.y + PROP_POS.wheel.radius - 3;
        hamster.state = 'walk';
        hamster.stateTimer = 5.0;
        hamster.statusText = `${hamster.name} berlari senang menuju roda putar!`;
        world.globalStatusText = hamster.statusText;
        spawnParticle(world, 'exclaim', hamster.x, hamster.y - 26, '#FF6B93', 0, -8, 0.8);
        pixelSound.playSqueak();
      },
      sendToNap: () => {
        const world = worldRef.current;
        const hamster = getSelectedHamster(world);
        hamster.targetTreatId = null;
        hamster.targetX = PROP_POS.cushion.x;
        hamster.targetY = PROP_POS.cushion.y + 1;
        hamster.state = 'walk';
        hamster.stateTimer = 4.5;
        hamster.statusText = `${hamster.name} menuju bantal empuk untuk tidur mochi~`;
        world.globalStatusText = hamster.statusText;
      },
      refillBowlAndWater: () => {
        const world = worldRef.current;
        world.bowlSeeds = 100;
        world.waterLevel = 100;
        spawnParticle(world, 'sparkle', PROP_POS.bowl.x, PROP_POS.bowl.y - 10, '#FFE066', 0, -10, 1.0);
        spawnParticle(world, 'sparkle', PROP_POS.bottle.x, PROP_POS.bottle.y - 10, '#9CE5FF', 0, -10, 1.0);
        world.globalStatusText = `Mangkuk kuaci dan botol minum sudah diisi penuh lagi!`;
        pixelSound.playHappyChime();
      },
      cleanBedding: () => {
        const world = worldRef.current;
        world.cleanliness = 100;
        for (const h of world.hamsters) {
          h.stats.happiness = Math.min(100, h.stats.happiness + 10);
        }
        for (let i = 0; i < 8; i++) {
          spawnParticle(
            world,
            'sparkle',
            40 + Math.random() * 210,
            FLOOR_TOP_Y + Math.random() * 26,
            '#FFE066',
            (Math.random() - 0.5) * 14,
            -16 - Math.random() * 10,
            1.1
          );
        }
        world.globalStatusText = `Serbuk kayu sudah diganti bersih dan harum! Semua hamster senang~`;
        pixelSound.playSparkle();
      },
      petNow: () => {
        const sel = getSelectedHamster(worldRef.current);
        triggerPetOn(sel, 0);
      },
      toggleChubby: () => {
        cycleChubbyMode(worldRef.current);
        pushHudNow();
      },
      spawnHamster: () => {
        spawnExtraHamster(worldRef.current);
        pushHudNow();
      },
      selectHamster: (id: number) => {
        const world = worldRef.current;
        const found = world.hamsters.find((h) => h.id === id);
        if (found) {
          world.selectedHamsterId = id;
          world.globalStatusText = found.statusText;
          applySquishImpulse(found, -2.8);
          pixelSound.playSqueak();
          pushHudNow();
        }
      },
      removeHamster: (id: number) => {
        const world = worldRef.current;
        if (world.hamsters.length <= 1) return;
        const idx = world.hamsters.findIndex((h) => h.id === id);
        if (idx !== -1) {
          const [removed] = world.hamsters.splice(idx, 1);
          if (world.selectedHamsterId === id) {
            world.selectedHamsterId = world.hamsters[0].id;
          }
          world.globalStatusText = `Dadah ${removed.name}~ sampai jumpa lagi!`;
          pushHudNow();
        }
      },
      setSelectedCoat: (coatId: string) => {
        const sel = getSelectedHamster(worldRef.current);
        sel.coatId = coatId;
        applySquishImpulse(sel, -3);
        pushHudNow();
      },
      setSelectedName: (name: string) => {
        const sel = getSelectedHamster(worldRef.current);
        sel.name = name;
        pushHudNow();
      },
      capturePng: () => {
        const canvas = canvasRef.current;
        if (!canvas) return null;
        const out = document.createElement('canvas');
        out.width = VIRTUAL_W * 4;
        out.height = VIRTUAL_H * 4;
        const octx = out.getContext('2d');
        if (!octx) return null;
        octx.imageSmoothingEnabled = false;
        octx.drawImage(canvas, 0, 0, out.width, out.height);
        return out.toDataURL('image/png');
      },
    }));

    useEffect(() => {
      let rafId = 0;
      let lastTime = performance.now();
      let hudSyncAccum = 0;

      const renderLoop = (now: number) => {
        const rawDt = (now - lastTime) / 1000;
        lastTime = now;
        const dt = Math.min(0.05, Math.max(0.001, rawDt));
        const timeSec = now / 1000;

        const world = worldRef.current;
        stepSimulation(world, dt, timeSec);

        const canvas = canvasRef.current;
        if (canvas) {
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.imageSmoothingEnabled = false;
            ctx.clearRect(0, 0, VIRTUAL_W, VIRTUAL_H);

            drawTerrariumBack(
              ctx,
              world.nightMode,
              world.rainMode,
              timeSec,
              world.cleanliness,
              world.iglooStash
            );
            drawWheelSpokes(ctx, world.wheelAngle, world.wheelSpeed);

            // Depth-sort hamsters by Y (with wheel runner drawn cleanly inside wheel)
            const sorted = [...world.hamsters].sort((a, b) => a.y - b.y);
            const showMarker = world.hamsters.length > 1;
            for (const h of sorted) {
              const coat =
                HAMSTER_COATS.find((c) => c.id === h.coatId) || HAMSTER_COATS[0];
              drawHamster(
                ctx,
                h,
                coat,
                timeSec,
                showMarker && h.id === world.selectedHamsterId
              );
            }

            drawTerrariumForeground(
              ctx,
              world.bowlSeeds,
              world.waterLevel,
              world.treats,
              world.nightMode,
              world.rainMode,
              world.wheelAngle
            );
            drawParticles(ctx, world.particles);
          }
        }

        hudSyncAccum += dt;
        if (hudSyncAccum >= 0.14) {
          hudSyncAccum = 0;
          pushHudNow();
        }

        rafId = requestAnimationFrame(renderLoop);
      };

      rafId = requestAnimationFrame(renderLoop);
      return () => cancelAnimationFrame(rafId);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const toVirtualCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
      const canvas = canvasRef.current;
      if (!canvas) return { x: VIRTUAL_W / 2, y: FLOOR_TOP_Y + 12 };
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * VIRTUAL_W;
      const y = ((e.clientY - rect.top) / rect.height) * VIRTUAL_H;
      return { x, y };
    };

    const findHamsterNear = (x: number, y: number, radius = 24): HamsterEntity | null => {
      let best: HamsterEntity | null = null;
      let bestDist = radius;
      for (const h of worldRef.current.hamsters) {
        const d = Math.hypot(x - h.x, y - (h.y - 11));
        if (d <= bestDist) {
          bestDist = d;
          best = h;
        }
      }
      return best;
    };

    const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
      isPointerDownRef.current = true;
      const { x, y } = toVirtualCoords(e);
      lastPointerXRef.current = x;
      const world = worldRef.current;

      // Direct hit on any hamster selects + pets/boops it!
      const hitHamster = findHamsterNear(x, y, 24);
      if (hitHamster) {
        pettingHamsterIdRef.current = hitHamster.id;
        triggerPetOn(hitHamster, 0);
        pushHudNow();
        return;
      }

      if (toolRef.current !== 'pet') {
        dropTreatAt(toolRef.current, x, y);
        return;
      }

      const hamster = getSelectedHamster(world);

      // Clicking the wheel sends selected hamster to wheel
      if (Math.hypot(x - PROP_POS.wheel.x, y - PROP_POS.wheel.y) <= 25) {
        hamster.targetTreatId = null;
        hamster.targetX = PROP_POS.wheel.x;
        hamster.targetY = PROP_POS.wheel.y + PROP_POS.wheel.radius - 3;
        hamster.state = 'walk';
        hamster.stateTimer = 5.0;
        hamster.statusText = `${hamster.name} berlari menuju roda putar!`;
        world.globalStatusText = hamster.statusText;
        pixelSound.playSqueak();
        return;
      }

      // Clicking cushion or igloo encourages nap
      if (
        Math.hypot(x - PROP_POS.cushion.x, y - PROP_POS.cushion.y) <= 18 ||
        Math.hypot(x - PROP_POS.igloo.x, y - (PROP_POS.igloo.y - 10)) <= 22
      ) {
        hamster.targetTreatId = null;
        hamster.targetX = PROP_POS.cushion.x;
        hamster.targetY = PROP_POS.cushion.y + 1;
        hamster.state = 'walk';
        hamster.stateTimer = 4.5;
        hamster.statusText = `${hamster.name} berjalan menuju bantal empuk~`;
        world.globalStatusText = hamster.statusText;
        return;
      }

      // Otherwise clicking bedding makes selected hamster waddle over curiously!
      if (y >= FLOOR_TOP_Y - 6) {
        hamster.targetTreatId = null;
        hamster.targetX = Math.max(32, Math.min(VIRTUAL_W - 36, x));
        hamster.targetY = Math.max(FLOOR_TOP_Y + 8, Math.min(FLOOR_BOTTOM_Y - 5, y));
        hamster.state = 'walk';
        hamster.stateTimer = 4.5;
        hamster.statusText = `${hamster.name} menghampiri jarimu dengan penuh rasa ingin tahu!`;
        world.globalStatusText = hamster.statusText;
        spawnParticle(world, 'question', hamster.x, hamster.y - 26, '#6C8CE8', 0, -8, 0.7);
      }
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
      if (!isPointerDownRef.current || toolRef.current !== 'pet') return;
      const { x, y } = toVirtualCoords(e);
      const dx = lastPointerXRef.current !== null ? x - lastPointerXRef.current : 0;
      lastPointerXRef.current = x;

      const target =
        (pettingHamsterIdRef.current !== null
          ? worldRef.current.hamsters.find((h) => h.id === pettingHamsterIdRef.current)
          : null) || findHamsterNear(x, y, 26);

      if (target && Math.hypot(x - target.x, y - (target.y - 11)) <= 28) {
        triggerPetOn(target, dx);
      }
    };

    const handlePointerUp = () => {
      isPointerDownRef.current = false;
      lastPointerXRef.current = null;
      pettingHamsterIdRef.current = null;
    };

    return (
      <div className="relative w-full overflow-hidden rounded-xl border-4 border-[#5A392C] bg-[#3E2820] shadow-[0_6px_0_#5A392C]">
        <canvas
          ref={canvasRef}
          width={VIRTUAL_W}
          height={VIRTUAL_H}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerLeave={handlePointerUp}
          className={`pixel-canvas block w-full aspect-[288/176] select-none ${
            toolMode === 'pet' ? 'cursor-grab active:cursor-grabbing' : 'cursor-crosshair'
          }`}
        />
      </div>
    );
  }
);

TerrariumCanvas.displayName = 'TerrariumCanvas';

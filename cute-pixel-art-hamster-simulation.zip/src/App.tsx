import React, { useCallback, useEffect, useRef, useState } from 'react';
import { HamsterPortraitBadge } from './components/HamsterPortraitBadge';
import {
  PixelBerryIcon,
  PixelBoltIcon,
  PixelBowlIcon,
  PixelCameraIcon,
  PixelChubbyIcon,
  PixelCornIcon,
  PixelHandIcon,
  PixelHeartIcon,
  PixelMoonSunIcon,
  PixelPlusHamIcon,
  PixelRainIcon,
  PixelSeedIcon,
  PixelSoundIcon,
  PixelSparkleIcon,
  PixelWheelIcon,
} from './components/PixelIcons';
import { HudSnapshot, TerrariumCanvas, TerrariumHandle } from './components/TerrariumCanvas';
import { HAMSTER_COATS } from './data/hamsterCoats';
import { ChubbyLevel, HamsterState, ToolMode } from './types/hamster';
import { pixelSound } from './utils/pixelSound';

const STATE_BADGE_LABELS: Record<HamsterState, string> = {
  idle: 'Santai',
  stand: 'Kepo',
  walk: 'Jalan Gembul',
  run_wheel: 'Ngebut Roda',
  dizzy: 'Pusing Lucu',
  eat: 'Nyam Nyam',
  stuff_cheek: 'Isi Pipi!',
  unload_stash: 'Simpan Iglo!',
  drink: 'Minum',
  groom: 'Cuci Muka',
  dig: 'Gali Sekam',
  sleep: 'Tidur Mochi',
  petted: 'Manja~',
  yawn: 'Menguap',
  stretch: 'Menggeliat',
  shake: 'Bulu Brrr~',
  happy_hop: 'Lompat Senang!',
};

const CHUBBY_LABELS: Record<ChubbyLevel, string> = {
  0: 'Normal',
  1: 'Gemuk',
  2: 'Super Gembrot!',
};

export function App() {
  const terrariumRef = useRef<TerrariumHandle | null>(null);

  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [nameDraft, setNameDraft] = useState<string>('Mochi');

  const [nightMode, setNightMode] = useState<boolean>(false);
  const [rainMode, setRainMode] = useState<boolean>(false);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [toolMode, setToolMode] = useState<ToolMode>('pet');
  const [snapshotUrl, setSnapshotUrl] = useState<string | null>(null);

  const [hud, setHud] = useState<HudSnapshot>({
    selectedId: 1,
    selectedName: 'Mochi',
    selectedCoatId: HAMSTER_COATS[0].id,
    selectedChubby: 0,
    selectedState: 'idle',
    selectedPouchCount: 0,
    iglooStashCount: 0,
    stats: {
      hunger: 78,
      happiness: 84,
      energy: 86,
      cleanliness: 94,
      cheekPuff: 0,
      affection: 12,
    },
    statusText: 'Mochi mengendus udara dengan hidung mungilnya~',
    hamsters: [
      {
        id: 1,
        name: 'Mochi',
        coatId: HAMSTER_COATS[0].id,
        chubbyLevel: 0,
        state: 'idle',
        pouchCount: 0,
      },
    ],
  });

  const currentCoat =
    HAMSTER_COATS.find((c) => c.id === hud.selectedCoatId) || HAMSTER_COATS[0];

  const handleHudUpdate = useCallback((next: HudSnapshot) => {
    setHud(next);
  }, []);

  // Keyboard shortcut 'B' -> make hamster gemuk / super gembrot!
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isEditingName) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if (e.key === 'b' || e.key === 'B') {
        e.preventDefault();
        terrariumRef.current?.toggleChubby();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isEditingName]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    pixelSound.setEnabled(next);
    if (next) pixelSound.playSqueak();
  };

  const toggleRain = () => {
    const next = !rainMode;
    setRainMode(next);
    pixelSound.playSparkle();
  };

  const commitName = () => {
    const trimmed = nameDraft.trim().slice(0, 14);
    if (trimmed) {
      terrariumRef.current?.setSelectedName(trimmed);
    } else {
      setNameDraft(hud.selectedName);
    }
    setIsEditingName(false);
  };

  const handleSelectTreat = (mode: 'seed' | 'strawberry' | 'corn') => {
    setToolMode(mode);
    terrariumRef.current?.dropTreat(mode);
  };

  const handleTakeSnapshot = () => {
    const url = terrariumRef.current?.capturePng();
    if (url) {
      setSnapshotUrl(url);
      pixelSound.playSparkle();
    }
  };

  const cheekPuffDots = Math.min(4, Math.round(hud.stats.cheekPuff));

  return (
    <div className="min-h-screen w-full px-3 py-4 sm:px-6 sm:py-6 flex flex-col items-center justify-center">
      <div className="w-full max-w-4xl flex flex-col gap-3">
        {/* Top Cozy 16-Bit Header */}
        <header className="pixel-panel rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-xl bg-[#FFE9C9] border-2 border-[#5A392C] animate-float-slow">
              <HamsterPortraitBadge coat={currentCoat} size={36} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="font-pixel text-xl sm:text-2xl font-bold tracking-tight text-[#4A3228]">
                  MochiHamu!
                </h1>
                <span className="font-pixel text-[11px] px-2 py-0.5 rounded-md bg-[#FFD6E2] border-2 border-[#5A392C] text-[#5A392C] font-semibold">
                  16-BIT PIXEL PET
                </span>
                {hud.selectedChubby > 0 && (
                  <span className="font-pixel text-[11px] px-2 py-0.5 rounded-md bg-[#FFE29E] border-2 border-[#5A392C] text-[#5A392C] font-bold">
                    ★ {CHUBBY_LABELS[hud.selectedChubby]}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 mt-0.5 text-sm flex-wrap">
                <span className="font-soft text-xs font-bold text-[#8A6552]">
                  Aktif:
                </span>
                {isEditingName ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      commitName();
                    }}
                    className="inline-flex items-center gap-1"
                  >
                    <input
                      type="text"
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      onBlur={commitName}
                      autoFocus
                      maxLength={14}
                      className="font-pixel text-sm px-2 py-0.5 w-28 rounded bg-white border-2 border-[#5A392C] focus:outline-none"
                    />
                  </form>
                ) : (
                  <button
                    onClick={() => {
                      setNameDraft(hud.selectedName);
                      setIsEditingName(true);
                    }}
                    title="Klik untuk ganti nama hamster aktif"
                    className="font-pixel text-sm font-bold text-[#5A392C] hover:text-[#D95D82] underline decoration-dotted cursor-pointer"
                  >
                    {hud.selectedName} ✎
                  </button>
                )}
                <span className="text-[#C6A892]">•</span>
                <span className="inline-flex items-center gap-1 font-pixel text-xs font-semibold text-[#D95D82]">
                  <PixelHeartIcon className="w-3.5 h-3.5" />
                  Sayang {hud.stats.affection}
                </span>
              </div>
            </div>
          </div>

          {/* Right Quick Toggles: Spawn Hamster, Rain, Night/Day, Sound */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => terrariumRef.current?.spawnHamster()}
              disabled={hud.hamsters.length >= 5}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1.5 ${
                hud.hamsters.length >= 5
                  ? 'bg-[#EAE0D5] opacity-60 cursor-not-allowed'
                  : 'bg-[#C9F7DB]'
              }`}
              title="Tambah hamster lucu baru ke kandang (maks 5)"
            >
              <PixelPlusHamIcon className="w-4 h-4" />
              <span>
                Hamster ({hud.hamsters.length}/5)
              </span>
            </button>

            <button
              onClick={toggleRain}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1.5 ${
                rainMode ? 'pixel-btn-active bg-[#CBE4FF]' : 'bg-[#FFF7EA]'
              }`}
              title="Ubah cuaca cerah / hujan rintik di luar jendela"
            >
              <PixelRainIcon raining={rainMode} className="w-4 h-4" />
              <span className="hidden sm:inline">
                {rainMode ? 'Hujan Rintik' : 'Cerah'}
              </span>
            </button>

            <button
              onClick={() => setNightMode((v) => !v)}
              className="pixel-btn rounded-xl px-2.5 py-1.5 bg-[#FFF1D6] text-xs font-pixel font-bold flex items-center gap-1.5"
              title="Ubah suasana pagi / lampu malam"
            >
              <PixelMoonSunIcon night={nightMode} className="w-4 h-4" />
              <span className="hidden sm:inline">
                {nightMode ? 'Malam Cozy' : 'Pagi Cerah'}
              </span>
            </button>

            <button
              onClick={toggleSound}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1.5 ${
                soundEnabled ? 'bg-[#DCF5E4]' : 'bg-[#F2E4DC]'
              }`}
              title="Nyalakan / matikan suara lucu 16-bit"
            >
              <PixelSoundIcon enabled={soundEnabled} className="w-4 h-4" />
              <span className="hidden sm:inline">
                {soundEnabled ? 'Suara On' : 'Bisukan'}
              </span>
            </button>
          </div>
        </header>

        {/* Multi-Hamster Switcher Bar (appears when > 1 hamster spawned!) */}
        {hud.hamsters.length > 1 && (
          <section className="pixel-panel rounded-xl px-3 py-2 flex items-center gap-2 flex-wrap">
            <span className="font-pixel text-xs font-bold text-[#6E4A3A]">
              Penghuni Kandang:
            </span>
            {hud.hamsters.map((h) => {
              const c =
                HAMSTER_COATS.find((coat) => coat.id === h.coatId) || HAMSTER_COATS[0];
              const isSel = h.id === hud.selectedId;
              return (
                <div
                  key={h.id}
                  className={`inline-flex items-center gap-1.5 rounded-lg border-2 border-[#5A392C] pl-1.5 pr-1 py-0.5 transition-colors ${
                    isSel ? 'bg-[#FFE2AD] shadow-sm' : 'bg-[#FFFDF9] hover:bg-[#FFF3DE]'
                  }`}
                >
                  <button
                    onClick={() => terrariumRef.current?.selectHamster(h.id)}
                    className="inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <HamsterPortraitBadge coat={c} size={20} />
                    <span className="font-pixel text-xs font-bold text-[#4A3228]">
                      {h.name}
                    </span>
                    {h.chubbyLevel > 0 && (
                      <span className="font-pixel text-[10px] px-1 rounded bg-[#FFD6E2] border border-[#5A392C]">
                        {h.chubbyLevel === 2 ? 'Gembrot' : 'Gemuk'}
                      </span>
                    )}
                  </button>
                  <button
                    onClick={() => terrariumRef.current?.removeHamster(h.id)}
                    title={`Keluarkan ${h.name}`}
                    className="ml-0.5 w-4 h-4 rounded text-[10px] font-bold text-[#8A6552] hover:bg-[#FFBFD0] hover:text-[#4A3228] cursor-pointer"
                  >
                    ×
                  </button>
                </div>
              );
            })}
          </section>
        )}

        {/* Stat Meters Row */}
        <section className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <StatMeter
            label="Kenyang"
            value={hud.stats.hunger}
            barColor="bg-[#FFB36B]"
            icon={<PixelSeedIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Senang"
            value={hud.stats.happiness}
            barColor="bg-[#FF7EA5]"
            icon={<PixelHeartIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Energi"
            value={hud.stats.energy}
            barColor="bg-[#FFE066]"
            icon={<PixelBoltIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Bersih"
            value={hud.stats.cleanliness}
            barColor="bg-[#88E0B4]"
            icon={<PixelSparkleIcon className="w-4 h-4" />}
          />
          {/* Cheek Pouch + Igloo Stash Indicator */}
          <div className="col-span-2 sm:col-span-1 pixel-panel rounded-xl px-3 py-2 flex items-center justify-between sm:flex-col sm:items-start sm:justify-center gap-1">
            <div className="w-full flex items-center justify-between">
              <span className="font-pixel text-xs font-bold text-[#6E4A3A]">
                Pipi &amp; Iglo
              </span>
              <span className="font-pixel text-[11px] font-bold text-[#B36B43]">
                Iglo: {hud.iglooStashCount}
              </span>
            </div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4].map((dot) => (
                <span
                  key={dot}
                  className={`inline-block w-3 h-3 rounded-sm border-2 border-[#5A392C] transition-transform ${
                    cheekPuffDots >= dot
                      ? 'bg-[#FF9CB8] scale-110'
                      : 'bg-[#F5E6D3]'
                  }`}
                />
              ))}
              <span className="font-pixel text-[11px] text-[#8A6552] ml-1">
                {hud.selectedPouchCount > 0
                  ? `${hud.selectedPouchCount} di pipi`
                  : 'Kosong'}
              </span>
            </div>
          </div>
        </section>

        {/* Main 16-Bit Pixel Terrarium Viewport */}
        <main className="relative">
          <TerrariumCanvas
            ref={terrariumRef}
            nightMode={nightMode}
            rainMode={rainMode}
            toolMode={toolMode}
            onHudUpdate={handleHudUpdate}
          />

          {/* Live Status Ticker Bar */}
          <div className="mt-2.5 pixel-panel rounded-xl px-3.5 py-2 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="shrink-0 font-pixel text-[11px] px-2 py-0.5 rounded bg-[#FFE4B8] border-2 border-[#5A392C] font-bold uppercase">
                {STATE_BADGE_LABELS[hud.selectedState]}
              </span>
              <p className="font-soft text-xs sm:text-sm font-bold text-[#4A3228] truncate">
                {hud.statusText}
              </p>
            </div>
            <span className="font-pixel text-[11px] text-[#8A6552] hidden lg:inline">
              Tekan [B] untuk mode Gembrot • Jatuhkan &gt;1 camilan agar pipinya penuh &amp; ditimbun ke iglo!
            </span>
          </div>
        </main>

        {/* Bottom Care & Toy Action Dock */}
        <section className="pixel-panel rounded-2xl p-3">
          <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-10 gap-2">
            <ActionButton
              active={toolMode === 'pet'}
              bg="bg-[#FFD6E2]"
              label="Elus"
              icon={<PixelHandIcon className="w-5 h-5" />}
              onClick={() => {
                setToolMode('pet');
                terrariumRef.current?.petNow();
              }}
            />
            <ActionButton
              active={toolMode === 'seed'}
              bg="bg-[#F5E1C8]"
              label="Kuaci"
              icon={<PixelSeedIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('seed')}
            />
            <ActionButton
              active={toolMode === 'strawberry'}
              bg="bg-[#FFC7D4]"
              label="Stroberi"
              icon={<PixelBerryIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('strawberry')}
            />
            <ActionButton
              active={toolMode === 'corn'}
              bg="bg-[#FFF0A8]"
              label="Jagung"
              icon={<PixelCornIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('corn')}
            />
            <ActionButton
              active={hud.selectedChubby > 0}
              bg="bg-[#FFE2A8]"
              label={`Gembrot [B]`}
              icon={<PixelChubbyIcon className="w-5 h-5" />}
              onClick={() => terrariumRef.current?.toggleChubby()}
            />
            <ActionButton
              bg="bg-[#FFE5EC]"
              label="Isi Mangkuk"
              icon={<PixelBowlIcon className="w-5 h-5" />}
              onClick={() => terrariumRef.current?.refillBowlAndWater()}
            />
            <ActionButton
              bg="bg-[#FFE9B8]"
              label="Main Roda"
              icon={<PixelWheelIcon className="w-5 h-5" />}
              onClick={() => terrariumRef.current?.sendToWheel()}
            />
            <ActionButton
              bg="bg-[#DCE3FF]"
              label="Tidur Mochi"
              icon={<PixelMoonSunIcon night className="w-5 h-5" />}
              onClick={() => terrariumRef.current?.sendToNap()}
            />
            <ActionButton
              bg="bg-[#D5F5E3]"
              label="Bersihkan"
              icon={<PixelSparkleIcon className="w-5 h-5" />}
              onClick={() => terrariumRef.current?.cleanBedding()}
            />
            <ActionButton
              bg="bg-[#EBDDFB]"
              label="Foto"
              icon={<PixelCameraIcon className="w-5 h-5" />}
              onClick={handleTakeSnapshot}
            />
          </div>
        </section>

        {/* Hamster Breed / Coat Selector */}
        <section className="pixel-panel rounded-2xl p-3">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-1">
            <h2 className="font-pixel text-sm font-bold text-[#5A392C]">
              Warna Bulu untuk {hud.selectedName} (16-Bit Fur Coats)
            </h2>
            <span className="font-soft text-xs font-bold text-[#8A6552]">
              {currentCoat.subtitle}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {HAMSTER_COATS.map((coat) => {
              const selected = coat.id === hud.selectedCoatId;
              return (
                <button
                  key={coat.id}
                  onClick={() => {
                    terrariumRef.current?.setSelectedCoat(coat.id);
                    pixelSound.playSqueak();
                  }}
                  className={`pixel-btn rounded-xl px-2.5 py-2 flex items-center gap-2 text-left ${
                    selected
                      ? 'pixel-btn-active bg-[#FFE4B5]'
                      : 'bg-[#FFFDF9] hover:bg-[#FFF5E4]'
                  }`}
                >
                  <div
                    className="p-1 rounded-lg border-2 border-[#5A392C]"
                    style={{ backgroundColor: coat.badgeColor }}
                  >
                    <HamsterPortraitBadge coat={coat} size={24} />
                  </div>
                  <div className="min-w-0">
                    <div className="font-pixel text-xs font-bold text-[#4A3228] truncate">
                      {coat.name}
                    </div>
                    <div className="font-soft text-[10px] font-bold text-[#8A6552]">
                      {selected ? '★ Aktif' : 'Pilih'}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </div>

      {/* Polaroid Pixel Photo Modal */}
      {snapshotUrl && (
        <div
          className="fixed inset-0 z-50 bg-[#3B241C]/65 flex items-center justify-center p-4"
          onClick={() => setSnapshotUrl(null)}
        >
          <div
            className="pixel-panel rounded-2xl p-4 max-w-md w-full flex flex-col items-center gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between">
              <span className="font-pixel text-base font-bold text-[#5A392C]">
                Foto Polaroid {hud.selectedName}!
              </span>
              <button
                onClick={() => setSnapshotUrl(null)}
                className="pixel-btn rounded-lg px-2.5 py-0.5 bg-[#FFD6E2] font-pixel text-xs font-bold"
              >
                Tutup
              </button>
            </div>
            <div className="p-2.5 pb-5 bg-white border-3 border-[#5A392C] rounded-lg shadow-md w-full">
              <img
                src={snapshotUrl}
                alt={`Foto ${hud.selectedName}`}
                className="pixel-canvas w-full rounded border-2 border-[#5A392C]"
              />
              <p className="font-pixel text-center text-sm font-bold text-[#5A392C] mt-2">
                ♥ {hud.selectedName} ({currentCoat.name}) ♥
              </p>
            </div>
            <a
              href={snapshotUrl}
              download={`${hud.selectedName.toLowerCase()}-16bit.png`}
              className="pixel-btn rounded-xl px-4 py-2 bg-[#B8F2D0] font-pixel text-sm font-bold text-[#4A3228] w-full text-center"
            >
              Simpan Foto Pixel (.PNG)
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

interface StatMeterProps {
  label: string;
  value: number;
  barColor: string;
  icon: React.ReactNode;
}

const StatMeter: React.FC<StatMeterProps> = ({
  label,
  value,
  barColor,
  icon,
}) => {
  const pct = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className="pixel-panel rounded-xl px-3 py-2 flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 font-pixel text-xs font-bold text-[#5A392C]">
          {icon}
          {label}
        </span>
        <span className="font-pixel text-xs font-bold text-[#7A5442]">
          {pct}%
        </span>
      </div>
      <div className="w-full h-3 rounded-sm bg-[#EAD8C0] border-2 border-[#5A392C] overflow-hidden">
        <div
          className={`h-full ${barColor} transition-all duration-300`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

interface ActionButtonProps {
  label: string;
  icon: React.ReactNode;
  bg: string;
  active?: boolean;
  onClick: () => void;
}

const ActionButton: React.FC<ActionButtonProps> = ({
  label,
  icon,
  bg,
  active,
  onClick,
}) => (
  <button
    onClick={onClick}
    className={`pixel-btn rounded-xl px-2 py-2 flex flex-col items-center justify-center gap-1 ${bg} ${
      active ? 'pixel-btn-active ring-2 ring-[#FF6B93]' : ''
    }`}
  >
    {icon}
    <span className="font-pixel text-[11px] font-bold text-[#4A3228] leading-tight text-center">
      {label}
    </span>
  </button>
);

export default App;

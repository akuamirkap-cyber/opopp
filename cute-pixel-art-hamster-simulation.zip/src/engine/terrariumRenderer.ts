import { PixelParticle, TreatItem, TreatKind } from '../types/hamster';
import { drawMatrix, px, rect } from './pixelPrimitives';

export const VIRTUAL_W = 288;
export const VIRTUAL_H = 176;
export const FLOOR_TOP_Y = 128;
export const FLOOR_BOTTOM_Y = 166;

export const PROP_POS = {
  igloo: { x: 40, y: 135 },
  wheel: { x: 114, y: 109, radius: 24, standY: 137 },
  cushion: { x: 186, y: 146 },
  bowl: { x: 232, y: 148 },
  bottle: { x: 266, y: 108, spoutX: 258, spoutY: 122 },
};

const HEART_SPRITE = [
  '.RR.RR.',
  'RRRRRRR',
  'RRWRRRR',
  '.RRRRR.',
  '..RRR..',
  '...R...',
];

const NOTE_SPRITE = [
  '...NN',
  '..NNN',
  '..N..',
  '.NN..',
  'NNN..',
  '.N...',
];

const ZZZ_SPRITE = [
  'ZZZZ',
  '..Z.',
  '.Z..',
  'ZZZZ',
];

const STAR_SPRITE = [
  '..S..',
  '.SSS.',
  'SSWSS',
  '.SSS.',
  '..S..',
];

export function drawTerrariumBack(
  ctx: CanvasRenderingContext2D,
  nightMode: boolean,
  rainMode: boolean,
  timeSec: number,
  cleanliness: number,
  iglooStash: TreatKind[]
) {
  // 1) Cozy pastel wallpaper
  const wallBg = nightMode ? '#3A3556' : rainMode ? '#F6EAE0' : '#FFF4E4';
  const wallStripe = nightMode ? '#433D63' : rainMode ? '#EFE0D3' : '#FCEAD2';
  rect(ctx, 0, 0, VIRTUAL_W, FLOOR_TOP_Y, wallBg);

  for (let x = 0; x < VIRTUAL_W; x += 12) {
    rect(ctx, x, 0, 4, FLOOR_TOP_Y, wallStripe);
  }

  // Wooden wainscoting trim behind cage
  rect(ctx, 0, FLOOR_TOP_Y - 10, VIRTUAL_W, 10, nightMode ? '#523C4A' : '#EBC69E');
  rect(ctx, 0, FLOOR_TOP_Y - 10, VIRTUAL_W, 2, nightMode ? '#6B4F5F' : '#F6DAB8');

  // 2) Window on back-right showing sky / stars / cozy rain outside!
  const winX = 188;
  const winY = 20;
  const winW = 58;
  const winH = 52;
  rect(ctx, winX - 3, winY - 3, winW + 6, winH + 6, '#5A392C');
  rect(ctx, winX - 2, winY - 2, winW + 4, winH + 4, nightMode ? '#8B6B61' : '#DFAA7B');

  const skyCol = rainMode
    ? nightMode
      ? '#1E2440'
      : '#7B98BD'
    : nightMode
    ? '#222447'
    : '#BCE8FF';
  rect(ctx, winX, winY, winW, winH, skyCol);

  if (rainMode) {
    // Misty lower sky band
    rect(ctx, winX, winY + 32, winW, 20, nightMode ? '#293152' : '#94B0D1');
    // Fluffy rain clouds drifting at top of window
    const drift = Math.floor((timeSec * 4) % 24);
    const cloudCol = nightMode ? '#414C73' : '#BCCCE0';
    const cloudLight = nightMode ? '#55638F' : '#D5E2F0';
    rect(ctx, winX + ((drift + 2) % 34), winY + 5, 22, 6, cloudCol);
    rect(ctx, winX + ((drift + 6) % 34), winY + 3, 14, 3, cloudLight);
    rect(ctx, winX + ((drift + 24) % 32), winY + 8, 18, 5, cloudCol);

    // Animated diagonal pixel raindrops inside the window!
    for (let i = 0; i < 22; i++) {
      const speed = 34 + (i % 3) * 10;
      const progress = (timeSec * speed + i * 17) % (winH - 4);
      const rx = winX + ((i * 11 + Math.floor(progress * 0.35)) % (winW - 3));
      const ry = winY + 4 + Math.floor(progress);
      const dropCol = nightMode ? '#7CA6E8' : '#DDF4FF';
      px(ctx, rx, ry, dropCol);
      if (ry + 1 < winY + winH) px(ctx, rx - 1, ry + 1, dropCol);
      if (i % 2 === 0 && ry + 2 < winY + winH) px(ctx, rx - 1, ry + 2, '#A4D8FF');
    }

    // Little splash pixels along window sill
    for (let s = 0; s < 5; s++) {
      if (Math.floor(timeSec * 9 + s * 3) % 3 === 0) {
        const sx = winX + 6 + s * 11;
        px(ctx, sx, winY + winH - 2, '#DDF4FF');
        px(ctx, sx + 2, winY + winH - 3, '#A4D8FF');
      }
    }
  } else if (!nightMode) {
    rect(ctx, winX, winY + 30, winW, 22, '#D9F4FF');
    const cloudOffset = Math.floor((timeSec * 3) % 42);
    const cx = winX + ((cloudOffset + 8) % 38);
    rect(ctx, cx, winY + 11, 14, 5, '#FFFFFF');
    rect(ctx, cx + 3, winY + 8, 8, 3, '#FFFFFF');
    rect(ctx, winX + 4, winY + 24, 10, 4, '#FFFFFF');
    rect(ctx, winX + 6, winY + 22, 6, 2, '#FFFFFF');
  } else {
    const twinkle = Math.floor(timeSec * 2) % 2 === 0;
    px(ctx, winX + 10, winY + 12, twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 22, winY + 24, !twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 46, winY + 16, twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 16, winY + 38, '#B8C4F2');
    rect(ctx, winX + 38, winY + 9, 7, 7, '#FFE994');
    rect(ctx, winX + 41, winY + 10, 4, 4, '#222447');
  }

  // Window mullions & sill
  rect(ctx, winX + winW / 2 - 1, winY, 2, winH, nightMode ? '#8B6B61' : '#DFAA7B');
  rect(ctx, winX, winY + winH / 2 - 1, winW, 2, nightMode ? '#8B6B61' : '#DFAA7B');
  // Subtle glass reflection diagonal glint
  px(ctx, winX + 5, winY + 6, 'rgba(255,255,255,0.45)');
  px(ctx, winX + 6, winY + 5, 'rgba(255,255,255,0.45)');
  rect(ctx, winX - 4, winY + winH + 2, winW + 8, 3, '#5A392C');
  rect(ctx, winX - 3, winY + winH + 2, winW + 6, 2, nightMode ? '#9E7B6E' : '#F2C79B');

  // 3) Framed tiny sunflower pixel picture on left wall
  const picX = 26;
  const picY = 26;
  rect(ctx, picX, picY, 24, 24, '#5A392C');
  rect(ctx, picX + 1, picY + 1, 22, 22, '#D9A06B');
  rect(ctx, picX + 3, picY + 3, 18, 18, '#FFF9EE');
  rect(ctx, picX + 11, picY + 13, 2, 6, '#6AC46E');
  rect(ctx, picX + 9, picY + 8, 6, 6, '#FFC947');
  rect(ctx, picX + 10, picY + 9, 4, 4, '#70442E');

  // 4) Cute pastel pennant bunting along top
  const buntingColors = ['#FFB5C8', '#FFE59E', '#B5EAD7', '#C7CEEA', '#FFDAC1'];
  for (let i = 0; i < 12; i++) {
    const bx = 8 + i * 24;
    const col = buntingColors[i % buntingColors.length];
    rect(ctx, bx, 6, 12, 2, '#5A392C');
    rect(ctx, bx + 1, 7, 10, 4, col);
    rect(ctx, bx + 3, 11, 6, 3, col);
    rect(ctx, bx + 5, 14, 2, 2, col);
  }
  rect(ctx, 0, 5, VIRTUAL_W, 1, '#7A5442');

  // 5) Fluffy Wood-Shaving Bedding Layer
  const bedTop = FLOOR_TOP_Y;
  const bedH = VIRTUAL_H - bedTop;
  rect(ctx, 0, bedTop, VIRTUAL_W, bedH, nightMode ? '#8D7366' : '#F5DFC2');

  for (let x = 0; x < VIRTUAL_W; x += 4) {
    const bump = (x / 4) % 3 === 0 ? -2 : (x / 4) % 2 === 0 ? -1 : 0;
    rect(ctx, x, bedTop + bump, 4, 3, nightMode ? '#A48879' : '#FFF1DC');
    px(ctx, x + 1, bedTop + bump - 1, '#5A392C');
    px(ctx, x + 2, bedTop + bump - 1, '#5A392C');
  }

  const chipA = nightMode ? '#7A6256' : '#E7C8A1';
  const chipB = nightMode ? '#A88C7D' : '#FFF7EA';
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 18; col++) {
      const cx = (col * 17 + row * 9) % (VIRTUAL_W - 8);
      const cy = bedTop + 5 + row * 7 + (col % 3);
      rect(ctx, cx, cy, 4, 2, col % 2 === 0 ? chipA : chipB);
    }
  }

  if (cleanliness < 70) {
    const messCount = Math.floor((75 - cleanliness) / 8);
    for (let i = 0; i < messCount; i++) {
      const mx = (i * 53 + 29) % (VIRTUAL_W - 20);
      const my = bedTop + 8 + ((i * 19) % 26);
      rect(ctx, mx, my, 2, 1, '#7D5C4C');
    }
  }

  // Bottom wooden terrarium frame bar
  rect(ctx, 0, VIRTUAL_H - 8, VIRTUAL_W, 8, '#7A4E3B');
  rect(ctx, 0, VIRTUAL_H - 8, VIRTUAL_W, 2, '#A36D54');
  rect(ctx, 0, VIRTUAL_H - 9, VIRTUAL_W, 1, '#5A392C');

  // 6) Cozy Pastel Igloo House (left-back) + stored cheek-pouch food hoard!
  drawIgloo(ctx, PROP_POS.igloo.x, PROP_POS.igloo.y, nightMode);
  drawIglooStash(ctx, PROP_POS.igloo.x + 17, PROP_POS.igloo.y + 3, iglooStash);

  // 7) Plush Star Cushion (center-right)
  drawCushion(ctx, PROP_POS.cushion.x, PROP_POS.cushion.y);

  // 8) Running Wheel (back stand + backplate)
  drawWheelBack(ctx, PROP_POS.wheel.x, PROP_POS.wheel.y, nightMode);
}

function drawIglooStash(
  ctx: CanvasRenderingContext2D,
  bx: number,
  by: number,
  stash: TreatKind[]
) {
  if (stash.length === 0) return;
  const maxShow = Math.min(10, stash.length);
  for (let i = 0; i < maxShow; i++) {
    const item = stash[i];
    const row = Math.floor(i / 4);
    const col = i % 4;
    const sx = bx - 5 + col * 3 + (row % 2);
    const sy = by - row * 2;
    if (item === 'strawberry') {
      rect(ctx, sx, sy - 2, 3, 2, '#5A392C');
      rect(ctx, sx, sy - 1, 2, 2, '#FF5478');
      px(ctx, sx, sy - 2, '#69D471');
    } else if (item === 'corn') {
      rect(ctx, sx, sy - 1, 3, 2, '#5A392C');
      rect(ctx, sx, sy - 1, 2, 1, '#FFD54F');
    } else {
      px(ctx, sx, sy, '#4F3C35');
      px(ctx, sx + 1, sy, '#E6DDD5');
      px(ctx, sx + 1, sy - 1, '#4F3C35');
    }
  }
}

function drawIgloo(ctx: CanvasRenderingContext2D, cx: number, baseY: number, nightMode: boolean) {
  const x = cx - 22;
  const y = baseY - 28;
  const body = nightMode ? '#7EA6A0' : '#B5E8DE';
  const light = nightMode ? '#9EC4BE' : '#D9FAF3';
  const shadow = nightMode ? '#5E827D' : '#8CCAC0';
  const trim = '#5A392C';

  rect(ctx, x + 7, y - 4, 8, 6, trim);
  rect(ctx, x + 8, y - 3, 6, 5, body);
  rect(ctx, x + 9, y - 2, 4, 3, '#FFA6B8');

  rect(ctx, x + 29, y - 4, 8, 6, trim);
  rect(ctx, x + 30, y - 3, 6, 5, body);
  rect(ctx, x + 31, y - 2, 4, 3, '#FFA6B8');

  rect(ctx, x + 4, y + 1, 36, 27, trim);
  rect(ctx, x + 2, y + 5, 40, 23, trim);
  rect(ctx, x, y + 11, 44, 17, trim);

  rect(ctx, x + 5, y + 2, 34, 25, body);
  rect(ctx, x + 3, y + 6, 38, 21, body);
  rect(ctx, x + 1, y + 12, 42, 15, body);

  rect(ctx, x + 6, y + 4, 18, 4, light);
  rect(ctx, x + 4, y + 8, 8, 6, light);
  rect(ctx, x + 1, y + 23, 42, 4, shadow);

  rect(ctx, x + 13, y + 11, 18, 17, trim);
  rect(ctx, x + 11, y + 14, 22, 14, trim);
  rect(ctx, x + 14, y + 12, 16, 15, '#3A2622');
  rect(ctx, x + 12, y + 15, 20, 12, '#3A2622');
}

function drawCushion(ctx: CanvasRenderingContext2D, cx: number, baseY: number) {
  const x = cx - 15;
  const y = baseY - 6;
  rect(ctx, x + 2, y - 1, 26, 8, '#5A392C');
  rect(ctx, x, y + 1, 30, 5, '#5A392C');
  rect(ctx, x + 3, y, 24, 6, '#FFBFD0');
  rect(ctx, x + 1, y + 2, 28, 3, '#FFBFD0');
  rect(ctx, x + 4, y + 1, 20, 2, '#FFE0E9');
  rect(ctx, x + 3, y + 5, 24, 1, '#E895AC');
  px(ctx, cx, y + 2, '#E895AC');
  px(ctx, cx - 1, y + 2, '#E895AC');
}

function drawWheelBack(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  nightMode: boolean
) {
  const r = PROP_POS.wheel.radius;

  // Wooden A-frame stand behind wheel
  rect(ctx, cx - 3, cy, 6, 28, '#5A392C');
  rect(ctx, cx - 2, cy + 1, 4, 26, '#C78E5D');
  rect(ctx, cx - 19, cy + 26, 38, 4, '#5A392C');
  rect(ctx, cx - 18, cy + 27, 36, 2, '#DFAA7B');

  // Wheel outer dark trim & warm wooden-pastel inner drum
  for (let dy = -r; dy <= r; dy++) {
    for (let dx = -r; dx <= r; dx++) {
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist <= r && dist >= r - 2.2) {
        px(ctx, cx + dx, cy + dy, '#5A392C');
      } else if (dist < r - 2.2 && dist >= r - 5.4) {
        px(ctx, cx + dx, cy + dy, nightMode ? '#C9A47C' : '#FFE0AD');
      } else if (dist < r - 5.4) {
        px(ctx, cx + dx, cy + dy, nightMode ? '#4A3F57' : '#FFF7E8');
      }
    }
  }
}

export function drawWheelSpokes(
  ctx: CanvasRenderingContext2D,
  wheelAngle: number,
  wheelSpeed: number
) {
  const { x: cx, y: cy, radius } = PROP_POS.wheel;
  const r = radius - 4;

  // Rotating pastel tread markers around inner track so rotation feels super crisp & smooth!
  const treadCount = 12;
  for (let i = 0; i < treadCount; i++) {
    const ang = wheelAngle + (i * Math.PI * 2) / treadCount;
    const tx = Math.round(cx + Math.cos(ang) * (radius - 3.6));
    const ty = Math.round(cy + Math.sin(ang) * (radius - 3.6));
    const col = i % 2 === 0 ? '#FF9BB8' : '#E8BA84';
    rect(ctx, tx, ty, 2, 2, col);
  }

  // Rotating 6 spokes
  for (let i = 0; i < 6; i++) {
    const ang = wheelAngle + (i * Math.PI) / 3;
    for (let step = 4; step <= r - 2; step++) {
      const sx = Math.round(cx + Math.cos(ang) * step);
      const sy = Math.round(cy + Math.sin(ang) * step);
      px(ctx, sx, sy, i % 2 === 0 ? '#E8BA84' : '#F5D3A6');
    }
  }

  // Cute spinning flower hub cap
  rect(ctx, cx - 3, cy - 3, 6, 6, '#5A392C');
  rect(ctx, cx - 2, cy - 2, 4, 4, '#FFB8C8');
  const petalAng = wheelAngle;
  for (let p = 0; p < 4; p++) {
    const a = petalAng + (p * Math.PI) / 2;
    px(
      ctx,
      Math.round(cx + Math.cos(a) * 2),
      Math.round(cy + Math.sin(a) * 2),
      '#FFF5F7'
    );
  }
  px(ctx, cx, cy, '#FFE066');

  // Subtle pixel speed-arc lines near the top-back when sprinting turbo!
  if (Math.abs(wheelSpeed) > 8.5) {
    const flicker = Math.floor(wheelAngle * 4) % 2 === 0;
    if (flicker) {
      rect(ctx, cx - 16, cy - 17, 5, 1, '#FFFFFF');
      rect(ctx, cx + 10, cy - 18, 6, 1, '#FFE8B8');
    } else {
      rect(ctx, cx - 19, cy - 12, 4, 1, '#FFE8B8');
      rect(ctx, cx + 13, cy - 14, 5, 1, '#FFFFFF');
    }
  }
}

export function drawWheelFrontRim(ctx: CanvasRenderingContext2D, wheelAngle: number) {
  const { x: cx, y: cy, radius } = PROP_POS.wheel;
  // Subtle lower front-rim lip & rotating front accent dots so the hamster sits *inside* the wheel!
  for (let deg = 25; deg <= 155; deg += 5) {
    const rad = (deg * Math.PI) / 180;
    const fx = Math.round(cx + Math.cos(rad) * (radius - 1.5));
    const fy = Math.round(cy + Math.sin(rad) * (radius - 1.5));
    px(ctx, fx, fy, '#5A392C');
    const fxIn = Math.round(cx + Math.cos(rad) * (radius - 2.6));
    const fyIn = Math.round(cy + Math.sin(rad) * (radius - 2.6));
    px(ctx, fxIn, fyIn, '#FFD8B0');
  }
  // Tiny front tread glints passing across the bottom lip
  for (let i = 0; i < 6; i++) {
    const ang = ((wheelAngle + (i * Math.PI) / 3) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    if (ang > 0.35 && ang < Math.PI - 0.35) {
      const gx = Math.round(cx + Math.cos(ang) * (radius - 2.4));
      const gy = Math.round(cy + Math.sin(ang) * (radius - 2.4));
      px(ctx, gx, gy, '#FF9BB8');
    }
  }
}

export function drawTerrariumForeground(
  ctx: CanvasRenderingContext2D,
  bowlSeeds: number,
  waterLevel: number,
  treats: TreatItem[],
  nightMode: boolean,
  rainMode: boolean,
  wheelAngle: number
) {
  // Wheel front lip over lower track
  drawWheelFrontRim(ctx, wheelAngle);

  // Hanging Water Bottle (right side)
  drawWaterBottle(ctx, PROP_POS.bottle.x, PROP_POS.bottle.y, waterLevel);

  // Ceramic Food Bowl (front-right)
  drawFoodBowl(ctx, PROP_POS.bowl.x, PROP_POS.bowl.y, bowlSeeds);

  // Dropped Treats on bedding
  for (const t of treats) {
    drawTreat(ctx, t);
  }

  // Subtle sunbeam / cozy rainy window mist / night lamp glow overlay
  if (nightMode) {
    ctx.fillStyle = 'rgba(26, 22, 54, 0.22)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
  } else if (rainMode) {
    // Cozy warm-amber indoor snug atmosphere vs cool window rain
    ctx.fillStyle = 'rgba(130, 165, 210, 0.07)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
  } else {
    ctx.fillStyle = 'rgba(255, 250, 210, 0.08)';
    ctx.beginPath();
    ctx.moveTo(188, 20);
    ctx.lineTo(246, 20);
    ctx.lineTo(178, FLOOR_TOP_Y + 26);
    ctx.lineTo(106, FLOOR_TOP_Y + 26);
    ctx.closePath();
    ctx.fill();
  }
}

function drawWaterBottle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  waterLevel: number
) {
  rect(ctx, x - 3, y - 16, 12, 4, '#5A392C');
  rect(ctx, x - 2, y - 15, 10, 2, '#FFB5C8');

  rect(ctx, x - 4, y - 24, 14, 24, '#5A392C');
  rect(ctx, x - 3, y - 23, 12, 22, '#EBF9FF');

  const fillH = Math.max(2, Math.round((waterLevel / 100) * 18));
  rect(ctx, x - 3, y - 1 - fillH, 12, fillH, '#7CD4FF');
  rect(ctx, x - 3, y - 1 - fillH, 12, 2, '#B6EAFF');
  rect(ctx, x - 1, y - 21, 2, 18, '#FFFFFF');

  rect(ctx, x - 2, y, 10, 4, '#5A392C');
  rect(ctx, x - 1, y + 1, 8, 2, '#FF9CB5');
  rect(ctx, x - 6, y + 4, 7, 3, '#5A392C');
  rect(ctx, x - 8, y + 7, 5, 4, '#5A392C');
  rect(ctx, x - 5, y + 5, 5, 2, '#D7E3EB');
  rect(ctx, x - 7, y + 8, 4, 2, '#B8C8D4');
  px(ctx, x - 8, y + 11, '#7CD4FF');
}

function drawFoodBowl(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  bowlSeeds: number
) {
  const x = cx - 11;
  const y = baseY - 7;
  ctx.fillStyle = 'rgba(130, 96, 68, 0.25)';
  ctx.fillRect(x - 1, y + 8, 24, 2);

  rect(ctx, x, y, 22, 8, '#5A392C');
  rect(ctx, x + 2, y + 7, 18, 2, '#5A392C');
  rect(ctx, x + 1, y + 1, 20, 6, '#FF9EBB');
  rect(ctx, x + 1, y + 1, 20, 2, '#FFC4D6');
  rect(ctx, x + 3, y + 5, 16, 2, '#E57C9D');
  rect(ctx, x + 3, y + 1, 16, 2, '#7A4F3D');

  if (bowlSeeds > 0) {
    const count = Math.min(8, Math.ceil(bowlSeeds / 12));
    for (let i = 0; i < count; i++) {
      const sx = x + 4 + ((i * 3) % 13);
      const sy = y - (i >= 4 ? 1 : 0);
      px(ctx, sx, sy, i % 2 === 0 ? '#4F3C35' : '#D9CFC7');
      px(ctx, sx + 1, sy, i % 2 === 0 ? '#D9CFC7' : '#FFD54F');
    }
  }
}

function drawTreat(ctx: CanvasRenderingContext2D, t: TreatItem) {
  const x = Math.round(t.x);
  const y = Math.round(t.y);
  ctx.fillStyle = 'rgba(130, 96, 68, 0.25)';
  ctx.fillRect(x - 2, y + 2, 5, 1);

  if (t.type === 'strawberry') {
    rect(ctx, x - 3, y - 3, 6, 5, '#5A392C');
    rect(ctx, x - 2, y - 2, 4, 3, '#FF5478');
    px(ctx, x - 1, y - 1, '#FF9EB3');
    px(ctx, x + 1, y, '#FFE49E');
    rect(ctx, x - 2, y - 4, 4, 2, '#69D471');
  } else if (t.type === 'corn') {
    rect(ctx, x - 2, y - 2, 5, 4, '#5A392C');
    rect(ctx, x - 1, y - 1, 3, 2, '#FFD54F');
    px(ctx, x, y - 1, '#FFF3B0');
  } else {
    rect(ctx, x - 2, y - 2, 5, 4, '#5A392C');
    px(ctx, x - 1, y - 1, '#4A3A35');
    px(ctx, x, y - 1, '#E6DDD5');
    px(ctx, x + 1, y - 1, '#4A3A35');
    px(ctx, x - 1, y, '#E6DDD5');
    px(ctx, x, y, '#4A3A35');
  }
}

export function drawParticles(ctx: CanvasRenderingContext2D, particles: PixelParticle[]) {
  for (const p of particles) {
    const x = Math.round(p.x);
    const y = Math.round(p.y);
    const alpha = Math.min(1, p.life / (p.maxLife * 0.35));
    ctx.save();
    ctx.globalAlpha = Math.max(0.15, alpha);

    if (p.kind === 'heart') {
      drawMatrix(ctx, x - 3, y - 3, HEART_SPRITE, {
        R: p.color || '#FF6B93',
        W: '#FFE5EC',
      });
    } else if (p.kind === 'note') {
      drawMatrix(ctx, x - 2, y - 3, NOTE_SPRITE, { N: p.color || '#FF8CB0' });
    } else if (p.kind === 'zzz') {
      drawMatrix(ctx, x - 2, y - 2, ZZZ_SPRITE, { Z: p.color || '#9FB4FF' });
    } else if (p.kind === 'star') {
      drawMatrix(ctx, x - 2, y - 2, STAR_SPRITE, {
        S: p.color || '#FFE066',
        W: '#FFFFFF',
      });
    } else if (p.kind === 'sparkle') {
      const big = Math.floor(p.life * 8) % 2 === 0;
      px(ctx, x, y, '#FFFFFF');
      if (big) {
        px(ctx, x - 1, y, p.color);
        px(ctx, x + 1, y, p.color);
        px(ctx, x, y - 1, p.color);
        px(ctx, x, y + 1, p.color);
      }
    } else if (p.kind === 'fluff') {
      rect(ctx, x, y, 2, 2, p.color || '#FFF7EB');
    } else if (p.kind === 'exclaim') {
      rect(ctx, x - 2, y - 7, 5, 8, '#5A392C');
      rect(ctx, x - 1, y - 6, 3, 6, '#FFFDF7');
      rect(ctx, x, y - 5, 1, 3, '#FF5C8A');
      px(ctx, x, y - 1, '#FF5C8A');
    } else if (p.kind === 'question') {
      rect(ctx, x - 3, y - 7, 7, 8, '#5A392C');
      rect(ctx, x - 2, y - 6, 5, 6, '#FFFDF7');
      px(ctx, x - 1, y - 5, '#6C8CE8');
      px(ctx, x, y - 5, '#6C8CE8');
      px(ctx, x + 1, y - 4, '#6C8CE8');
      px(ctx, x, y - 3, '#6C8CE8');
      px(ctx, x, y - 1, '#6C8CE8');
    } else {
      const sz = p.size || 1;
      rect(ctx, x, y, sz, sz, p.color);
    }
    ctx.restore();
  }
}

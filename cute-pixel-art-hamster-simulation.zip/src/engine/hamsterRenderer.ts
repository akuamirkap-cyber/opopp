import { HamsterCoat, HamsterEntity } from '../types/hamster';
import { PixelSpriteBuffer } from './pixelPrimitives';

const PAW_PINK = '#FFB8C8';
const PAW_SHADOW = '#E594A8';
const EYE_SHINE = '#FFFFFF';
const EYE_GLINT = '#FFD9E8';
const SEED_DARK = '#4F3C35';
const SEED_STRIPE = '#D9CFC7';
const BERRY_RED = '#FF5E7E';
const BERRY_LEAF = '#6BD472';
const CORN_GOLD = '#FFD54F';

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

export function drawHamster(
  ctx: CanvasRenderingContext2D,
  hamster: HamsterEntity,
  coat: HamsterCoat,
  timeSec: number,
  showSelectionMarker = false
) {
  const buf = new PixelSpriteBuffer(56, 48);
  const cx = 28;
  const frame = Math.floor(hamster.animFrame);
  const breath = Math.sin(timeSec * 3.1 + hamster.id) > 0.35 ? 1 : 0;

  const isSleeping = hamster.state === 'sleep';
  const isPetted = hamster.state === 'petted';
  const isStanding = hamster.state === 'stand' || hamster.state === 'drink';
  const isRunning = hamster.state === 'run_wheel';
  const isWalking = hamster.state === 'walk';
  const isEating = hamster.state === 'eat';
  const isStuffing = hamster.state === 'stuff_cheek';
  const isUnloading = hamster.state === 'unload_stash';
  const isGrooming = hamster.state === 'groom';
  const isDigging = hamster.state === 'dig';
  const isYawning = hamster.state === 'yawn';
  const isDizzy = hamster.state === 'dizzy';
  const isStretching = hamster.state === 'stretch';
  const isShaking = hamster.state === 'shake';
  const isHappyHop = hamster.state === 'happy_hop';

  const { phys, chubbyLevel } = hamster;
  const squash = clamp(phys.squashY, -0.85, 1.45);
  const localShear = clamp(phys.furShearX * hamster.facing, -2.5, 2.5);
  const shearPx = Math.round(localShear);
  const earOffsetL = Math.round(clamp(phys.earBounceL, -2.2, 2.2));
  const earOffsetR = Math.round(clamp(phys.earBounceR, -2.2, 2.2));
  const cheekJig = clamp(phys.cheekJiggle, -0.8, 1.5);
  const tailLag = Math.round(clamp(phys.tailWag, -2, 2));

  // Chubby / Gembrot multipliers!
  const chonkyRx = chubbyLevel === 2 ? 4.0 : chubbyLevel === 1 ? 2.1 : 0;
  const chonkyRy = chubbyLevel === 2 ? 2.2 : chubbyLevel === 1 ? 1.1 : 0;
  const chonkyCheek = chubbyLevel === 2 ? 1.8 : chubbyLevel === 1 ? 0.9 : 0;

  const cheekExtra = Math.min(4, hamster.stats.cheekPuff) + (isShaking ? 0.8 : 0);
  const squishY = (isSleeping ? 2 : isPetted ? 1.5 : 0) + squash * 1.45;
  const squishX = (isSleeping ? 2 : isPetted ? 1.5 : 0) + squash * 1.65;

  // Ground shadow under hamster (wider for gembrot hamsters!)
  const airFactor = clamp(Math.abs(hamster.hopOffset) / 14, 0, 0.55);
  const shadowW = Math.max(
    6,
    Math.round(
      ((isSleeping ? 14 : isStretching ? 15 : isStanding ? 9.5 : 12) +
        chonkyRx +
        cheekExtra * 0.55) *
        (1 - airFactor * 0.4)
    )
  );
  const shadowY = Math.round(hamster.y + 1);
  if (!isRunning) {
    ctx.fillStyle = 'rgba(130, 96, 68, 0.24)';
    ctx.fillRect(Math.round(hamster.x - shadowW), shadowY, shadowW * 2, 2);
    ctx.fillStyle = 'rgba(130, 96, 68, 0.13)';
    ctx.fillRect(Math.round(hamster.x - shadowW - 1), shadowY, shadowW * 2 + 2, 1);
  }

  // Local coordinate baseline inside 56x48 buffer (feet at y = 42)
  const baseFeetY = 42;
  const runCycle = frame % 4;
  const bobY =
    isWalking
      ? frame % 2 === 0
        ? -1
        : 0
      : isRunning
      ? runCycle === 1 || runCycle === 3
        ? -1
        : 0
      : isSleeping
      ? breath
      : isDigging
      ? frame % 2 === 0
        ? 1
        : 0
      : 0;

  // Center of torso & head with soft secondary physics shear + gembrot roundness!
  const bodyCx = cx - (isStretching ? 1 : 0);
  let bodyCy =
    baseFeetY -
    7 -
    Math.round(chonkyRy * 0.45) +
    Math.round(squishY * 0.7) +
    bobY +
    (isStretching ? 2 : 0);
  let headCx =
    cx +
    (isRunning ? 3 : isDigging ? 2 : isStretching ? 4 : 1) +
    shearPx;
  let headCy =
    bodyCy -
    (isStanding ? 9 : isSleeping ? 3 : isStretching ? 3 : 6) +
    Math.round(squash * 0.6);

  if (isStanding) {
    bodyCy = baseFeetY - 8 - Math.round(chonkyRy * 0.35) + Math.round(squishY * 0.5);
    headCy = bodyCy - 9 + Math.round(squash * 0.4);
  }

  // ---- 1) COTTON-BALL FLUFFY TAIL ----
  const tailX =
    bodyCx -
    (isSleeping ? 11 : isStretching ? 13 : 10) -
    Math.round(chonkyRx) -
    Math.round(squishX) -
    Math.round(shearPx * 0.4);
  const tailY = bodyCy + (isDigging ? -2 : isRunning ? 1 : 2) + tailLag;
  buf.fillCircle(tailX, tailY, 2.4, coat.belly);
  buf.set(tailX - 2, tailY - 1, coat.belly);
  buf.set(tailX - 2, tailY, coat.furLight);

  // ---- 2) BACK EAR ----
  const earTwitch = hamster.earTwitchTimer > 0 && frame % 2 === 0 ? 1 : 0;
  const backEarX = headCx + 4 + Math.round(localShear * 0.35);
  const backEarY = headCy - 7 + earOffsetR + (isRunning || isPetted ? 1 : 0);
  buf.fillEllipse(backEarX, backEarY, 2.7, 2.9, coat.earOuter);
  buf.set(backEarX, backEarY, coat.earInner);
  buf.set(backEarX + 1, backEarY, coat.earInner);

  // ---- 3) TORSO (Extra Plump Mochi Loaf when Gemuk/Gembrot!) ----
  const bodyRx = clamp(
    (isStanding ? 8.2 : isStretching ? 11.4 : 9.6) +
      chonkyRx +
      squishX +
      (isShaking ? 1.1 : 0),
    7.0,
    16.2
  );
  const bodyRy = clamp(
    (isStanding ? 8.6 : isStretching ? 5.8 : 7.5) +
      chonkyRy -
      squishY * 0.5,
    4.8,
    12.0
  );
  buf.fillEllipse(bodyCx - 1, bodyCy, bodyRx, bodyRy, coat.furBase);

  // Extra lower chonky belly roll for Super Gembrot!
  if (chubbyLevel >= 1 && !isStretching) {
    buf.fillEllipse(
      bodyCx,
      bodyCy + 2.2,
      bodyRx * 0.94,
      bodyRy * 0.72,
      coat.furBase
    );
  }

  // Fluffy rump tufts
  const rumpX = bodyCx - Math.round(bodyRx) - 1;
  buf.set(rumpX, bodyCy, coat.furLight);
  buf.set(rumpX, bodyCy + 2, coat.furBase);
  buf.set(rumpX + 1, bodyCy + 4, coat.furShadow);
  if (isShaking || cheekExtra > 1 || chubbyLevel > 0) {
    buf.set(rumpX - 1, bodyCy + 1, coat.furBase);
  }

  // ---- 4) HEAD & EXTRA-STUFFABLE FLUFFY CHEEKS ----
  const headRx = clamp(
    8.4 + chonkyRx * 0.35 + squishX * 0.5 + (isShaking ? 0.8 : 0),
    7.2,
    12.8
  );
  const headRy = clamp(7.2 + chonkyRy * 0.2 - squishY * 0.45, 5.5, 9.6);
  buf.fillEllipse(headCx, headCy, headRx, headRy, coat.furBase);

  // Huge adorable stuffed cheek pouches!
  const puff = cheekExtra * 0.95 + chonkyCheek + cheekJig * 0.65;
  const puffBump = isStuffing && frame % 2 === 0 ? 0.8 : 0;
  buf.fillEllipse(
    headCx - 4.2 - puff * 0.6,
    headCy + 2.6 + squash * 0.35,
    4.9 + puff + puffBump,
    4.3 + puff * 0.55 + puffBump * 0.5,
    coat.furBase
  );
  buf.fillEllipse(
    headCx + 4.2 + puff * 0.55,
    headCy + 2.5 + squash * 0.35,
    4.5 + puff * 0.85 + puffBump,
    4.0 + puff * 0.48 + puffBump * 0.5,
    coat.furBase
  );

  // Cute fur tufts on stuffed cheeks & swaying crown curl
  const cheekEdgeL = Math.round(headCx - 9 - puff);
  buf.set(cheekEdgeL, headCy + 1, coat.furLight);
  buf.set(cheekEdgeL, headCy + 3, coat.furBase);
  buf.set(cheekEdgeL + 1, headCy + 5, coat.furShadow);

  if (!isSleeping) {
    const tuftShift = Math.round(localShear * 0.6);
    buf.set(headCx - 1 + tuftShift, headCy - 8, coat.furLight);
    buf.set(headCx + tuftShift, headCy - 8, coat.furBase);
    buf.set(headCx - 2 + tuftShift, headCy - 7, coat.furLight);
  }

  // ---- 5) COAT SHADING, HIGHLIGHTS, PATCHES & CREAM BELLY ----
  buf.paintIfFilled(bodyCx - 5, bodyCy + 4, bodyRx * 0.88, bodyRy * 0.72, coat.furShadow);

  if (coat.id === 'taro-boba' && coat.stripe) {
    buf.paintIfFilled(bodyCx - 5, bodyCy - 3, 4.5 + chonkyRx * 0.3, 2.2, coat.stripe);
    buf.paintIfFilled(headCx - 2, headCy - 5, 2.2, 2.6, coat.stripe);
  } else if (coat.id === 'choco-panda' && coat.stripe) {
    buf.paintIfFilled(bodyCx - 5, bodyCy - 1, 5.2 + chonkyRx * 0.4, 4.8 + chonkyRy * 0.4, coat.stripe);
    buf.paintIfFilled(headCx + 3, headCy - 1, 3.4, 3.2, coat.stripe);
    buf.paintIfFilled(headCx - 5, headCy - 1, 3.1, 3.0, coat.stripe);
  }

  buf.paintIfFilled(headCx - 2, headCy - 4, 4.5, 2.4, coat.furLight);
  buf.paintIfFilled(bodyCx - 3, bodyCy - 4, 4.8 + chonkyRx * 0.3, 2.2, coat.furLight);

  // Creamy soft belly & chin patch (expands nicely for chonky/gembrot!)
  const bellyCx = bodyCx + 2;
  const bellyCy = bodyCy + 2;
  buf.paintIfFilled(
    bellyCx,
    bellyCy,
    6.4 + chonkyRx * 0.75 + squishX * 0.5,
    5.6 + chonkyRy * 0.75 - squishY * 0.4,
    coat.belly
  );
  buf.paintIfFilled(headCx + 2, headCy + 4, 5.6 + puff * 0.6, 2.8 + chonkyCheek * 0.3, coat.belly);
  buf.paintIfFilled(bellyCx, bodyCy + 6 + chonkyRy * 0.4, 5.4 + chonkyRx * 0.5, 2.2, coat.bellyShadow);

  // Subtle cute cheek-pouch highlight when stuffed full of treats!
  if (cheekExtra >= 2) {
    buf.set(Math.round(headCx - 6 - puff * 0.4), headCy + 2, coat.furLight);
    buf.set(Math.round(headCx + 7 + puff * 0.35), headCy + 2, coat.furLight);
  }

  // ---- 6) FRONT EAR ----
  const frontEarX = headCx - 5 + Math.round(localShear * 0.35);
  const frontEarY = headCy - 6 - earTwitch + earOffsetL + (isRunning || isPetted ? 1 : 0);
  buf.fillEllipse(frontEarX, frontEarY, 2.8, 3.1, coat.earOuter);
  buf.set(frontEarX, frontEarY, coat.earInner);
  buf.set(frontEarX + 1, frontEarY, coat.earInner);
  buf.set(frontEarX, frontEarY + 1, coat.earInner);
  buf.set(frontEarX, frontEarY + 3, coat.furShadow);

  // ---- 7) ROSY SHIMMER BLUSH CHEEKS ----
  const blushIntensity = isPetted || isEating || isStuffing || isUnloading || isHappyHop ? 1 : 0;
  const blushLeftX = headCx - 3 - Math.round(puff * 0.3);
  const blushRightX = headCx + 6 + Math.round(puff * 0.3);
  const blushY = headCy + 2;

  buf.set(blushLeftX, blushY, coat.blush);
  buf.set(blushLeftX + 1, blushY, coat.blush);
  buf.set(blushLeftX + 2, blushY, coat.blush);
  buf.set(blushLeftX + 1, blushY + 1, coat.blush);
  if (blushIntensity > 0) {
    buf.set(blushLeftX, blushY + 1, coat.blush);
    buf.set(blushLeftX + 2, blushY + 1, coat.blush);
    buf.set(blushLeftX + 1, blushY, '#FFC2D1');
  }

  buf.set(blushRightX, blushY, coat.blush);
  buf.set(blushRightX + 1, blushY, coat.blush);
  if (blushIntensity > 0) {
    buf.set(blushRightX, blushY + 1, coat.blush);
  }

  // ---- 8) EXPRESSIVE DOUBLE-SPARKLE BOBA EYES ----
  const eyeLeftX = headCx - 1;
  const eyeRightX = headCx + 5;
  const eyeY = headCy - 1;

  if (isSleeping || isStretching) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY + 2, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 2, coat.outline);
    buf.set(eyeRightX + 2, eyeY + 1, coat.outline);
  } else if (
    isPetted ||
    isGrooming ||
    isYawning ||
    isHappyHop ||
    isUnloading ||
    (isRunning && frame % 8 < 2)
  ) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY, coat.outline);
    buf.set(eyeRightX + 2, eyeY + 1, coat.outline);
  } else if (isDizzy || isShaking) {
    buf.set(eyeLeftX - 1, eyeY, coat.outline);
    buf.set(eyeLeftX, eyeY + 1, coat.outline);
    buf.set(eyeLeftX - 1, eyeY + 2, coat.outline);

    buf.set(eyeRightX + 1, eyeY, coat.outline);
    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 2, coat.outline);
  } else if (hamster.isBlinking) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY + 1, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 1, coat.outline);
  } else {
    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 3; dx++) {
        if ((dx === 0 && dy === 2) || (dx === 2 && dy === 2)) continue;
        buf.set(eyeLeftX - 1 + dx, eyeY - 1 + dy, coat.eye);
      }
    }
    buf.set(eyeLeftX - 1, eyeY - 1, EYE_SHINE);
    buf.set(eyeLeftX + 1, eyeY + 1, EYE_GLINT);

    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 2; dx++) {
        buf.set(eyeRightX + dx, eyeY - 1 + dy, coat.eye);
      }
    }
    buf.set(eyeRightX, eyeY - 1, EYE_SHINE);
    buf.set(eyeRightX + 1, eyeY + 1, EYE_GLINT);
  }

  // ---- 9) TWITCHY PINK NOSE, TINY WHISKERS & CUTE MOUTH ----
  const sniffBob =
    hamster.state === 'idle' || hamster.state === 'stand'
      ? frame % 4 === 0
        ? -1
        : 0
      : 0;
  const noseX = headCx + 3;
  const noseY = headCy + 1 + sniffBob;
  buf.set(noseX, noseY, coat.nose);
  buf.set(noseX + 1, noseY, coat.nose);

  if (!isSleeping) {
    buf.set(headCx - 6 - Math.round(puff * 0.4), headCy + 2 + sniffBob, coat.furLight);
    buf.set(headCx + 8 + Math.round(puff * 0.3), headCy + 1 + sniffBob, coat.furLight);
  }

  if (isYawning || isStuffing) {
    buf.set(noseX, noseY + 2, '#D95D7A');
    buf.set(noseX + 1, noseY + 2, '#D95D7A');
    buf.set(noseX, noseY + 3, '#FF9CB2');
    buf.set(noseX + 1, noseY + 3, '#FF9CB2');
  } else if (isEating || isUnloading) {
    if (frame % 2 === 0) {
      buf.set(noseX, noseY + 2, '#D95D7A');
      buf.set(noseX + 1, noseY + 2, '#D95D7A');
    } else {
      buf.set(noseX, noseY + 2, coat.outline);
    }
  } else if (!isSleeping) {
    if (isHappyHop || isPetted) {
      buf.set(noseX, noseY + 2, '#FF7596');
      buf.set(noseX + 1, noseY + 2, '#FF7596');
      buf.set(noseX - 1, noseY + 1, coat.outline);
      buf.set(noseX + 2, noseY + 1, coat.outline);
    } else {
      buf.set(noseX - 1, noseY + 2, coat.outline);
      buf.set(noseX + 1, noseY + 2, coat.outline);
      buf.set(noseX, noseY + 1, coat.outline);
    }
  }

  // ---- 10) TINY PINK FEET & EXPRESSIVE PAWS ----
  if (!isSleeping) {
    const footY = baseFeetY - 1;
    if (isRunning) {
      const backLegA = [
        { dx: -2, dy: 0 },
        { dx: 1, dy: -1 },
        { dx: 3, dy: 0 },
        { dx: 0, dy: 0 },
      ][runCycle];
      const backLegB = [
        { dx: 3, dy: 0 },
        { dx: 0, dy: 0 },
        { dx: -2, dy: 0 },
        { dx: 1, dy: -1 },
      ][runCycle];

      buf.set(bodyCx - 4 + backLegA.dx, footY + backLegA.dy, PAW_PINK);
      buf.set(bodyCx - 3 + backLegA.dx, footY + backLegA.dy, PAW_PINK);
      buf.set(bodyCx - 5 + backLegA.dx, footY + backLegA.dy, PAW_SHADOW);

      buf.set(bodyCx + 2 + backLegB.dx, footY + backLegB.dy, PAW_PINK);
      buf.set(bodyCx + 3 + backLegB.dx, footY + backLegB.dy, PAW_PINK);
      buf.set(bodyCx + 1 + backLegB.dx, footY + backLegB.dy, PAW_SHADOW);
    } else if (isHappyHop) {
      buf.set(bodyCx - 5, footY - 1, PAW_PINK);
      buf.set(bodyCx - 4, footY - 1, PAW_PINK);
      buf.set(bodyCx + 3, footY - 1, PAW_PINK);
      buf.set(bodyCx + 4, footY - 1, PAW_PINK);
    } else if (isStretching) {
      buf.set(bodyCx - 9, footY, PAW_PINK);
      buf.set(bodyCx - 8, footY, PAW_PINK);
    } else {
      const stepA = isWalking ? (frame % 2 === 0 ? -2 : 2) : 0;
      const stepB = isWalking ? (frame % 2 === 0 ? 2 : -2) : 0;

      buf.set(bodyCx - 4 + stepA, footY, PAW_PINK);
      buf.set(bodyCx - 3 + stepA, footY, PAW_PINK);
      buf.set(bodyCx - 5 + stepA, footY, PAW_SHADOW);

      buf.set(bodyCx + 3 + stepB, footY, PAW_PINK);
      buf.set(bodyCx + 4 + stepB, footY, PAW_PINK);
      buf.set(bodyCx + 2 + stepB, footY, PAW_SHADOW);
    }
  }

  // Front tiny paws (pose-dependent!)
  if (isEating || isStuffing) {
    const nibbleBob = frame % 2 === 0 ? 0 : 1;
    const treatX = headCx + 4;
    const treatY = headCy + (isStuffing ? 3 : 4) + nibbleBob;

    if (hamster.activeSnack === 'strawberry') {
      buf.set(treatX, treatY, BERRY_RED);
      buf.set(treatX + 1, treatY, BERRY_RED);
      buf.set(treatX, treatY + 1, BERRY_RED);
      buf.set(treatX + 1, treatY + 1, '#FF8FA6');
      buf.set(treatX, treatY - 1, BERRY_LEAF);
    } else if (hamster.activeSnack === 'corn') {
      buf.set(treatX, treatY, CORN_GOLD);
      buf.set(treatX + 1, treatY, '#FFE57F');
      buf.set(treatX, treatY + 1, CORN_GOLD);
    } else {
      buf.set(treatX, treatY, SEED_DARK);
      buf.set(treatX + 1, treatY, SEED_STRIPE);
      buf.set(treatX, treatY + 1, SEED_STRIPE);
      buf.set(treatX + 1, treatY + 1, SEED_DARK);
    }

    buf.set(treatX - 1, treatY + 1, PAW_PINK);
    buf.set(treatX + 2, treatY + 1, PAW_PINK);
    buf.set(treatX - 1, treatY + 2, PAW_SHADOW);
    buf.set(treatX + 2, treatY + 2, PAW_SHADOW);
  } else if (isUnloading) {
    // Both paws squishing puffy cheeks inward to empty stash!
    const push = frame % 2 === 0 ? 1 : 0;
    buf.set(headCx - 3 + push, headCy + 3, PAW_PINK);
    buf.set(headCx - 2 + push, headCy + 3, PAW_PINK);
    buf.set(headCx + 5 - push, headCy + 3, PAW_PINK);
    buf.set(headCx + 6 - push, headCy + 3, PAW_PINK);
  } else if (isGrooming) {
    const scrub = frame % 2 === 0 ? 0 : -1;
    buf.set(headCx - 1, headCy + 2 + scrub, PAW_PINK);
    buf.set(headCx, headCy + 2 + scrub, PAW_PINK);
    buf.set(headCx + 4, headCy + 3 - scrub, PAW_PINK);
    buf.set(headCx + 5, headCy + 3 - scrub, PAW_PINK);
  } else if (isStanding || isHappyHop) {
    const raise = isHappyHop ? -2 : 0;
    buf.set(bodyCx + 2, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 3, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 6, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 2 + raise, PAW_PINK);
  } else if (isStretching) {
    buf.set(bodyCx + 9, baseFeetY - 1, PAW_PINK);
    buf.set(bodyCx + 10, baseFeetY - 1, PAW_PINK);
    buf.set(bodyCx + 11, baseFeetY - 1, PAW_SHADOW);
  } else if (isDigging) {
    const digF = frame % 2 === 0 ? 1 : -1;
    buf.set(bodyCx + 6, bodyCy + 3 + digF, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy + 3 + digF, PAW_PINK);
    buf.set(bodyCx + 8, bodyCy + 2 - digF, PAW_PINK);
  } else if (isRunning) {
    const frontPawA = [
      { dx: 7, dy: 2 },
      { dx: 8, dy: 1 },
      { dx: 6, dy: 0 },
      { dx: 5, dy: 1 },
    ][runCycle];
    buf.set(bodyCx + frontPawA.dx, bodyCy + frontPawA.dy, PAW_PINK);
    buf.set(bodyCx + frontPawA.dx + 1, bodyCy + frontPawA.dy, PAW_PINK);
    buf.set(bodyCx + 5, bodyCy + 2, PAW_SHADOW);
  } else if (!isSleeping) {
    const pawOut = Math.round(chonkyRx * 0.45);
    buf.set(bodyCx + 1 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 2 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 5 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 6 + pawOut, bodyCy + 2, PAW_PINK);
  }

  // Stamp buffer onto virtual canvas centered on (hamster.x, hamster.y)
  const destX = Math.round(hamster.x - cx);
  const destY = Math.round(hamster.y - baseFeetY + hamster.hopOffset);
  buf.flush(ctx, destX, destY, coat.outline, hamster.facing === -1);

  // Subtle floating pastel arrow over currently selected hamster when multiple hamsters exist
  if (showSelectionMarker) {
    const bob = Math.round(Math.sin(timeSec * 5) * 1.5);
    const mx = Math.round(hamster.x);
    const my = Math.round(hamster.y - 29 + hamster.hopOffset + bob - chonkyRy);
    ctx.fillStyle = '#5A392C';
    ctx.fillRect(mx - 2, my - 2, 5, 2);
    ctx.fillRect(mx - 1, my, 3, 1);
    ctx.fillRect(mx, my + 1, 1, 1);
    ctx.fillStyle = '#FF7DA3';
    ctx.fillRect(mx - 1, my - 1, 3, 1);
    ctx.fillRect(mx, my, 1, 1);
  }
}

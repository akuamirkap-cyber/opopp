export function px(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
}

export function rect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

export function drawMatrix(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rows: string[],
  palette: Record<string, string>,
  flipX = false
) {
  const rx = Math.round(x);
  const ry = Math.round(y);
  for (let row = 0; row < rows.length; row++) {
    const line = rows[row];
    for (let col = 0; col < line.length; col++) {
      const ch = line[col];
      if (ch === '.' || ch === ' ') continue;
      const color = palette[ch];
      if (!color) continue;
      const drawX = flipX ? rx + (line.length - 1 - col) : rx + col;
      ctx.fillStyle = color;
      ctx.fillRect(drawX, ry + row, 1, 1);
    }
  }
}

/**
 * Mini integer pixel buffer that lets us compose overlapping fluffy shapes
 * (ears, chubby cheeks, pear body, tail, paws) and automatically apply a crisp
 * 1px 16-bit pixel outline around the combined silhouette!
 */
export class PixelSpriteBuffer {
  public readonly w: number;
  public readonly h: number;
  private grid: (string | null)[][];
  private outlineMask: boolean[][];

  constructor(w: number, h: number) {
    this.w = w;
    this.h = h;
    this.grid = Array.from({ length: h }, () => Array<string | null>(w).fill(null));
    this.outlineMask = Array.from({ length: h }, () => Array<boolean>(w).fill(false));
  }

  public set(x: number, y: number, color: string, outlineable = true) {
    const ix = Math.round(x);
    const iy = Math.round(y);
    if (ix < 0 || ix >= this.w || iy < 0 || iy >= this.h) return;
    this.grid[iy][ix] = color;
    if (outlineable) {
      this.outlineMask[iy][ix] = true;
    }
  }

  public has(x: number, y: number): boolean {
    const ix = Math.round(x);
    const iy = Math.round(y);
    if (ix < 0 || ix >= this.w || iy < 0 || iy >= this.h) return false;
    return this.grid[iy][ix] !== null;
  }

  public fillEllipse(
    cx: number,
    cy: number,
    rx: number,
    ry: number,
    color: string,
    outlineable = true
  ) {
    const x0 = Math.floor(cx - rx - 1);
    const x1 = Math.ceil(cx + rx + 1);
    const y0 = Math.floor(cy - ry - 1);
    const y1 = Math.ceil(cy + ry + 1);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1.0) {
          this.set(x, y, color, outlineable);
        }
      }
    }
  }

  public fillCircle(
    cx: number,
    cy: number,
    r: number,
    color: string,
    outlineable = true
  ) {
    this.fillEllipse(cx, cy, r, r, color, outlineable);
  }

  public paintIfFilled(
    cx: number,
    cy: number,
    rx: number,
    ry: number,
    color: string
  ) {
    const x0 = Math.floor(cx - rx - 1);
    const x1 = Math.ceil(cx + rx + 1);
    const y0 = Math.floor(cy - ry - 1);
    const y1 = Math.ceil(cy + ry + 1);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        if (x < 0 || x >= this.w || y < 0 || y >= this.h) continue;
        if (this.grid[y][x] === null) continue;
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1.0) {
          this.grid[y][x] = color;
        }
      }
    }
  }

  public flush(
    ctx: CanvasRenderingContext2D,
    destX: number,
    destY: number,
    outlineColor: string,
    flipX = false
  ) {
    const ox = Math.round(destX);
    const oy = Math.round(destY);

    // 1) Draw 4-connected crisp pixel outline around outlineMask pixels
    ctx.fillStyle = outlineColor;
    for (let y = 0; y < this.h; y++) {
      for (let x = 0; x < this.w; x++) {
        if (this.grid[y][x] !== null) continue;
        const n = y > 0 && this.outlineMask[y - 1][x];
        const s = y < this.h - 1 && this.outlineMask[y + 1][x];
        const w = x > 0 && this.outlineMask[y][x - 1];
        const e = x < this.w - 1 && this.outlineMask[y][x + 1];
        if (n || s || w || e) {
          const pxX = flipX ? ox + (this.w - 1 - x) : ox + x;
          ctx.fillRect(pxX, oy + y, 1, 1);
        }
      }
    }

    // 2) Draw filled pixels
    for (let y = 0; y < this.h; y++) {
      for (let x = 0; x < this.w; x++) {
        const col = this.grid[y][x];
        if (!col) continue;
        const pxX = flipX ? ox + (this.w - 1 - x) : ox + x;
        ctx.fillStyle = col;
        ctx.fillRect(pxX, oy + y, 1, 1);
      }
    }
  }
}

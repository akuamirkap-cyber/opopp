import { HAMSTER_COATS } from '../data/hamsterCoats';
import {
  ChubbyLevel,
  HamsterEntity,
  HamsterStats,
  PixelParticle,
  SoftPhysicsState,
  TreatItem,
  TreatKind,
} from '../types/hamster';
import { pixelSound } from '../utils/pixelSound';
import { FLOOR_BOTTOM_Y, FLOOR_TOP_Y, PROP_POS, VIRTUAL_W } from './terrariumRenderer';

const EXTRA_NAMES = ['Boba', 'Pudding', 'Berry', 'Matcha', 'Koko', 'Choco', 'Yuzu', 'Kuma'];

export interface SimWorld {
  hamsters: HamsterEntity[];
  selectedHamsterId: number;
  treats: TreatItem[];
  iglooStash: TreatKind[];
  particles: PixelParticle[];
  bowlSeeds: number;
  waterLevel: number;
  cleanliness: number;
  nightMode: boolean;
  rainMode: boolean;
  wheelAngle: number;
  wheelSpeed: number;
  nextId: number;
  globalStatusText: string;
}

function createInitialPhysics(): SoftPhysicsState {
  return {
    squashY: 0,
    squashVelY: 0,
    furShearX: 0,
    furShearVelX: 0,
    earBounceL: 0,
    earVelL: 0,
    earBounceR: 0,
    earVelR: 0,
    cheekJiggle: 0,
    cheekVel: 0,
    tailWag: 0,
    tailVel: 0,
  };
}

export function createHamsterEntity(
  id: number,
  name: string,
  coatId: string,
  x: number,
  y: number
): HamsterEntity {
  return {
    id,
    name,
    coatId,
    chubbyLevel: 0,
    storedPouch: [],
    activeSnack: null,
    stats: {
      hunger: 78,
      happiness: 84,
      energy: 86,
      cleanliness: 94,
      cheekPuff: 0,
      affection: 12,
    },
    x,
    y,
    vx: 0,
    vy: 0,
    facing: Math.random() < 0.5 ? 1 : -1,
    state: 'idle',
    stateTimer: 1.3 + Math.random() * 1.2,
    animFrame: Math.random() * 10,
    blinkTimer: 1.5 + Math.random() * 2.5,
    isBlinking: false,
    earTwitchTimer: 0,
    targetX: null,
    targetY: null,
    targetTreatId: null,
    targetStashEat: false,
    wheelAngle: 0,
    wheelSpeed: 0,
    wheelPhase: 'none',
    wheelSwing: 0,
    wheelSwingVel: 0,
    squish: 0,
    hopOffset: 0,
    hopVel: 0,
    socialCooldown: 4,
    phys: createInitialPhysics(),
    statusText: `${name} mengendus udara dengan hidung mungilnya~`,
  };
}

export function spawnParticle(
  world: SimWorld,
  kind: PixelParticle['kind'],
  x: number,
  y: number,
  color: string,
  vx = 0,
  vy = -12,
  life = 1.1,
  size = 1
) {
  world.particles.push({
    id: world.nextId++,
    kind,
    x,
    y,
    vx,
    vy,
    life,
    maxLife: life,
    color,
    size,
  });
}

export function applySquishImpulse(
  hamster: HamsterEntity,
  squashImpulse: number,
  shearImpulse = 0
) {
  hamster.phys.squashVelY += squashImpulse;
  hamster.phys.furShearVelX += shearImpulse;
  hamster.phys.earVelL += Math.abs(squashImpulse) * 0.65;
  hamster.phys.earVelR += Math.abs(squashImpulse) * 0.85;
  hamster.phys.cheekVel += Math.abs(squashImpulse) * 0.55;
  hamster.phys.tailVel -= squashImpulse * 0.4;
}

export function triggerHappyHop(
  world: SimWorld,
  hamster: HamsterEntity,
  text?: string
) {
  hamster.state = 'happy_hop';
  hamster.stateTimer = 0.85;
  hamster.hopVel = -52;
  hamster.phys.squashVelY = -5.2;
  hamster.phys.earVelL = -6.0;
  hamster.phys.earVelR = -7.2;
  if (text) {
    hamster.statusText = text;
    world.globalStatusText = text;
  }
  spawnParticle(world, 'heart', hamster.x - 5, hamster.y - 25, '#FF6B93', -8, -18, 1.1);
  spawnParticle(world, 'star', hamster.x + 6, hamster.y - 26, '#FFE066', 8, -18, 1.0);
}

export function createInitialWorld(hamsterName: string, coatId: string): SimWorld {
  const first = createHamsterEntity(1, hamsterName, coatId, 148, 146);
  return {
    hamsters: [first],
    selectedHamsterId: 1,
    treats: [],
    iglooStash: [],
    particles: [],
    bowlSeeds: 85,
    waterLevel: 94,
    cleanliness: 94,
    nightMode: false,
    rainMode: false,
    wheelAngle: 0,
    wheelSpeed: 0,
    nextId: 2,
    globalStatusText: first.statusText,
  };
}

export function getSelectedHamster(world: SimWorld): HamsterEntity {
  return (
    world.hamsters.find((h) => h.id === world.selectedHamsterId) ||
    world.hamsters[0]
  );
}

export function spawnExtraHamster(world: SimWorld): HamsterEntity | null {
  if (world.hamsters.length >= 5) return null;

  const usedCoats = new Set(world.hamsters.map((h) => h.coatId));
  const availableCoats = HAMSTER_COATS.filter((c) => !usedCoats.has(c.id));
  const coatPool = availableCoats.length > 0 ? availableCoats : HAMSTER_COATS;
  const chosenCoat = coatPool[Math.floor(Math.random() * coatPool.length)];

  const usedNames = new Set(world.hamsters.map((h) => h.name));
  const availableNames = EXTRA_NAMES.filter((n) => !usedNames.has(n));
  const chosenName =
    availableNames.length > 0
      ? availableNames[Math.floor(Math.random() * availableNames.length)]
      : `Mochi ${world.hamsters.length + 1}`;

  const x = 70 + Math.random() * 145;
  const y = FLOOR_TOP_Y + 12 + Math.random() * 20;
  const newHam = createHamsterEntity(
    world.nextId++,
    chosenName,
    chosenCoat.id,
    x,
    y
  );
  newHam.hopOffset = -28;
  newHam.hopVel = 15;
  newHam.state = 'happy_hop';
  newHam.stateTimer = 1.0;
  newHam.statusText = `${chosenName} (${chosenCoat.name}) baru saja bergabung ke kandang! Halo semuanya~`;

  world.hamsters.push(newHam);
  world.selectedHamsterId = newHam.id;
  world.globalStatusText = newHam.statusText;

  for (let i = 0; i < 8; i++) {
    spawnParticle(
      world,
      i % 2 === 0 ? 'heart' : 'star',
      x + (Math.random() * 20 - 10),
      y - 18 - Math.random() * 10,
      i % 2 === 0 ? '#FF6B93' : '#FFE066',
      (Math.random() - 0.5) * 28,
      -20 - Math.random() * 12,
      1.2
    );
  }
  pixelSound.playSpawnPop();
  return newHam;
}

export function cycleChubbyMode(
  world: SimWorld,
  hamsterId?: number
): ChubbyLevel {
  const ham =
    (hamsterId !== undefined
      ? world.hamsters.find((h) => h.id === hamsterId)
      : null) || getSelectedHamster(world);

  const nextLevel = (((ham.chubbyLevel + 1) % 3) as ChubbyLevel);
  ham.chubbyLevel = nextLevel;

  // Big squishy mochi bounce!
  applySquishImpulse(ham, nextLevel === 0 ? -5.5 : 8.5, 0);
  if (nextLevel > 0 && ham.state !== 'run_wheel') {
    ham.hopVel = -22;
  }

  for (let i = 0; i < 6; i++) {
    spawnParticle(
      world,
      i % 2 === 0 ? 'fluff' : 'sparkle',
      ham.x + (Math.random() * 18 - 9),
      ham.y - 10 - Math.random() * 10,
      nextLevel === 2 ? '#FFB5C8' : '#FFF2D6',
      (Math.random() - 0.5) * 32,
      -18 - Math.random() * 10,
      0.7
    );
  }

  if (nextLevel === 1) {
    ham.statusText = `POOF! ${ham.name} jadi GEMUK bulat seperti bakpao empuk!`;
  } else if (nextLevel === 2) {
    ham.statusText = `BOING!! ${ham.name} berubah jadi SUPER GEMBROT mochi raksasa!!`;
  } else {
    ham.statusText = `${ham.name} kembali ke ukuran imut normalnya~`;
  }
  world.globalStatusText = ham.statusText;
  pixelSound.playBoingGembrot(nextLevel);
  return nextLevel;
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

function stepSpring(
  val: number,
  vel: number,
  target: number,
  stiffness: number,
  damping: number,
  dt: number
): [number, number] {
  const force = (target - val) * stiffness - vel * damping;
  const nextVel = vel + force * dt;
  const nextVal = val + nextVel * dt;
  return [nextVal, nextVel];
}

function updateSoftPhysics(hamster: HamsterEntity, dt: number, timeSec: number) {
  const p = hamster.phys;

  let targetSquash = 0;
  let targetShear = 0;
  let targetEarL = 0;
  let targetEarR = 0;
  let targetCheek = 0;
  let targetTail = 0;

  const weightDamp = hamster.chubbyLevel === 2 ? 0.8 : 1;

  if (hamster.state === 'petted') {
    targetSquash = 0.72 + Math.sin(timeSec * 14) * 0.12;
    targetEarL = 0.9;
    targetEarR = 0.9;
    targetCheek = 0.65;
  } else if (hamster.state === 'sleep') {
    targetSquash = 0.45 + Math.sin(timeSec * 2.8 + hamster.id) * 0.14;
    targetEarL = 0.6;
    targetEarR = 0.6;
  } else if (hamster.state === 'stretch') {
    targetSquash = 0.55;
    targetShear = hamster.facing * 1.4;
    targetEarL = 0.8;
    targetEarR = 0.8;
  } else if (hamster.state === 'shake') {
    targetShear = Math.sin(timeSec * 46) * 2.2;
    targetSquash = -0.18;
    targetEarL = Math.sin(timeSec * 46) * 1.2;
    targetEarR = -Math.sin(timeSec * 46) * 1.2;
    targetCheek = 0.7;
  } else if (hamster.state === 'eat' || hamster.state === 'stuff_cheek') {
    targetCheek = 0.55 + Math.sin(timeSec * 22) * 0.45;
    targetSquash = Math.sin(timeSec * 14) * 0.15;
  } else if (hamster.state === 'unload_stash') {
    targetCheek = Math.sin(timeSec * 24) * 0.65;
    targetSquash = 0.3 + Math.sin(timeSec * 16) * 0.2;
  } else if (hamster.state === 'run_wheel') {
    const speedNorm = clamp(Math.abs(hamster.wheelSpeed) / 12, 0, 1);
    targetShear = -hamster.facing * (0.8 + speedNorm * 1.1);
    targetEarL = 0.6 + Math.sin(timeSec * 26) * 0.45;
    targetEarR = 0.7 + Math.cos(timeSec * 26) * 0.45;
    targetTail = Math.sin(timeSec * 22) * 1.0;
    targetCheek = Math.sin(timeSec * 18) * 0.25;
  } else if (hamster.state === 'walk') {
    targetShear = -hamster.facing * 0.6;
    targetEarL = Math.sin(timeSec * 16) * 0.4;
    targetEarR = -Math.sin(timeSec * 16) * 0.4;
    targetTail = Math.sin(timeSec * 16) * 0.7;
  } else if (hamster.state === 'happy_hop') {
    targetSquash = hamster.hopOffset < -3 ? -0.45 : 0.35;
    targetEarL = hamster.hopOffset < -3 ? -1.1 : 0.5;
    targetEarR = hamster.hopOffset < -3 ? -1.2 : 0.6;
  } else {
    targetSquash = Math.sin(timeSec * 3.1 + hamster.id) * 0.08;
    targetTail = Math.sin(timeSec * 2.4 + hamster.id) * 0.2;
  }

  const stiff = 165 * weightDamp;
  [p.squashY, p.squashVelY] = stepSpring(p.squashY, p.squashVelY, targetSquash, stiff, 10.5, dt);
  [p.furShearX, p.furShearVelX] = stepSpring(p.furShearX, p.furShearVelX, targetShear, 190, 13, dt);
  [p.earBounceL, p.earVelL] = stepSpring(p.earBounceL, p.earVelL, targetEarL, 210, 12, dt);
  [p.earBounceR, p.earVelR] = stepSpring(p.earBounceR, p.earVelR, targetEarR, 195, 11.5, dt);
  [p.cheekJiggle, p.cheekVel] = stepSpring(p.cheekJiggle, p.cheekVel, targetCheek, 175, 10, dt);
  [p.tailWag, p.tailVel] = stepSpring(p.tailWag, p.tailVel, targetTail, 220, 12, dt);
}

function getWheelTargetPos() {
  return {
    x: PROP_POS.wheel.x,
    y: PROP_POS.wheel.y + PROP_POS.wheel.radius - 3,
  };
}

function getIglooStashTarget() {
  return {
    x: PROP_POS.igloo.x + 25,
    y: PROP_POS.igloo.y + 7,
  };
}

function isWheelOccupied(world: SimWorld, excludeId: number): boolean {
  return world.hamsters.some(
    (h) => h.id !== excludeId && h.state === 'run_wheel'
  );
}

function setHamsterStatus(world: SimWorld, hamster: HamsterEntity, text: string) {
  hamster.statusText = text;
  if (hamster.id === world.selectedHamsterId) {
    world.globalStatusText = text;
  }
}

function pickNextBehavior(world: SimWorld, hamster: HamsterEntity) {
  const { stats } = hamster;

  // Priority 0: If hamster has food stuffed in cheek pouches and no loose treats remain -> unload stash at Igloo!
  const hasLooseTreats = world.treats.some((t) => t.landed);
  if (hamster.storedPouch.length > 0 && !hasLooseTreats) {
    const stashSpot = getIglooStashTarget();
    hamster.targetX = stashSpot.x;
    hamster.targetY = stashSpot.y;
    hamster.state = 'walk';
    hamster.stateTimer = 5.5;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} membawa pipi penuh simpanan menuju rumah iglo untuk ditimbun!`
    );
    return;
  }

  // Priority 1: Sleepy if low energy
  if (stats.energy < 22) {
    const goIgloo = Math.random() < 0.5;
    hamster.targetX = goIgloo ? PROP_POS.igloo.x + 2 : PROP_POS.cushion.x;
    hamster.targetY = goIgloo ? PROP_POS.igloo.y + 8 : PROP_POS.cushion.y + 1;
    hamster.state = 'walk';
    hamster.stateTimer = 4.5;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} mulai mengantuk dan mencari tempat empuk...`
    );
    return;
  }

  // Priority 2: Hungry -> check Igloo Stash first, then Food Bowl!
  if (stats.hunger < 60) {
    if (world.iglooStash.length > 0 && Math.random() < 0.65) {
      const stashSpot = getIglooStashTarget();
      hamster.targetStashEat = true;
      hamster.targetX = stashSpot.x;
      hamster.targetY = stashSpot.y;
      hamster.state = 'walk';
      hamster.stateTimer = 5.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} lapar dan pergi mengintip simpanan makanan di iglo!`
      );
      return;
    }
    if (world.bowlSeeds > 0) {
      hamster.targetX = PROP_POS.bowl.x - 12;
      hamster.targetY = PROP_POS.bowl.y + 4;
      hamster.state = 'walk';
      hamster.stateTimer = 5.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} berlari menuju mangkuk biji bunga matahari!`
      );
      return;
    }
  }

  const roll = Math.random();

  if (roll < 0.24 && stats.energy > 28 && !isWheelOccupied(world, hamster.id)) {
    const wt = getWheelTargetPos();
    hamster.targetX = wt.x;
    hamster.targetY = wt.y;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} bersemangat menuju roda putar!`
    );
  } else if (roll < 0.36) {
    hamster.state = 'groom';
    hamster.stateTimer = 2.6 + Math.random() * 1.4;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} mencuci muka dengan kaki mungilnya~`
    );
  } else if (roll < 0.48) {
    hamster.state = 'dig';
    hamster.stateTimer = 2.2 + Math.random() * 1.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} asyik menggali serbuk kayu yang empuk!`
    );
  } else if (roll < 0.59) {
    hamster.state = 'stand';
    hamster.stateTimer = 2.0 + Math.random() * 1.2;
    applySquishImpulse(hamster, -3.5);
    const msg = world.rainMode
      ? `${hamster.name} berdiri imut menatap rintik hujan di luar jendela~`
      : `${hamster.name} berdiri mengintip dengan telinga tegak!`;
    setHamsterStatus(world, hamster, msg);
    spawnParticle(world, 'question', hamster.x, hamster.y - 28, '#6C8CE8', 0, -6, 1.0);
  } else if (roll < 0.67) {
    hamster.state = 'shake';
    hamster.stateTimer = 1.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} menggetarkan bulu halusnya~ brrr!`
    );
  } else if (roll < 0.76 && world.waterLevel > 10) {
    hamster.targetX = PROP_POS.bottle.spoutX - 8;
    hamster.targetY = FLOOR_TOP_Y + 12;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} berjalan ke botol minumnya~`
    );
  } else if (roll < (world.nightMode || world.rainMode ? 0.92 : 0.85)) {
    const onCushion = Math.random() < 0.68;
    hamster.targetX = onCushion ? PROP_POS.cushion.x : 146 + (Math.random() * 24 - 12);
    hamster.targetY = onCushion ? PROP_POS.cushion.y + 1 : 144;
    hamster.state = 'walk';
    hamster.stateTimer = 4.0;
    setHamsterStatus(
      world,
      hamster,
      world.rainMode
        ? `${hamster.name} mencari tempat hangat untuk dengar suara hujan~`
        : `${hamster.name} mencari posisi nyaman untuk rebahan mochi...`
    );
  } else {
    hamster.targetX = 48 + Math.random() * 190;
    hamster.targetY = FLOOR_TOP_Y + 8 + Math.random() * (FLOOR_BOTTOM_Y - FLOOR_TOP_Y - 14);
    hamster.state = 'walk';
    hamster.stateTimer = 4.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} berjalan gembul keliling kandang~`
    );
  }
}

export function stepSimulation(world: SimWorld, dt: number, timeSec: number) {
  const { treats } = world;

  world.cleanliness = clamp(world.cleanliness - dt * 0.22, 0, 100);

  // 1) Update falling treats
  for (const t of treats) {
    if (!t.landed) {
      t.vy += 260 * dt;
      t.y += t.vy * dt;
      const landY = clamp(t.y, FLOOR_TOP_Y + 10, FLOOR_BOTTOM_Y - 8);
      if (t.y >= landY && t.vy > 0 && t.y > FLOOR_TOP_Y + 14) {
        t.y = clamp(t.y, FLOOR_TOP_Y + 14, FLOOR_BOTTOM_Y - 8);
        t.landed = true;
        t.vy = 0;
        spawnParticle(world, 'shaving', t.x - 2, t.y, '#FFF1DC', -14, -20, 0.35, 1);
        spawnParticle(world, 'shaving', t.x + 2, t.y, '#E7C8A1', 14, -20, 0.35, 1);
      }
    }
  }

  // 2) Wheel coasting when nobody is running on it
  const runner = world.hamsters.find((h) => h.state === 'run_wheel');
  if (!runner) {
    world.wheelSpeed *= Math.pow(0.28, dt);
    world.wheelAngle += world.wheelSpeed * dt;
  }

  // 3) Step each hamster
  for (const hamster of world.hamsters) {
    stepSingleHamster(world, hamster, dt, timeSec);
  }

  // 4) Cute social boop/chatter when two hamsters meet!
  for (let i = 0; i < world.hamsters.length; i++) {
    for (let j = i + 1; j < world.hamsters.length; j++) {
      const a = world.hamsters[i];
      const b = world.hamsters[j];
      if (a.socialCooldown > 0 || b.socialCooldown > 0) continue;
      if (
        (a.state === 'idle' || a.state === 'walk') &&
        (b.state === 'idle' || b.state === 'walk')
      ) {
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < 22) {
          a.socialCooldown = 10;
          b.socialCooldown = 10;
          a.facing = b.x >= a.x ? 1 : -1;
          b.facing = a.x >= b.x ? 1 : -1;
          a.state = 'stand';
          b.state = 'stand';
          a.stateTimer = 1.4;
          b.stateTimer = 1.4;
          applySquishImpulse(a, -3);
          applySquishImpulse(b, -3);
          spawnParticle(world, 'heart', (a.x + b.x) / 2, Math.min(a.y, b.y) - 24, '#FF6B93', 0, -16, 1.2);
          pixelSound.playGiggleChirp();
          world.globalStatusText = `${a.name} dan ${b.name} saling menyapa sambil mengendus hidung!`;
        }
      }
    }
  }

  // 5) Update particles
  for (let i = world.particles.length - 1; i >= 0; i--) {
    const p = world.particles[i];
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    if (p.kind === 'shaving' || p.kind === 'crumb' || p.kind === 'droplet' || p.kind === 'fluff') {
      p.vy += 80 * dt;
    }
    if (p.life <= 0) {
      world.particles.splice(i, 1);
    }
  }
}

function stepSingleHamster(
  world: SimWorld,
  hamster: HamsterEntity,
  dt: number,
  timeSec: number
) {
  const { stats } = hamster;
  const { treats } = world;

  hamster.socialCooldown = Math.max(0, hamster.socialCooldown - dt);
  stats.hunger = clamp(stats.hunger - dt * 0.4, 0, 100);
  stats.cleanliness = world.cleanliness;

  if (hamster.state === 'sleep') {
    stats.energy = clamp(stats.energy + dt * 3.8, 0, 100);
  } else if (hamster.state === 'run_wheel') {
    stats.energy = clamp(stats.energy - dt * 1.7, 0, 100);
    stats.happiness = clamp(stats.happiness + dt * 1.6, 0, 100);
  } else {
    stats.energy = clamp(stats.energy - dt * 0.32, 0, 100);
    stats.happiness = clamp(stats.happiness - dt * 0.2, 0, 100);
  }

  // Smooth visual cheek puff matches storedPouch count!
  const desiredPuff = Math.min(4, hamster.storedPouch.length * 1.15);
  if (hamster.state !== 'eat' && hamster.state !== 'stuff_cheek' && hamster.state !== 'unload_stash') {
    stats.cheekPuff += (desiredPuff - stats.cheekPuff) * Math.min(1, dt * 4);
  }

  hamster.squish = Math.max(0, hamster.squish - dt * 2.5);

  // Check for unclaimed landed treats to chase!
  if (
    treats.length > 0 &&
    hamster.state !== 'eat' &&
    hamster.state !== 'stuff_cheek' &&
    hamster.state !== 'unload_stash' &&
    hamster.state !== 'petted' &&
    hamster.targetTreatId === null &&
    hamster.storedPouch.length < 4
  ) {
    const claimedIds = new Set(
      world.hamsters
        .map((h) => h.targetTreatId)
        .filter((id): id is number => id !== null)
    );
    const available = treats.filter((t) => t.landed && !claimedIds.has(t.id));
    const target = available[0] || treats.find((t) => t.landed);
    if (target) {
      if (hamster.state === 'run_wheel') {
        hamster.wheelPhase = 'none';
        hamster.y = FLOOR_TOP_Y + 14;
      }
      hamster.targetTreatId = target.id;
      hamster.targetStashEat = false;
      hamster.targetX = target.x + (hamster.x < target.x ? -9 : 9);
      hamster.targetY = target.y + 1;
      hamster.state = 'walk';
      hamster.stateTimer = 6.0;
      applySquishImpulse(hamster, -4.0);
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} mencium camilan enak dan langsung berlari!`
      );
      spawnParticle(world, 'exclaim', hamster.x, hamster.y - 27, '#FF5C8A', 0, -8, 0.8);
      pixelSound.playSqueak();
    }
  }

  // Blinking & ear twitch
  hamster.blinkTimer -= dt;
  if (hamster.blinkTimer <= 0) {
    if (!hamster.isBlinking) {
      hamster.isBlinking = true;
      hamster.blinkTimer = 0.14;
    } else {
      hamster.isBlinking = false;
      hamster.blinkTimer = 2.0 + Math.random() * 3.2;
    }
  }

  hamster.earTwitchTimer = Math.max(0, hamster.earTwitchTimer - dt);
  if (Math.random() < dt * 0.45) {
    hamster.earTwitchTimer = 0.45;
    hamster.phys.earVelL -= 3.5;
  }

  // Jump / hop vertical physics
  if (hamster.hopOffset < 0 || hamster.hopVel < 0) {
    hamster.hopVel += 185 * dt;
    hamster.hopOffset += hamster.hopVel * dt;
    if (hamster.hopOffset >= 0) {
      hamster.hopOffset = 0;
      if (hamster.hopVel > 25) {
        applySquishImpulse(hamster, 7.2);
      }
      hamster.hopVel = 0;
    }
  }

  // State machine
  hamster.stateTimer -= dt;
  const animSpeed =
    hamster.state === 'run_wheel'
      ? hamster.wheelPhase === 'turbo'
        ? 28
        : hamster.wheelPhase === 'coast'
        ? 6
        : 20
      : hamster.state === 'dig' || hamster.state === 'eat' || hamster.state === 'stuff_cheek' || hamster.state === 'unload_stash'
      ? 11
      : hamster.state === 'walk'
      ? 10
      : 4;
  hamster.animFrame += dt * animSpeed;

  switch (hamster.state) {
    case 'idle': {
      hamster.hopOffset = 0;
      if (hamster.stateTimer <= 0) {
        pickNextBehavior(world, hamster);
      }
      break;
    }

    case 'stand': {
      hamster.hopOffset = 0;
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'walk': {
      if (hamster.targetX !== null && hamster.targetY !== null) {
        const dx = hamster.targetX - hamster.x;
        const dy = hamster.targetY - hamster.y;
        const dist = Math.hypot(dx, dy);
        // Slightly slower adorable waddle if super gembrot, faster when chasing treats!
        const chubbyFactor = hamster.chubbyLevel === 2 ? 0.82 : 1;
        const speed = (hamster.targetTreatId !== null ? 68 : 38) * chubbyFactor;
        const wt = getWheelTargetPos();
        const stashSpot = getIglooStashTarget();

        if (dist <= 2.5 || hamster.stateTimer <= 0) {
          hamster.x = hamster.targetX;
          hamster.y = hamster.targetY;
          const arrivedX = hamster.x;
          const arrivedY = hamster.y;
          hamster.targetX = null;
          hamster.targetY = null;
          hamster.hopOffset = 0;
          applySquishImpulse(hamster, 3.2);

          // Arrived at a dropped treat!
          if (hamster.targetTreatId !== null) {
            const idx = treats.findIndex((t) => t.id === hamster.targetTreatId);
            hamster.targetTreatId = null;
            if (idx !== -1) {
              const t = treats[idx];
              hamster.facing = t.x >= hamster.x ? 1 : -1;
              hamster.activeSnack = t.type;
              treats.splice(idx, 1);

              // Should we stuff into cheek pouch or eat immediately?
              const shouldStuff =
                treats.length >= 1 ||
                hamster.storedPouch.length > 0 ||
                hamster.stats.hunger > 72;

              if (shouldStuff && hamster.storedPouch.length < 4) {
                hamster.state = 'stuff_cheek';
                hamster.stateTimer = 0.72;
                setHamsterStatus(
                  world,
                  hamster,
                  `${hamster.name} memasukkan makanan ke kantong pipinya! Pipinya makin tembem~`
                );
              } else {
                hamster.state = 'eat';
                hamster.stateTimer = t.type === 'strawberry' ? 3.0 : 2.3;
                setHamsterStatus(
                  world,
                  hamster,
                  t.type === 'strawberry'
                    ? `${hamster.name} menggigit stroberi manis dengan kedua tangan mungilnya!`
                    : t.type === 'corn'
                    ? `${hamster.name} mengunyah jagung manis~ nyam nyam!`
                    : `${hamster.name} mengunyah kuaci dengan gembira!`
                );
              }
              break;
            }
          }

          // Arrived at Igloo Stash!
          if (Math.hypot(arrivedX - stashSpot.x, arrivedY - stashSpot.y) < 10) {
            if (hamster.targetStashEat && world.iglooStash.length > 0) {
              hamster.targetStashEat = false;
              hamster.activeSnack = world.iglooStash.pop() || 'seed';
              hamster.facing = -1;
              hamster.state = 'eat';
              hamster.stateTimer = 2.4;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} makan camilan dari simpanan rahasianya di iglo!`
              );
              break;
            }
            if (hamster.storedPouch.length > 0) {
              hamster.facing = -1;
              hamster.state = 'unload_stash';
              hamster.stateTimer = 1.4;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} mengeluarkan makanan dari pipi dan menumpuknya di rumah iglo!`
              );
              break;
            }
          }

          // Arrived at Wheel!
          if (Math.hypot(arrivedX - wt.x, arrivedY - wt.y) < 9) {
            if (!isWheelOccupied(world, hamster.id)) {
              hamster.state = 'run_wheel';
              hamster.wheelPhase = 'accel';
              hamster.stateTimer = 0.85;
              hamster.facing = Math.random() < 0.8 ? 1 : -1;
              hamster.wheelSwing = 0;
              hamster.wheelSwingVel = 0;
              hamster.hopVel = -26;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} melompat naik ke roda putar!`
              );
            } else {
              hamster.state = 'stand';
              hamster.stateTimer = 1.6;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} melihat temannya sedang asyik lari di roda~`
              );
            }
          } else if (Math.hypot(arrivedX - (PROP_POS.bowl.x - 12), arrivedY - (PROP_POS.bowl.y + 4)) < 9) {
            hamster.activeSnack = 'seed';
            world.bowlSeeds = Math.max(0, world.bowlSeeds - 14);
            hamster.facing = 1;
            hamster.state = 'eat';
            hamster.stateTimer = 2.5;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} makan lahap dari mangkuk kuaci!`
            );
          } else if (Math.hypot(arrivedX - (PROP_POS.bottle.spoutX - 8), arrivedY - (FLOOR_TOP_Y + 12)) < 10) {
            hamster.facing = 1;
            hamster.state = 'drink';
            hamster.stateTimer = 2.0;
            world.waterLevel = Math.max(0, world.waterLevel - 4);
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} minum air segar dari botol kaca~ gluk gluk`
            );
          } else if (
            Math.hypot(arrivedX - PROP_POS.cushion.x, arrivedY - (PROP_POS.cushion.y + 1)) < 11 ||
            Math.hypot(arrivedX - (PROP_POS.igloo.x + 2), arrivedY - (PROP_POS.igloo.y + 8)) < 11
          ) {
            hamster.state = 'yawn';
            hamster.stateTimer = 1.1;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} menguap lebar lalu menggulung diri...`
            );
          } else {
            hamster.state = 'idle';
            hamster.stateTimer = 1.2 + Math.random() * 1.1;
          }
        } else {
          const nextFacing: 1 | -1 = dx >= 0 ? 1 : -1;
          if (nextFacing !== hamster.facing) {
            hamster.phys.furShearVelX -= nextFacing * 10;
            hamster.facing = nextFacing;
          }
          hamster.x += (dx / dist) * speed * dt;
          hamster.y += (dy / dist) * speed * dt;
          hamster.hopOffset = Math.floor(hamster.animFrame) % 2 === 0 ? -1 : 0;
        }
      } else {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'stuff_cheek': {
      hamster.hopOffset = 0;
      if (hamster.stateTimer <= 0) {
        const snack = hamster.activeSnack || 'seed';
        hamster.activeSnack = null;
        hamster.storedPouch.push(snack);
        stats.cheekPuff = Math.min(4, hamster.storedPouch.length * 1.15);
        stats.happiness = clamp(stats.happiness + 10, 0, 100);
        stats.affection += 2;
        applySquishImpulse(hamster, 3.6);
        pixelSound.playCheekStuff();
        spawnParticle(world, 'heart', hamster.x, hamster.y - 25, '#FF8FA8', 0, -14, 0.9);

        // Immediately check if more treats are on the floor to stuff!
        const moreTreats = treats.some((t) => t.landed);
        if (moreTreats && hamster.storedPouch.length < 4) {
          hamster.state = 'idle';
          hamster.stateTimer = 0.08;
        } else {
          // Go store the cheek-pouch hoard inside/beside the Igloo!
          const stashSpot = getIglooStashTarget();
          hamster.targetX = stashSpot.x;
          hamster.targetY = stashSpot.y;
          hamster.state = 'walk';
          hamster.stateTimer = 6.0;
          setHamsterStatus(
            world,
            hamster,
            `Pipi ${hamster.name} penuh (${hamster.storedPouch.length} simpanan)! Menuju iglo untuk menyimpannya~`
          );
        }
      }
      break;
    }

    case 'unload_stash': {
      hamster.hopOffset = 0;
      if (Math.random() < dt * 5) {
        spawnParticle(
          world,
          'crumb',
          hamster.x - 6,
          hamster.y - 10,
          '#E6DDD5',
          -14 - Math.random() * 10,
          -12,
          0.45,
          2
        );
      }
      if (hamster.stateTimer <= 0) {
        while (hamster.storedPouch.length > 0) {
          const item = hamster.storedPouch.shift();
          if (item) {
            if (world.iglooStash.length >= 16) world.iglooStash.shift();
            world.iglooStash.push(item);
          }
        }
        stats.cheekPuff = 0;
        stats.happiness = clamp(stats.happiness + 12, 0, 100);
        stats.affection += 3;
        pixelSound.playUnloadStash();
        triggerHappyHop(
          world,
          hamster,
          `${hamster.name} berhasil menyimpan tumpukan camilan di depan iglo! (Total: ${world.iglooStash.length})`
        );
      }
      break;
    }

    case 'run_wheel': {
      const { x: wcx, y: wcy, radius } = PROP_POS.wheel;
      const trackR = radius - 4;

      if (hamster.wheelPhase === 'accel') {
        hamster.wheelSpeed += (7.5 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 4);
        hamster.wheelSwing += (0.24 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 5);
        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'cruise';
          hamster.stateTimer = 1.8 + Math.random() * 0.8;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} lari gembira di roda putar~ tap tap tap!`
          );
        }
      } else if (hamster.wheelPhase === 'cruise') {
        hamster.wheelSpeed += (8.6 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 5);
        hamster.wheelSwing += (0.28 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 5);
        if (Math.random() < dt * 2.5) {
          spawnParticle(
            world,
            'note',
            hamster.x + (Math.random() * 12 - 6),
            hamster.y - 26,
            '#FF8FB1',
            (Math.random() - 0.5) * 10,
            -16,
            1.0
          );
        }
        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'turbo';
          hamster.stateTimer = 1.6 + Math.random() * 0.8;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} MODE TURBO!! Kaki mungilnya super ngebut!!`
          );
          spawnParticle(world, 'exclaim', hamster.x, hamster.y - 28, '#FF5C8A', 0, -10, 0.7);
          pixelSound.playSqueak();
        }
      } else if (hamster.wheelPhase === 'turbo') {
        hamster.wheelSpeed += (12.8 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 6);
        hamster.wheelSwing += (0.42 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 6);
        if (Math.random() < dt * 7) {
          spawnParticle(
            world,
            'sparkle',
            hamster.x - hamster.facing * 9,
            hamster.y - 3,
            '#FFE8B5',
            -hamster.facing * 22,
            -10,
            0.35
          );
        }
        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'coast';
          hamster.stateTimer = 1.35;
          hamster.wheelSwingVel = 2.6 * hamster.facing;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} berhenti mendadak dan ikut berayun di roda~ wiiiii!`
          );
        }
      } else if (hamster.wheelPhase === 'coast') {
        hamster.wheelSpeed *= Math.pow(0.18, dt);
        const force = -24 * hamster.wheelSwing - 3.6 * hamster.wheelSwingVel;
        hamster.wheelSwingVel += force * dt;
        hamster.wheelSwing += hamster.wheelSwingVel * dt;

        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'none';
          hamster.hopOffset = 0;
          hamster.hopVel = -28;
          hamster.x = wcx + hamster.facing * 6;
          hamster.y = FLOOR_TOP_Y + 14;
          if (Math.random() < 0.55) {
            hamster.state = 'dizzy';
            hamster.stateTimer = 1.8;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} turun sambil sedikit pusing imut~ @_@`
            );
          } else {
            triggerHappyHop(
              world,
              hamster,
              `${hamster.name} turun dari roda dengan lompatan bangga!`
            );
          }
          break;
        }
      }

      hamster.wheelAngle += hamster.wheelSpeed * dt;
      world.wheelAngle = hamster.wheelAngle;
      world.wheelSpeed = hamster.wheelSpeed;

      hamster.x = wcx + Math.sin(hamster.wheelSwing) * trackR;
      hamster.y = wcy + Math.cos(hamster.wheelSwing) * trackR;

      if (
        hamster.wheelPhase !== 'coast' &&
        Math.floor(hamster.animFrame) % 4 === 0 &&
        Math.random() < dt * 8
      ) {
        pixelSound.playWheelTick();
      }
      break;
    }

    case 'dizzy': {
      hamster.hopOffset = 0;
      if (Math.random() < dt * 3.8) {
        const ang = timeSec * 5;
        spawnParticle(
          world,
          'star',
          hamster.x + Math.cos(ang) * 9,
          hamster.y - 26 + Math.sin(ang) * 2,
          '#FFE066',
          0,
          -4,
          0.45
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'shake';
        hamster.stateTimer = 0.8;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} menggoyangkan bulu halusnya biar sadar lagi!`
        );
      }
      break;
    }

    case 'shake': {
      if (Math.random() < dt * 8) {
        spawnParticle(
          world,
          'fluff',
          hamster.x + (Math.random() * 14 - 7),
          hamster.y - 10 - Math.random() * 8,
          '#FFF5E6',
          (Math.random() - 0.5) * 32,
          -14 - Math.random() * 10,
          0.45
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'stretch': {
      if (hamster.stateTimer <= 0) {
        hamster.state = 'stand';
        hamster.stateTimer = 1.2;
        applySquishImpulse(hamster, -4.5);
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} bangun tidur dengan tubuh segar!`
        );
      }
      break;
    }

    case 'happy_hop': {
      if (hamster.stateTimer <= 0 && hamster.hopOffset >= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.5;
      }
      break;
    }

    case 'eat': {
      hamster.hopOffset = 0;
      if (Math.random() < dt * 5.0) {
        const crumbCol =
          hamster.activeSnack === 'strawberry'
            ? '#FF6B8E'
            : hamster.activeSnack === 'corn'
            ? '#FFD54F'
            : '#D9CFC7';
        spawnParticle(
          world,
          'crumb',
          hamster.x + hamster.facing * 7,
          hamster.y - 12,
          crumbCol,
          (Math.random() - 0.5) * 26,
          -14 - Math.random() * 12,
          0.55,
          1
        );
        pixelSound.playNibble();
      }

      if (hamster.stateTimer <= 0) {
        const snack = hamster.activeSnack;
        hamster.activeSnack = null;
        stats.hunger = clamp(stats.hunger + (snack === 'strawberry' ? 22 : 16), 0, 100);
        stats.happiness = clamp(stats.happiness + (snack === 'strawberry' ? 18 : 11), 0, 100);
        stats.affection += 3;
        pixelSound.playHappyChime();

        if (snack === 'strawberry') {
          triggerHappyHop(
            world,
            hamster,
            `${hamster.name} meloncat kegirangan karena stroberi favoritnya!`
          );
        } else {
          spawnParticle(world, 'heart', hamster.x, hamster.y - 26, '#FF6B93', 0, -14, 1.2);
          hamster.state = 'idle';
          hamster.stateTimer = 1.8;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} selesai makan dengan puas~`
          );
        }
      }
      break;
    }

    case 'drink': {
      if (Math.random() < dt * 2.8) {
        spawnParticle(
          world,
          'droplet',
          PROP_POS.bottle.spoutX - 1,
          PROP_POS.bottle.spoutY + 2,
          '#7CD4FF',
          -6,
          12,
          0.4,
          1
        );
      }
      if (hamster.stateTimer <= 0) {
        stats.happiness = clamp(stats.happiness + 6, 0, 100);
        hamster.state = 'idle';
        hamster.stateTimer = 1.5;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} selesai minum~ segaaar!`
        );
      }
      break;
    }

    case 'groom': {
      if (hamster.stateTimer <= 0) {
        world.cleanliness = clamp(world.cleanliness + 6, 0, 100);
        stats.happiness = clamp(stats.happiness + 5, 0, 100);
        spawnParticle(world, 'sparkle', hamster.x, hamster.y - 22, '#FFE066', 0, -10, 0.8);
        hamster.state = 'idle';
        hamster.stateTimer = 1.6;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} jadi wangi, bersih, dan super fluffy!`
        );
      }
      break;
    }

    case 'dig': {
      if (Math.random() < dt * 6.5) {
        spawnParticle(
          world,
          'shaving',
          hamster.x + hamster.facing * 5,
          hamster.y - 2,
          Math.random() < 0.5 ? '#FFF1DC' : '#E7C8A1',
          -hamster.facing * (12 + Math.random() * 14),
          -24 - Math.random() * 14,
          0.55,
          2
        );
      }
      if (hamster.stateTimer <= 0) {
        stats.happiness = clamp(stats.happiness + 6, 0, 100);
        hamster.state = 'shake';
        hamster.stateTimer = 0.75;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} mengibaskan serbuk kayu dari bulunya~`
        );
      }
      break;
    }

    case 'yawn': {
      if (hamster.stateTimer <= 0) {
        hamster.state = 'sleep';
        hamster.stateTimer = 6.5 + Math.random() * 4.0;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} tidur pulas berbentuk mochi gepeng~ Zzz`
        );
      }
      break;
    }

    case 'sleep': {
      if (Math.random() < dt * 0.85) {
        spawnParticle(
          world,
          'zzz',
          hamster.x + 8,
          hamster.y - 18,
          world.nightMode ? '#C2CEFF' : '#8BA4F5',
          4,
          -10,
          1.4
        );
      }
      if (hamster.stateTimer <= 0 && stats.energy > 65) {
        hamster.state = 'stretch';
        hamster.stateTimer = 1.3;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} menggeliat panjang sehabis tidur~`
        );
      }
      break;
    }

    case 'petted': {
      hamster.squish = 1;
      if (Math.random() < dt * 4.0) {
        spawnParticle(
          world,
          'heart',
          hamster.x + (Math.random() * 14 - 7),
          hamster.y - 24,
          '#FF6B93',
          (Math.random() - 0.5) * 10,
          -16,
          1.1
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.6;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} senang sekali dielus~`
        );
      }
      break;
    }
  }

  if (hamster.state !== 'run_wheel') {
    hamster.x = clamp(hamster.x, 30, VIRTUAL_W - 34);
    hamster.y = clamp(hamster.y, FLOOR_TOP_Y + 6, FLOOR_BOTTOM_Y - 4);
  }

  updateSoftPhysics(hamster, dt, timeSec);
}

export type { HamsterStats };

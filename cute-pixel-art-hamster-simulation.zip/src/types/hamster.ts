export type HamsterState =
  | 'idle'
  | 'stand'
  | 'walk'
  | 'run_wheel'
  | 'dizzy'
  | 'eat'
  | 'stuff_cheek'
  | 'unload_stash'
  | 'drink'
  | 'groom'
  | 'dig'
  | 'sleep'
  | 'petted'
  | 'yawn'
  | 'stretch'
  | 'shake'
  | 'happy_hop';

export type ToolMode = 'pet' | 'seed' | 'strawberry' | 'corn';

export type TreatKind = 'seed' | 'strawberry' | 'corn';

export type ChubbyLevel = 0 | 1 | 2; // 0 = Normal, 1 = Gemuk, 2 = Super Gembrot

export interface HamsterCoat {
  id: string;
  name: string;
  subtitle: string;
  badgeColor: string;
  outline: string;
  furBase: string;
  furLight: string;
  furShadow: string;
  belly: string;
  bellyShadow: string;
  earOuter: string;
  earInner: string;
  blush: string;
  nose: string;
  eye: string;
  stripe?: string;
}

export interface TreatItem {
  id: number;
  type: TreatKind;
  x: number;
  y: number;
  vy: number;
  landed: boolean;
  bitesLeft: number;
}

export type ParticleKind =
  | 'heart'
  | 'sparkle'
  | 'crumb'
  | 'shaving'
  | 'zzz'
  | 'note'
  | 'droplet'
  | 'sweat'
  | 'exclaim'
  | 'question'
  | 'fluff'
  | 'star';

export interface PixelParticle {
  id: number;
  kind: ParticleKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size?: number;
}

export interface HamsterStats {
  hunger: number; // 0-100
  happiness: number; // 0-100
  energy: number; // 0-100
  cleanliness: number; // 0-100
  cheekPuff: number; // 0-4 visual puffiness
  affection: number; // total love points
}

/** Damped harmonic spring state for soft plush fur & body physics */
export interface SoftPhysicsState {
  squashY: number;
  squashVelY: number;
  furShearX: number;
  furShearVelX: number;
  earBounceL: number;
  earVelL: number;
  earBounceR: number;
  earVelR: number;
  cheekJiggle: number;
  cheekVel: number;
  tailWag: number;
  tailVel: number;
}

export interface HamsterEntity {
  id: number;
  name: string;
  coatId: string;
  chubbyLevel: ChubbyLevel;
  storedPouch: TreatKind[];
  activeSnack: TreatKind | null;
  stats: HamsterStats;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1; // 1 = right, -1 = left
  state: HamsterState;
  stateTimer: number;
  animFrame: number;
  blinkTimer: number;
  isBlinking: boolean;
  earTwitchTimer: number;
  targetX: number | null;
  targetY: number | null;
  targetTreatId: number | null;
  targetStashEat: boolean;
  wheelAngle: number;
  wheelSpeed: number;
  wheelPhase: 'none' | 'accel' | 'cruise' | 'turbo' | 'coast';
  wheelSwing: number;
  wheelSwingVel: number;
  squish: number;
  hopOffset: number;
  hopVel: number;
  socialCooldown: number;
  phys: SoftPhysicsState;
  statusText: string;
}

export interface HamsterSummary {
  id: number;
  name: string;
  coatId: string;
  chubbyLevel: ChubbyLevel;
  state: HamsterState;
  pouchCount: number;
}

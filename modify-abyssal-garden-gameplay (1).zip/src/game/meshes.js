// ============================================================================
// Procedural 3D meshes: Vintage Mark V Scuba Diver & Jules Verne Submarine
// ============================================================================
import { sin, cos, PI, TAU, mix, pow, qAxis, qMul, qRot, EntityMesh, Mesh } from './math.js';

// Diver material IDs:
// 0=canvas suit, 1=antique copper, 2=burnished brass, 3=warm glowing porthole glass,
// 4=ribbed dark rubber, 5=dark leather & lead, 6=vintage twin scuba tanks,
// 7=forehead dive-lamp lens, 8=expedition collar/tank accent
// Diver part IDs:
// 0=torso/tanks, 1=helmet, 2=leftArm, 3=rightArm, 4=leftLeg, 5=rightLeg, 6=leftFin, 7=rightFin, 8=hoses
export function buildDiverMesh() {
  const m = new EntityMesh();

  // --- PART 0: Vintage Puffy Canvas Torso + Belt + Copper Corselet + Twin Scuba Tanks ---
  m.tag(0, 0);
  m.lathe(0, 0, 0, [
    [0.00, 0.25, 0.55],
    [0.095, 0.26, 0.72],
    [0.125, 0.31, 0.85],
    [0.118, 0.36, 0.88],
    [0.132, 0.44, 0.95],
    [0.146, 0.52, 0.98],
    [0.132, 0.58, 0.95],
    [0.090, 0.61, 0.85],
    [0.00, 0.62, 0.80],
  ], 18, 'y', 0.80);

  // Riveted antique copper corselet (shoulder breastplate)
  m.tag(1, 0);
  m.lathe(0, 0, 0, [
    [0.150, 0.515, 0.82],
    [0.162, 0.545, 0.95],
    [0.148, 0.585, 1.00],
    [0.118, 0.612, 0.96],
    [0.105, 0.625, 0.90],
  ], 18, 'y', 0.84);

  // Brass neck locking ring + 12 vintage wing-nut bolts around collar
  m.tag(2, 0);
  m.torus(0, 0.612, 0, 0.122, 0.016, 18, 8, 'y');
  for (let k = 0; k < 12; k++) {
    const a = k / 12 * TAU;
    m.ellipsoid(cos(a) * 0.146, 0.552, sin(a) * 0.124, 0.011, 0.011, 0.011, 6, 5);
  }
  // Vintage chest weight medallion & expedition trim ring
  m.box(0, 0.465, -0.108, 0.048, 0.042, 0.016, qAxis(1, 0, 0, -0.1));
  m.tag(8, 0);
  m.torus(0, 0.522, 0, 0.144, 0.011, 16, 6, 'y');

  // Heavy dark saddle-leather weight belt + lead pouches + chunky brass buckle
  m.tag(5, 0);
  m.lathe(0, 0, 0, [
    [0.128, 0.332, 0.8],
    [0.134, 0.352, 0.92],
    [0.128, 0.372, 0.85],
  ], 18, 'y', 0.83);
  for (const a of [-2.3, -1.5, -0.75, 0.75, 1.5, 2.3]) {
    const px = sin(a) * 0.132, pz = -cos(a) * 0.110;
    m.box(px, 0.352, pz, 0.020, 0.026, 0.018, qAxis(0, 1, 0, -a), 0.85);
  }
  // Leather cross-shoulder tank harness straps
  for (const sx of [-1, 1]) {
    m.cyl(sx * 0.075, 0.58, -0.09, sx * 0.06, 0.36, -0.105, 0.012, 0.012, 6, false);
  }
  // Front square brass belt buckle + hip brass dive-knife tube
  m.tag(2, 0);
  m.box(0, 0.352, -0.112, 0.030, 0.027, 0.012);
  m.cyl(0.136, 0.37, -0.01, 0.142, 0.27, 0.01, 0.011, 0.008, 7, true);

  // Twin vintage 1940s Aqua-Lung / Jules Verne Scuba Cylinders on back (+Z)
  for (const sx of [-0.056, 0.056]) {
    m.tag(6, 0);
    m.lathe(sx, 0, 0.142, [
      [0.00, 0.315, 0.7],
      [0.036, 0.325, 0.85],
      [0.048, 0.355, 0.95],
      [0.048, 0.555, 1.0],
      [0.038, 0.585, 0.98],
      [0.016, 0.602, 0.95],
      [0.00, 0.606, 0.95],
    ], 14, 'y');
    // Brass tank harness bands
    m.tag(2, 0);
    m.torus(sx, 0.395, 0.142, 0.049, 0.007, 14, 6, 'y');
    m.torus(sx, 0.515, 0.142, 0.049, 0.007, 14, 6, 'y');
    // Expedition color stripe around upper tank
    m.tag(8, 0);
    m.cyl(sx, 0.525, 0.142, sx, 0.552, 0.142, 0.049, 0.049, 12, false);
  }
  // Brass twin-tank manifold crossbar, first-stage regulator drum & valve wheel
  m.tag(2, 0);
  m.cyl(-0.062, 0.612, 0.142, 0.062, 0.612, 0.142, 0.013, 0.013, 8, true);
  m.cyl(-0.056, 0.595, 0.142, -0.056, 0.618, 0.142, 0.015, 0.015, 8, true);
  m.cyl(0.056, 0.595, 0.142, 0.056, 0.618, 0.142, 0.015, 0.015, 8, true);
  // Classic Cousteau round pancake brass regulator housing at center of manifold
  m.cyl(0, 0.615, 0.125, 0, 0.615, 0.168, 0.034, 0.034, 12, true);
  m.torus(0, 0.648, 0.142, 0.022, 0.005, 10, 6, 'z');

  // --- PART 8: Twin Corrugated Dark Rubber Breathing Hoses (Regulator -> Helmet) ---
  for (const sx of [-1, 1]) {
    m.tag(4, 8);
    const hPts = [
      [sx * 0.028, 0.622, 0.142],
      [sx * 0.115, 0.645, 0.145],
      [sx * 0.178, 0.690, 0.095],
      [sx * 0.188, 0.725, 0.020],
      [sx * 0.152, 0.735, -0.045],
    ];
    m.tube(hPts, 0.017, 9, true);
    // Brass hose coupling ferrule
    m.tag(2, 8);
    m.torus(sx * 0.155, 0.735, -0.042, 0.020, 0.005, 9, 5, 'x');
  }

  // --- PART 1: Iconic Oversized Mark V Copper Diving Helmet (Little Nightmares silhouette!) ---
  // Main hammered copper sphere dome (centered at y = 0.785, radius ~0.168)
  m.tag(1, 1);
  m.ellipsoid(0, 0.785, 0, 0.166, 0.174, 0.168, 22, 16, null, (tv) => mix(1.0, 0.72, pow(tv, 2)));
  // Copper lower helmet skirt joining the neck ring
  m.cyl(0, 0.612, 0, 0, 0.675, 0, 0.118, 0.138, 16, false);

  // Large Front Brass Porthole (-Z face) + Glowing Warm Amber Faceplate + Crossed Brass Grille
  m.tag(2, 1);
  m.torus(0, 0.785, -0.150, 0.088, 0.018, 20, 9, 'z');
  m.cyl(0, 0.785, -0.135, 0, 0.785, -0.166, 0.094, 0.090, 18, false);
  // Warm glowing glass faceplate
  m.tag(3, 1);
  m.ellipsoid(0, 0.785, -0.152, 0.082, 0.082, 0.024, 18, 10);
  // Crossed protective Mark V brass lattice bars over front glass
  m.tag(2, 1);
  m.cyl(-0.086, 0.785, -0.174, 0.086, 0.785, -0.174, 0.0065, 0.0065, 6, false);
  m.cyl(0, 0.699, -0.174, 0, 0.871, -0.174, 0.0065, 0.0065, 6, false);

  // Left & Right Circular Side Brass Portholes + Glowing Glass + Guard Bar
  for (const sx of [-1, 1]) {
    m.tag(2, 1);
    m.torus(sx * 0.152, 0.785, -0.005, 0.054, 0.013, 14, 7, 'x');
    m.cyl(sx * 0.168, 0.731, -0.005, sx * 0.168, 0.839, -0.005, 0.0055, 0.0055, 6, false);
    m.tag(3, 1);
    m.ellipsoid(sx * 0.153, 0.785, -0.005, 0.018, 0.049, 0.049, 12, 8);
  }

  // Angled Upper-Front Mark V Top Observation Window + Forehead Brass Dive Lamp
  const topQ = qAxis(1, 0, 0, 0.82);
  m.tag(2, 1);
  m.torus(0, 0.908, -0.095, 0.042, 0.011, 14, 6, 'z', topQ);
  m.tag(3, 1);
  m.ellipsoid(0, 0.908, -0.095, 0.037, 0.037, 0.014, 12, 7, topQ);

  // Vintage Brass Forehead Headlamp Canister on Crown + Glowing Tungsten Lens
  m.tag(2, 1);
  m.cyl(0, 0.955, -0.01, 0, 0.955, -0.068, 0.024, 0.029, 12, true);
  m.torus(0, 0.955, -0.068, 0.028, 0.006, 12, 6, 'z');
  m.tag(7, 1);
  m.ellipsoid(0, 0.955, -0.068, 0.024, 0.024, 0.010, 10, 6);

  // Top Brass Lifting Ring & Side Brass Bubble-Exhaust Valve Knob
  m.tag(2, 1);
  m.torus(0, 0.968, 0.045, 0.022, 0.006, 10, 6, 'x');
  m.cyl(0.145, 0.865, 0.055, 0.175, 0.885, 0.065, 0.014, 0.018, 8, true);

  // --- PARTS 2 & 3: Left & Right Vintage Canvas Arms + Brass Cuffs + Rubber Mittens ---
  for (let s = 0; s < 2; s++) {
    const sx = s === 0 ? -1 : 1, part = s === 0 ? 2 : 3;
    m.tag(0, part);
    m.ellipsoid(sx * 0.155, 0.542, 0, 0.046, 0.046, 0.044, 10, 8);
    m.tube([
      [sx * 0.158, 0.540, 0.00],
      [sx * 0.176, 0.455, 0.008],
      [sx * 0.182, 0.375, -0.022],
    ], (t) => mix(0.041, 0.033, t), 10, true);
    // Brass waterproof wrist-cuff ring
    m.tag(2, part);
    m.torus(sx * 0.182, 0.372, -0.022, 0.034, 0.008, 10, 6, 'y');
    // Vintage dark vulcanized-rubber diving mitten + thumb
    m.tag(4, part);
    m.ellipsoid(sx * 0.182, 0.334, -0.030, 0.030, 0.038, 0.034, 10, 8);
    m.ellipsoid(sx * 0.158, 0.342, -0.052, 0.014, 0.018, 0.016, 7, 6);
  }

  // --- PARTS 4,5 & 6,7: Vintage Canvas Legs + Heavy Brass Diving Boots + Strapped Scuba Fins ---
  for (let s = 0; s < 2; s++) {
    const sx = s === 0 ? -1 : 1, legP = s === 0 ? 4 : 5, finP = s === 0 ? 6 : 7;
    const lx = sx * 0.072;
    // Canvas trouser leg
    m.tag(0, legP);
    m.tube([
      [lx, 0.295, 0.00],
      [lx * 1.04, 0.185, -0.008],
      [lx * 1.05, 0.085, 0.002],
    ], (t) => mix(0.052, 0.041, t), 11, true);
    // Leather knee patch
    m.tag(5, legP);
    m.ellipsoid(lx * 1.04, 0.185, -0.044, 0.028, 0.032, 0.014, 8, 6);
    // Heavy vintage deep-sea boot upper + brass ankle cuff + thick lead sole + domed brass toe cap
    m.cyl(lx * 1.05, 0.022, 0.002, lx * 1.05, 0.092, 0.002, 0.046, 0.044, 10, true);
    m.box(lx * 1.05, 0.014, -0.024, 0.046, 0.014, 0.076, null, 0.65);
    m.tag(2, legP);
    m.torus(lx * 1.05, 0.092, 0.002, 0.044, 0.008, 10, 5, 'y');
    m.ellipsoid(lx * 1.05, 0.038, -0.062, 0.045, 0.034, 0.048, 11, 8, null, () => 0.9);
    // Brass heel fin-strap buckle
    m.box(lx * 1.05, 0.034, 0.052, 0.038, 0.012, 0.012);

    // Classic 1940s frogman strapped dark-rubber swim flipper blade (trails cleanly when swimming!)
    m.tag(4, finP);
    const finSeg = 5;
    const fRings = [];
    for (let k = 0; k <= finSeg; k++) {
      const t = k / finSeg;
      const w = mix(0.038, 0.074, pow(t, 0.65));
      const th = mix(0.011, 0.004, t);
      const fy = mix(0.024, 0.005, t);
      const fz = mix(-0.092, -0.215, t);
      const ring = [];
      for (let j = 0; j <= 8; j++) {
        const a = j / 8 * TAU;
        ring.push(m.v(lx * 1.05 + cos(a) * w, fy + sin(a) * th, fz, 0.85, j / 8, t));
      }
      fRings.push(ring);
    }
    for (let k = 0; k < finSeg; k++) {
      for (let j = 0; j < 8; j++) {
        m.quad(fRings[k][j], fRings[k + 1][j], fRings[k + 1][j + 1], fRings[k][j + 1]);
      }
    }
  }

  // --- PART 9: Vintage Brass & Mahogany Hand-Held Scuba Harpoon Gun ---
  // Each of the six crew members carries a compact spring-loaded reef harpoon.
  // The steel shaft is animated in W_DIVER; firing recoil and the tether are live simulation state.
  m.tag(5, 9);
  m.box(0.205, 0.355, 0.018, 0.034, 0.024, 0.060, null, 0.88); // dark mahogany stock
  m.cyl(0.205, 0.345, -0.005, 0.205, 0.288, 0.018, 0.018, 0.014, 8, true); // rubber pistol grip
  m.tag(2, 9);
  m.cyl(0.205, 0.358, -0.025, 0.205, 0.358, -0.355, 0.017, 0.012, 10, true); // burnished brass barrel
  m.torus(0.205, 0.358, -0.080, 0.018, 0.004, 10, 5, 'z');
  m.torus(0.205, 0.358, -0.315, 0.013, 0.003, 10, 5, 'z');
  // Loaded steel spear with opposing barbs and a bright brass tip
  m.tag(4, 9);
  m.cyl(0.205, 0.358, -0.325, 0.205, 0.358, -0.535, 0.0055, 0.002, 7, true);
  m.tag(2, 9);
  m.cyl(0.205, 0.358, -0.505, 0.205, 0.358, -0.555, 0.009, 0.0008, 5, true);
  m.cyl(0.205, 0.358, -0.405, 0.187, 0.358, -0.445, 0.003, 0.0009, 5, false);
  m.cyl(0.205, 0.358, -0.405, 0.223, 0.358, -0.445, 0.003, 0.0009, 5, false);
  // Brass reel housing & tightly wound dark tether spool on the stock
  m.tag(2, 9);
  m.torus(0.205, 0.394, 0.048, 0.025, 0.006, 12, 6, 'x');
  m.tag(4, 9);
  m.cyl(0.205, 0.394, 0.028, 0.205, 0.394, 0.068, 0.009, 0.009, 8, true);
  m.tag(2, 9);
  m.cyl(0.174, 0.386, 0.018, 0.236, 0.386, 0.018, 0.004, 0.004, 6, false); // simple trigger guard

  return m.build();
}

// Submarine material IDs:
// 10=riveted iron-bronze hull, 11=burnished brass, 12=vintage ochre-gold stripe,
// 13=panoramic bubble dome glass, 14=side porthole glass, 15=polished brass propeller,
// 16=searchlight tungsten lens, 17=dark cast-iron keel/fins, 18=top navigation beacon
// 1=copper crew helmet, 3=warm crew visor
// Submarine part IDs:
// 0=hull, 1=propeller, 2=rudder, 3=dive planes, 4=top hatch, 5..10=6 crew inside windows
export function buildSubmarineMesh() {
  const m = new EntityMesh();

  // --- PART 0: Streamlined Riveted Jules Verne Pressure Hull (-Z bow, +Z stern) ---
  m.tag(10, 0);
  const hullProf = [
    [0.64, -1.86, 0.92],
    [0.73, -1.55, 0.96],
    [0.79, -1.10, 1.00],
    [0.82, -0.55, 1.00],
    [0.81, 0.05, 1.00],
    [0.76, 0.62, 0.98],
    [0.66, 1.12, 0.96],
    [0.50, 1.56, 0.94],
    [0.32, 1.92, 0.90],
    [0.16, 2.15, 0.85],
    [0.00, 2.20, 0.82],
  ];
  m.lathe(0, 0, 0, hullProf, 28, 'z', 0.94);

  // Raised Circumferential Brass Structural Hull Ribs
  m.tag(11, 0);
  for (const [rz, rr] of [[-1.85, 0.655], [-1.35, 0.765], [-0.65, 0.822], [0.15, 0.808], [0.92, 0.705], [1.56, 0.505]]) {
    m.torus(0, 0, rz, rr * 0.97, 0.026, 26, 8, 'z');
  }

  // Vintage Ochre-Mustard Expedition Stripe + Lateral Ballast Saddle Tanks
  for (const sx of [-1, 1]) {
    m.tag(12, 0);
    m.box(sx * 0.77, 0.08, -0.35, 0.045, 0.065, 1.18, null, 0.95);
    // Lower riveted ballast saddle tank
    m.tag(10, 0);
    m.ellipsoid(sx * 0.70, -0.28, -0.28, 0.22, 0.19, 1.18, 16, 10, null, () => 0.84);
    // Brass ballast tank straps
    m.tag(11, 0);
    for (const bz of [-0.95, -0.28, 0.38]) {
      m.torus(sx * 0.70, -0.28, bz, 0.20, 0.016, 14, 6, 'z');
    }
    // Tiny Little Nightmares-scale brass boarding ladder rungs climbing up the hull to the hatch!
    for (let k = 0; k < 7; k++) {
      const a = mix(0.05, 0.92, k / 6);
      const rx = sx * (cos(a) * 0.84), ry = sin(a) * 0.80;
      m.cyl(rx, ry, -0.02, rx, ry, -0.18, 0.012, 0.012, 6, true);
    }
  }

  // Heavy Dark Cast-Iron Ventral Keel + Twin Seabed Landing Skids
  m.tag(17, 0);
  m.box(0, -0.80, -0.15, 0.08, 0.14, 1.62, null, 0.65);
  for (const sx of [-0.46, 0.46]) {
    // Horizontal landing runner
    m.cyl(sx, -0.92, -1.25, sx, -0.92, 0.95, 0.036, 0.036, 8, true);
    // Curved upturned ski tip at front
    m.cyl(sx, -0.92, -1.25, sx, -0.78, -1.52, 0.036, 0.028, 8, true);
    // Strut legs connecting hull to skid
    m.cyl(sx * 0.85, -0.62, -0.88, sx, -0.92, -0.88, 0.028, 0.028, 7, false);
    m.cyl(sx * 0.85, -0.62, 0.55, sx, -0.92, 0.55, 0.028, 0.028, 7, false);
  }

  // --- Panoramic Forward Brass-Framed Observation Cockpit Dome + Skylight (-Z nose) ---
  m.tag(13, 0);
  m.ellipsoid(0, 0.02, -1.84, 0.65, 0.62, 0.60, 26, 16);
  // Upper panoramic cockpit skylight window integrated ahead of conning tower
  m.ellipsoid(0, 0.68, -1.18, 0.34, 0.16, 0.38, 18, 10);
  m.tag(11, 0);
  m.torus(0, 0.67, -1.18, 0.35, 0.024, 18, 7, 'y');
  // Riveted brass main cockpit bezel collar + wide-view curved meridian ribs (open center window!)
  m.torus(0, 0.02, -1.84, 0.655, 0.030, 26, 8, 'z');
  for (const a of [-2.45, -0.69, 0.62, 2.52]) {
    const pts = [];
    for (let j = 0; j <= 8; j++) {
      const t = j / 8, ph = mix(0.18, PI * 0.5, t);
      pts.push([cos(a) * sin(ph) * 0.665, 0.02 + sin(a) * sin(ph) * 0.635, -1.84 - cos(ph) * 0.612]);
    }
    m.tube(pts, 0.019, 8, false);
  }
  // Visible interior brass helm wheel & warm instrument console silhouette inside the forward dome
  m.box(0, -0.22, -1.96, 0.34, 0.12, 0.14, qAxis(1, 0, 0, 0.25));
  m.torus(0, -0.10, -1.86, 0.11, 0.014, 14, 6, 'z');
  // Jules Verne curved brass bow bumper / chin guard below dome
  m.tube([
    [-0.64, -0.34, -1.75],
    [-0.50, -0.45, -2.20],
    [0.0, -0.49, -2.46],
    [0.50, -0.45, -2.20],
    [0.64, -0.34, -1.75],
  ], 0.025, 8, true);

  // Twin Vintage Brass Bow Searchlights + Glowing Tungsten Lenses
  for (const sx of [-0.56, 0.56]) {
    m.tag(11, 0);
    m.cyl(sx * 0.86, -0.28, -1.72, sx, -0.34, -1.78, 0.024, 0.024, 7, false);
    m.cyl(sx, -0.34, -1.66, sx, -0.34, -1.96, 0.085, 0.115, 14, true);
    m.torus(sx, -0.34, -1.96, 0.112, 0.016, 14, 7, 'z');
    m.tag(16, 0);
    m.ellipsoid(sx, -0.34, -1.95, 0.098, 0.098, 0.032, 12, 8);
  }

  // --- 6 Round Bolted Brass Side Portholes (3 port, 3 starboard) ---
  for (const sx of [-1, 1]) {
    for (const [pz, rx] of [[-1.02, 0.77], [-0.26, 0.80], [0.50, 0.75]]) {
      m.tag(11, 0);
      m.torus(sx * rx, 0.16, pz, 0.155, 0.030, 16, 8, 'x');
      // Cross brass mullion
      m.cyl(sx * (rx + 0.025), 0.01, pz, sx * (rx + 0.025), 0.31, pz, 0.010, 0.010, 6, false);
      m.tag(14, 0);
      m.ellipsoid(sx * (rx - 0.005), 0.16, pz, 0.035, 0.138, 0.138, 14, 8);
    }
  }

  // --- Classic Conning Tower (Sail) + Top Hatch + Vintage Brass Periscope + Beacon ---
  m.tag(10, 0);
  m.lathe(0, 0, -0.18, [
    [0.38, 0.62, 0.78],
    [0.35, 0.85, 0.94],
    [0.33, 1.12, 1.00],
    [0.35, 1.17, 1.00],
    [0.00, 1.18, 0.98],
  ], 20, 'y', 1.48);
  // Flared brass conning-tower crown collar + vintage nameplate + small bridge porthole
  m.tag(11, 0);
  m.lathe(0, 0, -0.18, [
    [0.355, 1.11, 0.95],
    [0.375, 1.16, 1.00],
    [0.345, 1.20, 1.00],
  ], 20, 'y', 1.48);
  m.torus(0, 0.95, -0.68, 0.095, 0.022, 14, 7, 'z');
  m.tag(14, 0);
  m.ellipsoid(0, 0.95, -0.68, 0.082, 0.082, 0.025, 12, 7);
  m.tag(12, 0);
  m.box(-0.35, 0.94, -0.18, 0.02, 0.07, 0.22);
  m.box(0.35, 0.94, -0.18, 0.02, 0.07, 0.22);

  // Curved Vintage Brass Periscope + Scope Hood + Navigation Beacon Mast
  m.tag(11, 0);
  m.tube([
    [0.0, 1.17, -0.44],
    [0.0, 1.56, -0.44],
    [0.0, 1.70, -0.47],
    [0.0, 1.73, -0.60],
  ], (t) => mix(0.044, 0.056, t), 12, true);
  m.torus(0, 1.73, -0.61, 0.058, 0.012, 12, 6, 'z');
  m.tag(14, 0);
  m.ellipsoid(0, 1.73, -0.60, 0.048, 0.048, 0.018, 10, 6);

  // Aft conning-tower brass radio/lantern mast + warm pulsing navigation beacon
  m.tag(11, 0);
  m.cyl(0, 1.17, 0.14, 0, 1.56, 0.20, 0.022, 0.014, 8, true);
  m.torus(0, 1.58, 0.20, 0.044, 0.008, 10, 5, 'y');
  m.tag(18, 0);
  m.ellipsoid(0, 1.60, 0.20, 0.038, 0.048, 0.038, 10, 8);

  // Top Deck Brass Handrails (fore & aft of conning tower — tiny diver scale!)
  m.tag(11, 0);
  for (const sx of [-0.28, 0.28]) {
    m.cyl(sx, 0.88, -1.48, sx, 0.92, -0.72, 0.012, 0.012, 6, true);
    m.cyl(sx, 0.72, -1.42, sx, 0.88, -1.42, 0.011, 0.011, 6, false);
    m.cyl(sx, 0.76, -1.06, sx, 0.90, -1.06, 0.011, 0.011, 6, false);
    m.cyl(sx, 0.88, 0.34, sx, 0.78, 1.12, 0.012, 0.012, 6, true);
    m.cyl(sx, 0.74, 0.55, sx, 0.85, 0.55, 0.011, 0.011, 6, false);
    m.cyl(sx, 0.66, 1.05, sx, 0.79, 1.05, 0.011, 0.011, 6, false);
  }

  // --- PART 4: Hinged Circular Brass Diver Airlock Hatch + Locking Wheel ---
  m.tag(11, 4);
  m.cyl(0, 1.17, -0.10, 0, 1.24, -0.10, 0.25, 0.23, 16, true);
  m.torus(0, 1.29, -0.10, 0.11, 0.015, 14, 6, 'y');
  m.cyl(0, 1.24, -0.10, 0, 1.30, -0.10, 0.020, 0.020, 8, true);
  m.cyl(-0.11, 1.29, -0.10, 0.11, 0.0 + 1.29, -0.10, 0.010, 0.010, 6, false);
  m.cyl(0, 1.29, -0.21, 0, 1.29, 0.01, 0.010, 0.010, 6, false);

  // --- Stern Fixed Stabilizer Fins + Brass Kort-Nozzle Propeller Shroud ---
  m.tag(17, 0);
  // Fixed dorsal & ventral fin roots
  m.box(0, 0.38, 1.78, 0.032, 0.28, 0.28, qAxis(1, 0, 0, -0.25));
  m.box(0, -0.40, 1.78, 0.032, 0.26, 0.26, qAxis(1, 0, 0, 0.25));
  // Brass Kort nozzle shroud ring around propeller
  m.tag(11, 0);
  m.lathe(0, -0.02, 2.20, [
    [0.44, -0.14, 0.9],
    [0.47, 0.0, 1.0],
    [0.43, 0.14, 0.92],
    [0.40, 0.0, 0.8],
    [0.44, -0.14, 0.9],
  ], 24, 'z');
  // 4 struts linking hull tail to Kort nozzle
  for (let k = 0; k < 4; k++) {
    const a = k * PI / 2 + PI / 4;
    m.cyl(cos(a) * 0.16, -0.02 + sin(a) * 0.16, 2.08, cos(a) * 0.42, -0.02 + sin(a) * 0.42, 2.18, 0.018, 0.018, 6, false);
  }

  // --- PART 2: Articulated Stern Vertical Rudder ---
  m.tag(17, 2);
  m.box(0, 0.0, 1.98, 0.026, 0.56, 0.16);
  m.tag(11, 2);
  m.cyl(0, -0.58, 1.92, 0, 0.58, 1.92, 0.022, 0.022, 8, true);

  // --- PART 3: Articulated Bow & Stern Horizontal Dive Planes (Hydroplanes) ---
  for (const sx of [-1, 1]) {
    m.tag(17, 3);
    // Forward bow hydroplane
    m.box(sx * 0.92, -0.06, -1.18, 0.24, 0.024, 0.14);
    // Aft stern hydroplane
    m.box(sx * 0.56, -0.04, 1.82, 0.28, 0.024, 0.15);
    m.tag(11, 3);
    m.torus(sx * 0.72, -0.06, -1.18, 0.048, 0.014, 10, 5, 'x');
  }

  // --- PART 1: Spinning 5-Blade Polished Brass Screw Propeller ---
  m.tag(15, 1);
  m.cyl(0, -0.04, 2.08, 0, -0.04, 2.34, 0.095, 0.022, 14, true);
  for (let k = 0; k < 5; k++) {
    const a = k / 5 * TAU;
    const bx = cos(a) * 0.22, by = -0.04 + sin(a) * 0.22;
    const q = qMul(qAxis(0, 0, 1, a), qAxis(1, 0, 0, 0.52));
    m.ellipsoid(bx, by, 2.20, 0.165, 0.072, 0.016, 10, 7, q, () => 0.96);
  }

  // --- PARTS 5..10: Cute Copper-Helmeted Crew Visible Inside Forward Dome & Portholes! ---
  const addWindowDiver = (part, x, y, z, faceYaw) => {
    const q = qAxis(0, 1, 0, faceYaw);
    m.tag(1, part);
    m.ellipsoid(x, y, z, 0.105, 0.11, 0.105, 12, 9, q);
    const fx = -sin(faceYaw) * 0.095, fz = -cos(faceYaw) * 0.095;
    m.tag(3, part);
    m.ellipsoid(x + fx, y + 0.005, z + fz, 0.062, 0.062, 0.032, 10, 7, q);
  };
  // Pilot (Player, part 5) & Co-pilot (Bot 1, part 6) visible inside panoramic forward bubble dome!
  addWindowDiver(5, -0.15, 0.06, -2.02, 0.08);
  addWindowDiver(6, 0.18, 0.03, -1.98, -0.12);
  // Bots 2..5 peering out the cozy round side porthole windows!
  addWindowDiver(7, -0.69, 0.15, -1.02, PI / 2);
  addWindowDiver(8, 0.69, 0.15, -1.02, -PI / 2);
  addWindowDiver(9, -0.72, 0.15, -0.26, PI / 2);
  addWindowDiver(10, 0.72, 0.15, -0.26, -PI / 2);

  return m.build();
}

// ---------------------------------------------------------------- 3D Vintage Submarine Cockpit Interior
// Centered at captain's eye (0, 0, 0), looking forward along -Z (+X right, +Y up).
// Cockpit material IDs:
// 20=riveted dark bronze bulkhead, 21=burnished marine brass, 22=polished antique mahogany wood,
// 23=hammered copper pipes & co-pilot helmet, 24=painted crimson valve wheel & brass trim,
// 25=live CRT phosphor Sonar screen, 26=antique ivory Depth manometer, 27=antique ivory Speed gauge,
// 28=gimbaled brass Compass rose, 29=warm tungsten cabin lantern & crew indicator bulbs,
// 30=subtle curved dome glass rim sheen, 31=co-pilot warm glowing visor
// Cockpit animated part IDs:
// 0=static cabin & console, 1=spoked brass helm wheel, 2=engine telegraph lever,
// 3=ballast dive lever, 4=swaying cabin lanterns, 5=co-pilot companion diver
export function buildCockpitMesh() {
  const m = new EntityMesh();

  // Helper: planar polar-UV instrument face pointing toward pilot (+Z in local frame)
  const dialFace = (cx, cy, cz, r, seg, q) => {
    const c = m.v(cx, cy, cz, 1, 0.5, 0.5);
    const ring = [];
    for (let s = 0; s <= seg; s++) {
      const a = s / seg * TAU;
      const ca = cos(a), sa = sin(a);
      let lx = ca * r, ly = sa * r, lz = 0;
      if (q) [lx, ly, lz] = qRot(q, lx, ly, lz);
      ring.push(m.v(cx + lx, cy + ly, cz + lz, 1, 0.5 + 0.5 * ca, 0.5 + 0.5 * sa));
    }
    for (let s = 0; s < seg; s++) m.tri(c, ring[s], ring[s + 1]);
  };

  // --- 1. Wide-Open Panoramic Brass Observation Dome Framing (unobstructed center & skylight!) ---
  m.tag(21, 0);
  // Upper forward curved brass brow arch (leaves giant crystal-clear main viewport!)
  const browPts = [];
  for (let k = 0; k <= 20; k++) {
    const a = mix(-0.32, PI + 0.32, k / 20);
    const x = cos(a) * 0.62;
    const y = 0.02 + sin(a) * 0.34;
    const z = -0.44 - sin(a) * 0.14;
    browPts.push([x, y, z]);
  }
  m.tube(browPts, 0.018, 10, false);
  // Raised brass rivets studded along the panoramic brow arch
  for (let k = 1; k < 20; k++) {
    const p = browPts[k];
    m.ellipsoid(p[0] * 0.975, p[1] * 0.975, p[2] + 0.014, 0.0055, 0.0055, 0.0055, 6, 5);
  }

  // Lower curved brass windshield sill cradling the instrument bridge
  const sillPts = [];
  for (let k = 0; k <= 20; k++) {
    const u = (k / 20) * 2 - 1; // -1..+1
    const a = u * 1.38;
    sillPts.push([sin(a) * 0.64, -0.175 - 0.03 * (1 - u * u), -cos(a) * 0.60]);
  }
  m.tube(sillPts, 0.017, 9, false);

  // Two slender angled corner A-pillars at x = ±0.56 (wide 98-degree unobstructed front vista!)
  // plus sweeping overhead skylight cupola ribs so looking UP shows the 10x Manta Ray overhead!
  for (const sx of [-1, 1]) {
    const skyRib = [];
    for (let k = 0; k <= 12; k++) {
      const t = k / 12;
      skyRib.push([
        sx * mix(0.46, 0.42, t),
        0.24 + sin(t * PI) * 0.28,
        mix(-0.52, 0.38, t),
      ]);
    }
    m.tag(21, 0);
    m.tube(skyRib, 0.015, 8, false);
    for (let k = 1; k < 12; k += 2) {
      const p = skyRib[k];
      m.ellipsoid(p[0] * 0.96, p[1] - 0.012, p[2], 0.005, 0.005, 0.005, 5, 4);
    }

    // Side panoramic window frame pillar (frames far left/right edges while keeping 90% center view wide open!)
    m.tube([
      [sx * 0.51, -0.22, -0.41],
      [sx * 0.54, 0.04, -0.43],
      [sx * 0.49, 0.26, -0.46],
    ], 0.018, 9, false);

    // Aft side brass bulkhead arch
    m.tube([
      [sx * 0.56, -0.36, 0.14],
      [sx * 0.60, 0.05, 0.14],
      [sx * 0.45, 0.44, 0.12],
    ], 0.022, 9, false);

    // Curved hammered-copper pressure pipe running gracefully along upper-outer cockpit wall
    m.tag(23, 0);
    m.tube([
      [sx * 0.52, -0.28, -0.30],
      [sx * 0.56, 0.02, -0.31],
      [sx * 0.50, 0.25, -0.36],
      [sx * 0.42, 0.44, -0.10],
      [sx * 0.38, 0.46, 0.28],
    ], 0.011, 8, false);
    // Brass pipe flange rings
    m.tag(21, 0);
    m.torus(sx * 0.55, 0.02, -0.31, 0.015, 0.004, 8, 5, 'y');
    m.torus(sx * 0.49, 0.25, -0.36, 0.015, 0.004, 8, 5, 'y');
  }

  // Overhead aft skylight cross-arch + stowed brass periscope column behind/above pilot
  m.tag(21, 0);
  const aftArch = [];
  for (let k = 0; k <= 14; k++) {
    const u = (k / 14) * 2 - 1;
    aftArch.push([u * 0.45, 0.44 + (1 - u * u) * 0.10, 0.12]);
  }
  m.tube(aftArch, 0.020, 9, false);
  // Vintage crimson-painted ballast emergency handwheel on port (left) pillar
  m.tag(24, 0);
  m.torus(-0.53, -0.04, -0.31, 0.052, 0.007, 14, 6, 'x');
  m.cyl(-0.57, -0.04, -0.31, -0.52, -0.04, -0.31, 0.010, 0.010, 7, true);
  m.cyl(-0.53, -0.09, -0.31, -0.53, 0.01, -0.31, 0.005, 0.005, 6, false);
  m.cyl(-0.53, -0.04, -0.36, -0.53, -0.04, -0.26, 0.005, 0.005, 6, false);

  // --- 2. Lower Riveted-Bronze Hull Tub, Rear Cabin Bulkhead & Cabin Deck ---
  m.tag(20, 0);
  // Lower curved cockpit wall below windows (never blocks the panoramic glass!)
  const tubRows = [
    [-0.48, 0.56, 0.55],
    [-0.36, 0.62, 0.78],
    [-0.20, 0.63, 0.92],
  ];
  const tRings = [];
  for (let r = 0; r < tubRows.length; r++) {
    const [yy, rad, ao] = tubRows[r];
    const ring = [];
    for (let s = 0; s <= 24; s++) {
      const a = s / 24 * TAU;
      ring.push(m.v(sin(a) * rad, yy, -cos(a) * rad * 0.94, ao, s / 24, r / 2));
    }
    tRings.push(ring);
  }
  for (let r = 0; r < 2; r++) {
    for (let s = 0; s < 24; s++) {
      // Inward-facing normals toward pilot at (0,0,0)
      m.quad(tRings[r][s], tRings[r][s + 1], tRings[r + 1][s + 1], tRings[r + 1][s]);
    }
  }
  // Aft curved bronze pressure bulkhead (only behind z > +0.16 so front/side/top stay 100% open!)
  const bRings = [];
  for (let r = 0; r <= 6; r++) {
    const t = r / 6, yy = mix(-0.22, 0.52, t);
    const rad = mix(0.62, 0.44, pow(t, 1.4));
    const ring = [];
    for (let s = 0; s <= 12; s++) {
      const a = mix(PI * 0.58, PI * 1.42, s / 12);
      ring.push(m.v(sin(a) * rad, yy, -cos(a) * rad * 0.85, 0.82, s / 12, t));
    }
    bRings.push(ring);
  }
  for (let r = 0; r < 6; r++) {
    for (let s = 0; s < 12; s++) {
      m.quad(bRings[r][s], bRings[r][s + 1], bRings[r + 1][s + 1], bRings[r + 1][s]);
    }
  }
  // Cabin wooden grating floor
  m.tag(22, 0);
  m.box(0, -0.48, -0.05, 0.52, 0.02, 0.50, null, 0.55);

  // --- 3. Curved Antique Mahogany & Burnished-Brass Bridge Instrument Console ---
  const cTilt = qAxis(1, 0, 0, -0.34); // faces upward & back toward pilot eyes!
  // Main center mahogany instrument desk + side wing panels
  m.tag(22, 0);
  m.box(0, -0.255, -0.49, 0.25, 0.095, 0.065, cTilt, 0.94);
  m.box(-0.31, -0.262, -0.42, 0.13, 0.088, 0.062, qMul(qAxis(0, 1, 0, 0.46), cTilt), 0.92);
  m.box(0.31, -0.262, -0.42, 0.13, 0.088, 0.062, qMul(qAxis(0, 1, 0, -0.46), cTilt), 0.92);
  // Horizontal mahogany dashboard shelf lip + gleaming brass rail trim
  m.tag(21, 0);
  m.tube([
    [-0.42, -0.185, -0.36],
    [-0.24, -0.172, -0.46],
    [0.0, -0.165, -0.50],
    [0.24, -0.172, -0.46],
    [0.42, -0.185, -0.36],
  ], 0.011, 8, true);
  // Riveted dark-bronze pedestal column under console
  m.tag(20, 0);
  m.box(0, -0.39, -0.46, 0.22, 0.09, 0.08, null, 0.72);

  // --- 4. LIVE INSTRUMENTS: Center CRT Sonar, Depth Manometer, Knot Gauge & Gimbal Compass ---
  // (a) Center Round Brass-Bezeled Live Sonar CRT Display (detects 10x Manta Ray in real time!)
  const sonX = 0, sonY = -0.222, sonZ = -0.432, sonR = 0.066;
  m.tag(21, 0);
  m.torus(sonX, sonY, sonZ, sonR + 0.006, 0.010, 22, 8, 'z', cTilt);
  // Anti-glare upper brass hood over sonar + 8 bezel rivets
  for (let k = 0; k < 8; k++) {
    const a = k / 8 * TAU;
    const o = qRot(cTilt, cos(a) * (sonR + 0.008), sin(a) * (sonR + 0.008), 0.009);
    m.ellipsoid(sonX + o[0], sonY + o[1], sonZ + o[2], 0.0032, 0.0032, 0.0032, 5, 4);
  }
  m.tag(25, 0);
  dialFace(sonX, sonY, sonZ + 0.003, sonR, 24, cTilt);

  // (b) Port (Left) Vintage Brass Depth Manometer (live rotating depth needle!)
  const depX = -0.145, depY = -0.225, depZ = -0.425, depR = 0.046;
  m.tag(21, 0);
  m.torus(depX, depY, depZ, depR + 0.005, 0.008, 18, 7, 'z', cTilt);
  m.tag(26, 0);
  dialFace(depX, depY, depZ + 0.003, depR, 20, cTilt);

  // (c) Starboard (Right) Vintage Brass Knot / Speedometer Gauge (live rotating speed needle!)
  const spdX = 0.145, spdY = -0.225, spdZ = -0.425, spdR = 0.046;
  m.tag(21, 0);
  m.torus(spdX, spdY, spdZ, spdR + 0.005, 0.008, 18, 7, 'z', cTilt);
  m.tag(27, 0);
  dialFace(spdX, spdY, spdZ + 0.003, spdR, 20, cTilt);

  // (d) Top-Center Gimbaled Brass Binnacle Compass on Forward Nose Sill (live heading rose!)
  const cmpX = 0, cmpY = -0.142, cmpZ = -0.505, cmpR = 0.028;
  const cmpQ = qAxis(1, 0, 0, -0.48);
  m.tag(21, 0);
  m.torus(cmpX, cmpY, cmpZ, cmpR + 0.006, 0.0055, 18, 6, 'z', cmpQ);
  m.cyl(cmpX - 0.036, cmpY - 0.026, cmpZ, cmpX - 0.036, cmpY + 0.002, cmpZ, 0.004, 0.004, 6, true);
  m.cyl(cmpX + 0.036, cmpY - 0.026, cmpZ, cmpX + 0.036, cmpY + 0.002, cmpZ, 0.004, 0.004, 6, true);
  m.tag(28, 0);
  dialFace(cmpX, cmpY, cmpZ + 0.002, cmpR, 18, cmpQ);

  // (e) 6 Warm Filament Crew-Aboard Bulbs + Searchlight Indicator Jewel + Brass Toggle Switches
  for (let k = 0; k < 6; k++) {
    const bx = mix(-0.068, 0.068, k / 5), by = -0.302, bz = -0.398;
    m.tag(21, 0);
    m.torus(bx, by, bz, 0.0075, 0.0025, 8, 5, 'z', cTilt);
    m.tag(29, 0, (k + 0.5) / 6, 0.2); // u encodes crew slot 0..5!
    m.ellipsoid(bx, by + 0.002, bz + 0.005, 0.006, 0.006, 0.006, 7, 6, null, null, 0, 1);
  }
  // Searchlight indicator lamp (v = 0.85 marks searchlight status lamp!)
  m.tag(21, 0);
  m.torus(-0.215, -0.228, -0.415, 0.011, 0.003, 10, 5, 'z', cTilt);
  m.tag(29, 0, 0.5, 0.85);
  m.ellipsoid(-0.215, -0.226, -0.409, 0.0085, 0.0085, 0.007, 8, 6);
  // Vintage brass toggle switches on side wing panel
  m.tag(21, 0);
  for (let k = 0; k < 3; k++) {
    const tx = 0.215 + k * 0.022;
    m.cyl(tx, -0.265, -0.40, tx, -0.252, -0.382, 0.003, 0.0045, 6, true);
  }

  // --- 5. PART 1: Animated 8-Spoke Brass & Mahogany Submarine Helm Wheel ---
  // Pivot at (0, -0.325, -0.345), spins live around Z as you steer!
  const wx = 0, wy = -0.325, wz = -0.345, wR = 0.096;
  // Brass steering shaft housing (static)
  m.tag(21, 0);
  m.cyl(wx, wy - 0.02, -0.44, wx, wy, wz + 0.01, 0.022, 0.018, 12, true);
  // Mahogany outer wheel rim + inner brass strengthening ring + center brass hub
  m.tag(22, 1);
  m.torus(wx, wy, wz, wR, 0.011, 24, 8, 'z');
  m.tag(21, 1);
  m.torus(wx, wy, wz, wR * 0.62, 0.005, 20, 6, 'z');
  m.ellipsoid(wx, wy, wz + 0.006, 0.022, 0.022, 0.014, 12, 8);
  // 8 turned brass spokes extending into classic outer handle pegs!
  for (let k = 0; k < 8; k++) {
    const a = k / 8 * TAU + PI / 2;
    const ca = cos(a), sa = sin(a);
    m.tag(k === 0 ? 24 : 21, 1); // Top center "king spoke" accented in crimson-brass!
    m.cyl(wx + ca * 0.016, wy + sa * 0.016, wz, wx + ca * (wR + 0.032), wy + sa * (wR + 0.032), wz, 0.0048, 0.0062, 7, true);
    m.tag(21, 1);
    m.ellipsoid(wx + ca * (wR + 0.034), wy + sa * (wR + 0.034), wz, 0.0085, 0.0085, 0.0085, 7, 6);
  }

  // --- 6. PART 2: Animated Chadburn Brass Engine Order Telegraph (Port / Left) ---
  // Pivot at (-0.285, -0.235, -0.385), tilts forward/back with W/S & Shift!
  const etX = -0.285, etY = -0.235, etZ = -0.385;
  m.tag(21, 0);
  m.cyl(etX - 0.016, etY, etZ, etX + 0.016, etY, etZ, 0.038, 0.038, 16, true);
  m.tag(24, 0);
  m.torus(etX + 0.016, etY, etZ, 0.034, 0.004, 14, 5, 'x');
  m.tag(21, 2);
  m.cyl(etX + 0.020, etY, etZ, etX + 0.024, etY + 0.095, etZ, 0.005, 0.0045, 7, true);
  m.tag(24, 2);
  m.ellipsoid(etX + 0.025, etY + 0.104, etZ, 0.014, 0.016, 0.014, 9, 7);
  m.tag(21, 2);
  m.torus(etX + 0.025, etY + 0.104, etZ, 0.0145, 0.003, 9, 5, 'y');

  // --- 7. PART 3: Animated Copper Ballast Dive-Plane Lever (Starboard / Right) ---
  // Pivot at (+0.285, -0.235, -0.385), tilts forward/back with E/Q ascent/descent!
  const blX = 0.285, blY = -0.235, blZ = -0.385;
  m.tag(21, 0);
  m.cyl(blX - 0.016, blY, blZ, blX + 0.016, blY, blZ, 0.034, 0.034, 14, true);
  m.tag(21, 3);
  m.cyl(blX - 0.020, blY, blZ, blX - 0.024, blY + 0.088, blZ, 0.005, 0.0045, 7, true);
  // T-bar copper dive grip
  m.tag(23, 3);
  m.cyl(blX - 0.048, blY + 0.092, blZ, blX + 0.002, blY + 0.092, blZ, 0.009, 0.009, 8, true);

  // --- 8. PART 4: Twin Hanging Warm Tungsten Brass Cabin Lanterns (upper corners) ---
  for (const sx of [-1, 1]) {
    const lx = sx * 0.43, ly = 0.265, lz = -0.42;
    m.tag(21, 4);
    m.cyl(lx, ly + 0.035, lz, lx, ly + 0.008, lz, 0.004, 0.014, 8, true);
    m.cyl(lx, ly - 0.036, lz, lx, ly - 0.026, lz, 0.013, 0.007, 8, true);
    // Warm glowing glass lantern globe (v = 0.5 marks steady warm cabin lamp!)
    m.tag(29, 4, 0.5, 0.5);
    m.ellipsoid(lx, ly - 0.009, lz, 0.014, 0.020, 0.014, 10, 8);
  }

  // --- 9. PART 5: Cute Copper-Helmeted Companion Friend Co-Pilot on Starboard Seat! ---
  const cpX = 0.40, cpY = -0.23, cpZ = -0.17;
  const cpQ = qAxis(0, 1, 0, 0.42);
  // Vintage canvas shoulders + copper corselet
  m.tag(23, 5);
  m.ellipsoid(cpX, cpY - 0.10, cpZ, 0.095, 0.065, 0.075, 12, 8, cpQ);
  m.tag(21, 5);
  m.torus(cpX, cpY - 0.055, cpZ, 0.072, 0.010, 12, 6, 'y');
  // Antique copper Mark V diving helmet + brass portholes + warm glowing visor
  m.tag(23, 5);
  m.ellipsoid(cpX, cpY + 0.03, cpZ, 0.088, 0.092, 0.088, 16, 12, cpQ);
  const fOff = qRot(cpQ, 0, 0, -0.082);
  const sOff = qRot(cpQ, -0.082, 0, 0);
  m.tag(21, 5);
  m.torus(cpX + fOff[0], cpY + 0.03, cpZ + fOff[2], 0.048, 0.009, 14, 6, 'z', cpQ);
  m.torus(cpX + sOff[0], cpY + 0.03, cpZ + sOff[2], 0.032, 0.007, 12, 5, 'x', cpQ);
  m.tag(31, 5);
  m.ellipsoid(cpX + fOff[0], cpY + 0.03, cpZ + fOff[2], 0.043, 0.043, 0.014, 12, 8, cpQ);
  m.ellipsoid(cpX + sOff[0], cpY + 0.03, cpZ + sOff[2], 0.012, 0.028, 0.028, 10, 7, cpQ);

  return m.build();
}

// Curved transparent viewport shell rendered over the world in the 3D bridge.
// The bent front, two side panes, and overhead skylight make the glazing feel like a
// continuous, thick Jules Verne dome rather than an empty hole or a flat overlay.
export function buildCockpitGlassMesh() {
  const m = new EntityMesh();
  m.tag(32, 0);

  // Front panoramic bubble: center bows outward into the water, with round shoulders.
  const U = 28, V = 18, front = [];
  for (let j = 0; j <= V; j++) {
    const v = j / V;
    const arch = sin(PI * v);
    const y = -0.49 + v * 1.18 + arch * 0.08;
    const row = [];
    for (let k = 0; k <= U; k++) {
      const u = k / U * 2 - 1;
      const x = u * 1.22 * (0.91 + 0.09 * arch);
      const z = -0.42 - (1 - u * u) * 0.20 - arch * 0.035;
      row.push(m.v(x, y, z, 1, k / U, v));
    }
    front.push(row);
  }
  for (let j = 0; j < V; j++) {
    for (let k = 0; k < U; k++) {
      m.quad(front[j][k], front[j][k + 1], front[j + 1][k + 1], front[j + 1][k]);
    }
  }

  // Curved port and starboard panes catch caustics when the pilot looks sideways.
  for (const side of [-1, 1]) {
    const rows = [];
    for (let j = 0; j <= 12; j++) {
      const v = j / 12, y = -0.15 + v * 0.53;
      const row = [];
      for (let k = 0; k <= 12; k++) {
        const u = k / 12;
        const z = mix(-0.40, 0.16, u);
        const x = side * (0.57 + 0.045 * sin(u * PI));
        row.push(m.v(x, y, z - 0.035 * sin(v * PI), 1, u, v));
      }
      rows.push(row);
    }
    for (let j = 0; j < 12; j++) {
      for (let k = 0; k < 12; k++) {
        if (side < 0) m.quad(rows[j][k], rows[j][k + 1], rows[j + 1][k + 1], rows[j + 1][k]);
        else m.quad(rows[j][k + 1], rows[j][k], rows[j + 1][k], rows[j + 1][k + 1]);
      }
    }
  }

  // Overhead cupola glazing: looking up still reveals the open sea and colossal manta.
  const roof = [];
  for (let j = 0; j <= 12; j++) {
    const v = j / 12;
    const row = [];
    for (let k = 0; k <= 20; k++) {
      const u = k / 20 * 2 - 1;
      const z = mix(-0.48, 0.16, v);
      const x = u * 0.46;
      const y = 0.315 + (1 - u * u) * 0.105 + sin(v * PI) * 0.018;
      row.push(m.v(x, y, z, 1, k / 20, v));
    }
    roof.push(row);
  }
  for (let j = 0; j < 12; j++) {
    for (let k = 0; k < 20; k++) {
      // Reverse the front-panel winding so the skylight normal faces into the cabin.
      m.quad(roof[j][k + 1], roof[j][k], roof[j + 1][k], roof[j + 1][k + 1]);
    }
  }

  return m.build();
}

// Open tapered cone mesh in standard 16-byte vbSolid format for volumetric light beams
export function buildBeamMesh() {
  const m = new Mesh();
  const seg = 24, ringsN = 8, rings = [];
  for (let j = 0; j <= ringsN; j++) {
    const t = j / ringsN;
    const r = [];
    for (let s = 0; s < seg; s++) {
      const a = s / seg * TAU;
      r.push(m.v(cos(a), sin(a), t, 1));
    }
    rings.push(r);
  }
  for (let j = 0; j < ringsN; j++) {
    for (let s = 0; s < seg; s++) {
      const s2 = (s + 1) % seg;
      m.quad(rings[j][s], rings[j][s2], rings[j + 1][s2], rings[j + 1][s]);
    }
  }
  return m.build();
}

// ============================================================================
// Simulation: Tiny Vintage Scuba Diver + 5 Companion Bots + Vintage Submarine
// + 60% Smaller Miniature Mode + Megalophobia / POV / 3D Cockpit Cameras
// + 10x Giant Colossus Manta Rays (with dramatic front submarine flyby!)
// ============================================================================
import {
  sin, cos, sqrt, min, max, abs, floor, PI, atan2, hypot, exp, TAU,
  ernd, err, clamp, mix, sstep, wrapAngle, qAxis, qMul, qRot,
} from './math.js';

export const N_DIVERS = 6;    // 0 = Player, 1..5 = 5 Companion Bots
export const N_BEAMS = 8;     // 0..1 = Submarine Twin Searchlights, 2..7 = 6 Diver Helmet Lamps
export const N_DYNBUB = 480;  // Live rising bubbles from helmets, sub propeller & hatch
export const N_COLOSSUS = 2;  // 2 Giant 10x Manta Rays (alongside all 6 original normal mantas!)

// Normal Manta in Noniv/abyssal-garden is ~3.8 scale (7.6m wingspan).
// 10x Giant Manta = 38.0 scale -> colossal 76.0-meter wingspan!
const GIANT_MANTA_SCALE = 38.0;

// Base Little Nightmares vintage scuba crew (~50 cm standard; ~20 cm in -60% Mungil mode!)
const CREW_SPEC = [
  { name: 'Kamu',     suit: [0.76, 0.51, 0.12], badge: 0.11, scale: 0.52 },
  { name: 'Nemo',     suit: [0.21, 0.36, 0.50], badge: 0.56, scale: 0.51 },
  { name: 'Jules',    suit: [0.60, 0.25, 0.16], badge: 0.03, scale: 0.50 },
  { name: 'Cousteau', suit: [0.31, 0.40, 0.22], badge: 0.01, scale: 0.54 },
  { name: 'Maren',    suit: [0.23, 0.47, 0.41], badge: 0.44, scale: 0.49 },
  { name: 'Pip',      suit: [0.64, 0.55, 0.40], badge: 0.16, scale: 0.45 },
];

// Scenic points of wonder that the 5 companion bots glance & drift toward
const WONDERS = [
  [-5, -36, -4],     // Giant stone whale fluke
  [59.5, -24, 6],    // Sunken wooden ship
  [0, -24, -106],    // Surface-reaching kelp pillar
  [-62, -35, 2],     // Barrel sponge canyon garden
  [8, -32, -88],     // Sunlit kelp basin mound
  [6, -34, 84],      // Glowing purple grotto
  [19, -21, -15],    // Rock window tunnel
  [-23, -10, -16],   // High stone arch
];

// Cozy crew formation offsets [right, forward, up] — gathered tightly right around player & submarine!
const FORM_OFF = [
  [0, 0, 0],
  [-0.92, 1.15, 0.06],
  [0.72, 1.35, 0.14],
  [-1.55, 0.35, 0.22],
  [-0.38, 1.82, 0.18],
  [1.18, 0.62, 0.04],
];

// Camera modes:
// 0 = STANDAR (polished 3rd-person, never clips floor)
// 1 = MEGALOPHOBIA (wide-angle low-upward cinematic lens amplifying colossal scale!)
// 2 = KOKPIT / POV (true 1st-person Mark V helmet POV for diver, full 3D animated bridge cockpit in sub!)
export const CAM_LABELS = ['Standar', 'Megalophobia', 'POV / Kokpit'];

function orientQuat(yaw, pitch, roll = 0) {
  return qMul(qAxis(0, 1, 0, -yaw), qMul(qAxis(1, 0, 0, pitch), qAxis(0, 0, -1, roll)));
}

function diverQuat(yaw, bodyTilt, roll = 0) {
  return qMul(qAxis(0, 1, 0, -yaw), qMul(qAxis(1, 0, 0, -bodyTilt), qAxis(0, 1, 0, roll)));
}

export function createSimulation(sdAt, gradAt, audioHooks, fishInstances = new Float32Array(0)) {
  // Preallocated GPU instance arrays
  const diverData = new Float32Array(N_DIVERS * 24);
  const subData = new Float32Array(16);
  const cockpitData = new Float32Array(20);
  const colossusData = new Float32Array(N_COLOSSUS * 8);
  const beamData = new Float32Array(N_BEAMS * 12);
  const bubData = new Float32Array(N_DYNBUB * 8);
  const bubSim = new Float32Array(N_DYNBUB * 7);
  let bubCursor = 0;
  let fishDirty = false;
  const fishInventory = [0, 0, 0, 0];
  const FISH_NAMES = ['Ikan karang', 'Ikan kupu-kupu', 'Ikan singa', 'Ikan tropis'];
  const harpoon = {
    phase: 'ready', timer: 0, flightTime: 0.24, reelTime: 0, reelDuration: 0.9,
    targetIndex: -1, fishKind: 0, autoReel: false, recoil: 0,
    originX: 0, originY: 0, originZ: 0,
    tipX: 0, tipY: 0, tipZ: 0,
    fishX: 0, fishY: 0, fishZ: 0,
    range: 0, hit: false,
  };
  const fishSample = [0, 0, 0, 0, 0];

  function spawnBub(x, y, z, sz, vy = 1.15, spread = 0.04, vx0 = 0, vz0 = 0, maxAge = 3.6) {
    if (y > -0.6) return;
    const i = bubCursor;
    bubCursor = (bubCursor + 1) % N_DYNBUB;
    const o8 = i * 8, o7 = i * 7;
    const sd = ernd();
    bubData[o8] = x + err(-spread, spread);
    bubData[o8 + 1] = y + err(-spread * 0.5, spread * 0.5);
    bubData[o8 + 2] = z + err(-spread, spread);
    bubData[o8 + 3] = sz * 0.4;
    bubData[o8 + 4] = sd;
    bubData[o8 + 5] = 0.9;
    bubData[o8 + 6] = 0;
    bubData[o8 + 7] = 0;
    bubSim[o7] = vx0 + err(-0.16, 0.16);
    bubSim[o7 + 1] = vy * err(0.82, 1.22);
    bubSim[o7 + 2] = vz0 + err(-0.16, 0.16);
    bubSim[o7 + 3] = 0.001;
    bubSim[o7 + 4] = maxAge * err(0.75, 1.3);
    bubSim[o7 + 5] = sz;
    bubSim[o7 + 6] = sd;
  }

  function burstBubbles(x, y, z, count, szMin = 0.02, szMax = 0.09, spread = 0.25) {
    for (let k = 0; k < count; k++) {
      spawnBub(x, y, z, err(szMin, szMax), err(1.0, 2.1), spread, err(-0.35, 0.35), err(-0.35, 0.35), err(2.2, 4.4));
    }
  }

  function moveSphere(ent, dx, dy, dz, rad) {
    const dist = hypot(dx, dy, dz);
    const steps = floor(dist / max(rad * 0.65, 0.12)) + 1;
    let floorHit = false;
    for (let s = 0; s < steps; s++) {
      ent.x += dx / steps;
      ent.y += dy / steps;
      ent.z += dz / steps;
      const rXZ = hypot(ent.x, ent.z);
      if (rXZ > 150) { ent.x *= 150 / rXZ; ent.z *= 150 / rXZ; }
      ent.y = clamp(ent.y, -52.5, -1.05);
      for (let k = 0; k < 2; k++) {
        const d = sdAt(ent.x, ent.y, ent.z) + rad;
        if (d <= 0) break;
        const g = gradAt(ent.x, ent.y, ent.z);
        if (!g) break;
        ent.x -= g[0] * d;
        ent.y -= g[1] * d;
        ent.z -= g[2] * d;
        if (-g[1] > 0.62) floorHit = true;
        const vn = ent.vx * g[0] + ent.vy * g[1] + ent.vz * g[2];
        if (vn > 0) {
          ent.vx -= g[0] * vn;
          ent.vy -= g[1] * vn;
          ent.vz -= g[2] * vn;
        }
      }
    }
    return floorHit;
  }

  const CLEAR_OFFS = [[0, 0, 0], [0, -0.55, 0], [1.0, 0, 0], [-1.0, 0, 0], [0, 0, 1.0], [0, 0, -1.0]];
  function findClearSpot(x, y, z, clearR) {
    const rXZ = hypot(x, z);
    if (rXZ > 146) { x *= 146 / rXZ; z *= 146 / rXZ; }
    const big = clearR > 0.55;
    const sc = min(clearR, 1.0);
    const rad = min(clearR, 0.86);
    let px = x, py = clamp(y, -50.5, -2.2), pz = z;
    for (let iter = 0; iter < 16; iter++) {
      let worst = 0, wx = px, wy = py, wz = pz;
      if (big) {
        for (const o of CLEAR_OFFS) {
          const ox = px + o[0] * sc, oy = py + o[1] * sc, oz = pz + o[2] * sc;
          const d = sdAt(ox, oy, oz) + rad;
          if (d > worst) { worst = d; wx = ox; wy = oy; wz = oz; }
        }
      } else {
        worst = sdAt(px, py, pz) + rad;
      }
      if (worst <= 0) break;
      const g = gradAt(wx, wy, wz);
      if (g) {
        px -= g[0] * max(worst, 0.18);
        py -= g[1] * max(worst, 0.18);
        pz -= g[2] * max(worst, 0.18);
      } else {
        py += 0.45;
      }
      py = clamp(py, -50.5, -2.2);
    }
    return [px, py, pz];
  }

  // Safety net for bots pushed outside the world, into rock, or too far behind the squad.
  function recoverBot(b, index) {
    const pl = divers[0], sc = state.scaleMul;
    const fScale = mix(sc, 1.0, 0.24);
    const fo = FORM_OFF[index];
    const fx = sin(state.camYaw), fz = -cos(state.camYaw);
    const rx = cos(state.camYaw), rz = sin(state.camYaw);
    const p = findClearSpot(
      pl.x + rx * fo[0] * fScale + fx * (fo[1] + 1.0) * fScale,
      pl.y + (0.40 + fo[2]) * fScale,
      pl.z + rz * fo[0] * fScale + fz * (fo[1] + 1.0) * fScale,
      0.23 * sc
    );
    b.x = p[0]; b.y = p[1]; b.z = p[2];
    b.vx = b.vy = b.vz = 0;
    b.wanderX = b.wanderY = b.wanderZ = 0;
    b.wanderTimer = 1.4 + index * 0.17;
    b.stuckTimer = 0;
    b.lastX = p[0]; b.lastY = p[1]; b.lastZ = p[2];
    b.aboard = false;
    b.swimBlend = 1;
    b.bodyTilt = 0.32;
    b.waveTimer = 0.65;
    burstBubbles(p[0], p[1] + 0.25 * sc, p[2], 5, 0.012, 0.032, 0.08);
  }

  // 6 Vintage Scuba Divers (0 = Player, 1..5 = Friend Bots)
  const divers = CREW_SPEC.map((sp, idx) => ({
    idx,
    name: sp.name,
    suit: sp.suit,
    badge: sp.badge,
    baseScale: sp.scale,
    scale: sp.scale,
    x: 10, y: -42, z: 7,
    vx: 0, vy: 0, vz: 0,
    yaw: -0.8,
    bodyTilt: 0.22,
    roll: 0,
    swimBlend: 1,
    moveAmp: 0,
    phase: idx * 1.17,
    headYaw: 0,
    headPitch: 0.22,
    waveAmt: 0,
    waveTimer: 0,
    bubTimer: ernd() * 0.8,
    aboard: false,
    boardTimer: 0,
    exitDelay: 0,
    stuckTimer: 0,
    lastX: 10, lastY: -42, lastZ: 7,
    wanderX: 0, wanderY: 0, wanderZ: 0,
    wanderTimer: idx * 0.9,
    lookTarget: -1,
  }));

  // Vintage Expedition Submarine + Cockpit Instrument state
  const sub = {
    x: 8, y: -41, z: 5,
    vx: 0, vy: 0, vz: 0,
    yaw: -0.78,
    pitch: 0,
    roll: 0,
    scale: 1.0,
    propAngle: 0,
    propSpeed: 1.4,
    rudder: 0,
    plane: 0,
    wheelAngle: 0,
    throttleLev: 0,
    diveLev: 0,
    pendulum: 0,
    hatchOpen: 0,
    hatchTimer: 0,
    lightsOn: 1,
    lightSmooth: 1,
    bubTimer: 0,
    summonActive: false,
    summonX: 0, summonY: 0, summonZ: 0,
    wakeRock: 0,       // Gentle hull sway when the 76m 10x Giant Manta Ray sweeps past your bow!
    q: [0, 0, 0, 1],
  };

  // 2 Giant 10x Colossus Manta Rays (scale = 38.0 -> 76m wingspan, 10x normal 3.8 manta!)
  // Colossus[0] performs a breathtaking front-of-submarine flyby when you board the submarine,
  // then blends smoothly back into its grand canyon patrol alongside the normal mantas!
  // Colossus[1] majestically circles the sunlit northern kelp basin & shipwreck vista!
  const colossi = [
    {
      x: -14, y: -23, z: -22,
      yaw: 1.45, pitch: -0.03, roll: -0.18,
      scale: GIANT_MANTA_SCALE,
      flap: 0.4,
      // Orbit parameters (central canyon & whale fluke vista — right above normal manta!)
      cx: -4, cy: -18.5, cz: -14, R: 48, spd: 0.042, ph0: 2.35,
      // Dramatic close-front submarine flyby parameters
      flyActive: false,
      flyT: 0,
      flyDur: 22.0,
      sx: 0, sy: 0, sz: 0,
      mx: 0, my: 0, mz: 0,
      ex: 0, ey: 0, ez: 0,
      ancX: 0, ancY: 0, ancZ: 0,
      lastFlybyTime: -999,
      roared: false,
    },
    {
      x: 18, y: -14, z: -68,
      yaw: -1.2, pitch: 0.02, roll: 0.20,
      scale: GIANT_MANTA_SCALE,
      flap: 2.8,
      // Orbit parameters (northern sunlit kelp basin & shipwreck channel)
      cx: 16, cy: -13.5, cz: -56, R: 58, spd: -0.036, ph0: 0.65,
      flyActive: false,
      flyT: 0,
      flyDur: 22,
      sx: 0, sy: 0, sz: 0, mx: 0, my: 0, mz: 0, ex: 0, ey: 0, ez: 0,
      lastFlybyTime: -999,
      roared: false,
    },
  ];

  // Camera, Scale Mode & Gameplay State
  const state = {
    inSub: false,
    miniMode: false,      // true = -60% Smaller Mode (scaleMul = 0.40 for Diver, 5 Bots & Submarine!)
    scaleMul: 1.0,        // Smoothly animated: 1.0 (Standard) <-> 0.40 (Mungil -60%)
    midnightMode: false,  // No sunlight or ambient fill: only helmet & submarine lamps illuminate the abyss!
    viewMode: 0,          // 0 = Standar (3P), 1 = Megalophobia (Wide Low-Angle), 2 = POV / Kokpit 3D
    tanh: 0.68,           // Wider underwater camera baseline; POV and cockpit widen further
    diverZoom: 2.30,      // Clean fixed 3rd-person distance (shows diver + 5 friends + sub + vista!)
    subZoom: 6.80,        // Clean 3rd-person submarine chase distance
    curDist: 2.30,
    pivX: 10, pivY: -41.5, pivZ: 7,
    camX: 10, camY: -41.2, camZ: 7,
    camYaw: -0.8,
    camPitch: 0.08,
    // Cockpit relative head-look offset so you can freely glance around the glass dome, skylight & instruments!
    cockpitYaw: 0,
    cockpitPitch: 0.04,
    nearSub: true,
    subDist: 3.1,
    mantaDist: 45,
    mantaFlyby: false,
    botsAboard: 0,
    firstBoardDone: false,
    toastEvent: '',
    toastSeq: 0,
  };

  function emitToast(msg) {
    state.toastEvent = msg;
    state.toastSeq++;
  }

  const fract = (v) => v - floor(v);
  const fishHash = (v) => fract(sin(v * 127.1) * 43758.5453);

  // Mirrors W_ANIM.vsFish so harpoons target the same procedural school fish seen by the GPU.
  function sampleSchoolFish(index, time, out = fishSample) {
    const o = index * 8;
    if (o + 7 >= fishInstances.length) return false;
    const cx = fishInstances[o], cy = fishInstances[o + 1], cz = fishInstances[o + 2];
    const R = max(abs(fishInstances[o + 3]), 0.1);
    const seed = fishInstances[o + 4], rate = fishInstances[o + 5], size = fishInstances[o + 6], phase = fishInstances[o + 7];
    if (!Number.isFinite(cx + cy + cz + R + seed + rate + size + phase) || abs(cx) > 1000) return false;

    const h0 = fishHash(seed), h1 = fishHash(seed + 0.37), h2 = fishHash(seed + 0.71);
    const ta = time * rate + phase * 6.3 + (h0 - 0.5) * (26 / R);
    const ph = phase * 17;
    let px = cx + R * cos(ta);
    let py = cy + 2.2 * sin(3 * ta + ph);
    let pz = cz + R * 0.6 * sin(ta);

    let tx = -R * sin(ta), ty = 6.6 * cos(3 * ta + ph), tz = R * 0.6 * cos(ta);
    const tl = hypot(tx, ty, tz) || 1;
    const direction = rate < 0 ? -1 : 1;
    tx = tx / tl * direction; ty = ty / tl * direction; tz = tz / tl * direction;
    let sx = tz, sy = 0, sz = -tx;
    const sl = hypot(sx, sy, sz) || 1;
    sx /= sl; sz /= sl;
    const ux = ty * sz - tz * sy, uy = tz * sx - tx * sz, uz = tx * sy - ty * sx;
    const ox = (h1 - 0.5) * 5 + sin(time * 0.6 + seed * 40) * 0.5;
    const oy = (h2 - 0.5) * 3.2 + cos(time * 0.5 + seed * 31) * 0.4;
    px += sx * ox + ux * oy;
    py += uy * oy;
    pz += sz * ox + uz * oy;

    out[0] = px; out[1] = py; out[2] = pz; out[3] = size; out[4] = seed;
    return true;
  }

  function getAimRay() {
    const pitch = state.camPitch, yaw = state.camYaw;
    const cp = cos(pitch);
    return [cp * sin(yaw), sin(pitch), -cp * cos(yaw)];
  }

  function findHarpoonTarget(ox, oy, oz, dx, dy, dz, time) {
    let best = null;
    let bestAlong = Infinity;
    const count = floor(fishInstances.length / 8);
    for (let i = 0; i < count; i++) {
      if (!sampleSchoolFish(i, time, fishSample)) continue;
      const vx = fishSample[0] - ox, vy = fishSample[1] - oy, vz = fishSample[2] - oz;
      const along = vx * dx + vy * dy + vz * dz;
      if (along < 0.8 || along > 32 || along >= bestAlong) continue;
      const px = vx - dx * along, py = vy - dy * along, pz = vz - dz * along;
      const size = fishSample[3];
      const hitRadius = 0.17 + size * 0.68;
      if (px * px + py * py + pz * pz <= hitRadius * hitRadius) {
        const seed = fishSample[4];
        bestAlong = along;
        best = { index: i, along, x: fishSample[0], y: fishSample[1], z: fishSample[2], kind: floor(fishHash(seed * 3.17) * FISH_NAMES.length) };
      }
    }
    return best;
  }

  function muzzlePosition() {
    const pl = divers[0], q = diverQuat(pl.yaw, pl.bodyTilt, pl.roll);
    const o = qRot(q, 0.205 * pl.scale, (0.358 - 0.48) * pl.scale, -0.355 * pl.scale);
    return [pl.x + o[0], pl.y + o[1], pl.z + o[2]];
  }

  function fireHarpoon(time = 0) {
    if (state.inSub || (harpoon.phase !== 'ready' && harpoon.phase !== 'miss')) return false;
    const origin = muzzlePosition();
    const dir = getAimRay();
    const hit = findHarpoonTarget(origin[0], origin[1], origin[2], dir[0], dir[1], dir[2], time);

    harpoon.originX = origin[0]; harpoon.originY = origin[1]; harpoon.originZ = origin[2];
    harpoon.timer = 0;
    harpoon.autoReel = false;
    harpoon.recoil = 1;
    harpoon.hit = !!hit;
    harpoon.targetIndex = hit ? hit.index : -1;
    harpoon.fishKind = hit ? hit.kind : 0;
    harpoon.range = hit ? hit.along : 20;
    harpoon.flightTime = clamp(harpoon.range / 72, 0.11, 0.42);
    harpoon.tipX = hit ? hit.x : origin[0] + dir[0] * harpoon.range;
    harpoon.tipY = hit ? hit.y : origin[1] + dir[1] * harpoon.range;
    harpoon.tipZ = hit ? hit.z : origin[2] + dir[2] * harpoon.range;
    harpoon.fishX = harpoon.tipX; harpoon.fishY = harpoon.tipY; harpoon.fishZ = harpoon.tipZ;
    harpoon.phase = 'flying';
    audioHooks.onHarpoonShot?.(!!hit);
    return true;
  }

  function reelHarpoon() {
    if (harpoon.phase === 'flying' && harpoon.hit) {
      harpoon.autoReel = true;
      audioHooks.onHarpoonReel?.();
      return true;
    }
    if (harpoon.phase !== 'tethered') return false;
    harpoon.phase = 'reeling';
    harpoon.timer = 0;
    harpoon.reelTime = 0;
    harpoon.reelDuration = clamp(harpoon.range / 7.5, 0.48, 2.8);
    const muzzle = muzzlePosition();
    harpoon.originX = muzzle[0]; harpoon.originY = muzzle[1]; harpoon.originZ = muzzle[2];
    audioHooks.onHarpoonReel?.();
    return true;
  }

  function updateHarpoon(dt, time) {
    harpoon.recoil = max(0, harpoon.recoil - dt * 5.5);
    if (harpoon.phase === 'flying') {
      harpoon.timer += dt;
      if (harpoon.targetIndex >= 0 && sampleSchoolFish(harpoon.targetIndex, time, fishSample)) {
        harpoon.fishX = fishSample[0]; harpoon.fishY = fishSample[1]; harpoon.fishZ = fishSample[2];
      }
      const u = sstep(0, 1, harpoon.timer / harpoon.flightTime);
      const endX = harpoon.hit ? harpoon.fishX : harpoon.tipX;
      const endY = harpoon.hit ? harpoon.fishY : harpoon.tipY;
      const endZ = harpoon.hit ? harpoon.fishZ : harpoon.tipZ;
      harpoon.tipX = mix(harpoon.originX, endX, u);
      harpoon.tipY = mix(harpoon.originY, endY, u);
      harpoon.tipZ = mix(harpoon.originZ, endZ, u);
      if (harpoon.timer >= harpoon.flightTime) {
        if (harpoon.hit && harpoon.targetIndex >= 0) {
          const o = harpoon.targetIndex * 8;
          fishInstances[o] = 100000; // Remove only this school fish from the original GPU-rendered school.
          fishInstances[o + 1] = 100000;
          fishInstances[o + 2] = 100000;
          fishDirty = true;
          harpoon.phase = 'tethered';
          harpoon.timer = 0;
          harpoon.range = hypot(harpoon.fishX - harpoon.originX, harpoon.fishY - harpoon.originY, harpoon.fishZ - harpoon.originZ);
          emitToast(`${FISH_NAMES[harpoon.fishKind]} terkena harpun · Klik kanan untuk menarik tali`);
          audioHooks.onHarpoonHit?.();
          if (harpoon.autoReel) reelHarpoon();
        } else {
          harpoon.phase = 'miss';
          harpoon.timer = 0;
          audioHooks.onHarpoonMiss?.();
        }
      }
    } else if (harpoon.phase === 'reeling') {
      harpoon.timer += dt;
      const u = sstep(0, 1, harpoon.timer / harpoon.reelDuration);
      const muzzle = muzzlePosition();
      harpoon.tipX = mix(harpoon.fishX, muzzle[0], u);
      harpoon.tipY = mix(harpoon.fishY, muzzle[1], u);
      harpoon.tipZ = mix(harpoon.fishZ, muzzle[2], u);
      if (harpoon.timer >= harpoon.reelDuration) {
        fishInventory[harpoon.fishKind]++;
        const caught = FISH_NAMES[harpoon.fishKind];
        harpoon.phase = 'ready';
        harpoon.timer = 0;
        harpoon.targetIndex = -1;
        harpoon.hit = false;
        harpoon.autoReel = false;
        emitToast(`${caught} masuk inventori · ${fishInventory.reduce((a, b) => a + b, 0)} ikan`);
        audioHooks.onFishCatch?.();
      }
    } else if (harpoon.phase === 'miss') {
      harpoon.timer += dt;
      if (harpoon.timer > 0.45) {
        harpoon.phase = 'ready';
        harpoon.timer = 0;
      }
    } else if (harpoon.phase === 'tethered') {
      const muzzle = muzzlePosition();
      harpoon.tipX = harpoon.fishX;
      harpoon.tipY = harpoon.fishY;
      harpoon.tipZ = harpoon.fishZ;
      harpoon.originX = muzzle[0]; harpoon.originY = muzzle[1]; harpoon.originZ = muzzle[2];
    }
  }

  function toggleMidnight() {
    state.midnightMode = !state.midnightMode;
    if (state.midnightMode) sub.lightsOn = 1;
    audioHooks.onSwitch?.(state.midnightMode);
    emitToast(state.midnightMode
      ? 'MODE MIDNIGHT · Hanya lampu selam dan lampu sorot'
      : 'Mode Siang · Sinar matahari kembali');
    return state.midnightMode;
  }

  // Project the active spear/tether target into HUD coordinates for the reticle and rope.
  function harpoonScreenPoint() {
    if (harpoon.phase === 'ready') return { visible: false, x: 0.5, y: 0.5 };
    const dx = harpoon.tipX - state.camX, dy = harpoon.tipY - state.camY, dz = harpoon.tipZ - state.camZ;
    const yaw = state.camYaw, pitch = state.camPitch, cp = cos(pitch);
    const fx = cp * sin(yaw), fy = sin(pitch), fz = -cp * cos(yaw);
    const rx = cos(yaw), rz = sin(yaw);
    const ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
    const depth = dx * fx + dy * fy + dz * fz;
    if (depth <= 0.05) return { visible: false, x: 0.5, y: 0.5 };
    const aspect = typeof innerWidth !== 'undefined' && innerHeight > 0 ? innerWidth / innerHeight : 16 / 9;
    const ndcX = (dx * rx + dz * rz) / (depth * max(state.tanh, 0.1) * aspect);
    const ndcY = (dx * ux + dy * uy + dz * uz) / (depth * max(state.tanh, 0.1));
    return { visible: abs(ndcX) <= 1.1 && abs(ndcY) <= 1.1, x: clamp(0.5 + ndcX * 0.5, 0, 1), y: clamp(0.5 - ndcY * 0.5, 0, 1) };
  }

  // Evaluate quadratic Bezier curve & tangent for silky-smooth 10x Giant Manta Ray front flyby!
  function bezPos(c, u) {
    const v = 1 - u;
    return [
      v * v * c.sx + 2 * v * u * c.mx + u * u * c.ex,
      v * v * c.sy + 2 * v * u * c.my + u * u * c.ey,
      v * v * c.sz + 2 * v * u * c.mz + u * u * c.ez,
    ];
  }
  function bezTan(c, u) {
    return [
      2 * (1 - u) * (c.mx - c.sx) + 2 * u * (c.ex - c.mx),
      2 * (1 - u) * (c.my - c.sy) + 2 * u * (c.ey - c.my),
      2 * (1 - u) * (c.mz - c.sz) + 2 * u * (c.ez - c.mz),
    ];
  }

  // Schedule the 10x Giant Manta Ray (76m wingspan!) to glide right across the front of your submarine!
  function triggerGiantMantaFlyby(force = false, curTime = 0) {
    const c = colossi[0];
    if (!force && (c.flyActive || curTime - c.lastFlybyTime < 18)) return;
    const fx = sin(sub.yaw), fz = -cos(sub.yaw); // Submarine forward
    const rx = cos(sub.yaw), rz = sin(sub.yaw); // Submarine right

    // Sunlit clearance height above submarine & canyon structures so its 76m body blazes with god-rays & caustics!
    const passY = clamp(sub.y + 13.5, -27.0, -10.5);
    // Enters immediately from front-starboard (sunlit open canyon), sweeps DEAD-CENTER 31m right in front of your
    // submarine cockpit windshield alongside the normal mantas, then ascends gracefully to port!
    c.ancX = sub.x; c.ancY = sub.y; c.ancZ = sub.z;

    c.sx = sub.x + fx * 39 + rx * 32;
    c.sy = clamp(passY + 1.5, -26.5, -9.5);
    c.sz = sub.z + fz * 39 + rz * 32;

    c.mx = sub.x + fx * 32 - rx * 2;
    c.my = clamp(sub.y + 10.5, -29.5, -11.0);
    c.mz = sub.z + fz * 32 - rz * 2;

    c.ex = sub.x + fx * 40 - rx * 52;
    c.ey = clamp(passY + 6.5, -21.0, -8.5);
    c.ez = sub.z + fz * 40 - rz * 52;

    c.flyActive = true;
    c.flyT = 0;
    c.flyDur = 20.0;
    c.lastFlybyTime = curTime;
    c.roared = false;
    c.x = c.sx; c.y = c.sy; c.z = c.sz;
    const tg = bezTan(c, 0);
    c.yaw = atan2(tg[0], -tg[2]);
    c.pitch = atan2(tg[1], max(hypot(tg[0], tg[2]), 0.1));
    c.roll = 0.22; // Graceful bank tilting its colossal 76m wingspan toward your submarine cockpit!
    emitToast('Manta Ray Raksasa (10x) Melintas di Hadapan Kapal Selam!');
  }

  // Update both 10x Giant Colossus Manta Rays
  function stepColossi(dt, time) {
    for (let i = 0; i < N_COLOSSUS; i++) {
      const c = colossi[i];
      // Slow, majestic, ponderous mega-wingbeat (much slower & heavier than normal mantas!)
      c.flap = (c.flap + 0.62 * dt) % (TAU * 100);

      if (c.flyActive) {
        c.flyT += dt;
        const u = clamp(c.flyT / c.flyDur, 0, 1);
        // Smooth gentle ease so it lingers majestically right in front of your submarine nose!
        const eu = mix(u, u * u * (3 - 2 * u), 0.28);
        const p = bezPos(c, eu);
        const tg = bezTan(c, eu);
        // Smoothly pace submarine motion during crossing so even while cruising forward it sweeps right across your bow!
        const pace = state.inSub ? 0.65 * (1 - sstep(0.65, 1.0, u)) : 0;
        const px = clamp(p[0] + (sub.x - c.ancX) * pace, -145, 145);
        const py = clamp(p[1] + (sub.y - c.ancY) * pace * 0.4 + sin(c.flap) * 0.45, -34, -7.5);
        const pz = clamp(p[2] + (sub.z - c.ancZ) * pace, -145, 145);
        c.x = px;
        c.y = py;
        c.z = pz;
        const tyaw = atan2(tg[0], -tg[2]);
        const tpit = clamp(atan2(tg[1], max(hypot(tg[0], tg[2]), 0.1)), -0.35, 0.35);
        c.yaw += wrapAngle(tyaw - c.yaw) * (1 - exp(-dt * 4));
        c.pitch = mix(c.pitch, tpit, 1 - exp(-dt * 4));
        // Bank gracefully toward the submarine so both its dorsal chevrons and giant ventral gills catch the sunbeams!
        c.roll = mix(c.roll, 0.22 * sin(u * PI), 1 - exp(-dt * 3));

        // Deep resonant leviathan call + gentle hydro-wake rock as its 76m body crosses dead-center!
        if (!c.roared && c.flyT > 1.6) {
          c.roared = true;
          audioHooks.onLeviathan?.();
        }
        if (state.inSub && u > 0.18 && u < 0.72) {
          sub.wakeRock = sin((u - 0.18) / 0.54 * TAU * 1.5) * 0.055 * sin((u - 0.18) / 0.54 * PI);
        } else if (i === 0) {
          sub.wakeRock *= exp(-dt * 3);
        }

        if (c.flyT >= c.flyDur) {
          c.flyActive = false;
          // Seamlessly re-phase patrol orbit from current heading/angle so it never teleports!
          c.ph0 = atan2((c.z - c.cz) / 0.78, c.x - c.cx) - time * c.spd;
        }
      } else {
        // Grand panoramic ocean patrol (slow, peaceful, visible across the entire world!)
        const ta = time * c.spd + c.ph0;
        const gx = c.cx + c.R * cos(ta);
        const gy = c.cy + 2.8 * sin(2 * ta + i * 1.7);
        const gz = c.cz + c.R * 0.78 * sin(ta);
        const vx = -c.R * sin(ta) * c.spd;
        const vy = 5.6 * cos(2 * ta + i * 1.7) * c.spd;
        const vz = c.R * 0.78 * cos(ta) * c.spd;
        const sm = dt >= 0.9 ? 1 : 1 - exp(-dt * 1.4);
        c.x = mix(c.x, gx, sm);
        c.y = mix(c.y, gy, sm);
        c.z = mix(c.z, gz, sm);
        const tyaw = atan2(vx, -vz);
        c.yaw += wrapAngle(tyaw - c.yaw) * (dt >= 0.9 ? 1 : 1 - exp(-dt * 2.2));
        c.pitch = mix(c.pitch, atan2(vy, max(hypot(vx, vz), 1e-4)), sm);
        c.roll = mix(c.roll, -0.20 * Math.sign(c.spd), sm);
        if (i === 0) sub.wakeRock *= exp(-dt * 3);
      }

      const o = i * 8;
      colossusData[o] = c.x;
      colossusData[o + 1] = c.y;
      colossusData[o + 2] = c.z;
      colossusData[o + 3] = c.scale;
      colossusData[o + 4] = c.yaw;
      colossusData[o + 5] = c.pitch;
      colossusData[o + 6] = c.roll;
      colossusData[o + 7] = c.flap;
    }

    const ax = state.inSub ? sub.x : divers[0].x;
    const ay = state.inSub ? sub.y : divers[0].y;
    const az = state.inSub ? sub.z : divers[0].z;
    const d0 = hypot(colossi[0].x - ax, colossi[0].y - ay, colossi[0].z - az);
    const d1 = hypot(colossi[1].x - ax, colossi[1].y - ay, colossi[1].z - az);
    state.mantaDist = min(d0, d1);
    state.mantaFlyby = colossi[0].flyActive;
  }

  // Sync scales of all 6 divers & the submarine for Normal (1.0) vs Mungil -60% (0.40) mode
  function applyScale(mul) {
    state.scaleMul = mul;
    sub.scale = mul;
    for (const d of divers) d.scale = d.baseScale * mul;
  }

  // Place player, 5 friend bots, and vintage submarine cleanly at any of the 6 iconic viewpoints!
  function placeAtPose(pose, keepInSub = state.inSub) {
    const sc = state.miniMode ? 0.40 : 1.0;
    applyScale(sc);

    const [px, py, pz, tx, ty, tz] = pose;
    const dx = tx - px, dy = ty - py, dz = tz - pz;
    const yaw = atan2(dx, -dz);
    // Clean, level-to-slightly-upward opening angle so third-person camera NEVER hits the floor or blocks the view!
    const rawPitch = atan2(dy, hypot(dx, dz));
    state.camYaw = yaw;
    state.camPitch = clamp(rawPitch * 0.24, -0.12, 0.11);
    state.cockpitYaw = 0;
    state.cockpitPitch = 0.05;

    const fx = sin(yaw), fz = -cos(yaw);
    const rx = cos(yaw), rz = sin(yaw);
    const sCam = mix(sc, 1.0, 0.35);

    if (keepInSub) {
      const sp = findClearSpot(px + fx * 1.8, py + 1.25 * sc + 0.35, pz + fz * 1.8, 1.2 * sc);
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
      sub.vx = sub.vy = sub.vz = 0;
      sub.yaw = yaw; sub.pitch = 0.04; sub.roll = 0;
      sub.summonActive = false;
      for (const d of divers) {
        d.x = sub.x; d.y = sub.y; d.z = sub.z;
        d.vx = d.vy = d.vz = 0;
        d.aboard = true;
      }
      state.pivX = sub.x; state.pivY = sub.y + 0.55 * sc; state.pivZ = sub.z;
      state.curDist = state.viewMode === 2 ? 0 : (state.viewMode === 1 ? 9.2 : state.subZoom) * sCam;
    } else {
      // Place tiny vintage scuba player cleanly in foreground facing the iconic vista
      const pp = findClearSpot(px + fx * 1.5, py - 0.55 + 0.25 * sc, pz + fz * 1.5, 0.26 * sc);
      const pl = divers[0];
      pl.x = pp[0]; pl.y = pp[1]; pl.z = pp[2];
      pl.vx = pl.vy = pl.vz = 0;
      pl.yaw = yaw; pl.bodyTilt = 0.18; pl.roll = 0;
      pl.swimBlend = 0.65;
      pl.headYaw = 0; pl.headPitch = 0.18;
      pl.aboard = false;

      // Place all 5 vintage-scuba friend bots right beside you in a cozy explorer squad!
      const fScale = mix(sc, 1.0, 0.22);
      for (let i = 1; i < N_DIVERS; i++) {
        const fo = FORM_OFF[i];
        const bp = findClearSpot(
          pl.x + rx * fo[0] * fScale + fx * fo[1] * fScale,
          pl.y + fo[2] * fScale + 0.08,
          pl.z + rz * fo[0] * fScale + fz * fo[1] * fScale,
          0.25 * sc
        );
        const b = divers[i];
        b.x = bp[0]; b.y = bp[1]; b.z = bp[2];
        b.vx = b.vy = b.vz = 0;
        b.yaw = yaw + err(-0.32, 0.32);
        b.bodyTilt = 0.24; b.roll = 0;
        b.aboard = false; b.exitDelay = 0;
        b.stuckTimer = 0; b.lastX = b.x; b.lastY = b.y; b.lastZ = b.z;
        b.waveTimer = 1.6 + i * 0.25;
      }

      // Park the Vintage Submarine RIGHT NEXT TO THE CREW (~3.1m in Standard, ~1.7m in -60% Mungil mode!)
      // Framed cleanly on the right-front side of the squad, facing the open canyon ahead, instantly boardable with [F]!
      const parkR = 2.15 * mix(sc, 1.0, 0.25);
      const parkF = 2.25 * mix(sc, 1.0, 0.25);
      const sp = findClearSpot(
        pl.x + rx * parkR + fx * parkF,
        pl.y + 0.92 * sc + 0.18,
        pl.z + rz * parkR + fz * parkF,
        1.15 * sc
      );
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
      sub.vx = sub.vy = sub.vz = 0;
      // Aim submarine straight toward the landmark vista (slightly angled inward so its glowing glass nose greets the crew!)
      sub.yaw = yaw - 0.18;
      sub.pitch = 0.02; sub.roll = 0;
      sub.summonActive = false;

      state.pivX = pl.x; state.pivY = pl.y + 0.34 * sCam; state.pivZ = pl.z;
      state.curDist = state.viewMode === 2 ? 0 : (state.viewMode === 1 ? 3.55 : state.diverZoom) * sCam;
    }

    const pl0 = divers[0];
    const boardRange = 5.8 * mix(sc, 1.0, 0.45);
    state.subDist = keepInSub ? 0 : hypot(pl0.x - sub.x, pl0.y - sub.y, pl0.z - sub.z);
    state.nearSub = !keepInSub && state.subDist <= boardRange;

    stepColossi(1.0, 0);
    updateCamera(1.0, 0);
    packBuffers(0);
  }

  // Board / Disembark Submarine (Key F)
  function toggleSubmarine(curTime = 0) {
    const pl = divers[0];
    const sc = state.scaleMul;
    const boardRange = 6.2 * mix(sc, 1.0, 0.45);

    if (!state.inSub) {
      const dist = hypot(pl.x - sub.x, pl.y - sub.y, pl.z - sub.z);
      if (dist > boardRange) return false;
      state.inSub = true;
      sub.summonActive = false;
      sub.hatchTimer = 2.2;
      pl.aboard = true;
      pl.vx = pl.vy = pl.vz = 0;
      for (let i = 1; i < N_DIVERS; i++) divers[i].boardTimer = 0;

      // Align camera cleanly with submarine's forward vista & tilt slightly upward to greet the 10x Giant Manta Ray!
      state.camYaw = sub.yaw;
      state.camPitch = 0.10;
      state.cockpitYaw = 0;
      state.cockpitPitch = 0.12;

      // On very first boarding, automatically give a clean, dramatic view & trigger the 10x Giant Manta Ray front flyby!
      const firstTime = !state.firstBoardDone;
      state.firstBoardDone = true;
      triggerGiantMantaFlyby(firstTime, curTime);

      burstBubbles(sub.x, sub.y + 1.22 * sc, sub.z, 26, 0.025 * sc, 0.11 * sc, 0.32 * sc);
      audioHooks.onHatch?.(true);
      return true;
    } else {
      // Disembark smoothly right beside the submarine along with all 5 vintage-scuba friend bots!
      state.inSub = false;
      sub.hatchTimer = 2.2;
      sub.vx *= 0.22; sub.vy *= 0.22; sub.vz *= 0.22;
      state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw);
      state.camPitch = clamp(state.camPitch, -0.35, 0.25);
      state.cockpitYaw = 0;

      const rx = cos(sub.yaw), rz = sin(sub.yaw);
      const fx = sin(sub.yaw), fz = -cos(sub.yaw);
      const ep = findClearSpot(
        sub.x - rx * (1.35 * sc + 0.25) + fx * 0.25 * sc,
        sub.y + 0.65 * sc,
        sub.z - rz * (1.35 * sc + 0.25) + fz * 0.25 * sc,
        0.26 * sc
      );
      pl.x = ep[0]; pl.y = ep[1]; pl.z = ep[2];
      pl.vx = -rx * 0.9; pl.vy = 0.45; pl.vz = -rz * 0.9;
      pl.yaw = state.camYaw;
      pl.bodyTilt = 0.45;
      pl.swimBlend = 1;
      pl.aboard = false;
      for (let i = 1; i < N_DIVERS; i++) {
        if (divers[i].aboard) divers[i].exitDelay = 0.13 * i;
      }
      burstBubbles(sub.x, sub.y + 1.24 * sc, sub.z, 28, 0.025 * sc, 0.12 * sc, 0.35 * sc);
      audioHooks.onHatch?.(false);
      return true;
    }
  }

  // Toggle 60% Smaller Miniature Mode (1.0 <-> 0.40 scale for Player, 5 Bots, and Submarine!)
  function toggleMiniMode(forceVal) {
    state.miniMode = typeof forceVal === 'boolean' ? forceVal : !state.miniMode;
    const pl = divers[0];
    const cx = state.inSub ? sub.x : pl.x;
    const cy = state.inSub ? sub.y : pl.y;
    const cz = state.inSub ? sub.z : pl.z;
    burstBubbles(cx, cy + 0.3, cz, 22, 0.02, 0.08, 0.45);
    // If shrinking while outside, nudge parked submarine closer to crew so it stays cozy beside them!
    if (!state.inSub && state.subDist < 8) {
      const targetS = state.miniMode ? 0.40 : 1.0;
      const dx = sub.x - pl.x, dz = sub.z - pl.z;
      const d = hypot(dx, dz) || 1;
      const wantD = state.miniMode ? 2.1 : 3.2;
      const sp = findClearSpot(pl.x + (dx / d) * wantD, pl.y + 0.92 * targetS + 0.15, pl.z + (dz / d) * wantD, 1.1 * targetS);
      sub.x = sp[0]; sub.y = sp[1]; sub.z = sp[2];
    }
    audioHooks.onSwitch?.(state.miniMode);
    emitToast(state.miniMode ? 'Mode Mungil -60% Aktif (Penyelam & Kapal Selam Mini!)' : 'Ukuran Standar Little Nightmares');
  }

  // Set or Cycle Camera Mode: 0 = Standar, 1 = Megalophobia, 2 = POV / Kokpit 3D
  function setViewMode(mode) {
    const next = ((mode % 3) + 3) % 3;
    // Sync cockpit head-look seamlessly when entering/leaving Cockpit mode
    if (next === 2 && state.inSub) {
      state.cockpitYaw = clamp(wrapAngle(state.camYaw - sub.yaw), -1.1, 1.1);
      state.cockpitPitch = clamp(state.camPitch - sub.pitch, -0.6, 0.75);
    } else if (state.viewMode === 2 && next !== 2 && state.inSub) {
      state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw);
      state.camPitch = clamp(sub.pitch + state.cockpitPitch * 0.5, -0.8, 0.8);
      state.cockpitYaw = 0;
    }
    state.viewMode = next;
    audioHooks.onSwitch?.(true);
    const label = next === 0
      ? 'Kamera: Standar (3rd Person)'
      : next === 1
        ? 'Kamera: Megalophobia (Wide Low-Angle)'
        : state.inSub
          ? 'Kamera: Kokpit Kapal Selam 3D'
          : 'Kamera: POV Helm Scuba Klasik';
    emitToast(label);
  }

  function cycleView() {
    setViewMode(state.viewMode + 1);
  }

  // Quick toggle specifically for Cockpit / POV mode (Key K)
  function toggleCockpit() {
    setViewMode(state.viewMode === 2 ? 0 : 2);
  }

  // Quick toggle specifically for Megalophobia camera mode (Key B)
  function toggleMegalophobia() {
    setViewMode(state.viewMode === 1 ? 0 : 1);
  }

  function toggleLights() {
    sub.lightsOn = sub.lightsOn ? 0 : 1;
    audioHooks.onSwitch?.(!!sub.lightsOn);
    emitToast(sub.lightsOn ? 'Lampu Sorot Nyala' : 'Lampu Sorot Mati');
  }

  function zoom(deltaY) {
    const k = exp(clamp(deltaY, -180, 180) * 0.0012);
    if (state.inSub) state.subZoom = clamp(state.subZoom * k, 3.8, 16.5);
    else state.diverZoom = clamp(state.diverZoom * k, 1.05, 5.8);
    if (state.viewMode === 2 && deltaY > 0) setViewMode(0);
  }

  function callFriends() {
    if (state.inSub) {
      // Inside submarine, calling triggers the 10x Manta sonar greeting if cooldown passed!
      triggerGiantMantaFlyby(true, 0);
      audioHooks.onSonar?.();
      return;
    }
    const pl = divers[0];
    pl.waveTimer = 1.7;
    burstBubbles(pl.x, pl.y + 0.4 * state.scaleMul, pl.z, 10, 0.012, 0.04, 0.08);
    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i];
      b.wanderX = b.wanderY = b.wanderZ = 0;
      b.wanderTimer = 4.2;
      b.waveTimer = 2.2 + i * 0.18;
      b.lookTarget = 0;
      burstBubbles(b.x, b.y + 0.38 * state.scaleMul, b.z, 7, 0.012, 0.036, 0.07);
    }
    audioHooks.onBell?.();
    emitToast('5 Teman Penyelam Mendekat & Melambai');
  }

  function summonSubmarine() {
    if (state.inSub) return;
    const pl = divers[0];
    const sc = state.scaleMul;
    const pScale = mix(sc, 1.0, 0.25);
    const fx = sin(state.camYaw), fz = -cos(state.camYaw);
    const rx = cos(state.camYaw), rz = sin(state.camYaw);
    const goal = findClearSpot(pl.x + fx * 2.5 * pScale + rx * 2.0 * pScale, pl.y + 0.95 * sc + 0.2, pl.z + fz * 2.5 * pScale + rz * 2.0 * pScale, 1.15 * sc);
    sub.summonX = goal[0]; sub.summonY = goal[1]; sub.summonZ = goal[2];
    const d = hypot(sub.x - goal[0], sub.y - goal[1], sub.z - goal[2]);
    if (d > 34) {
      const start = findClearSpot(goal[0] + fx * 16, clamp(goal[1] + 4.5, -44, -4), goal[2] + fz * 16, 1.2 * sc);
      sub.x = start[0]; sub.y = start[1]; sub.z = start[2];
      sub.yaw = atan2(goal[0] - sub.x, -(goal[2] - sub.z));
    }
    sub.summonActive = true;
    audioHooks.onSonar?.();
    emitToast('Kapal Selam Mendekat ke Kru…');
  }

  // Scaled multi-point submarine hull collision
  const SUB_PROBES = [
    [0, 0, -1.75, 0.72],
    [0, 0, 0.0, 0.85],
    [0, 0, 1.55, 0.62],
    [0, 0.78, -0.18, 0.48],
    [0, -0.35, -0.4, 0.62],
  ];
  function moveSubmarine(dt) {
    const sc = sub.scale;
    const dx = sub.vx * dt, dy = sub.vy * dt, dz = sub.vz * dt;
    const steps = floor(hypot(dx, dy, dz) / max(0.32 * sc, 0.18)) + 1;
    const q = orientQuat(sub.yaw, sub.pitch, sub.roll);
    for (let s = 0; s < steps; s++) {
      sub.x += dx / steps;
      sub.y += dy / steps;
      sub.z += dz / steps;
      const rXZ = hypot(sub.x, sub.z);
      if (rXZ > 149) { sub.x *= 149 / rXZ; sub.z *= 149 / rXZ; }
      sub.y = clamp(sub.y, -52.0, -1.2 - 0.85 * sc);
      for (const pr of SUB_PROBES) {
        const off = qRot(q, pr[0] * sc, pr[1] * sc, pr[2] * sc);
        const wx = sub.x + off[0], wy = sub.y + off[1], wz = sub.z + off[2];
        const d = sdAt(wx, wy, wz) + pr[3] * sc;
        if (d > 0) {
          const g = gradAt(wx, wy, wz);
          if (!g) continue;
          sub.x -= g[0] * d;
          sub.y -= g[1] * d;
          sub.z -= g[2] * d;
          const vn = sub.vx * g[0] + sub.vy * g[1] + sub.vz * g[2];
          if (vn > 0) {
            sub.vx -= g[0] * vn;
            sub.vy -= g[1] * vn;
            sub.vz -= g[2] * vn;
          }
        }
      }
    }
  }

  // Polished Camera System:
  //   0 = Standar (clean 3rd-person, glides smoothly over seafloor — NEVER jams into diver's back!)
  //   1 = Megalophobia (wide-angle TANH=0.86, dramatic low-angle upward framing showing tiny player vs titanic abyss!)
  //   2 = POV / Kokpit 3D (true 1st-person copper helmet POV or 3D animated Jules Verne submarine cockpit!)
  function updateCamera(dt, time = 0) {
    const pl = divers[0];
    const sc = state.scaleMul;
    const sCam = mix(sc, 1.0, 0.30);
    const instant = dt >= 0.9;

    // Smoothly interpolate FOV (TANH) per camera mode!
    const wantTanh = state.viewMode === 1
      ? (state.miniMode ? 1.0 : 0.96)             // Ultra-wide Megalophobia cathedral lens!
      : state.viewMode === 2
        ? (state.inSub ? 0.94 : 0.86)             // Wide panoramic cockpit / round Mark V helmet porthole
        : (state.miniMode ? 0.72 : 0.68);          // Wider underwater exploration FOV
    state.tanh = instant ? wantTanh : mix(state.tanh, wantTanh, 1 - exp(-dt * 6.5));

    // --- MODE 2: FIRST-PERSON POV (DIVER HELMET) & 3D SUBMARINE COCKPIT ---
    if (state.viewMode === 2) {
      state.curDist = 0;
      if (state.inSub) {
        // Seated at the captain's station right inside the forward brass panoramic cockpit dome!
        const totRoll = sub.roll + sub.wakeRock;
        const q = orientQuat(sub.yaw, sub.pitch, totRoll);
        const cabinSway = sin(time * 0.43) * 0.004 + sub.wakeRock * 0.18;
        const cabinBob = sin(time * 0.68) * 0.003 + cos(time * 0.37) * 0.002;
        const eye = qRot(q, cabinSway * sc, 0.14 * sc + cabinBob * sc, -1.72 * sc);
        state.camX = sub.x + eye[0];
        state.camY = clamp(sub.y + eye[1], -52.2, -0.72);
        state.camZ = sub.z + eye[2];
        // Combine submarine heading + smooth pilot head free-look (can look left, right, down at wheel/sonar, up through skylight!)
        state.camYaw = wrapAngle(sub.yaw + state.cockpitYaw + sin(time * 0.31) * 0.0025);
        state.camPitch = clamp(sub.pitch + state.cockpitPitch + cos(time * 0.39) * 0.002, -1.25, 1.38);
        state.pivX = state.camX; state.pivY = state.camY; state.pivZ = state.camZ;
      } else {
        // Put the eye at the center of the round Mark V porthole, not down in the diver's chest.
        const dq = diverQuat(pl.yaw, pl.bodyTilt, pl.roll);
        const breathY = sin(time * 1.25) * 0.0035 * sc;
        const headDrift = sin(time * 0.37) * 0.0025 * sc;
        // Diver root is centered at the chest with a -0.48 local pivot, so .305 places the camera at helmet height.
        const eye = qRot(dq, headDrift, 0.305 * pl.scale + breathY, -0.155 * pl.scale);
        state.camX = pl.x + eye[0];
        state.camY = clamp(pl.y + eye[1], -52.2, -0.68);
        state.camZ = pl.z + eye[2];
        state.pivX = pl.x; state.pivY = pl.y + 0.25 * sc; state.pivZ = pl.z;
      }
      return;
    }

    // --- MODE 0 (STANDAR) & MODE 1 (MEGALOPHOBIA) ---
    const isMega = state.viewMode === 1;
    let tx, ty, tz, wantD, liftY;

    if (state.inSub) {
      tx = sub.x;
      // Megalophobia frames the tiny submarine low against towering 40m kelp, sunken ship & 76m Giant Manta Ray!
      ty = sub.y + (isMega ? 1.35 : 0.62) * sCam;
      tz = sub.z;
      wantD = (isMega ? state.subZoom * 1.38 : state.subZoom) * sCam;
      liftY = (isMega ? -0.45 : 0.48) * sCam;
    } else {
      // Frame the tiny vintage diver in the lower-third so the vast abyss & 5 friends shine above without occlusion!
      tx = pl.x;
      ty = pl.y + (isMega ? 0.92 : 0.42) * sCam;
      tz = pl.z;
      wantD = (isMega ? state.diverZoom * 1.58 : state.diverZoom) * sCam;
      liftY = (isMega ? -0.26 : 0.22) * sCam;
    }

    // Subtle deep-sea current sway in Megalophobia mode for living cinematic scale
    if (isMega && !instant) {
      tx += sin(time * 0.45) * 0.08 * sCam;
      ty += cos(time * 0.37) * 0.06 * sCam;
    }

    const sm = instant ? 1 : 1 - exp(-dt * (isMega ? 7.5 : 11.5));
    state.pivX = mix(state.pivX, tx, sm);
    state.pivY = mix(state.pivY, ty, sm);
    state.pivZ = mix(state.pivZ, tz, sm);
    state.curDist = instant ? wantD : mix(state.curDist, wantD, 1 - exp(-dt * 6.5));

    const effPitch = isMega ? clamp(state.camPitch + 0.09, -1.25, 1.42) : state.camPitch;
    const cp = cos(effPitch), sp = sin(effPitch);
    const fx = cp * sin(state.camYaw), fy = sp, fz = -cp * cos(state.camYaw);

    // Smart collision-free third-person positioning:
    // March backward; if the seafloor pushes from below when looking UP, glide camera smoothly ABOVE the floor
    // instead of slamming close into the diver's scuba tanks!
    const maxD = state.curDist;
    const minD = (state.inSub ? 2.5 : 0.72) * sCam;
    let cx = state.pivX - fx * maxD;
    let cy = state.pivY - fy * maxD + liftY;
    let cz = state.pivZ - fz * maxD;

    const steps = 10;
    for (let s = 1; s <= steps; s++) {
      const d = maxD * (s / steps);
      if (d < minD) continue;
      let tx2 = state.pivX - fx * d;
      let ty2 = clamp(state.pivY - fy * d + liftY * (d / max(maxD, 0.1)), -52.2, -0.72);
      let tz2 = state.pivZ - fz * d;
      const pen = sdAt(tx2, ty2, tz2) + 0.32;
      if (pen > 0) {
        const g = gradAt(tx2, ty2, tz2);
        // If hitting horizontal seafloor from above, smoothly skim just above the sand!
        if (g && -g[1] > 0.58) {
          ty2 += pen + 0.04;
          if (sdAt(tx2, ty2, tz2) + 0.24 <= 0) {
            cx = tx2; cy = ty2; cz = tz2;
            continue;
          }
        }
        // Otherwise hitting a vertical rock wall/arch: stop cleanly right in front of the wall!
        const safeD = max(minD, maxD * ((s - 1) / steps));
        cx = state.pivX - fx * safeD;
        cy = clamp(state.pivY - fy * safeD + liftY * (safeD / max(maxD, 0.1)), -52.2, -0.72);
        cz = state.pivZ - fz * safeD;
        break;
      }
      cx = tx2; cy = ty2; cz = tz2;
    }

    // Final gentle rock pushout so camera lens never clips a grain of sand
    const finPen = sdAt(cx, cy, cz) + 0.28;
    if (finPen > 0) {
      const g = gradAt(cx, cy, cz);
      if (g) { cx -= g[0] * finPen; cy -= g[1] * finPen; cz -= g[2] * finPen; }
    }

    state.camX = cx;
    state.camY = clamp(cy, -52.2, -0.72);
    state.camZ = cz;
    const rXZ = hypot(state.camX, state.camZ);
    if (rXZ > 151) { state.camX *= 151 / rXZ; state.camZ *= 151 / rXZ; }
  }

  // Pack all GPU buffers (Submarine, 3D Cockpit, 6 Vintage Divers, Beams)
  function packBuffers(time) {
    const sc = state.scaleMul;
    const inCockpit = state.inSub && state.viewMode === 2;
    const totRoll = sub.roll + sub.wakeRock;
    const sq = orientQuat(sub.yaw, sub.pitch, totRoll);
    sub.q = sq;

    let crewMask = 0, botsIn = 0;
    if (divers[0].aboard) crewMask |= 1;
    for (let i = 1; i < N_DIVERS; i++) {
      if (divers[i].aboard) {
        crewMask |= (1 << i);
        botsIn++;
      }
    }
    state.botsAboard = botsIn;
    const crewTotal = botsIn + (divers[0].aboard ? 1 : 0);

    // 1. Pack Exterior Submarine (hidden when inside 3D Cockpit so exterior bubble glass never double-draws!)
    subData[0] = sub.x; subData[1] = sub.y; subData[2] = sub.z;
    subData[3] = inCockpit ? 0.0 : sub.scale;
    subData[4] = sq[0]; subData[5] = sq[1]; subData[6] = sq[2]; subData[7] = sq[3];
    subData[8] = sub.propAngle; subData[9] = sub.rudder; subData[10] = sub.plane; subData[11] = sub.hatchOpen;
    subData[12] = sub.lightSmooth; subData[13] = crewMask; subData[14] = crewTotal; subData[15] = time;

    // 2. Pack Full 3D Vintage Submarine Cockpit Interior (rendered at 1:1 pilot scale around camX,camY,camZ!)
    if (inCockpit) {
      // Compute nearest 10x Giant Manta Ray relative position on the submarine's live CRT Sonar!
      const c0 = colossi[0], c1 = colossi[1];
      const d0 = hypot(c0.x - sub.x, c0.z - sub.z), d1 = hypot(c1.x - sub.x, c1.z - sub.z);
      const mc = d0 <= d1 ? c0 : c1;
      const mdx = mc.x - sub.x, mdz = mc.z - sub.z;
      const fx = sin(sub.yaw), fz = -cos(sub.yaw), rx = cos(sub.yaw), rz = sin(sub.yaw);
      const sonarRange = 95.0;
      let sx = (mdx * rx + mdz * rz) / sonarRange;
      let sy = (mdx * fx + mdz * fz) / sonarRange;
      const sl = hypot(sx, sy);
      if (sl > 0.86) { sx *= 0.86 / sl; sy *= 0.86 / sl; }

      const subSpd = hypot(sub.vx, sub.vy, sub.vz);
      cockpitData[0] = state.camX; cockpitData[1] = state.camY; cockpitData[2] = state.camZ;
      cockpitData[3] = 0.55; // Keeps cockpit well outside NEAR=0.05 and cleanly inside rock walls!
      cockpitData[4] = sq[0]; cockpitData[5] = sq[1]; cockpitData[6] = sq[2]; cockpitData[7] = sq[3];
      cockpitData[8] = sub.wheelAngle;
      cockpitData[9] = sub.throttleLev;
      cockpitData[10] = sub.diveLev;
      cockpitData[11] = sub.pendulum;
      cockpitData[12] = clamp(-sub.y / 54.0, 0, 1);         // Live Depth needle (0..54m)
      cockpitData[13] = clamp(subSpd / 24.0, 0, 1);         // Live Speed/Knot needle
      cockpitData[14] = sub.yaw;                            // Live Gimbaled Compass heading
      cockpitData[15] = sub.lightSmooth;                    // Searchlight jewel status
      cockpitData[16] = crewTotal;                          // 1..6 glowing crew filament bulbs
      cockpitData[17] = sx;                                 // 10x Manta Sonar X
      cockpitData[18] = sy;                                 // 10x Manta Sonar Y
      cockpitData[19] = botsIn > 0 ? 1 : 0;                 // Copper-helmeted co-pilot friend on right seat!
    } else {
      cockpitData[3] = 0.0;
    }

    // 3. Pack Submarine Twin Volumetric Searchlight Beams (scaled cleanly with miniMode!)
    const beamQ = orientQuat(sub.yaw, sub.pitch - 0.04, totRoll);
    for (let s = 0; s < 2; s++) {
      const sx = (s === 0 ? -0.56 : 0.56) * sc;
      const lp = qRot(sq, sx, -0.34 * sc, -2.02 * sc);
      const o = s * 12;
      beamData[o] = sub.x + lp[0];
      beamData[o + 1] = sub.y + lp[1];
      beamData[o + 2] = sub.z + lp[2];
      beamData[o + 3] = (state.inSub ? 30.0 : 16.0) * mix(sc, 1.0, 0.55);
      beamData[o + 4] = beamQ[0]; beamData[o + 5] = beamQ[1]; beamData[o + 6] = beamQ[2]; beamData[o + 7] = beamQ[3];
      beamData[o + 8] = 0.11 * sc;
      beamData[o + 9] = (state.inSub ? 4.6 : 2.6) * mix(sc, 1.0, 0.5);
      beamData[o + 10] = sub.lightSmooth * (inCockpit ? 0.65 : state.inSub ? 1.05 : 0.72);
      beamData[o + 11] = 0.0;
    }

    // 4. Pack 6 Vintage Scuba Divers + 6 Miniature Helmet Headlamp Beams
    for (let i = 0; i < N_DIVERS; i++) {
      const d = divers[i];
      const o = i * 24;
      const dq = diverQuat(d.yaw, d.bodyTilt, d.roll);
      const pivOff = qRot(dq, 0, -0.48 * d.scale, 0);
      const povHelmet = !state.inSub && state.viewMode === 2;
      // Keep close companion models from filling the frame when looking through your own helmet porthole.
      const closeBuddy = povHelmet && i > 0 && hypot(d.x - state.camX, d.y - state.camY, d.z - state.camZ) < 1.55 * sc;
      const vis = (!d.aboard && !(i === 0 && state.viewMode === 2) && !closeBuddy) ? 1 : 0;

      diverData[o] = d.x + pivOff[0];
      diverData[o + 1] = d.y + pivOff[1];
      diverData[o + 2] = d.z + pivOff[2];
      diverData[o + 3] = d.scale;
      diverData[o + 4] = dq[0]; diverData[o + 5] = dq[1]; diverData[o + 6] = dq[2]; diverData[o + 7] = dq[3];
      diverData[o + 8] = d.suit[0]; diverData[o + 9] = d.suit[1]; diverData[o + 10] = d.suit[2]; diverData[o + 11] = d.phase;
      diverData[o + 12] = d.swimBlend; diverData[o + 13] = d.moveAmp; diverData[o + 14] = d.headYaw; diverData[o + 15] = d.headPitch;
      diverData[o + 16] = d.waveAmt; diverData[o + 17] = d.badge; diverData[o + 18] = sub.lightSmooth; diverData[o + 19] = vis;
      diverData[o + 20] = i === 0 ? harpoon.recoil : 0;
      diverData[o + 21] = harpoon.phase === 'reeling' && i === 0 ? 1 : 0;
      diverData[o + 22] = 0; diverData[o + 23] = 0;

      const bo = (2 + i) * 12;
      if (!d.aboard && sub.lightSmooth > 0.02 && !(i === 0 && state.viewMode === 2)) {
        const hq = qMul(dq, qMul(qAxis(0, 1, 0, d.headYaw), qAxis(1, 0, 0, d.headPitch)));
        const lampPos = qRot(dq, 0, 0.94 * d.scale, -0.08 * d.scale);
        beamData[bo] = diverData[o] + lampPos[0];
        beamData[bo + 1] = diverData[o + 1] + lampPos[1];
        beamData[bo + 2] = diverData[o + 2] + lampPos[2];
        beamData[bo + 3] = (i === 0 ? 3.2 : 2.3) * mix(sc, 1.0, 0.4);
        beamData[bo + 4] = hq[0]; beamData[bo + 5] = hq[1]; beamData[bo + 6] = hq[2]; beamData[bo + 7] = hq[3];
        beamData[bo + 8] = 0.024 * d.scale;
        beamData[bo + 9] = (i === 0 ? 0.62 : 0.44) * mix(sc, 1.0, 0.4);
        beamData[bo + 10] = sub.lightSmooth * (i === 0 ? 0.62 : 0.42);
        beamData[bo + 11] = 0.35;
      } else {
        beamData[bo + 10] = 0;
      }
    }
  }

  // Main per-frame simulation step
  function step(dt, time, inp, isMenu) {
    // Smoothly animate scale multiplier between Standard (1.0) and Mungil -60% (0.40)!
    const wantScale = state.miniMode ? 0.40 : 1.0;
    if (abs(state.scaleMul - wantScale) > 0.0005) {
      applyScale(mix(state.scaleMul, wantScale, 1 - exp(-dt * 8.5)));
    }
    const sc = state.scaleMul;
    const inCockpit = state.inSub && state.viewMode === 2;

    // Update look angles
    if (inCockpit) {
      // Free pilot head-look around the panoramic 3D cockpit windows, ceiling skylight & brass instruments!
      state.cockpitYaw = clamp(state.cockpitYaw + inp.dyaw, -1.48, 1.48);
      state.cockpitPitch = clamp(state.cockpitPitch - inp.dpitch, -0.92, 1.28);
    } else {
      state.camYaw += inp.dyaw;
      state.camPitch = clamp(state.camPitch - inp.dpitch, -1.35, 1.42);
    }

    // Smooth light & airlock hatch animations
    sub.lightSmooth = mix(sub.lightSmooth, sub.lightsOn, 1 - exp(-dt * 9));
    if (sub.hatchTimer > 0) sub.hatchTimer = max(0, sub.hatchTimer - dt);
    sub.hatchOpen = mix(sub.hatchOpen, sub.hatchTimer > 0.2 ? 1 : 0, 1 - exp(-dt * 7));

    // ========================================================================
    // A. UPDATE 10x GIANT COLOSSUS MANTA RAYS (with dramatic front flyby!)
    // ========================================================================
    stepColossi(dt, time);

    // ========================================================================
    // B. SUBMARINE PHYSICS, PILOTING & LIVE COCKPIT CONTROLS
    // ========================================================================
    if (state.inSub && !isMenu) {
      const fast = (inp.boost ? 24.0 : 10.2) * mix(sc, 1.0, 0.72);
      const damp = 1 - exp(-dt * 3.2);
      const mf = inp.mf, mr = inp.mr, mu = inp.mu;
      let turnRate = 0;

      if (inCockpit) {
        // In 3D Cockpit Mode:
        // - A/D turns the spoked brass helm wheel & steers rudder directly!
        // - When thrusting forward (W), submarine also steers smoothly toward where you're looking,
        //   while gently recentering head-look — and when coasting/hovering, mouse lets you freely admire
        //   the 10x Giant Manta Ray through the front, side & ceiling windows without spinning the sub!
        turnRate = mr * 1.25;
        if (abs(mf) > 0.05 && abs(state.cockpitYaw) > 0.03) {
          const pull = clamp(state.cockpitYaw * 1.45, -1.3, 1.3);
          turnRate += pull;
          state.cockpitYaw -= pull * dt * 0.85;
        }
        sub.yaw += turnRate * dt;

        if (abs(mf) > 0.05 && abs(state.cockpitPitch) > 0.02) {
          const pPull = clamp(state.cockpitPitch * 1.15, -0.9, 0.9);
          sub.pitch = clamp(sub.pitch + pPull * dt, -0.75, 0.75);
          state.cockpitPitch -= pPull * dt * 0.9;
        }
        if (abs(mu) > 0.02) {
          sub.pitch = clamp(sub.pitch + mu * 0.72 * dt, -0.75, 0.75);
        } else if (abs(mf) < 0.05) {
          sub.pitch = mix(sub.pitch, 0, 1 - exp(-dt * 1.8));
        }
        const pDiff = state.cockpitPitch * 0.5 + mu * 0.35;

        sub.rudder = mix(sub.rudder, clamp(-turnRate * 0.42, -0.58, 0.58), 1 - exp(-dt * 7));
        sub.roll = mix(sub.roll, clamp(-turnRate * 0.16, -0.30, 0.30), 1 - exp(-dt * 4.5));
        sub.plane = mix(sub.plane, clamp(pDiff * 1.6 + mu * 0.38, -0.52, 0.52), 1 - exp(-dt * 7));
      } else {
        // 3rd-Person & Megalophobia Submarine Piloting
        if (mf > 0.05) {
          const diff = wrapAngle(state.camYaw - sub.yaw);
          turnRate = clamp(diff * 2.4 + mr * 0.85, -2.2, 2.2);
          sub.yaw += diff * (1 - exp(-dt * 3.4)) + mr * 0.65 * dt;
          sub.rudder = mix(sub.rudder, clamp(-diff * 0.9 - mr * 0.4, -0.58, 0.58), 1 - exp(-dt * 7));
          sub.roll = mix(sub.roll, clamp(-diff * 0.30 - mr * 0.14, -0.34, 0.34), 1 - exp(-dt * 4.5));
        } else {
          turnRate = mr * 1.15;
          sub.yaw += turnRate * dt;
          if (abs(mr) > 0.05) state.camYaw += mr * 0.85 * dt;
          sub.rudder = mix(sub.rudder, clamp(-mr * 0.52, -0.55, 0.55), 1 - exp(-dt * 7));
          sub.roll = mix(sub.roll, clamp(-mr * 0.14, -0.24, 0.24), 1 - exp(-dt * 4));
        }
        const wantPitch = mf > 0.05
          ? clamp(state.camPitch * 0.88 + mu * 0.28, -0.80, 0.80)
          : clamp(mu * 0.24, -0.45, 0.45);
        const pDiff = wantPitch - sub.pitch;
        sub.pitch += pDiff * (1 - exp(-dt * 3.2));
        sub.plane = mix(sub.plane, clamp(pDiff * 1.6 + mu * 0.35, -0.5, 0.5), 1 - exp(-dt * 7));
      }

      // Animate 3D cockpit brass wheel, Chadburn engine telegraph, ballast dive lever & lantern pendulum!
      const wantWheel = clamp(-turnRate * 1.35, -2.4, 2.4);
      sub.wheelAngle = mix(sub.wheelAngle, wantWheel, 1 - exp(-dt * 6.5));
      const wantThr = mf * (inp.boost ? 0.68 : 0.40);
      sub.throttleLev = mix(sub.throttleLev, wantThr, 1 - exp(-dt * 8.0));
      sub.diveLev = mix(sub.diveLev, clamp(mu * 0.52 + sub.pitch * 0.35, -0.62, 0.62), 1 - exp(-dt * 8.0));
      sub.pendulum = mix(sub.pendulum, clamp(-(sub.roll + sub.wakeRock) * 1.3, -0.35, 0.35), 1 - exp(-dt * 5.0));

      const cp = cos(sub.pitch), sp = sin(sub.pitch);
      const fx = cp * sin(sub.yaw), fy = sp, fz = -cp * cos(sub.yaw);
      const rx = cos(sub.yaw), rz = sin(sub.yaw);

      const thrust = mf >= 0 ? mf * fast : mf * fast * 0.55;
      const tvx = fx * thrust + (inCockpit ? 0 : rx * mr * fast * 0.22);
      const tvy = fy * thrust + mu * fast * 0.65;
      const tvz = fz * thrust + (inCockpit ? 0 : rz * mr * fast * 0.22);

      sub.vx += (tvx - sub.vx) * damp;
      sub.vy += (tvy - sub.vy) * damp;
      sub.vz += (tvz - sub.vz) * damp;
      moveSubmarine(dt);

      divers[0].x = sub.x; divers[0].y = sub.y; divers[0].z = sub.z;
      divers[0].vx = sub.vx; divers[0].vy = sub.vy; divers[0].vz = sub.vz;

      const fwdSpd = sub.vx * fx + sub.vy * fy + sub.vz * fz;
      const wantProp = abs(mf) > 0.05 ? (mf > 0 ? 1 : -1) * (8 + abs(fwdSpd) * 1.4) : 1.6;
      sub.propSpeed = mix(sub.propSpeed, wantProp, 1 - exp(-dt * 5));
      sub.propAngle = (sub.propAngle + sub.propSpeed * dt) % TAU;

      const bubRate = 0.14 / (1 + abs(fwdSpd) * 0.55 + abs(mu) * 1.8);
      sub.bubTimer -= dt;
      while (sub.bubTimer <= 0) {
        sub.bubTimer += bubRate;
        const propW = qRot(orientQuat(sub.yaw, sub.pitch, sub.roll), 0, -0.04 * sc, 2.28 * sc);
        spawnBub(
          sub.x + propW[0], sub.y + propW[1], sub.z + propW[2],
          err(0.022, 0.088) * mix(sc, 1.0, 0.35) * (inp.boost ? 1.25 : 1),
          err(0.7, 1.5), 0.20 * sc,
          -fx * (0.6 + abs(fwdSpd) * 0.22),
          -fz * (0.6 + abs(fwdSpd) * 0.22),
          err(1.8, 3.6)
        );
      }
      audioHooks.setSubThrottle?.(clamp(hypot(sub.vx, sub.vy, sub.vz) / 14 + abs(mf) * 0.35, 0, 1.3), true);
    } else {
      // Submarine parked gently next to crew OR gliding in when summoned with R
      if (sub.summonActive) {
        const dx = sub.summonX - sub.x, dy = sub.summonY - sub.y, dz = sub.summonZ - sub.z;
        const d = hypot(dx, dy, dz);
        if (d < 0.9) {
          sub.summonActive = false;
        } else {
          const tyaw = atan2(dx, -dz);
          sub.yaw += wrapAngle(tyaw - sub.yaw) * (1 - exp(-dt * 3.2));
          const sp = min(13.5, 2.4 + d * 0.95);
          sub.vx = mix(sub.vx, (dx / d) * sp, 1 - exp(-dt * 3.8));
          sub.vy = mix(sub.vy, (dy / d) * sp, 1 - exp(-dt * 3.8));
          sub.vz = mix(sub.vz, (dz / d) * sp, 1 - exp(-dt * 3.8));
          sub.pitch = mix(sub.pitch, clamp((dy / d) * 0.42, -0.4, 0.4), 1 - exp(-dt * 3));
          sub.propSpeed = mix(sub.propSpeed, 14, 1 - exp(-dt * 5));
          sub.bubTimer -= dt;
          if (sub.bubTimer <= 0) {
            sub.bubTimer = 0.045;
            const propW = qRot(orientQuat(sub.yaw, sub.pitch, sub.roll), 0, -0.04 * sc, 2.28 * sc);
            spawnBub(sub.x + propW[0], sub.y + propW[1], sub.z + propW[2], err(0.025, 0.08) * sc, 1.1, 0.18 * sc);
          }
        }
      } else {
        const damp = 1 - exp(-dt * 2.5);
        sub.vx *= (1 - damp);
        sub.vy = mix(sub.vy, sin(time * 0.85) * 0.06 * sc, damp);
        sub.vz *= (1 - damp);
        sub.pitch = mix(sub.pitch, sin(time * 0.55) * 0.02, damp);
        sub.roll = mix(sub.roll, cos(time * 0.47) * 0.025, damp);
        sub.rudder = mix(sub.rudder, 0, damp);
        sub.plane = mix(sub.plane, 0, damp);
        sub.wheelAngle = mix(sub.wheelAngle, 0, damp);
        sub.throttleLev = mix(sub.throttleLev, 0, damp);
        sub.diveLev = mix(sub.diveLev, 0, damp);
        sub.propSpeed = mix(sub.propSpeed, 1.15, damp);
        sub.bubTimer -= dt;
        if (sub.bubTimer <= 0) {
          sub.bubTimer = err(0.4, 0.95);
          spawnBub(sub.x, sub.y + 0.85 * sc, sub.z, err(0.018, 0.05) * mix(sc, 1.0, 0.4), 1.1, 0.2 * sc);
        }
      }
      sub.propAngle = (sub.propAngle + sub.propSpeed * dt) % TAU;
      moveSubmarine(dt);
      audioHooks.setSubThrottle?.(sub.summonActive ? 0.35 : 0, false);
    }

    // ========================================================================
    // C. TINY VINTAGE SCUBA PLAYER DIVER PHYSICS & ANIMATION
    // ========================================================================
    const pl = divers[0];
    const pRad = 0.25 * sc;
    if (!state.inSub) {
      if (!isMenu) {
        // Scuba propulsion accelerates gently, coasts on momentum, and needs fins/Shift for a stronger pace.
        const sp = (inp.boost ? 6.2 : 2.65) * mix(sc, 1.0, 0.72);
        const k = 1 - exp(-dt * 1.8);
        const cp = cos(state.camPitch), sy = sin(state.camYaw), cw = cos(state.camYaw);
        let tvx = (sy * cp * inp.mf + cw * inp.mr) * sp;
        let tvy = (sin(state.camPitch) * inp.mf + inp.mu) * sp * 0.76;
        let tvz = (-cw * cp * inp.mf + sy * inp.mr) * sp;

        const probeD = 0.34 * sc + 0.02;
        const floorD = sdAt(pl.x, pl.y - probeD, pl.z);
        const headD = sdAt(pl.x, pl.y + 0.16 * sc + 0.05, pl.z);
        const nearFloor = floorD > -0.10 && (floorD - headD) > 0.14 && tvy <= 0.42 && inp.mu <= 0;
        const walkMax = 1.7 * mix(sc, 1.0, 0.55);

        if (nearFloor && (abs(inp.mf) > 0.05 || abs(inp.mr) > 0.05) && !inp.boost && state.camPitch < 0.25) {
          tvx = (sy * inp.mf + cw * inp.mr) * walkMax;
          tvz = (-cw * inp.mf + sy * inp.mr) * walkMax;
          tvy = -1.15;
        } else {
          // A very gentle deep-water current keeps a neutral diver buoyant instead of frozen in place.
          tvx += sin(time * 0.31 + pl.y * 0.08) * 0.035;
          tvy += sin(time * 0.57 + pl.phase * 0.22) * 0.025;
          tvz += cos(time * 0.27 + pl.x * 0.07) * 0.032;
        }

        pl.vx += (tvx - pl.vx) * k;
        pl.vy += (tvy - pl.vy) * k;
        pl.vz += (tvz - pl.vz) * k;

        // Soft glide around parked submarine hull
        const hullR = 1.35 * sc;
        const sdx = pl.x - sub.x, sdy = pl.y + 0.15 * sc - sub.y, sdz = pl.z - sub.z;
        const sd = hypot(sdx, sdy, sdz);
        if (sd < hullR && sd > 0.01) {
          const push = (hullR - sd) * 6 * dt;
          pl.x += (sdx / sd) * push; pl.y += (sdy / sd) * push; pl.z += (sdz / sd) * push;
        }

        const onFloor = moveSphere(pl, pl.vx * dt, pl.vy * dt, pl.vz * dt, pRad);
        const fBelow = sdAt(pl.x, pl.y - probeD, pl.z);
        const groundClose = (onFloor || (fBelow > -0.09 && fBelow - sdAt(pl.x, pl.y + 0.16 * sc + 0.05, pl.z) > 0.14)) && pl.vy < 0.35 && inp.mu <= 0 && !inp.boost;

        const hSpd = hypot(pl.vx, pl.vz);
        const totSpd = hypot(hSpd, pl.vy);

        if (state.viewMode === 2) {
          // In First-Person POV mode, diver body smoothly aligns with look yaw!
          pl.yaw += wrapAngle(state.camYaw - pl.yaw) * (1 - exp(-dt * 12));
          pl.roll = mix(pl.roll, 0, 1 - exp(-dt * 6));
        } else if (hSpd > 0.18) {
          const moveYaw = atan2(pl.vx, -pl.vz);
          const yDiff = wrapAngle(moveYaw - pl.yaw);
          pl.yaw += yDiff * (1 - exp(-dt * 8.5));
          pl.roll = mix(pl.roll, clamp(-yDiff * 0.35, -0.35, 0.35) * pl.swimBlend, 1 - exp(-dt * 6));
        } else {
          pl.roll = mix(pl.roll, 0, 1 - exp(-dt * 5));
        }

        pl.swimBlend = mix(pl.swimBlend, groundClose ? 0 : 1, 1 - exp(-dt * 6.5));
        const swimPitch = totSpd > 0.28 ? atan2(pl.vy, max(hSpd, 0.2)) : 0;
        const walkTilt = clamp(hSpd / walkMax, 0, 1) * 0.17;
        const swimTilt = mix(0.24, clamp(1.26 - swimPitch * 0.92, 0.05, 2.65), sstep(0.15, 3.0, totSpd));
        pl.bodyTilt = mix(pl.bodyTilt, state.viewMode === 2 ? 0.12 : mix(walkTilt, swimTilt, pl.swimBlend), 1 - exp(-dt * 6.5));

        // Tiny 60%-smaller boots patter briskly like Six/Mono in Little Nightmares!
        const strideMul = 1 / mix(sc, 1.0, 0.45);
        pl.moveAmp = mix(pl.moveAmp, clamp(totSpd / (groundClose ? walkMax : 5.8), 0, 1.25), 1 - exp(-dt * 8));
        const rate = groundClose ? (0.85 + hSpd * 1.55 * strideMul) : (1.25 + totSpd * 0.78 * sqrt(strideMul));
        pl.phase = (pl.phase + rate * dt) % TAU;

        const relYaw = clamp(wrapAngle(state.camYaw - pl.yaw), -0.68, 0.68);
        const wantHPit = mix(clamp(state.camPitch * 0.55, -0.45, 0.55), clamp(pl.bodyTilt * 0.72 + state.camPitch * 0.25, -0.3, 1.05), pl.swimBlend);
        pl.headYaw = mix(pl.headYaw, -relYaw * 0.65, 1 - exp(-dt * 7));
        pl.headPitch = mix(pl.headPitch, wantHPit, 1 - exp(-dt * 7));
      } else {
        pl.phase = (pl.phase + 2.4 * dt) % TAU;
        pl.moveAmp = 0.14;
        pl.swimBlend = 0.85;
        pl.bodyTilt = 0.22 + sin(time * 0.9) * 0.04;
        pl.headYaw = sin(time * 0.55) * 0.24;
        pl.headPitch = 0.20;
      }

      if (pl.waveTimer > 0) pl.waveTimer = max(0, pl.waveTimer - dt);
      pl.waveAmt = mix(pl.waveAmt, pl.waveTimer > 0 ? 1 : 0, 1 - exp(-dt * 9));

      // Helmet scuba regulator exhaust bubbles (in POV mode, drift softly past side of porthole!)
      pl.bubTimer -= dt;
      if (pl.bubTimer <= 0) {
        pl.bubTimer = err(0.20, 0.54) / (1 + clamp(pl.moveAmp, 0, 1) * 1.35);
        const dq = diverQuat(pl.yaw, pl.bodyTilt, pl.roll);
        const valve = state.viewMode === 2
          ? qRot(orientQuat(state.camYaw, 0, 0), err(-0.22, 0.22), -0.06, -0.36)
          : qRot(dq, 0.08 * pl.scale, 0.42 * pl.scale, 0.06 * pl.scale);
        const bSz = err(0.011, 0.034) * mix(sc, 1.0, 0.45);
        spawnBub(pl.x + valve[0], pl.y + valve[1], pl.z + valve[2], bSz, err(0.85, 1.45), 0.025 * sc, pl.vx * 0.12, pl.vz * 0.12, err(2.4, 4.6));
      }
    }

    const boardRange = 6.2 * mix(sc, 1.0, 0.45);
    state.subDist = state.inSub ? 0 : hypot(pl.x - sub.x, pl.y - sub.y, pl.z - sub.z);
    state.nearSub = !state.inSub && state.subDist <= boardRange;

    // ========================================================================
    // D. 5 COMPANION FRIEND BOTS (Peaceful Squad Exploration + Sub Crew!)
    // ========================================================================
    const pFx = sin(state.camYaw), pFz = -cos(state.camYaw);
    const pRx = cos(state.camYaw), pRz = sin(state.camYaw);
    const hatchX = sub.x, hatchY = sub.y + 1.18 * sc, hatchZ = sub.z;
    const fScale = mix(sc, 1.0, 0.24);
    const bRad = 0.23 * sc;

    for (let i = 1; i < N_DIVERS; i++) {
      const b = divers[i];

      if (state.inSub) {
        if (b.aboard) {
          b.x = sub.x; b.y = sub.y; b.z = sub.z;
          continue;
        }
        b.boardTimer += dt;
        const dx = hatchX - b.x, dy = hatchY - b.y, dz = hatchZ - b.z;
        const d = hypot(dx, dy, dz);
        if (d < 1.65 * sc + 0.35 || d > 28 || b.boardTimer > 0.65 + i * 0.20) {
          b.aboard = true;
          sub.hatchTimer = max(sub.hatchTimer, 0.65);
          burstBubbles(hatchX, hatchY + 0.08 * sc, hatchZ, 8, 0.018 * sc, 0.065 * sc, 0.20 * sc);
          continue;
        }
        const subSpd = hypot(sub.vx, sub.vy, sub.vz);
        const sp = max(8.5, d * 2.4) + subSpd;
        const k = 1 - exp(-dt * 8.0);
        b.vx += (sub.vx * 0.6 + (dx / d) * sp - b.vx) * k;
        b.vy += (sub.vy * 0.6 + (dy / d) * sp - b.vy) * k;
        b.vz += (sub.vz * 0.6 + (dz / d) * sp - b.vz) * k;
        moveSphere(b, b.vx * dt, b.vy * dt, b.vz * dt, bRad);
        b.yaw += wrapAngle(atan2(b.vx, -b.vz) - b.yaw) * (1 - exp(-dt * 8));
        b.swimBlend = mix(b.swimBlend, 1, 1 - exp(-dt * 8));
        b.bodyTilt = mix(b.bodyTilt, 1.2, 1 - exp(-dt * 7));
        b.moveAmp = 1.0;
        b.phase = (b.phase + 9.5 * dt) % TAU;
        b.headYaw = 0; b.headPitch = 0.85;
        continue;
      }

      if (b.aboard) {
        b.exitDelay -= dt;
        if (b.exitDelay <= 0) {
          b.aboard = false;
          const an = (i / 5) * TAU + sub.yaw;
          const ep = findClearSpot(hatchX + cos(an) * 0.85 * sc, hatchY + 0.22 * sc, hatchZ + sin(an) * 0.85 * sc, bRad);
          b.x = ep[0]; b.y = ep[1]; b.z = ep[2];
          b.vx = cos(an) * 1.9; b.vy = 1.2; b.vz = sin(an) * 1.9;
          b.yaw = atan2(b.vx, -b.vz);
          b.swimBlend = 1; b.bodyTilt = 0.7;
          b.waveTimer = 1.2;
          burstBubbles(b.x, b.y + 0.18 * sc, b.z, 7, 0.018 * sc, 0.055 * sc, 0.14 * sc);
        } else {
          continue;
        }
      }

      const botDistNow = hypot(pl.x - b.x, pl.y - b.y, pl.z - b.z);
      if (!Number.isFinite(b.x + b.y + b.z) || hypot(b.x, b.z) > 153 || b.y < -53 || b.y > -0.5 || sdAt(b.x, b.y, b.z) > 0.15 || botDistNow > 24) {
        recoverBot(b, i);
      }

      b.wanderTimer -= dt;
      if (b.wanderTimer <= 0) {
        b.wanderTimer = err(3.2, 7.5);
        b.wanderX = err(-1.8, 1.8) * fScale;
        b.wanderY = err(-0.6, 1.2) * fScale;
        b.wanderZ = err(-1.8, 1.8) * fScale;
        for (const w of WONDERS) {
          const wd = hypot(pl.x - w[0], pl.z - w[2]);
          if (wd < 26 && wd > 4 && ernd() < 0.45) {
            b.wanderX += ((w[0] - pl.x) / wd) * 1.4 * fScale;
            b.wanderZ += ((w[2] - pl.z) / wd) * 1.4 * fScale;
            break;
          }
        }
        const r = ernd();
        b.lookTarget = r < 0.30 ? 0 : r < 0.50 ? (1 + ((ernd() * 5) | 0)) : r < 0.80 ? 10 : -1;
        if (ernd() < 0.15 && hypot(b.x - pl.x, b.z - pl.z) < 3.6 * fScale) b.waveTimer = err(1.2, 2.0);
      }

      const fo = FORM_OFF[i];
      const bobY = sin(time * (0.65 + i * 0.11) + i * 2.1) * 0.20 * fScale;
      let gx = pl.x + pRx * fo[0] * fScale + pFx * fo[1] * fScale + b.wanderX + pl.vx * 0.20;
      let gy = clamp(pl.y + fo[2] * fScale + b.wanderY * 0.55 + bobY + pl.vy * 0.16, -51.5, -1.5);
      let gz = pl.z + pRz * fo[0] * fScale + pFz * fo[1] * fScale + b.wanderZ + pl.vz * 0.20;

      const wantWalkWithPlayer = pl.swimBlend < 0.35 && (i === 1 || i === 2 || i === 5);
      if (wantWalkWithPlayer) gy = pl.y - 0.12 * sc;

      const dx = gx - b.x, dy = gy - b.y, dz = gz - b.z;
      const dist = hypot(dx, dy, dz);
      const pDist = hypot(pl.x - b.x, pl.y - b.y, pl.z - b.z);

      if (pDist > 22) {
        recoverBot(b, i);
        continue;
      }

      const pSpd = hypot(pl.vx, pl.vy, pl.vz);
      const maxSpd = max(3.0, pSpd * 1.16 + (pDist > 7 ? (pDist - 7) * 0.55 : 0));
      const desSpd = dist < 0.28 * fScale ? 0 : min(maxSpd, dist * 1.05);
      let tvx = dist > 0.04 ? (dx / dist) * desSpd : 0;
      let tvy = dist > 0.04 ? (dy / dist) * desSpd : 0;
      let tvz = dist > 0.04 ? (dz / dist) * desSpd : 0;

      // Soft separation between tiny vintage scuba friends
      for (let j = 0; j < N_DIVERS; j++) {
        if (j === i || divers[j].aboard) continue;
        const ox = b.x - divers[j].x, oy = b.y - divers[j].y, oz = b.z - divers[j].z;
        const od = hypot(ox, oy, oz);
        const minSep = (j === 0 ? 0.88 : 0.72) * fScale;
        if (od < minSep && od > 0.001) {
          const push = ((minSep - od) / minSep) * 3.0;
          tvx += (ox / od) * push;
          tvy += (oy / od) * push * 0.6;
          tvz += (oz / od) * push;
        }
      }

      // Keep clear of parked submarine hull
      const keepSubR = 2.15 * sc;
      const sx = b.x - sub.x, sy = b.y - sub.y, sz = b.z - sub.z;
      const sd = hypot(sx, sy, sz);
      if (sd < keepSubR && sd > 0.01) {
        const push = ((keepSubR - sd) / keepSubR) * 4.8;
        tvx += (sx / sd) * push;
        tvy += (sy / sd) * push;
        tvz += (sz / sd) * push;
      }

      if (wantWalkWithPlayer && dist < 3.2 * fScale) tvy = min(tvy, -0.9);

      const sm = 1 - exp(-dt * 3.6);
      b.vx += (tvx - b.vx) * sm;
      b.vy += (tvy - b.vy) * sm;
      b.vz += (tvz - b.vz) * sm;

      const hitFloor = moveSphere(b, b.vx * dt, b.vy * dt, b.vz * dt, bRad);
      const botOnFloor = (hitFloor || sdAt(b.x, b.y - (0.32 * sc + 0.02), b.z) > -0.09) && b.vy < 0.28 && pSpd < 4.2;

      const actualStep = hypot(b.x - b.lastX, b.y - b.lastY, b.z - b.lastZ);
      if (dist > 0.8 * fScale && actualStep < 0.006) b.stuckTimer += dt;
      else b.stuckTimer = max(0, b.stuckTimer - dt * 2);
      b.lastX = b.x; b.lastY = b.y; b.lastZ = b.z;
      if (b.stuckTimer > 3.0) {
        recoverBot(b, i);
        continue;
      }

      const hSpd = hypot(b.vx, b.vz);
      const totSpd = hypot(hSpd, b.vy);
      if (hSpd > 0.15) {
        const my = atan2(b.vx, -b.vz);
        const yd = wrapAngle(my - b.yaw);
        b.yaw += yd * (1 - exp(-dt * 6.0));
        b.roll = mix(b.roll, clamp(-yd * 0.35, -0.35, 0.35) * b.swimBlend, 1 - exp(-dt * 5));
      } else {
        const faceYaw = b.lookTarget === 0 ? atan2(pl.x - b.x, -(pl.z - b.z)) : state.camYaw;
        b.yaw += wrapAngle(faceYaw - b.yaw) * (1 - exp(-dt * 2.0));
        b.roll = mix(b.roll, sin(time * 0.8 + i) * 0.05, 1 - exp(-dt * 4));
      }

      const strideMul = 1 / mix(sc, 1.0, 0.45);
      b.swimBlend = mix(b.swimBlend, botOnFloor ? 0 : 1, 1 - exp(-dt * 5.5));
      const sPitch = totSpd > 0.22 ? atan2(b.vy, max(hSpd, 0.2)) : 0;
      const wTilt = clamp(hSpd / 2.8, 0, 1) * 0.15;
      const sTilt = mix(0.26, clamp(1.24 - sPitch * 0.9, 0.08, 2.55), sstep(0.15, 2.8, totSpd));
      b.bodyTilt = mix(b.bodyTilt, mix(wTilt, sTilt, b.swimBlend), 1 - exp(-dt * 5.5));
      b.moveAmp = mix(b.moveAmp, clamp(totSpd / (botOnFloor ? 2.6 : 5.4), 0, 1.2), 1 - exp(-dt * 7));
      b.phase = (b.phase + (botOnFloor ? (1.1 + hSpd * 3.0 * strideMul) : (2.4 + totSpd * 1.2 * sqrt(strideMul))) * dt) % TAU;

      let wantHY = 0, wantHP = mix(0.05, b.bodyTilt * 0.72, b.swimBlend);
      if (b.lookTarget >= 0 && b.lookTarget < N_DIVERS && b.lookTarget !== i) {
        const tgt = divers[b.lookTarget];
        const ly = atan2(tgt.x - b.x, -(tgt.z - b.z));
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62) * 0.75;
      } else if (b.lookTarget === 10) {
        // Point copper helmet up in awe at the 10x Giant Manta Ray gliding overhead!
        const ly = atan2(colossi[0].x - b.x, -(colossi[0].z - b.z));
        wantHY = -clamp(wrapAngle(ly - b.yaw), -0.62, 0.62) * 0.65;
        wantHP += 0.36;
      }
      b.headYaw = mix(b.headYaw, wantHY, 1 - exp(-dt * 4.5));
      b.headPitch = mix(b.headPitch, clamp(wantHP, -0.35, 1.1), 1 - exp(-dt * 4.5));

      if (b.waveTimer > 0) b.waveTimer = max(0, b.waveTimer - dt);
      b.waveAmt = mix(b.waveAmt, b.waveTimer > 0 ? 1 : 0, 1 - exp(-dt * 8));

      b.bubTimer -= dt;
      if (b.bubTimer <= 0) {
        b.bubTimer = err(0.30, 0.75) / (1 + clamp(b.moveAmp, 0, 1));
        const dq = diverQuat(b.yaw, b.bodyTilt, b.roll);
        const valve = qRot(dq, 0.08 * b.scale, 0.42 * b.scale, 0.06 * b.scale);
        spawnBub(b.x + valve[0], b.y + valve[1], b.z + valve[2], err(0.010, 0.030) * mix(sc, 1.0, 0.45), err(0.85, 1.4), 0.025 * sc, b.vx * 0.1, b.vz * 0.1, err(2.0, 4.2));
      }
    }

    // ========================================================================
    // E. UPDATE LIVE RISING BUBBLES
    // ========================================================================
    updateHarpoon(dt, time);

    const drag = exp(-dt * 2.8);
    for (let i = 0; i < N_DYNBUB; i++) {
      const o7 = i * 7;
      let age = bubSim[o7 + 3];
      if (age <= 0) continue;
      const maxA = bubSim[o7 + 4];
      age += dt;
      const o8 = i * 8;
      if (age >= maxA || bubData[o8 + 1] > -0.45) {
        bubSim[o7 + 3] = 0;
        bubData[o8 + 3] = 0;
        continue;
      }
      bubSim[o7 + 3] = age;
      const sd = bubSim[o7 + 6];
      bubSim[o7] *= drag;
      bubSim[o7 + 2] *= drag;
      const wob = 0.28 + age * 0.06;
      bubData[o8] += (bubSim[o7] + sin(time * 3.8 + sd * 40 + age * 2.1) * wob) * dt;
      bubData[o8 + 1] += bubSim[o7 + 1] * dt;
      bubData[o8 + 2] += (bubSim[o7 + 2] + cos(time * 3.3 + sd * 31 + age * 1.9) * wob) * dt;
      const life = age / maxA;
      bubData[o8 + 3] = bubSim[o7 + 5] * (0.55 + 0.72 * life) * sstep(0, 0.08, life) * sstep(1, 0.78, life);
      bubData[o8 + 5] = sstep(1, 0.72, life);
    }

    // ========================================================================
    // F. UPDATE CAMERA & PACK GPU INSTANCE BUFFERS
    // ========================================================================
    updateCamera(dt, time);
    packBuffers(time);
  }

  // Write submarine searchlight, tiny diver lantern, submarine scale & 10x Giant Manta shadow into UB[60..75]
  function writeLightUniforms(UB) {
    const q = sub.q;
    const sc = state.scaleMul;
    const bow = qRot(q, 0, -0.32 * sc, -1.96 * sc);
    const dir = qRot(q, 0, -0.05, -1.0);
    UB[60] = sub.x + bow[0];
    UB[61] = sub.y + bow[1];
    UB[62] = sub.z + bow[2];
    UB[63] = sub.lightSmooth * (state.inSub ? 1.55 : 0.95);
    UB[64] = dir[0];
    UB[65] = dir[1];
    UB[66] = dir[2];
    UB[67] = sc; // Used by dynSh for accurate submarine shadow scale!

    const pl = divers[0];
    UB[68] = pl.x;
    UB[69] = pl.y + 0.35 * sc;
    UB[70] = pl.z;
    UB[71] = state.inSub ? 0 : (0.28 + 0.42 * sub.lightSmooth);

    // Nearest 10x Giant Manta Ray casts a sweeping colossal shadow across the seabed!
    const ax = state.inSub ? sub.x : pl.x, az = state.inSub ? sub.z : pl.z;
    const c = hypot(colossi[0].x - ax, colossi[0].z - az) <= hypot(colossi[1].x - ax, colossi[1].z - az) ? colossi[0] : colossi[1];
    UB[72] = c.x;
    UB[73] = c.y;
    UB[74] = c.z;
    UB[75] = c.scale;
    UB[76] = state.midnightMode ? 0 : 1; // Daylight scattering; Midnight keeps only local lamps.
  }

  function getHudState() {
    const pl = divers[0];
    const ay = state.inSub ? sub.y : pl.y;
    const spd = state.inSub ? hypot(sub.vx, sub.vy, sub.vz) : hypot(pl.vx, pl.vy, pl.vz);
    const harpoonPoint = harpoonScreenPoint();
    return {
      inSub: state.inSub,
      miniMode: state.miniMode,
      midnightMode: state.midnightMode,
      nearSub: state.nearSub,
      subDist: state.subDist,
      depth: max(1, Math.round(-ay)),
      speed: spd,
      lightsOn: !!sub.lightsOn,
      viewMode: state.viewMode,
      botsAboard: state.botsAboard,
      summoning: sub.summonActive,
      mantaFlyby: state.mantaFlyby,
      mantaDist: Math.round(state.mantaDist),
      fishCount: fishInventory.reduce((a, b) => a + b, 0),
      fishInventory: [...fishInventory],
      harpoonPhase: harpoon.phase,
      harpoonTargetVisible: harpoonPoint.visible,
      harpoonTargetX: harpoonPoint.x,
      harpoonTargetY: harpoonPoint.y,
      harpoonRecoil: harpoon.recoil,
      toastEvent: state.toastEvent,
      toastSeq: state.toastSeq,
    };
  }

  return {
    diverData,
    subData,
    cockpitData,
    colossusData,
    beamData,
    bubData,
    fishInstances,
    consumeFishDirty: () => { const dirty = fishDirty; fishDirty = false; return dirty; },
    colossi,
    state,
    sub,
    divers,
    placeAtPose,
    toggleSubmarine,
    toggleMiniMode,
    toggleLights,
    toggleMidnight,
    setViewMode,
    cycleView,
    toggleCockpit,
    toggleMegalophobia,
    triggerGiantMantaFlyby,
    zoom,
    callFriends,
    fireHarpoon,
    reelHarpoon,
    summonSubmarine,
    step,
    writeLightUniforms,
    getHudState,
  };
}

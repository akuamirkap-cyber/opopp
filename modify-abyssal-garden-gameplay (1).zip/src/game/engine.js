// ============================================================================
// WebGPU renderer, world builder, input & loop (Noniv/abyssal-garden + Crew/Sub)
// ============================================================================
import { LV, SHADOW, AA, WATER, SAVED, keep, mob } from './quality.js';
import {
  sin, cos, sqrt, min, max, abs, floor, hypot, exp, round, atan2,
  clamp, NX, NY, NZ, VS, OX, OY, OZ, CELLS, CELLW, NCHUNK,
} from './math.js';
import {
  W_DENS, W_DETAIL, W_BLIT, W_WATER, W_SOLID, W_LEAF, W_ANIM, W_SURF, W_SPR, W_RAYS, W_RBLUR, W_POST,
} from './shaders.js';
import { W_DIVER, W_SUB, W_BEAM, W_COLOSSUS, W_COCKPIT } from './entityShaders.js';
import {
  MESAS, ARCHES, HOLES, CLEARS, PURPLE,
  primBuffer, buildTerrain, makeWorld,
  meshChunk, meshLathe, meshCoral, meshTubes, meshFluke, meshShip, meshManta, meshFish,
} from './world.js';
import { buildDiverMesh, buildSubmarineMesh, buildCockpitMesh, buildCockpitGlassMesh, buildBeamMesh } from './meshes.js';
import { createSimulation, N_DIVERS, N_BEAMS, N_DYNBUB, N_COLOSSUS } from './entities.js';
import { createAudio } from './audio.js';

export const VIEWPOINT_NAMES = [
  'Ekor Paus & Ngarai Kelp',
  'Kapal Kayu Karam',
  'Hutan Kelp Raksasa',
  'Taman Spons Barel',
  'Cekungan Sinar Matahari',
  'Gua Ungu Bercahaya',
];

export async function startAbyssalGarden(canvas, barEl, callbacks) {
  const rot = matchMedia('(orientation:portrait) and (pointer:coarse)');
  let loaded = 0, dead = false;

  const say = (msg, to, ms) => {
    if (!dead) callbacks.onProgress?.(msg, to);
    if (barEl && barEl.animate) {
      const a = barEl.animate(
        { transform: [`scaleX(${loaded})`, `scaleX(${to})`] },
        { duration: ms, fill: 'forwards', easing: 'cubic-bezier(.3,.5,.5,1)' }
      );
      loaded = to;
      return new Promise((r) => { a.ready.then(() => setTimeout(r)); setTimeout(r, document.hidden ? 0 : 900); });
    }
    loaded = to;
    return new Promise((r) => setTimeout(r, 16));
  };

  const fail = (m) => { const e = new Error(m); e.userFacing = true; throw e; };
  if (!navigator.gpu) fail('Scene ini membutuhkan WebGPU. Buka menggunakan Google Chrome atau Microsoft Edge terbaru.');
  const adapter = await navigator.gpu.requestAdapter({ powerPreference: 'high-performance' });
  if (!adapter) fail('Adaptor WebGPU tidak ditemukan. Pastikan akselerasi hardware aktif di Chrome / Edge.');

  callbacks.onBrowserHint?.(!navigator.userAgentData);

  const hasTS = adapter.features.has('timestamp-query');
  const device = await adapter.requestDevice({ requiredFeatures: hasTS ? ['timestamp-query'] : [] });
  device.addEventListener('uncapturederror', (e) => console.error('GPU: ' + e.error.message));
  device.lost.then((l) => {
    if (l.reason === 'destroyed') return;
    if (LV < 2) { keep('abyssal', LV + 1); location.reload(); return; }
    dead = true;
    document.body.className = 'l e';
    callbacks.onError?.('Perangkat grafis terputus. Muat ulang halaman untuk mencoba lagi.');
  });

  const ctx = canvas.getContext('webgpu');
  const FMT = navigator.gpu.getPreferredCanvasFormat();
  const Q = device.queue, HDR = 'rgba16float', DEPTH = 'depth32float';
  const TU = GPUTextureUsage, BU = GPUBufferUsage, SS = GPUShaderStage;

  const mod = (code) => device.createShaderModule({ code });
  const mkBuf = (data, usage) => {
    const b = device.createBuffer({ size: max(16, (data.byteLength + 3) & ~3), usage: usage | BU.COPY_DST });
    Q.writeBuffer(b, 0, data.buffer || data, data.byteOffset || 0, data.byteLength);
    return b;
  };
  const tex = (w, h, format, usage, o = {}) => device.createTexture({
    size: [w, h, o.d || 1], format, usage, mipLevelCount: o.mips || 1, sampleCount: o.samples || 1, dimension: o.d ? '3d' : '2d',
  });

  // ---------------------------------------------------------------- static resources
  const sRep = device.createSampler({ addressModeU: 'repeat', addressModeV: 'repeat', magFilter: 'linear', minFilter: 'linear', mipmapFilter: 'linear', maxAnisotropy: LV > 1 ? 1 : 8 });
  const sClamp = device.createSampler({ magFilter: 'linear', minFilter: 'linear' });
  const sCmp = device.createSampler({ compare: 'less-equal', magFilter: 'linear', minFilter: 'linear' });
  const tShadow = tex(SHADOW, SHADOW, DEPTH, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
  const tDummy = tex(1, 1, DEPTH, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
  const tWater = tex(WATER, WATER, HDR, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING, { mips: 5 });
  const tDetail = tex(1024, 1024, 'rgba8unorm', TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING, { mips: 11 });
  const tVol = tex(NX / 2, NY / 2, 'rg8unorm', TU.TEXTURE_BINDING | TU.COPY_DST, { d: NZ / 2 });
  const tMap = tex(512, 512, 'rgba8unorm', TU.TEXTURE_BINDING | TU.COPY_DST);

  // 80 floats = 320 bytes (original scene + dynamic lights/manta + Midnight day-light control)
  const UB = new Float32Array(80), UBS = new Float32Array(80);
  const ubo = device.createBuffer({ size: 320, usage: BU.UNIFORM | BU.COPY_DST });
  const uboS = device.createBuffer({ size: 320, usage: BU.UNIFORM | BU.COPY_DST });
  const WT = new Float32Array(4), uboW = device.createBuffer({ size: 16, usage: BU.UNIFORM | BU.COPY_DST });

  const VF = SS.VERTEX | SS.FRAGMENT;
  const bgl0 = device.createBindGroupLayout({ entries: [
    { binding: 0, visibility: VF, buffer: {} },
    { binding: 1, visibility: VF, sampler: {} }, { binding: 2, visibility: VF, sampler: {} }, { binding: 3, visibility: VF, sampler: { type: 'comparison' } },
    { binding: 4, visibility: VF, texture: { sampleType: 'depth' } },
    { binding: 5, visibility: VF, texture: {} }, { binding: 6, visibility: VF, texture: {} },
    { binding: 7, visibility: VF, texture: { viewDimension: '3d' } }, { binding: 8, visibility: VF, texture: {} },
  ] });
  const mkBG0 = (u, sh) => device.createBindGroup({ layout: bgl0, entries: [
    { binding: 0, resource: { buffer: u } }, { binding: 1, resource: sRep }, { binding: 2, resource: sClamp }, { binding: 3, resource: sCmp },
    { binding: 4, resource: sh.createView() }, { binding: 5, resource: tWater.createView() }, { binding: 6, resource: tDetail.createView() },
    { binding: 7, resource: tVol.createView() }, { binding: 8, resource: tMap.createView() },
  ] });
  const bg0 = mkBG0(ubo, tShadow), bg0s = mkBG0(uboS, tDummy);
  const pl0 = device.createPipelineLayout({ bindGroupLayouts: [bgl0] });

  const bglBlit = device.createBindGroupLayout({ entries: [{ binding: 0, visibility: SS.FRAGMENT, texture: {} }, { binding: 1, visibility: SS.FRAGMENT, sampler: {} }] });
  const plBlit = device.createPipelineLayout({ bindGroupLayouts: [bglBlit] });
  const mBlit = mod(W_BLIT);
  const blitPipe = (entry, format, add) => device.createRenderPipeline({
    layout: plBlit, vertex: { module: mBlit, entryPoint: 'vs' },
    fragment: { module: mBlit, entryPoint: entry, targets: [{ format, blend: add ? { color: { srcFactor: 'one', dstFactor: 'one' }, alpha: { srcFactor: 'one', dstFactor: 'one' } } : undefined }] },
  });
  const pMip8 = blitPipe('fsMip', 'rgba8unorm'), pMip16 = blitPipe('fsMip', HDR), pDown0 = blitPipe('fsDown0', HDR), pDown = blitPipe('fsDown', HDR), pUp = blitPipe('fsUp', HDR, true);
  const blitBG = (view) => device.createBindGroup({ layout: bglBlit, entries: [{ binding: 0, resource: view }, { binding: 1, resource: sClamp }] });
  const colorAtt = (view, clear) => ({ view, loadOp: clear ? 'clear' : 'load', storeOp: 'store', clearValue: [0, 0, 0, 0] });

  // Vertex buffer layouts
  const A = (shaderLocation, offset, format) => ({ shaderLocation, offset, format });
  const vbSolid = { arrayStride: 16, attributes: [A(0, 0, 'float32x3'), A(1, 12, 'snorm8x4')] };
  const ibSolid = { arrayStride: 48, stepMode: 'instance', attributes: [A(2, 0, 'float32x4'), A(3, 16, 'float32x4'), A(4, 32, 'float32x4')] };
  const ibLeaf = { arrayStride: 36, stepMode: 'instance', attributes: [A(0, 0, 'float32x4'), A(1, 16, 'float32x4'), A(2, 32, 'unorm8x4')] };
  const ibAnim = { arrayStride: 32, stepMode: 'instance', attributes: [A(2, 0, 'float32x4'), A(3, 16, 'float32x4')] };
  const ibBub = { arrayStride: 32, stepMode: 'instance', attributes: [A(0, 0, 'float32x4'), A(1, 16, 'float32x4')] };
  const ibSnow = { arrayStride: 16, stepMode: 'instance', attributes: [A(0, 0, 'float32x4')] };
  // Custom vertex & instance layouts for Vintage Divers & Vintage Submarine
  const vbEntity = { arrayStride: 20, attributes: [A(0, 0, 'float32x3'), A(1, 12, 'snorm8x4'), A(2, 16, 'unorm8x4')] };
  const ibDiverL = { arrayStride: 96, stepMode: 'instance', attributes: [A(3, 0, 'float32x4'), A(4, 16, 'float32x4'), A(5, 32, 'float32x4'), A(6, 48, 'float32x4'), A(7, 64, 'float32x4'), A(8, 80, 'float32x4')] };
  const ibSubL = { arrayStride: 64, stepMode: 'instance', attributes: [A(3, 0, 'float32x4'), A(4, 16, 'float32x4'), A(5, 32, 'float32x4'), A(6, 48, 'float32x4')] };
  const ibCockpitL = { arrayStride: 80, stepMode: 'instance', attributes: [A(3, 0, 'float32x4'), A(4, 16, 'float32x4'), A(5, 32, 'float32x4'), A(6, 48, 'float32x4'), A(7, 64, 'float32x4')] };

  const scenePipe = (m, vsE, fsE, buffers, o = {}) => device.createRenderPipeline({
    layout: pl0,
    vertex: { module: m, entryPoint: vsE, buffers, constants: o.constants },
    fragment: { module: m, entryPoint: fsE, targets: [{ format: HDR, blend: o.blend }] },
    primitive: { topology: o.strip ? 'triangle-strip' : 'triangle-list', cullMode: o.cull || 'none' },
    depthStencil: { format: DEPTH, depthWriteEnabled: !o.blend, depthCompare: 'greater' },
    multisample: { count: AA },
  });
  const shadowPipe = (m, vsE, buffers, o = {}) => device.createRenderPipeline({
    layout: pl0,
    vertex: { module: m, entryPoint: vsE, buffers, constants: o.constants },
    primitive: { topology: o.strip ? 'triangle-strip' : 'triangle-list', cullMode: o.cull || 'none' },
    depthStencil: { format: DEPTH, depthWriteEnabled: true, depthCompare: 'less', depthBias: 2, depthBiasSlopeScale: 1.5 },
  });

  await say('Compiling shaders…', 0.06, 300);
  const mSolid = mod(W_SOLID), mLeaf = mod(W_LEAF), mAnim = mod(W_ANIM), mSurf = mod(W_SURF), mSpr = mod(W_SPR);
  const mDiver = mod(W_DIVER), mSub = mod(W_SUB), mBeam = mod(W_BEAM);
  const mColossus = mod(W_COLOSSUS), mCockpit = mod(W_COCKPIT);
  const ALPHA = { color: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' }, alpha: { srcFactor: 'one', dstFactor: 'one-minus-src-alpha' } };
  const ADD = { color: { srcFactor: 'one', dstFactor: 'one' }, alpha: { srcFactor: 'one', dstFactor: 'one' } };

  const pTerrain = scenePipe(mSolid, 'vs', 'fs', [vbSolid, ibSolid], { cull: 'back' });
  const pSolid = scenePipe(mSolid, 'vs', 'fs', [vbSolid, ibSolid]);
  const pDiver = scenePipe(mDiver, 'vs', 'fs', [vbEntity, ibDiverL]);
  const pSub = scenePipe(mSub, 'vs', 'fs', [vbEntity, ibSubL]);
  const pCockpit = scenePipe(mCockpit, 'vs', 'fs', [vbEntity, ibCockpitL]);
  // Glass is rendered last with premultiplied alpha so the real underwater scene remains visible through it.
  const pCockpitGlass = scenePipe(mCockpit, 'vs', 'fs', [vbEntity, ibCockpitL], { blend: ALPHA });
  const pColossus = scenePipe(mColossus, 'vs', 'fs', [vbSolid, ibAnim]);
  const pBeam = scenePipe(mBeam, 'vs', 'fs', [vbSolid, ibSolid], { blend: ADD });
  const pLeaf = scenePipe(mLeaf, 'vs', 'fs', [ibLeaf], { strip: true, constants: { ROWS: 9 } });
  const pLeaf5 = scenePipe(mLeaf, 'vs', 'fs', [ibLeaf], { strip: true, constants: { ROWS: 5 } });
  const pLeafS = scenePipe(mLeaf, 'vs', 'fs', [ibLeaf], { strip: true, constants: { ROWS: 3, FAR: 70 } });
  const pLeafF = scenePipe(mLeaf, 'vs', 'fs', [ibLeaf], { strip: true, constants: { ROWS: 3 } });
  const pFish = scenePipe(mAnim, 'vsFish', 'fsFish', [vbSolid, ibAnim]);
  const pManta = scenePipe(mAnim, 'vsManta', 'fsManta', [vbSolid, ibAnim]);
  const pSurf = scenePipe(mSurf, 'vs', 'fs', [], { strip: true });
  const pBack = scenePipe(mSurf, 'vsB', 'fsB', [], { strip: true });
  const pBub = scenePipe(mSpr, 'vsBub', 'fsBub', [ibBub], { strip: true, blend: ALPHA });
  const pDynBub = scenePipe(mSpr, 'vsDynBub', 'fsBub', [ibBub], { strip: true, blend: ALPHA });
  const pSnow = scenePipe(mSpr, 'vsSnow', 'fsSnow', [ibSnow], { strip: true, blend: ADD });
  const pGl = scenePipe(mLeaf, 'vsGl', 'fsGl', [ibBub], { strip: true, blend: ADD, constants: { ROWS: 7 } });
  const pSolidSh = shadowPipe(mSolid, 'vs', [vbSolid, ibSolid]);
  const pTerrSh = shadowPipe(mSolid, 'vs', [vbSolid, ibSolid], { cull: 'front' });
  const pLeafSh = shadowPipe(mLeaf, 'vs', [ibLeaf], { strip: true, constants: { ROWS: 3 } });

  const mWater = mod(W_WATER);
  const pWater = device.createRenderPipeline({ layout: 'auto', vertex: { module: mWater, entryPoint: 'vs' }, fragment: { module: mWater, entryPoint: 'fs', targets: [{ format: HDR }] } });
  const bgWater = device.createBindGroup({ layout: pWater.getBindGroupLayout(0), entries: [{ binding: 0, resource: { buffer: uboW } }] });
  const waterViews = [0, 1, 2, 3, 4].map((m) => tWater.createView({ baseMipLevel: m, mipLevelCount: 1 }));
  const waterBG = waterViews.map((v) => blitBG(v));
  const waterPass = waterViews.map((v) => ({ colorAttachments: [colorAtt(v, true)] }));

  const mRays = mod(W_RAYS), mPost = mod(W_POST), mRB = mod(W_RBLUR);
  const pRB = device.createRenderPipeline({ layout: 'auto', vertex: { module: mRB, entryPoint: 'vs' }, fragment: { module: mRB, entryPoint: 'fs', targets: [{ format: HDR }] } });
  const pRays = device.createRenderPipeline({ layout: 'auto', vertex: { module: mRays, entryPoint: 'vs' }, fragment: { module: mRays, entryPoint: 'fs', targets: [{ format: HDR }] } });
  const pPost = device.createRenderPipeline({ layout: 'auto', vertex: { module: mPost, entryPoint: 'vs' }, fragment: { module: mPost, entryPoint: 'fs', targets: [{ format: FMT }] } });

  // ---------------------------------------------------------------- sun + shadow matrix (100% original)
  const SUN = (() => { const v = [0.27, 1, -0.24], l = hypot(...v); return v.map((c) => c / l); })();
  {
    const L = SUN, lr = [L[1], -L[0], 0], ll = hypot(...lr); lr[0] /= ll; lr[1] /= ll;
    const lu = [L[1] * lr[2] - L[2] * lr[1], L[2] * lr[0] - L[0] * lr[2], L[0] * lr[1] - L[1] * lr[0]];
    const R = 225, d0 = -175, d1 = 125, m = UBS;
    m[0] = lr[0] / R; m[4] = lr[1] / R; m[8] = lr[2] / R; m[12] = 0;
    m[1] = lu[0] / R; m[5] = lu[1] / R; m[9] = lu[2] / R; m[13] = 0;
    m[2] = -L[0] / (d1 - d0); m[6] = -L[1] / (d1 - d0); m[10] = -L[2] / (d1 - d0); m[14] = d1 / (d1 - d0);
    m[3] = 0; m[7] = 0; m[11] = 0; m[15] = 1;
    for (let i = 0; i < 16; i++) { UBS[16 + i] = m[i]; UB[16 + i] = m[i]; }
    for (let i = 0; i < 3; i++) { UB[48 + i] = UBS[48 + i] = SUN[i]; }
    UBS[32] = 0; UBS[33] = -20; UBS[34] = 0; UBS[35] = 0; UBS[58] = 1;
    Q.writeBuffer(uboS, 0, UBS);
  }

  // ---------------------------------------------------------------- world generation (100% original)
  await say('Sculpting the seabed…', 0.25, 1200);
  keep('abyssalLoad', 1);
  const onPageHide = () => keep('abyssalLoad', '');
  addEventListener('pagehide', onPageHide);

  let D;
  {
    const prims = primBuffer();
    const m = mod(W_DENS), p = device.createComputePipeline({ layout: 'auto', compute: { module: m, entryPoint: 'main' } });
    const size = NX * NY * NZ * 4;
    const u = new ArrayBuffer(48), uu = new Uint32Array(u), uf = new Float32Array(u);
    uu[0] = NX; uu[1] = NY; uu[2] = NZ; uf[4] = OX; uf[5] = OY; uf[6] = OZ; uf[7] = VS;
    uu[8] = MESAS.length; uu[9] = ARCHES.length; uu[10] = HOLES.length; uu[11] = CLEARS.length;
    const bu = mkBuf(new Uint8Array(u), BU.UNIFORM), bp = mkBuf(prims, BU.STORAGE);
    const bd = device.createBuffer({ size, usage: BU.STORAGE | BU.COPY_SRC });
    const br = device.createBuffer({ size, usage: BU.MAP_READ | BU.COPY_DST });
    const bg = device.createBindGroup({ layout: p.getBindGroupLayout(0), entries: [
      { binding: 0, resource: { buffer: bu } }, { binding: 1, resource: { buffer: bd } }, { binding: 2, resource: { buffer: bp } },
    ] });
    const e = device.createCommandEncoder(), c = e.beginComputePass();
    c.setPipeline(p); c.setBindGroup(0, bg); c.dispatchWorkgroups(NX / 4, NY / 4, NZ / 4); c.end();
    e.copyBufferToBuffer(bd, 0, br, 0, size);
    Q.submit([e.finish()]);
    await br.mapAsync(GPUMapMode.READ);
    D = new Float32Array(br.getMappedRange().slice(0));
    br.unmap(); br.destroy(); bd.destroy();
    const S = NX * NY, R = new Uint8Array(D.length), O = [1, -1, NX, -NX, S, -S], b = new Uint8Array(NX), L = [];
    for (let i = 0; i < D.length;) {
      b.fill(1);
      for (let y = 0; y < NY; y++) for (let x = 0; x < NX; x++, i++) {
        if (D[i] <= 0) b[x] = 0; else if (b[x]) R[i] = 1; else L.push(i);
      }
    }
    for (let k = 1; k; L.reverse()) { k = 0; for (const i of L) if (!R[i] && O.some((o) => R[i + o])) R[i] = k = 1; }
    for (const i of L) if (!R[i]) D[i] = -D[i];
  }

  // Rock SDF bricks for collision (used by Player Diver, 5 Friend Bots, Submarine, and Camera!)
  const CO = 52, CN = 102, CI = new Uint16Array(CN * CN * NY / 4);
  let CG = new Int8Array(64 * 65534);
  {
    let n = 0;
    for (let bz = 0; bz < CN; bz++) for (let by = 1; by < NY / 4 - 1; by++) for (let bx = 0; bx < CN; bx++) {
      if (hypot(bx - CN / 2 + 0.5, bz - CN / 2 + 0.5) > 52) continue;
      let lo = 127, hi = -127;
      for (let z = 0; z < 4; z++) for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
        const i = CO + bx * 4 + x + NX * (by * 4 + y + NY * (CO + bz * 4 + z));
        const gz = D[i + NX * NY] - D[i - NX * NY];
        const gx = D[i + 1] - D[i - 1], g = D[i + NX] - D[i - NX], l = sqrt(gx * gx + g * g + gz * gz) / 1.5;
        const q = round(clamp(D[i] / max(l, 0.05), -1, 1) * 127);
        CG[n * 64 + x + 4 * y + 16 * z] = q; if (q < lo) lo = q; if (q > hi) hi = q;
      }
      CI[bx + CN * (by + NY / 4 * bz)] = lo === hi && lo * lo === 16129 ? +(lo > 0) : (n++, n + 1);
    }
    CG = CG.slice(0, n * 64);
  }

  const maxC = CN * 4 - 1.01, maxY = NY - 4.01;
  const cv = (x, y, z) => {
    const b = CI[(x >> 2) + CN * ((y >> 2) + NY / 4 * (z >> 2))];
    return b > 1 ? CG[b * 64 - 128 + (x & 3) + 4 * (y & 3) + 16 * (z & 3)] : b * 254 - 127;
  };
  const sdAt = (wx, wy, wz) => {
    const x = clamp((wx - OX) / VS - CO, 0.01, maxC);
    const y = clamp((wy - OY) / VS, 4.01, maxY);
    const z = clamp((wz - OZ) / VS - CO, 0.01, maxC);
    const ix = x | 0, iy = y | 0, iz = z | 0, u = x - ix, v = y - iy;
    const a = cv(ix, iy, iz), b = cv(ix, iy + 1, iz), c = cv(ix, iy, iz + 1), d = cv(ix, iy + 1, iz + 1);
    const p = a + (cv(ix + 1, iy, iz) - a) * u, q = b + (cv(ix + 1, iy + 1, iz) - b) * u;
    const r = c + (cv(ix + 1, iy, iz + 1) - c) * u, s = d + (cv(ix + 1, iy + 1, iz + 1) - d) * u;
    const e = p + (q - p) * v;
    return (e + (r + (s - r) * v - e) * (z - iz)) / 127;
  };
  const _gr = [0, 0, 0];
  const gradAt = (wx, wy, wz) => {
    const e = 0.375;
    const gx = sdAt(wx + e, wy, wz) - sdAt(wx - e, wy, wz);
    const gy = sdAt(wx, wy + e, wz) - sdAt(wx, wy - e, wz);
    const gz = sdAt(wx, wy, wz + e) - sdAt(wx, wy, wz - e);
    const l = sqrt(gx * gx + gy * gy + gz * gz);
    if (l < 0.06) return null;
    _gr[0] = gx / l; _gr[1] = gy / l; _gr[2] = gz / l;
    return _gr;
  };

  await say('Carving canyons…', 0.32, 400);
  const T = buildTerrain(D);

  // Exact 6 viewpoints & 60 s path from Noniv/abyssal-garden
  const POSES = [
    [10, 1.3, 7, -9, -31, -10],
    [50, 1.3, 34, 58, -23, 8],
    [-26, 2.2, -100, 0, -9, -108],
    [-55, 1.5, -18, -60, -30, 8],
    [10, 1.2, -62, 6, -22, -90],
    [3, 1.6, 62, 1, -28, 100],
  ];
  const FLY = new Float32Array([
    10, -42.2, 7, -9, -31, -10,
    7.5, -41.8, 5.5, -10, -31, -12,
    9, -40.5, 18, 17, -37, 42,
    22, -39.2, 40, 48, -36, 45,
    38, -39.2, 46, 57, -27, 18,
    50, -40.4, 35, 58, -24, 8,
    55, -39, 20, 60, -18, -10,
    58, -34, -12, 40, -26, -60,
    50, -30, -44, 10, -26, -80,
    30, -30, -70, 4, -28, -90,
    12, -38.5, -62, 6, -27, -90,
    -4, -36.5, -70, 0, -14, -100,
    -16, -37, -84, 0, -22, -108,
    -29, -38, -90, -44, -34, -60,
    -41, -38, -70, -56, -34, -40,
    -53, -38, -50, -60, -34, -20,
    -58, -38, -28, -60, -32, 0,
    -57, -38, -10, -60, -30, 16,
    -60, -38, 10, -50, -36, 40,
    -52, -37, 36, -20, -35, 44,
    -22, -38, 43, 4, -38, 52,
    -6, -39.2, 44.5, 4, -37, 70,
    3, -40.6, 53, 3, -35, 84,
    3, -41.5, 62, 1, -30, 100,
    4, -39, 76, 3, -22, 100,
  ]);
  const FLYN = FLY.length / 6, FLYT = 60, LUTN = 1024, flyLUT = new Float32Array(LUTN + 1);
  const flyPts = [];
  const P6 = new Float64Array(6);
  const flyRaw = (s) => {
    let i = floor(s) | 0; if (i > FLYN - 2) i = FLYN - 2;
    const u = s - i, i0 = (i > 0 ? i - 1 : 0) * 6, i1 = i * 6, i2 = (i + 1) * 6, i3 = (i + 2 < FLYN ? i + 2 : FLYN - 1) * 6;
    for (let o = 0; o < 6; o++) {
      const a = FLY[i0 + o], b = FLY[i1 + o], c = FLY[i2 + o], d = FLY[i3 + o];
      P6[o] = 0.5 * (2 * b + (c - a) * u + (2 * a - 5 * b + 4 * c - d) * u * u + (3 * b - a - 3 * c + d) * u * u * u);
    }
  };
  {
    const M = 4096, len = new Float32Array(M + 1); let px = 0, py = 0, pz = 0;
    for (let k = 0; k <= M; k++) {
      flyRaw(k / M * (FLYN - 1));
      if (k) len[k] = len[k - 1] + hypot(P6[0] - px, P6[1] - py, P6[2] - pz);
      px = P6[0]; py = P6[1]; pz = P6[2];
    }
    for (let k = 0, j = 0; k <= LUTN; k++) {
      const d = k / LUTN * len[M];
      while (j < M - 1 && len[j + 1] < d) j++;
      flyLUT[k] = (j + (d - len[j]) / max(len[j + 1] - len[j], 1e-6)) / M * (FLYN - 1);
    }
  }
  for (let t = 0; t <= FLYT; t += 0.1) {
    let s = clamp(t / FLYT, 0, 1); s = s * s * (3 - 2 * s) * 0.25 + s * 0.75;
    s *= LUTN; let k = floor(s) | 0; if (k > LUTN - 1) k = LUTN - 1;
    flyRaw(flyLUT[k] + (flyLUT[k + 1] - flyLUT[k]) * (s - k));
    flyPts.push([P6[0], P6[1], P6[2]]);
  }
  for (const p of POSES) flyPts.push([p[0], -40, p[2]]);

  await say('Growing kelp…', 0.72, 2400);
  const Wd = makeWorld(D, T, flyPts, POSES);
  for (const p of POSES) p[1] += Wd.gy(p[0], p[2]);
  D = Wd.gy = T.smp = null;

  await say('Building set pieces & submarine…', 0.92, 1100);
  const meshes = [
    meshChunk(1, 3), meshChunk(7, 3), meshChunk(13, 3), meshChunk(22, 3),
    meshLathe([[0, 0, 0.5], [0.34, 0, 0.6], [0.5, 0.2, 0.85], [0.6, 0.6, 1], [0.55, 0.95, 1], [0.47, 1.08, 1], [0.38, 1.1, 0.9], [0.3, 1.0, 0.45], [0.26, 0.6, 0.15], [0, 0.35, 0.05]], 18, 0.3, 9),
    meshLathe([[0, 0, 0.5], [0.2, 0, 0.6], [0.26, 0.5, 0.85], [0.4, 1.25, 1], [0.4, 1.42, 1], [0.33, 1.48, 0.9], [0.26, 1.38, 0.4], [0.18, 0.8, 0.12], [0, 0.5, 0.05]], 16, 0.35, 8),
    meshLathe([[0, 0, 0.5], [0.5, 0, 0.7], [0.72, 0.18, 1], [0.74, 0.38, 1], [0.62, 0.5, 0.9], [0.48, 0.42, 0.45], [0.4, 0.2, 0.15], [0, 0.14, 0.06]], 18, 0.25, 10),
    meshCoral(0), meshCoral(1), meshTubes(),
  ].map((m) => m.build());
  meshes.push(
    meshFluke(), meshShip().build(), meshManta().build(), meshFish().build(),
    meshChunk(3).build(), meshChunk(11).build(), meshChunk(29).build(),
    meshChunk(5, 3).build(), meshChunk(17, 3).build(), meshChunk(41, 3).build(), meshChunk(9, 1).build(),
    meshCoral(0, 1).build(), meshCoral(1, 1).build(),
    meshChunk(5, 2, 1).build(), meshChunk(17, 2, 1).build(), meshChunk(41, 2, 1).build()
  );

  let nV = 0, nI = 0;
  for (const m of meshes) { m.v0 = nV; m.i0 = nI; nV += m.nv; nI += m.ib.length; }
  const allV = new Uint8Array(nV * 16), allI = new Uint32Array(nI);
  for (const m of meshes) { allV.set(new Uint8Array(m.vb), m.v0 * 16); allI.set(m.ib, m.i0); }
  const vbMesh = mkBuf(allV, BU.VERTEX), ibMesh = mkBuf(allI, BU.INDEX);
  const vbTerrain = mkBuf(new Uint8Array(T.vb), BU.VERTEX), ibTerrain = mkBuf(T.ib, BU.INDEX);
  const nSolid = Wd.solids.data.length / 12;
  const solidData = new Float32Array((nSolid + 1) * 12);
  solidData.set(Wd.solids.data);
  solidData.set([0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1, 0], nSolid * 12);
  const ibSolids = mkBuf(solidData, BU.VERTEX);
  const ibChunk = Wd.chunks.map((c) => mkBuf(c.data, BU.VERTEX));
  const ibProp = Wd.props.map((c) => mkBuf(c.data, BU.VERTEX));
  const ibBig = mkBuf(new Uint8Array(Wd.big.buf), BU.VERTEX);
  const ibBigF = mkBuf(new Uint8Array(Wd.bigF.buf), BU.VERTEX);
  const ibSmall = mkBuf(new Uint8Array(Wd.small.buf), BU.VERTEX);
  const ibFish = mkBuf(Wd.fish, BU.VERTEX), ibManta = mkBuf(Wd.mantas, BU.VERTEX);
  const ibBubbles = mkBuf(Wd.bubbles, BU.VERTEX), ibSnowB = mkBuf(Wd.snow, BU.VERTEX);
  const ibGl = mkBuf(Wd.glints, BU.VERTEX), nGl = Wd.glints.length / 8;
  const nFish = Wd.fish.length / 8, nManta = Wd.mantas.length / 8, nBub = Wd.bubbles.length / 8, nSnow = Wd.snow.length / 4;
  const MANTA = meshes[12], FISH = meshes[13];

  // Build Vintage Diver, Vintage Submarine, 3D Submarine Cockpit & Volumetric Searchlight GPU buffers
  const diverM = buildDiverMesh();
  const subM = buildSubmarineMesh();
  const cockpitM = buildCockpitMesh();
  const cockpitGlassM = buildCockpitGlassMesh();
  const beamM = buildBeamMesh();
  const vbDiver = mkBuf(new Uint8Array(diverM.vb), BU.VERTEX), idxDiver = mkBuf(diverM.ib, BU.INDEX);
  const vbSub = mkBuf(new Uint8Array(subM.vb), BU.VERTEX), idxSub = mkBuf(subM.ib, BU.INDEX);
  const vbCockpit = mkBuf(new Uint8Array(cockpitM.vb), BU.VERTEX), idxCockpit = mkBuf(cockpitM.ib, BU.INDEX);
  const vbCockpitGlass = mkBuf(new Uint8Array(cockpitGlassM.vb), BU.VERTEX), idxCockpitGlass = mkBuf(cockpitGlassM.ib, BU.INDEX);
  const vbBeam = mkBuf(new Uint8Array(beamM.vb), BU.VERTEX), idxBeam = mkBuf(beamM.ib, BU.INDEX);

  const F = new Float64Array(24);
  const CX = 0, CY = 1, CZ = 2, YAW = 3, PIT = 4, FX = 5, FY = 6, FZ = 7, RX = 8, RZ = 9, UX = 10, UY = 11, UZ = 12, TIME = 16, LAST = 18, GPU = 19, HUDT = 20;

  const audio = createAudio(() => [F[CX], F[CY], F[CZ]]);
  const sim = createSimulation(sdAt, gradAt, audio, Wd.fish);

  const ibDiver = mkBuf(sim.diverData, BU.VERTEX);
  const ibSub = mkBuf(sim.subData, BU.VERTEX);
  const ibCockpit = mkBuf(sim.cockpitData, BU.VERTEX);
  const ibColossus = mkBuf(sim.colossusData, BU.VERTEX);
  const ibBeam = mkBuf(sim.beamData, BU.VERTEX);
  const ibDynBub = mkBuf(sim.bubData, BU.VERTEX);

  Q.writeTexture({ texture: tVol }, Wd.volD, { bytesPerRow: NX, rowsPerImage: NY / 2 }, [NX / 2, NY / 2, NZ / 2]);
  Q.writeTexture({ texture: tMap }, Wd.gm, { bytesPerRow: 2048 }, [512, 512]);

  // ---------------------------------------------------------------- one-time bakes: detail texture + shadow map
  {
    const m = mod(W_DETAIL), p = device.createRenderPipeline({ layout: 'auto', vertex: { module: m, entryPoint: 'vs' }, fragment: { module: m, entryPoint: 'fs', targets: [{ format: 'rgba8unorm' }] } });
    const e = device.createCommandEncoder();
    let r = e.beginRenderPass({ colorAttachments: [colorAtt(tDetail.createView({ baseMipLevel: 0, mipLevelCount: 1 }), true)] });
    r.setPipeline(p); r.draw(3); r.end();
    for (let i = 1; i < 11; i++) {
      r = e.beginRenderPass({ colorAttachments: [colorAtt(tDetail.createView({ baseMipLevel: i, mipLevelCount: 1 }), true)] });
      r.setPipeline(pMip8); r.setBindGroup(0, blitBG(tDetail.createView({ baseMipLevel: i - 1, mipLevelCount: 1 }))); r.draw(3); r.end();
    }
    r = e.beginRenderPass({ colorAttachments: [], depthStencilAttachment: { view: tShadow.createView(), depthClearValue: 1, depthLoadOp: 'clear', depthStoreOp: 'store' } });
    r.setBindGroup(0, bg0s);
    r.setPipeline(pTerrSh);
    r.setVertexBuffer(0, vbTerrain); r.setVertexBuffer(1, ibSolids); r.setIndexBuffer(ibTerrain, 'uint32');
    r.drawIndexed(T.ib.length, 1, 0, 0, nSolid);
    r.setPipeline(pSolidSh); r.setVertexBuffer(0, vbMesh); r.setIndexBuffer(ibMesh, 'uint32');
    for (let i = 0; i < 12; i++) { const g = Wd.solids.ranges[i]; if (g[1]) r.drawIndexed(meshes[i].ib.length, g[1], meshes[i].i0, meshes[i].v0, g[0]); }
    if (!LV) for (let i = 0; i < NCHUNK; i++) { r.setVertexBuffer(1, ibChunk[i]); r.drawIndexed(meshes[14 + i].ib.length, Wd.chunks[i].n, meshes[14 + i].i0, meshes[14 + i].v0, 0); }
    if (!LV) for (let i = 0; i < 6; i++) if (Wd.props[i].n) { r.setVertexBuffer(1, ibProp[i]); r.drawIndexed(meshes[4 + i].ib.length, Wd.props[i].n, meshes[4 + i].i0, meshes[4 + i].v0, 0); }
    r.setPipeline(pLeafSh); r.setVertexBuffer(0, ibBig); r.draw(6, Wd.big.n);
    r.end();
    Q.submit([e.finish()]);
  }
  for (const o of [Wd.big, Wd.bigF, Wd.small, ...Wd.chunks, ...Wd.props]) o.buf = o.data = 0;
  Wd.glints = Wd.volD = Wd.gm = T.vb = T.ib = T.wp = T.wn = 0;

  // ---------------------------------------------------------------- render targets (rebuilt on resize)
  const PIXMAX = 2560 * 1440, PIXMIN = mob ? 25e4 : 5e5, DETMIN = 0.4;
  let W = 0, H = 0, DW = 0, DH = 0;
  let pix = +SAVED[1] || (LV > 1 ? 41e4 : mob ? 1280 * 720 : PIXMAX);
  let det = +SAVED[2] || 1;
  let dynN = 0, dynT = 0, dynG = 0, dynGN = 0, dynBad = 0, dynOk = 0, dynWait = 3;
  let passScene, passRays, passBlur, bgBlur, passPost, bgRays, bgPost, bloomPass = [], bloomBG = [], targets = [];
  const NB = 6;

  function resize() {
    DW = max(2, round((canvas.clientWidth || innerWidth) * devicePixelRatio));
    DH = max(2, round((canvas.clientHeight || innerHeight) * devicePixelRatio));
    const s = min(1, sqrt(pix / (DW * DH)));
    const w = max(4, round(DW * s) & ~1), h = max(4, round(DH * s) & ~1);
    if (w === W && h === H) return;
    dynN = dynG = dynGN = 0; dynT = -300;
    W = w; H = h; canvas.width = W; canvas.height = H;
    ctx.configure({ device, format: FMT, alphaMode: 'opaque' });
    for (const t of targets) t.destroy();
    const tMS = tex(AA > 1 ? W : 1, H, HDR, TU.RENDER_ATTACHMENT, { samples: AA });
    const tDp = tex(W, H, DEPTH, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING, { samples: AA });
    const tRes = tex(W, H, HDR, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
    const tRay = tex(W / 2, H / 2, HDR, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
    const tRay2 = tex(W / 2, H / 2, HDR, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
    targets = [tMS, tDp, tRes, tRay, tRay2];
    const bl = [];
    for (let i = 0; i < NB; i++) {
      const t = tex(max(1, W >> (i + 1)), max(1, H >> (i + 1)), HDR, TU.RENDER_ATTACHMENT | TU.TEXTURE_BINDING);
      bl.push(t); targets.push(t);
    }
    const vDp = tDp.createView(), vRes = tRes.createView(), vRay = tRay.createView(), vRay2 = tRay2.createView(), vBl = bl.map((t) => t.createView());
    passScene = {
      colorAttachments: [{ view: AA > 1 ? tMS.createView() : vRes, resolveTarget: AA > 1 ? vRes : undefined, loadOp: 'clear', storeOp: AA > 1 ? 'discard' : 'store', clearValue: [0, 0, 0, 1] }],
      depthStencilAttachment: { view: vDp, depthClearValue: 0, depthLoadOp: 'clear', depthStoreOp: 'store' },
    };
    passRays = { colorAttachments: [colorAtt(vRay, true)] };
    passBlur = { colorAttachments: [colorAtt(vRay2, true)] };
    bgBlur = device.createBindGroup({ layout: pRB.getBindGroupLayout(0), entries: [{ binding: 0, resource: vRay }] });
    passPost = { colorAttachments: [{ view: null, loadOp: 'clear', storeOp: 'store', clearValue: [0, 0, 0, 1] }] };
    bgRays = device.createBindGroup({ layout: pRays.getBindGroupLayout(0), entries: [
      { binding: 0, resource: { buffer: ubo } }, { binding: 1, resource: sRep }, { binding: 2, resource: sCmp },
      { binding: 3, resource: tShadow.createView() }, { binding: 4, resource: tWater.createView() },
      { binding: 5, resource: vDp }, { binding: 6, resource: tVol.createView() }, { binding: 7, resource: sClamp },
    ] });
    bgPost = device.createBindGroup({ layout: pPost.getBindGroupLayout(0), entries: [
      { binding: 0, resource: { buffer: ubo } }, { binding: 1, resource: sClamp }, { binding: 2, resource: vRes },
      { binding: 3, resource: vRay2 }, { binding: 4, resource: vBl[0] }, { binding: 5, resource: vDp },
    ] });
    bloomPass = []; bloomBG = [];
    for (let i = 0; i < NB; i++) { bloomPass.push({ colorAttachments: [colorAtt(vBl[i], true)] }); bloomBG.push(blitBG(i ? vBl[i - 1] : vRes)); }
    for (let i = NB - 1; i > 0; i--) { bloomPass.push({ colorAttachments: [colorAtt(vBl[i - 1], false)] }); bloomBG.push(blitBG(vBl[i])); }
    UB[52] = W; UB[53] = H; UB[54] = 1 / W; UB[55] = 1 / H;
  }
  resize();
  addEventListener('resize', resize);

  // ---------------------------------------------------------------- GPU timestamp queries
  let qs, qResolve, qRead = [], tsBegin, tsEnd;
  if (hasTS) {
    qs = device.createQuerySet({ type: 'timestamp', count: 2 });
    qResolve = device.createBuffer({ size: 16, usage: BU.QUERY_RESOLVE | BU.COPY_SRC });
    for (let i = 0; i < 6; i++) {
      const b = device.createBuffer({ size: 16, usage: BU.MAP_READ | BU.COPY_DST });
      const o = { b, busy: false, done: null };
      o.done = () => {
        const a = new BigInt64Array(b.getMappedRange());
        const ms = Number(a[1] - a[0]) / 1e6; F[GPU] = ms; b.unmap(); o.busy = false;
        if (dynT > 0 && ms > 0 && ms < 1e3) { dynG += ms; dynGN++; }
      };
      qRead.push(o);
    }
    tsBegin = { querySet: qs, beginningOfPassWriteIndex: 0 };
    tsEnd = { querySet: qs, endOfPassWriteIndex: 1 };
  }

  // ---------------------------------------------------------------- rendering (100% original + Crew, Sub, Cockpit & 10x Manta)
  const NEAR = 0.05, EXPO = 0.62, RAYS = 0.54;
  let curTanh = 0.6;
  const submitList = [null];
  const rowOrd = new Uint8Array(CELLS);

  function drawCells(r, start, lo, hi, mar, indexed, verts, minD, maxD) {
    const cx = F[CX], cy = F[CY], cz = F[CZ], fx = F[FX], fy = F[FY], fz = F[FZ], rx = F[RX], rz = F[RZ], ux = F[UX], uy = F[UY], uz = F[UZ];
    const ds = indexed === 1 ? 1 : det * det;
    const tx = curTanh * W / H, hw = CELLW * 0.5, ex = hw + mar, min2 = minD * minD * ds, max2 = maxD * maxD * ds;
    for (let k = 0; k < CELLS; k++) {
      const rw = rowOrd[k], row = rw * CELLS, pz = OZ + (rw + 0.5) * CELLW - cz, hz = max(abs(pz) - hw, 0);
      let run = -1;
      for (let x = 0; x <= CELLS; x++) {
        const c = row + x; let v = false;
        if (x < CELLS) {
          const l = lo[c], h = hi[c];
          if (l <= h) {
            const px = OX + (x + 0.5) * CELLW - cx, py = (l + h) * 0.5 - cy, ey = (h - l) * 0.5 + mar, hx = max(abs(px) - hw, 0), h2 = hx * hx + hz * hz;
            if (h2 < max2 && h2 >= min2) {
              const lim = px * fx + py * fy + pz * fz + ex * abs(fx) + ey * abs(fy) + ex * abs(fz);
              if (lim >= 0 && abs(px * rx + pz * rz) - ex * (abs(rx) + abs(rz)) <= lim * tx) {
                v = abs(px * ux + py * uy + pz * uz) - ex * (abs(ux) + abs(uz)) - ey * abs(uy) <= lim * curTanh;
              }
            }
          }
        }
        if (v) { if (run < 0) run = c; } else if (run >= 0) {
          const a = start[run], n = start[c] - a;
          if (n > 0) {
            if (indexed === 1) r.drawIndexed(n * 6, 1, a * 6, 0, nSolid);
            else if (indexed) r.drawIndexed(indexed.ib.length, n, indexed.i0, indexed.v0, a);
            else r.draw(verts, n, 0, a);
          }
          run = -1;
        }
      }
    }
  }

  function syncCameraFromSim() {
    F[CX] = sim.state.camX;
    F[CY] = sim.state.camY;
    F[CZ] = sim.state.camZ;
    F[YAW] = sim.state.camYaw;
    F[PIT] = sim.state.camPitch;
  }

  function render() {
    syncCameraFromSim();
    const cx = F[CX], cy = F[CY], cz = F[CZ], pitch = F[PIT], yaw = F[YAW];
    const cp = cos(pitch), fy = sin(pitch), rx = cos(yaw), rz = sin(yaw), fx = cp * rz, fz = -cp * rx;
    const ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
    F[FX] = fx; F[FY] = fy; F[FZ] = fz; F[RX] = rx; F[RZ] = rz; F[UX] = ux; F[UY] = uy; F[UZ] = uz;

    curTanh = sim.state.tanh;
    const asp = W / H, sx = 1 / (curTanh * asp), sy = 1 / curTanh, m = UB;
    m[0] = rx * sx; m[4] = 0; m[8] = rz * sx; m[12] = -(rx * cx + rz * cz) * sx;
    m[1] = ux * sy; m[5] = uy * sy; m[9] = uz * sy; m[13] = -(ux * cx + uy * cy + uz * cz) * sy;
    m[2] = 0; m[6] = 0; m[10] = 0; m[14] = NEAR;
    m[3] = fx; m[7] = fy; m[11] = fz; m[15] = -(fx * cx + fy * cy + fz * cz);
    m[32] = cx; m[33] = cy; m[34] = cz; m[35] = F[TIME];
    m[36] = rx; m[37] = 0; m[38] = rz; m[39] = curTanh * asp;
    m[40] = ux; m[41] = uy; m[42] = uz; m[43] = curTanh;
    m[44] = fx; m[45] = fy; m[46] = fz; m[47] = NEAR;
    const zx = cx - PURPLE[0], zz = cz - PURPLE[1];
    let zt = (44 - sqrt(zx * zx + zz * zz)) / 18; zt = zt < 0 ? 0 : zt > 1 ? 1 : zt;
    m[51] = zt * zt * (3 - 2 * zt);
    let ek = (-cy - 8) / 26; ek = ek < 0 ? 0 : ek > 1 ? 1 : ek;
    m[56] = EXPO * (0.6 + 0.4 * ek); m[57] = RAYS; m[58] = det;
    sim.writeLightUniforms(m);
    Q.writeBuffer(ubo, 0, UB);
    WT[0] = F[TIME]; Q.writeBuffer(uboW, 0, WT);

    // Upload live Crew, Submarine, 3D Cockpit, 10x Giant Manta, Searchlight Beam & Bubble buffers
    Q.writeBuffer(ibDiver, 0, sim.diverData);
    Q.writeBuffer(ibSub, 0, sim.subData);
    Q.writeBuffer(ibCockpit, 0, sim.cockpitData);
    Q.writeBuffer(ibColossus, 0, sim.colossusData);
    Q.writeBuffer(ibBeam, 0, sim.beamData);
    Q.writeBuffer(ibDynBub, 0, sim.bubData);
    if (sim.consumeFishDirty()) Q.writeBuffer(ibFish, 0, sim.fishInstances);

    {
      let cr = floor((cz - OZ) / CELLW) | 0; cr = cr < 0 ? 0 : cr > CELLS - 1 ? CELLS - 1 : cr;
      let n = 0; rowOrd[n++] = cr;
      for (let d = 1; d < CELLS; d++) { if (cr - d >= 0) rowOrd[n++] = cr - d; if (cr + d < CELLS) rowOrd[n++] = cr + d; }
    }

    const e = device.createCommandEncoder();
    let slot = null;
    if (hasTS) { for (let i = 0; i < qRead.length; i++) if (!qRead[i].busy) { slot = qRead[i]; break; } }
    waterPass[0].timestampWrites = slot ? tsBegin : undefined;
    passPost.timestampWrites = slot ? tsEnd : undefined;

    // Animated water caustics + surface slope mips
    let r = e.beginRenderPass(waterPass[0]); r.setPipeline(pWater); r.setBindGroup(0, bgWater); r.draw(3); r.end();
    for (let i = 1; i < 5; i++) { r = e.beginRenderPass(waterPass[i]); r.setPipeline(pMip16); r.setBindGroup(0, waterBG[i - 1]); r.draw(3); r.end(); }

    // Main underwater scene pass
    r = e.beginRenderPass(passScene);
    r.setBindGroup(0, bg0);
    r.setPipeline(pTerrain); r.setVertexBuffer(0, vbTerrain); r.setVertexBuffer(1, ibSolids); r.setIndexBuffer(ibTerrain, 'uint32');
    drawCells(r, T.start, T.lo, T.hi, 1.5, 1, 0, 0, 240);

    r.setPipeline(pSolid); r.setVertexBuffer(0, vbMesh); r.setIndexBuffer(ibMesh, 'uint32');
    for (let i = 0; i < 12; i++) { const g = Wd.solids.ranges[i]; if (g[1]) r.drawIndexed(meshes[i].ib.length, g[1], meshes[i].i0, meshes[i].v0, g[0]); }
    for (let i = 0; i < NCHUNK; i++) {
      const c = Wd.chunks[i], big = i > 2 && i < 6; r.setVertexBuffer(1, ibChunk[i]);
      drawCells(r, c.start, c.lo, c.hi, 3, meshes[14 + i], 0, 0, i > 5 ? 30 : big ? 40 : 96);
      if (big) drawCells(r, c.start, c.lo, c.hi, 3, meshes[20 + i], 0, 40, 150);
    }
    for (let i = 0; i < 6; i++) {
      const lod = i === 3 || i === 4; r.setVertexBuffer(1, ibProp[i]);
      drawCells(r, Wd.props[i].start, Wd.props[i].lo, Wd.props[i].hi, 3, meshes[4 + i], 0, 0, lod ? 6 : 110);
      if (lod) drawCells(r, Wd.props[i].start, Wd.props[i].lo, Wd.props[i].hi, 3, meshes[18 + i], 0, 6, 110);
    }

    // Draw Vintage Expedition Submarine + 3D Cockpit Interior + Tiny Scuba Diver Player & 5 Friend Bots!
    if (sim.cockpitData[3] > 0.01) {
      r.setPipeline(pCockpit); r.setVertexBuffer(0, vbCockpit); r.setVertexBuffer(1, ibCockpit); r.setIndexBuffer(idxCockpit, 'uint32');
      r.drawIndexed(cockpitM.ib.length, 1, 0, 0, 0);
    } else {
      r.setPipeline(pSub); r.setVertexBuffer(0, vbSub); r.setVertexBuffer(1, ibSub); r.setIndexBuffer(idxSub, 'uint32');
      r.drawIndexed(subM.ib.length, 1, 0, 0, 0);
    }

    r.setPipeline(pDiver); r.setVertexBuffer(0, vbDiver); r.setVertexBuffer(1, ibDiver); r.setIndexBuffer(idxDiver, 'uint32');
    r.drawIndexed(diverM.ib.length, N_DIVERS, 0, 0, 0);

    // Draw all 6 Original Normal Mantas + 2 Colossal 10x Giant Manta Rays + Fish schools!
    r.setVertexBuffer(0, vbMesh); r.setIndexBuffer(ibMesh, 'uint32');
    r.setPipeline(pManta); r.setVertexBuffer(1, ibManta); r.drawIndexed(MANTA.ib.length, nManta, MANTA.i0, MANTA.v0, 0);
    r.setPipeline(pColossus); r.setVertexBuffer(1, ibColossus); r.drawIndexed(MANTA.ib.length, N_COLOSSUS, MANTA.i0, MANTA.v0, 0);
    r.setPipeline(pFish); r.setVertexBuffer(1, ibFish); r.drawIndexed(FISH.ib.length, nFish, FISH.i0, FISH.v0, 0);

    // Swaying Kelp forests & magenta ground cover
    r.setPipeline(pLeaf); r.setVertexBuffer(0, ibBig); drawCells(r, Wd.big.start, Wd.big.lo, Wd.big.hi, 5, false, 18, 0, 24);
    r.setPipeline(pLeaf5); drawCells(r, Wd.big.start, Wd.big.lo, Wd.big.hi, 5, false, 10, 24, 58);
    r.setPipeline(pLeafF); r.setVertexBuffer(0, ibBigF); drawCells(r, Wd.bigF.start, Wd.bigF.lo, Wd.bigF.hi, 5, false, 6, 58, 150);
    r.setPipeline(pLeafS); r.setVertexBuffer(0, ibSmall); drawCells(r, Wd.small.start, Wd.small.lo, Wd.small.hi, 1.5, false, 6, 0, 70);

    // Water surface & far haze
    r.setPipeline(pSurf); r.draw(4);
    r.setPipeline(pBack); r.draw(4);

    // Bubbles (vent + diver helmet & submarine propeller), Volumetric Searchlight Beams, Kelp Glints & Marine Snow
    r.setPipeline(pBub); r.setVertexBuffer(0, ibBubbles); r.draw(4, nBub);
    r.setPipeline(pDynBub); r.setVertexBuffer(0, ibDynBub); r.draw(4, N_DYNBUB);
    r.setPipeline(pBeam); r.setVertexBuffer(0, vbBeam); r.setVertexBuffer(1, ibBeam); r.setIndexBuffer(idxBeam, 'uint32');
    r.drawIndexed(beamM.ib.length, N_BEAMS, 0, 0, 0);
    r.setPipeline(pGl); r.setVertexBuffer(0, ibGl); r.draw(4, nGl);
    r.setPipeline(pSnow); r.setVertexBuffer(0, ibSnowB); r.draw(4, nSnow);

    // A curved, real 3D glass dome is composited over the underwater world; depth testing keeps
    // the mahogany dashboard and brass instruments naturally in front of the lower windshield.
    if (sim.cockpitData[3] > 0.01) {
      r.setPipeline(pCockpitGlass);
      r.setVertexBuffer(0, vbCockpitGlass);
      r.setVertexBuffer(1, ibCockpit);
      r.setIndexBuffer(idxCockpitGlass, 'uint32');
      r.drawIndexed(cockpitGlassM.ib.length, 1, 0, 0, 0);
    }
    r.end();

    // Volumetric sunbeams + blur + 6-mip Karis bloom + ACES tonemap composite
    r = e.beginRenderPass(passRays); r.setPipeline(pRays); r.setBindGroup(0, bgRays); r.draw(3); r.end();
    r = e.beginRenderPass(passBlur); r.setPipeline(pRB); r.setBindGroup(0, bgBlur); r.draw(3); r.end();
    for (let i = 0; i < bloomPass.length; i++) {
      r = e.beginRenderPass(bloomPass[i]);
      r.setPipeline(i === 0 ? pDown0 : i < NB ? pDown : pUp);
      r.setBindGroup(0, bloomBG[i]); r.draw(3); r.end();
    }
    passPost.colorAttachments[0].view = ctx.getCurrentTexture().createView();
    r = e.beginRenderPass(passPost); r.setPipeline(pPost); r.setBindGroup(0, bgPost); r.draw(3); r.end();
    if (slot) { e.resolveQuerySet(qs, 0, 2, qResolve, 0); e.copyBufferToBuffer(qResolve, 0, slot.b, 0, 16); }
    submitList[0] = e.finish();
    Q.submit(submitList);
    if (slot) { slot.busy = true; slot.b.mapAsync(GPUMapMode.READ).then(slot.done).catch(() => { slot.busy = false; }); }
  }

  // ---------------------------------------------------------------- input & frame loop
  let menu = true, hud = false, running = true, hadPointerLock = false;
  let kf = 0, kb = 0, kl = 0, kr = 0, ku = 0, kd = 0, ks = 0;
  let al = 0, ar = 0, au = 0, ad = 0; // Arrow key camera look support!
  let dragging = false, dragX = 0, dragY = 0;
  let mdx = 0, mdy = 0, lkx = 0, lky = 0, l2x = 0, l2y = 0;
  let hN = 0, hMax = 0, hMin = 1e9, hPer = 1e9, hLate = 0, hTot = 0;
  let tId = -1, tN = 0, tx0 = 0, ty0 = 0, tx = 0, ty = 0;
  let uiEmitT = 0;
  const inp = { dyaw: 0, dpitch: 0, mf: 0, mr: 0, mu: 0, boost: false };

  function setMenu(m) {
    if (dead) return;
    menu = m;
    const locked = document.pointerLockElement === canvas;
    document.body.className = m ? 'm' : locked ? 'g p' : 'g';
    if (m) {
      releaseKeys();
      if (document.pointerLockElement === canvas) document.exitPointerLock?.();
    }
    callbacks.onMenuChange?.(m, locked);
  }

  function releaseKeys() {
    kf = kb = kl = kr = ku = kd = ks = al = ar = au = ad = 0;
    dragging = false; tId = -1; tN = 0;
  }

  function capture() {
    audio.sound();
    try {
      const p = canvas.requestPointerLock?.({ unadjustedMovement: true });
      if (p && p.catch) p.catch(() => canvas.requestPointerLock?.()?.catch?.(() => 0));
    } catch {
      try { canvas.requestPointerLock?.(); } catch {}
    }
  }

  function jumpToPose(idx) {
    if (idx < 0 || idx >= POSES.length) return;
    sim.placeAtPose(POSES[idx], sim.state.inSub);
    callbacks.onViewpoint?.(idx, VIEWPOINT_NAMES[idx]);
    callbacks.onHud?.(sim.getHudState());
  }

  const onKeyDown = (e) => {
    if (menu && e.code !== 'KeyH' && e.code !== 'KeyM') {
      if (e.code === 'Enter') diveIn();
      return;
    }
    audio.sound();
    switch (e.code) {
      case 'KeyW': kf = 1; break;
      case 'KeyS': kb = 1; break;
      case 'KeyA': kl = 1; break;
      case 'KeyD': kr = 1; break;
      case 'KeyE': case 'Space': ku = 1; e.preventDefault(); break;
      case 'KeyQ': case 'ControlLeft': kd = 1; break;
      case 'ShiftLeft': case 'ShiftRight': ks = 1; break;
      case 'ArrowLeft': al = 1; e.preventDefault(); break;
      case 'ArrowRight': ar = 1; e.preventDefault(); break;
      case 'ArrowUp': au = 1; e.preventDefault(); break;
      case 'ArrowDown': ad = 1; e.preventDefault(); break;
      default:
        if (!e.repeat) {
          if (e.code === 'KeyF') { sim.toggleSubmarine(F[TIME]); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyG') { sim.toggleMiniMode(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyK') { sim.toggleCockpit(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyB') { sim.toggleMegalophobia(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyN') { sim.toggleMidnight(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyV') { sim.cycleView(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyL') { sim.toggleLights(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyC') { sim.callFriends(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyR') { sim.summonSubmarine(); callbacks.onHud?.(sim.getHudState()); }
          else if (e.code === 'KeyH') { hud = !hud; hTot = 0; hPer = 1e9; callbacks.onStats?.(''); }
          else if (e.code === 'KeyM') { callbacks.onMute?.(audio.mute()); }
          else if (e.code === 'Escape') setMenu(true);
          else if (e.code >= 'Digit1' && e.code <= 'Digit6') jumpToPose(e.code.charCodeAt(5) - 49);
        }
    }
  };

  const onKeyUp = (e) => {
    switch (e.code) {
      case 'KeyW': kf = 0; break;
      case 'KeyS': kb = 0; break;
      case 'KeyA': kl = 0; break;
      case 'KeyD': kr = 0; break;
      case 'KeyE': case 'Space': ku = 0; break;
      case 'KeyQ': case 'ControlLeft': kd = 0; break;
      case 'ShiftLeft': case 'ShiftRight': ks = 0; break;
      case 'ArrowLeft': al = 0; break;
      case 'ArrowRight': ar = 0; break;
      case 'ArrowUp': au = 0; break;
      case 'ArrowDown': ad = 0; break;
    }
  };

  const onMouseDown = (e) => {
    if (menu) return;
    if (e.button === 2) {
      e.preventDefault();
      audio.sound();
      sim.reelHarpoon();
      callbacks.onHud?.(sim.getHudState());
      return;
    }
    if (e.button !== 0) return;
    audio.sound();
    if (document.pointerLockElement !== canvas) {
      dragging = true; dragX = e.clientX; dragY = e.clientY;
      capture();
    }
    sim.fireHarpoon(F[TIME]);
    callbacks.onHud?.(sim.getHudState());
  };
  const onContextMenu = (e) => e.preventDefault();
  const onMouseUp = () => { dragging = false; };
  const onMouseMove = (e) => {
    if (document.pointerLockElement === canvas) {
      mdx += e.movementX; mdy += e.movementY;
    } else if (dragging && !menu) {
      mdx += (e.clientX - dragX) * 1.45;
      mdy += (e.clientY - dragY) * 1.45;
      dragX = e.clientX; dragY = e.clientY;
    }
  };
  const onWheel = (e) => {
    if (menu) return;
    e.preventDefault();
    sim.zoom(e.deltaY);
  };
  const onPointerLockChange = () => {
    const locked = document.pointerLockElement === canvas;
    if (locked) {
      hadPointerLock = true;
      dragging = false;
      document.body.className = 'g p';
      callbacks.onMenuChange?.(false, true);
    } else if (hadPointerLock && !menu) {
      hadPointerLock = false;
      setMenu(true);
    }
  };
  const onTouch = (e) => {
    if (menu) return;
    e.preventDefault(); audio.sound(); tN = e.touches.length;
    let f = null, first = false;
    for (let i = 0; i < tN; i++) if (e.touches[i].identifier === tId) f = e.touches[i];
    if (!f) { tId = -1; if (tN) { f = e.touches[0]; tId = f.identifier; first = true; } }
    if (f) {
      const x = rot.matches ? f.clientY : f.clientX, y = rot.matches ? -f.clientX : f.clientY;
      const s = 1100 / min(innerWidth, innerHeight);
      if (first) { tx0 = x; ty0 = y; } else { mdx += (x - tx) * s; mdy += (y - ty) * s; }
      tx = x; ty = y;
    }
  };

  addEventListener('keydown', onKeyDown);
  addEventListener('keyup', onKeyUp);
  addEventListener('mousemove', onMouseMove);
  addEventListener('mouseup', onMouseUp);
  addEventListener('blur', releaseKeys);
  document.addEventListener('pointerlockchange', onPointerLockChange);
  canvas.addEventListener('mousedown', onMouseDown);
  canvas.addEventListener('contextmenu', onContextMenu);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  for (const n of ['touchstart', 'touchmove', 'touchend', 'touchcancel']) {
    canvas.addEventListener(n, onTouch, { passive: false });
  }

  let rafId = 0;
  function frame(now) {
    if (!running || dead) return;
    rafId = requestAnimationFrame(frame);
    const dtr = now - F[LAST]; F[LAST] = now;
    let dt = dtr / 1000; if (dt > 0.1) dt = 0.1; if (dt <= 0) dt = 0.016;

    // Dynamic resolution for smooth 60+ fps (100% original algorithm)
    if (dtr < 1e3 && (dynT += dtr) > 0 && (dynN++, dynT > (menu ? 400 : 1000))) {
      const a = dynT / dynN, g = dynGN ? dynG / dynGN : 0; let k = 1;
      if (g) { if (g > 13.6 || g < 9.8) k = 11.7 / g; }
      else if (a > 17.6) { dynOk = 0; if (++dynBad > 1) { k = 15 / a; dynBad = 0; dynWait = min(dynWait * 2, 60); } }
      else { dynBad = 0; if (a < 12.5) k = 15 / a; else if (++dynOk > dynWait) { k = 1.17; dynOk = 0; } }
      k = clamp(k, 0.5, 1.7);
      const top = min(PIXMAX, DW * DH), mid = max(top / 2, PIXMIN), was = pix + det;
      if (k < 1 ? pix > mid || det <= DETMIN : pix < mid || det >= 1) {
        const end = k < 1 ? (det > DETMIN ? mid : PIXMIN) : det < 1 ? mid : top;
        pix *= k; if (k < 1 ? pix < end : pix > end) pix = end;
      } else { det = clamp(det * sqrt(k), DETMIN, 1); }
      if (was !== pix + det) keep('abyssal', [LV, pix < top ? pix | 0 : '', det]);
      dynN = dynT = dynG = dynGN = 0; resize();
    }

    F[TIME] += dt;

    // Smooth two-stage low-pass mouse + touch + arrow look
    if (tId >= 0) {
      const tr = 4 / min(innerWidth, innerHeight);
      lkx += clamp((tx - tx0) * tr, -1, 1) * 1.5 * dt;
      lky += clamp((ty - ty0) * tr, -1, 1) * dt;
    }
    if (ar - al) lkx += (ar - al) * 1.85 * dt;
    if (ad - au) lky += (ad - au) * 1.35 * dt;

    const kq = 1 - exp(-dt * 30);
    lkx += mdx * 0.0022; lky += mdy * 0.0022; mdx = 0; mdy = 0;
    const ax = lkx * kq, ay = lky * kq; lkx -= ax; lky -= ay; l2x += ax; l2y += ay;
    const dyw = l2x * kq, dpt = l2y * kq; l2x -= dyw; l2y -= dpt;

    inp.dyaw = dyw;
    inp.dpitch = dpt;
    inp.mf = tId >= 0 ? 0.75 : (kf - kb);
    inp.mr = kr - kl;
    inp.mu = ku - kd;
    inp.boost = !!(ks || tN > 1);

    sim.step(dt, F[TIME], inp, menu);
    if (sim.consumeFishDirty()) Q.writeBuffer(ibFish, 0, sim.fishInstances);
    render();

    // Update minimal diegetic HUD ~6 Hz
    uiEmitT += dt;
    if (!menu && uiEmitT > 0.15) {
      uiEmitT = 0;
      callbacks.onHud?.(sim.getHudState());
    }

    if (hud) {
      hN++; if (dtr > hMax) hMax = dtr; if (dtr < hMin) hMin = dtr; if (dtr > hPer * 1.5) { hLate++; hTot++; }
      F[HUDT] += dtr / 1000;
      if (F[HUDT] > 0.5) {
        callbacks.onStats?.(`${(hN / F[HUDT]).toFixed(0)} fps  ·  worst frame ${hMax.toFixed(1)} ms  ·  late frames ${hLate} (total ${hTot})  ·  GPU ${F[GPU].toFixed(2)} ms  ·  ${W}x${H} (${W * 100 / DW | 0}%)`);
        F[HUDT] = 0; hPer = hMin; hN = 0; hMax = 0; hMin = 1e9; hLate = 0;
      }
    }
  }

  function diveIn() {
    if (dead) return;
    audio.sound();
    setMenu(false);
    callbacks.onHud?.(sim.getHudState());
    if (mob) {
      document.documentElement.requestFullscreen?.()?.then(() => screen.orientation?.lock?.('landscape')).catch(() => 0);
    } else {
      capture();
    }
  }

  // Place tiny vintage scuba diver, 5 friend bots, and vintage submarine at Viewpoint 1 & render first frame!
  sim.placeAtPose(POSES[0], false);
  await say('Letting the light in…', 1, 400);
  render();
  await Q.onSubmittedWorkDone();
  const survivedTimer = setTimeout(() => keep('abyssalLoad', ''), 15e3);
  setMenu(true);
  rafId = requestAnimationFrame((t) => { F[LAST] = t; rafId = requestAnimationFrame(frame); });

  return {
    level: LV,
    isMobile: mob,
    diveIn,
    openMenu: () => setMenu(true),
    setDetail: (lv) => { if (lv !== LV) { keep('abyssal', lv); location.reload(); } },
    toggleSubmarine: () => { audio.sound(); const ok = sim.toggleSubmarine(F[TIME]); if (!ok) sim.summonSubmarine(); callbacks.onHud?.(sim.getHudState()); },
    toggleMiniMode: (val) => { audio.sound(); sim.toggleMiniMode(val); callbacks.onHud?.(sim.getHudState()); },
    setViewMode: (mode) => { audio.sound(); sim.setViewMode(mode); callbacks.onHud?.(sim.getHudState()); },
    toggleCockpit: () => { audio.sound(); sim.toggleCockpit(); callbacks.onHud?.(sim.getHudState()); },
    toggleMegalophobia: () => { audio.sound(); sim.toggleMegalophobia(); callbacks.onHud?.(sim.getHudState()); },
    toggleLights: () => { audio.sound(); sim.toggleLights(); callbacks.onHud?.(sim.getHudState()); },
    toggleMidnight: () => { audio.sound(); const on = sim.toggleMidnight(); callbacks.onHud?.(sim.getHudState()); return on; },
    cycleView: () => { audio.sound(); sim.cycleView(); callbacks.onHud?.(sim.getHudState()); },
    callFriends: () => { audio.sound(); sim.callFriends(); callbacks.onHud?.(sim.getHudState()); },
    fireHarpoon: () => { audio.sound(); const ok = sim.fireHarpoon(F[TIME]); callbacks.onHud?.(sim.getHudState()); return ok; },
    reelHarpoon: () => { audio.sound(); const ok = sim.reelHarpoon(); callbacks.onHud?.(sim.getHudState()); return ok; },
    summonSubmarine: () => { audio.sound(); sim.summonSubmarine(); callbacks.onHud?.(sim.getHudState()); },
    jumpToPose: (idx) => { audio.sound(); jumpToPose(idx); },
    toggleMute: () => audio.mute(),
    destroy: () => {
      running = false;
      cancelAnimationFrame(rafId);
      clearTimeout(survivedTimer);
      keep('abyssalLoad', '');
      removeEventListener('pagehide', onPageHide);
      removeEventListener('resize', resize);
      removeEventListener('keydown', onKeyDown);
      removeEventListener('keyup', onKeyUp);
      removeEventListener('mousemove', onMouseMove);
      removeEventListener('mouseup', onMouseUp);
      removeEventListener('blur', releaseKeys);
      document.removeEventListener('pointerlockchange', onPointerLockChange);
      canvas.removeEventListener('contextmenu', onContextMenu);
      audio.destroy();
      for (const t of targets) t.destroy();
      device.destroy();
    },
  };
}

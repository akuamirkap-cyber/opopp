// ============================================================================
// WGSL shaders for Vintage Scuba Divers (Player + 5 Bots), Vintage Submarine,
// and Volumetric Underwater Searchlight / Helmet Lamp Beams
// ============================================================================
import { S_B } from './shaders.js';

const ROT_HELPERS = /*wgsl*/`
fn rotX(v: vec3f, a: f32) -> vec3f { let c = cos(a); let s = sin(a); return vec3f(v.x, v.y * c - v.z * s, v.y * s + v.z * c); }
fn rotY(v: vec3f, a: f32) -> vec3f { let c = cos(a); let s = sin(a); return vec3f(v.x * c + v.z * s, v.y, -v.x * s + v.z * c); }
fn rotZ(v: vec3f, a: f32) -> vec3f { let c = cos(a); let s = sin(a); return vec3f(v.x * c - v.y * s, v.x * s + v.y * c, v.z); }
`;

// ---------------------------------------------------------------- Vintage Mark V Scuba Diver Shader
// Local space: +X right, +Y up (0=sole, 1=helmet crown), -Z forward (face), +Z back (twin scuba tanks)
// Instance layout (20 floats = 80 bytes):
//   d0 (@location(3)): pos.xyz, scale
//   d1 (@location(4)): quat.xyzw
//   d2 (@location(5)): suitCol.rgb, phase
//   d3 (@location(6)): swimBlend, moveAmp, headYaw, headPitch
//   d4 (@location(7)): waveAmt, badgeHue, lampOn, vis
export const W_DIVER = S_B + ROT_HELPERS + /*wgsl*/`
struct DVI {
  @location(0) p: vec3f,
  @location(1) n: vec4f,
  @location(2) k: vec4f,
  @location(3) d0: vec4f,
  @location(4) d1: vec4f,
  @location(5) d2: vec4f,
  @location(6) d3: vec4f,
  @location(7) d4: vec4f,
  @location(8) d5: vec4f, // harpoon recoil, tether status, and reserved effects
};
struct DVO {
  @builtin(position) cp: vec4f,
  @location(0) wp: vec3f,
  @location(1) wn: vec3f,
  @location(2) lp: vec3f,
  @location(3) uv: vec2f,
  @location(4) @interpolate(flat) col: vec4f,
  @location(5) @interpolate(flat) pr: vec4f,
  @location(6) ao: f32,
};

@vertex fn vs(i: DVI) -> DVO {
  var o: DVO;
  if (i.d4.w < .01 || i.d0.w < .001) {
    o.cp = vec4f(0., 0., -2., 1.);
    return o;
  }
  let mat = i32(i.k.x * 255. + .5);
  let part = i32(i.k.y * 255. + .5);
  let ph = i.d2.w;
  let sw = i.d3.x;      // 0 = seabed weighted walk, 1 = open-water swim
  let mv = i.d3.y;      // 0 = idle/hover, 1 = full speed
  let hYaw = i.d3.z;
  let hPit = i.d3.w;
  let wav = i.d4.x;
  let tm = g.cam.w;

  var p = i.p;
  var n = i.n.xyz;

  // Subtle idle breathing / buoyancy sway
  let breath = sin(tm * 2.1 + i.d4.y * 19.) * .006;

  if (part == 1) {
    // Copper Mark V helmet pivots around neck ring (0, 0.61, 0)
    let piv = vec3f(0., .61, 0.);
    var d = p - piv;
    d = rotY(rotX(d, hPit), hYaw);
    n = rotY(rotX(n, hPit), hYaw);
    p = piv + d + vec3f(0., breath, 0.);
  } else if (part == 2 || part == 3) {
    // Left (2) & Right (3) vintage canvas arms + rubber diving mittens
    let sg_ = select(1., -1., part == 2); // -1 left, +1 right
    let piv = vec3f(sg_ * .145, .545, 0.);
    var d = p - piv;
    let cyc = sin(ph + select(0., 3.14159, part == 3));
    // Walk swing vs graceful underwater scuba stroke / swept-back glide
    let walkX = cyc * .48 * mv;
    let walkZ = sg_ * (.14 + .05 * sin(tm * 1.6 + sg_));
    let swimStroke = sin(ph * .5 + select(0., 3.14159, part == 3));
    let swimX = mix(.18 + swimStroke * .22, -.28 + swimStroke * .26, mv);
    let swimZ = sg_ * mix(.38 + .12 * sin(tm * 1.8 + sg_ * 2.), .22 + .08 * abs(swimStroke), mv);
    var rx = mix(walkX, swimX, sw);
    var rz = mix(walkZ, swimZ, sw);
    // Friendly wave on right arm when called or greeting!
    if (part == 3 && wav > .01) {
      rx = mix(rx, 2.35, wav);
      rz = mix(rz, .42 + sin(tm * 11. + i.d4.y * 10.) * .34, wav);
    }
    d = rotZ(rotX(d, rx), rz);
    n = rotZ(rotX(n, rx), rz);
    p = piv + d;
  } else if (part == 4 || part == 5 || part == 6 || part == 7) {
    // Left (4,6) & Right (5,7) legs, heavy brass boots, and vintage strapped flippers
    let isL = (part == 4 || part == 6);
    let isFlip = (part == 6 || part == 7);
    let sg_ = select(1., -1., isL);
    let piv = vec3f(sg_ * .072, .29, 0.);
    var d = p - piv;
    let s = sin(ph + select(0., 3.14159, !isL));
    let c = cos(ph + select(0., 3.14159, !isL));
    // Walk: crisp adorable Little Nightmares weighted-boot steps
    let walkHip = s * .56 * mv;
    // Swim: rhythmic underwater scuba flutter-kick (gentle paddle even while hovering!)
    let swimHip = s * (.16 + .38 * mv);
    let hipA = mix(walkHip, swimHip, sw);
    // Subtle knee bend on back-stroke
    if (d.y < -.12) {
      let kp = vec3f(0., -.12, 0.);
      let kn = max(0., -s) * mix(.38 * mv, .24 * (.3 + .7 * mv), sw);
      d = kp + rotX(d - kp, -kn);
      n = rotX(n, -kn);
    }
    // Vintage rubber flipper lies flat on seabed when walking, extends cleanly backward & flexes when swimming!
    if (isFlip) {
      let fp = vec3f(0., -.262, -.068);
      let flx = -1.05 * sw + c * (.16 + .38 * mv) * sw * i.k.w;
      d = fp + rotX(d - fp, flx);
      n = rotX(n, flx);
    }
    d = rotX(d, hipA);
    n = rotX(n, hipA);
    p = piv + d;
  } else if (part == 8) {
    // Corrugated vintage rubber breathing hoses: follow helmet partially + gentle water sway
    let wt = i.k.w;
    let piv = vec3f(0., .61, 0.);
    var d = p - piv;
    d = rotY(rotX(d, hPit * wt * .6), hYaw * wt * .6);
    p = piv + d;
    p.x += sin(tm * 3.1 + p.y * 14. + i.d4.y * 20.) * .006 * sin(wt * 3.14159);
  } else if (part == 9) {
    // The brass harpoon rifle follows the right forearm and kicks back when its spear fires.
    let piv = vec3f(.145, .545, 0.);
    var d = p - piv;
    let cyc = sin(ph + 3.14159);
    let armX = mix(cyc * .48 * mv, -.28 + sin(ph * .5 + 3.14159) * .24, sw);
    let armZ = mix(.16, .30, sw);
    d = rotZ(rotX(d, armX), armZ);
    d = rotY(rotX(d, clamp(hPit * .35, -.28, .35)), clamp(hYaw * .55, -.38, .38));
    p = piv + d + vec3f(0., -i.d5.x * .018, i.d5.x * .085);
    n = rotY(rotZ(rotX(n, armX), armZ), clamp(hYaw * .55, -.38, .38));
  } else {
    p.y += breath * .5;
  }

  // Subtle vertical hop in weighted seabed walk
  let walkBob = abs(sin(ph)) * .026 * mv * (1. - sw);
  p.y += walkBob;

  let sc = i.d0.w;
  let wp = i.d0.xyz + qrot(i.d1, p * sc);
  let wn = normalize(qrot(i.d1, n));
  o.cp = g.vp * vec4f(wp, 1.);
  o.wp = wp;
  o.wn = wn;
  o.lp = i.p;
  o.uv = i.k.zw;
  o.col = vec4f(i.d2.rgb, f32(mat));
  o.pr = vec4f(i.d4.y, i.d4.z, sc, i.d3.x);
  o.ao = clamp(i.n.w, .15, 1.);
  return o;
}

@fragment fn fs(i: DVO, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  let mat = i32(i.col.w + .5);
  var N = normalize(i.wn) * select(-1., 1., ff);
  let V = normalize(g.cam.xyz - i.wp);
  let L = g.sun.xyz;
  let dist = length(i.wp - g.cam.xyz);
  let z = zone(i.wp);
  let vv = vol(i.wp + vec3f(0., .6, 0.));
  let ca = caus(i.wp, dist);
  let E = sunE(i.wp.y, z) * shadow4(i.wp + N * .2);
  let sp = spotL(i.wp, N);

  // Sample procedural detail texture for weathered canvas weave, hammered copper & patina
  let tx1 = textureSample(tD, sR, i.lp.xy * 2.2 + i.lp.z * 1.7 + i.pr.x * 5.);
  let tx2 = textureSample(tD, sR, i.lp.zy * 6.5 + i.lp.x * 4.1);
  let bm = (vec3f(tx1.r, tx1.g, tx2.r) - .5) * 2.;

  var alb = vec3f(.3);
  var gloss = .2;
  var met = 0.;
  var emi = vec3f(0.);
  var bumpK = .18;

  if (mat == 0) {
    // Weathered vintage heavy canvas dry-suit (mustard-ochre for player, muted vintage hues for 5 bots)
    let weave = .82 + .34 * tx2.b;
    let fold = .76 + .44 * tx1.b;
    let damp = mix(.62, 1., ss(.04, .32, i.lp.y)); // damp/darkened around lower legs
    alb = i.col.rgb * weave * fold * damp;
    // Subtle stitched center/side seam darkening
    let seam = ss(.0, .012, abs(i.lp.x)) * ss(.0, .012, abs(abs(i.lp.x) - .11));
    alb *= .84 + .16 * seam;
    gloss = .16;
    bumpK = .32;
  } else if (mat == 1) {
    // Hammered antique Siebe-Gorman / Mark V copper diving helmet & corselet breastplate
    alb = mix(vec3f(.52, .22, .11), vec3f(.78, .39, .20), tx1.b);
    // Subtle ocean verdigris patina in sheltered crevices
    let pat = ss(.58, .78, tx1.a) * (1. - ss(.5, .9, N.y)) * .42;
    alb = mix(alb, vec3f(.16, .42, .34), pat);
    gloss = .78;
    met = .82;
    bumpK = .14;
  } else if (mat == 2) {
    // Burnished vintage marine brass (porthole bezels, protective grille bars, wing-nuts, buckle, boot toes, tank valves)
    alb = mix(vec3f(.56, .40, .14), vec3f(.88, .69, .28), tx1.b);
    alb = mix(alb, vec3f(.24, .20, .10), ss(.7, .9, tx1.a) * .3);
    gloss = .88;
    met = .88;
    bumpK = .09;
  } else if (mat == 3) {
    // Glowing warm amber helmet porthole faceplate (cozy Little Nightmares lantern warmth!)
    let ndv = sat(dot(N, V));
    let warmA = vec3f(1.55, .95, .36);
    let warmB = vec3f(1.15, .92, .55);
    let tint = mix(warmA, warmB, ss(.4, .9, i.pr.x));
    let core = .45 + .85 * pow(ndv, .75);
    let pulse = .94 + .06 * sin(g.cam.w * 2.3 + i.pr.x * 17.);
    alb = vec3f(.06, .14, .18);
    emi = tint * core * pulse * (1.05 + .35 * i.pr.y);
    gloss = .96;
    met = .1;
    bumpK = .02;
  } else if (mat == 4) {
    // Corrugated dark vintage vulcanized rubber (air hoses, mittens, neck gasket, swim flippers)
    let rib = .72 + .28 * sin(i.uv.y * 95.);
    alb = vec3f(.055, .062, .072) * (.75 + .45 * tx1.b) * rib;
    gloss = .42;
    bumpK = .16;
  } else if (mat == 5) {
    // Aged saddle leather belt, tank harness straps, lead weight pouches & heavy boot soles
    alb = mix(vec3f(.11, .065, .038), vec3f(.24, .14, .075), tx1.b);
    gloss = .32;
    bumpK = .22;
  } else if (mat == 6) {
    // Twin vintage 1940s Aqua-Lung scuba cylinders (weathered brushed brass-ochre / vintage steel)
    let tankCol = mix(vec3f(.62, .50, .22), vec3f(.52, .56, .54), step(.5, fract(i.pr.x * 3.7)));
    alb = tankCol * (.72 + .45 * tx1.b);
    alb = mix(alb, vec3f(.20, .24, .20), ss(.64, .82, tx1.a) * .35);
    gloss = .72;
    met = .68;
    bumpK = .12;
  } else if (mat == 7) {
    // Forehead brass dive-lamp glowing tungsten lens
    alb = vec3f(.2, .2, .18);
    emi = vec3f(2.6, 1.95, 1.05) * (.55 + .85 * i.pr.y);
    gloss = .95;
    bumpK = .01;
  } else {
    // Vintage expedition stripe / scarf accent (unique per diver)
    let h = i.pr.x;
    let ac = .5 + .42 * cos(TAU * (h + vec3f(0., .33, .67)));
    alb = mix(vec3f(.55, .14, .11), ac * .75, ss(.05, .25, h)) * (.75 + .4 * tx2.b);
    gloss = .22;
    bumpK = .25;
  }

  N = normalize(N + bm * bumpK);
  let ndl = sat(dot(N, L));
  let ndv = sat(dot(N, V));
  let sky = amb(i.wp, N, vv.g, z);
  let sdL = side(i.wp, N, sat((vv.r - .5) * 3.5 + .35), z);
  let diffL = (E * (.18 + ndl * (.35 + ca * 1.9)) + sky * 1.25 + sdL * .9 + sp) * i.ao;

  // Diffuse reduced slightly for pure metals, boosted metallic reflection + crisp caustic glints
  var c = alb * diffL * mix(1., .58, met) + emi;

  let H = normalize(V + L);
  let specCol = mix(vec3f(1.), alb * 1.55 + vec3f(.18), met);
  let shin = mix(12., 84., gloss);
  c += specCol * E * (.35 + ca * 1.35) * pow(sat(dot(N, H)), shin) * gloss * (1.2 + met * 1.4);

  // Underwater skylight reflection + soft Little Nightmares rim silhouette so tiny divers ALWAYS read clearly!
  let R = reflect(-V, N);
  let envR = amb(i.wp, R, vv.g, z) * 1.45 + mix(WCOL, PCOL, z) * exp(kd(z) * min(i.wp.y, 0.)) * .55;
  let rim = pow(1. - ndv, 2.8);
  c += mix(vec3f(.65, .88, 1.), specCol, met * .7) * envR * (rim * (.55 + gloss * .8) + met * .22) * i.ao;

  return fin(fog(c, i.wp, z));
}
`;

// ---------------------------------------------------------------- Vintage Expedition Submarine Shader
// Local space: +X right, +Y up, -Z forward (glass nose at z=-2.30), +Z stern (propeller at z=+2.28)
// Instance layout (16 floats = 64 bytes):
//   s0 (@location(3)): pos.xyz, scale
//   s1 (@location(4)): quat.xyzw
//   s2 (@location(5)): propAngle, rudderAngle, planeAngle, hatchOpen
//   s3 (@location(6)): lightsOn, crewMask (0..63), speedNorm, phase
export const W_SUB = S_B + ROT_HELPERS + /*wgsl*/`
struct SVI {
  @location(0) p: vec3f,
  @location(1) n: vec4f,
  @location(2) k: vec4f,
  @location(3) s0: vec4f,
  @location(4) s1: vec4f,
  @location(5) s2: vec4f,
  @location(6) s3: vec4f,
};
struct SVO {
  @builtin(position) cp: vec4f,
  @location(0) wp: vec3f,
  @location(1) wn: vec3f,
  @location(2) lp: vec3f,
  @location(3) uv: vec2f,
  @location(4) @interpolate(flat) info: vec4f,
  @location(5) ao: f32,
};

@vertex fn vs(i: SVI) -> SVO {
  var o: SVO;
  let mat = i32(i.k.x * 255. + .5);
  let part = i32(i.k.y * 255. + .5);
  let mask = u32(i.s3.y + .5);

  // Parts 5..10 are the 6 tiny vintage-diver copper helmets visible inside the cockpit & portholes when aboard!
  if (part >= 5 && part <= 10) {
    let bit = u32(part - 5);
    if (((mask >> bit) & 1u) == 0u) {
      o.cp = vec4f(0., 0., -2., 1.);
      return o;
    }
  }

  var p = i.p;
  var n = i.n.xyz;

  if (part == 1) {
    // 5-blade brass screw propeller spinning around stern shaft (0, -0.04, 2.20)
    let piv = vec3f(0., -.04, 2.20);
    p = piv + rotZ(p - piv, i.s2.x);
    n = rotZ(n, i.s2.x);
  } else if (part == 2) {
    // Vertical stern rudder pivots around (0, 0, 1.92)
    let piv = vec3f(0., 0., 1.92);
    p = piv + rotY(p - piv, i.s2.y);
    n = rotY(n, i.s2.y);
  } else if (part == 3) {
    // Forward & aft horizontal dive planes pivot around their local Z anchor
    let pz = select(1.82, -1.18, p.z < 0.);
    let sg_ = select(-1., 1., p.z < 0.);
    let piv = vec3f(p.x, -.06, pz);
    p = piv + rotX(p - piv, i.s2.z * sg_);
    n = rotX(n, i.s2.z * sg_);
  } else if (part == 4) {
    // Hinged top brass conning-tower hatch lid
    let piv = vec3f(-.28, 1.18, -.10);
    p = piv + rotZ(p - piv, i.s2.w * 1.15);
    n = rotZ(n, i.s2.w * 1.15);
  } else if (part >= 5 && part <= 10) {
    // Cute gentle head bob of tiny crew inside the submarine windows
    let id = f32(part - 5);
    p.y += sin(g.cam.w * 2.2 + id * 1.9) * .014;
    p.x += cos(g.cam.w * 1.5 + id * 2.7) * .010;
  }

  let wp = i.s0.xyz + qrot(i.s1, p * i.s0.w);
  let wn = normalize(qrot(i.s1, n));
  o.cp = g.vp * vec4f(wp, 1.);
  o.wp = wp;
  o.wn = wn;
  o.lp = i.p;
  o.uv = i.k.zw;
  o.info = vec4f(f32(mat), i.s3.x, i.s3.y, i.s3.z);
  o.ao = clamp(i.n.w, .12, 1.);
  return o;
}

@fragment fn fs(i: SVO, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  let mat = i32(i.info.x + .5);
  var N = normalize(i.wn) * select(-1., 1., ff);
  let V = normalize(g.cam.xyz - i.wp);
  let L = g.sun.xyz;
  let dist = length(i.wp - g.cam.xyz);
  let z = zone(i.wp);
  let vv = vol(i.wp + N * .8);
  let ca = caus(i.wp, dist);
  let E = sunE(i.wp.y, z) * shadow4(i.wp + N * .35);
  let sp = spotL(i.wp, N);

  let tx1 = textureSample(tD, sR, i.lp.zy * .55 + i.lp.x * .35);
  let tx2 = textureSample(tD, sR, i.lp.xz * 2.3 + i.lp.y * 1.9);
  let bm = (vec3f(tx1.r, tx1.g, tx2.r) - .5) * 2.;

  var alb = vec3f(.25);
  var gloss = .45;
  var met = .6;
  var emi = vec3f(0.);
  var bumpK = .22;

  if (mat == 10) {
    // Riveted vintage Jules Verne iron-bronze / weathered deep-nautical hull plating
    let an = atan2(i.lp.y, i.lp.x);
    let pZ = fract(i.lp.z * 1.65);
    let pA = fract(an * 1.91); // 12 circumferential plates
    let seam = ss(.0, .028, min(pZ, 1. - pZ)) * ss(.0, .032, min(pA, 1. - pA));
    // Tiny raised rivets running beside each hull seam
    let rZ = fract(i.lp.z * 19.8) - .5;
    let rA = fract(an * 22.9) - .5;
    let nearSeamZ = step(min(abs(pZ - .055), abs(pZ - .945)), .025);
    let nearSeamA = step(min(abs(pA - .065), abs(pA - .935)), .03);
    let riv = max(nearSeamZ * (1. - ss(.15, .32, abs(rA))), nearSeamA * (1. - ss(.15, .32, abs(rZ))));

    // Rich aged deep-teal-bronze upper hull fading to warm weathered dark-ochre-iron lower hull
    let base = mix(vec3f(.13, .17, .18), vec3f(.22, .29, .28), ss(-.45, .55, i.lp.y));
    alb = base * (.68 + .58 * tx1.b) * (.85 + .3 * tx2.b);
    // Warm aged-bronze & rust patina along seams + subtle turquoise sea verdigris
    alb = mix(alb, vec3f(.34, .19, .09), (1. - seam) * .55 + ss(.62, .82, tx1.a) * .32);
    alb = mix(alb, vec3f(.14, .36, .31), ss(.66, .84, tx2.a) * .28);
    alb *= (.76 + .24 * seam) * (1. + .22 * riv);
    gloss = .58 + .15 * riv;
    met = .72;
    bumpK = .28;
  } else if (mat == 11 || mat == 1) {
    // Heavy expedition brass & antique copper (ribs, bezels, conning crown, periscope, hatch, bow guard, crew helmets)
    let isCop = (mat == 1);
    let c0 = select(vec3f(.52, .37, .13), vec3f(.55, .23, .11), isCop);
    let c1 = select(vec3f(.86, .66, .26), vec3f(.80, .41, .21), isCop);
    alb = mix(c0, c1, tx1.b) * (.82 + .32 * tx2.b);
    alb = mix(alb, vec3f(.16, .38, .31), ss(.68, .88, tx1.a) * .30);
    gloss = .85;
    met = .88;
    bumpK = .14;
  } else if (mat == 12) {
    // Classic vintage expedition ochre-mustard painted hull band & conning badge (weathered enamel)
    alb = mix(vec3f(.58, .36, .08), vec3f(.78, .54, .14), tx1.b);
    alb = mix(alb, vec3f(.18, .15, .12), ss(.66, .80, tx2.a) * .42); // paint chips
    gloss = .48;
    met = .25;
    bumpK = .22;
  } else if (mat == 13) {
    // Panoramic forward brass-framed bubble dome glass (warm amber instrument bridge glow + crystal sea reflection)
    let ndv = sat(dot(N, V));
    let crewOn = sat(i.info.w);
    let cabGlow = vec3f(1.38, .86, .32) * (.55 + .55 * crewOn) * (.32 + .68 * pow(ndv, .9));
    // Warm instrument console glow stronger toward lower half of dome
    let dash = ss(.25, -.38, i.lp.y) * .55 + .55;
    alb = vec3f(.05, .14, .18);
    emi = cabGlow * dash * (.96 + .04 * sin(g.cam.w * 1.8));
    gloss = .97;
    met = .08;
    bumpK = .02;
  } else if (mat == 14 || mat == 3) {
    // Round brass porthole cabin windows & tiny crew helmet visors inside!
    let ndv = sat(dot(N, V));
    let hasCrew = ss(0., 6., i.info.w);
    let warm = mix(vec3f(1.25, .76, .26), vec3f(1.85, 1.18, .44), hasCrew);
    alb = vec3f(.06, .12, .15);
    emi = warm * (.5 + .7 * pow(ndv, .65)) * (.95 + .05 * sin(g.cam.w * 2.1 + i.lp.z * 3.));
    gloss = .96;
    met = .08;
    bumpK = .02;
  } else if (mat == 15) {
    // Polished spun marine-brass 5-blade propeller
    alb = mix(vec3f(.64, .46, .16), vec3f(.95, .76, .34), tx2.b);
    gloss = .92;
    met = .92;
    bumpK = .06;
  } else if (mat == 16) {
    // Twin bow searchlight lenses (glow warm tungsten gold when lights ON)
    let on = i.info.y;
    alb = vec3f(.14, .22, .25);
    emi = vec3f(3.6, 2.65, 1.35) * on;
    gloss = .96;
    met = .1;
    bumpK = .01;
  } else if (mat == 17) {
    // Heavy matte dark cast-iron keel, dive planes, rudder & ballast vent grates
    let grate = .75 + .25 * step(.35, fract(i.lp.z * 14.));
    alb = vec3f(.085, .095, .105) * (.7 + .5 * tx1.b) * grate;
    alb = mix(alb, vec3f(.24, .13, .07), ss(.65, .85, tx1.a) * .35);
    gloss = .36;
    met = .65;
    bumpK = .26;
  } else {
    // Top conning-tower vintage navigation beacon lantern (gentle warm amber-coral pulse)
    let pulse = .55 + .45 * sin(g.cam.w * 2.6);
    alb = vec3f(.3, .1, .06);
    emi = vec3f(2.4, .95, .32) * (.65 + .95 * pulse);
    gloss = .92;
    met = .05;
    bumpK = .01;
  }

  N = normalize(N + bm * bumpK);
  let ndl = sat(dot(N, L));
  let ndv = sat(dot(N, V));
  let ao = i.ao * (.45 + .55 * sat((vv.r - .5) * 4. + .5));
  let sky = amb(i.wp, N, vv.g, z);
  let sdL = side(i.wp, N, sat((vv.r - .5) * 3. + .4), z);
  let diffL = (E * (.14 + ndl * (.32 + ca * 2.1)) + sky * 1.15 + sdL * .85 + sp * .35) * ao;

  var c = alb * diffL * mix(1., .56, met) + emi;

  let H = normalize(V + L);
  let specCol = mix(vec3f(1.), alb * 1.5 + vec3f(.16), met);
  c += specCol * E * (.3 + ca * 1.45) * pow(sat(dot(N, H)), mix(14., 88., gloss)) * gloss * (1.15 + met * 1.35);

  let R = reflect(-V, N);
  let envR = amb(i.wp, R, vv.g, z) * 1.4 + side(i.wp, R, .8, z) * .6;
  let fr = pow(1. - ndv, 2.8);
  c += mix(vec3f(.7, .92, 1.), specCol, met * .65) * envR * (fr * (.55 + gloss * .95) + met * .18) * ao;

  return fin(fog(c, i.wp, z));
}
`;

// ---------------------------------------------------------------- Volumetric Underwater Light Cones
// Soft additive volumetric scatter for the submarine's twin searchlights & tiny diver helmet lamps
// Instance layout (12 floats = 48 bytes):
//   b0 (@location(2)): origin.xyz, length
//   b1 (@location(3)): quat.xyzw (maps local -Z along beam direction)
//   b2 (@location(4)): r0 (near radius), r1 (far radius), intensity, tint (0=warm tungsten, 1=soft gold)
export const W_BEAM = S_B + /*wgsl*/`
struct BVI {
  @location(0) p: vec3f,     // x=cos(a), y=sin(a), z=t in [0..1] along cone
  @location(1) n: vec4f,
  @location(2) b0: vec4f,
  @location(3) b1: vec4f,
  @location(4) b2: vec4f,
};
struct BVO {
  @builtin(position) cp: vec4f,
  @location(0) wp: vec3f,
  @location(1) wn: vec3f,
  @location(2) t: f32,
  @location(3) @interpolate(flat) pr: vec2f,
};

@vertex fn vs(i: BVI) -> BVO {
  var o: BVO;
  if (i.b2.z < .002) { o.cp = vec4f(0., 0., -2., 1.); return o; }
  let t = i.p.z;
  let len = i.b0.w;
  let r = mix(i.b2.x, i.b2.y, t);
  let lp = vec3f(i.p.x * r, i.p.y * r, -t * len);
  let slope = (i.b2.y - i.b2.x) / max(len, .1);
  let ln = normalize(vec3f(i.p.x, i.p.y, slope));
  let wp = i.b0.xyz + qrot(i.b1, lp);
  o.cp = g.vp * vec4f(wp, 1.);
  o.wp = wp;
  o.wn = normalize(qrot(i.b1, ln));
  o.t = t;
  o.pr = i.b2.zw;
  return o;
}

@fragment fn fs(i: BVO) -> @location(0) vec4f {
  let v = g.cam.xyz - i.wp;
  let d = length(v);
  let V = v / max(d, 1e-4);
  // Smooth grazing fade eliminates hard silhouette edges on volumetric cones
  let edge = pow(abs(dot(normalize(i.wn), V)), 1.85);
  let axial = ss(0., .06, i.t) * pow(1. - sat(i.t), 2.1);
  // Subtle swirling underwater plankton/caustic modulation inside the beam
  let wv = .78 + .35 * textureSampleLevel(tW, sR, i.wp.xz * .09 + vec2f(g.cam.w * .03, i.wp.y * .05), 2.).r;
  let camFade = ss(.35, 1.4, d);
  let col = mix(vec3f(1.25, .94, .52), vec3f(.95, .86, .58), i.pr.y);
  let c = col * i.pr.x * edge * axial * wv * camFade * exp(-SIG * d) * .16;
  return vec4f(min(max(c, vec3f(0.)), vec3f(4.)), 0.);
}
`;

// ---------------------------------------------------------------- 10x Giant Colossus Manta Ray Shader
// Matches 100% Noniv/abyssal-garden Manta aesthetics at monumental 10x scale (~76 m wingspan!),
// driven by CPU spline/flyby so it glides majestically right across your submarine cockpit bow!
// Instance layout (8 floats = 32 bytes, ibAnim):
//   a (@location(2)): worldPos.xyz, scale (38.0 = 10x normal 3.8 manta!)
//   b (@location(3)): yaw, pitch, roll, flapPhase
export const W_COLOSSUS = S_B + /*wgsl*/`
struct MVI { @location(0) p: vec3f, @location(1) n: vec4f, @location(2) a: vec4f, @location(3) b: vec4f };
struct MVO {
  @builtin(position) cp: vec4f,
  @location(0) wp: vec3f,
  @location(1) n: vec3f,
  @location(2) op: vec3f,
  @location(3) @interpolate(flat) sc: f32,
};

@vertex fn vs(i: MVI) -> MVO {
  var o: MVO;
  let sz = i.a.w;
  let yaw = i.b.x; let pit = i.b.y; let bank = i.b.z; let fph = i.b.w;
  let cp = cos(pit); let sp = sin(pit); let sy = sin(yaw); let cy = cos(yaw);
  // Forward T, Right S, Up basis
  let T = normalize(vec3f(cp * sy, sp, -cp * cy));
  var S = normalize(cross(vec3f(0., 1., 0.), T));
  var Up = cross(T, S);
  let cb = cos(bank); let sb = sin(bank);
  let S2 = S * cb + Up * sb; Up = Up * cb - S * sb; S = S2;

  // Slow, heavy, hypnotic mega-leviathan wingbeat
  let u = i.n.w; let au = abs(u);
  let fp = fph - au * 1.45;
  let amp = .34 * pow(au, 1.55);
  var l = i.p;
  l.y += amp * sin(fp) - .09 * sin(fph);
  let tail = ss(-.5, -1.9, l.z) * step(au, .001);
  l.x += tail * sin(fph * .65 + l.z * 2.2) * .11;
  let sl = (.527 * pow(au, .55) * sin(fp) - .493 * pow(au, 1.55) * cos(fp)) * sign(u);
  let ln = normalize(vec3f(i.n.x - sl * i.n.y, i.n.y + sl * i.n.x, i.n.z));

  let w = i.a.xyz + (S * l.x + Up * l.y + T * l.z) * sz;
  o.cp = g.vp * vec4f(w, 1.);
  o.wp = w;
  o.n = S * ln.x + Up * ln.y + T * ln.z;
  o.op = i.p;
  o.sc = sz;
  return o;
}

@fragment fn fs(i: MVO) -> @location(0) vec4f {
  let dist = length(i.wp - g.cam.xyz);
  let ca = caus(i.wp, min(dist, 65.));
  let tx = textureSample(tD, sR, i.op.xz * 1.35 + .42);
  let txF = textureSample(tD, sR, i.op.xz * 5.8 + .17);
  let n = normalize(i.n + (vec3f(tx.r, 0., tx.g) - vec3f(.5, 0., .5)) * .55 + (vec3f(txF.r, 0., txF.g) - vec3f(.5, 0., .5)) * .28);
  let L = g.sun.xyz;
  let V = normalize(g.cam.xyz - i.wp);
  let z = zone(i.wp);
  let vv = vol(clamp(i.wp, vec3f(-185., -54., -185.), vec3f(185., -1., 185.)));
  let top = ss(-.18, .22, normalize(i.n).y);
  let au = abs(i.op.x);

  // Monumental gill slits on belly (awe-inspiring when the 76m manta passes right above your tiny submarine!)
  let gill = ss(.26, .0, abs(au - .135) * 7.5) * ss(.03, .11, i.op.z) * ss(.35, .26, i.op.z) * ss(.15, .82, sin(i.op.z * 115.));
  var belly = vec3f(.18, .24, .29) * (.62 + .58 * tx.b) * (.82 + .32 * txF.b) * (1. - .78 * gill);
  belly = mix(belly, vec3f(.045, .075, .11), sat(ss(.46, .92, au + tx.a * .32) + ss(-.1, -.42, i.op.z + tx.b * .2) * .72));

  // Ancient deep-ocean chevron patterns + weathered barnacle/reef mottling across the 76m dorsal wings
  var back = vec3f(.035, .06, .095) + vec3f(.11, .18, .23) * ss(.48, .74, tx.a);
  back = mix(back, vec3f(.42, .54, .60), ss(.26, .0, abs(au - .26) * 3.4 + abs(i.op.z - .12) * 4.8) * .85);
  back = mix(back, vec3f(.28, .38, .44), ss(.18, .0, abs(au - .52) * 4.2 + abs(i.op.z + .04) * 5.5) * .55);
  let alb = mix(belly, back, top);

  let E = sunE(i.wp.y, z) * mix(.45, 1., shadow4(i.wp + n * .8));
  let ndv = sat(dot(n, V));
  let ir = .5 + .5 * cos(TAU * (vec3f(0., .33, .67) + ndv * 1.15 + tx.a * 1.5 + .55));
  let fillN = vec3f(n.x, abs(n.y) * .55 + .25, n.z);
  let sp = spotL(i.wp, n);

  var c = alb * (E * sat(dot(n, L)) * (.32 + ca * 1.15) + amb(i.wp, fillN, max(vv.g, .55), z) * 1.25 + side(i.wp, n, 1., z) * .9 + sp * 1.35);
  c += ir * vec3f(.32, .22, .62) * (.08 + .24 * tx.b) * (.45 + E.g * .24 * ca.g) * (1. - top * .25);
  c += E * pow(sat(dot(n, normalize(V + L))), 32.) * .55 * (.3 + ca);

  // Subtle ancient abyssal constellation bioluminescence along dorsal ridges & ventral gill lines
  let spots = ss(.76, .88, txF.a) * ss(.42, .72, tx.b) * ss(.08, .78, au) * ss(.96, .75, au);
  let rimGlow = pow(1. - ndv, 3.0);
  let sky = amb(i.wp, vec3f(0., 1., 0.), max(vv.g, .6), z);
  c += mix(vec3f(.18, .85, .95), vec3f(.55, .95, .82), tx.a) * spots * (.16 + .10 * sin(g.cam.w * 1.4 + au * 8.));
  c += alb * sky * ca * .52 * (1. - top) + sky * rimGlow * .55;

  // Slightly clearer megalophobia visibility out to 190m so its entire titanic silhouette looms through the deep!
  let v = i.wp - g.cam.xyz; let d = length(v); let rd = v / max(d, 1e-4);
  let att = exp(-sg(z) * d * .82) * ss(235., 185., d);
  let fg = c * att + fogIn(g.cam.xyz, rd, d, z, g.sun.xyz) * (.58 + .42 * vol(g.cam.xyz + rd * min(d, 150.)).g) * (1. - att * .12);
  return fin(fg);
}
`;

// ---------------------------------------------------------------- 3D Vintage Submarine Cockpit Interior Shader
// Instance layout (20 floats = 80 bytes, ibDiverL):
//   c0 (@location(3)): eyeWorld.xyz, scale (1 when in cockpit mode, 0 otherwise)
//   c1 (@location(4)): subQuat.xyzw
//   c2 (@location(5)): wheelAngle, throttleAngle, diveLeverAngle, lanternSway
//   c3 (@location(6)): depthNorm (0..1), speedNorm (0..1), subYaw, lightsOn
//   c4 (@location(7)): crewCount (1..6), mantaSonarX (-1..1), mantaSonarY (-1..1), coPilotVis
export const W_COCKPIT = S_B + ROT_HELPERS + /*wgsl*/`
struct CVI {
  @location(0) p: vec3f,
  @location(1) n: vec4f,
  @location(2) k: vec4f,
  @location(3) c0: vec4f,
  @location(4) c1: vec4f,
  @location(5) c2: vec4f,
  @location(6) c3: vec4f,
  @location(7) c4: vec4f,
};
struct CVO {
  @builtin(position) cp: vec4f,
  @location(0) wp: vec3f,
  @location(1) wn: vec3f,
  @location(2) lp: vec3f,
  @location(3) uv: vec2f,
  @location(4) @interpolate(flat) m0: vec4f, // mat, depthNorm, speedNorm, subYaw
  @location(5) @interpolate(flat) m1: vec4f, // crewCount, mantaX, mantaY, lightsOn
  @location(6) ao: f32,
};

fn dialSeg(q: vec2f, ang: f32, r0: f32, r1: f32, w: f32) -> f32 {
  let d = vec2f(sin(ang), cos(ang));
  let pr = clamp(dot(q, d), r0, r1);
  return 1. - ss(w * .5, w, length(q - d * pr));
}

@vertex fn vs(i: CVI) -> CVO {
  var o: CVO;
  let mat = i32(i.k.x * 255. + .5);
  let part = i32(i.k.y * 255. + .5);
  if (i.c0.w < .0001 || (part == 5 && i.c4.w < .5)) {
    o.cp = vec4f(0., 0., -2., 1.);
    return o;
  }

  var p = i.p;
  var n = i.n.xyz;
  let tm = g.cam.w;

  if (part == 1) {
    // 8-spoke brass & mahogany ship's helm wheel
    let piv = vec3f(0., -.325, -.345);
    p = piv + rotZ(p - piv, i.c2.x);
    n = rotZ(n, i.c2.x);
  } else if (part == 2) {
    // Chadburn brass engine telegraph lever
    let piv = vec3f(-.285, -.235, -.385);
    p = piv + rotX(p - piv, -i.c2.y);
    n = rotX(n, -i.c2.y);
  } else if (part == 3) {
    // Copper ballast dive-plane lever
    let piv = vec3f(.285, -.235, -.385);
    p = piv + rotX(p - piv, -i.c2.z);
    n = rotX(n, -i.c2.z);
  } else if (part == 4) {
    // Twin hanging warm tungsten brass cabin lanterns (sway gently with submarine roll)
    let sx = select(1., -1., p.x < 0.);
    let piv = vec3f(sx * .43, .30, -.42);
    let sw = i.c2.w + sin(tm * 2.1 + sx) * .03;
    p = piv + rotZ(p - piv, sw);
    n = rotZ(n, sw);
  } else if (part == 5) {
    // Cute copper-helmeted companion friend co-pilot glancing toward the 10x Manta Ray & bobbing!
    let piv = vec3f(.40, -.23, -.17);
    let lookY = clamp(-i.c4.y * .45, -.38, .38) + sin(tm * .9) * .12;
    let lookX = sin(tm * 1.4) * .06;
    p = piv + rotY(rotX(p - piv, lookX), lookY) + vec3f(0., sin(tm * 2.2) * .005, 0.);
    n = rotY(rotX(n, lookX), lookY);
  }

  let wp = i.c0.xyz + qrot(i.c1, p * i.c0.w);
  let wn = normalize(qrot(i.c1, n));
  o.cp = g.vp * vec4f(wp, 1.);
  o.wp = wp;
  o.wn = wn;
  o.lp = p;
  o.uv = i.k.zw;
  o.m0 = vec4f(f32(mat), i.c3.x, i.c3.y, i.c3.z);
  o.m1 = vec4f(i.c4.x, i.c4.y, i.c4.z, i.c3.w);
  o.ao = clamp(i.n.w, .2, 1.);
  return o;
}

@fragment fn fs(i: CVO, @builtin(front_facing) ff: bool) -> @location(0) vec4f {
  let mat = i32(i.m0.x + .5);
  var N = normalize(i.wn) * select(-1., 1., ff);
  let V = normalize(g.cam.xyz - i.wp);
  let L = g.sun.xyz;
  let tm = g.cam.w;
  let z = zone(i.wp);

  // Sample procedural surface detail in uniform control flow
  let tx1 = textureSample(tD, sR, i.lp.xy * 3.5 + i.lp.z * 2.8);
  let tx2 = textureSample(tD, sR, vec2f(i.lp.x * 2.2 + i.lp.z * 1.4, i.lp.y * 14.5));
  let ca = caus(i.wp, 4.);

  if (mat == 32) {
    // Laminated, thick underwater dome glass: animated water normals, caustics,
    // cool blue-green absorption, fine scratches and a strong grazing-angle reflection.
    let t = g.cam.w;
    let flow0 = textureSampleLevel(tW, sR, cuv(i.wp) * .16 + vec2f(t * .008, -t * .006), 0.);
    let flow1 = textureSampleLevel(tW, sR, cuv(i.wp).yx * .31 + vec2f(-t * .011, t * .007), 1.);
    // W_WATER stores signed wave slopes in B/A (centered on 0, not normalized colors).
    let glassN = normalize(N + vec3f(flow0.b, flow0.a, 0.) * .62);
    let ndv = clamp(abs(dot(glassN, V)), 0., 1.);
    let fresnel = pow(1. - ndv, 3.2);
    let caustic = textureSampleLevel(tW, sR, cuv(i.wp) * .24 + vec2f(t * .013, -t * .009), 0.).r;
    let film = .5 + .5 * cos((1. - ndv) * 21. + flow1.r * 5. + t * .26);
    let scratch = smoothstep(.78, .96, tx2.a) * .08;
    let reflected = pow(max(dot(reflect(-V, glassN), normalize(vec3f(-.28, .62, .73))), 0.), 28.);
    let shimmer = pow(max(dot(reflect(-V, glassN), normalize(vec3f(.62, .18, .76))), 0.), 46.);

    let waterTint = mix(vec3f(.07, .24, .31), vec3f(.19, .53, .61), .38 + caustic * .26);
    let thinFilm = mix(vec3f(.14, .36, .46), vec3f(.34, .68, .72), film) * (fresnel * .42);
    let glint = vec3f(.62, .86, .92) * (reflected * .22 + shimmer * .12 + scratch);
    let color = waterTint * (.48 + caustic * .12) + thinFilm + glint;
    let alpha = clamp(.075 + fresnel * .29 + caustic * .025 + scratch, .065, .34);
    // Premultiplied alpha is composited over the already-rendered abyssal scene.
    return vec4f(color * alpha, alpha);
  }

  // Live backlit bridge instruments (crisp self-illuminated dials + subtle glass reflection)
  let q = i.uv * 2. - 1.;
  let r = length(q);
  let an = atan2(q.x, q.y); // 0 = top (+Y), clockwise positive

  if (mat == 25) {
    // Center Live Phosphor Sonar CRT Screen (tracks the 10x Giant Manta Ray + 5 companion signals!)
    var sc = mix(vec3f(.012, .055, .048), vec3f(.004, .022, .020), r * r);
    // Concentric range rings + crosshairs
    let rings = max(max(1. - ss(.012, .026, abs(r - .32)), 1. - ss(.012, .026, abs(r - .64))), 1. - ss(.015, .032, abs(r - .92)));
    let cross_ = (1. - ss(.008, .020, abs(q.x))) + (1. - ss(.008, .020, abs(q.y)));
    sc += vec3f(.06, .36, .28) * sat(rings + cross_ * .55);
    // Rotating sonar sweep beam + phosphor afterglow trail
    let swA = fract(tm * .42) * TAU;
    let dA = fract((swA - (an + 3.1415926)) / TAU);
    let trail = exp(-dA * 5.2) * step(r, .95);
    let line = (1. - ss(.0, .035, dA)) * step(r, .95);
    sc += vec3f(.12, .72, .52) * trail * .55 + vec3f(.55, 1.45, 1.05) * line;
    // Center submarine triangle marker
    sc += vec3f(1.5, 1.15, .45) * (1. - ss(.035, .065, r));
    // HUGE Pulsing Gold-Cyan Blip for the 10x Giant Leviathan Manta Ray!
    let mp = vec2f(i.m1.y, i.m1.z);
    let md = length(q - mp);
    let pulse = .65 + .35 * sin(tm * 5.5);
    let mBlip = (1. - ss(.045, .13, md)) * pulse;
    let mRing = (1. - ss(.012, .032, abs(md - fract(tm * .8) * .24))) * (1. - fract(tm * .8));
    sc += vec3f(2.2, 1.55, .48) * mBlip + vec3f(.35, 1.45, 1.25) * mRing * step(length(mp), .93);
    // Curved CRT glass reflection & bezel shadow
    sc *= ss(1.02, .86, r);
    sc += vec3f(.22, .45, .52) * pow(1. - sat(dot(N, V)), 2.5) * .45;
    return fin(sc);
  }
  if (mat == 26 || mat == 27) {
    // Antique Warm-Ivory Backlit Brass Manometers: 26 = Depth (0..55m), 27 = Speed (0..45 kt)
    let val = select(i.m0.z, i.m0.y, mat == 26);
    var dc = mix(vec3f(1.18, .92, .54), vec3f(.62, .40, .16), pow(r, 1.6));
    dc *= .90 + .14 * tx1.b;
    // Scale ticks around 250-degree sweep (-2.2 .. +2.2 rad)
    let inArc = step(abs(an), 2.28);
    let maj = (1. - ss(.05, .11, abs(sin(an * 5.)))) * step(.70, r) * step(r, .89) * inArc;
    let mnr = (1. - ss(.08, .18, abs(sin(an * 15.)))) * step(.78, r) * step(r, .89) * inArc;
    let rimC = 1. - ss(.015, .035, abs(r - .89));
    // Crimson danger/boost arc on high values (an > 1.15)
    let redZone = step(1.15, an) * step(an, 2.25) * step(.74, r) * step(r, .88);
    dc = mix(dc, vec3f(.95, .18, .08), redZone * .75);
    dc = mix(dc, vec3f(.08, .05, .03), sat(maj + mnr * .6 + rimC * .8));
    // Live rotating indicator needle!
    let nAng = mix(-2.18, 2.18, sat(val));
    let ndl = dialSeg(q, nAng, -.14, .78, .055);
    let cap = 1. - ss(.08, .12, r);
    dc = mix(dc, select(vec3f(.12, .06, .03), vec3f(.72, .12, .06), mat == 27), ndl);
    dc = mix(dc, vec3f(.85, .62, .22), cap);
    dc *= ss(1.01, .88, r);
    return fin(dc);
  }
  if (mat == 28) {
    // Gimbaled Brass Nautical Binnacle Compass (live rotating rose with submarine yaw!)
    var cc = mix(vec3f(1.08, .84, .48), vec3f(.52, .34, .14), r * r);
    let ca_ = an + i.m0.w;
    let ticks = (1. - ss(.06, .14, abs(sin(ca_ * 8.)))) * step(.72, r) * step(r, .90);
    cc = mix(cc, vec3f(.1, .06, .03), ticks);
    // Red North needle + dark South needle + brass center pivot
    let north = dialSeg(q, -i.m0.w, 0., .76, .085);
    let south = dialSeg(q, 3.1415926 - i.m0.w, 0., .68, .075);
    let ew = dialSeg(q, 1.5708 - i.m0.w, -.52, .52, .055);
    cc = mix(cc, vec3f(.14, .09, .05), sat(south + ew * .7));
    cc = mix(cc, vec3f(1.05, .16, .08), north);
    cc = mix(cc, vec3f(.92, .70, .26), 1. - ss(.09, .14, r));
    return fin(cc * ss(1.02, .88, r));
  }

  // Cabin structural & trim materials
  var alb = vec3f(.2);
  var gloss = .5;
  var met = .5;
  var emi = vec3f(0.);
  var bumpK = .12;

  if (mat == 20) {
    // Riveted antique dark bronze interior pressure bulkhead
    alb = mix(vec3f(.09, .11, .12), vec3f(.19, .16, .12), tx1.b);
    gloss = .48; met = .68; bumpK = .22;
  } else if (mat == 21) {
    // Burnished Jules Verne marine brass (window arches, rivets, bezels, wheel spokes, telegraph)
    alb = mix(vec3f(.54, .38, .13), vec3f(.92, .71, .28), tx1.b);
    gloss = .88; met = .90; bumpK = .08;
  } else if (mat == 22) {
    // Rich varnished antique mahogany helm rim & instrument console
    let grain = .65 + .55 * tx2.b;
    alb = mix(vec3f(.16, .055, .022), vec3f(.36, .13, .048), grain);
    gloss = .72; met = .06; bumpK = .14;
  } else if (mat == 23) {
    // Hammered antique copper pressure pipes, dive lever grip & co-pilot Mark V helmet
    alb = mix(vec3f(.52, .21, .10), vec3f(.82, .42, .21), tx1.b);
    gloss = .82; met = .86; bumpK = .10;
  } else if (mat == 24) {
    // Vintage crimson-enamel emergency ballast valve wheel & telegraph handle
    alb = mix(vec3f(.48, .07, .05), vec3f(.78, .14, .09), tx1.b);
    gloss = .66; met = .18; bumpK = .10;
  } else if (mat == 29) {
    // Warm tungsten cabin lanterns (v≈0.5), 6 crew bulbs (v≈0.2), searchlight jewel (v≈0.85)
    alb = vec3f(.25, .18, .08);
    if (i.uv.y < .35) {
      let slot = floor(i.uv.x * 6.) + 1.;
      let on = step(slot, i.m1.x + .1);
      emi = mix(vec3f(.08, .04, .01), vec3f(2.2, 1.35, .42), on);
    } else if (i.uv.y > .70) {
      emi = mix(vec3f(.05, .08, .06), vec3f(.45, 2.2, 1.35), i.m1.w);
    } else {
      let flk = .96 + .04 * sin(tm * 3.7 + i.lp.x * 5.);
      emi = vec3f(2.5, 1.68, .72) * flk;
    }
    gloss = .95; met = .05; bumpK = .01;
  } else {
    // Co-pilot friend's warm amber glowing Mark V helmet visor!
    let ndv = sat(dot(N, V));
    alb = vec3f(.08, .12, .14);
    emi = vec3f(1.65, 1.02, .38) * (.55 + .65 * ndv);
    gloss = .96; met = .1; bumpK = .02;
  }

  let bm = (vec3f(tx1.r, tx1.g, tx2.r) - .5) * 2.;
  N = normalize(N + bm * bumpK);

  // Dual lighting: (1) Real ocean sunlight + shimmering caustics streaming in through the glass dome!
  //                (2) Cozy warm tungsten cabin lanterns + soft emerald CRT sonar bounce on console!
  let oceanE = sunE(i.wp.y, z) * (.35 + .65 * shadow1(i.wp + L * .6));
  let seaAmb = (mix(WCOL, PCOL, z) * exp(kd(z) * min(i.wp.y, 0.)) * .75 + vec3f(.04, .11, .16)) * mix(.035, 1., g.env.x);
  let sunLit = oceanE * sat(dot(N, L)) * (.35 + ca * 1.45);

  // Warm cabin light from overhead brass lanterns + instrument glow
  let lampDir = normalize(vec3f(0., .32, -.35) - i.lp);
  let warmLit = vec3f(1.05, .68, .32) * (.32 + .68 * sat(dot(N, lampDir))) * (.75 + .25 * i.m1.w);
  let sonarGlow = vec3f(.06, .34, .25) * ss(.34, .04, length(i.lp - vec3f(0., -.22, -.42)));

  let totL = (sunLit + seaAmb * .85 + warmLit + sonarGlow) * i.ao;
  var c = alb * totL * mix(1., .62, met) + emi;

  // Crisp specular highlights on brass ribs, mahogany wood & copper from both sunlight caustics & warm lanterns!
  let specCol = mix(vec3f(1.), alb * 1.55 + vec3f(.18), met);
  let shin = mix(16., 86., gloss);
  let Hs = normalize(V + L);
  let Hl = normalize(V + lampDir);
  c += specCol * oceanE * (.35 + ca * 1.2) * pow(sat(dot(N, Hs)), shin) * gloss * 1.1;
  c += specCol * vec3f(1.25, .85, .42) * pow(sat(dot(N, Hl)), shin * .7) * gloss * .85;
  c += mix(seaAmb, specCol * seaAmb, met) * pow(1. - sat(dot(N, V)), 2.6) * (.45 + gloss * .55) * i.ao;

  return fin(c);
}
`;

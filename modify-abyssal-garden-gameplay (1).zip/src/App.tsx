import { useEffect, useRef, useState } from 'react';
import { startAbyssalGarden, type EngineHandle, type HudState } from './game/engine';

let bootLock = false;

const CAM_NAMES = ['Standar', 'Megalophobia', 'POV / Kokpit'];

export function App() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const barRef = useRef<HTMLElement | null>(null);
  const diveBtnRef = useRef<HTMLButtonElement | null>(null);
  const engineRef = useRef<EngineHandle | null>(null);
  const toastTimerRef = useRef<number>(0);
  const lastSeqRef = useRef<number>(0);

  const [statusText, setStatusText] = useState('Diving…');
  const [browserHint, setBrowserHint] = useState(false);
  const [hasDived, setHasDived] = useState(false);
  const [detailLv, setDetailLv] = useState<number>(0);
  const [statsText, setStatsText] = useState('');
  const [toast, setToast] = useState('');
  const [hud, setHud] = useState<HudState>({
    inSub: false,
    miniMode: false,
    midnightMode: false,
    nearSub: true,
    subDist: 3.1,
    depth: 42,
    speed: 0,
    lightsOn: true,
    viewMode: 0,
    botsAboard: 0,
    summoning: false,
    mantaFlyby: false,
    mantaDist: 45,
    fishCount: 0,
    fishInventory: [0, 0, 0, 0],
    harpoonPhase: 'ready',
    harpoonTargetVisible: false,
    harpoonTargetX: 0.5,
    harpoonTargetY: 0.5,
    harpoonRecoil: 0,
    toastEvent: '',
    toastSeq: 0,
  });

  const showToast = (msg: string, ms = 2800) => {
    setToast(msg);
    window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => setToast(''), ms);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || bootLock) return;
    bootLock = true;
    document.body.className = 'l';

    startAbyssalGarden(canvas, barRef.current, {
      onProgress: (msg) => setStatusText(msg),
      onBrowserHint: (show) => setBrowserHint(show),
      onError: (msg) => setStatusText(msg),
      onMenuChange: (inMenu) => {
        if (inMenu) {
          window.setTimeout(() => diveBtnRef.current?.focus(), 100);
        } else {
          setHasDived(true);
          (document.activeElement as HTMLElement | null)?.blur?.();
        }
      },
      onHud: (next) => {
        if (next.toastSeq !== lastSeqRef.current && next.toastEvent) {
          lastSeqRef.current = next.toastSeq;
          showToast(next.toastEvent, next.mantaFlyby ? 3800 : 2400);
        }
        setHud(next);
      },
      onStats: (s) => setStatsText(s),
      onViewpoint: (idx, name) => showToast(`${idx + 1} · ${name}`),
      onMute: (m) => showToast(m ? 'Suara Mati' : 'Suara Aktif', 1400),
    })
      .then((handle) => {
        engineRef.current = handle;
        setDetailLv(handle.level);
      })
      .catch((e: Error & { userFacing?: boolean }) => {
        console.error(e);
        document.body.className = 'l e';
        setStatusText((e.userFacing ? '' : 'Gagal memulai: ') + e.message);
      });

    return () => {
      window.clearTimeout(toastTimerRef.current);
    };
  }, []);

  const handleDive = () => {
    setHasDived(true);
    engineRef.current?.diveIn();
  };

  const detailLabels = ['Low', 'Medium', 'High'];
  const camBadge = hud.viewMode === 1
    ? 'Megalophobia'
    : hud.viewMode === 2
      ? (hud.inSub ? 'Kokpit 3D' : 'POV Helm')
      : '3rd Person';

  return (
    <>
      <canvas id="c" ref={canvasRef} />

      {/* Minimal Diegetic In-Game HUD */}
      <div className="hud-layer">
        {/* Camera-specific subtle optical framing */}
        {hud.viewMode === 1 && <div className="mega-frame" />}
        {hud.viewMode === 2 && hud.inSub && <div className="fp-cockpit-glass" />}
        {hud.viewMode === 2 && !hud.inSub && (
          <div className="fp-helmet">
            <div className="helmet-glass-film" />
            <svg className="fp-helmet-svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMidYMid meet">
              <defs>
                <radialGradient id="helmetPortholeMask" cx="500" cy="500" r="500" gradientUnits="userSpaceOnUse">
                  <stop offset="0%" stopColor="#000" stopOpacity="0" />
                  <stop offset="80%" stopColor="#000" stopOpacity="0" />
                  <stop offset="88%" stopColor="#241306" stopOpacity="0.18" />
                  <stop offset="95%" stopColor="#160b04" stopOpacity="0.78" />
                  <stop offset="100%" stopColor="#050302" stopOpacity="0.98" />
                </radialGradient>
                <linearGradient id="helmetBrassRim" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#f0c574" stopOpacity="0.68" />
                  <stop offset="48%" stopColor="#744417" stopOpacity="0.65" />
                  <stop offset="100%" stopColor="#d49a42" stopOpacity="0.75" />
                </linearGradient>
              </defs>
              <rect width="1000" height="1000" fill="url(#helmetPortholeMask)" />
              {/* Round, aspect-correct Mark V porthole bezel; never stretch the diver POV into an oval. */}
              <circle cx="500" cy="500" r="476" fill="none" stroke="#281507" strokeWidth="34" opacity="0.9" />
              <circle cx="500" cy="500" r="462" fill="none" stroke="url(#helmetBrassRim)" strokeWidth="20" />
              <circle cx="500" cy="500" r="448" fill="none" stroke="#d9faff" strokeWidth="5" opacity="0.34" />
              {[0, 15, 30, 45, 60, 75, 90, 105, 120, 135, 150, 165, 180, 195, 210, 225, 240, 255, 270, 285, 300, 315, 330, 345].map((deg) => {
                const rad = (deg * Math.PI) / 180;
                const bx = 500 + Math.cos(rad) * 462;
                const by = 500 + Math.sin(rad) * 462;
                return <circle key={deg} cx={bx} cy={by} r="6.2" fill="#e0ab52" fillOpacity="0.68" stroke="#2a1405" strokeWidth="2.5" />;
              })}
            </svg>
          </div>
        )}

        {toast && <div className="scenic-toast">{toast}</div>}

        {/* Boarding prompt right beside the crew's parked vintage submarine */}
        {hud.nearSub && !hud.inSub && (
          <button
            type="button"
            className="board-prompt"
            onClick={() => engineRef.current?.toggleSubmarine()}
          >
            <i className="kbd kbd-brass">F</i>
            <span>Naik Kapal Selam{hud.miniMode ? ' Mini' : ''}</span>
            <span style={{ opacity: 0.68 }}>· {hud.subDist.toFixed(1)}m</span>
          </button>
        )}

        {/* Compact bottom-left status capsule */}
        {hud.inSub ? (
          <div className="crew-pill sub-mode">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kapal Selam · Kru {1 + hud.botsAboard}/6</span>
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m · {(hud.speed * 1.94).toFixed(0)} kt</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint"><i className="kbd kbd-cyan">K</i> Kokpit</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalo</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">C</i> Manta 10x</span>
            <span className="pill-hint"><i className="kbd kbd-brass">F</i> Keluar</span>
          </div>
        ) : (
          <div className="crew-pill">
            <span className={hud.viewMode === 1 ? 'crew-dot mega' : 'crew-dot'} />
            <span>Kru 6 Penyelam</span>
            {hud.miniMode && <span className="mini-badge">Mungil -60%</span>}
            <span className="pill-sep">·</span>
            <span>-{hud.depth}m</span>
            <span className="pill-sep">·</span>
            <span>{camBadge}</span>
            <span className="pill-sep pill-hint">·</span>
            <span className="pill-hint"><i className="kbd kbd-brass">G</i> -60%</span>
            <span className="pill-hint"><i className="kbd">B</i> Megalo</span>
            <span className="pill-hint"><i className="kbd kbd-cyan">K</i> POV</span>
            {hud.subDist > 8 && (
              <span className="pill-hint">
                <i className="kbd kbd-brass">R</i> {hud.summoning ? 'Datang…' : `Kapal (${Math.round(hud.subDist)}m)`}
              </span>
            )}
          </div>
        )}

        {/* Touch action buttons for mobile/tablet */}
        <div className="touch-bar">
          <button
            type="button"
            className="touch-btn gold"
            onClick={() => engineRef.current?.toggleSubmarine()}
          >
            {hud.inSub ? 'Keluar' : hud.nearSub ? 'Naik Kapal' : 'Panggil Kapal'}
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 2 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleCockpit()}
          >
            {hud.inSub ? 'Kokpit 3D' : 'POV'}
          </button>
          <button
            type="button"
            className={`touch-btn ${hud.viewMode === 1 ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMegalophobia()}
          >
            Megalo
          </button>
          <button
            type="button"
            className={`touch-btn gold ${hud.miniMode ? 'active' : ''}`}
            onClick={() => engineRef.current?.toggleMiniMode()}
          >
            -60%
          </button>
          <button
            type="button"
            className="touch-btn"
            onClick={() => engineRef.current?.toggleLights()}
          >
            Lampu
          </button>
        </div>
      </div>

      {/* Abyssal Garden Start & Pause Menu (with Size -60% & Camera Mode Selectors) */}
      <div id="m">
        <h1>Abyssal Garden</h1>
        <p className="sub-tag">Scuba Klasik · 5 Teman · Kokpit Kapal Selam · Manta 10x</p>

        <div id="a">
          <div id="l">
            <div id="p"><i id="b" ref={barRef} /></div>
            <p id="s">{statusText}</p>
            <p id="w" hidden={!browserHint}>Use Google Chrome for optimal experience</p>
          </div>

          <div id="g">
            <button id="d" ref={diveBtnRef} className="ag-btn" type="button" onClick={handleDive}>
              {hasDived ? 'Resume' : 'Dive in'}
            </button>

            {/* Size mode selector: Standard vs 60% Smaller Miniature Diver + Submarine */}
            <p className="opt-row">
              <span>Ukuran</span>
              <button
                type="button"
                className={!hud.miniMode ? 'ag-btn on' : 'ag-btn'}
                onClick={() => engineRef.current?.toggleMiniMode(false)}
              >
                Standar
              </button>
              <button
                type="button"
                className={hud.miniMode ? 'ag-btn on-brass' : 'ag-btn'}
                onClick={() => engineRef.current?.toggleMiniMode(true)}
              >
                Mungil -60%
              </button>
            </p>

            {/* Camera mode selector: Standar / Megalophobia / POV & 3D Cockpit */}
            <p className="opt-row">
              <span>Kamera</span>
              {CAM_NAMES.map((name, idx) => (
                <button
                  key={name}
                  type="button"
                  className={hud.viewMode === idx ? 'ag-btn on' : 'ag-btn'}
                  onClick={() => engineRef.current?.setViewMode(idx)}
                >
                  {name}
                </button>
              ))}
            </p>

            {/* Original Quality / Detail selector */}
            <p className="opt-row">
              <span>Detail</span>
              {detailLabels.map((label, i) => {
                const lv = 2 - i;
                return (
                  <button
                    key={label}
                    type="button"
                    className={lv === detailLv ? 'ag-btn on' : 'ag-btn'}
                    onClick={() => engineRef.current?.setDetail(lv)}
                  >
                    {label}
                  </button>
                );
              })}
            </p>

            <div id="k">
              <p>
                <i><b>W</b><b>A</b><b>S</b><b>D</b></i><span>Renang / Kemudi</span>
                <i><b>Q</b><b>E</b></i><span>Turun / Naik</span>
                <i><b>Shift</b></i><span>Lebih Cepat</span>
                <i><b className="kbd-brass">F</b></i><span>Naik / Turun Kapal</span>
                <i><b>R</b></i><span>Panggil Kapal · <b>L</b> Lampu</span>
              </p>
              <p>
                <i><b className="kbd-brass">G</b></i><span>Mode Mungil -60%</span>
                <i><b className="kbd-cyan">K</b></i><span>Kokpit 3D / POV Helm</span>
                <i><b>B</b></i><span>Kamera Megalophobia</span>
                <i><b>V</b></i><span>Ganti Kamera · <b>C</b> Sapa/Manta</span>
                <i><b>1</b>–<b>6</b></i><span>Lokasi · <b>M</b> Suara · <b>H</b> FPS</span>
              </p>
            </div>

            <p id="h">Tahan untuk berenang/mengemudi · geser untuk belok · 2 jari lebih cepat</p>
          </div>
        </div>

        <p id="f">
          <a href="https://github.com/Noniv/abyssal-garden" target="_blank" rel="noreferrer">
            <svg viewBox="0 0 16 16">
              <path d="M8 0c4.42 0 8 3.58 8 8a8.013 8.013 0 0 1-5.45 7.59c-.4.08-.55-.17-.55-.38 0-.27.01-1.13.01-2.2 0-.75-.25-1.23-.54-1.48 1.78-.2 3.65-.88 3.65-3.95 0-.88-.31-1.59-.82-2.15.08-.2.36-1.02-.08-2.12 0 0-.67-.22-2.2.82-.64-.18-1.32-.27-2-.27-.68 0-1.36.09-2 .27-1.53-1.03-2.2-.82-2.2-.82-.44 1.1-.16 1.92-.08 2.12-.51.56-.82 1.28-.82 2.15 0 3.06 1.86 3.75 3.64 3.95-.23.2-.44.55-.51 1.07-.46.21-1.61.55-2.33-.66-.15-.24-.6-.83-1.23-.82-.67.01-.27.38.01.53.34.19.73.9.82 1.13.16.45.68 1.31 2.69.94 0 .67.01 1.3.01 1.49 0 .21-.15.45-.55.38A7.995 7.995 0 0 1 0 8c0-4.42 3.58-8 8-8Z" />
            </svg>
            GitHub
          </a>
          <a href="https://ko-fi.com/noniv" target="_blank" rel="noreferrer">
            <svg viewBox="0 0 24 24">
              <path fillRule="evenodd" d="M2 5h16.5a4.5 4.5 0 0 1 0 9H17a6 6 0 0 1-6 5H8a6 6 0 0 1-6-6zM17 8v3h1.5a1.5 1.5 0 0 0 0-3zM9.5 15.5 5.9 12a2.2 2.2 0 0 1 3.6-2.5 2.2 2.2 0 0 1 3.6 2.5z" />
            </svg>
            Support
          </a>
        </p>
      </div>

      <button
        id="o"
        className="ag-btn"
        type="button"
        aria-label="Menu"
        onClick={() => engineRef.current?.openMenu()}
      >
        ≡
      </button>
      <pre id="i">{statsText}</pre>
    </>
  );
}

export default App;

import { useEffect, useRef } from "react";
import Title3D from "./Title3D";
import { sfx } from "../audio/sfx";
import {
  FreeDiamondsBar,
  HomeButton,
  NewBestRibbon,
  RetryButton,
  RewardBar,
  ScoreRow,
  TapToSkip,
  useCountUp,
  useOnce,
  useStepSfx,
  useTimeline,
  type ResultsProps,
} from "./ResultParts";

const STEPS = {
  GAME: 0,
  OVER: 400,
  SUB: 920,
  CARD: 1100,
  BEST: 2050,
  REWARD: 2250,
  COINS: 2550,
  BUTTONS: 2650,
  EXTRA: 2900,
};

/** V1 – "Progress" layout */
export default function ResultsV1(p: ResultsProps) {
  const { at, intro, skip, step, order } = useTimeline(STEPS);
  const once = useOnce();
  const rewardRef = useRef<HTMLDivElement>(null);
  const segTimers = useRef<number[]>([]);
  const isNewBest = p.score > p.prevBest;

  useEffect(() => {
    once("shake", at("OVER"), () => setTimeout(() => p.onShake(14), 230));
    once("best", at("BEST") && isNewBest, () => p.onBest(p.score));
    once("coins", at("COINS"), () => {
      setTimeout(() => p.onFly("coin", rewardRef.current, p.reward), 120);
      setTimeout(() => p.onFly("diamond", rewardRef.current, p.gems), 420);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);

  useEffect(() => () => segTimers.current.forEach(clearTimeout), []);

  useStepSfx(
    step,
    order,
    (k) => {
      switch (k) {
        case "OVER":
          setTimeout(sfx.boom, 230);
          break;
        case "SUB":
          sfx.gameOverJingle();
          break;
        case "CARD":
          sfx.whoosh(true, 0.3, 0.14);
          for (let i = 0; i <= p.hits && i < p.totalTargets; i++) {
            segTimers.current.push(
              window.setTimeout(() => (i < p.hits ? sfx.seg(i) : sfx.segMiss()), 250 + i * 70),
            );
          }
          break;
        case "BEST":
          if (isNewBest) sfx.newBest();
          break;
        case "REWARD":
          sfx.pop(1.1);
          break;
        case "BUTTONS":
          sfx.pop(0.9);
          setTimeout(() => sfx.pop(1.2), 90);
          break;
        case "EXTRA":
          sfx.softPop();
          break;
      }
    },
    () => {
      segTimers.current.forEach(clearTimeout);
      if (isNewBest) sfx.newBest();
    },
  );

  const score = useCountUp(p.score, at("CARD"), 900);
  const reward = useCountUp(p.reward, at("REWARD"), 500);
  const best = at("BEST") && isNewBest ? p.score : p.prevBest;

  return (
    <div className="relative flex h-full flex-col items-center px-6 pt-[66px]" onPointerDown={intro ? skip : undefined}>
      {/* ---------- TITLE ---------- */}
      <div className="relative w-full" style={{ animation: at("SUB") ? "title-bob 3s ease-in-out infinite" : undefined }}>
        <Title3D text="GAME" variant="red" size={74} anim="drop" stagger={70} sound />
        <div className="relative -mt-1">
          {at("OVER") ? <Title3D text="OVER" variant="gold" size={86} anim="slam" stagger={55} /> : <div className="h-[82px]" />}
          {at("OVER") && (
            <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 300 100" preserveAspectRatio="none">
              <g stroke="#3b1d00" strokeWidth="3" fill="none" strokeLinecap="round" opacity="0.8">
                <path className="crack-path" d="M150 4 L143 24 L156 40 L141 60 L152 78 L147 96" style={{ animationDelay: "0.45s" }} />
                <path className="crack-path" d="M156 40 L182 33 L200 44" style={{ animationDelay: "0.55s" }} />
                <path className="crack-path" d="M141 60 L114 65 L98 58" style={{ animationDelay: "0.6s" }} />
              </g>
            </svg>
          )}
        </div>
      </div>

      <div className={`mt-2.5 flex items-center gap-2 font-russo text-[13px] tracking-wider text-white txt-outline ${at("SUB") ? "anim-fade-up" : "invisible"}`}>
        STAGE {p.stage}
        <span className="inline-block h-2 w-2 rotate-45 bg-[#ffb81c]" />
        TARGET MISSED
      </div>

      {/* space for the shared target (rendered by GameOver) */}
      <div className="h-[124px] w-full shrink-0" />

      {/* ---------- STATS CARD ---------- */}
      <div className={`panel relative w-full rounded-[22px] px-5 pb-4 pt-3.5 ${at("CARD") ? "anim-slide-up" : "invisible"}`}>
        <div className="flex items-center gap-2 font-russo text-[11px] tracking-wider text-[#8fd3ff]">
          STAGE PROGRESS
          <span className="rounded-md bg-black/30 px-1.5 py-0.5 text-[10px] text-white/80">
            <span className="text-white">{p.hits}</span>/{p.totalTargets} HITS
          </span>
        </div>

        <div className="mt-2.5 flex gap-1.5">
          {Array.from({ length: p.totalTargets }).map((_, i) => {
            const hit = i < p.hits;
            const miss = i === p.hits;
            return (
              <div key={i} className="relative h-3 flex-1 overflow-hidden rounded-full bg-white/10">
                {at("CARD") && (hit || miss) && (
                  <div
                    className={`absolute inset-0 origin-left rounded-full ${
                      hit ? "bg-gradient-to-b from-[#7dfa93] to-[#1fbf45]" : "bg-gradient-to-b from-[#ff8070] to-[#d92a17]"
                    }`}
                    style={{ animation: `seg-fill .18s ease-out ${0.25 + i * 0.07}s both` }}
                  />
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-3.5">
          <ScoreRow score={score} best={best} bestPop={at("BEST") && isNewBest} />
        </div>

        {at("BEST") && isNewBest && <NewBestRibbon className="-right-3 -top-5" />}
      </div>

      {/* ---------- REWARD BAR ---------- */}
      <div className="mt-4 w-full">
        <RewardBar show={at("REWARD")} reward={reward} gems={p.gems} doubleUsed={p.doubleUsed} onDouble={p.onDouble} coinRef={rewardRef} />
      </div>

      {/* ---------- MAIN BUTTONS ---------- */}
      <div className="mt-6 flex w-full gap-4">
        <HomeButton show={at("BUTTONS")} onClick={p.onHome} />
        <RetryButton show={at("BUTTONS")} onClick={p.onRetry} />
      </div>

      {/* ---------- SECONDARY ---------- */}
      <div className="mt-5 w-full">
        <FreeDiamondsBar show={at("EXTRA")} left={p.adDiamondsLeft} amount={p.adDiamonds} onClick={p.onAdDiamonds} />
      </div>

      <TapToSkip show={intro && step >= 0} bottom={74} />
    </div>
  );
}

import Title3D from "./Title3D";
import { Bullet } from "./Target";
import { Coin, Diamond } from "./Icons";
import { CompactActions, RewardPills } from "./FancyButtons";
import { WEAPONS, WeaponArt } from "./Weapons";
import { NewBestRibbon, Trophy, fmt, type ResultsProps } from "./ResultParts";
import { CrosshairIcon, FlagIcon, TargetIcon, useShowcase } from "./ResultsV2";

function Stat({ icon, value, color, label }: { icon: React.ReactNode; value: string; color: string; label: string }) {
  return (
    <div className="flex flex-1 items-center justify-center gap-2">
      <span
        className="flex h-[30px] w-[30px] items-center justify-center rounded-[10px]"
        style={{ background: `linear-gradient(180deg, ${color}38, ${color}12)`, boxShadow: `inset 0 0 0 1.5px ${color}5c` }}
      >
        {icon}
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-russo text-[9.5px] tracking-wider text-white/55">{label}</span>
        <span className="mt-[3px] font-russo text-[18px]" style={{ color, textShadow: "0 2px 0 rgba(0,0,0,0.45)" }}>
          {value}
        </span>
      </span>
    </div>
  );
}

/** V6 – "Compact": everything tighter, grouped and calm */
export default function ResultsV6(p: ResultsProps) {
  const { at, intro, skip, rewardRef, gemRef, isNewBest, shots, score, acc, reward, best } = useShowcase(p);
  const aura = WEAPONS[p.gun].aura;

  return (
    <div className="relative flex h-full flex-col items-center px-6 pt-[70px]" onPointerDown={intro ? skip : undefined}>
      {/* title – one line */}
      <div className="relative z-20 flex w-full items-end justify-center gap-2.5" style={{ animation: at("GUN") ? "title-bob 3.2s ease-in-out infinite" : undefined }}>
        <Title3D text="GAME" variant="red" size={58} anim="drop" stagger={70} sound />
        {at("OVER") ? <Title3D text="OVER" variant="gold" size={58} anim="slam" stagger={55} /> : <div className="h-[56px] w-[160px]" />}
        {at("BULLET") && (
          <div className="pointer-events-none absolute left-0 top-[18px]" style={{ animation: "bullet-across .7s cubic-bezier(.3,.1,.4,1) both" }}>
            <Bullet className="scale-75" />
          </div>
        )}
      </div>

      {/* gun */}
      <div className="relative z-10 mt-1 flex h-[150px] w-full items-center justify-center">
        {at("GUN") && (
          <>
            <div className="rays anim-rays anim-fade absolute h-[300px] w-[300px] rounded-full opacity-50" />
            <div className="absolute bottom-1 h-5 w-40 rounded-[50%] bg-black/45 blur-md" />
            <div style={{ animation: "gun-in .75s cubic-bezier(.2,.8,.3,1.1) both" }}>
              <div className="anim-float" style={{ filter: aura ? `drop-shadow(0 0 14px ${aura})` : undefined }}>
                <WeaponArt id={p.gun} scale={1.3} tilt={-8} />
              </div>
            </div>
          </>
        )}
      </div>

      {/* compact card */}
      <div className={`panel relative mt-1 w-full rounded-[22px] ${at("CARD") ? "anim-slide-up" : "invisible"}`}>
        <div className="flex items-center justify-between px-5 pt-3">
          <div className="flex flex-col leading-none">
            <span className="font-russo text-[10.5px] tracking-[0.3em] text-white/55">SCORE</span>
            <span className="txt-gold mt-1 font-russo text-[42px] leading-none">{fmt(score)}</span>
          </div>
          <div className="flex flex-col items-end rounded-xl border border-white/10 bg-black/25 px-3 py-1.5">
            <span className="flex items-center gap-1 font-russo text-[9.5px] tracking-widest text-white/55">
              <Trophy size={11} /> BEST
            </span>
            <span key={best} className={`mt-0.5 inline-block font-russo text-[18px] leading-none text-white ${at("BEST") && isNewBest ? "anim-pop" : ""}`}>
              {fmt(best)}
            </span>
          </div>
        </div>

        <div className={`mx-3 mt-3 flex h-[48px] items-center rounded-2xl border border-white/10 bg-black/25 ${at("STATS") ? "anim-fade" : "invisible"}`}>
          <Stat icon={<FlagIcon size={15} />} label="STAGE" value={String(p.stage)} color="#7dff9a" />
          <span className="h-7 w-px bg-white/12" />
          <Stat icon={<TargetIcon size={15} />} label="HITS" value={`${p.hits}/${shots}`} color="#ff8a7a" />
          <span className="h-7 w-px bg-white/12" />
          <Stat icon={<CrosshairIcon size={15} />} label="ACC" value={`${acc}%`} color="#8fd8ff" />
        </div>

        <div className={`mt-3 flex h-[40px] items-center justify-center gap-4 rounded-b-[22px] border-t border-white/10 bg-black/20 ${at("REWARD") ? "anim-fade" : "invisible"}`}>
          <span className="font-russo text-[10px] tracking-[0.25em] text-white/50">REWARD</span>
          <span ref={rewardRef} className="flex items-center gap-1.5">
            <Coin size={22} />
            <span className="font-lilita text-[20px] text-[#ffc531]" style={{ textShadow: "0 2px 0 #7a4200" }}>
              +{reward}
            </span>
          </span>
          <span ref={gemRef} className="flex items-center gap-1">
            <Diamond size={19} />
            <span className="font-lilita text-[18px] text-[#bfeaff]" style={{ textShadow: "0 2px 0 #0c4c91" }}>
              +{p.gems}
            </span>
          </span>
        </div>

        {at("BEST") && isNewBest && <NewBestRibbon className="-top-5 right-[118px]" />}
      </div>

      {/* actions */}
      <div className="mt-5 w-full">
        <CompactActions show={at("BUTTONS")} onHome={p.onHome} onRetry={p.onRetry} />
      </div>

      {/* reward pills – narrower than the action row */}
      <div className="mt-[18px] flex w-full justify-center">
        <RewardPills show={at("EXTRA")} doubleUsed={p.doubleUsed} onDouble={p.onDouble} gift={p.gift} onGift={p.onGift} />
      </div>
    </div>
  );
}

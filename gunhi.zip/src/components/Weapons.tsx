import Revolver, { type GunTone } from "./Revolver";
import HolyGun from "./HolyGun";
import { Blaster, Cannon, Pistol } from "./Guns";

export type Rarity = "common" | "rare" | "epic" | "legend";
export type WeaponId = "revolver" | "bronze" | "jade" | "desert" | "frost" | "venom" | "void" | "ember" | "holy" | "royal";
export type Shape = "revolver" | "pistol" | "blaster" | "cannon" | "holy";

type Meta = {
  name: string;
  tag: string;
  tagBg: string;
  desc: React.ReactNode;
  rarity: Rarity | "starter";
  shape: Shape;
  tone?: GunTone;
  aura?: string;
};

const hl = (c: string, t: string) => <span style={{ color: c }}>{t}</span>;

export const WEAPONS: Record<WeaponId, Meta> = {
  revolver: { name: "CLASSIC REVOLVER", tag: "★ STANDAR", tagBg: "linear-gradient(180deg,#b8c3cc,#6b7a85)", desc: "Revolver andalan para penembak jitu.", rarity: "starter", shape: "revolver", tone: "silver" },

  bronze: { name: "IRON SIX", tag: "⚙ STABIL", tagBg: "linear-gradient(180deg,#e7b98a,#9a6232)", rarity: "common", shape: "revolver", tone: "bronze", desc: <>Revolver besi yang andal. Tarikan pelatuk ringan, {hl("#ffd8a8", "+5% akurasi")} setiap tembakan.</> },
  jade: { name: "JADE RANGER", tag: "🍃 RINGAN", tagBg: "linear-gradient(180deg,#6cf08a,#1aa83a)", rarity: "common", shape: "pistol", tone: "jade", desc: <>Pistol giok yang super ringan. Jeda antar tembakan {hl("#a7f3c0", "10% lebih cepat")}.</> },
  desert: { name: "DESERT HAWK", tag: "☀ PELURU BERAT", tagBg: "linear-gradient(180deg,#f0d9a8,#a8823e)", rarity: "common", shape: "cannon", tone: "desert", desc: <>Meriam tangan gurun. Peluru berat yang {hl("#f0d9a8", "tidak terpental")} dari target kayu.</> },

  frost: { name: "FROST BITE", tag: "❄ PELURU ES", tagBg: "linear-gradient(180deg,#7fd8ff,#1677d4)", rarity: "rare", shape: "pistol", tone: "frost", aura: "rgba(120,210,255,0.6)", desc: <>Pistol es abadi. Tembakan kena {hl("#bff3ff", "membekukan target 1 detik")} agar tembakan berikutnya lebih mudah.</> },
  venom: { name: "VENOM RAY", tag: "☠ RACUN", tagBg: "linear-gradient(180deg,#b6e65a,#4c7a0e)", rarity: "rare", shape: "blaster", tone: "venom", aura: "rgba(163,255,58,0.5)", desc: <>Blaster beracun. Target yang kena {hl("#d4f77a", "bergerak 20% lebih lambat")} selama 2 detik.</> },

  void: { name: "VOID BLASTER", tag: "✦ PELURU ANGKASA", tagBg: "linear-gradient(180deg,#c48bff,#7432d6)", rarity: "epic", shape: "blaster", tone: "void", aura: "rgba(176,110,255,0.6)", desc: <>Blaster energi angkasa. Setiap 3 tembakan kena, peluru berikutnya {hl("#8fe9ff", "menembus 2 target")} sekaligus.</> },
  ember: { name: "INFERNO", tag: "🔥 API", tagBg: "linear-gradient(180deg,#ffb27a,#e8572a)", rarity: "epic", shape: "cannon", tone: "ember", aura: "rgba(255,140,40,0.55)", desc: <>Meriam api. Setiap 5 tembakan kena, peluru berikutnya {hl("#ffd08a", "meledak mengenai target di sekitarnya")}.</> },

  holy: { name: "HOLY LIGHT GUN", tag: "☀ CAHAYA SUCI", tagBg: "linear-gradient(180deg,#ffb347,#f07a12)", rarity: "legend", shape: "holy", aura: "rgba(255,214,90,0.6)", desc: <>Senjata bersayap malaikat. Tiap tembakan kena {hl("#ffd84a", "menyucikan 1 peluru berkarat")}, plus {hl("#8fe9ff", "1 perisai suci")} per level.</> },
  royal: { name: "GOLDEN DRAGON", tag: "🐉 NAGA EMAS", tagBg: "linear-gradient(180deg,#ff6b95,#c8123f)", rarity: "legend", shape: "revolver", tone: "royal", aura: "rgba(255,200,60,0.55)", desc: <>Revolver emas sang naga. Hadiah koin tiap stage {hl("#ffd84a", "+50%")}, plus {hl("#ff9ab8", "1 peluru ekstra")} per level.</> },
};

export const POOL: Record<Rarity, WeaponId[]> = {
  common: ["bronze", "jade", "desert"],
  rare: ["frost", "venom"],
  epic: ["void", "ember"],
  legend: ["holy", "royal"],
};

export const ALL_WEAPONS = Object.keys(WEAPONS) as WeaponId[];

/** Renders any weapon at a comparable visual size. scale=1 ≈ 160px wide. */
export function WeaponArt({ id, scale = 1, tilt = -14 }: { id: WeaponId; scale?: number; tilt?: number }) {
  const m = WEAPONS[id];
  if (m.shape === "holy") return <HolyGun width={118 * scale} />;
  const w = 162 * scale;
  const tone = m.tone ?? "silver";
  const art = m.shape === "pistol" ? <Pistol width={w} tone={tone} /> : m.shape === "blaster" ? <Blaster width={w} tone={tone} /> : m.shape === "cannon" ? <Cannon width={w} tone={tone} /> : <Revolver width={w} tone={tone} />;
  return <div style={{ transform: `rotate(${tilt}deg)` }}>{art}</div>;
}

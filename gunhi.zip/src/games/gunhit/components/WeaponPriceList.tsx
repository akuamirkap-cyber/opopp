import { useState } from 'react';
import { WEAPONS, getWeaponCoinPrice, getWeaponDiamondPrice } from '../game/weapons';
import { RARITY_COLOR } from '../game/weapons';
import CoinSprite from '../../shared/CoinSprite';
import DiamondSprite from '../../shared/DiamondSprite';

type Props = { onClose: () => void };

const RARITY_ORDER = ['UMUM','LANGKA','EPIC','LEGENDARIS'] as const;
const RARITY_LABEL: Record<string,string> = { UMUM:'UMUM · FREE', LANGKA:'LANGKA · MURAH', EPIC:'EPIC · MURAH', LEGENDARIS:'LEGEND · MURAH' };

export default function WeaponPriceList({ onClose }: Props) {
  const [filter, setFilter] = useState<string>('ALL');

  return (
    <div className="absolute inset-0 z-[70] flex flex-col bg-[#0d1020]/96 backdrop-blur-md">
      <header className="flex items-center justify-between border-b border-white/10 bg-[#131630] px-3 py-2.5">
        <div>
          <div className="flex items-center gap-2">
            <span className="rounded-full bg-amber-300 px-2 py-0.5 text-[9px] font-black tracking-[0.16em] text-[#2a1d00]">3 HARI</span>
            <span className="text-[10px] font-bold tracking-[0.14em] text-white/50">DAFTAR HARGA SENJATA</span>
          </div>
          <h2 className="font-black text-[18px] leading-none text-white mt-0.5">MURAH & CEPAT DAPAT</h2>
          <p className="text-[10px] font-semibold text-white/60 mt-0.5">Semua senjata kebeli dalam 3 hari — koin & diamond x2.5</p>
        </div>
        <button onClick={onClose} className="grid h-9 w-9 place-items-center rounded-xl border border-white/15 bg-white/10 text-white font-black">✕</button>
      </header>

      {/* ringkasan ekonomi */}
      <div className="grid grid-cols-3 gap-2 px-3 py-2.5 bg-black/20 border-b border-white/10">
        {[
          { label:'UMUM', sub:'FREE', coin:'0', diamond:'0', color:'#cbd5e1', bg:'bg-white/10' },
          { label:'LANGKA', sub:'48💎 / 340🪙', coin:'340', diamond:'48', color:'#38bdf8', bg:'bg-sky-500/15' },
          { label:'EPIC', sub:'160🪙', coin:'160', diamond:'28', color:'#c084fc', bg:'bg-fuchsia-500/15' },
        ].map(c=>(
          <div key={c.label} className={`rounded-xl border border-white/10 ${c.bg} px-2 py-2 text-center`}>
            <div className="text-[10px] font-black tracking-widest" style={{color:c.color}}>{c.label}</div>
            <div className="text-[11px] font-black text-white">{c.sub}</div>
          </div>
        ))}
        <div className="col-span-3 flex items-center justify-center gap-3 rounded-xl border border-amber-300/30 bg-amber-400/10 px-2 py-1.5 text-[10px] font-bold text-amber-200">
          <span className="flex items-center gap-1"><CoinSprite size={14}/> START 480🪙</span>
          <span className="h-3 w-px bg-white/20"/>
          <span className="flex items-center gap-1"><DiamondSprite size={14}/> START 85💎</span>
          <span className="h-3 w-px bg-white/20"/>
          <span>Boss +18💎</span>
        </div>
      </div>

      {/* filter */}
      <div className="flex gap-1.5 px-3 py-2 border-b border-white/10 bg-black/10 overflow-x-auto">
        {['ALL', ...RARITY_ORDER].map(r=>(
          <button key={r} onClick={()=>setFilter(r)} className={`shrink-0 rounded-full border px-3 py-1.5 text-[10px] font-black tracking-widest ${filter===r ? 'bg-white text-[#0d1020] border-white' : 'bg-white/5 text-white/60 border-white/15'}`}>{r==='ALL' ? `SEMUA (${WEAPONS.length})` : `${r} (${WEAPONS.filter(w=>w.rarity===r).length})`}</button>
        ))}
      </div>

      {/* list */}
      <div className="flex-1 overflow-y-auto px-3 py-2.5 space-y-2">
        {RARITY_ORDER.filter(r=> filter==='ALL' || filter===r).map(rarity=>{
          const group = WEAPONS.filter(w=>w.rarity===rarity);
          return (
            <div key={rarity}>
              <div className="flex items-center gap-2 py-1">
                <span className="h-px flex-1 bg-white/10"/>
                <span className="rounded-full px-2.5 py-1 text-[9px] font-black tracking-[0.14em] border" style={{background:RARITY_COLOR[rarity]+'22', color:RARITY_COLOR[rarity], borderColor:RARITY_COLOR[rarity]+'55'}}>{RARITY_LABEL[rarity]} · {group.length} senjata</span>
                <span className="h-px flex-1 bg-white/10"/>
              </div>
              <div className="grid gap-1.5">
                {group.map(w=>{
                  const coin = getWeaponCoinPrice(w);
                  const diamond = getWeaponDiamondPrice(w);
                  const free = coin===0 && diamond===0;
                  return (
                    <div key={w.id} className="flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] px-2.5 py-2">
                      <span className="text-[18px] leading-none">{w.emoji}</span>
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-[12px] font-black leading-none text-white">{w.name.toUpperCase()}</div>
                        <div className="truncate text-[10px] font-semibold leading-tight text-white/55">{w.perk}</div>
                      </div>
                      <div className="flex flex-col items-end gap-0.5 shrink-0">
                        {free ? (
                          <span className="rounded-full bg-emerald-400 px-2 py-1 text-[10px] font-black leading-none text-[#052e16]">FREE</span>
                        ) : rarity==='LANGKA' ? (
                          <span className="flex items-center gap-1 rounded-full border border-sky-300/30 bg-sky-500/15 px-2 py-1 text-[10px] font-black leading-none text-sky-100"><DiamondSprite size={12}/>{diamond} <span className="opacity-40">/</span> <CoinSprite size={12}/>{coin}</span>
                        ) : (
                          <span className="flex items-center gap-1 rounded-full border border-amber-300/30 bg-amber-500/15 px-2 py-1 text-[10px] font-black leading-none text-amber-100"><CoinSprite size={12}/>{coin}</span>
                        )}
                        <span className="text-[8px] font-bold tracking-widest text-white/30">{w.rarity}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )
        })}
        <div className="rounded-xl border border-fuchsia-300/20 bg-fuchsia-500/10 p-3 text-center">
          <div className="text-[11px] font-black text-fuchsia-100">CARA CEPAT KAYA 3 HARI</div>
          <div className="mt-1 grid grid-cols-3 gap-2 text-[10px] font-bold leading-tight text-white/75">
            <span className="rounded-lg bg-white/5 py-2">Boss +18💎<br/><span className="text-white/40">tiap 5 stage</span></span>
            <span className="rounded-lg bg-white/5 py-2">Boulder +80💎<br/><span className="text-white/40">hancurkan diamond</span></span>
            <span className="rounded-lg bg-white/5 py-2">Koin x2.5<br/><span className="text-white/40">1-3 koin/stage</span></span>
          </div>
        </div>
      </div>

      <div className="border-t border-white/10 bg-[#131630] p-3">
        <button onClick={onClose} className="w-full rounded-xl bg-gradient-to-b from-amber-300 to-orange-500 py-2.5 text-[13px] font-black text-[#3a1d00] shadow-[0_4px_0_#7c2d12]">MENGERTI — GAS BELI!</button>
      </div>
    </div>
  )
}

/**
 * The launcher that used to sit here listed five archived HTML screens. The
 * archive pages are gone from this build, so the gun game is the app: the
 * Perfect Shot shell mounts the Gun Hit SGA game directly.
 */
export { default } from './PerfectShotApp';

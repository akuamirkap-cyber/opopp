import { useCallback, useEffect, useRef, useState, type PointerEvent, type ReactNode, type RefObject } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Maximize2, Minimize2, Pause, Play, Settings2, Volume2, VolumeX, X } from 'lucide-react';
import { VIEW_H, VIEW_W, ZONES } from './game/constants';
import { Game, type UIState } from './game/game';
import type { SoundVersion } from './game/soundPacks';
import { MOVE_LIST } from './game/moves';
import { MUTATIONS } from './game/mutations';
import { YOYO_SKINS, isYoyoSkinId } from './game/yoyoSkins';
import type { WeaponKind } from './game/types';
import { MutIcon, MutIconSm } from './MutIcon';

const MENU_ITEMS = [
  { id: 'start', label: 'START' },
  { id: 'board', label: 'LEADERBOARD' },
  { id: 'quit', label: 'QUIT' },
];

interface BoardRow { name: string; score: number; mode: string; you?: boolean }
const BOARD_KEY = 'sf_board_v1';
const SEED_BOARD: BoardRow[] = [
  { name: 'GURU', score: 48200, mode: 'DUEL 6' },
  { name: 'KAORI', score: 36750, mode: 'DUEL 4' },
  { name: 'IRON JAW', score: 29400, mode: 'DUEL 5' },
  { name: 'BRUNO', score: 21850, mode: 'WAVE 18' },
  { name: 'SASUKE', score: 16300, mode: 'DUEL 2' },
  { name: 'RENGGA', score: 11200, mode: 'DUEL 1' },
  { name: 'MURID', score: 6400, mode: 'WAVE 9' },
  { name: 'PEMULA', score: 2150, mode: 'WAVE 3' },
];
function loadBoard(): BoardRow[] {
  let mine: BoardRow[] = [];
  try { mine = JSON.parse(localStorage.getItem(BOARD_KEY) || '[]'); } catch { mine = []; }
  return [...SEED_BOARD, ...mine].sort((a, b) => b.score - a.score).slice(0, 10);
}
function saveBoardScore(g: Game) {
  const score = Math.round(g.score);
  if (score <= 0) return;
  let mine: BoardRow[] = [];
  try { mine = JSON.parse(localStorage.getItem(BOARD_KEY) || '[]'); } catch { mine = []; }
  mine.push({ name: 'KAMU', score, mode: g.mode === 'duel' ? `DUEL ${g.duelRound}` : `WAVE ${g.wave}`, you: true });
  mine.sort((a, b) => b.score - a.score);
  try { localStorage.setItem(BOARD_KEY, JSON.stringify(mine.slice(0, 5))); } catch { /* penyimpanan penuh */ }
}

const initialUI: UIState = {
  state: 'menu', level: 1, zoneName: ZONES[0].name, zoneSub: ZONES[0].sub, score: 0, age: 20, deathCounter: 1, deaths: 0, kills: 0,
  bestCombo: 0, choices: [], save: null, best: { level: 0, score: 0 }, muted: false, mutations: [], ageGain: 0, hp: 5, maxHp: 5, accent: '#ff5a36',
  mode: 'story', wave: 0, survivalTime: 0, bestWave: 0, bestSurvivalScore: 0, blood: 'combined', v2: true, long: false,
  filters: false, duelRound: 1, duelName: 'RENGGA', duelTitle: 'AHLI NUNCHAKU', duelHp: 1, clashOn: false,
  weapon: 'fist', yoyoVer: 2, yoyoSkin: 'ember', nunStyle: 'v3', boxStance: 'ali', arena: 'meadow', showHits: false, hasNunchaku: false,
};

function aimAtNearest(game: Game, scene = false) {
  if (!scene && game.input.mouseMovedAt && performance.now() - game.input.mouseMovedAt < 1500) return;
  let nearest = null;
  let distance = Infinity;
  for (const enemy of game.enemies) {
    if (enemy.dead || enemy.spawnT > 0 || (scene && (enemy.boss || enemy.z > 1 || enemy.down > 0))) continue;
    const d = (enemy.x - game.player.x) ** 2 + (enemy.y - game.player.y) ** 2;
    if (scene && d > (30 + enemy.r) ** 2) continue;
    if (d < distance) { distance = d; nearest = enemy; }
  }
  if (!nearest) return;
  game.input.mouse.x = (nearest.x - game.cam.x - VIEW_W / 2) * game.zoom + VIEW_W / 2;
  game.input.mouse.y = (nearest.y - game.cam.y - VIEW_H / 2) * game.zoom + VIEW_H / 2;
}

function HoldButton({ label, children, onPress, onRelease, className = '' }: {
  label: string; children: ReactNode; onPress: () => void; onRelease: () => void; className?: string;
}) {
  const held = useRef(false);
  const release = () => { if (held.current) { held.current = false; onRelease(); } };
  const press = (event: PointerEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (held.current) return;
    held.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    onPress();
  };
  return <button type="button" className={`game-touch-button ${className}`} aria-label={label}
    onPointerDown={press} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}
    onClick={(event) => { if (event.detail === 0) { onPress(); window.setTimeout(onRelease, 120); } }}>
    {children}
  </button>;
}

function TouchControls({ gameRef }: { gameRef: RefObject<Game | null> }) {
  const key = (code: string, down: boolean) => {
    const game = gameRef.current;
    if (!game) return;
    if (down && code === 'KeyG') aimAtNearest(game, true);
    game.input.focus();
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, bubbles: true }));
  };
  const mouse = (button: number, down: boolean) => {
    const game = gameRef.current;
    if (!game) return;
    if (down) { aimAtNearest(game); game.input.focus(); game.input.synthMouseDown(button); }
    else game.input.synthMouseUp(button);
  };
  const keyButton = (code: string, label: string, content: ReactNode, className = '') => (
    <HoldButton label={label} className={className} onPress={() => key(code, true)} onRelease={() => key(code, false)}>{content}</HoldButton>
  );
  return <div className="game-touch" aria-label="Kontrol sentuh">
    <div className="game-dpad">
      {keyButton('KeyW', 'Bergerak ke atas', <ArrowUp size={20} />, 'dpad-up')}
      {keyButton('KeyA', 'Bergerak ke kiri', <ArrowLeft size={20} />, 'dpad-left')}
      {keyButton('KeyS', 'Bergerak ke bawah', <ArrowDown size={20} />, 'dpad-down')}
      {keyButton('KeyD', 'Bergerak ke kanan', <ArrowRight size={20} />, 'dpad-right')}
    </div>
    <div className="game-actions">
      {keyButton('ShiftLeft', 'Menghindar', 'DASH')}
      {keyButton('Space', 'Lompat', 'LOMPAT')}
      {keyButton('KeyC', 'Parry', 'PARRY')}
      {keyButton('KeyG', 'Adegan aksi', 'AKSI')}
      <HoldButton label="Serangan ringan" className="game-attack" onPress={() => mouse(0, true)} onRelease={() => mouse(0, false)}>PUKUL</HoldButton>
      <HoldButton label="Serangan berat" onPress={() => mouse(2, true)} onRelease={() => mouse(2, false)}>BERAT</HoldButton>
      {keyButton('KeyE', 'Focus strike', 'FOCUS')}
      {keyButton('KeyX', 'One For All', 'OFA')}
      {keyButton('KeyF', 'Fatality', 'FINISH')}
    </div>
  </div>;
}

function useScale() {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const calc = () => {
      // Sisakan ruang untuk bilah suara di bawah supaya arena tidak pernah tertutup kontrol.
      const bar = document.getElementById('sound-bar');
      const bh = document.fullscreenElement || !bar ? 0 : bar.getBoundingClientRect().height;
      // portrait: kontrol sentuh mengalir di bawah arena, jadi ikut memakan tinggi
      const portrait = window.innerHeight > window.innerWidth && window.innerWidth <= 820;
      const deck = portrait ? 210 : 0;
      const s = Math.min(window.innerWidth / VIEW_W, Math.max(140, window.innerHeight - bh - deck) / VIEW_H);
      setScale(s > 0 ? s : 1);
    };
    calc();
    window.addEventListener('resize', calc);
    document.addEventListener('fullscreenchange', calc);
    return () => {
      window.removeEventListener('resize', calc);
      document.removeEventListener('fullscreenchange', calc);
    };
  }, []);
  return scale;
}

export default function App({ soundVersion = 'v2', onState }: { soundVersion?: SoundVersion; onState?: (ui: UIState) => void } = {}) {
  const stateCb = useRef(onState);
  stateCb.current = onState;
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const pausedForSetup = useRef(false);
  const [ui, setUi] = useState<UIState>(initialUI);
  const [showSetup, setShowSetup] = useState(false);
  const [menuIdx, setMenuIdx] = useState(0);
  const [menuPanel, setMenuPanel] = useState<'none' | 'board' | 'quit'>('none');
  const [board, setBoard] = useState<BoardRow[]>(() => loadBoard());
  const [showTouch, setShowTouch] = useState(() => window.matchMedia('(pointer: coarse)').matches);
  const [fullscreen, setFullscreen] = useState(false);
  const scale = useScale();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let g: Game;
    try {
      g = new Game(canvas, soundVersion);
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to create game', err);
      return;
    }
    gameRef.current = g;
    (window as unknown as { __kf?: Game }).__kf = g;
    g.onUI = (u) => { setUi(u); stateCb.current?.(u); };
    try {
      g.start();
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to start game', err);
    }
    g.input.focus();
    const resumeAudio = () => { if (g.sfx.ctx && g.sfx.ctx.state !== 'running' && g.sfx.ctx.state !== 'closed' && !g.sfx.muted) g.sfx.init(); };
    window.addEventListener('pointerdown', resumeAudio, true);
    window.addEventListener('keydown', resumeAudio, true);

    return () => {
      window.removeEventListener('pointerdown', resumeAudio, true);
      window.removeEventListener('keydown', resumeAudio, true);
      g.destroy();
      if (gameRef.current === g) gameRef.current = null;
      if ((window as unknown as { __kf?: Game }).__kf === g) delete (window as unknown as { __kf?: Game }).__kf;
    };
  }, []);

  const closeSetup = useCallback(() => {
    setShowSetup(false);
    const game = gameRef.current;
    if (pausedForSetup.current && game?.state === 'paused') game.resume();
    else game?.input.focus();
    pausedForSetup.current = false;
  }, []);

  useEffect(() => {
    if (!showSetup) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault(); event.stopImmediatePropagation(); closeSetup();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [showSetup, closeSetup]);

  useEffect(() => {
    if (ui.state !== 'menu') return;
    const onKey = (e: KeyboardEvent) => {
      // stopImmediatePropagation: input game tidak boleh ikut membaca tombol menu,
      // kalau tidak Enter akan membuka panel SEKALIGUS memulai pertarungan.
      const eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
      if (menuPanel !== 'none') {
        if (e.key === 'Escape' || e.key === 'Enter' || e.key === ' ') { eat(); setMenuPanel('none'); }
        return;
      }
      if (e.key === 'ArrowDown' || e.key === 's') { eat(); setMenuIdx((i) => (i + 1) % MENU_ITEMS.length); gameRef.current?.sfx.beep(); }
      else if (e.key === 'ArrowUp' || e.key === 'w') { eat(); setMenuIdx((i) => (i - 1 + MENU_ITEMS.length) % MENU_ITEMS.length); gameRef.current?.sfx.beep(); }
      else if (e.key === 'Enter' || e.key === ' ') { eat(); runMenuItem(MENU_ITEMS[menuIdx].id); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [ui.state, menuIdx, menuPanel]);

  useEffect(() => {
    const onChange = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  // Ukur berapa jauh tombol kanan atas menutupi panggung, lalu geser HUD kanan selebar itu.
  useEffect(() => {
    const apply = () => {
      const game = gameRef.current;
      const stage = rootRef.current?.querySelector('.solo-stage');
      const quick = rootRef.current?.querySelector('.game-quick');
      if (!game || !stage || !quick) return;
      const overlap = quick.getBoundingClientRect().bottom - stage.getBoundingClientRect().top;
      game.hudInset = Math.max(0, Math.ceil(overlap / scale));
    };
    apply();
    const id = window.setTimeout(apply, 60);
    return () => window.clearTimeout(id);
  }, [scale, fullscreen, ui.state]);

  const g = () => gameRef.current!;
  const runMenuItem = (id: string) => {
    if (id === 'start') { setMenuPanel('none'); saveBoardScore(g()); setBoard(loadBoard()); g().startDuelFromMenu(); }
    else if (id === 'board') { setBoard(loadBoard()); setMenuPanel('board'); g().sfx.select(); }
    else { setMenuPanel('quit'); g().sfx.select(); }
  };
  const focusGame = () => gameRef.current?.input.focus();
  const act = (fn: () => void) => () => { focusGame(); fn(); focusGame(); };
  const openSetup = () => {
    const game = gameRef.current;
    if (!game) return;
    pausedForSetup.current = game.state === 'playing';
    if (pausedForSetup.current) game.pause();
    setShowSetup(true);
  };
  const restart = () => {
    const game = gameRef.current;
    if (!game) return;
    pausedForSetup.current = false; setShowSetup(false);
    if (game.mode === 'survival') game.newSurvival(); else game.newGame(null);
  };
  const quit = () => {
    pausedForSetup.current = false; setShowSetup(false);
    gameRef.current?.toMenu(); gameRef.current?.input.focus();
  };
  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await rootRef.current?.requestFullscreen();
    } catch (error) { console.warn('Layar penuh tidak tersedia:', error); }
  };
  const w = VIEW_W * scale, h = VIEW_H * scale;
  const fontPx = Math.min(22, Math.max(12, Math.round(4.5 * scale)));
  // V2 renders into a display-sized backing store so the picture is resampled exactly ONCE (hard pixel edges).
  // V1 keeps the classic fixed 480x270 buffer that CSS stretches — that is the old, softer look.
  const dpr = typeof window === 'undefined' ? 1 : Math.min(2, window.devicePixelRatio || 1);
  // Pixel art diperbesar nearest-neighbour, jadi buffer di atas ~960px tidak menambah
  // detail apa pun — hanya melipatgandakan biaya fill. Dibatasi supaya tetap mulus.
  const bw = ui.v2 ? Math.max(VIEW_W, Math.min(960, Math.round(w * Math.min(dpr, 1.5)))) : VIEW_W;
  const bh = ui.v2 ? Math.max(VIEW_H, Math.round((bw * VIEW_H) / VIEW_W)) : VIEW_H;

  return (
    <div ref={rootRef} className={`solo-game ${showTouch && ui.state === 'playing' ? 'solo-game--touch' : ''}`} onContextMenu={(e) => e.preventDefault()}>
      <div className="game-quick pixel">
        <button type="button" onClick={act(() => g().toggleMute())} aria-label={ui.muted ? 'Nyalakan suara' : 'Bisukan semua suara'} aria-pressed={ui.muted} title={ui.muted ? 'Suara mati [M]' : 'Suara nyala [M]'}>{ui.muted ? <VolumeX size={15} /> : <Volume2 size={15} />}</button>
        {['playing', 'paused'].includes(ui.state) && <>
          <button type="button" onClick={() => { if (g().state === 'playing') g().pause(); else g().resume(); }} aria-label={ui.state === 'playing' ? 'Jeda permainan' : 'Lanjutkan permainan'} title={ui.state === 'playing' ? 'Jeda' : 'Lanjutkan'}>{ui.state === 'playing' ? <Pause size={15} /> : <Play size={15} />}</button>
          <button type="button" onClick={openSetup} aria-label="Pengaturan dan senjata"><Settings2 size={15} /><span>SENJATA</span></button>
        </>}
      </div>
      <div className="solo-stage relative" style={{ width: w, height: h, fontSize: fontPx }}>
        <canvas
          ref={canvasRef}
          width={bw}
          height={bh}
          tabIndex={0}
          className="block w-full h-full cursor-none outline-none"
          style={{ imageRendering: 'pixelated' }}
        />
        {/* garis pindai retro — hanya bila filter dinyalakan */}
        {ui.filters && (
          <div
            className="pointer-events-none absolute inset-0 opacity-[0.13]"
            style={{ backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.6) 0px, rgba(0,0,0,0.6) 1px, transparent 2px, transparent 4px)' }}
          />
        )}
        {ui.state === 'menu' && (
          <div className="absolute inset-0 cursor-default overflow-hidden sf-menu">
            {/* latar TRANSPARAN: arena tetap terlihat. Hanya kabut tipis di sisi kiri
                supaya daftar menu tetap terbaca di atas rumput terang. */}
            {ui.filters && <div className="absolute inset-0 pointer-events-none sf-menu-veil" />}
            {ui.filters && <div className="absolute inset-0 pointer-events-none sf-menu-scan" />}

            <h1 className="sf-title pixel" style={{ color: '#fff' }}>
              <span className="sf-title-shadow" aria-hidden="true">STICKFIGHT!</span>
              <span className="sf-title-main" style={{ color: ui.accent }}>STICKFIGHT!</span>
            </h1>

            <nav className="sf-list" aria-label="Menu utama">
              {MENU_ITEMS.map((item, i) => (
                <button
                  key={item.id}
                  type="button"
                  className={'sf-item pixel' + (menuIdx === i ? ' is-on' : '')}
                  onPointerEnter={() => setMenuIdx(i)}
                  onFocus={() => setMenuIdx(i)}
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={act(() => runMenuItem(item.id))}
                  style={menuIdx === i ? { color: ui.accent } : undefined}
                >
                  <span className="sf-caret" aria-hidden="true">{menuIdx === i ? '>' : ''}</span>
                  {item.label}
                </button>
              ))}
              <div className="sf-hint pixel">W S / PANAH  -  ENTER</div>
            </nav>

            {menuPanel === 'board' && (
              <div className="sf-panel-wrap" onPointerDown={(e) => e.stopPropagation()}>
                <div className="sf-panel">
                  <div className="sf-panel-head pixel">
                    <span style={{ color: ui.accent }}>LEADERBOARD</span>
                    <button type="button" className="sf-x pixel" aria-label="Tutup papan skor" onClick={() => setMenuPanel('none')}>X</button>
                  </div>
                  <div className="sf-board">
                    {board.map((r, i) => (
                      <div key={r.name + i} className={'sf-row pixel' + (r.you ? ' is-you' : '')}>
                        <span className="sf-rank" style={{ color: i === 0 ? '#ffd447' : i === 1 ? '#d8d8e0' : i === 2 ? '#e09a5a' : '#7d6a63' }}>{String(i + 1).padStart(2, '0')}</span>
                        <span className="sf-name">{r.name}</span>
                        <span className="sf-mode">{r.mode}</span>
                        <span className="sf-score" style={{ color: r.you ? ui.accent : '#fff2e4' }}>{r.score.toLocaleString('id-ID')}</span>
                      </div>
                    ))}
                  </div>
                  <div className="sf-panel-foot pixel">SKOR TERSIMPAN DI PERANGKAT INI</div>
                </div>
              </div>
            )}

            {menuPanel === 'quit' && (
              <div className="sf-panel-wrap" onPointerDown={(e) => e.stopPropagation()}>
                <div className="sf-panel sf-panel-sm">
                  <div className="sf-panel-head pixel"><span style={{ color: ui.accent }}>KELUAR?</span></div>
                  <p className="sf-quit-text pixel">Tab ini tidak bisa ditutup sendiri. Kamu bisa kembali ke menu kapan saja — skor tetap tersimpan.</p>
                  <div className="sf-quit-row">
                    <button type="button" className="sf-btn pixel" onClick={() => setMenuPanel('none')} style={{ background: ui.accent, color: '#150806' }}>KEMBALI</button>
                    <button type="button" className="sf-btn sf-btn-ghost pixel" onClick={() => { g().sfx.stopMusic(); setMenuPanel('none'); setMenuIdx(0); }}>DIAMKAN</button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
        {ui.state === 'mutation' && (
          <Overlay dim="bg-black/70">
            <div className="flex flex-col items-center gap-[0.9em] text-center px-[1em]">
              <div className="pixel text-[1.2em]" style={{ color: ui.accent }}>PILIH MUTASI</div>
              <div className="pixel text-[0.55em] text-white/55">1 · 2 · 3</div>
              <div className="flex flex-wrap justify-center gap-[0.8em] max-w-[36em]">
                {ui.choices.map((m, i) => (
                  <button key={m.id} type="button" onClick={act(() => g().chooseMutation(i))}
                    className="pixel text-left w-[10.5em] p-[0.8em] border-[0.15em] bg-black/70 cursor-pointer transition-transform hover:-translate-y-[0.15em]"
                    style={{ borderColor: m.color, boxShadow: '0.25em 0.25em 0 #000' }}>
                    <div className="flex items-center gap-[0.5em] mb-[0.4em]">
                      <MutIcon id={m.id} color={m.color} />
                      <span className="text-[0.62em]" style={{ color: m.color }}>{m.name}</span>
                    </div>
                    <div className="text-[0.5em] text-white/70 leading-[1.5]">{m.desc}</div>
                    <div className="text-[0.5em] text-white/35 mt-[0.5em]">[{i + 1}]</div>
                  </button>
                ))}
              </div>
            </div>
          </Overlay>
        )}
        {ui.state === 'dead' && (
          <Overlay dim="bg-black/55">
            <div className="flex flex-col items-center gap-[0.7em] text-center px-[1em]">
              <div className="pixel text-[1.8em] text-red-500" style={{ textShadow: '0.08em 0.08em 0 #000' }}>TUMBANG</div>
              <div className="pixel text-[0.6em] text-white/70">
                {ui.mode === 'duel' ? `RONDE ${ui.duelRound} · ${ui.duelName}` : `UMUR ${ui.age} · KEMATIAN ${ui.deathCounter}`}
              </div>
              <Stats ui={ui} />
              <div className="pixel text-[0.55em] text-white/45">ENTER UNTUK BANGKIT</div>
              <div className="flex gap-[0.8em] mt-[0.3em]">
                <Btn accent={ui.accent} onClick={act(() => g().respawn())} primary>BANGKIT</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>MENU</Btn>
              </div>
            </div>
          </Overlay>
        )}
        {ui.state === 'gameover' && (
          <Overlay dim="bg-black/75">
            <div className="flex flex-col items-center gap-[0.8em] text-center px-[1em]">
              <div className="pixel text-[1.6em] text-red-500" style={{ textShadow: '0.08em 0.08em 0 #000' }}>PERJALANAN USAI</div>
              <Stats ui={ui} />
              <div className="flex gap-[0.8em] mt-[0.5em]">
                <Btn accent={ui.accent} onClick={act(() => g().restartZone())} primary>{ui.mode === 'survival' ? 'SURVIVE AGAIN' : ui.mode === 'duel' ? 'COBA LAGI' : 'RETRY ZONE'}</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>MENU</Btn>
              </div>
            </div>
          </Overlay>
        )}
        {ui.state === 'victory' && (
          <Overlay dim="bg-black/75">
            <div className="flex flex-col items-center gap-[0.8em] text-center px-[1em]">
              <div className="pixel text-[1.5em] text-yellow-300" style={{ textShadow: '0 0 1em #ffd700' }}>KAMU Sang GURU</div>
              <div className="pixel text-[0.6em] text-white/70">SEMUA LAWAN TUMBANG. TANGAN KOSONG, HATI PENUH.</div>
              <Stats ui={ui} />
              <Btn accent={ui.accent} onClick={act(() => g().toMenu())} primary>KEMBALI KE MENU</Btn>
            </div>
          </Overlay>
        )}
        {ui.state === 'paused' && (
          <Overlay dim="bg-black/70">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[1.6em] text-white">PAUSED</div>
              <div className="pixel text-[0.55em] text-white/60">{ui.mode === 'survival' ? `SURVIVAL - WAVE ${ui.wave}` : `LEVEL ${ui.level} - ${ui.zoneName} - AGE ${ui.age}`}</div>
              <div className="flex flex-wrap justify-center gap-[0.4em] max-w-[30em]">
                {ui.mutations.map((id, i) => {
                  const m = MUTATIONS.find((mm) => mm.id === id);
                  return m ? <span key={i} title={m.name}><MutIconSm id={m.id} color={m.color} /></span> : null;
                })}
              </div>
              <div className="flex gap-[0.8em]">
                <Btn accent={ui.accent} onClick={act(() => g().resume())} primary>RESUME [ESC]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toggleMute())}>{ui.muted ? 'UNMUTE' : 'MUTE'} [M]</Btn>
                <Btn accent="#ff4d4d" onClick={act(() => g().cycleBlood())}>BLOOD: {ui.blood.toUpperCase()} [B]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>QUIT</Btn>
              </div>
              <Controls compact />
            </div>
          </Overlay>
        )}
      </div>
      {showTouch && ui.state === 'playing' && !showSetup && <TouchControls gameRef={gameRef} />}
      {showSetup && <GameSetup gameRef={gameRef} ui={ui} close={closeSetup} restart={restart} quit={quit} showTouch={showTouch} setShowTouch={setShowTouch} fullscreen={fullscreen} toggleFullscreen={toggleFullscreen} />}
    </div>
  );
}

function GameSetup({ gameRef, ui, close, restart, quit, showTouch, setShowTouch, fullscreen, toggleFullscreen }: {
  gameRef: RefObject<Game | null>;
  ui: UIState;
  close: () => void;
  restart: () => void;
  quit: () => void;
  showTouch: boolean;
  setShowTouch: (value: boolean) => void;
  fullscreen: boolean;
  toggleFullscreen: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => { closeRef.current?.focus(); }, []);
  const game = gameRef.current;
  if (!game) return null;

  const weapons: { id: WeaponKind; label: string; key: string; available: boolean }[] = [
    { id: 'fist', label: 'FIST', key: '1', available: true },
    { id: 'pistol', label: 'PISTOL', key: '2', available: true },
    { id: 'rifle', label: 'RIFLE', key: '3', available: game.player.hasRifle },
    { id: 'nunchaku', label: 'NUNCHAKU', key: '4', available: game.player.hasNunchaku },
    { id: 'katana', label: 'KATANA', key: '5', available: game.player.hasKatana },
    { id: 'axe', label: 'AXE', key: '6', available: game.player.hasAxe },
    { id: 'dual', label: 'DUAL', key: '7', available: game.player.hasDual },
    { id: 'bat', label: 'BASEBALL', key: 'T', available: true },
    { id: 'yoyo', label: 'YO-YO', key: '8', available: true },
    { id: 'takamura', label: 'TAKAMURA', key: '9', available: true },
    { id: 'hayabusa', label: 'HAYABUSA', key: '0', available: true },
    { id: 'boxing', label: 'BOXING', key: 'J', available: true },
  ];

  return <div className="game-setup-backdrop" role="dialog" aria-modal="true" aria-labelledby="setup-title" onMouseDown={(event) => event.stopPropagation()}>
    <div className="game-setup pixel">
      <div className="game-setup__header">
        <div><span>GAME DIJEDA</span><h2 id="setup-title">SENJATA &amp; KONTROL</h2></div>
        <button ref={closeRef} type="button" onClick={close} aria-label="Tutup pengaturan"><X size={17} /></button>
      </div>
      <div className="setup-label">PILIH SENJATA</div>
      <div className="weapon-grid">
        {weapons.map((weapon) => <button key={weapon.id} type="button" disabled={!weapon.available} aria-pressed={ui.weapon === weapon.id} onClick={() => game.setWeapon(weapon.id)}>
          <span>{weapon.label}</span><small>{weapon.key}</small>
        </button>)}
      </div>
      <div className="setup-versions">
        <div className="setup-version" role="group" aria-label="Gaya boxing">
          <span>BOXING</span>
          {(['ali', 'tyson', 'ippo'] as const).map((st) => <button key={st} type="button" aria-pressed={ui.weapon === 'boxing' && ui.boxStance === st} onClick={() => game.selectBoxStance(st)}>{st === 'ali' ? 'ALI' : st === 'tyson' ? 'TYSON' : 'IPPO'}</button>)}
        </div>
        <div className="setup-version" role="group" aria-label="Versi nunchaku">
          <span>NUNCHAKU</span>
          {(['v1', 'v2', 'v3'] as const).map((version) => <button key={version} type="button" disabled={!ui.hasNunchaku} aria-pressed={ui.weapon === 'nunchaku' && ui.nunStyle === version} onClick={() => game.selectNunStyle(version)}>{version === 'v3' ? 'V3 API' : version.toUpperCase()}</button>)}
        </div>
        <div className="setup-version" role="group" aria-label="Versi yo-yo">
          <span>YO-YO</span>
          {([1, 2] as const).map((version) => <button key={version} type="button" aria-pressed={ui.weapon === 'yoyo' && ui.yoyoVer === version} onClick={() => game.selectYoyoVersion(version)}>V{version}</button>)}
          <label>SKIN <select aria-label="Skin yo-yo V2" value={ui.yoyoSkin} onChange={(event) => { if (isYoyoSkinId(event.target.value)) { game.setYoyoSkin(event.target.value); game.selectYoyoVersion(2); } }}>{YOYO_SKINS.map((skin) => <option key={skin.id} value={skin.id}>{skin.name}</option>)}</select></label>
        </div>
      </div>
      <div className="setup-options">
        <button type="button" onClick={() => game.toggleMute()}>{ui.muted ? 'SUARA: MATI' : 'SUARA: NYALA'}</button>
        <button type="button" onClick={() => setShowTouch(!showTouch)} aria-pressed={showTouch}>SENTUH: {showTouch ? 'NYALA' : 'MATI'}</button>
        <button type="button" onClick={() => game.toggleV2()}>GRAFIK: {ui.v2 ? 'V2' : 'V1'}</button>
        <button type="button" onClick={() => game.toggleLong()}>LONG: {ui.long ? 'NYALA' : 'MATI'}</button>
        <button type="button" onClick={toggleFullscreen} disabled={!document.fullscreenEnabled && !fullscreen}>{fullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />} {fullscreen ? 'KECILKAN' : 'LAYAR PENUH'}</button>
      </div>
      <div className="setup-help">WASD GERAK / KLIK SERANG / SPACE LOMPAT / G AKSI / ESC JEDA</div>
      <div className="setup-actions">
        <button type="button" className="setup-resume" onClick={close}>KEMBALI</button>
        <button type="button" onClick={restart}>ULANGI</button>
        <button type="button" onClick={quit}>MENU AWAL</button>
      </div>
    </div>
  </div>;
}

function Overlay({ children, dim = 'bg-black/40' }: { children: ReactNode; dim?: string }) {
  return (
    <div className={`absolute inset-0 overflow-y-auto ${dim} cursor-default`}>
      <div className="min-h-full py-[1em] flex items-center justify-center w-full">{children}</div>
    </div>
  );
}

function Btn({ children, onClick, primary, accent }: { children: ReactNode; onClick: () => void; primary?: boolean; accent: string }) {
  return (
    <button
      onClick={onClick}
      className={`pixel text-[0.7em] px-[1.2em] py-[0.7em] border-[0.15em] transition-all cursor-pointer hover:translate-x-[0.1em] hover:-translate-y-[0.1em] active:translate-y-0 ${primary ? 'text-black' : 'text-white bg-black/60 hover:bg-white/10'}`}
      style={primary ? { background: accent, borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' } : { borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' }}
    >
      {children}
    </button>
  );
}

function Stats({ ui }: { ui: UIState }) {
  return (
    <div className="grid grid-cols-2 gap-x-[2em] gap-y-[0.3em] pixel text-[0.6em] text-white/80 bg-black/50 p-[1em] border border-white/20">
      <span className="text-white/50">SCORE</span><span>{ui.score}</span>
      <span className="text-white/50">KILLS</span><span>{ui.kills}</span>
      <span className="text-white/50">BEST COMBO</span><span>{ui.bestCombo}</span>
      <span className="text-white/50">DEATHS</span><span>{ui.deaths}</span>
      <span className="text-white/50">MUTATIONS</span><span>{ui.mutations.length}</span>
      {ui.mode === 'survival' ? <><span className="text-white/50">WAVES</span><span>{ui.wave}</span></> : <><span className="text-white/50">BEST LEVEL</span><span>{ui.best.level}</span></>}
    </div>
  );
}

function Controls({ compact }: { compact?: boolean }) {
  return (
    <div className={`grid ${compact ? 'grid-cols-2 gap-x-[2em]' : 'grid-cols-1 sm:grid-cols-2 gap-x-[2em]'} gap-y-[0.25em] pixel text-[0.5em] text-left bg-black/60 border border-white/15 p-[1em] max-w-[52em]`}>
      <div className="text-white/40 col-span-full mb-[0.3em]">CONTROLS</div>
      <Row k="G (FIST / BAT / NUNCHAKU)" v="SILAT ACTION SCENE NEAR AN ENEMY" />
      <Row k="T" v="SELECT BASEBALL BAT / TAUNT WHEN EQUIPPED" />
      <Row k="4 / N" v="NUNCHAKU / SWITCH V1 AND V2" />
      <Row k="WASD" v="MOVE (HOLD TO RUN)" /><Row k="MOUSE" v="AIM" />
      <Row k="LMB" v="LIGHT ATTACK / SHOOT" /><Row k="RMB" v="HEAVY (PALM STRIKE)" />
      <Row k="RUN + LMB (FISTS)" v="TAEKWONDO FLYING SIDE KICK" /><Row k="RUN + RMB (FISTS)" v="MK FLYING KICK / RUNNING STRAIGHT" />
      <Row k="RUN + LMB (WEAPON)" v="DRAGON LASH / IAIJUTSU / GRAND SLAM / PHANTOM CROSS" />
      <Row k="SPACE (AIR) + LMB" v="DIVE KICK" />
      <Row k="SPACE" v="JUMP (HOP OVER BULLETS)" /><Row k="SHIFT" v="SHADOW STEP (DASH, I-FRAMES)" />
      <Row k="C" v="PARRY" />
      <Row k="E" v="FOCUS STRIKE" /><Row k="F" v="FATALITY (ANY ENEMY IN REACH)" />
      <Row k="X" v="ONE FOR ALL (AT 25+ CHARGE): WORLD SLOWS TO 30%, YOU RUN AT REAL TIME, STRIKES AUTO-LOCK" />
      <Row k="CLICK TEMPO (FISTS)" v="FAST = WING CHUN  /  MEDIUM = BLACK LEG KICKS  /  SLOW = KUNG FU HEAVIES" /><Row k="R" v="RAGE (WHEN METER FULL): LMB = DASH + EXECUTE" />
            <Row k="Q / 1-9-0 / WHEEL" v="FIST / PISTOL / RIFLE / NUNCHAKU / KATANA / AXE / DUAL / YOYO / TAKAMURA / HAYABUSA" />
      <Row k="HAYABUSA (0) LMB" v="NINJA CHAIN: MOON SLASH > REVERSE FLOW > AERIAL RAVE > IZUNA DROP (TAP TO FLOW · THE BLADE ITSELF HITS)" />
      <Row k="HAYABUSA (0) RMB" v="TAP = BLADE MODE (SLOW-MO, 3 PRECISE CUTS, THEN ZANDATSU — PETALS, NO LIGHTNING) · HOLD = FLYING SWALLOW DASH-CUT" />
      <Row k="AXE (6) RMB" v="IDLE/WALK = THROW (FLIES, HITS, RETURNS TO YOUR HAND) · RMB AGAIN = RECALL EARLY" />
      <Row k="AXE (6) SHIFT+RMB" v="LEAP SMASH: JUMP THEN CHOP STRAIGHT DOWN (SHOCKWAVE + FROST). IF THE AXE IS OUT IT RACES BACK SO YOU SLAM WITH IT" />
      <Row k="TAKAMURA (9) LMB" v="SWORD CHAIN: BATTOUJUTSU > KESA X-CUT > CHAMPLOO SPIN > RYU TSUI SEN (TAP AGAIN AFTER A CUT TO FLOW INTO THE NEXT · THE BLADE ITSELF DOES THE HITTING)" />
      <Row k="TAKAMURA (9) RMB" v="TAP = RYU SHO SEN (RISING CUT, LAUNCHES) · HOLD + RELEASE = AMAKAKERU RYU NO HIRAMEKI (TWO HUGE CUTS, STRONGER THE LONGER YOU HOLD)" />
      <Row k="TAKAMURA (9) NOTO" v="EVERY ENEMY YOU CUT IS MARKED · WHEN THE BLADE CLICKS BACK INTO THE SAYA THE DELAYED CUTS LAND" />
      <Row k="B" v="BLOOD: NORMAL / GORE / COMBINED" /><Row k="ESC" v="PAUSE" />
      <Row k="V" v="SWITCH LOOK: V2 = CRISP PIXELS + GAME1 RAGDOLL (WALL BOUNCE, DIZZY STARS, KICKABLE BODIES) / V1 = CLASSIC BUILD" />
      {!compact && (
        <>
          <div className="text-white/40 col-span-full mt-[0.8em] mb-[0.3em]">KUNG FU TECHNIQUES</div>
          {MOVE_LIST.map((m) => (
            <div key={m.name} className="col-span-full flex gap-[1em] leading-relaxed">
              <span className="text-yellow-300 min-w-[9em]">{m.keys}</span>
              <span className="text-white">{m.name}</span>
              <span className="text-white/50">{m.desc}</span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-[1em]">
      <span className="text-yellow-300 min-w-[9em]">{k}</span>
      <span className="text-white/80">{v}</span>
    </div>
  );
}

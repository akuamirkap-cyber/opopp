import type { Pose } from './types';

export type Limb = 'fhand' | 'bhand' | 'ffoot' | 'bfoot' | 'both' | 'body' | 'nunchaku' | 'sweep' | 'blade' | 'blade2' | 'yoyo';

export interface Move {
  id: string;
  name: string;
  pose: Pose;
  dmg: number;
  structure: number;
  range: number;
  arc: number;
  windup: number;
  active: number;
  recover: number;
  kb: number;
  knockdown: boolean;
  lunge: number;
  hitstop: number;
  shake: number;
  sfx: 'punch' | 'kick' | 'heavy' | 'nunchaku' | 'yoyo' | 'slash' | 'axe' | 'dual';
  /** which skeleton joint carries the hitbox (hit tests use the real animated joint position) */
  limb: Limb;
  /** hitbox radius around the striking joint, px */
  hitR: number;
  launch?: number;
  finisher?: boolean;
  showName?: boolean;
  travel?: number;
  jump?: number;
  trail?: boolean;
  air?: boolean;
  /** multi-hit: minimum seconds between hits on the same target */
  rehit?: number;
  nunchaku?: boolean;
  yoyo?: boolean;
  orbit?: boolean;
  katana?: boolean;
  axe?: boolean;
  bat?: boolean;
  dual?: boolean;
  /** blade arc (radians) swept during the active frames: from -> to relative to aim, times facing */
  slash?: { from: number; to: number; r: number; lift?: number };
  bleed?: boolean;
}

// ============================== KUNG FU (fists) ==============================
// Sifu-style tree. Keys are input sequences: L = light (LMB), H = heavy (RMB).
export const MOVES: Record<string, Move> = {
  L: { id: 'jab', name: 'JAB', pose: 'jab', dmg: 2, structure: 8, range: 17, arc: 1.1, windup: 0.05, active: 0.09, recover: 0.1, kb: 70, knockdown: false, lunge: 60, hitstop: 0.035, shake: 0.18, sfx: 'punch', limb: 'fhand', hitR: 3.8, trail: true },
  LL: { id: 'cross', name: 'CROSS', pose: 'cross', dmg: 2, structure: 10, range: 18, arc: 1.1, windup: 0.06, active: 0.09, recover: 0.12, kb: 100, knockdown: false, lunge: 80, hitstop: 0.04, shake: 0.2, sfx: 'punch', limb: 'bhand', hitR: 3.8, trail: true },
  LLL: { id: 'hook', name: 'HOOK', pose: 'hook', dmg: 3, structure: 14, range: 17, arc: 1.4, windup: 0.08, active: 0.1, recover: 0.14, kb: 130, knockdown: false, lunge: 70, hitstop: 0.05, shake: 0.28, sfx: 'kick', limb: 'bhand', hitR: 5, trail: true },
  LLLL: { id: 'roundhouse', name: 'ROUNDHOUSE', pose: 'roundhouse', dmg: 5, structure: 22, range: 23, arc: 1.7, windup: 0.11, active: 0.13, recover: 0.26, kb: 300, knockdown: true, lunge: 50, hitstop: 0.08, shake: 0.5, sfx: 'heavy', limb: 'ffoot', hitR: 6, launch: 50, trail: true, finisher: true, showName: true },
  LLLLL: { id: 'dragontail', name: 'DRAGON TAIL', pose: 'dragontail', dmg: 7, structure: 40, range: 26, arc: Math.PI, windup: 0.1, active: 0.2, recover: 0.3, kb: 420, knockdown: true, lunge: 30, hitstop: 0.1, shake: 0.8, sfx: 'heavy', limb: 'bfoot', hitR: 6.5, launch: 90, trail: true, finisher: true, showName: true },
  H: { id: 'palm', name: 'PALM STRIKE', pose: 'palm', dmg: 3, structure: 28, range: 19, arc: 1.0, windup: 0.13, active: 0.11, recover: 0.28, kb: 420, knockdown: false, lunge: 110, hitstop: 0.07, shake: 0.45, sfx: 'heavy', limb: 'both', hitR: 5.5, showName: true, trail: true },
  LH: { id: 'elbow', name: 'ELBOW SMASH', pose: 'elbow', dmg: 4, structure: 32, range: 17, arc: 1.2, windup: 0.08, active: 0.1, recover: 0.2, kb: 100, knockdown: false, lunge: 150, hitstop: 0.06, shake: 0.35, sfx: 'kick', limb: 'bhand', hitR: 5, trail: true, showName: true },
  LLH: { id: 'sweep', name: 'SWEEP KICK', pose: 'sweep', dmg: 3, structure: 20, range: 26, arc: Math.PI, windup: 0.11, active: 0.18, recover: 0.3, kb: 140, knockdown: true, lunge: 0, hitstop: 0.06, shake: 0.4, sfx: 'heavy', limb: 'sweep', hitR: 6, trail: true, showName: true },
  LLLH: { id: 'dragon', name: 'DRAGON UPPERCUT', pose: 'uppercut', dmg: 8, structure: 45, range: 19, arc: 1.0, windup: 0.13, active: 0.11, recover: 0.38, kb: 120, knockdown: true, lunge: 70, hitstop: 0.1, shake: 0.7, sfx: 'heavy', limb: 'bhand', hitR: 6, launch: 200, finisher: true, showName: true },
  HL: { id: 'knee', name: 'KNEE STRIKE', pose: 'knee', dmg: 4, structure: 30, range: 16, arc: 1.0, windup: 0.07, active: 0.11, recover: 0.18, kb: 160, knockdown: false, lunge: 170, hitstop: 0.06, shake: 0.35, sfx: 'kick', limb: 'ffoot', hitR: 5.5, launch: 40, showName: true },
  HLL: { id: 'axekick', name: 'AXE KICK', pose: 'axekick', dmg: 7, structure: 50, range: 20, arc: 0.9, windup: 0.16, active: 0.1, recover: 0.34, kb: 90, knockdown: true, lunge: 60, hitstop: 0.11, shake: 0.8, sfx: 'heavy', limb: 'ffoot', hitR: 6.5, trail: true, finisher: true, showName: true },
  HLH: { id: 'monkeyflip', name: 'MONKEY FLIP KICK', pose: 'monkeyflip', dmg: 8, structure: 44, range: 22, arc: 1.1, windup: 0.12, active: 0.18, recover: 0.36, kb: 260, knockdown: true, lunge: 40, hitstop: 0.11, shake: 0.8, sfx: 'heavy', limb: 'ffoot', hitR: 6.5, launch: 240, jump: 14, trail: true, finisher: true, showName: true },
  HH: { id: 'spinback', name: 'SPINNING BACKFIST', pose: 'spinback', dmg: 6, structure: 36, range: 22, arc: Math.PI, windup: 0.12, active: 0.26, recover: 0.26, kb: 340, knockdown: true, lunge: 40, hitstop: 0.09, shake: 0.6, sfx: 'heavy', limb: 'bhand', hitR: 7, trail: true, finisher: true, showName: true },
  HHL: { id: 'cranekick', name: 'CRANE KICK', pose: 'cranekick', dmg: 9, structure: 55, range: 24, arc: 0.9, windup: 0.22, active: 0.1, recover: 0.4, kb: 520, knockdown: true, lunge: 120, hitstop: 0.13, shake: 0.9, sfx: 'heavy', limb: 'ffoot', hitR: 7, launch: 120, finisher: true, showName: true },
  LHL: { id: 'doublepalm', name: 'TWIN PALM', pose: 'palm', dmg: 5, structure: 40, range: 19, arc: 1.0, windup: 0.1, active: 0.1, recover: 0.26, kb: 520, knockdown: true, lunge: 140, hitstop: 0.09, shake: 0.6, sfx: 'heavy', limb: 'both', hitR: 6, finisher: true, showName: true },
  LHH: { id: 'tigerclaw', name: 'TIGER CLAW', pose: 'tigerclaw', dmg: 6, structure: 34, range: 18, arc: 1.1, windup: 0.09, active: 0.14, recover: 0.26, kb: 180, knockdown: false, lunge: 110, hitstop: 0.08, shake: 0.5, sfx: 'kick', limb: 'both', hitR: 6, rehit: 0.07, bleed: true, finisher: true, showName: true },
  LLLLH: { id: 'mantis', name: 'MANTIS STRIKE', pose: 'mantis', dmg: 10, structure: 80, range: 20, arc: 0.9, windup: 0.18, active: 0.1, recover: 0.42, kb: 80, knockdown: false, lunge: 100, hitstop: 0.14, shake: 0.9, sfx: 'heavy', limb: 'fhand', hitR: 5, finisher: true, showName: true },
  DASH: { id: 'flying', name: 'FLYING KICK', pose: 'flying', dmg: 6, structure: 30, range: 20, arc: 1.0, windup: 0.05, active: 0.3, recover: 0.22, kb: 400, knockdown: true, lunge: 0, hitstop: 0.08, shake: 0.55, sfx: 'heavy', limb: 'ffoot', hitR: 6, launch: 70, travel: 330, jump: 10, finisher: true, showName: true },
  RUNPUNCH: { id: 'runpunch', name: 'RUNNING STRAIGHT', pose: 'runpunch', dmg: 6, structure: 30, range: 20, arc: 1.0, windup: 0.06, active: 0.22, recover: 0.26, kb: 440, knockdown: true, lunge: 0, hitstop: 0.08, shake: 0.5, sfx: 'heavy', limb: 'bhand', hitR: 6, travel: 300, finisher: true, showName: true },
  TKD: { id: 'tkd', name: 'TAEKWONDO SIDE KICK', pose: 'sidekick', dmg: 8, structure: 40, range: 24, arc: 1.0, windup: 0.08, active: 0.34, recover: 0.3, kb: 560, knockdown: true, lunge: 0, hitstop: 0.11, shake: 0.7, sfx: 'heavy', limb: 'ffoot', hitR: 6.5, launch: 90, travel: 360, jump: 16, finisher: true, showName: true },
  AIR: { id: 'divekick', name: 'DIVE KICK', pose: 'flying', dmg: 5, structure: 26, range: 22, arc: 1.2, windup: 0.03, active: 0.26, recover: 0.2, kb: 260, knockdown: true, lunge: 0, hitstop: 0.07, shake: 0.5, sfx: 'heavy', limb: 'ffoot', hitR: 7, launch: 40, travel: 340, finisher: true, showName: true, air: true },
  // ---- BLACK LEG (Sanji): a rolling kick flow built by MEDIUM rhythm (0.3-0.6s between clicks). Each click = next kick.
  S1: { id: 's_collier', name: 'COLLIER', pose: 's_collier', dmg: 4, structure: 18, range: 24, arc: 1.2, windup: 0.06, active: 0.1, recover: 0.12, kb: 160, knockdown: false, lunge: 90, hitstop: 0.05, shake: 0.3, sfx: 'kick', limb: 'ffoot', hitR: 5.5, trail: true },
  S2: { id: 's_epaule', name: 'EPAULE', pose: 's_epaule', dmg: 4, structure: 20, range: 24, arc: 1.2, windup: 0.06, active: 0.1, recover: 0.12, kb: 180, knockdown: false, lunge: 80, hitstop: 0.05, shake: 0.3, sfx: 'kick', limb: 'ffoot', hitR: 5.5, trail: true },
  S3: { id: 's_cotelette', name: 'COTELETTE', pose: 's_cotelette', dmg: 4, structure: 20, range: 22, arc: 1.3, windup: 0.06, active: 0.1, recover: 0.12, kb: 190, knockdown: false, lunge: 80, hitstop: 0.05, shake: 0.32, sfx: 'kick', limb: 'bfoot', hitR: 5.5, trail: true },
  S4: { id: 's_antimanner', name: 'ANTI-MANNER KICK COURSE', pose: 's_antimanner', dmg: 6, structure: 32, range: 25, arc: 1.3, windup: 0.08, active: 0.12, recover: 0.16, kb: 260, knockdown: false, lunge: 110, hitstop: 0.07, shake: 0.45, sfx: 'heavy', limb: 'ffoot', hitR: 6, trail: true, showName: true },
  S5: { id: 's_mouton', name: 'MOUTON SHOT', pose: 's_mouton', dmg: 9, structure: 50, range: 26, arc: 1.2, windup: 0.1, active: 0.12, recover: 0.3, kb: 620, knockdown: true, lunge: 140, hitstop: 0.12, shake: 0.9, sfx: 'heavy', limb: 'ffoot', hitR: 6.5, launch: 60, trail: true, finisher: true, showName: true },
  S6: { id: 's_concasse', name: 'CONCASSE', pose: 's_concasse', dmg: 10, structure: 70, range: 24, arc: 1.0, windup: 0.14, active: 0.1, recover: 0.34, kb: 160, knockdown: true, lunge: 60, hitstop: 0.13, shake: 1.0, sfx: 'heavy', limb: 'ffoot', hitR: 6.5, jump: 12, trail: true, finisher: true, showName: true },
  S7: { id: 's_partytable', name: 'PARTY TABLE KICK COURSE', pose: 's_partyTable', dmg: 5, structure: 24, range: 30, arc: Math.PI, windup: 0.1, active: 0.5, recover: 0.3, kb: 300, knockdown: true, lunge: 0, hitstop: 0.05, shake: 0.5, sfx: 'kick', limb: 'ffoot', hitR: 6, trail: true, rehit: 0.14, finisher: true, showName: true },
  S8: { id: 's_diable', name: 'DIABLE JAMBE', pose: 's_diable', dmg: 16, structure: 120, range: 28, arc: 1.1, windup: 0.16, active: 0.14, recover: 0.4, kb: 760, knockdown: true, lunge: 180, hitstop: 0.16, shake: 1.2, sfx: 'heavy', limb: 'ffoot', hitR: 7.5, launch: 140, trail: true, finisher: true, showName: true },
  // ---- KUNG FU heavy flow (SLOW rhythm 0.6-1.0s): iron palm / hammer fist additions
  KF1: { id: 'k_ironpalm', name: 'IRON PALM', pose: 'k_ironpalm', dmg: 8, structure: 55, range: 20, arc: 1.0, windup: 0.16, active: 0.1, recover: 0.3, kb: 520, knockdown: true, lunge: 120, hitstop: 0.12, shake: 0.8, sfx: 'heavy', limb: 'fhand', hitR: 6, showName: true },
  KF2: { id: 'k_hammerfist', name: 'HAMMER FIST', pose: 'k_hammerfist', dmg: 9, structure: 70, range: 18, arc: 1.0, windup: 0.18, active: 0.1, recover: 0.34, kb: 140, knockdown: true, lunge: 100, hitstop: 0.13, shake: 0.9, sfx: 'heavy', limb: 'bhand', hitR: 6, showName: true },
  // ---- WING CHUN chain punch: rapid alternating vertical fists; spamming LMB in rhythm (0.1-0.4s) keeps the chain unbroken
  CHAIN: { id: 'chain', name: 'CHAIN PUNCH', pose: 'chainpunch', dmg: 1.4, structure: 7, range: 17, arc: 1.0, windup: 0.02, active: 0.06, recover: 0.05, kb: 25, knockdown: false, lunge: 50, hitstop: 0.018, shake: 0.1, sfx: 'punch', limb: 'fhand', hitR: 4.5 },
  // the chain's finishing blow: fires automatically when the target is almost dead (or on a long chain)
  CHAINEND: { id: 'chainend', name: 'WING CHUN FINISH', pose: 'chainfinish', dmg: 9, structure: 60, range: 20, arc: 1.0, windup: 0.08, active: 0.1, recover: 0.3, kb: 560, knockdown: true, lunge: 120, hitstop: 0.12, shake: 0.9, sfx: 'heavy', limb: 'both', hitR: 6, launch: 60, finisher: true, showName: true },
  // RAGE execution strike (after the rage dash): instant, lethal to normal enemies
  RAGEKILL: { id: 'ragekill', name: 'RAGE', pose: 'ragekill', dmg: 30, structure: 999, range: 22, arc: 1.4, windup: 0.03, active: 0.08, recover: 0.12, kb: 520, knockdown: true, lunge: 0, hitstop: 0.06, shake: 0.6, sfx: 'heavy', limb: 'bhand', hitR: 7, finisher: true },
  FOCUS: { id: 'focus', name: 'DRAGON PALM', pose: 'palm', dmg: 14, structure: 999, range: 24, arc: 1.4, windup: 0.06, active: 0.12, recover: 0.3, kb: 460, knockdown: true, lunge: 0, hitstop: 0.14, shake: 0.9, sfx: 'heavy', limb: 'both', hitR: 9, launch: 120, finisher: true, showName: true },

  // ============================== NUNCHAKU ==============================
  // The striking end of the chain IS the hitbox (physics-driven), so these moves hit exactly where the weapon is.
  // ---- Bruce Lee TRIANGLE COMBO: from the underarm tuck -> diagonal down-left strike -> bounce up to the left shoulder
  //      -> horizontal chest sweep back right -> catch & lock under the right armpit (an imaginary triangle in front of the body)
  NL: { id: 'n_tri1', name: 'TRIANGLE: DIAGONAL', pose: 'n_tri1', dmg: 4, structure: 18, range: 24, arc: 1.4, windup: 0.06, active: 0.12, recover: 0.1, kb: 110, knockdown: false, lunge: 70, hitstop: 0.045, shake: 0.25, sfx: 'nunchaku', limb: 'nunchaku', hitR: 4.5, nunchaku: true },
  NLL: { id: 'n_tri2', name: 'TRIANGLE: SHOULDER BOUNCE', pose: 'n_tri2', dmg: 3, structure: 16, range: 24, arc: 1.4, windup: 0.05, active: 0.14, recover: 0.1, kb: 100, knockdown: false, lunge: 80, hitstop: 0.04, shake: 0.22, sfx: 'nunchaku', limb: 'nunchaku', hitR: 4.5, nunchaku: true },
  NLLL: { id: 'n_tri3', name: 'TRIANGLE: CHEST SWEEP', pose: 'n_tri3', dmg: 5, structure: 26, range: 26, arc: 1.6, windup: 0.05, active: 0.14, recover: 0.1, kb: 180, knockdown: false, lunge: 60, hitstop: 0.06, shake: 0.35, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5, nunchaku: true, showName: true },
  NLLLL: { id: 'n_tri4', name: 'TRIANGLE: CATCH & LOCK', pose: 'n_tri4', dmg: 7, structure: 45, range: 22, arc: 1.2, windup: 0.08, active: 0.12, recover: 0.26, kb: 260, knockdown: true, lunge: 50, hitstop: 0.1, shake: 0.7, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5.5, nunchaku: true, finisher: true, showName: true },
  NLLLLL: { id: 'n_overhead', name: 'SKULL CRACKER', pose: 'n_overhead', dmg: 9, structure: 55, range: 26, arc: 1.0, windup: 0.14, active: 0.1, recover: 0.3, kb: 220, knockdown: true, lunge: 80, hitstop: 0.11, shake: 0.8, sfx: 'nunchaku', limb: 'nunchaku', hitR: 6, nunchaku: true, finisher: true, showName: true },
  NH: { id: 'n_helicopter', name: 'HELICOPTER', pose: 'n_helicopter', dmg: 2, structure: 12, range: 28, arc: Math.PI, windup: 0.08, active: 0.55, recover: 0.2, kb: 150, knockdown: false, lunge: 0, hitstop: 0.03, shake: 0.2, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5, nunchaku: true, rehit: 0.14, showName: true },
  NLH: { id: 'n_whipcrack', name: 'WHIP CRACK', pose: 'n_whipcrack', dmg: 6, structure: 40, range: 32, arc: 0.9, windup: 0.12, active: 0.1, recover: 0.26, kb: 360, knockdown: true, lunge: 40, hitstop: 0.09, shake: 0.6, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5.5, nunchaku: true, finisher: true, showName: true },
  NLLH: { id: 'n_choke', name: 'CHAIN CHOKE SLAM', pose: 'n_choke', dmg: 9, structure: 70, range: 20, arc: 0.9, windup: 0.14, active: 0.14, recover: 0.36, kb: 500, knockdown: true, lunge: 90, hitstop: 0.12, shake: 0.9, sfx: 'nunchaku', limb: 'nunchaku', hitR: 6, nunchaku: true, launch: 60, finisher: true, showName: true },
  NHL: { id: 'n_lowsweep', name: 'ANKLE BREAKER', pose: 'n_lowsweep', dmg: 4, structure: 30, range: 26, arc: Math.PI, windup: 0.1, active: 0.2, recover: 0.26, kb: 160, knockdown: true, lunge: 0, hitstop: 0.06, shake: 0.4, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5.5, nunchaku: true, rehit: 0.2, showName: true },
  NHH: { id: 'n_tornado', name: 'TORNADO', pose: 'n_tornado', dmg: 3, structure: 18, range: 30, arc: Math.PI, windup: 0.1, active: 0.7, recover: 0.3, kb: 220, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.3, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5.5, nunchaku: true, rehit: 0.12, launch: 50, finisher: true, showName: true },
  // RUN + LMB with the nunchaku: the lethal charging strike (replaces the taekwondo kick while the nunchaku is out)
  NRUN: { id: 'n_dragonlash', name: 'DRAGON LASH', pose: 'n_dragonlash', dmg: 12, structure: 90, range: 30, arc: 1.0, windup: 0.08, active: 0.34, recover: 0.3, kb: 620, knockdown: true, lunge: 0, hitstop: 0.13, shake: 0.9, sfx: 'nunchaku', limb: 'nunchaku', hitR: 7, nunchaku: true, launch: 140, travel: 360, jump: 8, rehit: 0.18, finisher: true, showName: true },
  NDASH: { id: 'n_flyspin', name: 'FLYING HELICOPTER', pose: 'n_helicopter', dmg: 3, structure: 16, range: 28, arc: Math.PI, windup: 0.05, active: 0.36, recover: 0.22, kb: 300, knockdown: true, lunge: 0, hitstop: 0.05, shake: 0.4, sfx: 'nunchaku', limb: 'nunchaku', hitR: 5.5, nunchaku: true, rehit: 0.12, travel: 300, jump: 10, finisher: true, showName: true },


  // YOYO V2: freestyle system transferred from MAXKUNG.
  YL: { id: 'y_snap', name: 'TOPROCK THROW', pose: 'y2_toprock', dmg: 5, structure: 18, range: 78, arc: 1.2, windup: 0.04, active: 0.34, recover: 0.1, kb: 140, knockdown: false, lunge: 0, hitstop: 0.025, shake: 0.18, sfx: 'yoyo', limb: 'yoyo', hitR: 6, yoyo: true },
  YLL: { id: 'y_loop', name: 'CROSS STEP LOOP', pose: 'y2_crossstep', dmg: 6, structure: 23, range: 82, arc: 1.5, windup: 0.04, active: 0.38, recover: 0.1, kb: 170, knockdown: false, lunge: 0, hitstop: 0.03, shake: 0.22, sfx: 'yoyo', limb: 'yoyo', hitR: 7, yoyo: true, showName: true },
  YLLL: { id: 'y_dragon', name: 'WINDMILL WHIP', pose: 'y2_windmill', dmg: 10, structure: 45, range: 90, arc: 1.7, windup: 0.06, active: 0.48, recover: 0.16, kb: 300, knockdown: true, lunge: 0, hitstop: 0.05, shake: 0.4, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, launch: 70, showName: true, trail: true },
  YLLLL: { id: 'y_trapeze', name: 'ONE HAND FREEZE', pose: 'y2_freeze', dmg: 8, structure: 35, range: 86, arc: 1.9, windup: 0.05, active: 0.4, recover: 0.12, kb: 220, knockdown: false, lunge: 0, hitstop: 0.035, shake: 0.28, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, showName: true, trail: true },
  YLLLLL: { id: 'y_flare', name: 'B-BOY FLARE', pose: 'y2_spin', dmg: 5, structure: 24, range: 64, arc: Math.PI, windup: 0.06, active: 0.56, recover: 0.16, kb: 200, knockdown: true, lunge: 0, hitstop: 0.025, shake: 0.3, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, rehit: 0.24, finisher: true, showName: true, trail: true },
  YH: { id: 'y_orbit', name: 'BREAKDANCE ORBIT', pose: 'y2_spin', dmg: 3.5, structure: 15, range: 54, arc: Math.PI, windup: 0.06, active: 0.65, recover: 0.13, kb: 105, knockdown: false, lunge: 0, hitstop: 0.015, shake: 0.12, sfx: 'yoyo', limb: 'yoyo', hitR: 7, yoyo: true, rehit: 0.28, showName: true, trail: true },
  YLH: { id: 'y_trapeze', name: 'FREEZE TRAPEZE', pose: 'y2_freeze', dmg: 8, structure: 35, range: 85, arc: 1.9, windup: 0.05, active: 0.44, recover: 0.14, kb: 240, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.3, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, launch: 80, finisher: true, showName: true, trail: true },
  YLLH: { id: 'y_trapeze', name: 'FREEZE TRAPEZE', pose: 'y2_freeze', dmg: 9, structure: 40, range: 88, arc: 1.9, windup: 0.05, active: 0.44, recover: 0.14, kb: 260, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.3, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, launch: 90, finisher: true, showName: true, trail: true },
  YHL: { id: 'y_breakaway', name: 'WINDMILL BREAK', pose: 'y2_windmill', dmg: 8, structure: 32, range: 92, arc: 1.8, windup: 0.04, active: 0.44, recover: 0.12, kb: 220, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.3, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, finisher: true, showName: true, trail: true },
  YHH: { id: 'y_storm', name: 'FLARE STORM', pose: 'y2_spin', dmg: 4, structure: 18, range: 64, arc: Math.PI, windup: 0.06, active: 0.7, recover: 0.16, kb: 140, knockdown: false, lunge: 0, hitstop: 0.02, shake: 0.2, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, rehit: 0.24, finisher: true, showName: true, trail: true },
  YRUN: { id: 'y_rocket', name: 'SLIDE THROW', pose: 'y2_crossstep', dmg: 9, structure: 35, range: 96, arc: 1.4, windup: 0.04, active: 0.39, recover: 0.12, kb: 280, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.3, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, finisher: true, showName: true },
  YAIR: { id: 'y_air', name: 'AIR FLARE', pose: 'y2_airflip', dmg: 8, structure: 30, range: 85, arc: 1.5, windup: 0.04, active: 0.38, recover: 0.12, kb: 220, knockdown: true, lunge: 0, hitstop: 0.035, shake: 0.25, sfx: 'yoyo', limb: 'yoyo', hitR: 8, yoyo: true, showName: true, trail: true },

  // ============================== BASEBALL BAT (spam swings, streets-of-rage crack) ==============================
  BL: { id: 'b_chop', name: 'CHOP', pose: 'a_swing1', dmg: 4, structure: 16, range: 26, arc: 1.5, windup: 0.03, active: 0.10, recover: 0.07, kb: 220, knockdown: false, lunge: 70, hitstop: 0.045, shake: 0.35, sfx: 'axe', limb: 'blade', hitR: 5.5, bat: true, slash: { from: -2.2, to: 0.9, r: 19 } },
  BLL: { id: 'b_back', name: 'BACKHAND', pose: 'a_swing2', dmg: 4, structure: 16, range: 26, arc: 1.5, windup: 0.03, active: 0.10, recover: 0.07, kb: 240, knockdown: false, lunge: 60, hitstop: 0.045, shake: 0.35, sfx: 'axe', limb: 'blade', hitR: 5.5, bat: true, slash: { from: 2.2, to: -0.9, r: 19 } },
  BLLL: { id: 'b_golf', name: 'GOLF', pose: 'a_golf', dmg: 5, structure: 22, range: 27, arc: 1.3, windup: 0.04, active: 0.10, recover: 0.08, kb: 280, knockdown: true, lunge: 70, hitstop: 0.05, shake: 0.4, sfx: 'axe', limb: 'blade', hitR: 6, bat: true, launch: 40, slash: { from: 1.6, to: -1.4, r: 18, lift: 0.4 } },
  BLLLL: { id: 'b_homerun', name: 'HOME RUN', pose: 'a_homerun', dmg: 12, structure: 70, range: 32, arc: 1.7, windup: 0.08, active: 0.12, recover: 0.18, kb: 820, knockdown: true, lunge: 100, hitstop: 0.12, shake: 1.0, sfx: 'axe', limb: 'blade', hitR: 7, bat: true, launch: 180, finisher: true, showName: true, slash: { from: -2.5, to: 1.1, r: 22 } },
  BH: { id: 'b_spin', name: 'TORNADO BAT', pose: 'a_spin', dmg: 3.5, structure: 14, range: 30, arc: Math.PI, windup: 0.05, active: 0.55, recover: 0.12, kb: 260, knockdown: true, lunge: 0, hitstop: 0.03, shake: 0.3, sfx: 'axe', limb: 'blade', hitR: 6, bat: true, rehit: 0.12, showName: true, slash: { from: 0, to: 6.3, r: 20 } },
  BRUN: { id: 'b_grandslam', name: 'GRAND SLAM', pose: 'a_homerun', dmg: 14, structure: 90, range: 34, arc: 1.7, windup: 0.06, active: 0.22, recover: 0.22, kb: 900, knockdown: true, lunge: 0, hitstop: 0.14, shake: 1.15, sfx: 'axe', limb: 'blade', hitR: 7.5, bat: true, launch: 200, travel: 340, finisher: true, showName: true, slash: { from: -2.4, to: 1.2, r: 23 } },
  BDASH: { id: 'b_slide', name: 'SLIDE SWING', pose: 'a_swing1', dmg: 8, structure: 40, range: 28, arc: 1.5, windup: 0.03, active: 0.20, recover: 0.14, kb: 480, knockdown: true, lunge: 0, hitstop: 0.08, shake: 0.6, sfx: 'axe', limb: 'blade', hitR: 6.5, bat: true, travel: 300, slash: { from: -2.0, to: 1.0, r: 20 } },

  // ============================== KATANA ==============================
  // The blade sweeps an arc during the active frames; the hitbox is the swept blade segment (base->tip).
  KL: { id: 'k_draw', name: 'IAI DRAW', pose: 'k_draw', dmg: 6, structure: 20, range: 30, arc: 1.3, windup: 0.08, active: 0.08, recover: 0.16, kb: 160, knockdown: false, lunge: 150, hitstop: 0.07, shake: 0.35, sfx: 'slash', limb: 'blade', hitR: 3.5, katana: true, bleed: true, slash: { from: -1.4, to: 0.9, r: 18 } },
  KLL: { id: 'k_return', name: 'RETURN CUT', pose: 'k_return', dmg: 6, structure: 22, range: 30, arc: 1.3, windup: 0.07, active: 0.08, recover: 0.16, kb: 170, knockdown: false, lunge: 120, hitstop: 0.07, shake: 0.35, sfx: 'slash', limb: 'blade', hitR: 3.5, katana: true, bleed: true, slash: { from: 1.2, to: -1.0, r: 18 } },
  KLLL: { id: 'k_crescent', name: 'CRESCENT MOON', pose: 'k_crescent', dmg: 8, structure: 30, range: 32, arc: 2.0, windup: 0.1, active: 0.12, recover: 0.2, kb: 220, knockdown: true, lunge: 110, hitstop: 0.09, shake: 0.5, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, slash: { from: -2.2, to: 1.6, r: 20 }, finisher: false, showName: true },
  KLLLL: { id: 'k_heaven', name: 'HEAVEN SPLITTER', pose: 'k_heaven', dmg: 16, structure: 80, range: 32, arc: 0.9, windup: 0.2, active: 0.08, recover: 0.4, kb: 300, knockdown: true, lunge: 140, hitstop: 0.16, shake: 1, sfx: 'slash', limb: 'blade', hitR: 5, katana: true, bleed: true, slash: { from: 0, to: 0, r: 22, lift: 1 }, finisher: true, showName: true },
  KH: { id: 'k_thrust', name: 'LUNGING THRUST', pose: 'k_thrust', dmg: 10, structure: 40, range: 40, arc: 0.6, windup: 0.14, active: 0.16, recover: 0.3, kb: 380, knockdown: true, lunge: 220, hitstop: 0.11, shake: 0.7, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, slash: { from: 0, to: 0, r: 24 }, finisher: true, showName: true },
  KLH: { id: 'k_rising', name: 'RISING MOON', pose: 'k_rising', dmg: 9, structure: 50, range: 28, arc: 1.0, windup: 0.11, active: 0.1, recover: 0.3, kb: 140, knockdown: true, lunge: 90, hitstop: 0.11, shake: 0.7, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, slash: { from: 0.9, to: -1.9, r: 20, lift: 0.6 }, launch: 220, finisher: true, showName: true },
  KLLH: { id: 'k_whirlwind', name: 'WHIRLWIND', pose: 'k_whirlwind', dmg: 5, structure: 24, range: 34, arc: Math.PI, windup: 0.12, active: 0.4, recover: 0.32, kb: 260, knockdown: true, lunge: 0, hitstop: 0.06, shake: 0.5, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, rehit: 0.16, slash: { from: 0, to: Math.PI * 4, r: 21 }, finisher: true, showName: true },
  KHL: { id: 'k_thousand', name: 'THOUSAND CUTS', pose: 'k_thousand', dmg: 2, structure: 10, range: 30, arc: 1.1, windup: 0.06, active: 0.5, recover: 0.3, kb: 40, knockdown: false, lunge: 60, hitstop: 0.025, shake: 0.15, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, rehit: 0.07, slash: { from: -1.2, to: 1.2, r: 18 }, finisher: true, showName: true },
  KHH: { id: 'k_dragonfang', name: 'DRAGON FANG', pose: 'k_dragonfang', dmg: 14, structure: 70, range: 36, arc: 1.2, windup: 0.18, active: 0.14, recover: 0.42, kb: 480, knockdown: true, lunge: 60, hitstop: 0.15, shake: 1, sfx: 'slash', limb: 'blade', hitR: 5, katana: true, bleed: true, slash: { from: -2.4, to: 0.6, r: 24 }, launch: 80, finisher: true, showName: true },
  // RUN + LMB with the katana: the dash-through "one cut" (Iaijutsu)
  KRUN: { id: 'k_iaijutsu', name: 'IAIJUTSU', pose: 'k_iaijutsu', dmg: 18, structure: 120, range: 36, arc: 1.0, windup: 0.1, active: 0.26, recover: 0.5, kb: 120, knockdown: true, lunge: 0, hitstop: 0.0, shake: 0.3, sfx: 'slash', limb: 'blade', hitR: 6, katana: true, bleed: true, travel: 520, rehit: 0.3, slash: { from: 0, to: 0, r: 21 }, finisher: true, showName: true },
  KDASH: { id: 'k_dashcut', name: 'DASH CUT', pose: 'k_crescent', dmg: 9, structure: 36, range: 32, arc: 1.6, windup: 0.04, active: 0.24, recover: 0.24, kb: 280, knockdown: true, lunge: 0, hitstop: 0.09, shake: 0.5, sfx: 'slash', limb: 'blade', hitR: 4.5, katana: true, bleed: true, travel: 300, slash: { from: -2.0, to: 1.4, r: 20 }, finisher: true, showName: true },
  // V2 finisher: bilah melesat masuk sarung — ring putih + slow-mo sekejap ala panel manga Takamura
  KSHEATH: { id: 'k_sheatheflash', name: 'SHEATHE FLASH', pose: 'k_sheathe', dmg: 6, structure: 40, range: 26, arc: 2.6, windup: 0.05, active: 0.05, recover: 0.34, kb: 240, knockdown: true, lunge: 0, hitstop: 0.16, shake: 0.9, sfx: 'slash', limb: 'blade', hitR: 4, katana: true, bleed: true, slash: { from: -0.5, to: 0.5, r: 15 }, finisher: true, showName: true },
};

// ============================== AXE: baseball-bat swings (flat, hip-driven, follow-through) ==============================
Object.assign(MOVES, {
  // LMB chain: a slugger's combo. Every swing is a full horizontal bat swing with a load (wind-up), hip rotation, contact and follow-through.
  AL: { id: 'a_swing1', name: 'SWING', pose: 'a_swing1', dmg: 9, structure: 40, range: 28, arc: 1.5, windup: 0.14, active: 0.1, recover: 0.26, kb: 380, knockdown: true, lunge: 90, hitstop: 0.1, shake: 0.7, sfx: 'axe', limb: 'blade', hitR: 5.5, axe: true, bleed: true, slash: { from: -2.4, to: 0.9, r: 21 } },
  ALL: { id: 'a_swing2', name: 'BACKHAND', pose: 'a_swing2', dmg: 9, structure: 40, range: 28, arc: 1.5, windup: 0.12, active: 0.1, recover: 0.24, kb: 380, knockdown: true, lunge: 80, hitstop: 0.1, shake: 0.7, sfx: 'axe', limb: 'blade', hitR: 5.5, axe: true, bleed: true, slash: { from: 2.4, to: -0.9, r: 21 } },
  ALLL: { id: 'a_homerun', name: 'HOME RUN', pose: 'a_homerun', dmg: 16, structure: 90, range: 32, arc: 1.6, windup: 0.22, active: 0.1, recover: 0.4, kb: 760, knockdown: true, lunge: 120, hitstop: 0.16, shake: 1.2, sfx: 'axe', limb: 'blade', hitR: 6.5, axe: true, bleed: true, launch: 160, slash: { from: -2.8, to: 1.1, r: 24 }, finisher: true, showName: true },
  // RMB: a 720 spinning swing that keeps going
  AH: { id: 'a_spin', name: 'TORNADO SWING', pose: 'a_spin', dmg: 7, structure: 40, range: 32, arc: Math.PI, windup: 0.18, active: 0.56, recover: 0.4, kb: 420, knockdown: true, lunge: 0, hitstop: 0.08, shake: 0.7, sfx: 'axe', limb: 'blade', hitR: 6, axe: true, bleed: true, rehit: 0.22, slash: { from: 0, to: Math.PI * 4, r: 24 }, finisher: true, showName: true },
  // LMB, RMB: golf-swing upper: scoops the target off the floor into the air
  ALH: { id: 'a_golf', name: 'GOLF SWING', pose: 'a_golf', dmg: 11, structure: 60, range: 28, arc: 1.1, windup: 0.16, active: 0.1, recover: 0.36, kb: 200, knockdown: true, lunge: 70, hitstop: 0.12, shake: 0.9, sfx: 'axe', limb: 'blade', hitR: 6, axe: true, bleed: true, launch: 260, slash: { from: 1.2, to: -1.6, r: 22, lift: 0.5 }, finisher: true, showName: true },
  // LMB, LMB, RMB: the overhead chop (the only vertical one)
  ALLH: { id: 'a_overhead', name: 'SKULL SPLITTER', pose: 'a_overhead', dmg: 18, structure: 110, range: 28, arc: 0.9, windup: 0.26, active: 0.08, recover: 0.5, kb: 200, knockdown: true, lunge: 140, hitstop: 0.18, shake: 1.2, sfx: 'axe', limb: 'blade', hitR: 6.5, axe: true, bleed: true, slash: { from: 0, to: 0, r: 22, lift: 1.2 }, finisher: true, showName: true },
  // RMB, LMB: bunt - a short, fast jab with the haft that staggers
  AHL: { id: 'a_bunt', name: 'BUNT', pose: 'a_bunt', dmg: 5, structure: 55, range: 22, arc: 1.0, windup: 0.06, active: 0.1, recover: 0.16, kb: 240, knockdown: false, lunge: 110, hitstop: 0.06, shake: 0.4, sfx: 'axe', limb: 'blade', hitR: 5, axe: true, slash: { from: 0, to: 0, r: 18 }, showName: true },
  // RUN + LMB: grand slam - sprinting flat swing with a huge launch
  ARUN: { id: 'a_grandslam', name: 'GRAND SLAM', pose: 'a_homerun', dmg: 20, structure: 130, range: 34, arc: 1.6, windup: 0.1, active: 0.3, recover: 0.46, kb: 900, knockdown: true, lunge: 0, hitstop: 0.18, shake: 1.3, sfx: 'axe', limb: 'blade', hitR: 7, axe: true, bleed: true, launch: 200, travel: 300, slash: { from: -2.8, to: 1.1, r: 24 }, finisher: true, showName: true },
  ADASH: { id: 'a_dashswing', name: 'SLIDING SWING', pose: 'a_swing1', dmg: 12, structure: 60, range: 30, arc: 1.5, windup: 0.05, active: 0.24, recover: 0.36, kb: 460, knockdown: true, lunge: 0, hitstop: 0.12, shake: 0.8, sfx: 'axe', limb: 'blade', hitR: 6, axe: true, bleed: true, travel: 280, slash: { from: -2.4, to: 0.9, r: 21 }, finisher: true, showName: true },
  // ============================== DUAL BLADES (fast, flurry, two hitboxes) ==============================
  DL: { id: 'd_cross', name: 'CROSS CUT', pose: 'd_cross', dmg: 4, structure: 12, range: 24, arc: 1.3, windup: 0.04, active: 0.08, recover: 0.08, kb: 90, knockdown: false, lunge: 90, hitstop: 0.04, shake: 0.25, sfx: 'dual', limb: 'blade2', hitR: 3.5, dual: true, bleed: true, slash: { from: -1.2, to: 0.8, r: 16 } },
  DLL: { id: 'd_scissor', name: 'SCISSOR', pose: 'd_scissor', dmg: 5, structure: 16, range: 24, arc: 1.3, windup: 0.05, active: 0.08, recover: 0.09, kb: 120, knockdown: false, lunge: 90, hitstop: 0.05, shake: 0.3, sfx: 'dual', limb: 'blade2', hitR: 3.5, dual: true, bleed: true, slash: { from: 1.1, to: -0.9, r: 16 } },
  DLLL: { id: 'd_flurry', name: 'BLADE FLURRY', pose: 'd_flurry', dmg: 2, structure: 8, range: 24, arc: 1.2, windup: 0.05, active: 0.45, recover: 0.2, kb: 30, knockdown: false, lunge: 70, hitstop: 0.02, shake: 0.15, sfx: 'dual', limb: 'blade2', hitR: 3.5, dual: true, bleed: true, rehit: 0.06, slash: { from: -1.0, to: 1.0, r: 16 }, showName: true },
  DLLLL: { id: 'd_xslash', name: 'X-SLASH', pose: 'd_xslash', dmg: 12, structure: 50, range: 26, arc: 1.2, windup: 0.14, active: 0.1, recover: 0.3, kb: 300, knockdown: true, lunge: 120, hitstop: 0.12, shake: 0.8, sfx: 'dual', limb: 'blade2', hitR: 4.5, dual: true, bleed: true, slash: { from: -1.4, to: 1.4, r: 18 }, finisher: true, showName: true },
  DH: { id: 'd_dance', name: 'BLADE DANCE', pose: 'd_dance', dmg: 4, structure: 16, range: 28, arc: Math.PI, windup: 0.1, active: 0.6, recover: 0.3, kb: 200, knockdown: true, lunge: 0, hitstop: 0.04, shake: 0.4, sfx: 'dual', limb: 'blade2', hitR: 4, dual: true, bleed: true, rehit: 0.14, slash: { from: 0, to: Math.PI * 6, r: 18 }, finisher: true, showName: true },
  DLH: { id: 'd_launch', name: 'TWIN RISING', pose: 'd_launch', dmg: 9, structure: 40, range: 24, arc: 1.0, windup: 0.1, active: 0.12, recover: 0.3, kb: 120, knockdown: true, lunge: 140, hitstop: 0.1, shake: 0.7, sfx: 'dual', limb: 'blade2', hitR: 5, dual: true, bleed: true, launch: 220, slash: { from: 0.6, to: -1.2, r: 17, lift: 0.3 }, finisher: true, showName: true },
  DRUN: { id: 'd_dash', name: 'PHANTOM CROSS', pose: 'd_dash', dmg: 14, structure: 70, range: 30, arc: 1.0, windup: 0.08, active: 0.26, recover: 0.4, kb: 200, knockdown: true, lunge: 0, hitstop: 0.0, shake: 0.4, sfx: 'dual', limb: 'blade2', hitR: 5, dual: true, bleed: true, travel: 540, rehit: 0.3, slash: { from: 0, to: 0, r: 16 }, finisher: true, showName: true },
  DDASH: { id: 'd_dashcut', name: 'DASH SCISSOR', pose: 'd_scissor', dmg: 8, structure: 30, range: 26, arc: 1.4, windup: 0.04, active: 0.22, recover: 0.22, kb: 220, knockdown: true, lunge: 0, hitstop: 0.08, shake: 0.5, sfx: 'dual', limb: 'blade2', hitR: 4, dual: true, bleed: true, travel: 300, slash: { from: 1.3, to: -1.1, r: 16 }, finisher: true, showName: true },
} as Record<string, Move>);

export const MOVE_LIST: { keys: string; name: string; desc: string }[] = [
  { keys: '4 / N', name: 'NUNCHAKU V1 / V2', desc: 'Tekan 4 untuk memakai nunchaku dan N untuk berganti versi. V2 memakai rantai fisika serta kombo SWING, CROSS, SPIN, dan WHIP CRACK. Tahan klik kiri atau tekan berulang; klik kanan untuk WHIP CRACK.' },
  { keys: 'FIST / NUNCHAKU / BAT: G', name: 'ADEGAN AKSI SILAT', desc: 'Dekati musuh dan tekan G untuk memulai tangkapan, counter, atau adegan serangan. Serangan pada musuh yang lemah juga dapat memicu adegan otomatis.' },
  { keys: 'T: BASEBALL BAT', name: 'STREET BAT', desc: 'Tahan klik kiri untuk ayunan berantai, klik kanan untuk putaran, dan tekan T lagi untuk taunt. Serang musuh di udara untuk juggle.' },
  { keys: 'LMB x5', name: 'JAB > CROSS > HOOK > ROUNDHOUSE > DRAGON TAIL', desc: 'Light chain ending in a 360 launcher. Every hit lands where the fist/foot is.' },
  { keys: 'X', name: 'ONE FOR ALL (SLOW-MO SUPER)', desc: 'At 25+ charge, press X: the WORLD drops to 30% speed while you keep running at full real-time speed (about 4.4x faster than everything around you), the camera pulls back, lightning crackles off your body, and every strike AUTO-LOCKS and blinks to the nearest enemy. The meter burns for roughly 12.5 seconds on a full charge. Charge it by landing hits (damage x0.1), kills (+7, boss +15), parries (+5) and fatalities (+6/+10). Ported from STICK FIST.' },
  { keys: 'RHYTHM = STYLE', name: 'FREESTYLE FLOW (FISTS)', desc: 'Your click TEMPO picks the style and the game chains the moves. FAST taps (0.1-0.3s) = WING CHUN chain punch. MEDIUM groove (0.3-0.6s) = BLACK LEG kick flow (Collier > Epaule > Cotelette > Anti-Manner > Mouton Shot > Concasse > Party Table > DIABLE JAMBE). SLOW heavy beats (0.6-1.0s) = KUNG FU heavies (Palm > Iron Palm > Hammer Fist > Dragon Uppercut). Switch tempo mid-fight to transition styles; nearly-dead targets get an automatic finisher.' },
  { keys: 'HEAT', name: 'IN THE ZONE', desc: 'Stay in one rhythm to build HEAT: damage and move speed rise, the screen pulses with the beat. Getting hit cools you down.' },
  { keys: 'R (RAGE FULL)', name: 'RAGE MODE', desc: '8 seconds: every LMB dashes to the nearest enemy and executes it (bosses take heavy damage). Fair: rage only fills by landing chain punches.' },
  { keys: 'LMB x4, RMB', name: 'MANTIS STRIKE', desc: 'One-inch finger strike. Shatters structure.' },
  { keys: 'LMB x3, RMB', name: 'DRAGON UPPERCUT', desc: 'Launcher. Juggle them in the air.' },
  { keys: 'LMB, LMB, RMB', name: 'SWEEP KICK', desc: '360 sweep. Knocks everyone down.' },
  { keys: 'LMB, RMB, LMB / RMB', name: 'TWIN PALM / TIGER CLAW', desc: 'Palm blast across the room, or a 4-hit bleeding claw rake.' },
  { keys: 'RMB, LMB, LMB / RMB', name: 'AXE KICK / MONKEY FLIP', desc: 'Heel crash, or a backflip kick that launches.' },
  { keys: 'RMB, RMB, LMB', name: 'CRANE KICK', desc: 'The classic. Long windup, devastating.' },
  { keys: 'RUN + LMB', name: 'TAEKWONDO FLYING SIDE KICK', desc: 'Fists only. Sprint, then left click.' },
  { keys: '4: NUNCHAKU LMB x4', name: 'BRUCE LEE TRIANGLE COMBO', desc: 'From the underarm tuck: diagonal down-left strike > bounce up to the left shoulder > horizontal chest sweep back right > catch & lock under the right armpit. 5th LMB: SKULL CRACKER.' },
  { keys: 'NUNCHAKU RMB', name: 'HELICOPTER / SPECIALS', desc: 'RMB: HELICOPTER (hold). RMB,LMB: ANKLE BREAKER. RMB,RMB: TORNADO. LMB,RMB: WHIP CRACK. LMB,LMB,RMB: CHAIN CHOKE SLAM.' },
  { keys: 'NUNCHAKU: RUN + LMB', name: 'DRAGON LASH', desc: 'Lethal charging strike: leap in, chain whips around and detonates. Replaces the kick.' },
  { keys: 'NUNCHAKU: F', name: 'CHAIN FATALITIES', desc: 'Garrote snap, skull drum, helicopter decapitation.' },
  { keys: '5: KATANA', name: 'IAI DRAW > RETURN CUT > CRESCENT MOON > HEAVEN SPLITTER', desc: 'RMB: LUNGING THRUST. LMB,RMB: RISING MOON (launch). LMB,LMB,RMB: WHIRLWIND. RMB,LMB: THOUSAND CUTS. RMB,RMB: DRAGON FANG. Cuts bleed.' },
  { keys: 'KATANA: RUN + LMB', name: 'IAIJUTSU', desc: 'Dash through them. One cut. They fall after you sheathe.' },
  { keys: '5: KATANA V2', name: 'VARIABLE CHAINS + DASH SLASH', desc: 'Every chain is rolled: 1 cut then SHEATHE FLASH (snap into the sheath), 2 cuts then DASH CUT through them, or the classic 4-hit HEAVEN SPLITTER. Dash-slashes trail afterimages.' },
  { keys: 'KATANA: F', name: 'BLADE FATALITIES', desc: 'Bisection, beheading, impale & flick.' },
  { keys: '6: AXE', name: 'SWING > BACKHAND > HOME RUN', desc: 'Baseball-bat swings: load, hips, contact, follow-through. 3rd swing is a HOME RUN launcher. RMB: TORNADO SWING (720). LMB,RMB: GOLF SWING (scoop launch). LMB,LMB,RMB: SKULL SPLITTER. RMB,LMB: BUNT. RUN+LMB: GRAND SLAM.' },
  { keys: '7: DUAL BLADES', name: 'CROSS > SCISSOR > FLURRY > X-SLASH', desc: 'Two hitboxes, very fast. RMB: BLADE DANCE. LMB,RMB: TWIN RISING (launch). RUN+LMB: PHANTOM CROSS (dash through).' },
  { keys: 'SPACE', name: 'JUMP', desc: 'Hop over bullets and sweeps. LMB in the air = DIVE KICK.' },
  { keys: 'SHIFT', name: 'SHADOW STEP', desc: 'Dash with i-frames. Perfect-dodge to refill focus.' },
  { keys: 'E', name: 'DRAGON PALM', desc: 'Focus attack. Costs 1 focus bar.' },
  { keys: 'F', name: 'FATALITY', desc: 'Weapon-specific finishers. Staggered (yellow) enemy = PERFECT.' },
];

// ============================== BASEBALL BAT: FREESTYLE SLUGGER ==============================
// LMB = freestyle (the game never repeats the same swing twice in a row, every 5th = HOME RUN),
// LMB on an airborne enemy = PEPPER juggle (4th = METEOR SPIKE), RMB = BAT TORNADO, RUN+LMB = GRAND SLAM.
const BAT = { sfx: 'axe' as const, limb: 'blade' as const, axe: true, bat: true, knockdown: true };
Object.assign(MOVES, {
  B_SWING: { ...BAT, id: 'b_swing', name: 'LINE DRIVE', pose: 'a_swing1', dmg: 9, structure: 45, range: 29, arc: 1.6, windup: 0.1, active: 0.09, recover: 0.2, kb: 420, lunge: 100, hitstop: 0.1, shake: 0.7, hitR: 6, slash: { from: -2.4, to: 1.0, r: 22 } },
  B_BACK: { ...BAT, id: 'b_back', name: 'BACKHAND', pose: 'a_swing2', dmg: 9, structure: 45, range: 29, arc: 1.6, windup: 0.09, active: 0.09, recover: 0.2, kb: 420, lunge: 90, hitstop: 0.1, shake: 0.7, hitR: 6, slash: { from: 2.4, to: -1.0, r: 22 } },
  B_BEHIND: { ...BAT, id: 'b_behind', name: 'BEHIND THE BACK', pose: 'a_swing2', dmg: 11, structure: 55, range: 30, arc: 2.2, windup: 0.12, active: 0.12, recover: 0.22, kb: 480, lunge: 80, hitstop: 0.12, shake: 0.8, hitR: 6.5, slash: { from: -4.4, to: 1.0, r: 23 }, showName: true },
  B_POP: { ...BAT, id: 'b_pop', name: 'POP FLY', pose: 'a_golf', dmg: 8, structure: 55, range: 28, arc: 1.3, windup: 0.11, active: 0.1, recover: 0.26, kb: 120, lunge: 70, hitstop: 0.12, shake: 0.8, hitR: 6, launch: 250, slash: { from: 1.3, to: -1.7, r: 22, lift: 0.5 }, showName: true },
  B_SLAM: { ...BAT, id: 'b_slam', name: 'CLEANUP SLAM', pose: 'a_overhead', dmg: 14, structure: 90, range: 28, arc: 1.0, windup: 0.16, active: 0.08, recover: 0.32, kb: 240, lunge: 130, hitstop: 0.15, shake: 1.1, hitR: 6.5, slash: { from: 0, to: 0, r: 22, lift: 1.2 }, showName: true },
  B_BUNT: { ...BAT, id: 'b_bunt', name: 'BUNT JAB', pose: 'a_bunt', dmg: 6, structure: 60, range: 24, arc: 1.0, windup: 0.04, active: 0.08, recover: 0.12, kb: 300, knockdown: false, lunge: 140, hitstop: 0.06, shake: 0.45, hitR: 5, slash: { from: 0, to: 0, r: 18 } },
  B_HELI: { ...BAT, id: 'b_heli', name: 'HELICOPTER', pose: 'a_spin', dmg: 8, structure: 45, range: 32, arc: Math.PI, windup: 0.08, active: 0.26, recover: 0.22, kb: 460, lunge: 40, hitstop: 0.08, shake: 0.7, hitR: 6.5, rehit: 0.2, slash: { from: 0, to: Math.PI * 2, r: 24 }, showName: true },
  B_HOMER: { ...BAT, id: 'b_homerun', name: 'HOME RUN', pose: 'a_homerun', dmg: 18, structure: 110, range: 33, arc: 1.7, windup: 0.2, active: 0.1, recover: 0.36, kb: 860, lunge: 130, hitstop: 0.18, shake: 1.3, hitR: 7, launch: 170, slash: { from: -2.9, to: 1.2, r: 25 }, finisher: true },
  B_PEPPER: { ...BAT, id: 'b_pepper', name: 'PEPPER', pose: 'a_golf', dmg: 5, structure: 30, range: 34, arc: 1.4, windup: 0.05, active: 0.1, recover: 0.12, kb: 30, knockdown: false, lunge: 60, hitstop: 0.07, shake: 0.5, hitR: 7, launch: 230, slash: { from: 1.3, to: -1.7, r: 22, lift: 0.6 } },
  B_SPIKE: { ...BAT, id: 'b_spike', name: 'METEOR SPIKE', pose: 'a_overhead', dmg: 16, structure: 120, range: 34, arc: 1.4, windup: 0.08, active: 0.1, recover: 0.3, kb: 620, lunge: 80, hitstop: 0.2, shake: 1.4, hitR: 7.5, slash: { from: 0, to: 0, r: 22, lift: 1.2 }, finisher: true },
  BH: { ...BAT, id: 'b_tornado', name: 'BAT TORNADO', pose: 'a_spin', dmg: 7, structure: 45, range: 33, arc: Math.PI, windup: 0.14, active: 0.5, recover: 0.34, kb: 440, lunge: 0, hitstop: 0.08, shake: 0.7, hitR: 6.5, rehit: 0.2, slash: { from: 0, to: Math.PI * 4, r: 24 }, finisher: true, showName: true },
  BRUN: { ...BAT, id: 'b_grandslam', name: 'GRAND SLAM', pose: 'a_homerun', dmg: 20, structure: 130, range: 35, arc: 1.7, windup: 0.08, active: 0.3, recover: 0.42, kb: 940, lunge: 0, hitstop: 0.18, shake: 1.3, hitR: 7.5, launch: 200, travel: 320, slash: { from: -2.9, to: 1.2, r: 25 }, finisher: true },
  BDASH: { ...BAT, id: 'b_slide', name: 'SLIDE INTO HOME', pose: 'a_swing1', dmg: 12, structure: 65, range: 31, arc: 1.6, windup: 0.04, active: 0.24, recover: 0.3, kb: 500, lunge: 0, hitstop: 0.12, shake: 0.8, hitR: 6.5, travel: 300, slash: { from: -2.4, to: 1.0, r: 22 }, finisher: true, showName: true },
});
export const BAT_FREESTYLE = ['B_SWING', 'B_BACK', 'B_BEHIND', 'B_POP', 'B_SLAM', 'B_BUNT', 'B_HELI'];

// ============================== STREET BAT: spammable brawler swings ==============================
// LMB spam = WILD SWING / BACKHAND alternating, every 4th = a special (KNOB JAB / UPPER SWING / OVERHEAD SMASH),
// every 12th = HOME RUN. Downed enemy in front = CURB SMASH (bounces them up). RMB = 360 SWING (BAT TORNADO at 12+ spam).
Object.assign(MOVES, {
  SB_F: { ...BAT, id: 'sb_f', name: 'WILD SWING', pose: 'b_wild', dmg: 6, structure: 30, range: 29, arc: 1.7, windup: 0.05, active: 0.07, recover: 0.1, kb: 230, knockdown: false, lunge: 70, hitstop: 0.045, shake: 0.35, hitR: 6, slash: { from: -2.2, to: 1.2, r: 22 } },
  SB_B: { ...BAT, id: 'sb_b', name: 'BACKHAND', pose: 'b_wildback', dmg: 6, structure: 30, range: 29, arc: 1.7, windup: 0.05, active: 0.07, recover: 0.1, kb: 230, knockdown: false, lunge: 70, hitstop: 0.045, shake: 0.35, hitR: 6, slash: { from: 2.2, to: -1.2, r: 22 } },
  SB_KNOB: { ...BAT, id: 'sb_knob', name: 'KNOB JAB', pose: 'b_knob', limb: 'fhand', dmg: 5, structure: 50, range: 20, arc: 1.0, windup: 0.03, active: 0.06, recover: 0.09, kb: 170, knockdown: false, lunge: 110, hitstop: 0.06, shake: 0.4, hitR: 5, slash: { from: Math.PI, to: Math.PI, r: 0 }, showName: true },
  SB_UPPER: { ...BAT, id: 'sb_upper', name: 'UPPER SWING', pose: 'b_upper', dmg: 8, structure: 50, range: 28, arc: 1.4, windup: 0.06, active: 0.08, recover: 0.14, kb: 120, lunge: 70, hitstop: 0.08, shake: 0.6, hitR: 6.5, launch: 240, slash: { from: 1.4, to: -1.8, r: 22, lift: 0.4 }, showName: true },
  SB_SMASH: { ...BAT, id: 'sb_smash', name: 'OVERHEAD SMASH', pose: 'b_smash', dmg: 12, structure: 90, range: 29, arc: 1.1, windup: 0.09, active: 0.07, recover: 0.17, kb: 260, lunge: 120, hitstop: 0.1, shake: 0.9, hitR: 7, slash: { from: -2.1, to: 0.9, r: 22 }, showName: true },
  SB_POUND: { ...BAT, id: 'sb_pound', name: 'CURB SMASH', pose: 'b_pound', dmg: 9, structure: 70, range: 28, arc: 1.3, windup: 0.06, active: 0.07, recover: 0.12, kb: 60, lunge: 50, hitstop: 0.08, shake: 0.7, hitR: 8, launch: 150, slash: { from: -1.7, to: 1.3, r: 20 }, showName: true },
  SB_SPIN: { ...BAT, id: 'sb_spin', name: '360 SWING', pose: 'a_spin', dmg: 7, structure: 40, range: 32, arc: Math.PI, windup: 0.06, active: 0.2, recover: 0.12, kb: 360, lunge: 30, hitstop: 0.05, shake: 0.6, hitR: 6.5, rehit: 0.15, slash: { from: 0, to: Math.PI * 2, r: 24 }, showName: true },
});

// ============================== BOXING: sarung tinju, tiga gaya ==============================
// ALI  : flicker jab + Ali Shuffle (jab beruntun sambil kaki menari).
// TYSON: peek-a-boo — merunduk masuk, hook badan lalu uppercut.
// IPPO : menekan maju — body blow, Dempsey Roll, Gazelle Punch, Heartbreak Shot.
const BOX: Move = {
  id: 'bx_jab', name: 'FLICKER JAB', pose: 'bx_jab', dmg: 3, structure: 12, range: 21, arc: 0.95,
  windup: 0.03, active: 0.06, recover: 0.08, kb: 90, knockdown: false, lunge: 70,
  hitstop: 0.03, shake: 0.16, sfx: 'punch', limb: 'fhand', hitR: 5.4, trail: true,
};
Object.assign(MOVES, {
  BX_JAB: { ...BOX },
  BX_CROSS: { ...BOX, id: 'bx_cross', name: 'STRAIGHT RIGHT', pose: 'bx_cross', dmg: 6, structure: 26, range: 23, arc: 0.95, windup: 0.06, active: 0.07, recover: 0.15, kb: 260, lunge: 110, hitstop: 0.055, shake: 0.36, limb: 'bhand', hitR: 5.6, showName: true },
  BX_LHOOK: { ...BOX, id: 'bx_lhook', name: 'LEFT HOOK', pose: 'bx_lhook', dmg: 7, structure: 34, range: 20, arc: 1.9, windup: 0.07, active: 0.09, recover: 0.17, kb: 300, knockdown: true, lunge: 80, hitstop: 0.06, shake: 0.42, hitR: 5.8, showName: true },
  BX_UPPER: { ...BOX, id: 'bx_upper', name: 'UPPERCUT', pose: 'bx_upper', dmg: 9, structure: 48, range: 18, arc: 1.2, windup: 0.09, active: 0.08, recover: 0.24, kb: 200, knockdown: true, lunge: 90, launch: 210, hitstop: 0.09, shake: 0.62, limb: 'bhand', hitR: 5.8, showName: true },
  BX_BODY: { ...BOX, id: 'bx_body', name: 'BODY BLOW', pose: 'bx_body', dmg: 5, structure: 52, range: 18, arc: 1.1, windup: 0.05, active: 0.07, recover: 0.12, kb: 70, lunge: 95, hitstop: 0.05, shake: 0.3, hitR: 5.6 },
  BX_SMASH: { ...BOX, id: 'bx_smash', name: 'SMASH', pose: 'bx_smash', dmg: 14, structure: 90, range: 22, arc: 1.3, windup: 0.16, active: 0.09, recover: 0.34, kb: 520, knockdown: true, lunge: 130, hitstop: 0.13, shake: 1.0, limb: 'bhand', hitR: 6.2, finisher: true, showName: true },
  BX_GAZELLE: { ...BOX, id: 'bx_gazelle', name: 'GAZELLE PUNCH', pose: 'bx_gazelle', dmg: 13, structure: 80, range: 25, arc: 1.7, windup: 0.1, active: 0.26, recover: 0.3, kb: 620, knockdown: true, lunge: 0, travel: 330, jump: 13, hitstop: 0.12, shake: 0.9, hitR: 6.4, launch: 150, finisher: true, showName: true, trail: true },
  BX_DEMPSEY: { ...BOX, id: 'bx_dempsey', name: 'DEMPSEY ROLL', pose: 'bx_dempsey', dmg: 3.2, structure: 22, range: 22, arc: 2.4, windup: 0.06, active: 0.78, recover: 0.28, kb: 110, lunge: 150, hitstop: 0.02, shake: 0.2, hitR: 6.2, rehit: 0.085, limb: 'both', finisher: true, showName: true, trail: true },
  BX_HEART: { ...BOX, id: 'bx_heart', name: 'HEARTBREAK SHOT', pose: 'bx_heart', dmg: 18, structure: 130, range: 24, arc: 1.0, windup: 0.34, active: 0.1, recover: 0.4, kb: 760, knockdown: true, lunge: 190, hitstop: 0.17, shake: 1.25, limb: 'bhand', hitR: 6.4, launch: 90, finisher: true, showName: true, trail: true },
  BX_SHUFFLE: { ...BOX, id: 'bx_shuffle', name: 'ALI SHUFFLE', pose: 'bx_jab', dmg: 2.6, structure: 16, range: 23, arc: 1.1, windup: 0.04, active: 0.62, recover: 0.22, kb: 90, lunge: 60, hitstop: 0.02, shake: 0.16, hitR: 5.6, rehit: 0.1, limb: 'both', finisher: true, showName: true, trail: true },
  BX_JAB2: { ...BOX, id: 'bx_jab2', name: 'DOUBLE JAB', pose: 'bx_jab', dmg: 2.2, structure: 10, range: 22, arc: 1.0, windup: 0.02, active: 0.16, recover: 0.07, kb: 55, lunge: 55, hitstop: 0.015, shake: 0.12, hitR: 5.4, rehit: 0.075 },
  BX_RHOOK: { ...BOX, id: 'bx_rhook', name: 'RIGHT HOOK', pose: 'bx_rhook', dmg: 7, structure: 34, range: 20, arc: 1.9, windup: 0.07, active: 0.09, recover: 0.17, kb: 300, lunge: 80, hitstop: 0.06, shake: 0.42, limb: 'bhand', hitR: 5.8, showName: true },
  BX_SHOVEL: { ...BOX, id: 'bx_shovel', name: 'SHOVEL HOOK', pose: 'bx_shovel', dmg: 6, structure: 44, range: 19, arc: 1.3, windup: 0.06, active: 0.08, recover: 0.15, kb: 150, lunge: 100, hitstop: 0.055, shake: 0.36, limb: 'bhand', hitR: 5.7, launch: 60 },
  BX_OVER: { ...BOX, id: 'bx_over', name: 'OVERHAND', pose: 'bx_over', dmg: 8, structure: 46, range: 22, arc: 1.4, windup: 0.1, active: 0.08, recover: 0.2, kb: 340, lunge: 115, hitstop: 0.075, shake: 0.5, limb: 'bhand', hitR: 5.9, showName: true },
  BX_CHECK: { ...BOX, id: 'bx_check', name: 'CHECK HOOK', pose: 'bx_lhook', dmg: 6, structure: 38, range: 21, arc: 2.1, windup: 0.05, active: 0.1, recover: 0.18, kb: 360, lunge: -70, hitstop: 0.06, shake: 0.4, hitR: 5.8, showName: true },
  BX_ROLLIN: { ...BOX, id: 'bx_rollin', name: 'PEEK-A-BOO RUSH', pose: 'bx_dempsey', dmg: 5, structure: 40, range: 20, arc: 2.2, windup: 0.08, active: 0.5, recover: 0.26, kb: 220, knockdown: true, lunge: 210, hitstop: 0.05, shake: 0.4, hitR: 6.0, rehit: 0.14, limb: 'both', finisher: true, showName: true, trail: true },
});

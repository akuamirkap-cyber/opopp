import assert from 'node:assert/strict';
import { createServer } from 'vite';

globalThis.window ??= { location: { search: '' } };
const server = await createServer({ configFile: false, server: { middlewareMode: true }, appType: 'custom' });

try {
  const load = name => server.ssrLoadModule(`/src/games/maxkungfu/game/${name}.ts`);
  const { Game, makePlayer } = await load('game');
  const { makeEnemy, startBossMove, updateEnemy, updateBossWeaponPhysics, bossStickOpts } = await load('enemies');
  const { generateLevel, flowField, moveWithCollision, solidAt } = await load('level');
  const { defaultStats } = await load('types');
  const { Nunchaku } = await load('nunchaku');
  const { SFNunchaku } = await load('sfnunchaku');
  const { Katana } = await load('katana');
  const { Yoyo } = await load('yoyo');
  const { YoyoV2 } = await load('yoyoV2');
  const { Takamura } = await load('takamura');
  const { Hayabusa } = await load('hayabusa');
  const { Leviathan } = await load('leviathan');
  const { solvePose, drawSkeleton } = await load('stick');
  const noop = () => {};
  const effects = new Proxy({}, { get: () => noop });
  let cases = 0;

  function fixture(weapon = 'fist', enemyWeapon = 'fist') {
    const g = Object.create(Game.prototype);
    const p = makePlayer();
    Object.assign(p, { x: 240, y: 176, aim: 0, bodyAim: 0, weapon });
    const e = makeEnemy('boss', enemyWeapon, 258, 176, 1, false);
    Object.assign(e, { spawnT: 0, aim: Math.PI, bodyAim: Math.PI, facing: -1 });
    const input = {
      keys: new Set(), pressed: new Set(), mouseMovedAt: 0, keyboardSeen: true,
      mouse: { x: 265.2, y: 126.6, down: false, rdown: false, mdown: false, pressed: false, rpressed: false, wheel: 0 },
      key(key) { return this.keys.has(key); }, hit(key) { return this.pressed.has(key); }, focus: noop,
      endFrame() { this.pressed.clear(); this.mouse.pressed = false; this.mouse.rpressed = false; },
    };
    Object.assign(g, {
      player: p, enemies: [e], level: generateLevel(1), input,
      stats: defaultStats(), age: 20, state: 'playing', mode: 'survival', wave: 1, levelN: 1,
      menuTransition: null, pendingRiposte: null, parryCounterKey: null,
      nunchaku: new Nunchaku(), sfNun: new SFNunchaku(), katana: new Katana(),
      yoyo: new Yoyo(), yoyoV2: new YoyoV2(), tak: new Takamura(), hay: new Hayabusa(), lev: new Leviathan(),
      nunStyle: 'v2', yoyoVer: 2, sfNunAim: 0, nunFlourish: 0, nunFlourishCd: 1,
      particles: effects, sfx: effects, blood: effects, texts: { list: [], add: noop, update: noop }, gunfx: effects,
      pal: { accent: '#ff3838', accent2: '#ffffff', wallTop: '#333333' },
      cam: { x: 0, y: 41 }, camKick: { x: 0, y: 0 }, zoom: 1.4, zoomTarget: 1.4,
      time: 1, rawDt: 1 / 60, longMode: false, v2: true, timeScaleBonus: 1,
      trauma: 0, hitstop: 0, flashA: 0, zoomKick: 0, score: 0, combo: 0, bestCombo: 0, comboMax: 2.2,
      meleeHits: 0, fistHits: 0, fistHitT: -9, kills: 0, finishCd: 0, announce: [], afterimages: [],
      clashDuel: null, clashCd: 10, silat: null, silatPending: null, silatCd: 0, silatLinkT: 0,
      batFlow: 0, batSpam: 0, batSpamT: 0, batTauntT: 0, batEquippedAt: 0, wallHits: [],
      props: [], bullets: [], pickups: [], hazards: [], corpses: [], pools: [], spawnQueue: [],
      cleared: true, exitOpen: false, flowT: Infinity, survivalTime: 0, waveT: 0, waveLen: 9999,
      waveBudget: 0, bossBeatenT: 0, pendingChoice: false, stamp: noop,
    });
    g.flow = flowField(g.level, p.x, p.y);
    g.sfNun.reset(p.x + 4, p.y - 8);
    g.nunchaku.reset(p.x + 4, p.y - 8);
    g.yoyoV2.reset(p.x + 4, p.y - 8);
    return { g, p, e, input };
  }

  {
    const { g, p, e } = fixture();
    startBossMove(g, e, 'L', true);
    e.attackPhase = 'active';
    p.parryT = 0.25;
    const before = { px: p.x, py: p.y, ex: e.x, ey: e.y };
    assert.equal(g.perfectParry(e, Math.PI), true);
    assert.deepEqual({ px: p.x, py: p.y, ex: e.x, ey: e.y }, before, 'A parry cannot teleport either fighter');
    assert.equal(e.attackPhase, 'none');
    assert.equal(e.moveKey, null);
    assert.ok(e.counterLockT >= 0.6);
    const focus = p.focus, structure = e.structure, combo = g.combo;
    assert.equal(g.perfectParry(e, Math.PI), false);
    assert.equal(p.focus, focus);
    assert.equal(e.structure, structure);
    assert.equal(g.combo, combo, 'One incoming strike can reward a parry only once');
    updateEnemy(g, e, 1 / 60);
    assert.equal(e.attackPhase, 'none', 'Boss must respect the successful counter opening');
    cases++;
  }

  {
    const { g, p, e } = fixture();
    e.x = p.x + 70;
    const before = { px: p.x, ex: e.x };
    g.startClash(e);
    assert.deepEqual({ px: p.x, ex: e.x }, before, 'Entering an exchange cannot pull distant fighters together instantly');
    g.updateClash(1 / 60);
    assert.ok(Math.abs(p.x - before.px) <= 220 / 60 + 0.001);
    assert.ok(Math.abs(e.x - before.ex) <= 220 / 60 + 0.001);
    cases++;
  }

  {
    const { g, p } = fixture();
    g.level.tiles[11 * g.level.w + 16] = 1;
    moveWithCollision(g.level, p, 80, 0);
    assert.ok(p.x < 256, 'A fast counter dash cannot tunnel through an intermediate wall');
    assert.equal(solidAt(g.level, p.x, p.y), false);
    cases++;
  }

  {
    const { g, p, e, input } = fixture();
    startBossMove(g, e, 'L', true);
    input.pressed.add('c');
    g.updatePlayer(1 / 60);
    assert.equal(e.structure, 0, 'Pressing C during windup is not an instant success');
    assert.ok(p.parryT > 0);
    input.endFrame();
    for (let i = 0; i < 25 && !p.parryHit; i++) {
      g.time += 1 / 60;
      g.updatePlayer(1 / 60); updateEnemy(g, e, 1 / 60); g.physics(1 / 60);
    }
    assert.equal(p.parryHit, true, 'The guard must catch the actual contact frame');
    p.parryHit = false; p.parryT = 0.2; p.aim = Math.PI;
    assert.equal(g.canPlayerParry(e), false, 'A forward parry does not block a strike from behind');
    cases++;
  }

  {
    const { g, p, e } = fixture();
    Object.assign(p, { attackPhase: 'active', moveKey: 'L', attackT: 0.001, buffered: 'H' });
    g.resolveMelee = () => g.cancelPlayerAttack();
    g.updateAttack(1 / 60);
    assert.equal(p.attackPhase, 'none'); assert.equal(p.moveKey, null);
    startBossMove(g, e, 'L', true);
    Object.assign(e, { attackPhase: 'active', attackT: 0.0001 });
    Object.assign(p, { parryT: 0.2, parryHit: false, aim: 0 });
    updateEnemy(g, e, 1 / 60);
    assert.equal(e.attackPhase, 'none', 'An interrupted attack cannot resurrect in recovery');
    assert.ok(e.counterLockT > 0);
    cases++;
  }

  {
    const { g, input, e } = fixture();
    g.startClash(e); g.clashDuel.playerContestedBeat = false; g.beginClashBeat(e, 'boss', 1);
    const C = g.clashDuel;
    Object.assign(C, { u: 0.62, hitDone: true, beatOutcome: 'pushed', power: 44 });
    input.pressed.add('c'); g.time += 0.12; g.updateClash(1 / 60);
    assert.equal(C.beatOutcome, 'pushed', 'Late input cannot retroactively undo a resolved hit');
    assert.equal(C.power, 44); assert.equal(g.combo, 0);
    cases++;
  }

  {
    const { g, input, e } = fixture();
    g.startClash(e); g.clashDuel.playerContestedBeat = false; g.beginClashBeat(e, 'boss', 1);
    const C = g.clashDuel;
    C.u = 0.25;
    input.pressed.add('c'); g.time += 0.12; g.updateClash(1 / 60); input.endFrame();
    assert.equal(C.beatOutcome, 'perfect');
    assert.equal(C.power, 50, 'The advantage is applied at contact, not on key presses');
    for (let i = 0; i < 20 && !C.hitDone; i++) { g.time += 1 / 60; g.updateClash(1 / 60); }
    assert.equal(C.power, 60);
    for (let i = 0; i < 5; i++) { input.pressed.add('c'); g.time += 0.01; g.updateClash(0.001); input.endFrame(); }
    assert.equal(C.power, 60, 'Repeated presses cannot multiply one parry reward');
    cases++;
  }

  for (const weapon of ['fist', 'nunchaku', 'katana', 'takamura', 'hayabusa', 'bat', 'axe', 'dual', 'yoyo']) {
    const { g, p, e } = fixture(weapon);
    g.startClash(e);
    const hp = e.hp;
    const position = { x: p.x, y: p.y };
    g.endClash(true);
    assert.equal(e.hp, hp, `${weapon}: no damage before the counter connects`);
    assert.deepEqual({ x: p.x, y: p.y }, position, `${weapon}: no finisher teleport`);
    for (let i = 0; i < 60 && g.pendingRiposte; i++) { g.time += 1 / 60; g.updatePlayer(1 / 60); }
    assert.equal(g.pendingRiposte, null);
    let damageEvents = 0, previousHp = hp;
    for (let i = 0; i < 160; i++) {
      g.time += 1 / 60; g.updatePlayer(1 / 60);
      if (e.hp < previousHp) damageEvents++;
      previousHp = e.hp;
      if (damageEvents && p.attackPhase === 'none' && !g.sfNun.attacking) break;
    }
    assert.equal(damageEvents, 1, `${weapon}: the counter must connect exactly once`);
    assert.ok(e.hp < hp);
    cases++;
  }

  {
    const { g, p, e } = fixture();
    g.startClash(e);
    const hp = p.hp;
    g.endClash(false);
    assert.equal(p.hp, hp, 'A lost exchange cannot damage the player before the boss swings');
    for (let i = 0; i < 60 && g.pendingRiposte; i++) { g.time += 1 / 60; g.updatePlayer(1 / 60); }
    assert.equal(p.hp, hp);
    for (let i = 0; i < 90 && !e.hitDone; i++) { updateEnemy(g, e, 1 / 60); g.physics(1 / 60); }
    assert.ok(p.hp < hp, 'Boss counter damage occurs on contact');
    assert.ok(p.kx < 0, 'The losing player recoils away from the real boss position');
    cases++;
  }

  {
    const { g, e } = fixture();
    e.structure = e.maxStructure + 1;
    g.enemyLand(e);
    assert.ok(e.stagger > 0, 'A counter that breaks posture must resolve the break when the launcher lands');
    assert.equal(e.attackPhase, 'none');
    assert.equal(e.state, 'stagger');
    assert.equal(e.z, 0);
    cases++;
  }

  {
    const { g, p, e } = fixture('nunchaku');
    g.sfNun.start(true);
    g.sfNun.update = () => { g.sfNun.endSpeed = 1000; };
    g.sfNun.stickDist = () => 0;
    e.counterLockT = 1;
    const hp = e.hp;
    g.updateSFNunchaku(0.13);
    g.time += 0.12; g.updateSFNunchaku(0.12);
    assert.equal(hp - e.hp, 15, 'Animation event and swept stick cannot double-hit the same target');
    assert.equal(p.hp, 8);
    cases++;
  }

  {
    const { g, e } = fixture('fist', 'nunchaku');
    Object.assign(e, { moveKey: null, attackPhase: 'none', scenePose: 'parry', sceneT: 0.5, sceneZ: 12, sqx: 1.3, sqy: 0.8 });
    const opts = bossStickOpts(g, e, 'parry', 0.5);
    delete opts.handOverride;
    const expected = solvePose(opts).fhand;
    updateBossWeaponPhysics(g, e, 1 / 60);
    assert.ok(Math.abs(e.nun.px[0] - (e.x + expected.x)) < 0.001);
    assert.ok(Math.abs(e.nun.py[0] - (e.y + expected.y - e.sceneZ)) < 0.001, 'Weapon grip must include the hop height');
    const renderedOpts = bossStickOpts(g, e, 'parry', 0.5);
    const sk = solvePose(renderedOpts);
    drawSkeleton({ fillRect: noop }, renderedOpts, sk);
    assert.ok(Math.abs(e.x + sk.fhand.x - e.nun.px[0]) < 0.001, 'Squash cannot detach the palm from its grip');
    cases++;
  }

  {
    const { g, p, e } = fixture();
    g.startClash(e);
    g.updatePlayer = () => { g.clashDuel = null; };
    let physicsCalls = 0;
    g.physics = () => { physicsCalls++; };
    g.mode = 'story';
    g.updateWorld(1 / 60);
    assert.equal(physicsCalls, 0, 'The cinematic owns both actors for its entire final frame');
    assert.equal(p.hp, 8);
    cases++;
  }

  console.log(`PASS: ${cases} parry timing, cancellation, counter damage, weapon attachment, and scene ownership cases.`);
} finally {
  await server.close();
}
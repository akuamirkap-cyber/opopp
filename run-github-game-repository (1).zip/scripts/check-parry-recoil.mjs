import assert from 'node:assert/strict';
import { createServer } from 'vite';

globalThis.window ??= { location: { search: '' } };

const server = await createServer({
  configFile: false,
  server: { middlewareMode: true },
  appType: 'custom',
});

try {
  const { Game } = await server.ssrLoadModule('/src/games/maxkungfu/game/game.ts');
  const { makeEnemy } = await server.ssrLoadModule('/src/games/maxkungfu/game/enemies.ts');
  const { generateLevel, solidAt, moveWithCollision } = await server.ssrLoadModule('/src/games/maxkungfu/game/level.ts');
  const { defaultStats } = await server.ssrLoadModule('/src/games/maxkungfu/game/types.ts');
  const { Katana } = await server.ssrLoadModule('/src/games/maxkungfu/game/katana.ts');
  const noop = () => {};
  const effects = new Proxy({}, { get: () => noop });

  function fixture(angle = 0) {
    const g = Object.create(Game.prototype);
    const p = {
      x: 240, y: 176, r: 5, hp: 8, maxHp: 8, weapon: 'fist',
      aim: angle, facing: 1, focus: 100, chainSide: 1, parryCd: 0,
      attackPhase: 'active', moveKey: 'L', fatality: null, z: 0, kx: 0, ky: 0,
    };
    const e = makeEnemy('boss', 'fist', p.x + Math.cos(angle) * 24, p.y + Math.sin(angle) * 24, 1, false);
    e.spawnT = 0;
    e.attackPhase = 'active';
    e.moveKey = 'L';
    Object.assign(g, {
      player: p, enemies: [e], level: generateLevel(1), props: [],
      particles: effects, sfx: effects, texts: { list: [], add: noop },
      sfNun: { cur: {}, buffered: true }, nunStyle: 'v2', katana: new Katana(),
      input: { mouse: { pressed: false, rpressed: false }, hit: () => false },
      stats: defaultStats(), age: 20, mode: 'survival', wave: 1,
      state: 'playing', time: 1, rawDt: 1 / 60, longMode: false, v2: true,
      trauma: 0, hitstop: 0, zoomKick: 0, score: 0, announce: [],
      clashDuel: null, clashCd: 0, silat: null,
    });
    return { g, p, e };
  }

  for (const angle of [0, Math.PI / 2, Math.PI, -Math.PI / 3]) {
    const { g, p, e } = fixture(angle);
    const nx = Math.cos(angle), ny = Math.sin(angle);
    const before = { playerHp: p.hp, bossHp: e.hp, structure: e.structure, focus: p.focus };
    g.mutualClashDeflect(e, angle + Math.PI);
    assert.ok(p.kx * nx + p.ky * ny < 0, 'Player must recoil away from the boss');
    assert.ok(e.kx * nx + e.ky * ny > 0, 'Boss must recoil away from the player');
    assert.ok(Math.abs(Math.hypot(p.kx, p.ky) - Math.hypot(e.kx, e.ky)) < 0.001);
    assert.equal(p.attackPhase, 'none');
    assert.equal(e.attackPhase, 'none');
    assert.ok(p.stunT > 0 && e.stun > 0, 'Both must have a recovery window');
    assert.equal(g.sfNun.cur, null);
    assert.equal(e.rallyWindow, 0);
    assert.equal(p.hp, before.playerHp);
    assert.equal(e.hp, before.bossHp);
    assert.equal(e.structure, before.structure);
    assert.equal(p.focus, before.focus);
    const px = p.x, py = p.y, ex = e.x, ey = e.y;
    moveWithCollision(g.level, p, p.kx / 60, p.ky / 60);
    g.physics(1 / 60);
    assert.ok((p.x - px) * nx + (p.y - py) * ny < 0);
    assert.ok((e.x - ex) * nx + (e.y - ey) * ny > 0);
  }

  for (const turn of ['player', 'boss', 'both']) {
    const { g, p, e } = fixture();
    g.startClash(e);
    g.clashDuel.playerContestedBeat = true;
    g.beginClashBeat(e, turn, 1);
    const C = g.clashDuel;
    C.beatOutcome = 'clash';
    C.u = 0.44;
    C.hitDone = true;
    const before = { px: p.x, ex: e.x, hp: p.hp, bossHp: e.hp, power: C.power };
    g.clashImpact(e);
    assert.ok(C.recoilT > 0, 'A tied cinematic beat must start a recoil animation');
    while (C.recoilT > 0) {
      g.time += 1 / 60;
      g.updateClash(1 / 60);
    }
    assert.ok(p.x < before.px - 17, 'Player cinematic recoil must remain visible');
    assert.ok(e.x > before.ex + 17, 'Boss cinematic recoil must remain visible');
    assert.equal(p.hp, before.hp);
    assert.equal(e.hp, before.bossHp);
    assert.equal(C.power, before.power, 'A draw must not favor either fighter');
    const settled = { px: p.x, ex: e.x };
    g.time += 1 / 60;
    g.updateClash(1 / 60);
    assert.ok(Math.abs(p.x - settled.px) < 4, 'Do not snap the player back after recoil');
    assert.ok(Math.abs(e.x - settled.ex) < 4, 'Do not snap the boss back after recoil');
    assert.equal(g.texts.list.length, 0);
    assert.equal(g.announce.length, 0);
  }

  {
    const { g, p, e } = fixture();
    g.startClash(e);
    Object.assign(g.clashDuel, { power: 50, beatsDone: 12, u: 1, hitDone: true });
    const before = { hp: p.hp, bossHp: e.hp, score: g.score };
    g.updateClash(1 / 60);
    assert.equal(g.clashDuel, null);
    assert.ok(p.kx < 0 && e.kx > 0, 'An overall draw knocks both fighters backward');
    assert.equal(p.hp, before.hp);
    assert.equal(e.hp, before.bossHp);
    assert.equal(g.score, before.score);
    assert.equal(p.attackPhase, 'none');
    assert.equal(e.attackPhase, 'none');
    assert.equal(g.announce[0].text, 'IMBANG');
  }

  for (const [power, expected] of [[80, true], [20, false]]) {
    const { g, e } = fixture();
    g.startClash(e);
    Object.assign(g.clashDuel, { power, beatsDone: 12, u: 1, hitDone: true });
    let result;
    g.endClash = value => { result = value; };
    g.updateClash(1 / 60);
    assert.equal(result, expected, 'Decisive wins and losses must still resolve normally');
  }

  {
    const { g, p, e } = fixture();
    p.x = 60; e.x = 36;
    g.mutualClashDeflect(e, 0);
    const hp = e.hp;
    g.props = [{ x: e.x, y: e.y, r: 6, hp: 3, dead: false }];
    g.physics(1 / 30);
    assert.equal(e.hp, hp, 'Draw recoil must not cause asymmetric wall or prop damage');
    assert.equal(g.props[0].hp, 3);
    assert.equal(solidAt(g.level, e.x, e.y), false);
  }

  console.log('PASS: equal recoil in all directions, cinematic recoil, neutral draws, wins/losses, and wall collisions.');
} finally {
  await server.close();
}
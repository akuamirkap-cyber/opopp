import assert from 'node:assert/strict';
import { createServer } from 'vite';

globalThis.window ??= { location: { search: '' } };
const storage = new Map();
globalThis.localStorage = { getItem: key => storage.get(key) ?? null, setItem: (key, value) => storage.set(key, value) };
const server = await createServer({ configFile: false, server: { middlewareMode: true }, appType: 'custom' });

try {
  const { Game } = await server.ssrLoadModule('/src/games/maxkungfu/game/game.ts');
  const noop = () => {};

  function fixture() {
    const g = Object.create(Game.prototype);
    const player = { x: 272, y: 176, hp: 8, attackPhase: 'active', moveKey: 'LL', attackT: 0.04 };
    const boss = { id: 17, x: 236, y: 176, hp: 105, dead: false, attackPhase: 'windup', moveKey: 'NL', attackT: 0.1 };
    Object.assign(g, {
      state: 'menu', player, enemies: [boss], mode: 'survival',
      cam: { x: 24.2, y: 32.225 }, camKick: { x: 0, y: 0 }, zoom: 16, zoomTarget: 16,
      menuCamera: { x: 24.2, y: 32.225, zoom: 16 }, menuTransition: null,
      menuInputBlocked: false, menuDemoPaused: false,
      input: { mouse: { x: 0, y: 0, down: true, rdown: true }, endFrame: noop, focus: noop },
      sfx: { init: noop, startMusic: noop }, pushUI: noop,
      scores: [], bestSurvival: { score: 0, wave: 0 }, runSaved: false,
      score: 0, kills: 0, bestCombo: 0, survivalTime: 0,
    });
    return { g, player, boss };
  }

  {
    const { g } = fixture();
    const expected = { ...g.cam };
    for (let i = 0; i < 120; i++) {
      g.input.mouse.x = Math.random() * 480;
      g.input.mouse.y = Math.random() * 270;
      g.updateCamera(1 / 60);
      assert.deepEqual(g.cam, expected);
      assert.equal(g.zoom, 16);
      assert.equal(g.shakeX, 0);
      assert.equal(g.shakeY, 0);
    }
  }

  {
    const { g, player, boss } = fixture();
    const before = { player: { ...player }, boss: { ...boss }, cam: { ...g.cam } };
    g.startFromMenu();
    assert.equal(g.state, 'playing');
    assert.equal(g.player, player);
    assert.equal(g.enemies[0], boss);
    assert.deepEqual(player, before.player);
    assert.deepEqual(boss, before.boss);
    assert.deepEqual(g.cam, before.cam);
    assert.equal(g.zoom, 16);
    assert.equal(g.input.mouse.down, false);
    const transition = g.menuTransition;
    g.startFromMenu();
    assert.equal(g.menuTransition, transition, 'Repeated Start must not restart the intro');
    let previousZoom = g.zoom;
    for (let i = 0; i < 100 && g.menuTransition; i++) {
      g.updateCamera(1 / 60);
      assert.ok(g.zoom <= previousZoom + 0.000001, 'Zoom-out must stay monotonic');
      previousZoom = g.zoom;
    }
    assert.equal(g.menuTransition, null);
    assert.equal(g.zoom, 1.4);
    assert.deepEqual(player, before.player);
    assert.deepEqual(boss, before.boss);
  }

  {
    const { g, player, boss } = fixture();
    g.menuInputBlocked = true;
    g.startFromMenu();
    assert.equal(g.state, 'menu');
    assert.equal(g.menuTransition, null);
    g.damagePlayer(5, 0);
    g.damageEnemy(boss, 100, 100, 0, 200, { melee: true });
    assert.equal(player.hp, 8, 'Attract mode must not hurt the player');
    assert.equal(boss.hp, 105, 'Attract mode must not hurt the real boss');
    g.recordScore();
    assert.equal(g.scores.length, 0, 'Autoplay cannot create leaderboard scores');
  }

  {
    const { g } = fixture();
    Object.assign(g, { state: 'playing', score: 1250, kills: 2, bestCombo: 12, survivalTime: 34, wave: 3 });
    g.recordScore();
    g.recordScore();
    assert.equal(g.scores.length, 1, 'Record a finished run only once');
    assert.equal(g.leaderboard()[0].score, 1250);
    assert.equal(g.leaderboard()[0].bosses, 2);
    assert.equal(JSON.parse(storage.get('stickfight_local_scores_v1')).length, 1);
  }

  console.log('PASS: fixed menu camera, seamless actor handoff, monotonic zoom, safe autoplay, and persistent local scores.');
} finally {
  await server.close();
}
import { useCallback, useEffect, useRef, useState, type PointerEvent, type ReactNode, type RefObject } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Maximize2, Minimize2, Pause, Play, Settings2, X } from 'lucide-react';
import { VIEW_H, VIEW_W, ZONES } from './game/constants';
import { BOSS_DEFS, BOSS_ORDER, bossForLevel } from './game/enemies';
import { Game, type UIState } from './game/game';
import { MOVE_LIST } from './game/moves';
import { MUTATIONS } from './game/mutations';
import { YOYO_SKINS, isYoyoSkinId } from './game/yoyoSkins';
import type { WeaponKind } from './game/types';
import { MutIcon, MutIconSm } from './MutIcon';

const initialUI: UIState = {
  state: 'menu', level: 1, zoneName: ZONES[0].name, zoneSub: ZONES[0].sub, score: 0, age: 20, deathCounter: 1, deaths: 0, kills: 0,
  bestCombo: 0, choices: [], save: null, best: { level: 0, score: 0 }, muted: false, mutations: [], ageGain: 0, hp: 8, maxHp: 8, accent: '#ff5a36',
  mode: 'story', wave: 0, survivalTime: 0, bestWave: 0, bestSurvivalScore: 0, blood: 'combined', v2: true, long: false,
  weapon: 'nunchaku', yoyoVer: 2, yoyoSkin: 'ember', nunStyle: 'v2', hasNunchaku: true,
  intro: false, leaderboard: [],
};

function aimAtNearest(game: Game, scene = false) {
  if (!scene && game.input.mouseMovedAt && performance.now() - game.input.mouseMovedAt < 1500) return;
  let nearest = null;
  let distance = Infinity;
  for (const enemy of game.enemies) {
    if (enemy.dead || enemy.spawnT > 0 || (scene && (enemy.z > 1 || enemy.down > 0))) continue;
    const d = (enemy.x - game.player.x) ** 2 + (enemy.y - game.player.y) ** 2;
    if (scene && d > (30 + enemy.r) ** 2) continue;
    if (d < distance) { distance = d; nearest = enemy; }
  }
  if (!nearest) return;
  game.input.mouse.x = (nearest.x - game.cam.x - VIEW_W / 2) * game.zoom + VIEW_W / 2;
  game.input.mouse.y = (nearest.y - game.cam.y - VIEW_H / 2) * game.zoom + VIEW_H / 2;
}

function HoldButton({ label, children, onPress, onRelease, className = '' }: {
  label: string; children: ReactNode; onPress: () => void; onRelease: () => void; className?: string;
}) {
  const held = useRef(false);
  const release = () => { if (held.current) { held.current = false; onRelease(); } };
  const press = (event: PointerEvent<HTMLButtonElement>) => {
    event.preventDefault();
    event.stopPropagation();
    if (held.current) return;
    held.current = true;
    event.currentTarget.setPointerCapture(event.pointerId);
    onPress();
  };
  return <button type="button" className={`game-touch-button ${className}`} aria-label={label}
    onPointerDown={press} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}
    onClick={(event) => { if (event.detail === 0) { onPress(); window.setTimeout(onRelease, 120); } }}>
    {children}
  </button>;
}

function TouchControls({ gameRef }: { gameRef: RefObject<Game | null> }) {
  const key = (code: string, down: boolean) => {
    const game = gameRef.current;
    if (!game) return;
    if (down && code === 'KeyG') aimAtNearest(game, true);
    game.input.focus();
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { code, bubbles: true }));
  };
  const mouse = (button: number, down: boolean) => {
    const game = gameRef.current;
    if (!game) return;
    if (down) { aimAtNearest(game); game.input.focus(); game.input.synthMouseDown(button); }
    else game.input.synthMouseUp(button);
  };
  const keyButton = (code: string, label: string, content: ReactNode, className = '') => (
    <HoldButton label={label} className={className} onPress={() => key(code, true)} onRelease={() => key(code, false)}>{content}</HoldButton>
  );
  return <div className="game-touch" aria-label="Kontrol sentuh">
    <div className="game-dpad">
      {keyButton('KeyW', 'Bergerak ke atas', <ArrowUp size={20} />, 'dpad-up')}
      {keyButton('KeyA', 'Bergerak ke kiri', <ArrowLeft size={20} />, 'dpad-left')}
      {keyButton('KeyS', 'Bergerak ke bawah', <ArrowDown size={20} />, 'dpad-down')}
      {keyButton('KeyD', 'Bergerak ke kanan', <ArrowRight size={20} />, 'dpad-right')}
    </div>
    <div className="game-actions">
      {keyButton('ShiftLeft', 'Menghindar', 'DASH')}
      {keyButton('Space', 'Lompat', 'LOMPAT')}
      {keyButton('KeyC', 'Parry', 'PARRY')}
      {keyButton('KeyG', 'Adegan aksi', 'AKSI')}
      <HoldButton label="Serangan ringan" className="game-attack" onPress={() => mouse(0, true)} onRelease={() => mouse(0, false)}>PUKUL</HoldButton>
      <HoldButton label="Serangan berat" onPress={() => mouse(2, true)} onRelease={() => mouse(2, false)}>BERAT</HoldButton>
      {keyButton('KeyE', 'Focus strike', 'FOCUS')}
      {keyButton('KeyX', 'One For All', 'OFA')}
      {keyButton('KeyF', 'Fatality', 'FINISH')}
    </div>
  </div>;
}

function useScale() {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const calc = () => {
      const s = Math.min(window.innerWidth / VIEW_W, window.innerHeight / VIEW_H);
      setScale(s > 0 ? s : 1);
    };
    calc();
    window.addEventListener('resize', calc);
    return () => window.removeEventListener('resize', calc);
  }, []);
  return scale;
}

function StartScreen({ gameRef, ui }: { gameRef: RefObject<Game | null>; ui: UIState }) {
  const [panel, setPanel] = useState<'leaderboard' | 'quit' | null>(null);
  const startRef = useRef<HTMLButtonElement>(null);
  const backRef = useRef<HTMLButtonElement>(null);
  const openPanel = (next: 'leaderboard' | 'quit') => {
    const game = gameRef.current;
    if (game) { game.menuInputBlocked = true; game.menuDemoPaused = next === 'quit'; }
    setPanel(next);
  };
  const back = useCallback(() => {
    const game = gameRef.current;
    if (game) { game.menuInputBlocked = false; game.menuDemoPaused = false; }
    setPanel(null);
    requestAnimationFrame(() => startRef.current?.focus());
  }, [gameRef]);

  useEffect(() => {
    if (!panel) return;
    backRef.current?.focus();
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); event.stopImmediatePropagation(); back(); }
      if (event.key === 'Tab') { event.preventDefault(); backRef.current?.focus(); }
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [panel, back]);

  useEffect(() => () => {
    const game = gameRef.current;
    if (game) { game.menuInputBlocked = false; game.menuDemoPaused = false; }
  }, [gameRef]);

  return <section className={`start-screen${ui.intro ? ' start-screen--leaving' : ''}`} aria-labelledby="start-title" aria-hidden={ui.intro || undefined}>
    <h1 id="start-title" className="start-screen__title">stickfight!</h1>
    {!panel && <nav className="start-screen__nav" aria-label="Menu utama">
      <button ref={startRef} type="button" disabled={ui.intro} onClick={() => gameRef.current?.startFromMenu()}>start</button>
      <button type="button" disabled={ui.intro} onClick={() => openPanel('leaderboard')}>leaderboard</button>
      <button type="button" disabled={ui.intro} onClick={() => openPanel('quit')}>quit</button>
    </nav>}
    {panel === 'leaderboard' && <section className="start-screen__panel" role="dialog" aria-modal="true" aria-labelledby="scores-title">
      <h2 id="scores-title">leaderboard</h2>
      {ui.leaderboard.length ? <>
        <div className="start-screen__scores-label">local scores</div>
        <table className="start-screen__scores">
          <thead><tr><th scope="col">#</th><th scope="col">score</th><th scope="col">boss</th></tr></thead>
          <tbody>{ui.leaderboard.slice(0, 5).map((entry, i) => <tr key={entry.id}>
            <td>{String(i + 1).padStart(2, '0')}</td><td>{entry.score.toLocaleString('id-ID')}</td><td>{entry.bosses}</td>
          </tr>)}</tbody>
        </table>
      </> : <p className="start-screen__note">belum ada skor.<br />mainkan duel pertamamu.</p>}
      <button ref={backRef} className="start-screen__back" type="button" onClick={back}>back</button>
    </section>}
    {panel === 'quit' && <section className="start-screen__panel" role="dialog" aria-modal="true" aria-labelledby="quit-title">
      <h2 id="quit-title">see you.</h2>
      <p className="start-screen__note">demo dijeda.<br />kamu bisa menutup tab ini.</p>
      <button ref={backRef} className="start-screen__back" type="button" onClick={back}>back to menu</button>
    </section>}
  </section>;
}

export default function App() {
  const rootRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const pausedForSetup = useRef(false);
  const [ui, setUi] = useState<UIState>(initialUI);
  const [showSetup, setShowSetup] = useState(false);
  const [showTouch, setShowTouch] = useState(() => window.matchMedia('(pointer: coarse)').matches);
  const [fullscreen, setFullscreen] = useState(false);
  const scale = useScale();

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let g: Game;
    try {
      g = new Game(canvas);
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to create game', err);
      return;
    }
    gameRef.current = g;
    (window as unknown as { __kf?: Game }).__kf = g;
    g.onUI = (u) => setUi(u);
    try {
      g.start();
    } catch (err) {
      console.error('[KUNGFU DRIFTER] failed to start game', err);
    }
    g.input.focus();
    const resumeAudio = () => { if (g.sfx.ctx && g.sfx.ctx.state !== 'running' && g.sfx.ctx.state !== 'closed' && !g.sfx.muted) g.sfx.init(); };
    window.addEventListener('pointerdown', resumeAudio, true);
    window.addEventListener('keydown', resumeAudio, true);

    return () => {
      window.removeEventListener('pointerdown', resumeAudio, true);
      window.removeEventListener('keydown', resumeAudio, true);
      g.destroy();
      if (gameRef.current === g) gameRef.current = null;
      if ((window as unknown as { __kf?: Game }).__kf === g) delete (window as unknown as { __kf?: Game }).__kf;
    };
  }, []);

  const closeSetup = useCallback(() => {
    setShowSetup(false);
    const game = gameRef.current;
    if (pausedForSetup.current && game?.state === 'paused') game.resume();
    else game?.input.focus();
    pausedForSetup.current = false;
  }, []);

  useEffect(() => {
    if (!showSetup) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault(); event.stopImmediatePropagation(); closeSetup();
    };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [showSetup, closeSetup]);

  useEffect(() => {
    const onChange = () => setFullscreen(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onChange);
    return () => document.removeEventListener('fullscreenchange', onChange);
  }, []);

  const g = () => gameRef.current!;
  const focusGame = () => gameRef.current?.input.focus();
  const act = (fn: () => void) => () => { focusGame(); fn(); focusGame(); };
  const openSetup = () => {
    const game = gameRef.current;
    if (!game) return;
    pausedForSetup.current = game.state === 'playing';
    if (pausedForSetup.current) game.pause();
    setShowSetup(true);
  };
  const restart = () => {
    const game = gameRef.current;
    if (!game) return;
    pausedForSetup.current = false; setShowSetup(false);
    if (game.mode === 'survival') game.newSurvival(); else game.newGame(null);
  };
  const quit = () => {
    pausedForSetup.current = false; setShowSetup(false);
    gameRef.current?.toMenu(); gameRef.current?.input.focus();
  };
  const toggleFullscreen = async () => {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
      else await rootRef.current?.requestFullscreen();
    } catch (error) { console.warn('Layar penuh tidak tersedia:', error); }
  };
  const w = VIEW_W * scale, h = VIEW_H * scale;
  const fontPx = Math.min(22, Math.max(12, Math.round(4.5 * scale)));
  // V2 renders into a display-sized backing store so the picture is resampled exactly ONCE (hard pixel edges).
  // V1 keeps the classic fixed 480x270 buffer that CSS stretches — that is the old, softer look.
  const dpr = typeof window === 'undefined' ? 1 : Math.min(2, window.devicePixelRatio || 1);
  const bw = ui.v2 ? Math.max(VIEW_W, Math.min(1920, Math.round(w * dpr))) : VIEW_W;
  const bh = ui.v2 ? Math.max(VIEW_H, Math.round((bw * VIEW_H) / VIEW_W)) : VIEW_H;

  return (
    <div ref={rootRef} className={`solo-game ${ui.state === 'menu' || ui.intro ? 'solo-game--menu' : ''} ${showTouch && ui.state === 'playing' && !ui.intro ? 'solo-game--touch' : ''}`} onContextMenu={(e) => e.preventDefault()}>
      {!ui.intro && ['playing', 'paused'].includes(ui.state) && <div className="game-quick pixel">
        <button type="button" onClick={() => { if (g().state === 'playing') g().pause(); else g().resume(); }} aria-label={ui.state === 'playing' ? 'Jeda permainan' : 'Lanjutkan permainan'} title={ui.state === 'playing' ? 'Jeda' : 'Lanjutkan'}>{ui.state === 'playing' ? <Pause size={15} /> : <Play size={15} />}</button>
        <button type="button" onClick={openSetup} aria-label="Pengaturan dan senjata"><Settings2 size={15} /><span>SENJATA</span></button>
      </div>}
      <div className="solo-stage relative" style={{ width: w, height: h, fontSize: fontPx }}>
        <canvas
          ref={canvasRef}
          width={bw}
          height={bh}
          tabIndex={0}
          className="block w-full h-full cursor-none outline-none"
          style={{ imageRendering: 'pixelated' }}
        />
        {/* scanlines */}
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.13]"
          style={{ backgroundImage: 'repeating-linear-gradient(0deg, rgba(0,0,0,0.6) 0px, rgba(0,0,0,0.6) 1px, transparent 2px, transparent 4px)' }}
        />
        {(ui.state === 'menu' || ui.intro) && <StartScreen gameRef={gameRef} ui={ui} />}
        {ui.state === 'mutation' && (
          <Overlay dim="bg-black/80">
            <div className="flex flex-col items-center gap-[1.2em] w-full px-[1em]">
              <div className="pixel text-[1.6em] leading-none" style={{ color: ui.accent, textShadow: `0.08em 0.08em 0 #000, 0 0 0.6em ${ui.accent}` }}>{`BOS ${ui.mode === 'survival' ? ui.wave : ui.level} DIKALAHKAN!`}</div>
              <div className="pixel text-[0.85em] text-white tracking-[0.2em]">PILIH MUTASI KEKUATAN</div>
              <div className="mutation-options flex gap-[1.2em] w-full max-w-[64em] justify-center flex-wrap">
                {ui.choices.map((m, i) => (
                  <button
                    key={m.id}
                    onClick={act(() => g().chooseMutation(i))}
                    className="mutation-choice group relative flex flex-col items-center gap-[0.7em] w-[19em] min-h-[22em] p-[1.3em] pt-[1.6em] border-[0.28em] bg-black/80 hover:bg-black cursor-pointer overflow-hidden"
                    style={{ borderColor: m.color, boxShadow: `0.4em 0.4em 0 #000, 0 0 1.6em ${m.color}44, inset 0 0 2em ${m.color}18` }}
                  >
                    <div className="absolute top-0 left-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute top-0 right-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute bottom-0 left-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="absolute bottom-0 right-0 w-[0.7em] h-[0.7em]" style={{ background: m.color }} />
                    <div className="mutation-icon relative flex items-center justify-center w-[7em] h-[7em] border-[0.18em]" style={{ borderColor: m.color, background: '#050505', boxShadow: `inset 0 0 1.2em ${m.color}33` }}>
                      <MutIcon id={m.id} color={m.color} />
                    </div>
                    <div className="mutation-name pixel text-[0.95em] text-center leading-tight" style={{ color: m.color, textShadow: '0.06em 0.06em 0 #000' }}>{m.name}</div>
                    <div className="mutation-description pixel text-[0.62em] text-white/80 leading-relaxed text-center max-w-[16em]">{m.desc}</div>
                    <div className="pixel text-[0.7em] mt-auto px-[0.7em] py-[0.25em] text-black" style={{ background: m.color }}>{i + 1}</div>
                  </button>
                ))}
              </div>
              {(() => {
                const nextRound = (ui.mode === 'survival' ? ui.wave : ui.level) + 1;
                const nextBoss = BOSS_DEFS[bossForLevel(nextRound)];
                return <div className="pixel text-[0.6em] text-yellow-300">{`LAWAN BERIKUTNYA: BOS ${nextRound} - ${nextBoss.name} [${nextBoss.rivalWeapon.toUpperCase()}]`}</div>;
              })()}
            </div>
          </Overlay>
        )}
        {ui.state === 'dead' && (
          <Overlay dim="bg-transparent">
            <div className="flex flex-col items-center gap-[0.8em] text-center animate-[fadeIn_1s_ease-in]">
              <div className="pixel text-[2.4em] text-red-500" style={{ textShadow: '0.08em 0.08em 0 #000' }}>YOU DIED</div>
              {ui.mode === 'survival' ? (
                <div className="pixel text-[0.7em] text-yellow-300">YOU SURVIVED {ui.wave} WAVES - {Math.floor(ui.survivalTime / 60)}:{String(Math.floor(ui.survivalTime % 60)).padStart(2, '0')}</div>
              ) : (
                <>
                  <div className="pixel text-[0.8em] text-yellow-300">
                    AGE {ui.age} <span className="text-white/60">→</span> {ui.age + ui.ageGain}
                  </div>
                  <div className="pixel text-[0.55em] text-white/60">YOU GROW OLDER. YOU HIT HARDER. YOU HAVE LESS HEALTH.</div>
                  {ui.age + ui.ageGain >= 70 ? (
                    <div className="pixel text-[0.6em] text-red-400">THIS BODY CANNOT GO ON...</div>
                  ) : (
                    <div className="pixel text-[0.6em] text-white/50">DEATH COUNTER: {ui.deathCounter} (RESETS ON BOSS KILL)</div>
                  )}
                </>
              )}
              <Btn accent={ui.accent} onClick={act(() => g().respawn())} primary>{ui.mode === 'survival' ? 'RESULTS [ENTER]' : 'RISE AGAIN [ENTER]'}</Btn>
            </div>
          </Overlay>
        )}
        {ui.state === 'gameover' && (
          <Overlay dim="bg-black/80">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[2em] text-red-500">{ui.mode === 'survival' ? 'OVERRUN' : 'DIED OF OLD AGE'}</div>
              <div className="pixel text-[0.6em] text-white/60">{ui.mode === 'survival' ? `YOU HELD OUT FOR ${ui.wave} WAVES (${Math.floor(ui.survivalTime / 60)}:${String(Math.floor(ui.survivalTime % 60)).padStart(2, '0')})${ui.wave >= ui.bestWave && ui.wave > 0 ? ' - NEW RECORD!' : ''}` : `THE ROAD ENDED AT LEVEL ${ui.level} - ${ui.zoneName}`}</div>
              <Stats ui={ui} />
              <div className="flex gap-[0.8em] mt-[0.5em]">
                <Btn accent={ui.accent} onClick={act(() => g().restartZone())} primary>{ui.mode === 'survival' ? 'SURVIVE AGAIN' : 'RETRY ZONE'}</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>MENU</Btn>
              </div>
            </div>
          </Overlay>
        )}
        {ui.state === 'victory' && (
          <Overlay dim="bg-black/75">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[2em] text-yellow-300" style={{ textShadow: '0 0 1em #ffd700' }}>YOU ARE THE MASTER</div>
              <div className="pixel text-[0.6em] text-white/70">200 FLOORS. ONE FIST. AGE {ui.age}.</div>
              <Stats ui={ui} />
              <Btn accent={ui.accent} onClick={act(() => g().toMenu())} primary>RETURN TO MENU</Btn>
            </div>
          </Overlay>
        )}
        {ui.state === 'paused' && (
          <Overlay dim="bg-black/70">
            <div className="flex flex-col items-center gap-[0.8em] text-center">
              <div className="pixel text-[1.6em] text-white">PAUSED</div>
              <div className="pixel text-[0.55em] text-white/60">{ui.mode === 'survival' ? `SURVIVAL - WAVE ${ui.wave}` : `LEVEL ${ui.level} - ${ui.zoneName} - AGE ${ui.age}`}</div>
              <div className="flex flex-wrap justify-center gap-[0.4em] max-w-[30em]">
                {ui.mutations.map((id, i) => {
                  const m = MUTATIONS.find((mm) => mm.id === id);
                  return m ? <span key={i} title={m.name}><MutIconSm id={m.id} color={m.color} /></span> : null;
                })}
              </div>
              <div className="flex gap-[0.8em]">
                <Btn accent={ui.accent} onClick={act(() => g().resume())} primary>RESUME [ESC]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toggleMute())}>{ui.muted ? 'UNMUTE' : 'MUTE'} [M]</Btn>
                <Btn accent="#ff4d4d" onClick={act(() => g().cycleBlood())}>BLOOD: {ui.blood.toUpperCase()} [B]</Btn>
                <Btn accent={ui.accent} onClick={act(() => g().toMenu())}>QUIT</Btn>
              </div>
              <Controls compact />
            </div>
          </Overlay>
        )}
      </div>
      {showTouch && ui.state === 'playing' && !ui.intro && !showSetup && <TouchControls gameRef={gameRef} />}
      {showSetup && <GameSetup gameRef={gameRef} ui={ui} close={closeSetup} restart={restart} quit={quit} showTouch={showTouch} setShowTouch={setShowTouch} fullscreen={fullscreen} toggleFullscreen={toggleFullscreen} />}
    </div>
  );
}

function GameSetup({ gameRef, ui, close, restart, quit, showTouch, setShowTouch, fullscreen, toggleFullscreen }: {
  gameRef: RefObject<Game | null>;
  ui: UIState;
  close: () => void;
  restart: () => void;
  quit: () => void;
  showTouch: boolean;
  setShowTouch: (value: boolean) => void;
  fullscreen: boolean;
  toggleFullscreen: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => { closeRef.current?.focus(); }, []);
  const game = gameRef.current;
  if (!game) return null;

  const weapons: { id: WeaponKind; label: string; key: string; available: boolean }[] = [
    { id: 'fist', label: 'FIST', key: '1', available: true },
    { id: 'pistol', label: 'PISTOL', key: '2', available: true },
    { id: 'rifle', label: 'RIFLE', key: '3', available: game.player.hasRifle },
    { id: 'nunchaku', label: 'NUNCHAKU', key: '4', available: game.player.hasNunchaku },
    { id: 'katana', label: 'KATANA', key: '5', available: game.player.hasKatana },
    { id: 'axe', label: 'AXE', key: '6', available: game.player.hasAxe },
    { id: 'dual', label: 'DUAL', key: '7', available: game.player.hasDual },
    { id: 'bat', label: 'BASEBALL', key: 'T', available: true },
    { id: 'yoyo', label: 'YO-YO', key: '8', available: true },
    { id: 'takamura', label: 'TAKAMURA', key: '9', available: true },
    { id: 'hayabusa', label: 'HAYABUSA', key: '0', available: true },
  ];

  return <div className="game-setup-backdrop" role="dialog" aria-modal="true" aria-labelledby="setup-title" onMouseDown={(event) => event.stopPropagation()}>
    <div className="game-setup pixel">
      <div className="game-setup__header">
        <div><span>GAME DIJEDA</span><h2 id="setup-title">SENJATA &amp; KONTROL</h2></div>
        <button ref={closeRef} type="button" onClick={close} aria-label="Tutup pengaturan"><X size={17} /></button>
      </div>
      <div className="setup-label">PILIH SENJATA KAMU</div>
      <div className="weapon-grid">
        {weapons.map((weapon) => <button key={weapon.id} type="button" disabled={!weapon.available} aria-pressed={ui.weapon === weapon.id} onClick={() => game.setWeapon(weapon.id)}>
          <span>{weapon.label}</span><small>{weapon.key}</small>
        </button>)}
      </div>
      <div className="setup-label">PILIH LAWAN BOS (1 VS 1)</div>
      <div className="weapon-grid">
        {BOSS_ORDER.map((bk, idx) => {
          const bd = BOSS_DEFS[bk];
          const roundN = idx + 1;
          const active = (ui.mode === 'survival' ? ui.wave : ui.level) === roundN;
          return (
            <button
              key={bk}
              type="button"
              aria-pressed={active}
              onClick={() => { game.fightBoss(roundN); close(); }}
            >
              <span>{`BOS ${roundN}: ${bd.rivalWeapon.toUpperCase()}`}</span>
              <small>{bd.name.replace('MASTER ', '')}</small>
            </button>
          );
        })}
      </div>
      <div className="setup-versions">
        <div className="setup-version" role="group" aria-label="Versi nunchaku">
          <span>NUNCHAKU</span>
          {(['v1', 'v2'] as const).map((version) => <button key={version} type="button" disabled={!ui.hasNunchaku} aria-pressed={ui.weapon === 'nunchaku' && ui.nunStyle === version} onClick={() => game.selectNunStyle(version)}>{version.toUpperCase()}</button>)}
        </div>
        <div className="setup-version" role="group" aria-label="Versi yo-yo">
          <span>YO-YO</span>
          {([1, 2] as const).map((version) => <button key={version} type="button" aria-pressed={ui.weapon === 'yoyo' && ui.yoyoVer === version} onClick={() => game.selectYoyoVersion(version)}>V{version}</button>)}
          <label>SKIN <select aria-label="Skin yo-yo V2" value={ui.yoyoSkin} onChange={(event) => { if (isYoyoSkinId(event.target.value)) { game.setYoyoSkin(event.target.value); game.selectYoyoVersion(2); } }}>{YOYO_SKINS.map((skin) => <option key={skin.id} value={skin.id}>{skin.name}</option>)}</select></label>
        </div>
      </div>
      <div className="setup-options">
        <button type="button" onClick={() => game.toggleMute()}>{ui.muted ? 'SUARA: MATI' : 'SUARA: NYALA'}</button>
        <button type="button" onClick={() => setShowTouch(!showTouch)} aria-pressed={showTouch}>SENTUH: {showTouch ? 'NYALA' : 'MATI'}</button>
        <button type="button" onClick={() => game.toggleV2()}>GRAFIK: {ui.v2 ? 'V2' : 'V1'}</button>
        <button type="button" onClick={() => game.toggleLong()}>LONG: {ui.long ? 'NYALA' : 'MATI'}</button>
        <button type="button" onClick={toggleFullscreen} disabled={!document.fullscreenEnabled && !fullscreen}>{fullscreen ? <Minimize2 size={13} /> : <Maximize2 size={13} />} {fullscreen ? 'KECILKAN' : 'LAYAR PENUH'}</button>
      </div>
      <div className="setup-help">WASD GERAK / LMB SERANG &amp; ADU SPAM / C SALING PARRY / G CLASH &amp; SILAT / ESC JEDA</div>
      <div className="setup-actions">
        <button type="button" className="setup-resume" onClick={close}>KEMBALI</button>
        <button type="button" onClick={restart}>ULANGI</button>
        <button type="button" onClick={quit}>MENU AWAL</button>
      </div>
    </div>
  </div>;
}

function Overlay({ children, dim = 'bg-black/40' }: { children: ReactNode; dim?: string }) {
  return (
    <div className={`absolute inset-0 overflow-y-auto ${dim} cursor-default`}>
      <div className="min-h-full py-[1em] flex items-center justify-center w-full">{children}</div>
    </div>
  );
}

function Btn({ children, onClick, primary, accent }: { children: ReactNode; onClick: () => void; primary?: boolean; accent: string }) {
  return (
    <button
      onClick={onClick}
      className={`pixel text-[0.7em] px-[1.2em] py-[0.7em] border-[0.15em] transition-all cursor-pointer hover:translate-x-[0.1em] hover:-translate-y-[0.1em] active:translate-y-0 ${primary ? 'text-black' : 'text-white bg-black/60 hover:bg-white/10'}`}
      style={primary ? { background: accent, borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' } : { borderColor: accent, boxShadow: '0.25em 0.25em 0 #000' }}
    >
      {children}
    </button>
  );
}

function Stats({ ui }: { ui: UIState }) {
  return (
    <div className="grid grid-cols-2 gap-x-[2em] gap-y-[0.3em] pixel text-[0.6em] text-white/80 bg-black/50 p-[1em] border border-white/20">
      <span className="text-white/50">SCORE</span><span>{ui.score}</span>
      <span className="text-white/50">KILLS</span><span>{ui.kills}</span>
      <span className="text-white/50">BEST COMBO</span><span>{ui.bestCombo}</span>
      <span className="text-white/50">DEATHS</span><span>{ui.deaths}</span>
      <span className="text-white/50">MUTATIONS</span><span>{ui.mutations.length}</span>
      {ui.mode === 'survival' ? <><span className="text-white/50">WAVES</span><span>{ui.wave}</span></> : <><span className="text-white/50">BEST LEVEL</span><span>{ui.best.level}</span></>}
    </div>
  );
}

function Controls({ compact }: { compact?: boolean }) {
  return (
    <div className={`grid ${compact ? 'grid-cols-2 gap-x-[2em]' : 'grid-cols-1 sm:grid-cols-2 gap-x-[2em]'} gap-y-[0.25em] pixel text-[0.5em] text-left bg-black/60 border border-white/15 p-[1em] max-w-[52em]`}>
      <div className="text-white/40 col-span-full mb-[0.3em]">CONTROLS</div>
      <Row k="G (FIST / BAT / NUNCHAKU)" v="SILAT ACTION SCENE NEAR AN ENEMY" />
      <Row k="T" v="SELECT BASEBALL BAT / TAUNT WHEN EQUIPPED" />
      <Row k="4 / N" v="NUNCHAKU / SWITCH V1 AND V2" />
      <Row k="WASD" v="MOVE (HOLD TO RUN)" /><Row k="MOUSE" v="AIM" />
      <Row k="LMB" v="LIGHT ATTACK / SHOOT" /><Row k="RMB" v="HEAVY (PALM STRIKE)" />
      <Row k="RUN + LMB (FISTS)" v="TAEKWONDO FLYING SIDE KICK" /><Row k="RUN + RMB (FISTS)" v="MK FLYING KICK / RUNNING STRAIGHT" />
      <Row k="RUN + LMB (WEAPON)" v="DRAGON LASH / IAIJUTSU / GRAND SLAM / PHANTOM CROSS" />
      <Row k="SPACE (AIR) + LMB" v="DIVE KICK" />
      <Row k="SPACE" v="JUMP (HOP OVER BULLETS)" /><Row k="SHIFT" v="SHADOW STEP (DASH, I-FRAMES)" />
      <Row k="C" v="PARRY" />
      <Row k="E" v="FOCUS STRIKE" /><Row k="F" v="FATALITY (ANY ENEMY IN REACH)" />
      <Row k="X" v="ONE FOR ALL (AT 25+ CHARGE): WORLD SLOWS TO 30%, YOU RUN AT REAL TIME, STRIKES AUTO-LOCK" />
      <Row k="CLICK TEMPO (FISTS)" v="FAST = WING CHUN  /  MEDIUM = BLACK LEG KICKS  /  SLOW = KUNG FU HEAVIES" /><Row k="R" v="RAGE (WHEN METER FULL): LMB = DASH + EXECUTE" />
            <Row k="Q / 1-9-0 / WHEEL" v="FIST / PISTOL / RIFLE / NUNCHAKU / KATANA / AXE / DUAL / YOYO / TAKAMURA / HAYABUSA" />
      <Row k="HAYABUSA (0) LMB" v="NINJA CHAIN: MOON SLASH > REVERSE FLOW > AERIAL RAVE > IZUNA DROP (TAP TO FLOW · THE BLADE ITSELF HITS)" />
      <Row k="HAYABUSA (0) RMB" v="TAP = BLADE MODE (SLOW-MO, 3 PRECISE CUTS, THEN ZANDATSU — PETALS, NO LIGHTNING) · HOLD = FLYING SWALLOW DASH-CUT" />
      <Row k="AXE (6) RMB" v="IDLE/WALK = THROW (FLIES, HITS, RETURNS TO YOUR HAND) · RMB AGAIN = RECALL EARLY" />
      <Row k="AXE (6) SHIFT+RMB" v="LEAP SMASH: JUMP THEN CHOP STRAIGHT DOWN (SHOCKWAVE + FROST). IF THE AXE IS OUT IT RACES BACK SO YOU SLAM WITH IT" />
      <Row k="TAKAMURA (9) LMB" v="SWORD CHAIN: BATTOUJUTSU > KESA X-CUT > CHAMPLOO SPIN > RYU TSUI SEN (TAP AGAIN AFTER A CUT TO FLOW INTO THE NEXT · THE BLADE ITSELF DOES THE HITTING)" />
      <Row k="TAKAMURA (9) RMB" v="TAP = RYU SHO SEN (RISING CUT, LAUNCHES) · HOLD + RELEASE = AMAKAKERU RYU NO HIRAMEKI (TWO HUGE CUTS, STRONGER THE LONGER YOU HOLD)" />
      <Row k="TAKAMURA (9) NOTO" v="EVERY ENEMY YOU CUT IS MARKED · WHEN THE BLADE CLICKS BACK INTO THE SAYA THE DELAYED CUTS LAND" />
      <Row k="B" v="BLOOD: NORMAL / GORE / COMBINED" /><Row k="ESC" v="PAUSE" />
      <Row k="V" v="SWITCH LOOK: V2 = CRISP PIXELS + GAME1 RAGDOLL (WALL BOUNCE, DIZZY STARS, KICKABLE BODIES) / V1 = CLASSIC BUILD" />
      {!compact && (
        <>
          <div className="text-white/40 col-span-full mt-[0.8em] mb-[0.3em]">KUNG FU TECHNIQUES</div>
          {MOVE_LIST.map((m) => (
            <div key={m.name} className="col-span-full flex gap-[1em] leading-relaxed">
              <span className="text-yellow-300 min-w-[9em]">{m.keys}</span>
              <span className="text-white">{m.name}</span>
              <span className="text-white/50">{m.desc}</span>
            </div>
          ))}
        </>
      )}
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex gap-[1em]">
      <span className="text-yellow-300 min-w-[9em]">{k}</span>
      <span className="text-white/80">{v}</span>
    </div>
  );
}

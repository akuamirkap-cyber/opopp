import { Sfx } from './audio';
import { BASE_ZOOM, LEVELS_PER_ZONE, PLAYER_BAND, PLAYER_COLOR, TILE, TOTAL_LEVELS, VIEW_H, VIEW_W, ZONES, type Palette } from './constants';
import { buildLevelCanvas, drawHUD, drawShadow, drawStick, drawVignette } from './draw';
import { blendSkeleton, solvePose } from './stick';
import { Nunchaku } from './nunchaku';
import { SFNunchaku } from './sfnunchaku';
import { Katana } from './katana';
import { Yoyo } from './yoyo';
import { YoyoV2 } from './yoyoV2';
import { YOYO_SKIN_KEY, YOYO_SKINS, isYoyoSkinId, type YoyoSkinId } from './yoyoSkins';
import { Takamura } from './takamura';
import { Hayabusa } from './hayabusa';
import { Leviathan } from './leviathan';
import { GunFX } from './gunfx';
import { SILAT, LINK_FLIPS, type SilatScene, type SilatHit } from './silat';
import { Blood, type BloodMode } from './blood';
import { AXE_LEN, BAT_LEN, DUAL_LEN, drawAxe, drawAxeIcon, drawBat, drawDualIcon, drawShortBlade } from './weapons';
import { BOSS_DEFS, bossAttackPoseT, bossForLevel, bossStickOpts, makeEnemy, startBossMove, updateBossWeaponPhysics, updateEnemy } from './enemies';
import { Input } from './input';
import { flowField, freeAt, generateArena, generateLevel, lineOfSight, moveWithCollision, solidAt, unstick, type Level } from './level';
import { MOVES, type Move } from './moves';
import { G1_BIOMES } from './constants';
import { MUTATIONS, rollMutations, type Mutation } from './mutations';
import { Particles, Texts } from './particles';
import { pcircle, pfont, pfontO, pline, prect, pring, px } from './pixel';
import { Rng, angleDiff, clamp, dist, lerp, rnd } from './rng';
import {
  defaultStats, type Afterimage, type Bullet, type BossKind, type Corpse, type Enemy, type EnemyKind, type Fatality, type FatalityKind,
  type GameState, type Hazard, type Pickup, type Player, type PlayerStats, type Pose, type Prop, type Vec, type WeaponKind,
} from './types';

export interface SaveData { level: number; mutations: string[]; score: number; }
export interface RunScore { id: string; score: number; bosses: number; combo: number; time: number; }
export interface UIState {
  state: GameState; level: number; zoneName: string; zoneSub: string; score: number; age: number; deathCounter: number;
  deaths: number; kills: number; bestCombo: number; choices: Mutation[]; save: SaveData | null; best: { level: number; score: number };
  muted: boolean; mutations: string[]; ageGain: number; hp: number; maxHp: number; accent: string;
  mode: GameMode; wave: number; survivalTime: number; bestWave: number; bestSurvivalScore: number; blood: BloodMode;
  v2: boolean;
  long: boolean;
  weapon: WeaponKind;
  yoyoVer: 1 | 2;
  yoyoSkin: YoyoSkinId;
  nunStyle: 'v1' | 'v2';
  hasNunchaku: boolean;
  intro: boolean;
  leaderboard: RunScore[];
}
export type GameMode = 'story' | 'survival';

/** ONE FOR ALL (X), ported from game1: costs 25 to start, burns 8/s (about 12.5s on a full meter),
 *  drops the WORLD to 30% speed while the player runs on real time at 4/3x — so the hero moves
 *  roughly 4.4x faster than everything around him and auto-locks the nearest enemy. */
const OFA_COST = 25, OFA_DRAIN = 8, OFA_WORLD = 0.3, OFA_PLAYER = 4 / 3, OFA_COL = '#57e6ff';

const SAVE_KEY = 'kungfu_drifter_maxkungfu_save_v1';
const SURV_KEY = 'kungfu_drifter_maxkungfu_survival_v1';
const BLOOD_KEY = 'kungfu_drifter_maxkungfu_blood_v1';
const BEST_KEY = 'kungfu_drifter_maxkungfu_best_v1';
const V2_KEY = 'kungfu_drifter_maxkungfu_v2';
const LONG_KEY = 'kungfu_drifter_maxkungfu_long';
const NUN_KEY = 'kungfu_drifter_maxkungfu_nunstyle';
const SCORES_KEY = 'stickfight_local_scores_v1';
const MENU_ZOOM = 16;
const MENU_PALETTE: Palette = {
  bg: '#1b0608', floor: '#20080b', floorAlt: '#260c10', wall: '#310e12', wallTop: '#3d161b', accent: '#ff3838', accent2: '#ffc2ac',
};
const easeOut = (t: number) => 1 - (1 - t) * (1 - t);

export function makePlayer(): Player {
  return {
    x: 0, y: 0, vx: 0, vy: 0, kx: 0, ky: 0, r: 5, hp: 8, maxHp: 8, dead: false, flash: 0, facing: 1, aim: 0, walk: 0, moving: false,
    dashT: 0, dashCd: 0, dashDir: { x: 1, y: 0 }, iframes: 0, comboStr: '', comboTimer: 0, attackT: 0, attackPhase: 'none', moveKey: null,
    hitSet: [], buffered: null, parryT: 0, parryCd: 0, parryHit: false, focus: 100, weapon: 'nunchaku', hasRifle: true, ammoP: 40, ammoR: 60,
    fireCd: 0, recoil: 0, lean: { x: 1, y: 0 }, stunT: 0, lastMoveName: '', focusDash: null, shootT: 0, attackElapsed: 0, sinceDash: 9, attackAim: 0,
    brakeT: 0, brakeCd: 0, prevSpd: 0,
    z: 0, runT: 0, running: false, bloom: 0, muzzle: 0, muzzleMax: 0.06, muzzleX: 0, muzzleY: 0, muzzleA: 0, fatality: null, holdPose: 'idle', holdPoseT: 0, holdT: 0,
    dustT: 0, stepT: 0, travelHit: false,
    hitTimes: {}, prevLimb: null, hasNunchaku: true, hasKatana: true, hasAxe: true, hasDual: true, bladeA: 0, bladeB: 0, bladePrevA: 0, chain: 0, chainLast: -9, chainSide: 1, rage: 0, rageOn: false, rageT: 0, rageDash: null, rageKills: 0, ofa: 0, ofaActive: false, rhythm: [], style: 'none', styleStreak: 0, styleHeat: 0, flowStep: 0, sheatheT: 0, katanaPlan: 0, iaiVictims: [], strideHalf: 3, bodyAim: 0, vz: 0, jumpT: 0, jumpCd: 0, landT: 0, airborne: false, squash: 1, prevPose: 'idle', prevPoseT: 0, blend: 0, lastDir: { x: 1, y: 0 }, tkdCd: 0, tkdT: 0, tkdDir: { x: 1, y: 0 },
  };
}

export class Game {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  scene: HTMLCanvasElement;
  wctx: CanvasRenderingContext2D;
  /** V2: screen-space layers (HUD, letterbox, vignette, wipe) get their own 1:1 buffer so that neither the world
   *  nor the UI is ever resampled twice. V1 draws them straight onto the visible canvas, like the old build. */
  hud: HTMLCanvasElement;
  hctx: CanvasRenderingContext2D;
  /** Which build of the look & feel is running.
   *  V1 = exactly the old build (two-stage nearest upscale: scene -> fractional zoom blit -> CSS).
   *  V2 = crisp single-stage pixels + the game1-flavoured ragdoll (wall slam bounce, dizzy stars, kickable bodies).
   *  Toggle with V or the on-screen button; the choice is persisted. */
  v2 = true;
  /** enemy aggression 0..1. 0.5 = half as eager to swing / shoot. */
  mental = 0.5;
  /** LONG-LIMB mode (tombol L): badan/tangan/kaki 2.5x panjang normal — rig diskalakan seragam
   *  dari telapak kaki di solvePose, jadi reach serangan & posisi senjata otomatis ikut. Persisted. */
  longMode = false;
  input: Input;
  sfx = new Sfx();
  particles = new Particles();
  texts = new Texts();
  state: GameState = 'menu';
  level!: Level;
  levelCanvas!: HTMLCanvasElement;
  levelCtx!: CanvasRenderingContext2D;
  levelN = 1;
  pal: Palette = ZONES[0].pal;
  player: Player = makePlayer();
  enemies: Enemy[] = [];
  bullets: Bullet[] = [];
  pickups: Pickup[] = [];
  props: Prop[] = [];
  corpses: Corpse[] = [];
  hazards: Hazard[] = [];
  afterimages: Afterimage[] = [];
  pendingBooms: { x: number; y: number; t: number; r: number; dmg: number; fromPlayer: boolean }[] = [];
  pools: { x: number; y: number; r: number; max: number; c: string }[] = [];
  fatTargetId = -1;
  flow: Int16Array = new Int16Array(0);
  flowT = 0;
  cam = { x: 0, y: 0 };
  camKick = { x: 0, y: 0 };
  camFocus: Vec | null = null;
  zoom = BASE_ZOOM;
  zoomTarget = BASE_ZOOM;
  zoomKick = 0;
  cinematic = false;
  trauma = 0;
  shakeX = 0;
  shakeY = 0;
  hitstop = 0;
  timeScale = 1;
  slowT = 0;
  slowFactor = 1;
  /** ONE FOR ALL: the enemy the player is auto-locked onto, plus the "press X" announcement latch */
  lockTarget: Enemy | null = null;
  ofaReadySaid = false;
  flashA = 0;
  flashC = '#ffffff';
  time = 0;
  rawDt = 0;
  levelTime = 0;
  bannerT = 0;
  spawnQueue: EnemyKind[] = [];
  spawnTimer = 0;
  maxAlive = 4;
  eliteChance = 0;
  exitOpen = false;
  portalT = 0;
  cleared = false;
  wipe: { t: number; dir: 1 | -1; cb: (() => void) | null } | null = null;
  stats: PlayerStats = defaultStats();
  mutations: string[] = [];
  score = 0;
  kills = 0;
  combo = 0;
  comboTimer = 0;
  comboMax = 2.2;
  comboPop = 0;
  bestCombo = 0;
  meleeHits = 0;
  age = 20;
  deathCounter = 1;
  deaths = 0;
  ageGain = 0;
  choices: Mutation[] = [];
  nextLevelN = 1;
  onUI: ((u: UIState) => void) | null = null;
  rng = new Rng(1);
  running = false;
  raf = 0;
  lastT = 0;
  vignette = { cv: null as HTMLCanvasElement | null };
  save: SaveData | null = null;
  best = { level: 0, score: 0 };
  deathT = 0;
  bossBeatenT = 0;
  hitMarkerT = 0;
  hitMarkerKill = false;
  fatalityTextT = 0;
  fatalityIdx = 0;
  finishCd = 0;
  casingSfxCd = 0;
  heldInput = false;
  lastPoseT = 0;
  menuT = 0;
  menuSwing = 1;
  menuStep = 0;
  menuContactCd = 0;
  menuAnchor = { x: 0, y: 0 };
  menuCamera = { x: 0, y: 0, zoom: MENU_ZOOM };
  menuTransition: { t: number; duration: number; x: number; y: number; zoom: number } | null = null;
  menuInputBlocked = false;
  menuDemoPaused = false;
  scores: RunScore[] = [];
  runSaved = false;
  get isAttractMode() { return this.state === 'menu' || Boolean(this.menuTransition); }
  rageReadySaid = false;
  get pendingFlowKeyStore() { return this._pfk; }
  _pfk: string | null = null;
  timeScaleBonus = 1;
  // ---- survival (endless waves)
  mode: GameMode = 'story';
  wave = 0;
  waveT = 0;            // seconds into the current wave
  waveLen = 30;         // seconds per wave
  survivalTime = 0;
  waveBudget = 0;       // enemies still to pour in this wave
  trickle = 0;          // timer between spawns
  bestSurvival = { wave: 0, score: 0 };
  waveBannerT = 0;
  waveKills = 0;
  pendingChoice = false;
  bossWaveActive = false;
  ambushT = 20;
  nunchaku = new Nunchaku();
  nunStyle: 'v1' | 'v2' = 'v2';
  sfNun = new SFNunchaku();
  sfNunAim = 0;
  parryCounterKey: string | null = null;
  pendingRiposte: { id: number; owner: 'player' | 'boss'; key: string; t: number } | null = null;
  get sfNunOn() { return this.nunStyle === 'v2' && this.player.weapon === 'nunchaku'; }
  /** V2 (game1): idle flourish spin of the chain around the hand. */
  nunFlourish = 0;
  nunFlourishCd = 1;
  /** V2 anti-monoton: tiap flourish di-roll — kadang 2 putaran, kadang 3, arah random */
  nunFlourishTurns = 2;
  nunFlourishDir = 1;
  katana = new Katana();
  yoyo = new Yoyo();
  yoyoV2 = new YoyoV2();
  yoyoVer: 1 | 2 = 2;
  yoyoEchoT = 0;
  yoyoDustT = 0;
  yoyoFeet: { front: Vec; back: Vec } | null = null;
  tak = new Takamura();
  hay = new Hayabusa();
  lev = new Leviathan();
  gunfx = new GunFX();
  silat: { sc: SilatScene; id: number; i: number; t: number; dir: number; from: { f: number; s: number; z: number; r: number }; cur: { f: number; s: number; z: number; r: number }; px: number; py: number; hitDone: boolean; dur: number; id2: number | null; from2: { f: number; s: number; z: number; r: number }; cur2: { f: number; s: number; z: number; r: number } } | null = null;
  silatCd = 0; silatLast = ''; fistHits = 0; fistHitT = -9;
  silatLinkT = 0; silatChainN = 0; silatAcroT = 0; silatParryAlt = 0;
  /** ADEGAN SALING ADU & PARRY (Choreographed 1-for-1 Dynamic Exchange Scene) */
  clashDuel: {
    id: number;
    t: number;
    power: number;
    hits: number;
    maxBeats: number;
    beatsDone: number;
    turn: 'player' | 'boss' | 'both' | 'idle';
    u: number;
    beatDur: number;
    activeTempo: number;
    playerTempo: number;
    bossTempo: number;
    lastPlayerTapAt: number;
    pendingPlayerReplies: number;
    bossReplyQueued: boolean;
    playerContestedBeat: boolean;
    parryTapAt: number | null;
    bossIdleWaitT: number;
    bossBurstLeft: number;
    hitDone: boolean;
    pMoveKey: string;
    bMoveKey: string;
    defenseStyle: 'deflect' | 'duck' | 'hop' | 'pivot' | 'lock';
    beatOutcome: 'perfect' | 'clash' | 'pushed';
    dir: number;
    targetDir: number;
    baseDir: number;
    cx: number;
    cy: number;
    targetCx: number;
    targetCy: number;
    poseIdx: number;
    recoilT: number;
    recoilMoved: number;
    recoilDir: number;
    recoilGap: number;
  } | null = null;
  clashCd = 0;
  batFlow = 0; batLastSpecial = ''; batSpam = 0; batSpamT = 0; batTauntT = 0;
  batJuggle = 0; batLastT = -9; batTwirl = 0; batTwirlCd = 1.5; batEquippedAt = -9;
  wallHits: { x: number; y: number; a: number; t: number }[] = [];
  blood = new Blood();
  nSpin = 0;
  enemyMuzzles: { x: number; y: number; a: number; t: number; c: string }[] = [];
  tokenTimer = 0;
  runHeavyToggle = 0;
  prevBlade: { base: Vec; tip: Vec } | null = null;
  /** One compact notification at a time, above the action. */
  announce: { text: string; c: string; t: number; max: number; scale: number }[] = [];
  say(text: string, c: string, scale = 2, life = 1.1) {
    if (this.clashDuel || this.isAttractMode) return;
    this.announce = [{ text, c, t: 0, max: Math.min(life, 1), scale: Math.min(scale, 1) }];
  }
  fatalityCd = 0;
  static FATALITY_CD = 7;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d')!;
    this.scene = document.createElement('canvas');
    this.scene.width = VIEW_W;
    this.scene.height = VIEW_H;
    this.wctx = this.scene.getContext('2d')!;
    this.hud = document.createElement('canvas');
    this.hud.width = VIEW_W;
    this.hud.height = VIEW_H;
    this.hctx = this.hud.getContext('2d')!;
    this.input = new Input(canvas);
    try {
      this.save = JSON.parse(localStorage.getItem(SAVE_KEY) || 'null');
      this.best = JSON.parse(localStorage.getItem(BEST_KEY) || 'null') || { level: 0, score: 0 };
      this.bestSurvival = JSON.parse(localStorage.getItem(SURV_KEY) || 'null') || { wave: 0, score: 0 };
      const scores: unknown = JSON.parse(localStorage.getItem(SCORES_KEY) || '[]');
      if (Array.isArray(scores)) this.scores = scores.filter((entry): entry is RunScore =>
        entry && typeof entry.id === 'string' && ['score', 'bosses', 'combo', 'time'].every((key) => Number.isFinite(entry[key]) && entry[key] >= 0)
      ).sort((a, b) => b.score - a.score).slice(0, 8);
      const vv = localStorage.getItem(V2_KEY);
      if (vv === '0' || vv === '1') this.v2 = vv === '1';
      const lv = localStorage.getItem(LONG_KEY);
      if (lv === '0' || lv === '1') this.longMode = lv === '1';
      const nun = localStorage.getItem(NUN_KEY);
      if (nun === 'v1' || nun === 'v2') this.nunStyle = nun;
      const bm = localStorage.getItem(BLOOD_KEY);
      if (bm === 'normal' || bm === 'gore' || bm === 'combined') this.blood.mode = bm;
      const skin = localStorage.getItem(YOYO_SKIN_KEY);
      if (isYoyoSkinId(skin)) this.yoyoV2.setSkin(skin);
    } catch { /* ignore */ }
    this.particles.onLand = (x, y, c, s) => this.stamp(x, y, c, s);
    this.particles.bloodEnabled = () => this.blood.classic;
    this.particles.onCasing = () => { if (this.casingSfxCd <= 0) { this.sfx.casing(); this.casingSfxCd = 0.05; } };
    // Let the choreography and sparks carry feedback during a close-up exchange.
    this.texts.enabled = () => !this.clashDuel && !this.isAttractMode;
    this.loadLevel(1);
    this.toMenu();
  }

  // ------------------------------------------------------------------ lifecycle
  start() {
    if (this.running) return;
    this.running = true;
    this.lastT = performance.now();
    const loop = (ts: number) => {
      if (!this.running) return;
      const raw = Math.min(0.05, (ts - this.lastT) / 1000);
      this.lastT = ts;
      this.frame(raw);
      this.render();
      this.endFrameInput();
      this.raf = requestAnimationFrame(loop);
    };
    this.raf = requestAnimationFrame(loop);
    this.pushUI();
  }
  destroy() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.input.destroy();
    this.sfx.dispose();
  }
  /** Taps that land on a hit-stop frame are kept buffered until the next simulated frame (no dropped inputs). */
  endFrameInput() {
    if (this.heldInput) { this.heldInput = false; return; }
    this.input.endFrame();
  }

  pushUI() {
    const z = ZONES[this.level.zone];
    this.onUI?.({
      state: this.state, level: this.levelN, zoneName: z.name, zoneSub: z.sub, score: this.score, age: this.age, deathCounter: this.deathCounter,
      deaths: this.deaths, kills: this.kills, bestCombo: this.bestCombo, choices: this.choices, save: this.save, best: this.best,
      muted: this.sfx.muted, mutations: [...this.mutations], ageGain: this.ageGain, hp: this.player.hp, maxHp: this.maxHp(), accent: this.pal.accent,
      mode: this.mode, wave: this.wave, survivalTime: this.survivalTime, bestWave: this.bestSurvival.wave, bestSurvivalScore: this.bestSurvival.score, blood: this.blood.mode, v2: this.v2, long: this.longMode,
      weapon: this.player.weapon, yoyoVer: this.yoyoVer, yoyoSkin: this.yoyoV2.skinId,
      nunStyle: this.nunStyle, hasNunchaku: this.player.hasNunchaku,
      intro: Boolean(this.menuTransition), leaderboard: this.leaderboard(),
    });
  }

  moveDirOf(vx: number, vy: number): Vec | undefined {
    const l = Math.hypot(vx, vy);
    return l > 3 ? { x: vx / l, y: vy / l } : undefined;
  }
  maxHp() {
    return clamp(8 + this.stats.hpBonus - Math.floor((this.age - 20) / 12), 4, 16);
  }
  ageDmg() {
    return 1 + (this.age - 20) * 0.012;
  }
  comboMult() {
    return 1 + Math.floor(this.combo / 5) * 0.5;
  }

  clearCombatScene() {
    this.menuTransition = null;
    this.parryCounterKey = null;
    this.pendingRiposte = null;
    const active = this.silat;
    if (active) {
      for (const e of this.enemies) {
        if (e.id !== active.id && e.id !== active.id2) continue;
        e.scenePose = undefined; e.sceneZ = 0; e.sceneRot = 0;
        if (!e.dead && e.stagger > 1) { e.stagger = 0; e.state = 'chase'; e.pose = 'idle'; e.attackCd = Math.max(e.attackCd, 0.5); }
      }
      this.player.holdT = 0; this.player.z = 0;
      this.cinematic = false; this.zoomTarget = BASE_ZOOM; this.camFocus = null;
    }
    if (this.clashDuel) {
      const ce = this.enemies.find((en) => en.id === this.clashDuel!.id);
      if (ce) { ce.scenePose = undefined; ce.sceneZ = 0; ce.sceneRot = 0; }
      this.player.holdT = 0; this.player.z = 0;
      this.cinematic = false; this.zoomTarget = BASE_ZOOM; this.camFocus = null;
    }
    this.clashDuel = null; this.clashCd = 0;
    this.silat = null; this.silatPending = null; this.silatCd = 0; this.silatLinkT = 0; this.silatChainN = 0;
    this.fistHits = 0; this.fistHitT = -9; this.batFlow = 0; this.batSpam = 0; this.batJuggle = 0; this.batTauntT = 0;
  }

  // ------------------------------------------------------------------ game flow
  newGame(fromSave: SaveData | null, automatic = false) {
    this.clearCombatScene();
    this.runSaved = false;
    this.mode = 'story';
    if (!automatic) { this.sfx.init(); this.input.focus(); }
    this.stats = defaultStats();
    this.mutations = [];
    this.score = 0; this.kills = 0; this.combo = 0; this.bestCombo = 0; this.deaths = 0; this.meleeHits = 0;
    this.age = 20; this.deathCounter = 1;
    this.player = makePlayer();
    let start = 1;
    if (fromSave) {
      start = fromSave.level;
      this.score = fromSave.score;
      for (const id of fromSave.mutations) {
        const m = MUTATIONS.find((mm) => mm.id === id);
        if (m) { m.apply(this.stats); this.mutations.push(id); }
      }
      if (start >= 5) { this.player.hasRifle = true; this.player.ammoR = 60; }
      if (start >= 3) this.player.hasNunchaku = true;
      if (start >= 7) this.player.hasKatana = true;
      if (start >= 9) this.player.hasAxe = true;
      if (start >= 11) this.player.hasDual = true;
      this.player.hp = this.maxHp();
    }
    this.state = 'playing';
    this.startLevel(start);
    this.wipe = { t: 1, dir: 1, cb: null };
    this.sfx.startMusic(this.level.zone);
  }

  // ================================================================== SURVIVAL (endless waves)
  newSurvival(automatic = false) {
    this.clearCombatScene();
    this.runSaved = false;
    this.mode = 'survival';
    if (!automatic) { this.sfx.init(); this.input.focus(); }
    this.stats = defaultStats();
    this.mutations = [];
    this.score = 0; this.kills = 0; this.combo = 0; this.bestCombo = 0; this.deaths = 0; this.meleeHits = 0;
    this.age = 20; this.deathCounter = 1;
    this.player = makePlayer();
    this.player.hasNunchaku = true; this.player.hasKatana = true; this.player.hasAxe = true; this.player.hasDual = true; this.player.hasRifle = true; this.player.ammoR = 60; this.player.ammoP = 40;
    this.wave = 0; this.waveT = 0; this.survivalTime = 0; this.waveBudget = 0; this.trickle = 0; this.waveKills = 0; this.pendingChoice = false; this.bossWaveActive = false; this.ambushT = 20;
    this.state = 'playing';
    this.levelN = 1;
    this.level = generateArena(Date.now() % 100000, !this.v2);
    this.applyPalette(true);
    this.levelCtx = this.levelCanvas.getContext('2d')!;
    this.blood.resetFloor(this.levelCanvas.width, this.levelCanvas.height);
    this.blood.solid = (x, y) => solidAt(this.level, x, y);
    this.flow = flowField(this.level, this.level.spawn.x, this.level.spawn.y);
    const p = this.player;
    this.enemies = []; this.bullets = []; this.pickups = []; this.props = []; this.corpses = []; this.hazards = []; this.afterimages = []; this.pendingBooms = []; this.pools = [];
    this.particles.list = []; this.texts.list = []; this.announce = [];
    p.x = this.level.spawn.x; p.y = this.level.spawn.y; p.hp = this.maxHp();
    this.resetCamera();
    this.rng = new Rng(this.level.seed);
    for (let i = 0; i < 6; i++) {
      const pos = this.randomFloorNear(p.x, p.y, 60, 9999, this.rng);
      if (pos) this.props.push({ x: pos.x, y: pos.y, kind: this.rng.chance(0.4) ? 'barrel' : 'crate', hp: 3, r: 6, dead: false, flash: 0 });
    }
    this.spawnQueue = []; this.maxAlive = 999; this.exitOpen = false; this.cleared = true; this.levelTime = 0; this.bannerT = 0; this.flowT = 0;
    this.cam.x = p.x - VIEW_W / 2; this.cam.y = p.y - VIEW_H / 2;
    this.wipe = { t: 1, dir: 1, cb: null };
    this.sfx.startMusic(0);
    this.startWave(1);
    this.pushUI();
  }

  /** difficulty derived from the wave number: never stops growing */
  waveDiff() { return this.wave / 18; }
  /** virtual "level" used by enemy stat scaling and kind unlocks (hp/speed/dmg keep scaling past the story cap) */
  waveLevel() { return Math.floor(this.wave * 9); }

  /** Jump directly to a 1vs1 duel against Boss #n (1 = Nunchaku, 2 = Katana, 3 = Kung Fu, 4 = Bat, 5 = Dual, 6 = Yo-Yo, 7 = Axe, 8 = Takamura) */
  fightBoss(n: number) {
    if (this.state !== 'playing' && this.state !== 'paused') {
      this.newSurvival();
    }
    this.state = 'playing';
    this.pendingChoice = false;
    this.startWave(Math.max(1, n));
  }

  startWave(n: number) {
    this.clearCombatScene();
    this.wave = n; this.waveT = 0; this.waveKills = 0;
    this.waveLen = 9999;
    this.waveBudget = 0;
    this.trickle = 999;
    this.bossWaveActive = true;
    this.eliteChance = 0;
    this.levelN = n;
    this.maxAlive = 1;
    this.level.zone = (n - 1) % ZONES.length;
    this.level.seed = n * 17 + 3;
    this.applyPalette(true);
    this.sfx.setIntensity(Math.min(19, (n - 1) * 2));
    this.waveBannerT = 2.4;

    const p = this.player;
    this.enemies = []; this.bullets = []; this.hazards = []; this.pendingBooms = [];
    p.x = this.level.spawn.x; p.y = this.level.spawn.y;
    p.vx = p.vy = p.kx = p.ky = 0; p.z = 0; p.vz = 0; p.airborne = false;
    p.facing = 1; p.aim = 0;
    this.nunchaku.reset(p.x + 4, p.y - 8);
    this.sfNun.reset(p.x, p.y - 8);
    if (p.weapon === 'yoyo') {
      this.yoyo.reset(p.x + 6, p.y + 2);
      this.yoyoV2.reset(p.x + 6, p.y - 7);
    }

    const bk = bossForLevel(n);
    const bd = BOSS_DEFS[bk];
    this.spawnEnemyAt('boss', this.level.exit.x, this.level.exit.y, false, bk);
    this.say(`BOS ${n}: ${bd.name}`, bd.color, 3, 2.2);
    this.say(`SENJATA: ${bd.rivalWeapon.toUpperCase()}`, '#ffffff', 1, 2.2);
    if (n > 1) {
      this.sfx.announce();
      p.hp = Math.min(this.maxHp(), p.hp + 2);
    }
    p.ammoP = Math.min(Math.round(60 * this.stats.maxAmmo), p.ammoP + 15);
    p.ammoR = Math.min(Math.round(180 * this.stats.maxAmmo), p.ammoR + 30);
    this.pushUI();
  }

  pickSurvivalKind(): EnemyKind {
    return 'boss';
  }

  survivalSpawnPos(): Vec | null {
    return { x: this.level.exit.x, y: this.level.exit.y };
  }

  updateSurvival(dt: number) {
    this.survivalTime += dt;
    this.waveT += dt;
    if (this.bossBeatenT > 0) this.bossBeatenT -= dt;
    const n = this.wave;
    const bossAlive = this.enemies.some((e) => !e.dead);
    const done = !bossAlive && this.waveT > 0.6 && this.bossBeatenT <= 0.6 && !this.player.fatality && !this.silat;
    if (done && !this.pendingChoice) {
      this.score += 200 + n * 50;
      this.say(`BOS ${n} DIKALAHKAN!`, '#ffd700', 2, 1.6);
      this.sfx.levelClear();
      this.updateSurvivalBest();
      this.choices = rollMutations(this.mutations, 3);
      this.pendingChoice = true;
      this.state = 'mutation';
      this.nextLevelN = -1;
      this.pushUI();
    }
  }

  updateSurvivalBest() {
    let changed = false;
    if (this.wave > this.bestSurvival.wave) { this.bestSurvival.wave = this.wave; changed = true; }
    if (this.score > this.bestSurvival.score) { this.bestSurvival.score = this.score; changed = true; }
    if (changed) try { localStorage.setItem(SURV_KEY, JSON.stringify(this.bestSurvival)); } catch { /* ignore */ }
  }

  leaderboard(): RunScore[] {
    if (this.scores.length) return [...this.scores];
    if (this.bestSurvival.score > 0) return [{ id: 'best', score: this.bestSurvival.score, bosses: Math.max(0, this.bestSurvival.wave - 1), combo: 0, time: 0 }];
    return [];
  }

  private recordScore() {
    if (this.isAttractMode || this.mode !== 'survival' || this.runSaved || this.score <= 0) return;
    this.runSaved = true;
    this.scores = [...this.scores, {
      id: `${Date.now()}-${Math.floor(Math.random() * 100000)}`,
      score: this.score, bosses: this.kills, combo: this.bestCombo, time: Math.floor(this.survivalTime),
    }].sort((a, b) => b.score - a.score || b.bosses - a.bosses).slice(0, 8);
    this.updateSurvivalBest();
    try { localStorage.setItem(SCORES_KEY, JSON.stringify(this.scores)); } catch { /* Storage may be unavailable. */ }
  }

  toMenu() {
    this.recordScore();
    this.clearCombatScene();
    this.state = 'menu';
    this.mode = 'survival';
    this.sfx.stopMusic();
    this.stats = defaultStats(); this.mutations = [];
    this.score = 0; this.kills = 0; this.combo = 0; this.bestCombo = 0; this.deaths = 0;
    this.age = 20; this.deathCounter = 1; this.survivalTime = 0; this.waveT = 0;
    this.wave = 1; this.levelN = 1; this.waveBudget = 0; this.maxAlive = 1; this.bossWaveActive = true;
    this.level = generateArena(7, !this.v2);
    this.pal = MENU_PALETTE;
    this.levelCanvas = buildLevelCanvas(this.level, this.pal, this.v2);
    this.levelCtx = this.levelCanvas.getContext('2d')!;
    this.blood.resetFloor(this.levelCanvas.width, this.levelCanvas.height);
    this.blood.solid = (x, y) => solidAt(this.level, x, y);
    this.bullets = []; this.pickups = []; this.props = []; this.hazards = []; this.corpses = [];
    this.afterimages = []; this.announce = []; this.texts.list = []; this.particles.list = [];
    this.pendingBooms = []; this.pools = []; this.spawnQueue = [];
    this.exitOpen = false; this.cleared = true; this.pendingChoice = false; this.choices = [];
    this.wipe = null; this.bannerT = 0; this.levelTime = 0; this.bossBeatenT = 0;
    this.hitstop = 0; this.flashA = 0; this.slowT = 0; this.timeScale = 1; this.trauma = 0;
    this.longMode = false;
    this.player = makePlayer();
    const p = this.player;
    p.weapon = 'fist'; p.x = this.level.w * TILE / 2; p.y = this.level.h * TILE / 2;
    p.aim = p.attackAim = p.bodyAim = Math.PI; p.facing = -1; p.lean = { x: -1, y: 0 };
    this.menuAnchor = { x: p.x, y: p.y };
    const boss = makeEnemy('boss', 'nunchaku', p.x - 36, p.y, 1, false);
    boss.spawnT = 0; boss.attackCd = 0.7; boss.aim = boss.bodyAim = 0; boss.facing = 1;
    this.enemies = [boss];
    this.flow = flowField(this.level, p.x, p.y);
    this.nunchaku.reset(p.x - 4, p.y - 8); this.sfNun.reset(p.x - 4, p.y - 8);
    this.menuT = 0; this.menuStep = 0; this.menuSwing = 0.9; this.menuContactCd = 0;
    this.menuInputBlocked = false; this.menuDemoPaused = false;
    this.menuCamera = {
      x: p.x - VIEW_W / 2 - (VIEW_W * 0.76 - VIEW_W / 2) / MENU_ZOOM,
      y: p.y - VIEW_H / 2 - (VIEW_H * 1.02 - VIEW_H / 2) / MENU_ZOOM,
      zoom: MENU_ZOOM,
    };
    this.resetCamera();
    this.updateCamera(0);
    this.pushUI();
  }

  startFromMenu() {
    if (this.state !== 'menu' || this.menuInputBlocked) return;
    // Keep the live actors and attack phases; only the camera and ownership change.
    this.menuTransition = { t: 0, duration: 1.35, x: this.cam.x, y: this.cam.y, zoom: this.zoom };
    this.state = 'playing';
    this.runSaved = false; this.menuDemoPaused = false;
    this.zoomTarget = BASE_ZOOM;
    this.input.mouse.down = false; this.input.mouse.rdown = false;
    this.input.endFrame(); this.input.focus();
    this.sfx.init(); this.sfx.startMusic(0);
    this.pushUI();
  }

  previewContact(e: Enemy) {
    if (this.menuContactCd > 0) return;
    this.menuContactCd = 0.35;
    this.particles.spark((this.player.x + e.x) / 2, this.player.y - 6, 2, '#ffd9c4', Math.PI / 2, 1, 40);
    if (this.menuTransition) this.sfx.clashPing(0.9);
  }

  private updateMenuFight(raw: number) {
    if (this.menuDemoPaused) return;
    this.menuT += raw;
    this.menuContactCd = Math.max(0, this.menuContactCd - raw);
    const p = this.player, e = this.enemies[0];
    if (!e) return;
    const dt = raw * 0.8;
    this.menuSwing -= dt;
    if (p.attackPhase === 'none' && this.menuSwing <= 0) {
      const moves = ['L', 'LL', 'LH', 'L', 'LLL', 'H'];
      this.startAttack(moves[this.menuStep++ % moves.length]);
      this.menuSwing = 0.7 + this.rng.next() * 0.35;
    }
    if (p.attackPhase === 'none' && e.attackPhase === 'windup') p.parryT = 0.2;

    const input = this.input;
    const real = { keys: input.keys, pressed: input.pressed, mouse: input.mouse, muted: this.sfx.muted };
    input.keys = new Set(); input.pressed = new Set();
    input.mouse = {
      ...real.mouse, x: VIEW_W / 2 + (e.x - this.cam.x - VIEW_W / 2) * this.zoom,
      y: VIEW_H / 2 + (e.y - 6 - this.cam.y - VIEW_H / 2) * this.zoom,
      down: false, rdown: false, mdown: false, pressed: false, rpressed: false, wheel: 0,
    };
    if (this.state === 'menu') this.sfx.muted = true;
    try {
      this.updatePlayer(dt);
      updateEnemy(this, e, dt);
      this.physics(dt);
    } finally {
      input.keys = real.keys; input.pressed = real.pressed; input.mouse = real.mouse;
      this.sfx.muted = real.muted;
    }
    // Sparring footwork stays inside the locked portrait framing until handoff.
    p.x = clamp(p.x, this.menuAnchor.x - 0.8, this.menuAnchor.x + 0.8);
    p.y = clamp(p.y, this.menuAnchor.y - 0.4, this.menuAnchor.y + 0.4);
    e.x = clamp(e.x, this.menuAnchor.x - 44, this.menuAnchor.x - 36);
    e.y = clamp(e.y, this.menuAnchor.y - 2, this.menuAnchor.y + 2);
    p.kx = p.ky = 0; e.kx = e.ky = 0;
    this.particles.update(dt); this.blood.update(dt); this.texts.update(dt);
    for (let i = this.afterimages.length - 1; i >= 0; i--) {
      this.afterimages[i].life -= dt;
      if (this.afterimages[i].life <= 0) this.afterimages.splice(i, 1);
    }
    this.hitstop = 0; this.flashA = 0; this.trauma = 0;
  }

  pause() { if (this.state === 'playing') { this.state = 'paused'; this.pushUI(); } }
  resume() { if (this.state === 'paused') { this.state = 'playing'; this.sfx.init(); this.input.focus(); this.pushUI(); } }
  toggleMute() { this.sfx.init(); this.sfx.toggleMute(); this.pushUI(); }
  setBlood(m: BloodMode) {
    this.blood.mode = m;
    try { localStorage.setItem(BLOOD_KEY, m); } catch { /* ignore */ }
    this.sfx.select();
    if (this.state === 'playing') this.say(m === 'normal' ? 'BLOOD: NORMAL' : m === 'gore' ? 'BLOOD: GORE' : 'BLOOD: COMBINED', '#ff4d4d', 1, 0.9);
    this.pushUI();
  }
  cycleBlood() { this.setBlood(this.blood.mode === 'normal' ? 'gore' : this.blood.mode === 'gore' ? 'combined' : 'normal'); }

  private loadLevel(n: number) {
    this.level = generateLevel(n);
    this.applyPalette(true);
    this.levelCtx = this.levelCanvas.getContext('2d')!;
    this.blood.resetFloor(this.levelCanvas.width, this.levelCanvas.height);
    this.blood.solid = (x, y) => solidAt(this.level, x, y);
    this.flow = flowField(this.level, this.level.spawn.x, this.level.spawn.y);
  }

  resetCamera() {
    this.cinematic = false; this.zoomTarget = BASE_ZOOM; this.zoom = BASE_ZOOM; this.zoomKick = 0; this.camFocus = null; this.camKick.x = this.camKick.y = 0;
  }

  startLevel(n: number) {
    this.clearCombatScene();
    this.levelN = n;
    this.loadLevel(n);
    const p = this.player;
    this.enemies = []; this.bullets = []; this.pickups = []; this.props = []; this.corpses = []; this.hazards = []; this.afterimages = []; this.pendingBooms = []; this.pools = [];
    this.particles.list = []; this.texts.list = [];
    p.x = this.level.spawn.x; p.y = this.level.spawn.y; p.vx = p.vy = p.kx = p.ky = 0;
    p.dashT = 0; p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; p.parryT = 0; p.fatality = null; p.focusDash = null; p.stunT = 0; p.iframes = 0.5;
    p.z = 0; p.holdT = 0; p.runT = 0; p.running = false; p.bloom = 0; p.muzzle = 0; p.chain = 0; p.rageDash = null;
    p.ofaActive = false; this.lockTarget = null; this.ofaReadySaid = p.ofa >= OFA_COST;
    p.hp = Math.min(Math.max(p.hp, 1), this.maxHp());
    this.resetCamera();
    this.fatalityTextT = 0; this.slowT = 0; this.timeScale = 1;
    this.rng = new Rng(this.level.seed * 31 + 7);
    this.combo = 0; this.comboTimer = 0;
    const propCount = this.level.isBoss ? 2 : 2 + this.rng.int(1, 4);
    for (let i = 0; i < propCount; i++) {
      const pos = this.randomFloorNear(p.x, p.y, 70, 9999, this.rng);
      if (pos && dist(pos.x, pos.y, this.level.exit.x, this.level.exit.y) > 24) {
        this.props.push({ x: pos.x, y: pos.y, kind: this.rng.chance(0.42) ? 'barrel' : 'crate', hp: 3, r: 6, dead: false, flash: 0 });
      }
    }
    this.spawnQueue = [];
    this.eliteChance = 0;
    this.maxAlive = 1;
    const far = this.farthestFloor();
    const bk = bossForLevel(n);
    const bd = BOSS_DEFS[bk];
    this.spawnEnemyAt('boss', far.x, far.y, false, bk);
    this.say(`BOS ${n}: ${bd.name}`, bd.color, 3, 2.2);
    this.say(`SENJATA: ${bd.rivalWeapon.toUpperCase()}`, '#ffffff', 1, 2.2);
    this.nunchaku.reset(p.x + 4, p.y - 8);
    this.sfNun.reset(p.x, p.y - 8);
    this.exitOpen = false; this.cleared = false; this.portalT = 0; this.levelTime = 0; this.bannerT = 2.4; this.flowT = 0;
    this.cam.x = p.x - VIEW_W / 2; this.cam.y = p.y - VIEW_H / 2;
    this.sfx.setIntensity(this.level.zone);
    if ((n - 1) % LEVELS_PER_ZONE === 0) this.saveCheckpoint();
    this.updateBest();
    this.pushUI();
  }

  saveCheckpoint() {
    this.save = { level: this.levelN, mutations: [...this.mutations], score: this.score };
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.save)); } catch { /* ignore */ }
  }
  updateBest() {
    let changed = false;
    if (this.levelN > this.best.level) { this.best.level = this.levelN; changed = true; }
    if (this.score > this.best.score) { this.best.score = this.score; changed = true; }
    if (changed) try { localStorage.setItem(BEST_KEY, JSON.stringify(this.best)); } catch { /* ignore */ }
  }

  onLevelCleared() {
    this.cleared = true;
    this.exitOpen = true;
    this.sfx.levelClear();
    this.slow(0.5, 0.25);
    this.flash(this.pal.accent, 0.25);
    this.say('LEVEL CLEAR!', this.pal.accent, 3, 1.6);
    this.score += this.levelN * 25;
    const p = this.player;
    const ex = this.level.exit;
    const kind: Pickup['kind'] = p.hp < this.maxHp() ? 'hp' : p.hasRifle && p.ammoR < 40 ? 'ammoR' : p.ammoP < 30 ? 'ammoP' : 'focus';
    this.pickups.push({ x: ex.x + 16, y: ex.y + 4, kind, t: 0, vx: 0, vy: 0, magnet: false });
    this.particles.shockwave(ex.x, ex.y, 40, this.pal.accent, 0.6);
    this.updateBest();
  }

  beginExit() {
    if (this.wipe) return;
    this.sfx.portal();
    this.wipe = { t: 0, dir: -1, cb: () => this.nextLevel() };
  }

  nextLevel() {
    const n = this.levelN;
    if (n >= TOTAL_LEVELS) { this.victory(); return; }
    this.nextLevelN = n + 1;
    if (n % 3 === 0 || this.level.isBoss) {
      this.choices = rollMutations(this.mutations, 3);
      this.state = 'mutation';
      this.pushUI();
    } else {
      this.startLevel(n + 1);
    }
  }

  chooseMutation(i: number) {
    const m = this.choices[i];
    if (!m) return;
    m.apply(this.stats);
    this.mutations.push(m.id);
    const p = this.player;
    if (m.instant === 'heal') p.hp = Math.min(this.maxHp(), p.hp + 1);
    if (m.instant === 'fullheal') { p.hp = this.maxHp(); p.focus = 300; }
    if (m.instant === 'ammo') { p.ammoP = Math.min(60 * this.stats.maxAmmo, p.ammoP + 40); if (p.hasRifle) p.ammoR = Math.min(180 * this.stats.maxAmmo, p.ammoR + 100); }
    if (m.instant === 'youth') { this.age = Math.max(20, this.age - 6); }
    this.sfx.select();
    this.state = 'playing';
    this.choices = [];
    this.input.focus();
    if (this.mode === 'survival') { this.pendingChoice = false; this.startWave(this.wave + 1); return; }
    this.startLevel(this.nextLevelN);
    this.wipe = { t: 1, dir: 1, cb: null };
  }

  die() {
    this.recordScore();
    const p = this.player;
    p.hp = 0;
    p.ofaActive = false; this.lockTarget = null;
    this.state = 'dead';
    this.deathT = 0;
    this.deaths++;
    this.ageGain = this.deathCounter;
    this.sfx.death();
    this.flash('#ff0000', 0.6);
    this.shake(1);
    this.particles.blood(p.x, p.y - 6, 30, p.aim + Math.PI, 160);
    for (let i = 0; i < 4; i++) this.particles.limb(p.x, p.y - 6, rnd(0, 6.3), 140, '#ffffff', 4);
    this.splat(p.x, p.y, 10);
    this.corpses.push({ x: p.x, y: p.y, rot: p.aim, color: '#ffffff', color2: PLAYER_BAND, scale: 1, accessory: 'headband', vx: 0, vy: 0, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
    this.slow(1.5, 0.3);
    this.cinematic = false; this.camFocus = null; this.zoomTarget = 1.3 * BASE_ZOOM;
    this.pushUI();
  }

  respawn() {
    if (this.state !== 'dead') return;
    if (this.mode === 'survival') { this.updateSurvivalBest(); this.gameOver(); return; }
    this.age += this.deathCounter;
    this.deathCounter++;
    if (this.age >= 70) { this.gameOver(); return; }
    this.player.hp = this.maxHp();
    this.state = 'playing';
    this.input.focus();
    this.startLevel(this.levelN);
    this.wipe = { t: 1, dir: 1, cb: null };
    this.say('OLDER. STRONGER.', '#ffd700', 2, 1.6);
  }

  gameOver() {
    this.recordScore();
    this.state = 'gameover';
    this.sfx.stopMusic();
    this.updateBest();
    this.pushUI();
  }

  victory() {
    this.state = 'victory';
    this.sfx.stopMusic();
    this.sfx.levelClear();
    this.updateBest();
    try { localStorage.removeItem(SAVE_KEY); } catch { /* ignore */ }
    this.save = null;
    this.pushUI();
  }

  restartZone() {
    if (this.mode === 'survival') { this.newSurvival(); return; }
    const zoneStart = Math.floor((this.levelN - 1) / LEVELS_PER_ZONE) * LEVELS_PER_ZONE + 1;
    const keep: SaveData = { level: zoneStart, mutations: [...this.mutations], score: this.score };
    this.newGame(keep);
  }

  // ------------------------------------------------------------------ helpers
  shake(t: number) { this.trauma = Math.min(1, this.trauma + t); }
  slow(dur: number, factor: number) { this.slowT = Math.max(this.slowT, dur); this.slowFactor = factor; }
  flash(c: string, a: number) { this.flashC = c; this.flashA = Math.max(this.flashA, a); }
  isFree(x: number, y: number, r: number) { return freeAt(this.level, x, y, r * 0.8); }
  hasLOS(e: { x: number; y: number }) { return lineOfSight(this.level, e.x, e.y, this.player.x, this.player.y); }
  mouseWorld(): Vec {
    const z = this.zoom;
    return { x: this.cam.x + VIEW_W / 2 + (this.input.mouse.x - VIEW_W / 2) / z, y: this.cam.y + VIEW_H / 2 + (this.input.mouse.y - VIEW_H / 2) / z };
  }
  randomFloorNear(x: number, y: number, minD: number, maxD: number, rng?: Rng): Vec | null {
    const ft = this.level.floorTiles;
    for (let i = 0; i < 40; i++) {
      const t = rng ? rng.pick(ft) : ft[Math.floor(Math.random() * ft.length)];
      const px0 = t.x * TILE + TILE / 2, py0 = t.y * TILE + TILE / 2;
      const d = dist(px0, py0, x, y);
      if (d >= minD && d <= maxD && this.isFree(px0, py0, 6)) return { x: px0, y: py0 };
    }
    return null;
  }
  farthestFloor(): Vec {
    return { x: this.level.exit.x, y: this.level.exit.y };
  }
  stamp(x: number, y: number, c: string, s: number, force = false) {
    if (!force && solidAt(this.level, x, y)) return;
    const ctx = this.blood.gore && this.blood.sctx ? this.blood.sctx : this.levelCtx;
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = c;
    ctx.fillRect(Math.round(x), Math.round(y), s, s);
    ctx.globalAlpha = 1;
  }
  splat(x: number, y: number, n: number, c = '#8a0000', force = false) {
    for (let i = 0; i < n; i++) {
      const a = rnd(0, 6.3), r = rnd(0, 9);
      const k = Math.random();
      this.stamp(x + Math.cos(a) * r, y + Math.sin(a) * r * 0.6, k < 0.25 ? '#5e0000' : c, k < 0.15 ? 3 : k < 0.55 ? 2 : 1, force);
    }
    this.stamp(x - 1, y - 1, c, 3, force);
    this.stamp(x - 2, y, '#5e0000', 2, force);
  }
  /** growing blood pool stamped into the floor over ~1s (clipped to floor tiles) */
  addPool(x: number, y: number, max: number, c = '#7a0000') {
    this.pools.push({ x, y, r: 1, max, c });
    if (this.pools.length > 40) this.pools.shift();
  }
  updatePools(dt: number) {
    for (let i = this.pools.length - 1; i >= 0; i--) {
      const q = this.pools[i];
      q.r += (q.max / 0.9) * dt;
      const r = Math.min(q.r, q.max);
      this.stampEllipse(q.x, q.y, r, r * 0.5, q.c, 0.2);
      if (q.r >= q.max) this.pools.splice(i, 1);
    }
  }
  stampEllipse(x: number, y: number, rx: number, ry: number, c: string, alpha: number) {
    const ctx = this.levelCtx;
    ctx.globalAlpha = alpha;
    ctx.fillStyle = c;
    const cx = Math.round(x), cy = Math.round(y);
    const ryi = Math.ceil(ry);
    for (let dy = -ryi; dy <= ryi; dy++) {
      const f = 1 - (dy * dy) / (ry * ry + 0.5);
      if (f < 0) continue;
      const dx = Math.floor(Math.sqrt(f) * rx);
      let start = -1;
      for (let xx = cx - dx; xx <= cx + dx + 1; xx++) {
        const solid = xx > cx + dx || solidAt(this.level, xx, cy + dy);
        if (!solid && start < 0) start = xx;
        if (solid && start >= 0) { ctx.fillRect(start, cy + dy, xx - start, 1); start = -1; }
      }
    }
    ctx.globalAlpha = 1;
  }
  bulletHole(x: number, y: number) {
    this.stamp(x, y, '#050505', 1);
    if (Math.random() < 0.5) this.stamp(x + rnd(-1, 1), y + rnd(-1, 1), 'rgba(0,0,0,0.5)', 1);
  }
  addHazard(h: Partial<Hazard>) {
    const base: Hazard = { x: 0, y: 0, r: 0, maxR: 40, life: 1, max: 1, kind: 'ring', hit: false, dmg: 1, fromPlayer: false };
    const out = Object.assign(base, h);
    out.max = h.max ?? h.life ?? 1;
    this.hazards.push(out);
  }
  addAfterimage(src: { x: number; y: number; facing: number; aim: number; scale?: number; color?: string; pose?: Pose; poseT?: number; dancePhase?: number }, color?: string, lean?: Vec) {
    if (this.afterimages.length > 60) this.afterimages.shift();
    this.afterimages.push({
      x: src.x, y: src.y, life: 0.22, max: 0.22, pose: src.pose ?? 'dash', t: src.poseT ?? 0, facing: src.facing, aim: src.aim,
      color: color ?? src.color ?? this.pal.accent, scale: src.scale ?? 1, lean: lean ?? { x: Math.cos(src.aim), y: Math.sin(src.aim) }, dancePhase: src.dancePhase,
    });
  }
  spawnEnemyAt(kind: EnemyKind, x: number, y: number, elite: boolean, boss?: BossKind) {
    const e = makeEnemy(kind, boss, x, y, this.levelN, elite);
    this.enemies.push(e);
    this.sfx.spawn();
    this.particles.ring(x, y - 6, 16, 2, this.pal.accent, 0.6, 1);
    return e;
  }
  spawnNext() {
    const kind = this.spawnQueue.shift();
    if (!kind) return;
    const p = this.player;
    let pos = this.randomFloorNear(p.x, p.y, 110, 320);
    if (!pos) pos = this.randomFloorNear(p.x, p.y, 70, 9999);
    if (!pos) pos = { x: this.level.exit.x, y: this.level.exit.y };
    this.spawnEnemyAt(kind, pos.x, pos.y, Math.random() < this.eliteChance);
  }
  spawnPickup(x: number, y: number, kind: Pickup['kind']) {
    this.pickups.push({ x, y, kind, t: 0, vx: rnd(-50, 50), vy: rnd(-50, 50), magnet: false });
  }
  dropLoot(e: Enemy, melee: boolean) {
    const p = this.player;
    let chance = (0.2 + (melee ? 0.1 : 0)) * this.stats.dropRate * (e.elite ? 2 : 1);
    if (e.boss) chance = 3;
    let n = Math.floor(chance) + (Math.random() < chance % 1 ? 1 : 0);
    while (n-- > 0) {
      const w: [Pickup['kind'], number][] = [
        ['hp', p.hp < this.maxHp() ? 3 : 0.3],
        ['ammoP', 3],
        ['ammoR', p.hasRifle ? 3 : this.levelN >= 8 ? 1.2 : 0],
        ['focus', 1.5],
      ];
      const total = w.reduce((a, b) => a + b[1], 0);
      let r = Math.random() * total;
      let kind: Pickup['kind'] = 'ammoP';
      for (const [k, wt] of w) { r -= wt; if (r <= 0) { kind = k; break; } }
      if (kind === 'ammoR' && !p.hasRifle) kind = 'rifle';
      this.spawnPickup(e.x, e.y, kind);
    }
  }
  nearestEnemy(x: number, y: number, maxD: number, aim?: number, arc?: number): Enemy | null {
    let best: Enemy | null = null;
    let bd = maxD;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = dist(x, y, e.x, e.y) - e.r;
      if (d > bd) continue;
      if (aim !== undefined && arc !== undefined && Math.abs(angleDiff(Math.atan2(e.y - y, e.x - x), aim)) > arc) continue;
      bd = d; best = e;
    }
    return best;
  }
  /** staggered enemy in reach -> "FINISH HIM!" banner (perfect fatality) */
  finishTarget(): Enemy | null {
    const p = this.player;
    let best: Enemy | null = null, bd = 60;
    for (const e of this.enemies) {
      if (e.dead || e.stagger <= 0 || e.spawnT > 0) continue;
      const d = dist(p.x, p.y, e.x, e.y);
      if (d < bd) { bd = d; best = e; }
    }
    return best;
  }
  /** ANY enemy can be fatality'd: close ones directly, far ones (in aim direction) via a running/flying finisher */
  fatalityTarget(): { e: Enemy; far: boolean } | null {
    const p = this.player;
    let best: Enemy | null = null, bs = -1e9, far = false;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = dist(p.x, p.y, e.x, e.y) - e.r;
      const ang = Math.abs(angleDiff(Math.atan2(e.y - p.y, e.x - p.x), p.aim));
      let score = -1e9, isFar = false;
      if (d < 60) score = 200 - d * 2 - ang * 8 + (e.stagger > 0 ? 80 : 0);
      else if (d < 150 && ang < 0.75 && lineOfSight(this.level, p.x, p.y, e.x, e.y)) { score = 100 - d * 0.5 - ang * 20 + (e.stagger > 0 ? 80 : 0); isFar = true; }
      if (score > bs) { bs = score; best = e; far = isFar; }
    }
    return best ? { e: best, far } : null;
  }
  addCombo(n = 1) {
    this.combo += n;
    this.comboTimer = this.comboMax;
    this.comboPop = 0.1;
    if (this.combo > this.bestCombo) this.bestCombo = this.combo;
    if ([6, 12, 25, 50, 100].includes(this.combo)) {
      const names: Record<number, string> = { 6: 'GOOD!', 12: 'GREAT!', 25: 'BRUTAL!', 50: 'MASTER!', 100: 'LEGENDARY!' };
      this.say(names[this.combo], this.pal.accent2, 2, 0.9);
      this.sfx.select();
    }
  }

  // ------------------------------------------------------------------ frame
  frame(raw: number) {
    this.time += raw;
    this.rawDt = raw;
    const inp = this.input;
    if (inp.hit('m')) this.toggleMute();
    if (inp.hit('b')) this.cycleBlood();
    if (!this.isAttractMode) {
      if (inp.hit('n')) this.toggleNunStyle();
      if (inp.hit('v')) this.toggleV2();
      if (inp.hit('l')) this.toggleLong();
    }
    if (this.casingSfxCd > 0) this.casingSfxCd -= raw;
    if (this.hitMarkerT > 0) this.hitMarkerT -= raw;
    if (this.fatalityTextT > 0) this.fatalityTextT -= raw;
    if (this.finishCd > 0) this.finishCd -= raw;
    for (let i = this.announce.length - 1; i >= 0; i--) { this.announce[i].t += raw; if (this.announce[i].t >= this.announce[i].max) this.announce.splice(i, 1); }
    if (this.fatalityCd > 0 && this.state === 'playing') this.fatalityCd -= raw;
    this.input.autoFocusOnHover = this.state === 'playing';
    switch (this.state) {
      case 'menu': {
        if (!this.menuInputBlocked && (inp.hit('enter') || inp.hit(' '))) { this.startFromMenu(); return; }
        this.updateMenuFight(raw);
        this.updateCamera(raw);
        return;
      }
      case 'paused':
        if (inp.hit('escape') || inp.hit('p')) this.resume();
        return;
      case 'mutation':
        if (inp.hit('1')) this.chooseMutation(0);
        else if (inp.hit('2')) this.chooseMutation(1);
        else if (inp.hit('3')) this.chooseMutation(2);
        return;
      case 'dead':
        this.deathT += raw;
        this.particles.update(raw * 0.5);
        this.texts.update(raw);
        this.updateCorpses(raw * 0.5);
        this.updateCamera(raw);
        if (this.deathT > 1.0 && (inp.hit('enter') || inp.hit(' ') || inp.mouse.pressed)) this.respawn();
        return;
      case 'gameover': case 'victory':
        this.particles.update(raw);
        return;
      default:
        break;
    }
    if (this.menuTransition) {
      this.updateMenuFight(raw);
      this.updateCamera(raw);
      return;
    }
    if (inp.hit('escape') || inp.hit('p')) { this.pause(); return; }
    this.trauma = Math.max(0, this.trauma - raw * 2.4);
    this.gunfx.update(raw);
    if (this.hitstop > 0) {
      this.hitstop -= raw;
      this.updateCamera(raw);
      this.heldInput = true;
      return;
    }
    if (this.slowT > 0) { this.slowT -= raw; this.timeScale = lerp(this.timeScale, this.slowFactor, 0.4); }
    else if (this.player.ofaActive) this.timeScale = lerp(this.timeScale, OFA_WORLD, raw * 9);
    else this.timeScale = lerp(this.timeScale, 1, 0.25);
    const dt = raw * this.timeScale;
    if (this.wipe) {
      if (this.wipe.dir === -1) {
        this.wipe.t += raw * 2.2;
        if (this.wipe.t >= 1) {
          this.wipe.t = 1;
          const cb = this.wipe.cb;
          this.wipe = { t: 1, dir: 1, cb: null };
          cb?.();
          if (this.state !== 'playing') return;
        }
        this.particles.update(dt);
        this.updateCamera(raw);
        return;
      }
      this.wipe.t -= raw * 2.2;
      if (this.wipe.t <= 0) this.wipe = null;
    }
    this.levelTime += dt;
    if (this.bannerT > 0) this.bannerT -= raw;
    this.updateWorld(dt);
    this.updateCamera(raw);
  }

  updateWorld(dt: number) {
    const p = this.player;
    const scriptedActors = Boolean(this.clashDuel || this.pendingRiposte);
    // ONE FOR ALL: the world is slowed by timeScale, but the player keeps running on REAL time
    this.updatePlayer(p.ofaActive ? this.rawDt * OFA_PLAYER : dt);
    this.updateOfa(this.rawDt);
    this.flowT -= dt;
    if (this.flowT <= 0) { this.flow = flowField(this.level, p.x, p.y); this.flowT = 0.25; }
    const alive = this.enemies.filter((e) => !e.dead).length;
    if (this.mode === 'survival') this.updateSurvival(dt);
    else if (this.spawnQueue.length && alive < this.maxAlive) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) { this.spawnNext(); this.spawnTimer = this.levelTime < 2 ? 0.18 : 0.5; }
    }
    if (this.state !== 'playing') return;
    if (!scriptedActors && !this.clashDuel && !this.pendingRiposte) {
      this.updateTactics(dt);
      for (const e of this.enemies) if (!e.dead) updateEnemy(this, e, dt);
      this.physics(dt);
      this.updateBullets(dt);
      this.updatePickups(dt);
      this.updateProps(dt);
      this.updateHazards(dt);
    }
    for (let i = this.afterimages.length - 1; i >= 0; i--) { this.afterimages[i].life -= dt; if (this.afterimages[i].life <= 0) this.afterimages.splice(i, 1); }
    this.updateCorpses(dt);
    this.updatePools(dt);
    this.blood.update(dt);
    this.particles.update(dt);
    this.texts.update(dt);
    if (this.combo > 0) { this.comboTimer -= dt * this.stats.comboDecay; if (this.comboTimer <= 0) this.combo = 0; }
    this.comboPop -= dt;
    this.flashA = Math.max(0, this.flashA - dt * 2.5);
    if (p.recoil > 0) p.recoil = Math.max(0, p.recoil - dt * 8);
    if (this.mode === 'story' && !this.cleared && !p.fatality && this.spawnQueue.length === 0 && this.enemies.every((e) => e.dead)) this.onLevelCleared();
    if (this.exitOpen) {
      this.portalT += dt;
      const ex = this.level.exit;
      if (Math.random() < 0.5) this.particles.add({ x: ex.x + rnd(-10, 10), y: ex.y + rnd(-4, 4), vx: 0, vy: rnd(-40, -15), life: 0.6, c: Math.random() < 0.5 ? this.pal.accent : '#ffffff', k: 7 });
      const d = dist(p.x, p.y, ex.x, ex.y);
      if (d < 40 && d > 0.5 && !p.fatality) { p.kx += ((ex.x - p.x) / d) * 60 * dt * 20; p.ky += ((ex.y - p.y) / d) * 60 * dt * 20; }
      if (d < 10 && !p.fatality) this.beginExit();
    }
    for (let i = this.enemies.length - 1; i >= 0; i--) if (this.enemies[i].dead) this.enemies.splice(i, 1);
  }

  updateCorpses(dt: number) {
    for (let i = this.corpses.length - 1; i >= 0; i--) {
      const c = this.corpses[i];
      c.t += dt;
      if (this.v2 && c.t > 2.3) { this.corpses.splice(i, 1); continue; }   // game1: bodies fade & clear out
      if (c.cd) c.cd -= dt;
      c.sqx = (c.sqx ?? 1) + (1 - (c.sqx ?? 1)) * Math.min(1, dt * 9);
      c.sqy = (c.sqy ?? 1) + (1 - (c.sqy ?? 1)) * Math.min(1, dt * 9);
      if (c.z > 0 || c.vz !== 0) {
        c.vz -= 500 * dt;
        c.z += c.vz * dt;
        if (this.v2) {
          // game1: salto HANYA saat benar-benar di udara; begitu menyentuh lantai badan berhenti
          // berputar dan rotasinya meredah cepat (di-wrap dulu supaya tidak roll tambahan di tanah)
          if (c.z > 0.5) c.rot += c.spin * dt;
          else { c.rot = Math.atan2(Math.sin(c.rot), Math.cos(c.rot)); c.rot *= Math.pow(0.001, dt); c.spin = 0; }
        } else c.rot += c.spin * dt;
        // bleeding while flying (a few drops)
        if (Math.random() < 0.18) this.blood.spray(c.x, c.y - 6 - c.z, Math.atan2(c.vy, c.vx) + Math.PI, 0.3, false);
        if (c.z <= 0) {
          c.z = 0;
          if (c.gib) { this.gibAt(c.x, c.y, c.color, c.scale, Math.atan2(c.vy, c.vx), 1.3); this.corpses.splice(i, 1); continue; }
          // ragdoll bounce: first impact bounces back up a little, then settles
          if (this.v2 ? (c.vz < -55 && c.bounces < 5) : (c.vz < -90 && c.bounces < 2)) {
            c.bounces++;
            c.vz = -c.vz * (this.v2 ? 0.52 : 0.35);           // game1: 0.52 = mayat memantul lebih hidup
            if (this.v2) { c.sqx = 1.4; c.sqy = 0.58; }
            c.vx *= this.v2 ? 0.78 : 0.6; c.vy *= this.v2 ? 0.78 : 0.6; c.spin *= this.v2 ? 0.8 : 0.6;
            this.particles.smoke(c.x, c.y, 3, '#888', 20, 0.3); this.splat(c.x, c.y, 3); this.sfx.land();
            continue;
          }
          c.vz = 0; c.spin = 0;
          if (!this.v2) c.rot = Math.round(c.rot / Math.PI) * Math.PI; // V1: lies flat
          this.particles.smoke(c.x, c.y, 4, '#888', 25, 0.4);
          this.blood.pool(c.x, c.y + 1, 4 + c.scale);
        }
      }
      if (this.v2 && c.z <= 0 && c.vz === 0) c.rot *= Math.pow(0.001, dt);  // game1: bodies settle upright
      if (Math.abs(c.vx) + Math.abs(c.vy) > 1) {
        const o = { x: c.x, y: c.y, r: 3 };
        const m = moveWithCollision(this.level, o, c.vx * dt, c.vy * dt);
        c.x = o.x; c.y = o.y;
        const sp = Math.hypot(c.vx, c.vy);
        if ((m.bx || m.by) && sp > 160) {
          // body slams the wall: blood splatter on the wall, body drops
          const wx = c.x + (m.bx ? Math.sign(c.vx) * 7 : 0), wy = c.y - 6 + (m.by ? Math.sign(c.vy) * 7 : 0);
          this.splat(wx, wy, 14, '#8a0000', true);
          this.blood.spray(c.x, c.y - 6 - c.z, Math.atan2(-c.vy, -c.vx), 3, true);
          this.shake(Math.min(0.6, sp / 500)); this.sfx.slam();
          if (c.gib) { this.gibAt(c.x, c.y, c.color, c.scale, Math.atan2(-c.vy, -c.vx), 1.4); this.say('SPLAT!', '#ff3b3b', 2, 0.8); this.corpses.splice(i, 1); continue; }
          c.vz = Math.min(c.vz, 20);
        }
        const cb = this.v2 ? -0.55 : -0.3;                    // game1: corpse rebound 0.55
        if (m.bx) c.vx *= cb;
        if (m.by) c.vy *= cb;
        if (this.v2 && (m.bx || m.by) && sp > 230) {
          c.spin *= 0.85; c.sqx = 1.3; c.sqy = 0.7;
          this.particles.spark(c.x, c.y - 6 - c.z, 5, '#ffffff', Math.atan2(-c.vy, -c.vx), 1.2, 130);
          if (Math.random() < 0.5) this.texts.add(c.x, c.y - 18 - c.z, 'BONK!', '#ffffff', 1, 0.5);
        }
        const f = Math.max(0, 1 - (c.z > 0 ? 0.4 : this.v2 ? 7.7 : 6) * dt); c.vx *= f; c.vy *= f;  // V2: game1's 0.88/frame ground grip
      }
      // V2 (game1): running through a loose body kicks it out of the way instead of gliding over it
      if (this.v2 && c.z < 6 && this.state === 'playing') {
        const pl = this.player;
        const ps = Math.hypot(pl.vx, pl.vy);
        const d = dist(c.x, c.y, pl.x, pl.y);
        if (ps > 55 && d < pl.r + 7 && d > 0.01) {
          const a = Math.atan2(c.y - pl.y, c.x - pl.x);
          c.vx = pl.vx * 1.3 + Math.cos(a) * 55; c.vy = pl.vy * 1.3 + Math.sin(a) * 55;
          c.vz = Math.max(c.vz, 60); c.spin += rnd(-6, 6); c.bounces = 0;
          c.sqx = 1.25; c.sqy = 0.75;
          this.particles.smoke(c.x, c.y, 2, '#888', 20, 0.3);
          if (Math.random() < 0.35) this.sfx.land();
        }
      }
      // V2 (game1): a fast-flying body bowls over live enemies — momentum transfers, so flights
      // stay short and funny instead of rocketing across the arena
      if (this.v2 && c.z < 8 && (c.cd ?? 0) <= 0 && this.state === 'playing') {
        const cspd = Math.hypot(c.vx, c.vy);
        for (const e of this.enemies) {
          if (e.dead || e.spawnT > 0 || e.boss) continue;
          const d = dist(c.x, c.y, e.x, e.y);
          if (d > (e.r ?? 6) + 6 || d < 0.01) continue;
          const a2 = Math.atan2(e.y - c.y, e.x - c.x);
          if (cspd > 130) {
            e.hp = Math.max(1, e.hp - 8); e.flash = 0.12;
            e.sqx = 1.35; e.sqy = 0.65;
            e.kx = c.vx * 0.62 + Math.cos(a2) * 95; e.ky = c.vy * 0.62 + Math.sin(a2) * 95;
            const ksp = Math.hypot(e.kx, e.ky); if (ksp > 320) { e.kx = e.kx / ksp * 320; e.ky = e.ky / ksp * 320; }
            e.z = Math.max(e.z, 0.1); e.vz = Math.min(120, 55 + cspd * 0.1); e.down = 0; e.stun = 0; e.state = 'air'; e.pose = 'launched';
            this.texts.add(e.x, e.y - 26, 'BODY CHECK!', this.pal.accent, 1, 0.6);
            this.sfx.slam(); this.shake(0.25); this.hitstop = Math.max(this.hitstop, 0.02);
            this.blood.spray(e.x - Math.cos(a2) * (e.r ?? 6), e.y - 5, a2, 4, false);
            c.vx *= 0.4; c.vy *= 0.4; c.spin *= 0.55; c.cd = 0.32;
          } else {
            c.vx = Math.cos(a2) * e.speed * 0.9 + e.vx; c.vy = Math.sin(a2) * e.speed * 0.9 + e.vy;
            c.vz = Math.max(c.vz, 26); c.spin += rnd(-4, 4); c.cd = 0.3;
          }
          break;
        }
      }
    }
    // V2 (game1): corpse vs corpse — bouncy pile-ups instead of overlapping planks
    if (this.v2) {
      for (let i = 0; i < this.corpses.length; i++) for (let j = i + 1; j < this.corpses.length; j++) {
        const a = this.corpses[i], b = this.corpses[j];
        if (Math.abs(a.z - b.z) > 16) continue;
        const dx = b.x - a.x, dy = b.y - a.y, d = Math.hypot(dx, dy) || 0.01, min = 11;
        if (d >= min) continue;
        const nx = dx / d, ny = dy / d, push = (min - d) / 2;
        a.x -= nx * push; a.y -= ny * push; b.x += nx * push; b.y += ny * push;
        const rel = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny;
        if (rel < 0) {
          const imp = -rel * 0.72;
          a.vx -= nx * imp; a.vy -= ny * imp; b.vx += nx * imp; b.vy += ny * imp;
          a.spin += rnd(-3.5, 3.5); b.spin += rnd(-3.5, 3.5);
          if (a.z < 1 && b.z < 1) { a.vz = Math.max(a.vz, 18); b.vz = Math.max(b.vz, 18); }
          if (rel < -120) this.particles.smoke((a.x + b.x) / 2, a.y, 2, '#666', 20, 0.3);
        }
      }
    }
  }

  // ------------------------------------------------------------------ player
  updatePlayer(dt: number) {
    const p = this.player;
    const inp = this.input;
    const raw = this.rawDt;
    for (const k of ['dashCd', 'parryCd', 'iframes', 'flash', 'stunT', 'shootT', 'holdT'] as const) if (p[k] > 0) p[k] -= dt;
    p.fireCd = Math.max(-1, p.fireCd - dt);
    p.sinceDash += dt;
    if (p.bloom > 0) p.bloom = Math.max(0, p.bloom - dt * 0.25);
    if (p.muzzle > 0) p.muzzle -= raw;
    const mw = this.mouseWorld();
    if (!p.fatality && !p.focusDash && !this.silat) {
      if (p.ofaActive && this.lockTarget && !this.lockTarget.dead) p.aim = Math.atan2(this.lockTarget.y - (p.y - 6), this.lockTarget.x - p.x);
      else p.aim = Math.atan2(mw.y - (p.y - 6), mw.x - p.x);
      if ((p.attackPhase === 'windup' || p.attackPhase === 'active') && !(p.weapon === 'yoyo' && this.yoyoVer === 2)) p.aim = p.attackAim;
      if (this.sfNunOn && this.sfNun.attacking) p.aim = this.sfNunAim;
      if (p.weapon === 'yoyo' && this.yoyoVer === 2 && p.attackPhase !== 'none' && p.moveKey && MOVES[p.moveKey].yoyo) {
        const autoAim = inp.mouseMovedAt === 0 || performance.now() - inp.mouseMovedAt > 1500;
        const target = autoAim ? this.nearestEnemy(p.x, p.y, 120) : this.nearestEnemy(p.x, p.y, 110, p.aim, 0.65);
        if (target) {
          const targetAngle = Math.atan2(target.y - p.y, target.x - p.x);
          p.aim += angleDiff(targetAngle, p.aim) * (autoAim ? 1 : 0.35);
        }
      }
    }
    // Facing: while running with fists the body faces the direction of travel (otherwise the run cycle
    // reads as "running backwards" whenever the cursor is behind you). Guns, attacks and finishers face the aim.
    const bodyFacesTravel = p.weapon === 'fist' && !p.fatality && !p.focusDash && p.attackPhase === 'none' && p.dashT <= 0 && p.moving && Math.hypot(p.vx, p.vy) > 30;
    if (bodyFacesTravel) { if (Math.abs(p.vx) > 8) p.facing = p.vx >= 0 ? 1 : -1; }
    else p.facing = Math.cos(p.aim) >= 0 ? 1 : -1;
    // the body's pose aims along the travel direction while running (fists); the head/eyes still track the cursor
    p.bodyAim = bodyFacesTravel ? Math.atan2(p.vy, p.vx) : p.aim;

    if (this.clashCd > 0) this.clashCd -= dt;
    if (p.fatality) { this.updateFatality(raw); return; }
    if (this.clashDuel) { this.updateClash(raw); return; }
    if (this.pendingRiposte) { this.updateParryRiposte(dt); return; }
    if (this.silat) { this.updateSilat(dt); return; }
    if (this.silatCd > 0) this.silatCd -= dt;
    if (this.silatLinkT > 0) { this.silatLinkT -= dt; if (this.silatLinkT <= 0) this.silatChainN = 0; }
    if (p.focusDash) {
      const fd = p.focusDash;
      fd.t += raw / 0.14;
      const k = Math.min(1, fd.t);
      const ek = 1 - Math.pow(1 - k, 3);
      p.x = lerp(fd.sx, fd.tx, ek); p.y = lerp(fd.sy, fd.ty, ek);
      this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim, scale: 1 }, this.pal.accent, p.lean);
      if (k >= 1) {
        p.focusDash = null;
        const e = this.enemies.find((en) => en.id === fd.id);
        if (e) p.aim = Math.atan2(e.y - p.y, e.x - p.x);
        this.startAttack('FOCUS');
      }
      return;
    }

    // ---- movement & running
    let ix = (inp.key('d') || inp.key('arrowright') ? 1 : 0) - (inp.key('a') || inp.key('arrowleft') ? 1 : 0);
    let iy = (inp.key('s') || inp.key('arrowdown') ? 1 : 0) - (inp.key('w') || inp.key('arrowup') ? 1 : 0);
    let il = Math.hypot(ix, iy);
    if (il === 0 && inp.mouse.mdown) { ix = Math.cos(p.aim); iy = Math.sin(p.aim); il = 1; } // middle mouse = run toward cursor
    if (il > 0) { ix /= il; iy /= il; }
    const attacking = p.attackPhase !== 'none';
    const move = attacking && p.moveKey ? MOVES[p.moveKey] : null;
    const traveling = !!(move && move.travel && p.attackPhase === 'active');
    const frozen = p.stunT > 0 || p.holdT > 0;
    const sprintBefore = clamp((p.runT - 0.08) / 0.3, 0, 1);

    // ---- Taekwondo flying side kick: RUN + LEFT CLICK (handled in startAttackInput); cooldown ticks here
    if (p.tkdCd > 0) p.tkdCd -= dt;
    void sprintBefore;
    if (il > 0) p.lean = { x: ix, y: iy };
    if (il > 0 && !frozen && !attacking) p.lastDir = { x: ix, y: iy };
    if (il > 0 && !frozen) { if (!attacking && p.dashT <= 0) p.runT += dt; }
    else p.runT = 0;
    const sprint = clamp((p.runT - 0.08) / 0.3, 0, 1);
    p.running = p.runT > 0.4 && il > 0 && !frozen;
    if (p.running && !attacking && p.comboStr) p.comboStr = '';
    const airMul = p.airborne ? 0.75 : 1;
    const attackMobility = p.weapon === 'yoyo' && this.yoyoVer === 2 ? 0.9 : p.moveKey && MOVES[p.moveKey]?.bat ? 0.6 : p.attackPhase === 'recover' ? 0.55 : 0.25;
    const spd = 118 * this.stats.moveSpeed * (1 + 0.3 * sprint) * (attacking ? attackMobility : 1) * (p.parryT > 0 ? 0.4 : 1) * (frozen ? 0 : 1) * airMul * (p.weapon === 'takamura' ? this.tak.moveMul : p.weapon === 'hayabusa' ? this.hay.moveMul : 1);
    const accel = p.airborne ? 6 : 22;
    const k = 1 - Math.exp(-accel * dt);
    p.vx = lerp(p.vx, ix * spd, k);
    p.vy = lerp(p.vy, iy * spd, k);
    p.moving = il > 0 && !frozen;
    // walk cycle advances with actual ground speed so feet never slide
    const gspd = Math.hypot(p.vx, p.vy);
    // ANIME BRAKE (V2): berhenti mendadak dari lari -> pose skid + debu di kaki
    p.brakeT = Math.max(0, p.brakeT - dt); p.brakeCd -= dt;
    if (!p.airborne && p.prevSpd > 115 && gspd < 70 && p.brakeCd <= 0 && p.dashT <= 0 && p.attackPhase === 'none') {
      p.brakeT = 0.35; p.brakeCd = 0.8;
      this.particles.smoke(p.x, p.y, 3, '#9a8f7d', 14, 0.3);
    }
    p.prevSpd = Math.max(gspd, p.prevSpd - 140 * dt); // recent top speed, meluruh ~0.55s
    // cadence: ~3.2 steps/s at full sprint (period 0.31s per step). Half-stride length follows from the speed so the
    // planted foot stays still in the world: strideHalf = speed / (2 * stepsPerSec)... clamped to what the legs can reach.
    if (!p.airborne && gspd > 5) {
      // small legs, fast cadence: 3 steps/s at a jog up to ~5.5 steps/s at full sprint. Step length saturates at the leg reach.
      const stepsPerSec = 3 + 2.5 * clamp(gspd / 160, 0, 1);
      p.strideHalf = clamp(gspd / (4 * stepsPerSec), 2.4, 5.6); // px, half of the step length
      const previousStep = Math.floor((p.walk + Math.PI / 2) / Math.PI);
      p.walk += dt * stepsPerSec * Math.PI; // 2 steps per 2PI
      const currentStep = Math.floor((p.walk + Math.PI / 2) / Math.PI);
      if (p.moving && p.dashT <= 0 && !inp.hit('shift') && currentStep > previousStep) this.sfx.footstep(sprint);
    }
    else if (!p.moving) p.walk = 0;
    if (p.moving && !attacking && p.dashT <= 0 && !p.airborne) {
      p.dustT -= dt;
      if (p.dustT <= 0) { p.dustT = 0.16 - 0.07 * sprint; this.particles.smoke(p.x - p.lean.x * 4, p.y + 1, 1, '#9a9a9a', 14 + 10 * sprint, 0.35); }
      if (sprint >= 1 && Math.random() < 0.35) this.particles.lines(p.x - p.lean.x * 7, p.y - 6 - p.lean.y * 4, 1, 'rgba(255,255,255,0.55)', Math.atan2(-p.lean.y, -p.lean.x), 140);
    }

    // ---- JUMP (space): hop over bullets, sweeps and shockwaves
    if (p.landT > 0) p.landT -= dt;
    if (p.jumpCd > 0) p.jumpCd -= dt;
    if (inp.hit(' ') && !p.airborne && p.jumpCd <= 0 && p.stunT <= 0 && p.holdT <= 0 && p.dashT <= 0 && !traveling) {
      p.jumpCd = 0.55;
      p.airborne = true; p.vz = 200; p.jumpT = 0; p.squash = 0.82;
      p.attackPhase = 'none'; p.buffered = null; p.parryT = 0;
      this.sfx.whoosh();
      this.particles.smoke(p.x, p.y, 4, '#888', 22, 0.35);
      this.particles.dirBurst(p.x, p.y, 4, '#cfcfcf', Math.PI / 2, 1.2, 50, 0.3);
    }
    if (p.airborne) {
      p.jumpT += dt;
      p.vz -= 760 * dt;
      p.z += p.vz * dt;
      // air attack: LMB in the air = dive kick
      if (inp.mouse.pressed && !attacking && p.z > 6) {
        const w = p.weapon;
        if (w === 'fist') this.startAttack('AIR');
        else if (w === 'katana') this.startAttack('KDASH');
        else if (w === 'dual') this.startAttack('DDASH');
        else if (w === 'axe' && this.lev.mode === 'leap') { /* leap smash owns the air */ }
        else if (w === 'axe' && !this.lev.held) this.startAttack('AIR');
        else if (w === 'axe') this.startAttack('ADASH');
        else if (w === 'bat') this.startAttack('BDASH');
        else if (w === 'nunchaku') {
          if (this.sfNunOn) { this.sfNunAim = p.aim; this.sfNun.start(); this.sfx.swing(1.1); }
          else this.startAttack('NDASH');
        }
        else if (w === 'yoyo' && this.yoyoVer === 2) this.startAttack('YAIR');
      }
      if (p.z <= 0 && p.vz < 0) {
        p.z = 0; p.vz = 0; p.airborne = false; p.landT = 0.12; p.squash = 0.72;
        this.sfx.land();
        this.particles.smoke(p.x, p.y, 5, '#888', 26, 0.4);
        this.shake(0.08);
        if (attacking && move?.air) {
          p.attackPhase = 'recover'; p.attackT = move.recover; this.shake(0.3); this.particles.shockwave(p.x, p.y, 18, '#ffffff', 0.25);
          for (const e of this.enemies) { if (e.dead || e.spawnT > 0 || p.hitSet.includes(e.id)) continue; if (dist(p.x, p.y, e.x, e.y) > 18 + e.r) continue; p.hitSet.push(e.id); this.meleeHitEnemy(e, move, Math.atan2(e.y - p.y, e.x - p.x), { x: p.x + Math.cos(p.aim) * 6, y: p.y - 2 }); }
        }
      }
    }
    p.squash = lerp(p.squash, 1, 1 - Math.exp(-16 * dt));

    // ---- SHADOW STEP (shift): fast i-frame dash, perfect-dodge rewards focus
    if (inp.hit('shift') && p.dashCd <= 0 && p.stunT <= 0 && p.holdT <= 0 && !traveling) {
      const dx = il > 0 ? ix : Math.cos(p.aim), dy = il > 0 ? iy : Math.sin(p.aim);
      p.dashT = 0.15; p.dashCd = 0.55 * this.stats.dashCd; p.dashDir = { x: dx, y: dy }; p.lean = { x: dx, y: dy }; p.sinceDash = 0;
      p.attackPhase = 'none'; p.buffered = null; p.parryT = 0; p.iframes = Math.max(p.iframes, 0.22);
      p.prevPose = 'dash';
      this.sfx.dash();
      this.particles.smoke(p.x, p.y, 5, '#7a6aa0', 28, 0.4);
      this.particles.dirBurst(p.x, p.y, 7, '#c7b3ff', Math.atan2(-dy, -dx), 0.5, 90, 0.3);
      this.particles.ring(p.x, p.y - 6, 2, 10, '#c7b3ff', 0.18, 1);
      // perfect dodge: a bullet or an attack was about to land
      let perfect = false;
      for (const b of this.bullets) if (b.owner === 'enemy' && dist(b.x, b.y, p.x, p.y - 5) < 22) { perfect = true; break; }
      if (!perfect) for (const e of this.enemies) if (!e.dead && (e.state === 'windup' || e.state === 'attack' || e.state === 'lunge') && dist(e.x, e.y, p.x, p.y) < 36) { perfect = true; break; }
      if (perfect) {
        p.focus = Math.min(300, p.focus + 25 * this.stats.focusGain);
        this.say('SHADOW STEP!', '#c7b3ff', 1, 0.6);
        this.slow(0.18, 0.35);
        this.particles.ring(p.x, p.y - 6, 4, 18, '#ffffff', 0.25, 1);
      }
    }
    if (p.dashT > 0) {
      p.dashT -= dt;
      const ds = 420 * this.stats.dashDist;
      p.vx = p.dashDir.x * ds; p.vy = p.dashDir.y * ds;
      this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, scale: 1 }, '#8f7bdc', p.lean);
      if (Math.random() < 0.6) this.particles.add({ x: p.x + rnd(-4, 4), y: p.y - 6 + rnd(-5, 5), vx: -p.dashDir.x * 40, vy: -p.dashDir.y * 40, life: 0.25, c: '#c7b3ff', k: 0, s: 1 });
    }

    if (inp.hit('q')) this.cycleWeapon(1);
    if (inp.mouse.wheel !== 0) this.cycleWeapon(inp.mouse.wheel > 0 ? 1 : -1);
    if (inp.hit('1')) this.setWeapon('fist');
    if (inp.hit('2')) this.setWeapon('pistol');
    if (inp.hit('3') && p.hasRifle) this.setWeapon('rifle');
    if (inp.hit('4') && p.hasNunchaku) this.setWeapon('nunchaku');
    if (inp.hit('5') && p.hasKatana) this.setWeapon('katana');
    if (inp.hit('6') && p.hasAxe) this.setWeapon('axe');
    if (inp.hit('7') && p.hasDual) this.setWeapon('dual');
    if (inp.hit('8')) {
      if (p.weapon === 'yoyo') this.selectYoyoVersion(this.yoyoVer === 1 ? 2 : 1);
      else this.setWeapon('yoyo');
    }
    if (inp.hit('9')) this.setWeapon('takamura');
    if (inp.hit('0')) this.setWeapon('hayabusa');
    if (inp.hit('t') && p.weapon !== 'bat') this.setWeapon('bat');

    // A guard opens on input; success is resolved only when the incoming hit reaches it.
    if (inp.hit('c') && p.parryCd <= 0 && p.stunT <= 0 && p.holdT <= 0 && p.dashT <= 0 && !traveling && !p.airborne) {
      this.cancelPlayerAttack();
      p.parryT = 0.28 * this.stats.parryWindow; p.parryCd = 0.32; p.parryHit = false;
      this.sfx.whoosh();
      this.particles.ring(p.x, p.y - 6, 3, 12, '#9be7ff', 0.16, 1);
    }
    if (p.parryT > 0) p.parryT -= dt;
    if (inp.hit('e')) this.tryFocus();
    if (inp.hit('x')) this.tryOfa();
    if (inp.hit('f')) this.tryFatality();
    if (inp.hit('g')) {
      const LS = this.longMode ? 2.5 : 1;
      const clashTarget = this.enemies.find((e) => !e.dead && dist(e.x, e.y, p.x, p.y) < 46 * LS && (e.attackPhase === 'windup' || e.attackPhase === 'active' || (e.rallyWindow ?? 0) > 0));
      if (clashTarget) { this.startClash(clashTarget); return; }
      if (this.trySilat(null, true)) return;
    }
    if (inp.hit('r')) this.tryRage();
    this.updateRage(dt, raw);
    if (p.rageDash) return;

    if (p.stunT <= 0 && p.holdT <= 0) {
      if (inp.mouse.rpressed && !p.airborne && !(p.weapon === 'yoyo' && this.yoyoVer === 1) && p.weapon !== 'takamura' && p.weapon !== 'hayabusa' && p.weapon !== 'axe') this.queueAttack('H');
      if ((p.weapon === 'yoyo' && this.yoyoVer === 1) || p.weapon === 'takamura' || p.weapon === 'hayabusa') {
        /* yoyo V1 / takamura / hayabusa read LMB / RMB themselves */
      } else if (p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'katana' || p.weapon === 'axe' || p.weapon === 'dual' || p.weapon === 'bat' || (p.weapon === 'yoyo' && this.yoyoVer === 2)) {
        if (inp.mouse.pressed && !p.airborne) this.queueAttack('L');
        if (this.sfNunOn && inp.mouse.down && !inp.mouse.pressed && !p.airborne && p.parryT <= 0) {
          if (!this.sfNun.attacking) { this.sfNunAim = p.aim; this.sfNun.start(); this.sfx.swing(1.1); }
          else if (this.sfNun.cur && this.sfNun.t / this.sfNun.cur.dur > 0.3) this.sfNun.buffered = true;
        }
        // HELICOPTER: holding RMB keeps the chain spinning as long as you hold it
        if (p.weapon === 'nunchaku' && inp.mouse.rdown && p.attackPhase === 'active' && p.moveKey === 'NH' && p.attackT < 0.1) p.attackT = 0.1;
        if (p.weapon === 'yoyo' && this.yoyoVer === 2 && !p.airborne) {
          if (inp.mouse.rdown && p.attackPhase === 'active' && (p.moveKey === 'YH' || p.moveKey === 'YHH') && p.attackT < 0.1) p.attackT = 0.1;
          if (p.attackPhase === 'none' && inp.mouse.rdown && !inp.mouse.rpressed) this.startAttack('YH');
          else if (p.attackPhase === 'none' && inp.mouse.down && !inp.mouse.pressed) this.queueAttack('L');
        }
        if (p.weapon === 'bat' && inp.mouse.down && !inp.mouse.pressed && !p.airborne && !p.buffered && (p.attackPhase === 'none' || p.attackPhase === 'recover')) this.queueAttack('L');
        if (p.weapon === 'bat' && inp.mouse.rdown && !inp.mouse.rpressed && !p.airborne && !p.buffered && (p.attackPhase === 'none' || p.attackPhase === 'recover')) this.queueAttack('H');
      } else if (!attacking && p.dashT <= 0) {
        const semi = p.weapon === 'pistol';
        if ((semi ? inp.mouse.pressed || (inp.mouse.down && p.fireCd <= -0.15) : inp.mouse.down) && p.fireCd <= 0) this.fire();
      }
    }
    if (this.silat) return;
    this.updateYoyoV2(dt);
    this.updateAttack(dt);
    if (this.clashDuel || this.silat) return;
    if (this.sfNunOn) this.updateSFNunchaku(dt); else this.updateNunchaku(dt);
    if (this.clashDuel || this.silat) return;
    this.updateKatana(dt);
    this.updateYoyo(dt);
    this.updateBat(dt);
    this.updateSilatPending(dt);
    this.updateTak(dt);
    this.updateHay(dt);
    this.updateLev(dt);

    // ---- apply movement
    const trav = p.attackPhase === 'active' && p.moveKey && MOVES[p.moveKey].travel;
    if (trav) {
      const m = MOVES[p.moveKey!];
      const sp = m.travel! * (p.travelHit ? 0.2 : 1);
      p.vx = Math.cos(p.aim) * sp; p.vy = Math.sin(p.aim) * sp;
    }
    const dx = (p.vx + p.kx) * dt, dy = (p.vy + p.ky) * dt;
    const blocked = moveWithCollision(this.level, p, dx, dy);
    if (trav && (blocked.bx || blocked.by)) p.travelHit = true;
    const fr = Math.max(0, 1 - 8 * dt); p.kx *= fr; p.ky *= fr;
    p.x = clamp(p.x, TILE, this.level.w * TILE - TILE); p.y = clamp(p.y, TILE, this.level.h * TILE - TILE);
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0 || e.z > 4 || p.z > 8) continue;
      const d = dist(p.x, p.y, e.x, e.y), min = p.r + e.r - 1;
      if (d < min && d > 0.01) {
        const o = (min - d) * 0.5, nx = (p.x - e.x) / d, ny = (p.y - e.y) / d;
        if (p.dashT <= 0 && !trav && this.isFree(p.x + nx * o, p.y + ny * o, p.r)) { p.x += nx * o; p.y += ny * o; }
        if (this.isFree(e.x - nx * o, e.y - ny * o, e.r)) { e.x -= nx * o; e.y -= ny * o; }
      }
    }
    unstick(this.level, p);
  }

  /** Blade angle follows the move's slash arc during the active frames; trails + iaijutsu bookkeeping. */
  updateKatana(dt: number) {
    const p = this.player;
    this.katana.update(dt);
    if (p.weapon !== 'katana' && p.weapon !== 'axe' && p.weapon !== 'dual' && p.weapon !== 'bat' && !this.parryCounterKey) return;
    if (p.sheatheT > 0) p.sheatheT -= dt;
    const move = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
    p.bladePrevA = p.bladeA;
    if (move && move.slash) {
      const pt = this.attackPoseT();
      const s = move.slash;
      // windup: blade waits at the start angle; active (0.3-0.6): sweeps from->to; recover: eases back toward the aim
      const k = pt < 0.3 ? 0 : pt < 0.6 ? (pt - 0.3) / 0.3 : 1;
      const ease = k < 1 ? 1 - Math.pow(1 - k, 2.2) : 1;
      const rel = s.from + (s.to - s.from) * ease;
      const settle = pt > 0.6 ? clamp((pt - 0.6) / 0.4, 0, 1) : 0;
      p.bladeA = p.aim + rel * p.facing * (1 - settle) + 0 * settle;
      p.bladeB = p.aim - rel * p.facing * (1 - settle); // mirrored second blade (dual)
      if (move.id === 'k_heaven' || move.id === 'k_thrust' || move.id === 'k_iaijutsu') p.bladeA = p.aim + (move.id === 'k_heaven' ? (pt < 0.3 ? -1.4 * p.facing * (1 - pt / 0.3) - 0.3 * p.facing : 0.4 * p.facing * settle) : 0);
      // slash arc trail once per swing (and repeatedly for the spin/flurry moves)
      if (pt >= 0.3 && pt < 0.34 && !p.travelHit && s.from !== s.to) {
        const sk = solvePose(this.playerStickOpts(move.pose, pt));
        const hx = p.x + sk.fhand.x, hy = p.y + sk.fhand.y - p.z;
        const col = move.axe || move.bat ? '#ffd27f' : '#bfe8ff';
        this.katana.addArc(hx, hy, s.r, p.aim + s.from * p.facing, p.aim + s.to * p.facing, col, s.lift ?? 0, move.rehit ? 0.3 : 0.22);
        if (move.dual) { const bx = p.x + sk.bhand.x, by = p.y + sk.bhand.y - p.z; this.katana.addArc(bx, by, s.r, p.aim - s.from * p.facing, p.aim - s.to * p.facing, col, s.lift ?? 0, 0.22); }
        if (!move.rehit) p.travelHit = true; // used as 'arc emitted' flag for the blade
        if (move.axe || move.bat) this.sfx.axeSwing(); else if (move.dual) this.sfx.dualSwing(); else this.sfx.slash(move.id === 'k_heaven' || move.id === 'k_dragonfang' ? 0.7 : 1);
      }
      if (move.rehit && pt >= 0.3 && Math.random() < 0.5) {
        const sk = solvePose(this.playerStickOpts(move.pose, pt));
        const hx = p.x + sk.fhand.x, hy = p.y + sk.fhand.y - p.z;
        const a0 = p.bladePrevA, a1 = p.bladeA;
        if (Math.abs(a1 - a0) > 0.2) this.katana.addArc(hx, hy, s.r * 0.95, a0, a1, '#bfe8ff', 0, 0.12);
      }
      if ((move.id === 'k_iaijutsu' || (this.v2 && move.id === 'k_dashcut')) && p.attackPhase === 'active') this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: move.id === 'k_dashcut' ? 'k_crescent' : 'k_iaijutsu', poseT: 0.5 }, '#bfe8ff', p.lean);
    } else {
      // idle: blade points along the aim (chudan guard)
      const target = p.aim + (p.sheatheT > 0 ? 0 : 0);
      p.bladeA += angleDiff(target, p.bladeA) * Math.min(1, dt * 18);
    }
  }

  /** iaijutsu: victims are frozen (doomed) while you dash through and sheathe; then they fall apart */
  iaiKill(e: Enemy) {
    if (e.dead) return;
    const a = Math.atan2(e.y - this.player.y, e.x - this.player.x);
    this.particles.blood(e.x, e.y - 6 - e.z, 40, a + Math.PI / 2, 180);
    this.particles.blood(e.x, e.y - 6 - e.z, 40, a - Math.PI / 2, 180);
    this.particles.fountain(e.x, e.y - 6, 14);
    this.sfx.slash(0.6); this.sfx.kill();
    this.hitstop = Math.max(this.hitstop, 0.06); this.shake(0.5);
    this.texts.add(e.x, e.y - 24, 'ONE CUT', '#ffffff', 1, 0.8);
    // split corpse: two halves slide apart
    const corpse = (vx: number, vy: number): Corpse => ({ x: e.x, y: e.y, rot: a, color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory, vx, vy, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
    this.corpses.push(corpse(Math.cos(a + Math.PI / 2) * 40, Math.sin(a + Math.PI / 2) * 40));
    this.corpses.push(corpse(Math.cos(a - Math.PI / 2) * 40, Math.sin(a - Math.PI / 2) * 40));
    this.splat(e.x, e.y, 26);
    this.addPool(e.x, e.y + 1, 9);
    if (e.boss) { e.doom = 0; return; }
    e.dead = true; this.kills++; this.score += Math.round(e.value * 1.5 * this.comboMult()); this.addCombo(2); this.dropLoot(e, true);
  }

  /** Freestyle yoyo: the string is tied to the hand (or the FOOT in floor moves) of the current pose; feet are weapons too. */
  updateYoyo(dt: number) {
    const p = this.player;
    if (p.weapon !== 'yoyo' || this.yoyoVer !== 1 || this.parryCounterKey || p.parryT > 0 || p.stunT > 0) return;
    const yo = this.yoyo;
    const pose: Pose = yo.bodyPose ?? (p.dashT > 0 ? 'dash' : p.moving && p.runT > 0.03 ? 'run' : 'idle');
    const sk = solvePose(this.playerStickOpts(pose, yo.bodyPose ? yo.bodyT : 0));
    const limb = yo.anchorLimb === 'ffoot' ? sk.ffoot : sk.fhand;
    const w = (v: Vec): Vec => ({ x: p.x + v.x, y: p.y + v.y - p.z });
    yo.update(this, dt, w(limb), [w(sk.ffoot), w(sk.bfoot)]);
  }

  /** MAXKUNG's freestyle yo-yo trajectory, trail and dance effects. */
  updateYoyoV2(dt: number) {
    const p = this.player;
    if (p.weapon !== 'yoyo' || (this.yoyoVer !== 2 && !this.parryCounterKey)) return;
    const move = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
    const yoMove = move?.yoyo ? move : null;
    const pose: Pose = move ? move.pose : p.dashT > 0 ? 'dash' : p.airborne ? 'jump' : p.moving ? 'run' : 'y2_idle';
    const progress = move ? this.attackPoseT() : 0;
    const sk = solvePose(this.playerStickOpts(pose, progress));
    const hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
    const origin = { x: p.x, y: p.y - 6 - p.z };
    const skin = this.yoyoV2.skin;
    this.yoyoV2.update(dt, hand, origin, p.aim, yoMove?.id ?? null, p.attackPhase, progress, (yoMove?.range ?? 78) * this.stats.meleeRange);
    if (yoMove && p.attackPhase === 'active' && Math.random() < 0.16) {
      const tip = this.yoyoV2.position;
      this.particles.add({ x: tip.x, y: tip.y, vx: rnd(-20, 20), vy: rnd(-30, 15), life: 0.18, c: Math.random() < 0.5 ? skin.spark : skin.trailLight, s: 1, k: 0 });
    }
    if (yoMove && p.attackPhase === 'active') {
      const powerMove = pose === 'y2_windmill' || pose === 'y2_spin' || pose === 'y2_freeze' || pose === 'y2_airflip';
      this.yoyoEchoT -= dt;
      if (this.yoyoEchoT <= 0) {
        this.yoyoEchoT = powerMove ? 0.075 : 0.14;
        this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose, poseT: progress, dancePhase: this.yoyoV2.spin }, powerMove ? skin.afterimage : skin.trailLight, p.lean);
      }
      this.yoyoDustT -= dt;
      if (powerMove && !p.airborne && this.yoyoDustT <= 0) {
        this.yoyoDustT = 0.14;
        this.particles.smoke(p.x + rnd(-5, 5), p.y + 1, 2, '#a18d7f', 16, 0.22);
        this.particles.spark(p.x + rnd(-5, 5), p.y, 2, skin.spark, -Math.PI / 2, 1.3, 80);
      }
    } else {
      this.yoyoEchoT = 0;
      this.yoyoDustT = 0;
    }
  }
  /** Hayabusa: ninja-gaiden / raiden blade-mode. */
  updateHay(dt: number) {
    if (this.player.weapon !== 'hayabusa' || this.parryCounterKey || this.player.parryT > 0 || this.player.stunT > 0) return;
    this.hay.update(this, dt);
  }
  updateLev(dt: number) {
    if (this.player.weapon !== 'axe' || this.parryCounterKey || this.player.parryT > 0 || this.player.stunT > 0) return;
    this.lev.update(this, dt);
  }

  /** Takamura: all inputs, cuts and the NOTO payout live in takamura.ts */
  updateTak(dt: number) {
    if (this.player.weapon !== 'takamura' || this.parryCounterKey || this.player.parryT > 0 || this.player.stunT > 0) return;
    this.tak.update(this, dt);
  }

  /** Drive the nunchaku chain from the posed hand every frame; the far stick is pure physics. */
  updateNunchaku(dt: number) {
    const p = this.player;
    if (p.weapon !== 'nunchaku') return;
    const move = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
    let pose: Pose = 'n_idle', t = 0;
    if (move) { pose = move.pose; t = this.attackPoseT(); }
    else if (p.holdT > 0) { pose = p.holdPose; t = p.holdPoseT; }
    else if (p.parryT > 0) pose = 'parry';
    else if (p.dashT > 0) pose = 'dash';
    else if (p.moving && p.runT > 0.03) pose = 'run';
    const sk = solvePose(this.playerStickOpts(pose, t));
    let hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
    // the held stick points from the neck through the hand (extends the forearm)
    let ndx = sk.fhand.x - sk.neck.x, ndy = sk.fhand.y - sk.neck.y;
    const nl = Math.hypot(ndx, ndy) || 1; ndx /= nl; ndy /= nl;
    let spin = 0;
    let boost: Vec | null = null;
    if (move) {
      const ph = this.attackPoseT();
      switch (move.id) {
        case 'n_helicopter': case 'n_flyspin': spin = 26 * p.facing; break;
        case 'n_lowsweep': spin = -22 * p.facing; break;
        case 'n_tornado': spin = 30 * p.facing; break;
        case 'n_dragonlash': if (ph >= 0.28) { boost = { x: Math.cos(p.aim) * 1500, y: Math.sin(p.aim) * 900 + 300 }; } break;
        case 'n_figure8': spin = (Math.floor(ph * 4) % 2 === 0 ? 1 : -1) * 26; boost = { x: Math.cos(p.aim) * 350, y: Math.sin(p.aim) * 210 }; break;
        case 'n_tri1': case 'n_tri2': case 'n_tri3': case 'n_tri4': {
          if (ph >= 0.28 && ph <= 0.46) {
            const f = p.facing;
            const side = { x: -Math.sin(p.aim), y: Math.cos(p.aim) }; // screen 'left' of the facing direction
            let bx = 0, by = 0;
            if (move.id === 'n_tri1') { bx = Math.cos(p.aim) * 900 - side.x * f * 500; by = Math.sin(p.aim) * 540 + 700; }           // diagonal down-left
            else if (move.id === 'n_tri2') { bx = Math.cos(p.aim) * 1300; by = Math.sin(p.aim) * 500 - 900; }                       // bounce forward+up through the target to the shoulder
            else if (move.id === 'n_tri3') { bx = Math.cos(p.aim) * 1000 + side.x * f * 700; by = Math.sin(p.aim) * 600 + 80; }  // horizontal across the chest
            else { bx = Math.cos(p.aim) * 700 + side.x * f * 200; by = Math.sin(p.aim) * 420 + 900; }                                // catch: short downward smash
            boost = { x: bx, y: by };
          }
          break;
        }
        case 'n_lash': case 'n_cross': case 'n_whipcrack': case 'n_overhead': case 'n_choke': {
          // during the snap, fling the chain forward along the aim so the far stick whips out ahead of the hand
          if (ph >= 0.28 && ph <= 0.45) { const pow = move.id === 'n_whipcrack' ? 1400 : move.id === 'n_overhead' ? 1100 : 900; boost = { x: Math.cos(p.aim) * pow, y: Math.sin(p.aim) * pow * 0.6 + (move.id === 'n_overhead' ? 500 : 0) }; }
          break;
        }
      }
    }
    if (!move && p.weapon === 'nunchaku' && !p.moving && p.dashT <= 0) {
      // underarm tuck: the free stick is held folded back along the forearm (gentle pull toward the armpit)
      boost = { x: -ndx * 260, y: -ndy * 160 - 120 };
    }
    if (this.v2) {
      // V2: grip digerakkan pakai sweep arc ala game1 (wind back -> snap -> follow through),
      // plus flourish spin saat idle dan drape guard — rantai jadi menjutrat kayak di STICK FIST
      const LS = this.longMode ? 2.5 : 1;
      const sh = { x: p.x, y: p.y - 4 * LS - p.z };
      const sweep = (u: number, from: number, to: number, snap = 0.5) => {
        if (u < 0.18) return from - Math.sign(to - from) * 0.5 * (u / 0.18);
        const v = Math.min(1, (u - 0.18) / snap);
        const e = 1 - Math.pow(1 - v, 3);
        return from + (to - from) * e + Math.sin(v * Math.PI) * 0.12 * Math.sign(to - from);
      };
      const fdir = Math.cos(p.aim) >= 0 ? 1 : -1;
      if (move && move.nunchaku) {
        const u = Math.min(1, this.attackPoseT());
        let ang = p.aim, rad = (8 + 5 * u) * LS;
        switch (move.id) {
          case 'n_tri2': case 'n_cross': ang = p.aim + sweep(u, 2.0, -1.0); break;
          case 'n_whipcrack': case 'n_overhead': ang = p.aim + sweep(u, -2.3, 0.8, 0.34); rad = (6 + 8 * Math.min(1, Math.max(0, (u - 0.18) / 0.34))) * LS; break;
          case 'n_choke': ang = p.aim + sweep(u, -1.6, 0.6, 0.3); break;
          case 'n_tri4': ang = p.aim + sweep(u, 1.8, -0.6, 0.3); break;
          case 'n_helicopter': case 'n_flyspin': case 'n_tornado': case 'n_lowsweep': ang = p.aim + u * Math.PI * 3; rad = 12 * LS; break;
          case 'n_dragonlash': ang = p.aim + sweep(u, -2.4, 1.2, 0.3); rad = (9 + 6 * u) * LS; break;
          default: ang = p.aim + sweep(u, -2.0, 1.0); break;
        }
        hand = { x: sh.x + Math.cos(ang) * rad, y: sh.y + Math.sin(ang) * rad };
        void fdir;
      } else if (p.dashT > 0) {
        hand = { x: sh.x - Math.cos(p.aim) * 6 * LS, y: sh.y + 3 * LS };
      } else if (p.parryT > 0 || p.holdT > 0) {
        boost = null;
      } else {
        this.nunFlourishCd -= dt; this.nunFlourish = Math.max(0, this.nunFlourish - dt);
        if (this.nunFlourishCd <= 0 && this.nunFlourish === 0 && !p.moving && p.attackPhase === 'none') {
          this.nunFlourish = 0.55; this.nunFlourishCd = 1.6 + Math.random() * 1.2;
          this.nunFlourishTurns = Math.random() < 0.35 ? 3 : 2;
          this.nunFlourishDir = Math.random() < 0.5 ? 1 : -1;
        }
        if (this.nunFlourish > 0) {
          const fu = 1 - this.nunFlourish / 0.55, ga = p.aim + fu * Math.PI * 2 * this.nunFlourishTurns * this.nunFlourishDir;
          hand = { x: sh.x + Math.cos(ga) * 7.5 * LS, y: sh.y + Math.sin(ga) * 7.5 * LS };
          boost = null;
        } else {
          hand = { x: sh.x + Math.cos(p.aim) * 6.5 * LS, y: sh.y + (2.5 + Math.sin(p.aim) * 3) * LS };
          boost = null;
        }
      }
    }
    if (spin !== 0 && this.nunchaku.spinSpeed === 0) this.nunchaku.spinAng = Math.atan2(ndy, ndx);
    this.nunchaku.spinSpeed = spin;
    this.nunchaku.v2 = this.v2;
    this.nunchaku.update(hand, { x: ndx, y: ndy }, dt, spin, boost, p.attackPhase !== 'none');
    // WHIP CRACK: the moment the chain snaps taut at full reach during the crack move
    if (move && (move.id === 'n_whipcrack' || move.id === 'n_overhead') && !p.travelHit && this.attackPoseT() > 0.33 && this.nunchaku.tautness() > 0.93 && this.nunchaku.tipSpeed > 300) {
      p.travelHit = true; // reused as 'cracked' flag for nunchaku moves
      const tp = this.nunchaku.tip();
      this.sfx.nunchakuHit(true); this.sfx.hit();
      this.particles.impact(tp.x, tp.y, 7, '#ffffff');
      this.particles.ring(tp.x, tp.y, 2, 9, '#ffffff', 0.15, 1);
      this.shake(0.15);
    }
    // chatter / whoosh feedback
    if (this.nunchaku.tipSpeed > 260 && Math.random() < 0.25) this.sfx.chainRattle();
    if (this.nunchaku.tipSpeed > 420 && Math.random() < 0.5) { const tp = this.nunchaku.tip(); this.particles.lines(tp.x, tp.y, 1, 'rgba(255,255,255,0.6)', Math.atan2(tp.y - this.nunchaku.prevTip.y, tp.x - this.nunchaku.prevTip.x) + Math.PI, 120); }
  }

  cycleWeapon(dir: number) {
    const p = this.player;
    const owned: WeaponKind[] = ['fist', 'pistol'];
    if (p.hasRifle) owned.push('rifle');
    if (p.hasNunchaku) owned.push('nunchaku');
    if (p.hasKatana) owned.push('katana');
    if (p.hasAxe) owned.push('axe');
    if (p.hasDual) owned.push('dual');
    owned.push('yoyo', 'takamura', 'hayabusa', 'bat');
    const i = (owned.indexOf(p.weapon) + dir + owned.length) % owned.length;
    this.setWeapon(owned[i]);
  }
  setWeapon(w: WeaponKind) {
    const p = this.player;
    if (p.weapon === w) return;
    this.cancelPlayerAttack();
    if (this.silat) this.clearCombatScene();
    p.weapon = w;
    this.sfx.select();
    this.texts.add(p.x, p.y - 22, w === 'fist' ? 'KUNG FU' : w.toUpperCase(), '#ffffff', 1, 0.5);
    if (w === 'nunchaku') { this.nunchaku.reset(p.x + p.facing * 4, p.y - 8); this.sfNun.reset(p.x, p.y - 8); this.sfNunAim = p.aim; }
    if (w === 'katana') { this.katana.sheen = 0.25; p.sheatheT = 0; }
    if (w === 'axe') { this.lev.reset(); this.sfx.axeSwing(); }
    if (w === 'dual') this.sfx.dualSwing();
    if (w === 'takamura') { this.tak.reset(); this.katana.sheen = 0.3; this.sfx.sheathe(); }
    if (w === 'hayabusa') { this.hay.reset(); this.sfx.whoosh(); }
    if (w === 'bat') { this.batFlow = 0; this.batJuggle = 0; this.batTwirl = 0.6; this.batEquippedAt = this.time; this.sfx.batCrack(); this.sfx.axeSwing(); }
    if (w === 'yoyo') { if (this.yoyoVer === 1) this.yoyo.reset(p.x + p.facing * 6, p.y + 2); else this.yoyoV2.reset(p.x + p.facing * 6, p.y - 7 - p.z); this.sfx.whoosh(); this.texts.add(p.x, p.y - 22, this.yoyoVer === 1 ? 'YOYO V1' : 'YOYO V2', '#ffb84a', 1, 0.5); }
    p.comboStr = ''; p.attackPhase = 'none'; p.buffered = null;
    this.pushUI();
  }

  setNunStyle(style: 'v1' | 'v2') {
    if (this.nunStyle === style) return;
    const p = this.player;
    if (this.silat && p.weapon === 'nunchaku') this.clearCombatScene();
    this.nunStyle = style;
    try { localStorage.setItem(NUN_KEY, style); } catch { /* storage can be unavailable */ }
    this.sfNun.reset(p.x, p.y - 8);
    this.sfNunAim = p.aim;
    this.nunchaku.reset(p.x + p.facing * 4, p.y - 8);
    if (p.weapon === 'nunchaku') { p.attackPhase = 'none'; p.moveKey = null; p.comboStr = ''; p.buffered = null; }
    this.say(style === 'v2' ? 'NUNCHAKU V2 - STICK FIST STYLE' : 'NUNCHAKU V1 - DRIFTER CLASSIC', style === 'v2' ? '#ff6a4a' : '#9a9a9a', 2, 1.6);
    this.sfx.select();
    this.pushUI();
  }

  toggleNunStyle() { this.setNunStyle(this.nunStyle === 'v1' ? 'v2' : 'v1'); }

  selectNunStyle(style: 'v1' | 'v2') {
    if (!this.player.hasNunchaku) return;
    this.setNunStyle(style);
    if (this.player.weapon !== 'nunchaku') this.setWeapon('nunchaku');
    else this.pushUI();
  }

  /** OPUS V2: a four-hit combo with a Verlet chain and swept-stick collisions. */
  updateSFNunchaku(dt: number) {
    const p = this.player, nun = this.sfNun;
    if (!this.sfNunOn) return;
    if (p.stunT > 0) { nun.cur = null; nun.buffered = false; nun.idx = 0; }
    if (!nun.attacking) this.sfNunAim = p.aim;
    const facing = nun.attacking ? this.sfNunAim : p.aim;
    const event = nun.step(dt);
    if (nun.cur) {
      const lunge = nun.lungeK() * nun.cur.lunge;
      p.vx += Math.cos(facing) * lunge; p.vy += Math.sin(facing) * lunge;
    }
    const limbScale = this.longMode ? 2.5 : 1;
    let guardHand: Vec | undefined;
    if (!nun.attacking && (p.parryT > 0 || p.holdT > 0 || p.stunT > 0)) {
      const sk = solvePose(this.playerStickOpts(p.holdT > 0 ? p.holdPose : 'parry', p.holdT > 0 ? p.holdPoseT : 0.5));
      guardHand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
    }
    nun.update(dt, p.x, p.y - 4 * limbScale - p.z, facing, this.time, p.dashT > 0 ? 'dash' : 'idle', limbScale, guardHand);
    const attack = nun.cur;
    const recordHit = () => {
      if (this.time - this.fistHitT > 2) this.fistHits = 0;
      this.fistHits++; this.fistHitT = this.time;
    };
    if (event === 'hit' && attack) {
      const target = this.nearestEnemy(p.x, p.y, attack.range * limbScale, facing, attack.arc / 2);
      if (target && this.hasLOS(target) && !nun.hitIds.includes(target.id)) {
        nun.hitIds.push(target.id);
        target.playerSpamCount = (target.playerSpamCount ?? 0) + 1;
        // Check if both are attacking -> Trigger ADU SPAM or Mutual Deflect!
        if (!p.airborne && p.z <= 4 && (target.attackPhase === 'windup' || target.attackPhase === 'active') && target.stun <= 0 && (target.counterLockT ?? 0) <= 0 && target.stagger <= 0 && target.down <= 0) {
          if (this.clashCd <= 0 && ((target.rallyStreak ?? 0) >= 2 || Math.random() < 0.55)) {
            this.startClash(target);
            return;
          }
          this.mutualClashDeflect(target, facing);
          return;
        }
        // Smart Boss Parry on Nunchaku V2 swings
        const parryChance = 0.26 + Math.min(0.38, (target.playerSpamCount ?? 0) * 0.09);
        if (target.canParry && (target.counterLockT ?? 0) <= 0 && target.parryCd <= 0 && target.stagger <= 0 && target.down <= 0 && target.stun <= 0 && target.z <= 0 && ((target.parryT ?? 0) > 0 || Math.random() < parryChance)) {
          this.bossParryPlayer(target, target.x - Math.cos(facing) * target.r, target.y - 6, facing);
          return;
        }
        (target as Enemy & { nunCd?: number }).nunCd = this.time + 0.22;
        this.damageEnemy(target, attack.dmg, attack.posture, facing, attack.kb, { melee: true, knockdown: !!attack.heavy, hitstop: attack.name === 'WHIP CRACK' ? 0.05 : 0.02, shake: attack.heavy ? 0.2 : 0.08 });
        this.particles.impact(target.x, target.y - 4, 5, '#ffffff');
        this.sfx.nunchakuHit(!!attack.heavy); this.sfx.hit(); this.addCombo(1); this.addOfa(attack.dmg * 0.1); recordHit();
      }
      if (attack.name === 'WHIP CRACK') { this.shake(0.15); const tip = nun.pts[5]; this.particles.ring(tip.x, tip.y, 2, 9, '#ffffff', 0.15, 1); }
    }
    if (attack && nun.cur === attack && !this.clashDuel && p.stunT <= 0 && nun.endSpeed > 150) {
      const end = nun.pts[5];
      const hitAngle = Math.atan2(end.y - nun.prevEnd.y, end.x - nun.prevEnd.x);
      for (const enemy of this.enemies) {
        if (enemy.dead || enemy.spawnT > 0 || nun.hitIds.includes(enemy.id) || !this.hasLOS(enemy)) continue;
        const cooldown = enemy as Enemy & { nunCd?: number };
        if ((cooldown.nunCd ?? 0) > this.time) continue;
        if (nun.stickDist(enemy.x, enemy.y - 6 - enemy.z * 0.4) < enemy.r + 4.5) {
          nun.hitIds.push(enemy.id);
          cooldown.nunCd = this.time + 0.18;
          this.damageEnemy(enemy, attack.dmg, attack.posture, hitAngle, attack.kb, { melee: true, hitstop: 0.02, shake: 0.08 });
          this.particles.impact(enemy.x, enemy.y - 4, 4, '#ffffff'); this.sfx.nunchakuHit(false); this.addCombo(1); recordHit();
        }
      }
    }
    if (nun.endSpeed > 260 && Math.random() < 0.25) this.sfx.chainRattle();
  }

  selectYoyoVersion(version: 1 | 2) {
    const p = this.player;
    if (p.weapon === 'yoyo' && this.yoyoVer === version) return;
    this.yoyoVer = version;
    if (p.weapon !== 'yoyo') {
      this.setWeapon('yoyo');
      return;
    }
    p.attackPhase = 'none'; p.moveKey = null; p.comboStr = ''; p.buffered = null;
    p.prevLimb = null; this.yoyoFeet = null;
    if (version === 1) this.yoyo.reset(p.x + p.facing * 6, p.y + 2);
    else this.yoyoV2.reset(p.x + p.facing * 6, p.y - 7 - p.z);
    this.sfx.select();
    this.texts.add(p.x, p.y - 22, `YOYO V${version}`, '#ffb84a', 1, 0.6);
    this.pushUI();
  }

  setYoyoSkin(id: YoyoSkinId) {
    if (!isYoyoSkinId(id)) return;
    this.yoyoV2.setSkin(id);
    try { localStorage.setItem(YOYO_SKIN_KEY, id); } catch { /* storage can be unavailable */ }
    this.pushUI();
  }

  cycleYoyoSkin() {
    const index = YOYO_SKINS.findIndex((skin) => skin.id === this.yoyoV2.skinId);
    this.setYoyoSkin(YOYO_SKINS[(index + 1) % YOYO_SKINS.length].id);
    this.selectYoyoVersion(2);
  }

  // ------------------------------------------------------------------ guns
  fire() {
    const p = this.player;
    const w = p.weapon;
    if (w === 'fist') return;
    const ammo = w === 'pistol' ? p.ammoP : p.ammoR;
    if (ammo <= 0) {
      this.sfx.empty();
      this.texts.add(p.x, p.y - 22, 'EMPTY! FISTS!', '#ff3b3b', 1, 0.7);
      this.setWeapon('fist');
      return;
    }
    if (w === 'pistol') p.ammoP--; else p.ammoR--;
    const pistol = w === 'pistol';
    p.fireCd = (pistol ? 0.19 : 0.082) / this.stats.fireRate;
    const spread = (pistol ? 0.012 : 0.03) + p.bloom;
    p.bloom = Math.min(pistol ? 0.08 : 0.16, p.bloom + (pistol ? 0.03 : 0.022));
    const a = p.aim + rnd(-spread, spread);
    const sp = pistol ? 1150 : 1300;
    const hx = p.x + Math.cos(p.aim) * 11, hy = p.y - 7 + Math.sin(p.aim) * 7;
    this.bullets.push({
      x: hx, y: hy, px: hx, py: hy, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, r: 2, dmg: (pistol ? 4 : 2) + this.stats.bulletDmg, owner: 'player',
      life: 1.2, color: pistol ? '#fff6c8' : '#ffe08a', pierce: this.stats.pierce, bounce: this.stats.bounce, kind: pistol ? 'pistol' : 'rifle', hitIds: [],
      structure: pistol ? 10 : 5, kb: pistol ? 90 : 35,
    });
    p.muzzleMax = pistol ? 0.07 : 0.05;
    p.muzzle = p.muzzleMax; p.muzzleX = hx; p.muzzleY = hy; p.muzzleA = a;
    // PUNCHY PIXEL MUZZLE: hot core sparks, side-vent sparks, chunky smoke puffs, light pop
    const mxp = hx + Math.cos(a) * 3, myp = hy + Math.sin(a) * 3;
    // pixelfx muzzle: spiky white-cored flash, sparks + powder, curling smoke, tumbling casing
    this.gunfx.muzzle(mxp, myp, a, pistol, p.y, Math.cos(a) >= 0 ? 1 : -1);
    this.flash('#ffd27f', pistol ? 0.07 : 0.035);
    this.hitstop = Math.max(this.hitstop, pistol ? 0.012 : 0);
    this.sfx.shot(pistol ? 'pistol' : 'rifle');
    this.shake(pistol ? 0.34 : 0.19);
    p.recoil = 1;
    p.shootT = 0.12;
    p.kx -= Math.cos(p.aim) * (pistol ? 26 : 12); p.ky -= Math.sin(p.aim) * (pistol ? 26 : 12);
    this.camKick.x -= Math.cos(p.aim) * (pistol ? 6.5 : 3.2); this.camKick.y -= Math.sin(p.aim) * (pistol ? 6.5 : 3.2);
  }

  // ------------------------------------------------------------------ kung fu
  queueAttack(k: 'L' | 'H') {
    const p = this.player;
    if (p.stunT > 0 || p.fatality || p.focusDash || p.holdT > 0 || p.rageDash) return;
    p.parryT = 0; p.parryHit = false;
    // ---- RAGE: every LMB dashes to the nearest enemy and executes it
    const bareFists = p.weapon === 'fist' || (p.weapon === 'axe' && !this.lev.held);
    if (k === 'L' && p.rageOn && bareFists) { this.rageStrike(); return; }
    const silatWeapon = p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat';
    if (k === 'L' && silatWeapon && this.silatLinkT > 0 && this.trySilatLink()) return;
    if (k === 'L' && silatWeapon && !p.airborne && p.attackPhase !== 'active' && this.trySilat(null, false)) return;
    if (this.sfNunOn) {
      if (!this.sfNun.attacking) { this.sfNunAim = p.aim; this.sfNun.start(k === 'H'); this.sfx.swing(this.sfNun.cur?.heavy ? 0.7 : 1.1); }
      else if (this.sfNun.cur && this.sfNun.t / this.sfNun.cur.dur > 0.3) this.sfNun.buffered = true;
      return;
    }
    // ---- FREESTYLE RHYTHM ENGINE (fists): the tempo of your clicks picks the style and the game chains the moves
    if (k === 'L' && bareFists && !p.airborne && !p.running && p.dashT <= 0 && p.sinceDash > 0.2) {
      const gap = this.time - p.chainLast;
      p.chainLast = this.time;
      if (gap <= 1.1) { p.rhythm.push(gap); if (p.rhythm.length > 4) p.rhythm.shift(); } else { p.rhythm = []; p.style = 'none'; p.styleStreak = 0; p.flowStep = 0; p.chain = 0; }
      const style = this.classifyRhythm();
      if (style !== 'none') { this.flowMove(style); return; }
    }
    const cur = p.moveKey ? MOVES[p.moveKey] : null;
    if (p.attackPhase === 'none' || (p.attackPhase === 'recover' && cur && (cur.bat || p.attackT < cur.recover * 0.65))) this.startAttackInput(k);
    else p.buffered = k;
  }

  /** Tempo -> style. Needs 2 consistent gaps so a single fast double-click doesn't flip styles. */
  classifyRhythm(): 'none' | 'wingchun' | 'blackleg' | 'kungfu' {
    const p = this.player;
    const r = p.rhythm;
    if (r.length < 2) return 'none';
    const a = r[r.length - 1], b = r[r.length - 2];
    const cls = (x: number) => (x >= 0.06 && x < 0.3 ? 'wingchun' : x >= 0.3 && x < 0.62 ? 'blackleg' : x >= 0.62 && x <= 1.05 ? 'kungfu' : 'none');
    const ca = cls(a), cb = cls(b);
    if (ca === 'none') return 'none';
    // continuing an established style tolerates one off-beat; switching styles needs two beats in the new tempo
    if (ca === p.style) return ca;
    if (ca === cb) return ca;
    return p.style !== 'none' && p.styleStreak > 0 ? p.style : 'none';
  }

  /** Advance the chosen style's auto-combo by one move. Styles have their own flows; transitions get a bridge move. */
  flowMove(style: 'wingchun' | 'blackleg' | 'kungfu') {
    const p = this.player;
    const switching = p.style !== style && p.style !== 'none';
    if (p.style !== style) { p.style = style; p.flowStep = 0; p.styleStreak = 0; p.chain = 0; if (switching) this.say(style === 'wingchun' ? 'WING CHUN' : style === 'blackleg' ? 'BLACK LEG' : 'KUNG FU', this.pal.accent2, 2, 0.6); }
    p.styleStreak++;
    p.styleHeat = Math.min(1, p.styleHeat + 0.08);
    if (p.styleStreak === 2) this.say(style === 'wingchun' ? 'WING CHUN' : style === 'blackleg' ? 'BLACK LEG STYLE' : 'KUNG FU', this.pal.accent2, 1, 0.6);
    // target state decides finishers
    const target = this.nearestEnemy(p.x, p.y, 34, p.aim, 1.5) ?? this.nearestEnemy(p.x, p.y, 22, p.aim, 2.8);
    const nearlyDead = !!target && !target.boss && target.hp <= Math.max(3, target.maxHp * 0.22);
    const bossSoft = !!target && target.boss && target.structure >= target.maxStructure * 0.6;
    if (style === 'wingchun') { this.chainPunch(); return; }
    // bridge move when switching styles: a flashy transition that fits the new tempo
    if (switching) { p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; this.startAttack(style === 'blackleg' ? 'S4' : 'HH'); return; }
    const flows: Record<'blackleg' | 'kungfu', string[]> = {
      blackleg: ['S1', 'S2', 'S3', 'S4', 'S5', 'S1', 'S3', 'S2', 'S6', 'S7', 'S8'],
      kungfu: ['H', 'KF1', 'LH', 'KF2', 'LLLH', 'HHL', 'LHH', 'LLLLH', 'HLL'],
    };
    const flow = flows[style];
    let key = flow[p.flowStep % flow.length];
    if ((nearlyDead || bossSoft) && p.styleStreak >= 2) key = style === 'blackleg' ? (p.flowStep % 2 ? 'S8' : 'S5') : (p.flowStep % 2 ? 'LLLH' : 'HHL');
    p.flowStep++;
    // fire NOW (interrupt the previous move's recovery so the flow feels continuous)
    const cur = p.moveKey ? MOVES[p.moveKey] : null;
    if (p.attackPhase === 'windup' || (p.attackPhase === 'active' && cur && p.attackT > cur.active * 0.5)) { p.buffered = 'L'; this._pfk = key; return; }
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = '';
    this.startAttack(key);
    if (MOVES[key].finisher) this.say(MOVES[key].name, this.pal.accent2, 2, 0.8);
  }

  /** one link of the Wing Chun chain: instant restart of the punch with the other fist; finish when the target is nearly dead */
  chainPunch() {
    const p = this.player;
    p.chain++;
    p.chainSide *= -1;
    const target = this.nearestEnemy(p.x, p.y, 30, p.aim, 1.4) ?? this.nearestEnemy(p.x, p.y, 20, p.aim, 2.8);
    if (target) {
      // almost dead (or a very long chain): the next click is the FINISH
      const nearlyDead = target.hp <= Math.max(3, target.maxHp * 0.22) && !target.boss;
      const bossSoft = target.boss && target.structure >= target.maxStructure * 0.6;
      if (nearlyDead || bossSoft || p.chain >= 24) {
        p.chain = 0;
        this.startAttack('CHAINEND');
        this.say('WING CHUN FINISH', this.pal.accent2, 2, 0.8);
        return;
      }
    }
    // hard reset of the attack state so the next fist fires immediately (no recovery wait)
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = '';
    this.startAttack('CHAIN');
    // speed lines + alternating fist flash
    this.particles.lines(p.x + Math.cos(p.aim) * 8, p.y - 6 + Math.sin(p.aim) * 5, 2, '#ffffff', p.aim, 220);
    if (p.chain === 6) this.say('CHAIN PUNCH!', this.pal.accent2, 2, 0.7);
    if (p.chain > 0 && p.chain % 10 === 0) this.say(`${p.chain} CHAIN`, '#ffe66d', 1, 0.5);
  }

  /** RAGE activation (R) when the meter is full */
  tryRage() {
    const p = this.player;
    if (p.rageOn) return;
    if (p.rage < 100) { this.texts.add(p.x, p.y - 22, 'RAGE NOT READY', '#777', 1, 0.5); this.sfx.empty(); return; }
    p.rage = 100; p.rageOn = true; p.rageT = 8; p.rageKills = 0; this.rageReadySaid = false;
    this.setWeapon('fist');
    this.say('RAGE!', '#ff2a2a', 4, 1.2);
    this.sfx.announce(); this.sfx.focus();
    this.flash('#ff2a2a', 0.5); this.shake(0.8); this.slow(0.5, 0.25);
    this.particles.shockwave(p.x, p.y - 4, 60, '#ff2a2a', 0.5);
    for (const e of this.enemies) if (!e.dead && dist(e.x, e.y, p.x, p.y) < 60) { e.stun = Math.max(e.stun, 0.6); e.state = 'stun'; }
  }

  /** RAGE LMB: blur-dash to the nearest enemy, then an execution strike */
  rageStrike() {
    const p = this.player;
    let e = this.nearestEnemy(p.x, p.y, 170, p.aim, 1.3);
    if (!e) e = this.nearestEnemy(p.x, p.y, 170, p.aim, Math.PI);
    if (!e) { this.startAttack('LLLL'); return; } // nobody near: a spinning kick for show
    const a = Math.atan2(e.y - p.y, e.x - p.x);
    const gap = e.r + p.r + 3;
    p.rageDash = { sx: p.x, sy: p.y, tx: e.x - Math.cos(a) * gap, ty: e.y - Math.sin(a) * gap, t: 0, id: e.id };
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; p.aim = a; p.attackAim = a; p.facing = Math.cos(a) >= 0 ? 1 : -1; p.z = 0;
    e.stun = Math.max(e.stun, 0.5); e.state = 'stun';
    this.sfx.dash(); this.sfx.whoosh();
    this.particles.ring(p.x, p.y - 6, 2, 16, '#ff2a2a', 0.2, 1);
  }

  updateRage(dt: number, raw: number) {
    const p = this.player;
    if (p.rageOn) {
      p.rageT -= dt; p.rage = Math.max(0, 100 * (p.rageT / 8));
      if (Math.random() < 0.6) this.particles.add({ x: p.x + rnd(-5, 5), y: p.y - 6 + rnd(-8, 4), vx: rnd(-10, 10), vy: rnd(-50, -20), life: rnd(0.3, 0.6), c: Math.random() < 0.5 ? '#ff2a2a' : '#ffb347', k: 7 });
      if (p.rageT <= 0) { p.rageOn = false; p.rage = 0; p.rageDash = null; this.say('RAGE OVER', '#9a9a9a', 1, 0.8); }
    }
    if (p.rageDash) {
      const rd = p.rageDash;
      rd.t += raw / 0.1;
      const k = Math.min(1, rd.t), ek = 1 - Math.pow(1 - k, 3);
      const nx = lerp(rd.sx, rd.tx, ek), ny = lerp(rd.sy, rd.ty, ek);
      if (this.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; }
      this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim, pose: 'ragedash', poseT: 0 }, '#ff2a2a', { x: Math.cos(p.aim), y: Math.sin(p.aim) });
      if (k >= 1) {
        const e = this.enemies.find((en) => en.id === rd.id);
        p.rageDash = null;
        if (e && !e.dead) { p.aim = Math.atan2(e.y - p.y, e.x - p.x); p.attackAim = p.aim; }
        this.startAttack('RAGEKILL');
        p.iframes = Math.max(p.iframes, 0.35);
      }
    }
    // chain / style decay when the rhythm stops
    if (p.chain > 0 && this.time - p.chainLast > 0.5) p.chain = 0;
    if (this.time - p.chainLast > 1.2) { if (p.style !== 'none') { p.style = 'none'; p.styleStreak = 0; p.flowStep = 0; p.rhythm = []; } p.styleHeat = Math.max(0, p.styleHeat - dt * 0.6); }
    // all style moves build rage a little (chain builds the most); heat makes every style flow faster
    this.timeScaleBonus = 1 + 0.25 * p.styleHeat;
  }
  startAttackInput(k: 'L' | 'H') {
    const p = this.player;
    let key: string;
    const running = p.running || (p.runT > 0.25 && p.moving);
    if (p.weapon === 'yoyo' && this.yoyoVer === 2) {
      if (k === 'L' && running && p.comboStr === '') key = 'YRUN';
      else if (k === 'L' && p.airborne) key = 'YAIR';
      else { const base = p.comboStr.startsWith('Y') ? p.comboStr : 'Y'; const cand = base + k; key = MOVES[cand] ? cand : 'Y' + k; }
      this.startAttack(key);
      return;
    }
    if (p.weapon === 'nunchaku') {
      // nunchaku tree: N + sequence. RUN + LMB = DRAGON LASH (lethal charge), dash + LMB = flying helicopter.
      if (k === 'L' && running && p.comboStr === '' && p.tkdCd <= 0) { key = 'NRUN'; p.tkdCd = 1.1; this.say('DRAGON LASH!', this.pal.accent2, 2, 0.7); this.sfx.launch(); }
      else if (k === 'L' && (p.dashT > 0 || p.sinceDash < 0.16 || (running && p.comboStr === ''))) key = 'NDASH';
      else {
        const base = p.comboStr.startsWith('N') ? p.comboStr : 'N';
        const cand = base + k;
        key = MOVES[cand] ? cand : 'N' + k;
      }
      this.startAttack(key);
      return;
    }
    if (p.weapon === 'bat') {
      if (this.time - this.batLastT > 1.1) { this.batFlow = 0; this.batJuggle = 0; }
      this.batLastT = this.time; this.batTauntT = 0;
      if (k === 'L' && running && p.comboStr === '' && p.tkdCd <= 0) { key = 'BRUN'; p.tkdCd = 1.3; this.say('GRAND SLAM', '#ffb347', 2, 0.7); this.sfx.launch(); }
      else if (k === 'L' && (p.dashT > 0 || p.sinceDash < 0.16)) key = 'BDASH';
      else if (k === 'H') key = this.batSpam >= 12 ? 'BH' : 'SB_SPIN';
      else {
        const air = this.nearestEnemy(p.x, p.y, 38, p.aim, 1.3);
        const down = this.enemies.find((e) => !e.dead && e.spawnT <= 0 && e.z <= 1 && (e.down > 0 || e.state === 'down') && dist(e.x, e.y, p.x, p.y) < 30 + e.r && Math.abs(angleDiff(Math.atan2(e.y - p.y, e.x - p.x), p.aim)) < 1.4);
        if (air && air.z > 3) { this.batJuggle++; if (this.batJuggle >= 4) { key = 'B_SPIKE'; this.batJuggle = 0; } else key = 'B_PEPPER'; }
        else if (down) key = 'SB_POUND';
        else {
          const n = ++this.batFlow;
          if (n % 12 === 0) key = 'B_HOMER';
          else if (n % 4 === 0) { const specials = ['SB_KNOB', 'SB_UPPER', 'SB_SMASH'].filter((x) => x !== this.batLastSpecial); key = specials[Math.floor(Math.random() * specials.length)]; this.batLastSpecial = key; }
          else key = n % 2 === 1 ? 'SB_F' : 'SB_B';
        }
      }
      this.startAttack(key);
      return;
    }
    if ((p.weapon === 'axe' && this.lev.held) || p.weapon === 'dual') {
      const R = p.weapon === 'axe' ? 'A' : 'D';
      if (k === 'L' && running && p.comboStr === '' && p.tkdCd <= 0) { key = R + 'RUN'; p.tkdCd = p.weapon === 'axe' ? 1.5 : 1.2; this.say(MOVES[key].name, p.weapon === 'axe' ? '#ffb347' : '#bfe8ff', 2, 0.7); if (p.weapon === 'axe') this.sfx.launch(); else this.sfx.dualSwing(); }
      else if (k === 'L' && (p.dashT > 0 || p.sinceDash < 0.16 || (running && p.comboStr === ''))) key = R + 'DASH';
      else { const base = p.comboStr.startsWith(R) ? p.comboStr : R; const cand = base + k; key = MOVES[cand] ? cand : R + k; }
      this.startAttack(key);
      return;
    }
    if (p.weapon === 'katana') {
      // katana tree: K + sequence. RUN + LMB = IAIJUTSU dash-through, dash + LMB = dash cut.
      if (k === 'L' && running && p.comboStr === '' && p.tkdCd <= 0) { key = 'KRUN'; p.tkdCd = 1.3; this.say('IAIJUTSU', '#ffffff', 2, 0.7); this.sfx.whoosh(); }
      else if (k === 'L' && (p.dashT > 0 || p.sinceDash < 0.16 || (running && p.comboStr === ''))) key = 'KDASH';
      else {
        const base = p.comboStr.startsWith('K') ? p.comboStr : 'K';
        const cand = base + k;
        key = MOVES[cand] ? cand : 'K' + k;
        if (this.v2 && k === 'L') {
          // V2 KATANA CHAIN VARIATIF (Takamura / Hyun's Dojo): tiap chain baru di-roll —
          // kadang 1 tebas + SHEATHE FLASH, kadang 2 tebas + DASH CUT menerobos, kadang 3 + HEAVEN SPLITTER
          if (p.comboStr === '') { const r = Math.random(); p.katanaPlan = r < 0.4 ? 1 : r < 0.7 ? 2 : 3; }
          const nS = p.comboStr === 'KL' ? 1 : p.comboStr === 'KLL' ? 2 : p.comboStr === 'KLLL' ? 3 : 0;
          if (p.katanaPlan === 1 && nS >= 1) key = 'KSHEATH';
          else if (p.katanaPlan === 2 && nS >= 2) key = 'KDASH';
        }
      }
      this.startAttack(key);
      return;
    }
    if (k === 'L' && (p.dashT > 0 || p.sinceDash < 0.16)) key = 'DASH';
    else if (k === 'L' && running && p.comboStr === '') {
      // RUN + LEFT CLICK = Taekwondo flying side kick (falls back to the running straight while on cooldown)
      if (p.tkdCd <= 0) {
        key = 'TKD';
        p.tkdCd = 0.9;
        p.tkdDir = { x: Math.cos(p.aim), y: Math.sin(p.aim) };
        this.say('TAEKWONDO!', this.pal.accent2, 2, 0.7);
        this.sfx.launch();
      } else key = 'RUNPUNCH';
    }
    else if (k === 'H' && running && p.comboStr === '' && p.weapon === 'fist') key = p.tkdCd > 0.45 ? 'DASH' : this.runHeavyToggle++ % 2 === 0 ? 'RUNPUNCH' : 'DASH';
    else { const cand = p.comboStr + k; key = MOVES[cand] ? cand : k; }
    this.startAttack(key);
  }
  /** attack-token system: how many melee enemies may press the attack at once */
  maxTokens() {
    if (this.mode === 'survival') return Math.min(6, 1 + Math.floor(this.wave / 3));
    return this.levelN < 8 ? 1 : this.levelN < 35 ? 2 : this.levelN < 110 ? 3 : 4;
  }
  /** 0..1 how smart/aggressive the AI behaves right now */
  brutality() {
    return this.mode === 'survival' ? clamp(this.wave / 18, 0, 1) : clamp(this.levelN / 160, 0, 1);
  }
  releaseToken(e: Enemy) {
    if (e.token) { e.token = false; e.tokenT = 0; }
  }
  slotCount(role: 'melee' | 'ranged') {
    let n = 0;
    for (const e of this.enemies) if (!e.dead && e.role === role && e.kind !== 'boss' && e.kind !== 'bomber') n++;
    return n;
  }
  /** assign ring slots + attack tokens; called every frame (cheap) */
  updateTactics(dt: number) {
    const p = this.player;
    const melee: Enemy[] = [], ranged: Enemy[] = [];
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0 || e.kind === 'boss' || e.kind === 'bomber') continue;
      (e.role === 'melee' ? melee : ranged).push(e);
    }
    // slots: sort by angle around the player so neighbours don't cross paths, assign evenly
    // each enemy's ring angle = its own bearing, relaxed toward the midpoint between its angular neighbours.
    // Nobody is ever sent to the far side of the player, so they spread out without crossing through him.
    const relax = (arr: Enemy[]) => {
      arr.sort((a, b) => Math.atan2(a.y - p.y, a.x - p.x) - Math.atan2(b.y - p.y, b.x - p.x));
      const n = arr.length;
      const angs = arr.map((e) => Math.atan2(e.y - p.y, e.x - p.x));
      for (let i = 0; i < n; i++) {
        arr[i].slot = i;
        if (n === 1) { arr[i].slotAng = angs[i]; continue; }
        const prev = angs[(i - 1 + n) % n] - (i === 0 ? Math.PI * 2 : 0);
        const next = angs[(i + 1) % n] + (i === n - 1 ? Math.PI * 2 : 0);
        const minGap = Math.min(1.1, Math.PI * 2 / n); // keep at least this much arc from the neighbours when possible
        let a = angs[i];
        if (a - prev < minGap) a += (minGap - (a - prev)) * 0.5;
        if (next - a < minGap) a -= (minGap - (next - a)) * 0.5;
        arr[i].slotAng = a;
      }
    };
    relax(melee); relax(ranged);
    // tokens: expire stale ones, hand out to the closest eligible attackers
    let held = 0;
    for (const e of melee) {
      if (e.token) { e.tokenT -= dt; if (e.tokenT <= 0 || e.stagger > 0 || e.down > 0) this.releaseToken(e); else held++; }
    }
    const max = this.maxTokens();
    this.tokenTimer -= dt;
    if (held < max && this.tokenTimer <= 0) {
      const cands = melee.filter((e) => !e.token && e.stagger <= 0 && e.down <= 0 && e.stun <= 0 && e.attackCd <= 0.3 && e.state === 'chase').sort((a, b) => dist(a.x, a.y, p.x, p.y) - dist(b.x, b.y, p.x, p.y));
      // one attacker at a time with a short gap between hand-offs; sometimes a coordinated pair/trio rushes together
      const coordinated = Math.random() < 0.2 + this.brutality() * 0.5;
      const want = coordinated ? max : Math.min(max, held + 1);
      for (const e of cands) {
        if (held >= Math.max(1, Math.round(want * this.mental))) break;
        e.token = true; e.tokenT = 2.4; held++;
      }
      this.tokenTimer = coordinated ? 1.0 - this.brutality() * 0.5 : Math.max(0.1, 0.45 - this.brutality() * 0.3);
    }
    // separation vectors (allies + player) so nobody stacks
    const all = this.enemies;
    for (const e of all) {
      e.sepx = 0; e.sepy = 0;
      if (e.dead || e.spawnT > 0) continue;
      for (const o of all) {
        if (o === e || o.dead || o.spawnT > 0) continue;
        const dx = e.x - o.x, dy = e.y - o.y;
        const d = Math.hypot(dx, dy);
        const want = (e.r + o.r) * 2.2;
        if (d < want && d > 0.01) { const f = (want - d) / want; e.sepx += (dx / d) * f; e.sepy += (dy / d) * f; }
      }
    }
  }
  startAttack(key: string) {
    const p = this.player;
    const move = MOVES[key];
    if (!move) return;
    if (this.parryCounterKey !== key) this.parryCounterKey = null;
    p.comboStr = ['DASH', 'FOCUS', 'RUNPUNCH', 'NDASH', 'NRUN', 'KDASH', 'KRUN', 'ARUN', 'ADASH', 'DRUN', 'DDASH', 'TKD', 'AIR', 'CHAIN', 'CHAINEND', 'RAGEKILL', 'YRUN', 'YAIR', 'BRUN', 'BDASH'].includes(key) ? '' : key;
    if (move.katana || move.axe || move.dual || move.bat) { p.iaiVictims = []; p.sheatheT = 0; p.bladeA = p.aim + (move.slash ? move.slash.from * p.facing : 0); p.bladePrevA = p.bladeA; p.bladeB = p.aim - (move.slash ? move.slash.from * p.facing : 0); }
    p.moveKey = key; p.attackPhase = 'windup'; p.attackT = move.windup; p.attackElapsed = 0; p.hitSet = []; p.hitTimes = {}; p.prevLimb = null; p.travelHit = false; this.prevBlade = null; this.yoyoFeet = null;
    p.comboTimer = 0.9;
    // ONE FOR ALL lock-on: blink to the locked enemy when it is out of reach (game1's behaviour),
    // so a full meter plays as "pick a target, delete it, the lock jumps to the next one".
    if (p.ofaActive && this.lockTarget && !this.lockTarget.dead && key !== 'FOCUS') {
      const lt = this.lockTarget;
      const d = dist(lt.x, lt.y, p.x, p.y);
      const reach = move.range * this.stats.meleeRange + 6;
      if (d > reach && d < 240) {
        const la = Math.atan2(lt.y - p.y, lt.x - p.x);
        for (let i = 1; i <= 5; i++) {
          const tt = i / 6;
          this.addAfterimage({ x: lerp(p.x, lt.x, tt), y: lerp(p.y, lt.y, tt), facing: Math.cos(la) >= 0 ? 1 : -1, aim: la, scale: 1 }, OFA_COL, { x: Math.cos(la), y: Math.sin(la) });
        }
        const nx = lt.x - Math.cos(la) * (lt.r + p.r + 3), ny = lt.y - Math.sin(la) * (lt.r + p.r + 3);
        if (this.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; p.iframes = Math.max(p.iframes, 0.1); p.aim = la; p.attackAim = la; p.facing = Math.cos(la) >= 0 ? 1 : -1; }
        this.sfx.dash();
      }
    }
    if (key !== 'FOCUS') {
      // soft aim assist: snap toward the nearest enemy in a generous cone around the cursor direction
      const searchArc = Math.max(1.3, move.arc + 0.7);
      let target = this.nearestEnemy(p.x, p.y, move.range * this.stats.meleeRange * 1.7 + 12 + (move.travel ? 50 : 0), p.aim, searchArc);
      // point-blank: an enemy touching you gets the strike even if the cursor drifted behind you
      if (!target) target = this.nearestEnemy(p.x, p.y, 16, p.aim, 2.6);
      if (target) {
        const ta = Math.atan2(target.y - p.y, target.x - p.x);
        p.aim += angleDiff(ta, p.aim) * 0.85;
      }
    }
    p.attackAim = p.aim;
    p.facing = Math.cos(p.aim) >= 0 ? 1 : -1;
    if (p.dashT > 0) p.dashT = 0;
    p.parryT = 0;
    p.runT = 0; p.running = false;
    if (move.jump && !move.air) { this.particles.smoke(p.x, p.y, 5, '#888', 30, 0.4); p.squash = 0.85; }
    if (move.id === 'tkd') {
      p.lean = { x: Math.cos(p.aim), y: Math.sin(p.aim) }; p.tkdDir = { ...p.lean };
      this.particles.dirBurst(p.x, p.y, 8, '#cfcfcf', p.aim + Math.PI, 0.5, 110, 0.35);
      this.particles.ring(p.x, p.y, 3, 12, '#ffffff', 0.18, 1);
    }
  }
  attackPoseT() {
    if (this.clashDuel && (this.clashDuel.turn === 'player' || this.clashDuel.turn === 'both')) {
      return this.clashDuel.u;
    }
    const p = this.player;
    if (!p.moveKey) return 0;
    const m = MOVES[p.moveKey];
    if (p.attackPhase === 'windup') return 0.3 * (1 - p.attackT / m.windup);
    if (p.attackPhase === 'active') return 0.3 + 0.3 * (1 - p.attackT / m.active);
    if (p.attackPhase === 'recover') return 0.6 + 0.4 * (1 - p.attackT / m.recover);
    return 0;
  }
  updateAttack(dt: number) {
    const p = this.player;
    if (p.attackPhase === 'none') {
      this.parryCounterKey = null;
      if (p.comboStr) { p.comboTimer -= dt; if (p.comboTimer <= 0) { p.comboStr = ''; p.katanaPlan = 0; } }
      return;
    }
    const attackKey = p.moveKey;
    const move = attackKey ? MOVES[attackKey] : null;
    if (!move) { this.cancelPlayerAttack(); return; }
    const spd = (move.id === 'chain' ? 1 : this.timeScaleBonus) * (move.bat ? this.batSpeed() : 1);
    p.attackT -= dt * spd;
    p.attackElapsed += dt * spd;
    if (p.attackPhase === 'windup') {
      if (p.attackT <= 0) {
        p.attackPhase = 'active'; p.attackT = move.active;
        p.kx += Math.cos(p.aim) * move.lunge; p.ky += Math.sin(p.aim) * move.lunge;
        this.sfx.swing(move.sfx === 'heavy' ? 0.7 : move.sfx === 'kick' ? 0.85 : move.sfx === 'nunchaku' ? 1.4 : 1.1);
        if (move.nunchaku) { this.nunchaku.spinSpeed = 0; if (move.id === 'n_whipcrack' || move.id === 'n_overhead') this.sfx.whoosh(); }
        if (move.yoyo) {
          const spin = move.id === 'y_orbit' || move.id === 'y_storm' || move.id === 'y_flare';
          this.sfx.yoyoThrow(spin);
          this.particles.ring(p.x, p.y - 6 - p.z, 3, spin ? 16 : 10, this.yoyoV2.skin.aura, 0.2, 1);
          if (spin || move.finisher) this.say(move.name, this.yoyoV2.skin.accent, 2, 0.7);
        }
        const a = p.aim;
        const fx = p.x + Math.cos(a) * 9, fy = p.y - 6 + Math.sin(a) * 6;
        if (move.bat) { this.particles.lines(fx, fy, 2, '#ffffff', a + rnd(-0.4, 0.4), 260); if (this.batSpam >= 8) this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: move.pose, poseT: 0.45 }, '#ffb347', p.lean); }
        switch (move.id) {
          case 'jab': case 'cross': this.particles.lines(fx, fy, 3, '#ffffff', a, 240); break;
          case 'runpunch': this.particles.lines(fx, fy, 6, '#ffffff', a, 320); this.particles.smoke(p.x, p.y, 4, '#888', 30, 0.4); break;
          case 'sweep': this.particles.ring(p.x, p.y, 6, move.range * this.stats.meleeRange, '#ffffff', 0.22, 1); this.particles.smoke(p.x, p.y, 5, '#777', 30, 0.4); break;
          case 'roundhouse': this.particles.smoke(p.x, p.y, 3, '#777', 25, 0.35); break;
          case 'dragon': case 'focus':
            this.particles.smoke(p.x, p.y, 6, '#888', 35, 0.45);
            this.particles.dirBurst(fx, fy, 8, '#ffffff', -Math.PI / 2, 0.35, 180, 0.3);
            if (move.id === 'focus') this.particles.shockwave(p.x, p.y - 4, 30, this.pal.accent, 0.3);
            break;
          case 'palm': this.particles.ring(fx, fy, 2, 10, '#ffffff', 0.15, 1); break;
          case 'flying': this.sfx.launch(); this.particles.dirBurst(p.x, p.y, 6, '#cfcfcf', a + Math.PI, 0.4, 90, 0.3); break;
        }
      }
    }
    if (p.attackPhase === 'active') {
      if (move.travel) {
        const prog = 1 - p.attackT / move.active;
        if (!move.air) p.z = (move.jump ?? 0) * Math.sin(Math.PI * clamp(prog, 0, 1));
        this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: move.pose, poseT: move.id === 'tkd' ? 0.5 : 0.45 }, this.pal.accent, p.lean);
        if (Math.random() < 0.8) this.particles.lines(p.x - Math.cos(p.aim) * 6, p.y - 6 - Math.sin(p.aim) * 4, 1, '#ffffff', p.aim + Math.PI, 160);
        if (move.air) { p.vz = Math.min(p.vz, -90); }
      }
      this.resolveMelee(move);
      if (p.attackPhase !== 'active' || p.moveKey !== attackKey || this.clashDuel || this.silat) return;
      if (p.attackT <= 0) {
        p.attackPhase = 'recover'; p.attackT = move.recover;
        if (move.id === 'sb_smash' || move.id === 'sb_pound' || move.id === 'b_spike') {
          const gx = p.x + Math.cos(p.aim) * 15, gy = p.y + Math.sin(p.aim) * 7;
          this.particles.shockwave(gx, gy, move.id === 'sb_pound' ? 14 : 20, '#ffffff', 0.25);
          this.particles.smoke(gx, gy, 6, '#8a8a8a', 40, 0.45);
          this.particles.burst(gx, gy, 6, this.pal.wallTop, 120, 0.4, 2, 3);
          this.stamp(gx, gy, '#00000055', 2); this.shake(0.35); this.sfx.slam();
        }
        if (move.jump && !move.air) { p.z = 0; p.squash = 0.78; this.particles.smoke(p.x, p.y, 6, '#888', 30, 0.4); this.sfx.land(); this.shake(0.15); }
      }
    } else if (p.attackPhase === 'recover') {
      if (p.buffered && (move.bat || p.attackT < move.recover * 0.65)) { const b = p.buffered; p.buffered = null; if (this._pfk) { const k2 = this._pfk; this._pfk = null; this.startAttack(k2); } else this.startAttackInput(b); return; }
      if (p.attackT <= 0) {
        p.attackPhase = 'none'; p.buffered = null; p.comboTimer = 0.9;
        if (move.finisher || p.moveKey === 'FOCUS' || p.moveKey === 'NH' || p.moveKey === 'NHL' || p.moveKey === 'LLH' || p.moveKey === 'KLLL') { p.comboStr = ''; p.katanaPlan = 0; }
        if (p.moveKey === 'NLLLL' && p.buffered === 'L') { /* allow the 5th hit: keep the chain alive one more input */ p.comboStr = 'NLLLL'; }
        if (move.katana) { p.sheatheT = 0.45; if (move.id === 'k_iaijutsu') { this.sfx.sheathe(); this.slow(0.25, 0.3); }
          if (this.v2 && move.id === 'k_sheatheflash') {
            // CLACK! bilah masuk sarung — sheen maksimal, ring putih, slow-mo sekejap
            this.katana.sheen = 0.35; this.particles.ring(p.x, p.y - 6, 5, 24, '#ffffff', 0.28, 1);
            this.sfx.sheathe(); this.slow(0.12, 0.25); this.shake(0.5);
          } }
      }
    }
  }

  /** World position of the striking limb for the current frame of the current move (from the real animated skeleton). */
  /** current blade segment in world space (hand -> tip) for a katana move */
  bladeSeg(move: Move, second = false): { base: Vec; tip: Vec } {
    const p = this.player;
    const sk = solvePose(this.playerStickOpts(move.pose, this.attackPoseT()));
    const hand = second ? { x: p.x + sk.bhand.x, y: p.y + sk.bhand.y - p.z } : { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
    const len = move.bat ? BAT_LEN : move.axe ? AXE_LEN : move.dual ? DUAL_LEN : this.katana.len;
    const ang = second ? p.bladeB : p.bladeA;
    const lift = move.slash?.lift ?? 0;
    return { base: hand, tip: { x: hand.x + Math.cos(ang) * len, y: hand.y + Math.sin(ang) * len * 0.6 - lift * 10 } };
  }
  strikePoint(move: Move): { pt: Vec; r: number; seg?: { base: Vec; tip: Vec }; seg2?: { base: Vec; tip: Vec } } | null {
    const p = this.player;
    if (move.limb === 'blade' || move.limb === 'blade2') {
      const b = this.bladeSeg(move);
      return { pt: { x: (b.base.x + b.tip.x * 2) / 3, y: (b.base.y + b.tip.y * 2) / 3 }, r: move.hitR, seg: b, seg2: move.limb === 'blade2' ? this.bladeSeg(move, true) : undefined };
    }
    if (move.limb === 'yoyo') {
      const pt = { ...this.yoyoV2.position };
      const orbit = move.id === 'y_orbit' || move.id === 'y_storm' || move.id === 'y_flare';
      return { pt, r: move.hitR, seg: orbit ? { base: { ...this.yoyoV2.hand }, tip: pt } : undefined };
    }
    if (move.limb === 'nunchaku') {
      const tip = this.nunchaku.tip();
      const mid = this.nunchaku.farMid();
      // hitbox covers the far stick: point between its middle and tip
      return { pt: { x: (tip.x + mid.x) / 2, y: (tip.y + mid.y) / 2 }, r: move.hitR + this.stats.meleeRange * 1.5 - 1.5 };
    }
    const sk = solvePose(this.playerStickOpts(move.pose, this.attackPoseT()));
    const lift = p.z;
    const at = (v: Vec): Vec => ({ x: p.x + v.x, y: p.y + v.y - lift });
    if (move.id === 'chain') return { pt: at(p.chainSide < 0 ? sk.bhand : sk.fhand), r: move.hitR };
    switch (move.limb) {
      case 'fhand': return { pt: at(sk.fhand), r: move.hitR };
      case 'bhand': return { pt: at(sk.bhand), r: move.hitR };
      case 'ffoot': return { pt: at(sk.ffoot), r: move.hitR };
      case 'bfoot': return { pt: at(sk.bfoot), r: move.hitR };
      case 'both': { const a = at(sk.fhand), b = at(sk.bhand); return { pt: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, r: move.hitR + 1.5 }; }
      case 'sweep': return { pt: at(sk.ffoot), r: move.hitR + 1 };
      default: return { pt: { x: p.x, y: p.y - 6 }, r: move.hitR + 4 };
    }
  }

  /** distance from point c to segment ab */
  segDist(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
    const dx = bx - ax, dy = by - ay;
    const l2 = dx * dx + dy * dy;
    let t = l2 > 0 ? ((cx - ax) * dx + (cy - ay) * dy) / l2 : 0;
    t = clamp(t, 0, 1);
    return Math.hypot(cx - (ax + dx * t), cy - (ay + dy * t));
  }

  /**
   * Hit resolution that matches what you see: the limb (fist / foot / nunchaku stick) carrying the move is sampled
   * from the animated skeleton every frame; the segment it swept since the previous frame is tested against enemy
   * bodies. No more "hit from 20px away before the arm is extended".
   */
  resolveMelee(move: Move) {
    const p = this.player;
    const sp = this.strikePoint(move);
    if (!sp) return;
    const cur = sp.pt;
    const prev = p.prevLimb ?? cur;
    p.prevLimb = cur;
    const prevBladeThisFrame = this.prevBlade;
    if (sp.seg) this.prevBlade = { base: { ...sp.seg.base }, tip: { ...sp.seg.tip } };
    // the strike only counts during the impact window of the animation (the snap + settle part)
    const pt = this.attackPoseT();
    const wide = move.limb === 'nunchaku' || move.limb === 'yoyo' || move.limb === 'blade' || move.rehit || move.id === 'spinback' || move.id === 'sweep' || move.id === 'axekick' || move.id === 'dragontail' || move.id === 'monkeyflip';
    const spin360 = move.id === 'spinback' || move.id === 'dragontail' || move.id === 'sweep';
    const impactWindow = move.id === 'chain' ? pt >= 0.08 && pt <= 0.6 : move.id === 'ragekill' ? pt >= 0.2 : spin360 ? pt >= 0.2 && pt <= 0.8 : wide ? pt >= 0.3 && pt <= 0.72 : pt >= 0.33 && pt <= 0.62;
    if (!impactWindow && !move.travel) return;
    let footSweep: { from: { front: Vec; back: Vec }; to: { front: Vec; back: Vec } } | null = null;
    if (move.yoyo && (move.pose === 'y2_windmill' || move.pose === 'y2_spin' || move.pose === 'y2_freeze' || move.pose === 'y2_airflip')) {
      const sk = solvePose(this.playerStickOpts(move.pose, pt));
      const feet = { front: { x: p.x + sk.ffoot.x, y: p.y + sk.ffoot.y - p.z }, back: { x: p.x + sk.bfoot.x, y: p.y + sk.bfoot.y - p.z } };
      footSweep = { from: this.yoyoFeet ?? feet, to: feet };
      this.yoyoFeet = feet;
    }
    // very short moves (elbow / knee / uppercut) also count a tight body-contact zone in front of the chest,
    // because the striking joint stays close to the torso by design
    // travelling strikes (flying kicks, running straight, dive kick) carry the whole body: a contact zone just ahead
    // of the chest counts too, since the character is physically crashing into the target
    const contact = move.id === 'elbow' || move.id === 'knee' || move.id === 'dragon' ? { x: p.x + Math.cos(p.aim) * 7, y: p.y - 5 - p.z + Math.sin(p.aim) * 4, r: 6 }
      : move.travel || move.id === 'k_thrust' ? { x: p.x + Math.cos(p.aim) * 9, y: p.y - 5 - p.z * 0.5 + Math.sin(p.aim) * 5, r: 7 } : null;
    const reach = move.range * this.stats.meleeRange + 6; // sanity cap from the body (prevents long-chain exploits)
    const now = this.time;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      if (!move.rehit && p.hitSet.includes(e.id)) continue;
      if (move.rehit && now - (p.hitTimes[e.id] ?? -9) < move.rehit) continue;
      const ex = e.x, ey = e.y - 5 - e.z; // body centre (chest height)
      const bodyR = e.r + 1.0;
      // body-shaped target: a continuous vertical capsule from the feet to the top of the head
      const top = e.y - 13 * e.scale - e.z, bottom = e.y + 1 - e.z;
      let dmin = 1e9;
      for (let k = 0; k <= 4; k++) { const yy = top + ((bottom - top) * k) / 4; dmin = Math.min(dmin, this.segDist(prev.x, prev.y, cur.x, cur.y, e.x, yy)); }
      let near = dmin <= sp.r + bodyR;
      let impactAt = cur;
      if (!near && sp.seg && (this.prevBlade || sp.seg)) {
        const oldBlade = prevBladeThisFrame ?? sp.seg;
        // the blade swept the area between its previous and current segment: sample a few blade points along both
        for (let k = 0; k <= 4 && !near; k++) {
          const f = k / 4;
          const ax = oldBlade.base.x + (oldBlade.tip.x - oldBlade.base.x) * f, ay = oldBlade.base.y + (oldBlade.tip.y - oldBlade.base.y) * f;
          const bx = sp.seg.base.x + (sp.seg.tip.x - sp.seg.base.x) * f, by = sp.seg.base.y + (sp.seg.tip.y - sp.seg.base.y) * f;
          for (let q = 0; q <= 4; q++) { const yy = top + ((bottom - top) * q) / 4; if (this.segDist(ax, ay, bx, by, e.x, yy) <= sp.r + bodyR) { near = true; break; } }
        }
        // also the blade itself as a segment this frame
        if (!near) for (let q = 0; q <= 4; q++) { const yy = top + ((bottom - top) * q) / 4; if (this.segDist(sp.seg.base.x, sp.seg.base.y, sp.seg.tip.x, sp.seg.tip.y, e.x, yy) <= sp.r + bodyR) { near = true; break; } }
      }
      if (!near && sp.seg2) for (let q = 0; q <= 4; q++) { const yy = top + ((bottom - top) * q) / 4; if (this.segDist(sp.seg2.base.x, sp.seg2.base.y, sp.seg2.tip.x, sp.seg2.tip.y, e.x, yy) <= sp.r + bodyR) { near = true; break; } }
      if (!near && footSweep) {
        for (const foot of ['front', 'back'] as const) {
          for (let q = 0; q <= 4; q++) {
            const yy = top + ((bottom - top) * q) / 4;
            if (this.segDist(footSweep.from[foot].x, footSweep.from[foot].y, footSweep.to[foot].x, footSweep.to[foot].y, e.x, yy) <= bodyR + 3) {
              near = true; impactAt = footSweep.to[foot]; break;
            }
          }
          if (near) break;
        }
      }
      if (!near && contact && dist(contact.x, contact.y, ex, ey) <= contact.r + bodyR) near = true;
      if (!near) continue;
      if (dist(p.x, p.y, e.x, e.y) > reach + e.r + (move.limb === 'nunchaku' ? 10 : move.limb === 'blade' ? 8 : 0)) continue;
      const a = Math.atan2(e.y - p.y, e.x - p.x);
      if (!move.yoyo || !p.hitSet.includes(e.id)) p.hitSet.push(e.id);
      p.hitTimes[e.id] = now;
      this.meleeHitEnemy(e, move, a, impactAt);
      if (p.attackPhase !== 'active' || this.clashDuel || this.silat) return;
    }
    for (const pr of this.props) {
      if (pr.dead) continue;
      const key = -1000 - this.props.indexOf(pr);
      if (p.hitSet.includes(key)) continue;
      if (this.segDist(prev.x, prev.y, cur.x, cur.y, pr.x, pr.y - 4) > sp.r + pr.r) continue;
      p.hitSet.push(key);
      this.damageProp(pr, move.dmg, Math.atan2(pr.y - p.y, pr.x - p.x));
      this.hitstop = Math.max(this.hitstop, 0.02);
    }
    for (const b of this.bullets) {
      if (b.owner !== 'enemy' || b.kind === 'bomb') continue;
      if (this.segDist(prev.x, prev.y, cur.x, cur.y, b.x, b.y) > sp.r + 3) continue;
      this.deflectBullet(b, p.aim);
    }
  }

  /** StickOpts for the player as drawn this frame (shared by the renderer and the hit tester) */
  playerStickOpts(pose: Pose, t: number): import('./stick').StickOpts {
    const p = this.player;
    const runBlend = clamp(p.runT / 0.2, 0, 1);
    const moving = p.moving && (pose === 'idle' || pose === 'run' || pose === 'shoot' || pose === 'n_idle' || pose === 'y2_idle' || pose === 'k_idle' || pose === 'a_idle' || pose === 'd_idle');
    const so: import('./stick').StickOpts = {
      x: p.x, y: p.y, c: PLAYER_COLOR, c2: PLAYER_BAND, scale: 1, facing: p.facing, aim: pose === 'run' || pose === 'idle' || pose === 'n_idle' ? p.bodyAim : p.aim, look: p.aim, walk: p.walk, moving,
      pose, t, acc: 'headband', weapon: !this.parryCounterKey && (p.weapon === 'pistol' || p.weapon === 'rifle') ? p.weapon : 'none', flash: p.flash > 0, alpha: 1, outline: '#000000', eyes: '#111111', time: this.time, lean: p.lean,
      z: p.z, recoil: p.recoil, run: runBlend, squash: p.squash, vel: this.moveDirOf(p.vx + p.kx * 0.3, p.vy + p.ky * 0.3), stride: p.strideHalf, chainSide: p.chainSide,
      anime: this.v2, brake: this.v2 ? clamp(p.brakeT / 0.35, 0, 1) : 0,
      limbScale: this.longMode ? 2.5 : 1,
      dancePhase: p.weapon === 'yoyo' && (this.yoyoVer === 2 || this.parryCounterKey) ? this.yoyoV2.spin : undefined,
      ysub: this.yoyo.sub, ysign: this.yoyo.sign,
      tka: p.weapon === 'hayabusa' ? this.hay.bladeA : this.tak.bladeA, tkp: p.weapon === 'hayabusa' ? this.hay.ext : (this.tak.mode === 'charge' ? this.tak.chargeLevel : this.tak.ext), tkh: p.weapon === 'hayabusa' ? this.hay.hop : this.tak.hop,
    };
    // takamura locks body + facing to the cut direction while an iai move is running
    if (!this.parryCounterKey && p.weapon === 'takamura' && this.tak.lockAim !== null) { so.aim = this.tak.lockAim; so.look = this.tak.lockAim; so.facing = Math.cos(this.tak.lockAim) >= 0 ? 1 : -1; }
    if (!this.parryCounterKey && p.weapon === 'hayabusa' && this.hay.lockAim !== null) { so.aim = this.hay.lockAim; so.look = this.hay.lockAim; so.facing = Math.cos(this.hay.lockAim) >= 0 ? 1 : -1; }
    return so;
  }

  deflectBullet(b: Bullet, dir: number) {
    const sp = Math.hypot(b.vx, b.vy) * 1.5 + 80;
    b.owner = 'player'; b.vx = Math.cos(dir) * sp; b.vy = Math.sin(dir) * sp; b.dmg = Math.max(4, b.dmg * 3); b.color = this.pal.accent; b.kind = 'deflect'; b.life = 1.5; b.hitIds = []; b.pierce = 1; b.kb = 200;
    this.sfx.parry();
    this.particles.spark(b.x, b.y, 6, '#ffffff', dir, 0.6, 200);
    this.particles.impact(b.x, b.y, 5, '#9be7ff');
    this.texts.add(b.x, b.y - 10, 'DEFLECT!', '#35f0ff', 1, 0.5);
    this.hitstop = Math.max(this.hitstop, 0.04);
    this.player.focus = Math.min(300, this.player.focus + 15 * this.stats.focusGain);
    this.addCombo();
  }

  meleeHitEnemy(e: Enemy, move: Move, a: number, at?: Vec) {
    if (this.isAttractMode) { this.previewContact(e); return; }
    if (this.clashDuel || this.pendingRiposte || !this.hasLOS(e)) return;
    const p = this.player;
    const heavy = !['jab', 'cross', 'hook', 'n_lash', 'n_cross', 'n_figure8', 'n_helicopter', 'y_free', 'y_ret'].includes(move.id);
    // impact FX exactly at the limb contact point (clamped onto the body surface)
    let hx = e.x - Math.cos(a) * e.r, hy = e.y - e.z - 6 - Math.sin(a) * e.r;
    if (at) { const ddx = at.x - e.x, ddy = at.y - (e.y - e.z - 5); const dl = Math.hypot(ddx, ddy) || 1; const cl = Math.min(dl, e.r + 1); hx = e.x + (ddx / dl) * cl; hy = e.y - e.z - 5 + (ddy / dl) * cl; }
    if (e.kind === 'shield' && e.stagger <= 0 && e.down <= 0 && e.z <= 0 && !heavy && Math.abs(angleDiff(Math.atan2(p.y - e.y, p.x - e.x), e.aim)) < 1.3) {
      this.particles.spark(hx, hy, 8, '#ffffff', a + Math.PI, 0.8, 180);
      this.particles.impact(hx, hy, 4, '#cccccc');
      this.sfx.hit();
      e.structure += move.structure * 0.6 * this.stats.structureDmg;
      e.flash = 0.05;
      this.texts.add(e.x, e.y - 20, 'BLOCKED', '#cccccc', 1, 0.4);
      this.hitstop = Math.max(this.hitstop, 0.03);
      p.kx -= Math.cos(a) * 70; p.ky -= Math.sin(a) * 70;
      if (e.structure >= e.maxStructure) this.staggerEnemy(e);
      return;
    }
    e.playerSpamCount = (e.playerSpamCount ?? 0) + 1;
    if (!p.airborne && p.z <= 4 && (e.attackPhase === 'windup' || e.attackPhase === 'active') && e.stun <= 0 && (e.counterLockT ?? 0) <= 0 && e.stagger <= 0 && e.down <= 0 && e.z <= 0) {
      if (this.clashCd <= 0 && ((e.rallyStreak ?? 0) >= 2 || Math.random() < 0.55)) {
        this.startClash(e);
        return;
      }
      this.mutualClashDeflect(e, a);
      return;
    }
    const smartParryChance = 0.26 + Math.min(0.4, (e.playerSpamCount ?? 0) * 0.09);
    if (e.canParry && (e.counterLockT ?? 0) <= 0 && e.parryCd <= 0 && e.stagger <= 0 && e.down <= 0 && e.stun <= 0 && e.z <= 0 && (!e.attackPhase || e.attackPhase === 'none' || e.attackPhase === 'recover' || (e.parryT ?? 0) > 0) && ((e.parryT ?? 0) > 0 || Math.random() < smartParryChance)) {
      this.bossParryPlayer(e, hx, hy, a);
      return;
    }
    if (move.id === 'k_iaijutsu' && !e.boss && e.doom <= 0) {
      // the cut is already fatal: freeze them until the sheathe, then they fall (classic iai)
      e.doom = 0.55 + 0.08 * p.iaiVictims.length; e.state = 'doom'; e.kx = e.ky = 0; e.flash = 0.1; e.token = false;
      p.iaiVictims.push(e.id);
      this.particles.lines(hx, hy, 3, '#ffffff', p.aim + Math.PI / 2, 80); this.particles.lines(hx, hy, 3, '#ffffff', p.aim - Math.PI / 2, 80);
      this.particles.impact(hx, hy, 5, '#bfe8ff');
      this.sfx.slash(1.3);
      this.addCombo();
      return;
    }
    let dmg = move.dmg * this.stats.meleeDmg * this.ageDmg() * (1 + Math.min(0.6, this.combo * this.stats.berserk)) * (1 + 0.5 * p.styleHeat);
    if (e.stagger > 0) dmg *= 2; else if (e.down > 0) dmg *= 1.5;
    if (e.z > 0) dmg *= 1.25; // juggle bonus
    const kb = move.kb * 0.45 * this.stats.knockback * (heavy ? 1 : 0.6);
    const wasAlive = !e.dead;
    const launch = move.launch ? move.launch * 0.6 * (1 - e.kbRes * 0.6) : 0;
    this.damageEnemy(e, dmg, move.structure * this.stats.structureDmg, a, kb, { knockdown: move.knockdown, hitstop: move.hitstop, shake: move.shake, melee: true, launch });
    this.particles.spark(hx, hy, 5 + (heavy ? 5 : 0), '#ffffff', a, 0.9, 200 + kb * 0.2);
    this.particles.blood(hx, hy, 3 + Math.floor(dmg * 0.8), a, 100 + kb * 0.3);
    this.blood.spray(hx, hy, a, dmg, heavy);
    if (heavy) this.stamp(e.x + rnd(-3, 3), e.y + rnd(-1, 2), '#8a0000', 1);
    this.particles.impact(hx, hy, heavy ? 8 : 5, '#ffffff');
    if (move.showName && p.hitSet.length === 1) this.say(move.name, this.pal.accent2, move.finisher ? 2 : 1, move.finisher ? 0.8 : 0.6);
    if (e.z > 0 && wasAlive) this.say('JUGGLE!', '#ffe66d', 1, 0.5);
    this.sfx.hit();
    if (move.sfx === 'punch') this.sfx.punch(); else if (move.sfx === 'kick') this.sfx.kick(); else if (move.sfx === 'nunchaku') { this.sfx.nunchakuHit(heavy); } else if (move.sfx === 'yoyo') { this.sfx.yoyoHit(!!move.finisher); this.yoyoV2.impact(); this.particles.ring(hx, hy, 3, move.finisher ? 16 : 10, this.yoyoV2.skin.aura, 0.18, 1); this.particles.spark(hx, hy, 4, this.yoyoV2.skin.spark, a, 1.2, 140); } else if (move.sfx === 'slash') { this.sfx.slashHit(heavy); } else if (move.sfx === 'axe') { this.sfx.axeHit(heavy); this.sfx.batCrack(); if (move.id === 'a_homerun' || move.id === 'a_grandslam' || move.id === 'b_homerun' || move.id === 'b_grandslam') { this.slow(0.25, 0.25); this.flash('#ffffff', 0.18); this.zoomKick = 0.1; this.say(move.id === 'b_grandslam' || move.id === 'a_grandslam' ? 'GRAND SLAM!' : 'HOME RUN!', '#ffe66d', 3, 1.0); } } else if (move.sfx === 'dual') { this.sfx.dualHit(); } else this.sfx.heavy();
    if (move.bleed && !e.dead) { e.bleed = Math.min(6, e.bleed + (heavy ? 3 : 2)); if (e.bleedT <= 0) e.bleedT = 0.3; }
    if (move.bat) {
      this.particles.ring(hx, hy, 2, heavy ? 16 : 11, '#ffffff', 0.16, 1);
      this.particles.spark(hx, hy, heavy ? 10 : 6, '#fff3a0', a, 0.9, 300);
      this.particles.burst(hx, hy, 3, '#e6b877', 120, 0.4, 1, 3);
      this.wallHits.push({ x: hx, y: hy, a: a + Math.PI, t: 0.09 });
      if (move.id === 'b_spike' && !e.dead) { e.vz = -320; this.particles.shockwave(e.x, e.y, 22, '#ffffff', 0.3); this.say('METEOR SPIKE!', '#ff6a4a', 2, 0.9); this.slow(0.15, 0.3); this.flash('#ffffff', 0.12); }
      if (move.id === 'b_behind' || move.id === 'b_heli') this.zoomKick = Math.max(this.zoomKick, 0.04);
      this.batSpamHit();
      if (Math.random() < 0.4 || move.id === 'sb_smash' || move.id === 'sb_pound') {
        const words = ['BONK!', 'WHAM!', 'CRACK!', 'THWACK!', 'POW!', 'SMACK!'];
        this.texts.add(e.x + rnd(-6, 6), e.y - 24 - e.z, move.id === 'sb_pound' ? 'CURB!' : words[Math.floor(Math.random() * words.length)], Math.random() < 0.5 ? '#ffd27f' : '#ffffff', 1, 0.45);
      }
    }
    if ((move.sfx === 'slash' || move.sfx === 'dual' || move.sfx === 'axe') && !e.dead && !move.bat) {
      // a clean cut line across the body
      const ca = p.bladeA + Math.PI / 2;
      this.particles.lines(hx, hy, 2, '#ffffff', ca, 60); this.particles.lines(hx, hy, 2, '#ffffff', ca + Math.PI, 60);
      this.particles.blood(hx, hy, 6, p.bladeA + Math.PI / 2, 90);
    }
    p.focus = Math.min(300, p.focus + 7 * this.stats.focusGain);
    this.addOfa(dmg * 0.1);
    this.addCombo();
    this.meleeHits++;
    if (p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat') { if (this.time - this.fistHitT > 2) this.fistHits = 0; this.fistHits++; this.fistHitT = this.time; }
    if ((move.id === 'chain' || p.style !== 'none') && !p.rageOn) { p.rage = Math.min(100, p.rage + (move.id === 'chain' ? 2.2 : move.finisher ? 5 : 3)); if (p.rage >= 100 && !this.rageReadySaid) { this.rageReadySaid = true; this.say('RAGE READY - PRESS R', '#ff2a2a', 2, 1.4); this.sfx.select(); } }
    if (move.id === 'chainend') { p.rage = Math.min(100, p.rage + 10); this.slow(0.2, 0.3); }
    if (move.id === 'ragekill') {
      p.rageKills++;
      this.flash('#ff2a2a', 0.15); this.zoomKick = 0.06;
      if (!e.dead && !e.boss) this.killEnemy(e, a, 700, false, true);
      else if (!e.dead && e.boss) this.damageEnemy(e, e.maxHp * 0.08, 60, a, 300, { knockdown: true, hitstop: 0.08, shake: 0.6, melee: true });
      if (p.rageKills % 3 === 0) this.heal(1);
    }
    if (move.travel) p.travelHit = true;
    if (move.finisher) this.zoomKick = Math.max(this.zoomKick, 0.04);
    if (move.id === 'n_dragonlash' && p.hitSet.length === 1) {
      // detonation: the chain whips around the first target and blasts everyone nearby
      this.particles.shockwave(e.x, e.y - 4, 44, this.pal.accent, 0.35);
      this.particles.impact(hx, hy, 12, '#ffffff');
      this.flash('#ffffff', 0.2); this.slow(0.2, 0.3);
      this.sfx.explosion();
      for (const o of this.enemies) {
        if (o === e || o.dead || o.spawnT > 0 || dist(o.x, o.y, e.x, e.y) > 44 + o.r) continue;
        p.hitSet.push(o.id);
        this.damageEnemy(o, move.dmg * 0.6 * this.stats.meleeDmg, 40, Math.atan2(o.y - e.y, o.x - e.x), 420, { knockdown: true, hitstop: 0.02, shake: 0.2, melee: true, launch: 90 });
      }
    }
    if (this.stats.lifesteal > 0 && this.meleeHits % Math.max(10, 25 - this.stats.lifesteal * 5) === 0) this.heal(1);
    if (this.stats.shockwave > 0 && move.finisher && wasAlive) this.shockwaveHit(e.x, e.y, 34, dmg * 0.6, e.id);
  }

  shockwaveHit(x: number, y: number, r: number, dmg: number, excludeId: number) {
    this.particles.shockwave(x, y - 4, r, this.pal.accent, 0.3);
    this.sfx.heavy();
    for (const e of this.enemies) {
      if (e.dead || e.id === excludeId || e.spawnT > 0) continue;
      const d = dist(x, y, e.x, e.y);
      if (d > r + e.r) continue;
      this.damageEnemy(e, dmg, 20, Math.atan2(e.y - y, e.x - x), 200, { knockdown: true, hitstop: 0.02, shake: 0.1, melee: false });
    }
  }

  heal(n: number) {
    const p = this.player;
    const before = p.hp;
    p.hp = Math.min(this.maxHp(), p.hp + n);
    if (p.hp > before) { this.texts.add(p.x, p.y - 26, `+${p.hp - before} HP`, '#ff6b6b', 1, 0.8); this.particles.burst(p.x, p.y - 8, 8, '#ff6b6b', 50, 0.5); }
  }

  staggerEnemy(e: Enemy) {
    this.cancelBossAttack(e);
    e.stagger = e.boss ? 1.8 : 2.6; e.state = 'stagger'; e.down = 0; e.stun = 0; e.kx *= 0.4; e.ky *= 0.4; e.fuse = -1;
    if (this.v2) { e.sqx = 1.25; e.sqy = 0.75; }
    this.sfx.stagger();
    this.particles.ring(e.x, e.y - 8, 2, 18, '#ffd700', 0.3, 1);
    if (this.finishCd <= 0 && dist(e.x, e.y, this.player.x, this.player.y) < 90) { this.finishCd = 4; this.sfx.announce(); }
  }

  damageEnemy(e: Enemy, dmg: number, structure: number, dir: number, kb: number, o: { knockdown?: boolean; hitstop?: number; shake?: number; melee?: boolean; launch?: number }) {
    if (this.isAttractMode || this.clashDuel) return;
    if (e.dead || e.spawnT > 0) return;
    e.hp -= dmg;
    e.flash = 0.1;
    e.flinch = 0.12;
    if (this.v2) { e.sqx = 1.35; e.sqy = 0.65; }        // juicy impact squeeze, game1 style
    e.structure += structure;
    const kbMul = (1 - e.kbRes) * (1 - e.kbRes * 0.5) * (e.stagger > 0 ? 1.25 : 1) * (e.z > 0 ? 0.6 : 1);
    e.kx += Math.cos(dir) * kb * kbMul; e.ky += Math.sin(dir) * kb * kbMul;
    this.hitstop = Math.max(this.hitstop, o.hitstop ?? 0.02);
    this.shake(o.shake ?? 0.1);
    if (e.hp <= 0) { this.killEnemy(e, dir, kb + dmg * 20, false, !!o.melee, e.z > 0 || (o.launch ?? 0) > 0); return; }
    if (o.launch || o.knockdown) this.cancelBossAttack(e);
    if (o.launch && o.launch > 0 && !e.armor) {
      // real launchers (uppercut, taekwondo kick, crane, monkey flip, focus) always lift; small pops need a softened target
      const softened = e.structure >= e.maxStructure * 0.35 || e.hp <= e.maxHp * 0.55 || e.stagger > 0 || o.launch >= 50;
      if (!softened) { e.stun = Math.max(e.stun, 0.3); e.state = 'stun'; e.kx *= 0.5; e.ky *= 0.5; return; }
      e.vz = Math.max(e.vz, o.launch); e.z = Math.max(e.z, 0.1); e.down = 0; e.stun = 0; e.state = 'air'; e.pose = 'launched'; e.fuse = -1;
      if (this.v2) { e.sqx = 0.8; e.sqy = 1.25; }       // stretch while flying
      this.sfx.launch();
      return;
    }
    if (e.z > 0) { e.vz += 70; return; }
    if (e.structure >= e.maxStructure && e.stagger <= 0) { this.staggerEnemy(e); return; }
    if (e.stagger > 0) return;
    if (o.knockdown && !e.armor) {
      if (e.boss && Math.random() < 0.6) { e.stun = Math.max(e.stun, 0.25); e.state = 'stun'; return; }
      // tough enemies only go down once softened up: enough structure damage, low hp, or an elite's luck
      const softened = e.structure >= e.maxStructure * 0.4 || e.hp <= e.maxHp * 0.5 || e.stagger > 0;
      if (!softened && !(o.launch && o.launch > 0)) { e.stun = Math.max(e.stun, 0.3); e.state = 'stun'; return; }
      e.down = e.boss ? 0.7 : 1.0; e.state = 'down'; e.fuse = -1; return;
    }
    if (!e.armor && o.melee && e.down <= 0) {
      const committed = (e.state === 'windup' && e.stateT < 0.12) || e.state === 'attack' || e.state === 'lunge';
      const poise = e.boss ? 0.7 : e.elite ? 0.45 : e.kind === 'monk' ? 0.25 : 0;
      if (!committed && Math.random() >= poise) { e.stun = Math.max(e.stun, 0.16); e.state = 'stun'; }
    }
  }

  enemyLand(e: Enemy, impact = 0) {
    // V2 (game1 feel): a body that slams into the floor springs back up once before it goes down.
    // Self-limiting: the rebound is only ~34% of the impact, so the next landing is always below the threshold.
    if (this.v2 && impact > 260 && !e.dead) {
      e.vz = impact * 0.34; e.z = 0.1;
      e.sqx = 1.3; e.sqy = 0.7;
      this.particles.smoke(e.x, e.y, 8, '#777', 50, 0.5);
      this.particles.burst(e.x, e.y, 8, this.pal.wallTop, 110, 0.4);
      this.splat(e.x, e.y, 6);
      this.shake(0.4); this.sfx.land();
      this.texts.add(e.x, e.y - 20, 'THUD!', '#ffffff', 1, 0.45);
      return;
    }
    if (this.v2) {
      e.sqx = 1.45; e.sqy = 0.55;        // hard landing pancake, game1 style
      // V2: ragdoll rebah yang BERVARIASI seperti game1, bukan satu pose papan yang sama terus
      const lat = Math.hypot(e.kx, e.ky);
      const r = Math.random();
      e.fall = lat > 60 ? (r < 0.5 ? 'knock' : 'curled') : r < 0.45 ? 'broken' : r < 0.8 ? 'knock' : 'curled';
      e.fallFlip = Math.random() < 0.4 ? -1 : 1;
    }
    this.particles.smoke(e.x, e.y, 6, '#888', 30, 0.45);
    this.particles.burst(e.x, e.y, 6, this.pal.wallTop, 80, 0.4);
    this.particles.blood(e.x, e.y - 3, 10, rnd(0, 6.3), 90);
    this.splat(e.x, e.y, 8);
    this.sfx.land();
    this.shake(0.2);
    if (e.dead) return;
    if (e.structure >= e.maxStructure && e.stagger <= 0) this.staggerEnemy(e);
    if (e.stagger > 0) { e.state = 'stagger'; e.pose = 'stagger'; return; }
    e.down = e.boss ? 0.6 : 1.0; e.state = 'down'; e.pose = 'down';
    e.hp -= 1;
    if (e.hp <= 0) this.killEnemy(e, Math.atan2(e.ky, e.kx), 150, false, true);
  }

  killEnemy(e: Enemy, dir: number, power: number, silent = false, melee = false, airborne = false) {
    if (e.dead) return;
    e.dead = true;
    this.kills++;
    this.addOfa(e.boss ? 15 : 7);
    this.score += Math.round(e.value * this.comboMult());
    const gy = e.y - 6 - e.z;
    // blood: classic particles (normal/combined) + the new gore emitters (gore/combined)
    this.particles.blood(e.x, gy, 8 + Math.min(10, power / 30), dir, 110 + power * 0.4);
    this.blood.spray(e.x, gy, dir, 3 + Math.min(4, power / 100), true);
    this.particles.ring(e.x, gy, 3, 14, '#ffffff', 0.18, 1);
    this.splat(e.x, e.y, 6 + Math.floor(e.scale * 2));
    this.addPool(e.x, e.y + 1, 4 + e.scale);
    // RAGDOLL: the body is flung along the hit direction, tumbling in the air, bouncing when it lands
    if (this.corpses.length > 80) this.corpses.shift();
    // V2 uses game1's launch recipe: inherit fast momentum, else a capped toss + a 125-220 hop,
    // so bodies tumble a funny short arc instead of rocketing across the arena
    const cur = Math.hypot(e.vx, e.vy);
    // game1: a body inherits the victim's OWN momentum when it was already moving (a walking enemy
    // drops with a funny hop nearby); only already-launched victims rocket away
    const useOwn = this.v2 && cur > 70;
    const fling = useOwn ? cur * 1.05 : this.v2 ? Math.min(430, 110 + power * 0.85) : Math.min(520, 120 + power * 0.9);
    const lang = useOwn ? Math.atan2(e.vy, e.vx) : dir;
    const up = this.v2 ? Math.max(e.vz, e.z > 1 ? e.vz : 125 + Math.random() * 95) : airborne ? Math.max(e.vz, 120) : Math.min(260, 60 + power * 0.35);
    this.corpses.push({
      x: e.x, y: e.y, rot: dir + (Math.random() < 0.5 ? 0.3 : -0.3), color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory,
      vx: Math.cos(lang) * fling, vy: Math.sin(lang) * fling * 0.75, spin: this.v2 ? 11 * (Math.cos(lang) >= 0 ? 1 : -1) * (0.7 + Math.random() * 0.6) : rnd(6, 14) * (Math.random() < 0.5 ? 1 : -1), t: 0, z: Math.max(e.z, 1), vz: up, gib: false, bounces: 0,
      face: Math.cos(lang) >= 0 ? 1 : -1,
      sqx: 0.8, sqy: 1.3,
    });
    if (!silent) { this.sfx.kill(); this.shake(0.3 + Math.min(0.4, power / 900)); this.hitstop = Math.max(this.hitstop, 0.045); }
    if (e.kind === 'bomber') this.pendingBooms.push({ x: e.x, y: e.y, t: 0.05, r: 30, dmg: 2, fromPlayer: true });
    this.dropLoot(e, melee);
    this.addCombo();
    if (e.boss) {
      this.slow(1.4, 0.2);
      this.flash('#ffffff', 0.6);
      this.shake(1);
      this.say('BOSS DEFEATED!', '#ffd700', 3, 2.2);
      this.deathCounter = 1;
      this.score += 500;
      for (let i = 0; i < 3; i++) this.particles.shockwave(e.x, e.y - 6, 60 + i * 30, this.pal.accent, 0.6 + i * 0.2);
      this.bossBeatenT = 2;
      for (const o of this.enemies) if (!o.dead && o !== e) this.killEnemy(o, Math.atan2(o.y - e.y, o.x - e.x), 200, true);
    } else if (melee && this.combo >= 3) this.slow(0.1, 0.35);
  }

  gibAt(x: number, y: number, color: string, scale: number, dir = 0, power = 1) {
    this.particles.blood(x, y - 6, 30, dir, 170 * power);
    this.particles.blood(x, y - 6, 16, rnd(0, 6.3), 100 * power);
    this.particles.fountain(x, y - 6, 8);
    this.blood.spray(x, y - 6, dir, 5 * power, true); this.blood.arterial(x, y - 6, dir, power * 0.7); this.blood.fountain(x, y - 6, 10); this.blood.gibs(x, y - 6, dir, 200 * power, color, 3);
    for (let i = 0; i < 5; i++) this.particles.limb(x, y - 6, dir + rnd(-1.2, 1.2), 180 * power, color, 3 + scale * 2);
    this.particles.burst(x, y - 6, 12, color, 140, 0.4);
    this.particles.ring(x, y - 6, 3, 20, '#ffffff', 0.2, 1);
    this.particles.impact(x, y - 6, 9, '#ff4040');
    this.splat(x, y, 40);
    this.addPool(x, y + 1, 9 + scale * 3);
    this.sfx.kill(); this.sfx.heavy();
    this.shake(0.6);
  }

  explode(x: number, y: number, r: number, dmg: number, fromPlayer: boolean) {
    this.particles.smoke(x, y, 12, '#555555', 60, 0.7);
    this.particles.burst(x, y, 24, '#ffb347', 180, 0.45, 2, 3);
    this.particles.burst(x, y, 14, '#ffffff', 120, 0.25, 1, 3);
    this.particles.shockwave(x, y, r + 10, '#ffd27f', 0.35);
    this.particles.ember(x, y, 10, '#ff6a00');
    this.sfx.explosion();
    this.shake(0.8);
    this.hitstop = Math.max(this.hitstop, 0.05);
    this.flash('#ffb060', 0.25);
    this.splat(x, y, 16, '#111111');
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = dist(x, y, e.x, e.y);
      if (d > r + e.r) continue;
      this.damageEnemy(e, dmg * 3, 60, Math.atan2(e.y - y, e.x - x), 320, { knockdown: true, hitstop: 0.02, shake: 0.1, melee: false, launch: 120 });
    }
    const p = this.player;
    if (!fromPlayer && dist(x, y, p.x, p.y) < r + p.r) this.damagePlayer(dmg, Math.atan2(p.y - y, p.x - x));
    for (const pr of this.props) {
      if (pr.dead) continue;
      if (dist(x, y, pr.x, pr.y) < r + pr.r) this.damageProp(pr, 10, Math.atan2(pr.y - y, pr.x - x));
    }
  }

  damageProp(pr: Prop, dmg: number, dir: number) {
    if (pr.dead || pr.hp <= 0) return;
    pr.hp -= dmg;
    pr.flash = 0.08;
    this.particles.burst(pr.x, pr.y - 4, 5, pr.kind === 'crate' ? '#b07a3c' : '#c0392b', 90, 0.4);
    this.sfx.hit();
    if (pr.hp <= 0) {
      pr.dead = true;
      if (pr.kind === 'crate') {
        this.particles.burst(pr.x, pr.y - 4, 16, '#b07a3c', 140, 0.6, 2, 3);
        for (let i = 0; i < 3; i++) this.particles.limb(pr.x, pr.y - 4, dir, 120, '#8a5a2b', 4);
        const n = 1 + (Math.random() < 0.5 ? 1 : 0);
        for (let i = 0; i < n; i++) {
          const k: Pickup['kind'][] = ['ammoP', 'ammoP', 'hp', 'focus', this.player.hasRifle ? 'ammoR' : 'ammoP'];
          this.spawnPickup(pr.x, pr.y, k[Math.floor(Math.random() * k.length)]);
        }
        this.sfx.kick();
      } else {
        pr.dead = false;
        pr.flash = 0.5;
        this.pendingBooms.push({ x: pr.x, y: pr.y, t: 0.5, r: 38, dmg: 2, fromPlayer: false });
        this.sfx.beep();
      }
    }
  }

  // ============================== STREET BAT ==============================
  batSpeed() { return 1 + Math.min(0.7, this.batSpam * 0.045); }
  batSpamHit() {
    this.batSpam++; this.batSpamT = 1.4;
    const n = this.batSpam;
    if (n === 15 || n === 30 || n === 50) {
      this.say(n === 15 ? 'STREET FRENZY!' : n === 30 ? 'UNSTOPPABLE!' : 'BAT GOD!', '#ff6a4a', 2, 1.0);
      this.flash('#ffd27f', 0.12); this.shake(0.4); this.slow(0.12, 0.35);
    }
  }
  updateBat(dt: number) {
    const p = this.player;
    if (this.batSpamT > 0) { this.batSpamT -= dt; if (this.batSpamT <= 0) this.batSpam = 0; }
    if (this.batTauntT > 0) this.batTauntT -= dt;
    if (p.weapon !== 'bat') return;
    if (this.input.hit('t') && this.time - this.batEquippedAt > 0.08 && p.attackPhase === 'none' && this.batTauntT <= 0) {
      this.batTauntT = 0.9;
      const T = ['COME ON!', 'BRING IT!', 'WHO NEXT?', 'BATTER UP!'];
      this.say(T[Math.floor(Math.random() * T.length)], '#ffd27f', 1, 0.8);
      p.focus = Math.min(300, p.focus + 30);
      this.sfx.select();
    }
  }

  // ============================== SILAT SCENES (The Raid) ==============================
  silatPending: { id: number; t: number; kind?: string } | null = null;
  /** best victim in front: auto = needs a softened target (staggered / low hp / 6+ fist hits) */
  silatTarget(forced: boolean): Enemy | null {
    const p = this.player;
    let best: Enemy | null = null, bd = 32;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0 || e.z > 1 || e.down > 0) continue;
      const d = dist(e.x, e.y, p.x, p.y) - e.r;
      if (d > bd) continue;
      if (Math.abs(angleDiff(Math.atan2(e.y - p.y, e.x - p.x), p.aim)) > 1.25) continue;
      if (!forced && !(e.stagger > 0 || e.hp <= e.maxHp * 0.35 || (this.fistHits >= (this.player.weapon === 'bat' ? 9 : 7) && this.time - this.fistHitT < 2))) continue;
      bd = d; best = e;
    }
    if (!forced && this.silatCd > 0) return null;
    return best;
  }
  trySilat(target: Enemy | null, forced: boolean, kind?: string, link = false): boolean {
    const p = this.player;
    if (this.silat || p.fatality || p.stunT > 0 || p.airborne || (p.weapon !== 'fist' && p.weapon !== 'nunchaku' && p.weapon !== 'bat') || p.rageDash || p.focusDash) return false;
    const W = p.weapon === 'nunchaku' ? 'nunchaku' : p.weapon === 'bat' ? 'bat' : 'fist';
    const e = target ?? this.silatTarget(forced);
    if (!e) { if (forced && !target) { this.texts.add(p.x, p.y - 22, 'NO GRAB', '#777', 1, 0.4); } return false; }
    if (!link && forced && !target && this.silatCd > 0 && e.stagger <= 0) { this.texts.add(p.x, p.y - 22, `GRAB ${this.silatCd.toFixed(1)}S`, '#777', 1, 0.4); return false; }
    // pick the scene: parry -> arm lock, enemy facing away -> back take, else a random one (never the same twice)
    const behind = Math.cos(e.aim - Math.atan2(e.y - p.y, e.x - p.x)) > 0.3;
    // DOUBLE: a second enemy hugging us -> hit both at once (70%)
    let e2: Enemy | null = null;
    if (!kind) {
      let bd2 = 24;
      for (const o of this.enemies) {
        if (o === e || o.dead || o.spawnT > 0 || o.boss || o.z > 1 || o.down > 0) continue;
        const d2 = dist(o.x, o.y, p.x, p.y) - o.r;
        if (d2 < bd2) { bd2 = d2; e2 = o; }
      }
      if (e2 && Math.random() < 0.7) { const dp = SILAT.filter((s) => s.double && (s.weapon ?? 'fist') === W && s.id !== this.silatLast); kind = dp[Math.floor(Math.random() * dp.length)].id; }
      else e2 = null;
    }
    if (W === 'nunchaku' && kind) kind = kind === 'counter' ? 'n_counter' : kind === 'armbar' ? 'n_triangle' : kind;
    if (W === 'bat' && kind) kind = kind === 'counter' ? 'b_counter' : kind === 'armbar' ? 'b_disarm' : kind;
    let id = kind ?? (behind && Math.random() < 0.7 ? (W === 'nunchaku' ? 'n_choke' : W === 'bat' ? 'b_choke' : 'backtake') : '');
    if (!id) { const pool = SILAT.filter((s) => (s.weapon ?? 'fist') === W && s.id !== this.silatLast && s.id !== 'armbar' && s.id !== 'counter' && s.id !== 'n_counter' && s.id !== 'b_counter' && s.id !== 'b_disarm' && !s.double); id = pool[Math.floor(Math.random() * pool.length)].id; }
    let sc = SILAT.find((s) => s.id === id)!;
    const D = dist(e.x, e.y, p.x, p.y);
    if (link) {
      // acrobatic transition into the next sequence: flip across the gap, land in front of the next victim
      const L = LINK_FLIPS[Math.floor(Math.random() * LINK_FLIPS.length)];
      sc = { ...sc, beats: [{ d: 0.26, pp: L.pp, pt: L.pt, ep: 'hurt', f: 9, step: Math.max(0, D - 9), pz: 16, acro: true, spin: W === 'nunchaku' ? 28 : undefined, name: L.name }, ...sc.beats] };
    }
    this.silatLast = id;
    const dir = Math.atan2(e.y - p.y, e.x - p.x);
    const f0 = link ? D : clamp(D, 6, 14);
    // QUICK takes: half duration — always rolled 40%, 70% when a crowd is around (efficient)
    const crowd = this.enemies.filter((o) => !o.dead && o !== e && o !== e2 && dist(o.x, o.y, p.x, p.y) < 70).length;
    const quick = Math.random() < (crowd >= 2 ? 0.7 : 0.4);
    const rel = (o: Enemy) => { const dx = o.x - p.x, dy = o.y - p.y; return { f: dx * Math.cos(dir) + dy * Math.sin(dir), s: -dx * Math.sin(dir) + dy * Math.cos(dir), z: 0, r: 0 }; };
    const r2 = e2 ? rel(e2) : { f: 0, s: 0, z: 0, r: 0 };
    this.silat = { sc, id: e.id, i: -1, t: 0, dir, from: { f: f0, s: 0, z: 0, r: 0 }, cur: { f: f0, s: 0, z: 0, r: 0 }, px: p.x, py: p.y, hitDone: false, dur: quick ? 0.5 : 1, id2: e2 ? e2.id : null, from2: { ...r2 }, cur2: { ...r2 } };
    if (e2) { e2.stagger = 10; e2.state = 'stagger'; e2.kx = e2.ky = e2.vx = e2.vy = 0; e2.stun = 0; e2.fuse = -1; e2.tele = null; this.releaseToken(e2); }
    if (this.sfNunOn) { this.sfNun.cur = null; this.sfNun.buffered = false; this.sfNun.idx = 0; this.sfNun.comboTimer = 0; }
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; p.dashT = 0; p.vx = p.vy = p.kx = p.ky = 0; p.moving = false; p.running = false; p.runT = 0;
    p.aim = dir; p.facing = Math.cos(dir) >= 0 ? 1 : -1;
    e.stagger = 10; e.state = 'stagger'; e.kx = e.ky = e.vx = e.vy = 0; e.stun = 0; e.fuse = -1; e.tele = null; this.releaseToken(e);
    for (const o of this.enemies) if (o !== e && !o.dead) o.attackCd = Math.max(o.attackCd, 1.2);
    this.cinematic = true; this.zoomTarget = (e2 ? 1.2 : 1.35) * BASE_ZOOM;
    this.fistHits = 0;
    const ttl = (quick ? 'QUICK ' : '') + sc.title;
    this.say(link ? `LINK x${this.silatChainN + 1} - ${ttl}` : ttl, e2 ? '#ff6a4a' : '#ffd27f', 2, quick ? 0.7 : 1.0);
    this.sfx.whoosh();
    this.silatBeat(0);
    return true;
  }
  silatBeat(i: number) {
    const S = this.silat!, p = this.player;
    S.i = i; S.t = 0; S.hitDone = false;
    const b = S.sc.beats[i];
    if (b.turn) { S.dir += Math.PI; S.cur.f = -S.cur.f; S.cur.s = -S.cur.s; S.cur2.f = -S.cur2.f; S.cur2.s = -S.cur2.s; p.aim = S.dir; p.facing = Math.cos(S.dir) >= 0 ? 1 : -1; }
    S.from = b.snap ? { f: b.f, s: b.s ?? 0, z: b.z ?? 0, r: b.r ?? 0 } : { ...S.cur };
    S.from2 = { ...S.cur2 };
    S.px = p.x; S.py = p.y;
    if (b.name) this.texts.add(p.x, p.y - 30, b.name, '#ffffff', 1, 0.6);
  }
  updateSilat(dt: number) {
    const S = this.silat!, p = this.player;
    const e = this.enemies.find((en) => en.id === S.id);
    if (!e || e.dead) { this.endSilat(e ?? null); return; }
    S.t += dt;
    const b = S.sc.beats[S.i];
    const u = clamp(S.t / (b.d * S.dur), 0, 1), k = u * u * (3 - 2 * u);
    // victim offset eased toward the beat target
    const T = { f: b.f, s: b.s ?? 0, z: b.z ?? 0, r: b.r ?? 0 };
    S.cur = { f: lerp(S.from.f, T.f, k), s: lerp(S.from.s, T.s, k), z: lerp(S.from.z, T.z, k), r: lerp(S.from.r, T.r, k) };
    // player step along the fight line
    if (b.step) { const nx = S.px + Math.cos(S.dir) * b.step * k, ny = S.py + Math.sin(S.dir) * b.step * k; if (this.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; } }
    const cd = Math.cos(S.dir), sd = Math.sin(S.dir);
    const ex = p.x + cd * S.cur.f - sd * S.cur.s, ey = p.y + sd * S.cur.f + cd * S.cur.s;
    if (this.isFree(ex, ey, e.r * 0.8)) { e.x = ex; e.y = ey; }
    const towards = Math.atan2(p.y - e.y, p.x - e.x);
    e.aim = b.away ? towards + Math.PI : towards; e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
    e.stagger = 10; e.down = 0; e.kx = e.ky = e.vx = e.vy = 0;
    e.scenePose = b.ep; e.sceneT = b.et ? lerp(b.et[0], b.et[1], k) : 0.5; e.sceneZ = S.cur.z; e.sceneRot = S.cur.r * e.facing;
    // player pose
    p.holdT = 0.1; p.holdPose = b.pp; p.holdPoseT = lerp(b.pt[0], b.pt[1], k);
    p.vx = p.vy = p.kx = p.ky = 0; p.moving = false; p.iframes = Math.max(p.iframes, 0.3);
    p.z = b.pz ? b.pz * Math.sin(Math.PI * u) : 0;
    if (p.weapon === 'nunchaku') {
      const LS = this.longMode ? 2.5 : 1;
      const sk = solvePose(this.playerStickOpts(b.pp, p.holdPoseT));
      let hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
      if (b.spin) { const ang = this.time * b.spin, sh = { x: p.x, y: p.y - 5 * LS - p.z }; hand = { x: sh.x + Math.cos(ang) * 7 * LS, y: sh.y + Math.sin(ang) * 5 * LS }; }
      if (this.sfNunOn) this.sfNun.update(dt, p.x, p.y - 4 * LS - p.z, S.dir, this.time, 'idle', LS, hand);
      else this.nunchaku.update(hand, { x: Math.cos(S.dir), y: Math.sin(S.dir) }, dt, b.spin ?? 0, b.hit && !S.hitDone && u > 0.25 ? { x: Math.cos(S.dir) * 900, y: Math.sin(S.dir) * 500 } : null, true);
      if (b.spin && Math.random() < 0.3) this.sfx.chainRattle();
    }
    if (b.acro) {
      this.silatAcroT -= dt;
      if (this.silatAcroT <= 0) { this.silatAcroT = 0.035; this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: b.pp, poseT: p.holdPoseT }, '#9be7ff', p.lean); }
      if (u < 0.12 && Math.random() < 0.5) this.particles.smoke(p.x, p.y, 1, '#8a8a8a', 25, 0.35);
      if (Math.random() < 0.4) this.particles.lines(p.x, p.y - 6 - p.z, 1, '#ffffff', S.dir + Math.PI, 150);
    }
    this.slowT = Math.max(this.slowT, 0.05); this.slowFactor = Math.max(this.slowFactor, 0.8);
    this.camFocus = { x: (p.x + e.x) / 2, y: (p.y + e.y) / 2 - 4 };
    // second victim (DOUBLE scenes)
    let e2: Enemy | undefined;
    if (S.id2 !== null) {
      e2 = this.enemies.find((en) => en.id === S.id2);
      if (!e2 || e2.dead) { if (e2) { e2.scenePose = undefined; e2.sceneZ = 0; e2.sceneRot = 0; } S.id2 = null; e2 = undefined; }
    }
    if (e2) {
      const T2 = { f: b.f2 ?? S.from2.f, s: b.s2 ?? 0, z: b.z2 ?? 0, r: b.r2 ?? 0 };
      S.cur2 = { f: lerp(S.from2.f, T2.f, k), s: lerp(S.from2.s, T2.s, k), z: lerp(S.from2.z, T2.z, k), r: lerp(S.from2.r, T2.r, k) };
      const x2 = p.x + cd * S.cur2.f - sd * S.cur2.s, y2 = p.y + sd * S.cur2.f + cd * S.cur2.s;
      if (this.isFree(x2, y2, e2.r * 0.8)) { e2.x = x2; e2.y = y2; }
      const tw2 = Math.atan2(p.y - e2.y, p.x - e2.x);
      e2.aim = b.away2 ? tw2 + Math.PI : tw2; e2.facing = Math.cos(e2.aim) >= 0 ? 1 : -1;
      e2.stagger = 10; e2.down = 0; e2.kx = e2.ky = e2.vx = e2.vy = 0;
      e2.scenePose = b.ep2 ?? b.ep; e2.sceneT = b.et2 ? lerp(b.et2[0], b.et2[1], k) : 0.5; e2.sceneZ = S.cur2.z; e2.sceneRot = S.cur2.r * e2.facing;
      this.camFocus = { x: (e.x + e2.x) / 2, y: (e.y + e2.y) / 2 - 4 };
    }
    // impact lands at 45% of the beat
    if (!S.hitDone && u >= 0.45 && (b.hit || b.hit2)) {
      S.hitDone = true;
      if (e2 && b.hit2) this.silatHit(e2, b.hit2, S);
      if (b.hit) this.silatHit(e, b.hit, S);
      if (e.dead) { if (e2 && !e2.dead && S.id2 !== null) { e2.scenePose = undefined; e2.sceneZ = 0; e2.sceneRot = 0; if (e2.stagger > 1) e2.stagger = 0; } this.endSilat(e); return; }
    }
    if (u >= 1) {
      if (S.i + 1 < S.sc.beats.length) this.silatBeat(S.i + 1);
      else this.endSilat(e);
    }
  }
  silatHit(e: Enemy, h: SilatHit, S: NonNullable<Game['silat']>) {
    const p = this.player;
    const hx = e.x + Math.sin(e.sceneRot ?? 0) * 4, hy = e.y - 7 - (e.sceneZ ?? 0);
    const a = S.dir;
    if (p.weapon === 'bat' && h.fx !== 'block') { this.sfx.batCrack(); this.sfx.axeHit(!!h.final); this.particles.ring(hx, hy, 2, h.final ? 18 : 11, '#ffffff', 0.16, 1); this.particles.burst(hx, hy, 3, '#e6b877', 120, 0.4, 1, 3); this.batSpamHit(); }
    if (p.weapon === 'nunchaku' && h.fx !== 'block') { this.sfx.nunchakuHit(!!h.final); const tp = this.sfNunOn ? this.sfNun.pts[5] : this.nunchaku.tip(); if (tp) this.particles.ring(tp.x, tp.y, 1, 8, '#ffffff', 0.14, 1); }
    if (h.fx === 'block') {
      const bx = (p.x + e.x) / 2, by = p.y - 7;
      this.texts.add(bx, by - 18, h.word, '#9be7ff', 1, 0.5);
      this.particles.ring(bx, by, 2, 12, '#9be7ff', 0.18, 1); this.particles.spark(bx, by, 10, '#9be7ff', a + Math.PI, 1.2, 220);
      this.sfx.parry(); this.hitstop = Math.max(this.hitstop, 0.08); this.shake(0.3);
      return;
    }
    this.texts.add(e.x + rnd(-5, 5), e.y - 26 - (e.sceneZ ?? 0), h.word, h.final ? '#ff6a4a' : '#ffffff', h.final ? 2 : 1, 0.55);
    this.hitstop = Math.max(this.hitstop, (h.stop ?? 0.05) * (S.dur < 1 ? 0.6 : 1));
    this.shake(h.shake ?? 0.25);
    e.flash = 0.1; e.sqx = 1.3; e.sqy = 0.7;
    this.gunfx.hitSpark(hx, hy, a + rnd(-0.4, 0.4), e.y, !!h.final || h.fx === 'slam');
    this.particles.impact(hx, hy, h.final ? 8 : 5, '#ffffff');
    if (h.fx !== 'sweep') { this.particles.blood(hx, hy, h.final ? 10 : 4, a, 120); this.blood.spray(hx, hy, a, h.dmg * 0.6, !!h.final); }
    if (h.fx === 'slam') { this.particles.shockwave(e.x, e.y, 22, '#ffffff', 0.3); this.particles.smoke(e.x, e.y, 8, '#8a8a8a', 40, 0.5); this.particles.burst(e.x, e.y, 6, this.pal.wallTop, 120, 0.4, 2, 3); this.sfx.slam(); }
    if (h.fx === 'snap') { this.particles.ring(hx, hy, 2, 12, '#ffffff', 0.18, 1); this.sfx.parry(); this.flash('#ffffff', 0.08); }
    if (h.fx === 'knee' || h.fx === 'head') this.sfx.kick(); else if (h.fx === 'elbow' || h.fx === 'punch') this.sfx.punch(); else if (h.fx === 'sweep') this.sfx.whoosh();
    this.sfx.hit(); if (h.final) this.sfx.heavy();
    this.addCombo(); this.addOfa(h.dmg * 0.15);
    p.focus = Math.min(300, p.focus + 6 * this.stats.focusGain);
    const dmg = h.dmg * this.stats.meleeDmg;
    if (!h.final) { e.hp = Math.max(1, e.hp - dmg); e.structure += 10; return; }
    // the last blow: real damage, may kill (ragdoll) — otherwise the victim is left on the floor
    const second = S.id2 !== null && e.id === S.id2;
    if (!second) this.slow(0.32 * (S.dur < 1 ? 0.6 : 1), 0.25);
    this.zoomKick = Math.max(this.zoomKick, 0.09); this.flash('#ffffff', 0.14);
    this.particles.shockwave(e.x, e.y - 4, 30, '#ffd27f', 0.35); this.particles.ring(hx, hy, 3, 20, '#ffffff', 0.22, 2);
    if (!second) this.say(S.id2 !== null ? 'DOUBLE KO!' : this.silatChainN >= 2 ? 'GRAND FINALE!' : h.word, this.silatChainN >= 2 ? '#ff6a4a' : '#ffd27f', 3, 1.0);
    if (S.id2 !== null && !second) this.score += 80;
    if (!second && this.silatChainN >= 2) { this.score += 100; this.slow(0.45, 0.2); }
    e.scenePose = undefined; e.sceneZ = 0; e.sceneRot = 0; e.stagger = 0;
    const R = S.sc.release;
    this.damageEnemy(e, dmg, 80, a, R.kb, { melee: true, knockdown: true, hitstop: h.stop ?? 0.1, shake: h.shake ?? 0.6, launch: R.launch });
    if (!e.dead && R.down && R.kb < 200) { e.down = e.boss ? 0.7 : 1.3; e.state = 'down'; e.pose = 'down'; e.fuse = -1; }
    this.score += 40;
  }
  endSilat(e: Enemy | null) {
    const p = this.player;
    if (e) { e.scenePose = undefined; e.sceneZ = 0; e.sceneRot = 0; if (!e.dead && e.stagger > 1) { e.stagger = 0; e.state = 'chase'; e.pose = 'idle'; e.attackCd = Math.max(e.attackCd, 0.5); } }
    const e2 = this.silat && this.silat.id2 !== null ? this.enemies.find((en) => en.id === this.silat!.id2) : null;
    if (e2) { e2.scenePose = undefined; e2.sceneZ = 0; e2.sceneRot = 0; if (!e2.dead && e2.stagger > 1) { e2.stagger = 0; e2.state = 'chase'; e2.pose = 'idle'; e2.attackCd = Math.max(e2.attackCd, 0.5); } }
    this.silat = null; this.silatCd = 2.0;
    this.silatLinkT = 0.75;
    p.holdT = 0; p.z = 0; p.iframes = Math.max(p.iframes, 0.4);
    this.cinematic = false; this.zoomTarget = BASE_ZOOM; this.camFocus = null;
  }
  /** next victim for a LINK (acrobatic transition) after a sequence */
  silatLinkTarget(): Enemy | null {
    const p = this.player;
    let best: Enemy | null = null, bd = 95;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0 || e.boss || e.z > 1 || e.down > 0) continue;
      const d = dist(e.x, e.y, p.x, p.y);
      if (d < bd && this.hasLOSFrom(p.x, p.y, e.x, e.y)) { bd = d; best = e; }
    }
    return best;
  }
  hasLOSFrom(x0: number, y0: number, x1: number, y1: number) { return lineOfSight(this.level, x0, y0, x1, y1); }
  trySilatLink(): boolean {
    const e = this.silatLinkTarget();
    if (!e) return false;
    const n = this.silatChainN + 1;
    this.silatLinkT = 0;
    const ok = this.trySilat(e, true, undefined, true);
    if (ok) this.silatChainN = n;
    return ok;
  }

  updateSilatPending(dt: number) {
    if (!this.silatPending) return;
    this.silatPending.t -= dt;
    if (this.silatPending.t > 0) return;
    const e = this.enemies.find((en) => en.id === this.silatPending!.id);
    const pk = this.silatPending.kind;
    this.silatPending = null;
    if (e && !e.dead) { this.trySilat(e, true, pk ?? 'armbar'); return; }
  }

  enemyMeleeHit(e: Enemy, dmg: number, range: number, arc: number, knockdown: boolean) {
    const p = this.player;
    const d = dist(e.x, e.y, p.x, p.y);
    if (d > range + p.r) return;
    const a = Math.atan2(p.y - e.y, p.x - e.x);
    if (Math.abs(angleDiff(a, e.aim)) > arc) return;
    // fair enemy strikes too: for normal punches/kicks the striking limb (from the enemy's own posed skeleton)
    // must actually reach the player's body; area attacks (brute slam, charges, sweeps with arc >= PI) skip this
    if (arc < 3 && (e.pose === 'punch' || e.pose === 'kick' || e.pose === 'palm')) {
      const sk = solvePose({ x: e.x, y: e.y, c: e.color, c2: e.color2, scale: e.scale, facing: e.facing, aim: e.aim, walk: e.walk, moving: false, pose: e.pose, t: Math.min(1, Math.max(0.36, e.poseT)), acc: 'none', weapon: 'none', flash: false, alpha: 1, outline: null, eyes: '#000', time: this.time, lean: { x: Math.cos(e.aim), y: Math.sin(e.aim) } });
      const j = e.pose === 'kick' ? sk.ffoot : e.pose === 'palm' ? sk.fhand : sk.bhand;
      const jx = e.x + j.x, jy = e.y + j.y - e.z;
      const hitR = 5 * e.scale + 2;
      let dmin = 1e9;
      for (let k = 0; k <= 4; k++) { const yy = p.y - 13 + (14 * k) / 4 - p.z; dmin = Math.min(dmin, Math.hypot(jx - p.x, jy - yy)); }
      if (dmin > hitR + p.r + 1.5) return;
    }
    if (this.canPlayerParry(e)) { this.perfectParry(e, a); return; }
    if (p.dashT > 0 && (p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat') && !e.boss && !this.silat && !p.fatality && !this.silatPending) { this.say('DODGE!', '#9be7ff', 2, 0.6); this.slow(0.15, 0.3); this.silatPending = { id: e.id, t: 0.06, kind: 'counter' }; return; }
    if (p.z > 12 && !e.boss) { this.texts.add(p.x, p.y - 26 - p.z, 'JUMPED!', '#9be7ff', 1, 0.5); return; } // leapt clean over a sweep/strike
    this.damagePlayer(dmg, a, knockdown);
  }

  private cancelPlayerAttack() {
    const p = this.player;
    p.attackPhase = 'none'; p.attackT = 0; p.moveKey = null; p.buffered = null; p.comboStr = '';
    p.hitSet = []; p.hitTimes = {}; p.prevLimb = null; p.travelHit = false;
    p.dashT = 0; p.parryT = 0; p.parryHit = false; p.holdT = 0;
    p.focusDash = null; p.rageDash = null; p.runT = 0; p.running = false;
    this.sfNun.cur = null; this.sfNun.buffered = false; this.sfNun.idx = 0;
    this.sfNun.comboTimer = 0; this.sfNun.hitIds = [];
    this._pfk = null; this.prevBlade = null; this.yoyoFeet = null; this.silatPending = null;
    this.parryCounterKey = null; this.pendingRiposte = null;
    if (p.weapon === 'takamura') this.tak?.reset();
    if (p.weapon === 'hayabusa') this.hay?.reset();
    if (p.weapon === 'axe') this.lev?.reset();
    if (p.weapon === 'yoyo' && this.yoyoVer === 1) this.yoyo?.reset(p.x, p.y - 8 - p.z);
  }

  private cancelBossAttack(e: Enemy) {
    e.attackPhase = 'none'; e.attackT = 0; e.moveKey = null; e.comboQueue = [];
    e.hitDone = true; e.prevLimb = null; e.travelHit = false; e.dashT = 0; e.parryT = 0;
    e.vx = e.vy = 0;
  }

  private queueParryRiposte(e: Enemy, owner: 'player' | 'boss', key: string) {
    this.cancelPlayerAttack(); this.cancelBossAttack(e);
    const p = this.player;
    p.vx = p.vy = p.kx = p.ky = 0; p.z = 0; p.vz = 0; p.airborne = false;
    e.kx = e.ky = 0; e.z = 0; e.vz = 0;
    e.scenePose = undefined; e.sceneZ = 0; e.sceneRot = 0; e.down = 0; e.stagger = 0;
    e.counterLockT = owner === 'player' ? 0.95 : 0;
    e.parryCd = owner === 'player' ? 0.95 : 0.3;
    e.stun = owner === 'player' ? 0.45 : 0;
    e.state = owner === 'player' ? 'parried' : 'chase';
    p.stunT = owner === 'boss' ? 0.12 : 0;
    this.pendingRiposte = { id: e.id, owner, key, t: 0.32 };
  }

  private updateParryRiposte(dt: number) {
    const riposte = this.pendingRiposte!;
    const p = this.player, e = this.enemies.find((enemy) => enemy.id === riposte.id && !enemy.dead);
    if (!e) { this.pendingRiposte = null; p.holdT = 0; return; }
    const winner = riposte.owner === 'player' ? p : e;
    const loser = riposte.owner === 'player' ? e : p;
    const dir = Math.atan2(loser.y - winner.y, loser.x - winner.x);
    const LS = this.longMode ? 2.5 : 1;
    const move = MOVES[riposte.key];
    const reach = (riposte.key === 'SF_HEAVY' ? 29 : move?.range ?? 24) * LS;
    const gap = Math.max(p.r + e.r + 3, Math.min(20 * LS, reach * 0.6));
    const distance = dist(winner.x, winner.y, loser.x, loser.y);
    const step = Math.min(Math.max(0, distance - gap), 240 * LS * dt);
    p.vx = p.vy = e.vx = e.vy = 0;
    if (step > 0) moveWithCollision(this.level, winner, Math.cos(dir) * step, Math.sin(dir) * step);
    winner.aim = dir; winner.facing = Math.cos(dir) >= 0 ? 1 : -1;
    loser.aim = dir + Math.PI; loser.facing = -winner.facing;
    p.holdT = 0.1; p.holdPose = riposte.owner === 'player' && step > 0 ? 'dash' : 'parry'; p.holdPoseT = 0.5;
    e.pose = riposte.owner === 'boss' && step > 0 ? 'dash' : 'hurt';
    if (this.sfNunOn) this.sfNun.update(dt, p.x, p.y - 4 * LS, p.aim, this.time, 'dash', LS);
    else this.updateNunchaku(dt);
    this.updateKatana(dt); updateBossWeaponPhysics(this, e, dt);
    riposte.t -= dt;
    if (dist(winner.x, winner.y, loser.x, loser.y) > gap + 1 && riposte.t > 0) return;
    this.pendingRiposte = null; p.holdT = 0;
    if (dist(winner.x, winner.y, loser.x, loser.y) > reach + loser.r || !this.hasLOS(e)) return;
    if (riposte.owner === 'player') {
      p.stunT = 0; p.aim = p.attackAim = p.bodyAim = dir;
      if (riposte.key === 'SF_HEAVY') {
        this.sfNunAim = dir; this.sfNun.start(true); this.sfx.swing(0.8);
      } else {
        this.startAttack(riposte.key); this.parryCounterKey = riposte.key;
      }
    } else {
      p.iframes = 0; p.stunT = 0.1; p.parryT = 0;
      startBossMove(this, e, riposte.key, true);
    }
  }

  canPlayerParry(e: Enemy) {
    const p = this.player;
    return this.state === 'playing' && !this.clashDuel && !this.silat && !p.fatality &&
      p.stunT <= 0 && p.holdT <= 0 && !p.airborne && p.parryT > 0 && !p.parryHit &&
      !e.dead && e.spawnT <= 0 && this.hasLOS(e) && Math.abs(angleDiff(Math.atan2(e.y - p.y, e.x - p.x), p.aim)) <= 1.7;
  }

  bossParryPlayer(e: Enemy, hx: number, hy: number, _attackAngle: number) {
    if (e.dead || e.stun > 0 || e.stagger > 0 || (e.counterLockT ?? 0) > 0 || this.clashDuel) return;
    const p = this.player;
    const dir = Math.atan2(e.y - p.y, e.x - p.x);
    const nx = Math.cos(dir), ny = Math.sin(dir);
    const streak = (e.rallyStreak ?? 0) + 1;
    this.cancelPlayerAttack(); this.cancelBossAttack(e);
    e.rallyStreak = streak; e.rallyWindow = 1.1;
    e.parryCd = 0.65; e.parryT = 0.14; e.attackCd = 0.22;
    e.state = 'chase'; e.pose = 'parry'; e.poseT = 0.5;
    p.vx = p.vy = 0;
    p.kx = -nx * 135; p.ky = -ny * 135;
    p.stunT = 0.12; p.brakeT = 0.3; p.squash = 0.86;
    p.aim = p.attackAim = p.bodyAim = dir; p.facing = nx >= 0 ? 1 : -1;
    e.kx = -nx * 20; e.ky = -ny * 20;
    e.aim = e.bodyAim = dir + Math.PI; e.facing = -p.facing;
    this.sfx.clashPing(1 + Math.min(0.5, streak * 0.12));
    this.particles.ring(hx, hy, 3, 16, '#ffd700', 0.2, 1);
    this.particles.spark(hx, hy, 9, '#ffd700', dir + Math.PI, 1.1, 180);
    this.particles.smoke(p.x, p.y + 1, 4, '#9a8f7d', 20, 0.3);
    this.hitstop = Math.max(this.hitstop, 0.055); this.shake(0.25);
    this.zoomKick = 0.04;
    if (streak >= 3 && this.clashCd <= 0) this.startClash(e);
  }

  private parryDrawRecoil(e: Enemy, impulse = 190) {
    const p = this.player;
    this.cancelPlayerAttack(); this.cancelBossAttack(e);
    const dir = dist(p.x, p.y, e.x, e.y) > 0.01 ? Math.atan2(e.y - p.y, e.x - p.x) : p.aim;
    const nx = Math.cos(dir), ny = Math.sin(dir);
    p.attackPhase = 'none'; p.attackT = 0; p.moveKey = null; p.buffered = null; p.comboStr = '';
    p.dashT = 0; p.parryT = 0; p.focusDash = null; p.rageDash = null;
    p.vx = p.vy = 0; p.kx = -nx * impulse; p.ky = -ny * impulse;
    p.z = 0; p.vz = 0; p.airborne = false; p.runT = 0; p.running = false; p.moving = false;
    p.aim = p.attackAim = p.bodyAim = dir;
    p.facing = nx >= 0 ? 1 : -1;
    p.lean = { x: nx, y: ny };
    p.stunT = 0.28; p.holdT = 0.28; p.holdPose = 'parry'; p.holdPoseT = 0.6;
    p.brakeT = 0.35; p.squash = 0.84; p.parryCd = Math.max(p.parryCd, 0.28);
    this.sfNun.cur = null; this.sfNun.buffered = false;
    this.silatPending = null; this._pfk = null;

    e.attackPhase = 'none'; e.attackT = 0; e.moveKey = null; e.comboQueue = [];
    e.dashT = 0; e.parryT = 0; e.rallyWindow = 0; e.rallyStreak = 0;
    e.vx = e.vy = 0; e.kx = nx * impulse; e.ky = ny * impulse;
    e.z = 0; e.vz = 0; e.moving = false;
    e.aim = e.bodyAim = dir + Math.PI; e.facing = -p.facing;
    e.state = 'parryRecoil'; e.stun = 0.28; e.pose = 'parry'; e.poseT = 0.6;
    e.scenePose = undefined; e.sceneZ = 0; e.sceneRot = 0;
    e.attackCd = Math.max(e.attackCd, 0.28); e.parryCd = Math.max(e.parryCd, 0.28);
    e.sqx = 1.2; e.sqy = 0.84;
    this.particles.smoke(p.x, p.y + 1, 4, '#9a8f7d', 24, 0.35);
    this.particles.smoke(e.x, e.y + 1, 4, '#9a8f7d', 24, 0.35);
    return dir;
  }

  /** Drawn parries push both fighters away from their actual point of contact. */
  mutualClashDeflect(e: Enemy, _attackAngle: number) {
    const p = this.player;
    const mx = (p.x + e.x) / 2, my = (p.y + e.y) / 2 - 6;
    const dir = this.parryDrawRecoil(e);
    this.sfx.clashPing(1.15);
    this.particles.ring(mx, my, 3, 23, '#ffd700', 0.22, 2);
    this.particles.spark(mx, my, 14, '#ffffff', dir + Math.PI / 2, 1.4, 240);
    this.particles.impact(mx, my, 9, '#ffd700');
    this.hitstop = Math.max(this.hitstop, 0.07);
    this.shake(0.42);
    this.zoomKick = 0.06;
  }

  perfectParry(e: Enemy, _attackAngle: number) {
    const p = this.player;
    if (this.state !== 'playing' || e.dead || e.spawnT > 0 || this.clashDuel || this.silat || p.fatality) return false;
    const serial = e.attackSerial ?? 0;
    if (e.parriedSerial === serial) return false;
    const dir = Math.atan2(e.y - p.y, e.x - p.x);
    const nx = Math.cos(dir), ny = Math.sin(dir);
    const streak = (e.rallyStreak ?? 0) + 1;
    this.cancelPlayerAttack(); this.cancelBossAttack(e);
    e.parriedSerial = serial; e.rallyStreak = streak; e.rallyWindow = 1.4;
    e.counterLockT = 0.65; e.parryCd = Math.max(e.parryCd, 0.65);
    e.stun = Math.max(e.stun, 0.28); e.state = 'parried'; e.pose = 'hurt'; e.flinch = 0.1;
    e.attackCd = 0.12;
    e.kx = nx * 75; e.ky = ny * 75;
    if (e.z > 0) e.vz = Math.min(e.vz, -60);
    p.vx = p.vy = 0; p.kx = nx * 30; p.ky = ny * 30;
    p.aim = p.attackAim = p.bodyAim = dir; p.facing = nx >= 0 ? 1 : -1;
    p.lean = { x: nx, y: ny }; p.stunT = 0;
    p.parryHit = true; p.parryT = 0.09; p.parryCd = 0.14;
    p.iframes = Math.max(p.iframes, 0.16);
    p.squash = 0.92; e.sqx = 1.18; e.sqy = 0.88;
    e.structure += e.maxStructure * 0.18;
    p.focus = Math.min(300, p.focus + 38 * this.stats.focusGain);
    this.addOfa(6); this.addCombo(1);
    const mx = (p.x + e.x) / 2, my = (p.y + e.y) / 2 - 6;
    this.sfx.clashPing(1.1 + Math.min(0.5, streak * 0.12));
    this.particles.ring(mx, my, 3, 19, '#35f0ff', 0.22, 1);
    this.particles.spark(mx, my, 10, '#9be7ff', dir, 1.1, 200);
    this.particles.impact(mx, my, 6, '#ffffff');
    this.hitstop = Math.max(this.hitstop, 0.065); this.shake(0.3);
    this.zoomKick = 0.05;
    if (e.structure >= e.maxStructure) this.staggerEnemy(e);
    else if (streak >= 3 && this.clashCd <= 0) this.startClash(e);
    return true;
  }

  // ============================== ADEGAN SALING ADU & PARRY (1-FOR-1 TEMPO EXCHANGE) ==============================
  clashMovesFor(w: WeaponKind): string[] {
    switch (w) {
      case 'nunchaku': return ['NL', 'NLL', 'NLLL', 'NLH', 'NLLLL', 'NHL'];
      case 'katana':
      case 'takamura':
      case 'hayabusa': return ['KL', 'KLL', 'KLLL', 'KH', 'KLLLL'];
      case 'bat': return ['SB_F', 'SB_B', 'B_BEHIND', 'SB_UPPER', 'B_SLAM'];
      case 'axe': return ['AL', 'ALL', 'ALH', 'ALLL'];
      case 'dual': return ['DL', 'DLL', 'DLH', 'DLLLL'];
      case 'yoyo': return ['YL', 'YLL', 'YLLL', 'YLH'];
      default: return ['L', 'LL', 'LLL', 'S1', 'S2', 'LH', 'LLLL', 'H'];
    }
  }

  startClash(e: Enemy) {
    if (this.isAttractMode) return;
    if (this.clashDuel || this.silat || this.player.fatality || this.player.airborne || this.player.z > 4 || e.z > 4 || e.dead || e.spawnT > 0 || !this.hasLOS(e)) return;
    const p = this.player;
    const LS = this.longMode ? 2.5 : 1;
    const cx = (p.x + e.x) / 2;
    const cy = (p.y + e.y) / 2;
    const dir = Math.atan2(e.y - p.y, e.x - p.x);
    const pMoves = this.clashMovesFor(p.weapon);
    const bMoves = this.clashMovesFor(e.rivalWeapon ?? 'nunchaku');
    this.cancelPlayerAttack(); this.cancelBossAttack(e);

    this.clashDuel = {
      id: e.id,
      t: 0,
      power: 50,
      hits: 1,
      maxBeats: 12,
      beatsDone: 0,
      turn: 'both',
      u: 0,
      beatDur: 0.38,
      activeTempo: 1.0,
      playerTempo: 1.0,
      bossTempo: 1.0,
      lastPlayerTapAt: this.time,
      pendingPlayerReplies: 0,
      bossReplyQueued: true,
      playerContestedBeat: true,
      parryTapAt: null,
      bossIdleWaitT: 0.28,
      bossBurstLeft: 0,
      hitDone: false,
      pMoveKey: pMoves[0],
      bMoveKey: bMoves[0],
      defenseStyle: 'deflect',
      beatOutcome: 'clash',
      dir,
      targetDir: dir,
      baseDir: dir,
      cx,
      cy,
      targetCx: cx,
      targetCy: cy,
      poseIdx: 0,
      recoilT: 0,
      recoilMoved: 0,
      recoilDir: dir,
      recoilGap: Math.max(0, dist(p.x, p.y, e.x, e.y) / 2 - 11.2 * LS),
    };
    this.announce = [];
    this.texts.list = [];
    this.clashCd = 5.0;
    e.rallyStreak = 0;
    e.rallyWindow = 0;
    e.counterLockT = 0;
    e.attackPhase = 'none';
    e.comboQueue = [];
    e.stagger = 0; e.stun = 0; e.down = 0;
    e.vx = e.vy = e.kx = e.ky = 0;
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; p.dashT = 0; p.stunT = 0; p.parryT = 0;
    p.vx = p.vy = p.kx = p.ky = 0; p.z = 0; p.vz = 0; p.airborne = false;
    if (this.sfNunOn) { this.sfNun.cur = null; this.sfNun.buffered = false; }

    p.aim = dir; p.facing = Math.cos(dir) >= 0 ? 1 : -1;
    e.aim = dir + Math.PI; e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;

    this.cinematic = true;
    this.zoomTarget = 1.44 * BASE_ZOOM;
    this.camFocus = { x: cx, y: cy - 5 };
    this.flash('#ffd700', 0.18);
    this.shake(0.5);
    this.sfx.parry();
    this.sfx.announce();
    this.particles.shockwave(cx, cy - 5, 34, '#ffd700', 0.35);
    this.particles.ring(cx, cy - 5, 4, 22, '#35f0ff', 0.28, 2);
  }

  /** Pick a varied, non-monotonous defensive/parry reaction style based on incoming move & beat index */
  pickDefenseStyle(moveKey: string, idx: number, outcome: 'perfect' | 'clash' | 'pushed'): 'deflect' | 'duck' | 'hop' | 'pivot' | 'lock' {
    if (outcome === 'pushed') return 'deflect';
    if (moveKey === 'NHL' || moveKey === 'LLH' || moveKey === 'S1' || moveKey === 'YHL') return 'hop';
    if (moveKey === 'NLLL' || moveKey === 'NH' || moveKey === 'KLLL' || moveKey === 'SB_F' || moveKey === 'B_BEHIND' || moveKey === 'LLLL') {
      return idx % 2 === 0 ? 'duck' : 'pivot';
    }
    const styles: ('deflect' | 'duck' | 'hop' | 'pivot' | 'lock')[] = ['deflect', 'pivot', 'duck', 'lock', 'hop'];
    return styles[idx % styles.length];
  }

  /** Weapon-specific active deflect pose so parrying doesn't always use the same static arm pose */
  activeDeflectPose(w: WeaponKind, idx: number): Pose {
    switch (w) {
      case 'nunchaku': return idx % 2 === 0 ? 'n_tri2' : 'n_tri4';
      case 'katana':
      case 'takamura':
      case 'hayabusa': return idx % 2 === 0 ? 'k_return' : 'parry';
      case 'bat':
      case 'axe': return idx % 2 === 0 ? 'a_bunt' : 'parry';
      case 'dual': return idx % 2 === 0 ? 'd_cross' : 'parry';
      case 'yoyo': return 'y2_freeze';
      default: return idx % 2 === 0 ? 'parry' : 'elbow';
    }
  }

  beginClashBeat(e: Enemy, turn: 'player' | 'boss' | 'both', tempo: number) {
    const C = this.clashDuel!;
    const p = this.player;
    C.turn = turn;
    C.u = 0;
    C.hitDone = false;
    C.parryTapAt = null;
    C.activeTempo = clamp(tempo, 0.85, 2.8);
    // Base duration of 1 full martial-arts strike+parry beat is 0.40s at 1.0x tempo, shrinking down to ~0.14s when pressing fast!
    C.beatDur = clamp(0.40 / C.activeTempo, 0.14, 0.46);
    C.poseIdx++;
    C.recoilMoved = 0;
    p.chainSide *= -1;
    e.chainSide = (e.chainSide ?? 1) * -1;

    const pMoves = this.clashMovesFor(p.weapon);
    const bMoves = this.clashMovesFor(e.rivalWeapon ?? 'nunchaku');
    C.pMoveKey = pMoves[C.poseIdx % pMoves.length];
    C.bMoveKey = bMoves[(C.poseIdx + 1) % bMoves.length];
    p.travelHit = false;
    e.travelHit = false;

    // Decide whether the defender wins this parry cleanly, clashes evenly, or gets pushed back!
    if (turn === 'player') {
      // Player is attacking -> If Player is pressing fast or has high power, Boss's guard gets pushed back ('pushed')!
      // Otherwise Boss executes a smart varied parry ('perfect' or 'clash').
      C.beatOutcome = C.playerTempo >= 1.75 || C.power >= 68 ? 'pushed' : C.poseIdx % 3 === 0 ? 'perfect' : 'clash';
      C.defenseStyle = this.pickDefenseStyle(C.pMoveKey, C.poseIdx, C.beatOutcome);
    } else if (turn === 'boss') {
      // Boss is attacking -> Outcome depends on whether Player contested/parried the beat!
      C.beatOutcome = C.playerContestedBeat ? (C.playerTempo >= 1.5 ? 'perfect' : 'clash') : 'pushed';
      C.defenseStyle = this.pickDefenseStyle(C.bMoveKey, C.poseIdx, C.beatOutcome);
    } else {
      C.beatOutcome = 'clash';
      C.defenseStyle = 'deflect';
    }
    if (C.beatOutcome === 'clash') C.defenseStyle = 'deflect';

    // Dynamic angle & footwork: on 'pivot' defense style, the two fighters rotate/swap sides!
    if (C.defenseStyle === 'pivot' && C.beatOutcome !== 'pushed') {
      C.targetDir += (C.poseIdx % 2 === 0 ? 1 : -1) * 1.15;
    } else {
      C.targetDir += Math.sin(C.poseIdx * 1.5) * 0.22;
    }

    if (turn === 'player' || turn === 'both') {
      const pm = MOVES[C.pMoveKey];
      if (pm?.slash) {
        p.bladeA = C.dir + pm.slash.from * p.facing;
        p.bladePrevA = p.bladeA;
        p.bladeB = C.dir - pm.slash.from * p.facing;
      }
      this.sfx.swing(1.0 + (C.activeTempo - 1) * 0.2);
    }
    if (turn === 'boss' || turn === 'both') {
      const bm = MOVES[C.bMoveKey];
      if (bm?.slash) {
        e.bladeA = (C.dir + Math.PI) + bm.slash.from * e.facing;
        e.bladePrevA = e.bladeA;
        e.bladeB = (C.dir + Math.PI) - bm.slash.from * e.facing;
      }
      if (turn === 'boss') this.sfx.swing(0.95 + (C.activeTempo - 1) * 0.2);
    }
  }

  /** Shift the duel center along `dir` by `distPx` so the winner physically walks the loser backward across the dojo! */
  shiftClashCenter(e: Enemy, dir: number, distPx: number) {
    const C = this.clashDuel!;
    const p = this.player;
    const LS = this.longMode ? 2.5 : 1;
    const gap = 11.2 * LS;
    const nx = C.targetCx + Math.cos(dir) * distPx;
    const ny = C.targetCy + Math.sin(dir) * distPx;
    const pTestX = nx - Math.cos(C.targetDir) * gap;
    const pTestY = ny - Math.sin(C.targetDir) * gap;
    const eTestX = nx + Math.cos(C.targetDir) * gap;
    const eTestY = ny + Math.sin(C.targetDir) * gap;

    if (this.isFree(pTestX, pTestY, p.r) && this.isFree(eTestX, eTestY, e.r)) {
      C.targetCx = nx;
      C.targetCy = ny;
    } else {
      // Loser's back hit a dojo wall/pillar during the parry exchange -> WALL PIN CRASH!
      const wallX = distPx > 0 ? e.x : p.x;
      const wallY = distPx > 0 ? e.y : p.y;
      this.sfx.slam();
      this.shake(0.55);
      this.particles.smoke(wallX, wallY, 8, '#888', 38, 0.45);
      this.particles.burst(wallX, wallY - 6, 8, this.pal.wallTop, 110, 0.4, 2, 3);
      this.particles.ring(wallX, wallY - 6, 2, 18, '#ffffff', 0.2, 1);
      if (distPx > 0) {
        C.power = Math.min(100, C.power + 14);
        e.structure = Math.min(e.maxStructure - 1, e.structure + 28);
        this.texts.add(e.x, e.y - 26, 'TERPOJOK TEMBOK!', '#ffd700', 1, 0.6);
      } else {
        C.power = Math.max(0, C.power - 10);
        this.texts.add(p.x, p.y - 26, 'TERPOJOK!', '#ff6b6b', 1, 0.6);
      }
      // Bounce angle away from the wall
      C.targetDir += Math.PI * 0.65;
    }
  }

  private updateClashRecoil(e: Enemy, raw: number) {
    const C = this.clashDuel!;
    const p = this.player;
    const LS = this.longMode ? 2.5 : 1;
    C.recoilT = Math.max(0, C.recoilT - raw);
    const u = clamp(1 - C.recoilT / 0.32, 0, 1);
    const moved = 18 * LS * (1 - Math.pow(1 - u, 3));
    const step = moved - C.recoilMoved;
    const nx = Math.cos(C.recoilDir), ny = Math.sin(C.recoilDir);
    moveWithCollision(this.level, p, -nx * step, -ny * step);
    moveWithCollision(this.level, e, nx * step, ny * step);
    C.recoilMoved = moved;
    C.cx = C.targetCx = (p.x + e.x) / 2;
    C.cy = C.targetCy = (p.y + e.y) / 2;
    C.recoilGap = Math.max(0, dist(p.x, p.y, e.x, e.y) / 2 - 11.2 * LS);

    p.vx = p.vy = p.kx = p.ky = 0;
    e.vx = e.vy = e.kx = e.ky = 0;
    p.moveKey = e.moveKey = null;
    p.attackPhase = e.attackPhase = 'none';
    p.aim = p.bodyAim = C.recoilDir; p.facing = nx >= 0 ? 1 : -1;
    e.aim = e.bodyAim = C.recoilDir + Math.PI; e.facing = -p.facing;
    p.z = 0; e.z = 0; e.sceneZ = 0;
    p.holdT = 0.1; p.holdPose = 'parry'; p.holdPoseT = 0.65 - u * 0.3;
    p.brakeT = 0.35 * (1 - u);
    e.scenePose = 'parry'; e.sceneT = p.holdPoseT; e.sceneRot = 0;
    if (this.sfNunOn) this.sfNun.update(raw, p.x, p.y - 4 * LS, p.aim, this.time, 'dash', LS);
    else this.updateNunchaku(raw);
    this.updateKatana(raw);
    updateBossWeaponPhysics(this, e, raw);
    this.camFocus = { x: C.cx, y: C.cy - 5 };
    if (C.recoilT === 0) C.u = 1;
  }

  clashImpact(e: Enemy) {
    const C = this.clashDuel!;
    const p = this.player;
    const mx = (p.x + e.x) / 2;
    const my = (p.y + e.y) / 2 - 6;
    C.hits++;
    C.beatsDone++;
    if (C.turn === 'player') C.power = clamp(C.power + (C.beatOutcome === 'pushed' ? 8 : C.beatOutcome === 'perfect' ? -5 : 0), 0, 100);
    if (C.turn === 'boss' && C.beatOutcome === 'perfect') C.power = Math.min(100, C.power + 10);
    const pitch = 0.92 + Math.min(1.0, C.hits * 0.04) + (C.activeTempo - 1) * 0.15;
    this.sfx.clashPing(pitch);

    if (C.beatOutcome === 'clash') {
      // Cinematic positions are scripted, so animate recoil instead of using overridden velocities.
      C.recoilT = 0.32;
      C.recoilMoved = 0;
      C.recoilDir = Math.atan2(e.y - p.y, e.x - p.x);
      C.dir = C.targetDir = C.recoilDir;
      p.parryT = 0.18; e.parryT = 0.18;
      p.squash = 0.84; e.sqx = 1.2; e.sqy = 0.84;
      this.particles.smoke(p.x, p.y + 1, 4, '#9a8f7d', 24, 0.35);
      this.particles.smoke(e.x, e.y + 1, 4, '#9a8f7d', 24, 0.35);
      this.particles.ring(mx, my, 3, 22, '#ffd700', 0.22, 2);
      this.particles.spark(mx, my, 12, '#ffffff', C.dir + Math.PI / 2, 1.4, 220);
      this.particles.impact(mx, my, 8, '#ffffff');
      this.hitstop = Math.max(this.hitstop, 0.04);
      this.shake(0.3);
      return;
    }

    if (C.turn === 'player') {
      if (p.weapon === 'nunchaku') this.sfx.nunchakuHit(C.activeTempo > 1.6);
      else if (p.weapon === 'katana' || p.weapon === 'takamura' || p.weapon === 'hayabusa') this.sfx.slashHit(false);
      else if (p.weapon === 'bat' || p.weapon === 'axe') this.sfx.batCrack();
      else if (p.weapon === 'dual') this.sfx.dualHit();
      else this.sfx.punch();

      const bx = e.x - Math.cos(C.dir) * 4, by = e.y - 6;
      if (C.beatOutcome === 'pushed') {
        // Boss LOSES this parry beat: Boss's guard cracks and Boss skids backward across the floor!
        e.sqx = 1.36; e.sqy = 0.68;
        e.flash = 0.09;
        this.shiftClashCenter(e, C.dir, 8.5);
        this.particles.smoke(e.x, e.y + 1, 5, '#9a8f7d', 28, 0.38);
        this.particles.ring(bx, by, 3, 18, '#35f0ff', 0.2, 2);
        this.particles.spark(bx, by, 12, '#35f0ff', C.dir, 1.3, 230);
        this.particles.impact(bx, by, 8, '#ffffff');
        this.texts.add(e.x, e.y - 24, 'BOS TERDESAK!', '#35f0ff', 1, 0.45);
      } else {
        // Boss WINS/HOLDS this parry with varied martial-arts defense (Duck, Hop, Slip Pivot, Lock, or Deflect)!
        e.parryT = Math.min(0.22, C.beatDur * 0.55);
        e.sqx = 1.2; e.sqy = 0.84;
        this.shiftClashCenter(e, C.dir, -5.5);
        this.particles.ring(bx, by, 3, 15, '#ffd700', 0.18, 2);
        this.particles.spark(bx, by, 10, '#ffd700', C.dir + Math.PI, 1.3, 210);
        this.particles.impact(bx, by, 6, '#ffffff');
        const label =
          C.defenseStyle === 'duck' ? 'DUCK WEAVE!' :
          C.defenseStyle === 'hop' ? 'ACRO HOP!' :
          C.defenseStyle === 'pivot' ? 'SLIP PIVOT!' :
          C.defenseStyle === 'lock' ? 'WEAPON LOCK!' : 'DEFLECT!';
        this.texts.add(e.x, e.y - 24, label, '#ffd700', 1, 0.42);
      }
    } else if (C.turn === 'boss') {
      const rw = e.rivalWeapon ?? 'nunchaku';
      if (rw === 'nunchaku') this.sfx.nunchakuHit(C.activeTempo > 1.6);
      else if (rw === 'katana' || rw === 'takamura') this.sfx.slashHit(false);
      else if (rw === 'bat' || rw === 'axe') this.sfx.batCrack();
      else if (rw === 'dual') this.sfx.dualHit();
      else this.sfx.kick();

      const px0 = p.x + Math.cos(C.dir) * 4, py0 = p.y - 6;
      if (C.playerContestedBeat) {
        // Player WINS this parry beat: Player deflects/ducks/pivots/hops and drives Boss back!
        p.parryT = Math.min(0.22, C.beatDur * 0.55);
        p.squash = 0.84;
        this.shiftClashCenter(e, C.dir, 5.5);
        this.particles.ring(px0, py0, 3, 17, '#35f0ff', 0.18, 2);
        this.particles.spark(px0, py0, 11, '#35f0ff', C.dir, 1.3, 220);
        this.particles.impact(px0, py0, 7, '#ffffff');
        const label =
          C.defenseStyle === 'duck' ? 'WEAVE COUNTER!' :
          C.defenseStyle === 'hop' ? 'HOP COUNTER!' :
          C.defenseStyle === 'pivot' ? 'SLIP COUNTER!' :
          C.defenseStyle === 'lock' ? 'TRAP COUNTER!' : 'PERFECT PARRY!';
        this.texts.add(p.x, p.y - 24, label, '#35f0ff', 1, 0.42);
      } else {
        // Player LOSES this parry beat (didn't press in time): Player's guard cracks and Player skids backward!
        C.beatOutcome = 'pushed';
        C.power = Math.max(0, C.power - 8.0);
        p.brakeT = 0.35;
        p.squash = 0.74;
        this.shiftClashCenter(e, C.dir, -8.5);
        this.particles.smoke(p.x, p.y + 1, 5, '#9a8f7d', 28, 0.38);
        this.particles.ring(px0, py0, 3, 15, '#ff4d4d', 0.18, 2);
        this.particles.spark(px0, py0, 11, '#ff6b6b', C.dir + Math.PI, 1.3, 210);
        this.particles.impact(px0, py0, 7, '#ff4d4d');
        this.texts.add(p.x, p.y - 24, 'GUARD GOYAH! [PENCET!]', '#ff6b6b', 1, 0.5);
      }
    } else {
      // Simultaneous weapon clash in the center!
      e.parryT = 0.18; p.parryT = 0.18;
      e.sqx = 1.22; e.sqy = 0.82; p.squash = 0.82;
      this.particles.ring(mx, my, 3, 20, '#ffd700', 0.2, 2);
      this.particles.ring(mx, my, 2, 14, '#35f0ff', 0.18, 1);
      this.particles.spark(mx, my, 14, '#ffffff', C.dir + Math.PI / 2, 1.5, 230);
      this.particles.impact(mx, my, 8, '#ffd700');
      this.texts.add(mx, my - 18, 'CLASH!', '#ffd700', 1, 0.45);
    }

    this.hitstop = Math.max(this.hitstop, C.activeTempo > 1.9 ? 0.012 : 0.024);
    this.shake(C.activeTempo > 1.8 ? 0.28 : 0.2);
  }

  updateClash(raw: number) {
    const C = this.clashDuel!;
    const p = this.player;
    const inp = this.input;
    const e = this.enemies.find((en) => en.id === C.id);
    if (!e || e.dead) { this.endClash(true); return; }

    C.t += raw;
    const LS = this.longMode ? 2.5 : 1;
    p.iframes = 0.3;

    // Smoothly interpolate the moving duel center (cx, cy) and angle (dir) across the dojo floor!
    const followK = 1 - Math.exp(-14 * raw);
    C.cx = lerp(C.cx, C.targetCx, followK);
    C.cy = lerp(C.cy, C.targetCy, followK);
    C.dir += angleDiff(C.targetDir, C.dir) * followK;

    // 1) Read Player single press or rapid presses (LMB, RMB, Space, C, G, E, F)
    const tapped = inp.mouse.pressed || inp.mouse.rpressed || inp.hit(' ') || inp.hit('c') || inp.hit('g') || inp.hit('e') || inp.hit('f');
    if (tapped) {
      const gap = Math.max(0.06, this.time - C.lastPlayerTapAt);
      C.lastPlayerTapAt = this.time;
      // Compute Player press tempo: 1 press slowly = 1.0x (0.40s per beat); fast presses scale up to 2.75x (0.14s per beat)!
      const measuredTempo = gap > 0.44 ? 1.0 : clamp(0.40 / gap, 1.0, 2.75);
      C.playerTempo = lerp(C.playerTempo, measuredTempo, 0.75);

      // Boss AI reacts to your tempo: sometimes matches your speed, or bursts faster!
      const enraged = e.hp < e.maxHp * 0.5;
      C.bossTempo = clamp(C.playerTempo * (enraged ? 1.08 : 0.96) + (C.bossBurstLeft > 0 ? 0.45 : 0), 1.0, 2.75);

      // Pressing during a Boss attack beat parries it cleanly with dynamic footwork and queues your counter-exchange!
      if (C.recoilT <= 0 && C.turn === 'boss' && !C.hitDone && C.u < 0.44 && C.parryTapAt === null) {
        C.parryTapAt = C.u;
        C.playerContestedBeat = true;
        const timedWell = C.u >= 0.16;
        C.beatOutcome = timedWell ? 'perfect' : 'clash';
        C.defenseStyle = this.pickDefenseStyle(C.bMoveKey, C.poseIdx, C.beatOutcome);
      }

      // Queue 1 Player strike (which will automatically trigger 1 Boss response: "saya pencet sekali ya dia pencet sekali")
      C.pendingPlayerReplies = Math.min(2, C.pendingPlayerReplies + 1);

      // Accelerate current beat if player is pressing faster than the current beat duration!
      if (C.turn !== 'idle') {
        C.activeTempo = Math.max(C.activeTempo, C.playerTempo);
        C.beatDur = clamp(0.40 / C.activeTempo, 0.14, 0.46);
      }
    } else {
      const sinceTap = this.time - C.lastPlayerTapAt;
      if (sinceTap > 0.45) C.playerTempo = lerp(C.playerTempo, 1.0, raw * 4);
    }

    if (C.recoilT > 0) {
      this.updateClashRecoil(e, raw);
      return;
    }

    // 2) Advance the current choreographed beat (or wait in tense martial-arts guard if 'idle')
    if (C.turn === 'idle') {
      C.bossIdleWaitT -= raw;
      if (C.pendingPlayerReplies > 0) {
        C.pendingPlayerReplies--;
        C.bossReplyQueued = true;
        this.beginClashBeat(e, 'player', C.playerTempo);
      } else if (C.bossIdleWaitT <= 0) {
        if (C.bossBurstLeft <= 0 && Math.random() < (e.hp < e.maxHp * 0.5 ? 0.55 : 0.38)) {
          C.bossBurstLeft = 2 + Math.floor(Math.random() * 2);
          C.bossTempo = 2.15 + Math.random() * 0.45;
          this.say('BOS MENCET CEPAT! BALAS PARRY!', e.color, 2, 0.9);
        } else if (C.bossBurstLeft <= 0) {
          C.bossTempo = 1.05 + Math.random() * 0.25;
        }
        if (C.bossBurstLeft > 0) C.bossBurstLeft--;
        C.playerContestedBeat = false;
        this.beginClashBeat(e, 'boss', C.bossTempo);
      }
    } else {
      const speedBoost = C.pendingPlayerReplies > 0 && C.u > 0.48 ? 1.45 : 1.0;
      C.u += (raw / C.beatDur) * speedBoost;

      if (!C.hitDone && C.u >= 0.44) {
        C.hitDone = true;
        this.clashImpact(e);
        if (C.recoilT > 0) {
          this.updateClashRecoil(e, raw);
          return;
        }
      }

      if (C.u >= 1) {
        if (C.beatsDone >= C.maxBeats || C.power >= 100 || C.power <= 0) {
          this.endClash(C.power >= 45 && C.power <= 55 ? 'draw' : C.power > 55);
          return;
        }
        if (C.turn === 'player' && C.bossReplyQueued) {
          // 1-for-1 response: Boss immediately answers your strike with 1 strike!
          C.bossReplyQueued = false;
          C.playerContestedBeat = true;
          const replyTempo = Math.max(C.playerTempo, C.bossTempo);
          this.beginClashBeat(e, C.beatsDone === C.maxBeats - 1 ? 'both' : 'boss', replyTempo);
        } else if (C.pendingPlayerReplies > 0) {
          C.pendingPlayerReplies--;
          C.bossReplyQueued = true;
          this.beginClashBeat(e, C.beatsDone === C.maxBeats - 1 ? 'both' : 'player', C.playerTempo);
        } else if (C.bossBurstLeft > 0) {
          C.bossBurstLeft--;
          C.playerContestedBeat = false;
          this.beginClashBeat(e, 'boss', C.bossTempo);
        } else {
          C.turn = 'idle';
          C.u = 0;
          C.bossIdleWaitT = 0.24;
          p.attackPhase = 'none';
          p.moveKey = null;
          p.z = 0;
          e.moveKey = null;
          e.sceneZ = 0;
          e.sceneRot = 0;
        }
      }
    }

    // 3) Dynamic Position, Height (Jump/Duck), & Pose for Winner vs Loser of the Parry Beat!
    const bell = C.turn === 'idle' ? 0 : Math.sin(clamp(C.u, 0, 1) * Math.PI);
    if (C.turn !== 'idle') C.recoilGap *= Math.exp(-10 * raw * C.activeTempo);
    const baseGap = 11.2 * LS + C.recoilGap;
    const sideVec = { x: -Math.sin(C.dir), y: Math.cos(C.dir) };
    const pivotSign = C.poseIdx % 2 === 0 ? 1 : -1;

    // Attacker steps deeply forward; Defender either weaves sideways ('pivot'), holds ground, or skids backward ('pushed')!
    const defBackShift = C.beatOutcome === 'pushed' ? 4.8 * bell * LS : C.defenseStyle === 'pivot' ? 0.5 * bell * LS : 1.8 * bell * LS;
    const defSideShift = C.defenseStyle === 'pivot' && C.beatOutcome !== 'pushed' ? 5.2 * bell * pivotSign * LS : 0;

    const pShift = C.turn === 'player' ? bell * 3.8 * LS : C.turn === 'boss' ? -defBackShift : C.turn === 'both' ? bell * 2.4 * LS : 0;
    const eShift = C.turn === 'boss' ? -bell * 3.8 * LS : C.turn === 'player' ? defBackShift : C.turn === 'both' ? -bell * 2.4 * LS : 0;
    const pSide = C.turn === 'boss' ? defSideShift : 0;
    const eSide = C.turn === 'player' ? -defSideShift : 0;

    const px0 = C.cx - Math.cos(C.dir) * (baseGap - pShift) + sideVec.x * pSide;
    const py0 = C.cy - Math.sin(C.dir) * (baseGap - pShift) + sideVec.y * pSide;
    const ex0 = C.cx + Math.cos(C.dir) * (baseGap + eShift) + sideVec.x * eSide;
    const ey0 = C.cy + Math.sin(C.dir) * (baseGap + eShift) + sideVec.y * eSide;
    for (const [actor, x, y] of [[p, px0, py0], [e, ex0, ey0]] as const) {
      const dx = x - actor.x, dy = y - actor.y;
      const distance = Math.hypot(dx, dy);
      const step = Math.min(1, 220 * LS * raw / Math.max(distance, 0.001));
      moveWithCollision(this.level, actor, dx * step, dy * step);
    }

    p.aim = C.dir; p.facing = Math.cos(C.dir) >= 0 ? 1 : -1;
    e.aim = C.dir + Math.PI; e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
    p.z = 0; e.sceneZ = 0; e.sceneRot = 0;

    // Resolve Defender's varied pose (Winner of Parry vs Loser of Parry)
    const resolveDefenderPose = (w: WeaponKind): { pose: Pose; pt: number; z: number; rot: number } => {
      if (C.beatOutcome === 'pushed') {
        return { pose: C.hitDone ? 'stagger' : this.activeDeflectPose(w, C.poseIdx), pt: clamp(C.u, 0, 1), z: 0, rot: C.hitDone ? -0.26 * bell : 0 };
      }
      switch (C.defenseStyle) {
        case 'duck':
          // Ducking low under a high swing!
          return { pose: 'crouch', pt: 0.3 + 0.6 * bell, z: 0, rot: 0.15 * bell };
        case 'hop':
          // Acrobatic hop over a low sweep!
          return { pose: 'monkeyflip', pt: clamp(C.u * 0.85, 0, 0.85), z: 12 * bell, rot: 0 };
        case 'pivot':
          // Slip-step sideways counter!
          return { pose: this.activeDeflectPose(w, C.poseIdx), pt: 0.25 + 0.55 * bell, z: 0, rot: 0.18 * bell };
        case 'lock':
          // Trapping / redirecting the opponent's weapon arm!
          return { pose: 'grab', pt: 0.2 + 0.7 * bell, z: 0, rot: 0.12 * bell };
        case 'deflect':
        default:
          return { pose: this.activeDeflectPose(w, C.poseIdx), pt: 0.2 + 0.6 * bell, z: 0, rot: 0 };
      }
    };

    if (C.turn === 'player') {
      const pm = MOVES[C.pMoveKey] ?? MOVES.L;
      const def = resolveDefenderPose(e.rivalWeapon ?? 'nunchaku');
      p.moveKey = C.pMoveKey;
      p.attackPhase = 'active';
      p.holdT = 0.1;
      p.holdPose = pm.pose;
      p.holdPoseT = clamp(C.u, 0, 1);
      if (pm.jump) p.z = pm.jump * 0.65 * bell;
      e.moveKey = null;
      e.attackPhase = 'none';
      e.scenePose = def.pose;
      e.sceneT = def.pt;
      e.sceneZ = def.z;
      e.sceneRot = def.rot * e.facing;
      e.pose = def.pose;
      if ((C.activeTempo > 1.5 || C.defenseStyle === 'pivot') && Math.random() < 0.4) {
        this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: pm.pose, poseT: p.holdPoseT }, '#35f0ff', p.lean);
      }
    } else if (C.turn === 'boss') {
      const bm = MOVES[C.bMoveKey] ?? MOVES.L;
      const def = resolveDefenderPose(p.weapon);
      p.moveKey = null;
      p.attackPhase = 'none';
      p.holdT = 0.1;
      p.holdPose = def.pose;
      p.holdPoseT = def.pt;
      p.z = def.z;
      e.moveKey = C.bMoveKey;
      e.attackPhase = 'active';
      e.scenePose = bm.pose;
      e.sceneT = clamp(C.u, 0, 1);
      if (bm.jump) e.sceneZ = bm.jump * 0.65 * bell;
      e.pose = bm.pose;
      if (C.defenseStyle === 'pivot' && C.playerContestedBeat && Math.random() < 0.45) {
        this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: def.pose, poseT: def.pt }, '#35f0ff', p.lean);
      }
      if (C.activeTempo > 1.5 && Math.random() < 0.35) {
        this.addAfterimage({ x: e.x, y: e.y - (e.sceneZ ?? 0), facing: e.facing, aim: e.aim, pose: bm.pose, poseT: e.sceneT }, e.color, { x: Math.cos(e.aim), y: Math.sin(e.aim) });
      }
    } else if (C.turn === 'both') {
      const pm = MOVES[C.pMoveKey] ?? MOVES.L;
      const bm = MOVES[C.bMoveKey] ?? MOVES.L;
      p.moveKey = C.pMoveKey;
      p.attackPhase = 'active';
      p.holdT = 0.1;
      p.holdPose = pm.pose;
      p.holdPoseT = clamp(C.u, 0, 1);
      e.moveKey = C.bMoveKey;
      e.attackPhase = 'active';
      e.scenePose = bm.pose;
      e.sceneT = clamp(C.u, 0, 1);
      e.pose = bm.pose;
    } else {
      p.moveKey = null;
      p.attackPhase = 'none';
      p.holdT = 0.1;
      p.holdPose = p.weapon === 'nunchaku' ? 'n_idle' : p.weapon === 'katana' ? 'k_idle' : p.weapon === 'bat' || p.weapon === 'axe' ? 'a_idle' : p.weapon === 'dual' ? 'd_idle' : p.weapon === 'yoyo' ? 'y2_idle' : 'parry';
      p.holdPoseT = 0.3;
      e.moveKey = null;
      e.attackPhase = 'none';
      e.scenePose = e.rivalWeapon === 'nunchaku' ? 'n_idle' : e.rivalWeapon === 'katana' || e.rivalWeapon === 'takamura' ? 'k_idle' : e.rivalWeapon === 'bat' || e.rivalWeapon === 'axe' ? 'a_idle' : e.rivalWeapon === 'dual' ? 'd_idle' : e.rivalWeapon === 'yoyo' ? 'y2_idle' : 'parry';
      e.sceneT = 0.3;
      e.pose = e.scenePose;
    }

    // 4) Update both fighters' weapon physics at the exact beat tempo!
    const wDt = raw;
    if (this.sfNunOn) {
      if (C.turn === 'player' || C.turn === 'both') {
        const sweepAng = p.aim + (-1.9 + 3.1 * clamp(C.u, 0, 1)) * (C.poseIdx % 2 === 0 ? 1 : -1);
        this.sfNun.update(wDt, p.x, p.y - 4 * LS, sweepAng, this.time, 'idle', LS, { x: p.x + Math.cos(sweepAng) * 10 * LS, y: p.y - 4 * LS + Math.sin(sweepAng) * 8 * LS });
      } else {
        const sk = solvePose(this.playerStickOpts(p.holdPose, p.holdPoseT));
        this.sfNun.update(raw, p.x, p.y - 4 * LS - p.z, p.aim, this.time, 'idle', LS, { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z });
      }
    } else {
      this.updateNunchaku(wDt);
    }
    this.updateKatana(wDt);
    this.updateYoyoV2(wDt);
    updateBossWeaponPhysics(this, e, wDt);

    this.camFocus = { x: C.cx, y: C.cy - 5 };

  }

  endClash(playerWon: boolean | 'draw') {
    const C = this.clashDuel;
    if (!C) return;
    const e = this.enemies.find((en) => en.id === C.id);
    const p = this.player;
    const hits = C.hits;
    const cx = C.cx, cy = C.cy;
    this.clashDuel = null;
    this.cancelPlayerAttack();
    if (e) this.cancelBossAttack(e);
    p.holdT = 0; p.z = 0;
    p.attackPhase = 'none'; p.moveKey = null; p.buffered = null;
    this.cinematic = false;
    this.zoomTarget = BASE_ZOOM;
    this.camFocus = null;
    if (e) {
      e.scenePose = undefined;
      e.sceneZ = 0;
      e.sceneRot = 0;
      e.attackPhase = 'none'; e.moveKey = null; e.comboQueue = [];
    }

    if (playerWon === 'draw') {
      if (e && !e.dead) {
        this.parryDrawRecoil(e, C.recoilMoved > 0 && C.beatOutcome === 'clash' ? 0 : 190);
        this.sfx.clashPing(1.1);
        this.particles.ring(cx, cy - 5, 3, 24, '#dfe5e9', 0.24, 1);
        this.say('IMBANG', '#dfe5e9', 1, 0.6);
        this.clashCd = Math.max(this.clashCd, 1.2);
      }
      return;
    }

    if (!e || e.dead) return;
    if (playerWon) {
      this.sfx.clashFinish();
      this.slow(0.16, 0.55); this.shake(0.3); this.zoomKick = 0.05;
      this.particles.ring(cx, cy - 5, 4, 28, '#35f0ff', 0.28, 1);
      p.focus = Math.min(300, p.focus + 65 * this.stats.focusGain);
      this.addOfa(15); this.score += 250 + hits * 5;
      p.iframes = Math.max(p.iframes, 0.3);
      const w = p.weapon;
      const key = w === 'nunchaku' ? (this.sfNunOn ? 'SF_HEAVY' : 'NLLLL')
        : w === 'katana' || w === 'takamura' || w === 'hayabusa' ? 'KRUN'
        : w === 'bat' ? 'B_HOMER' : w === 'axe' ? 'ALLL'
        : w === 'dual' ? 'DLLLL' : w === 'yoyo' ? 'YLLL' : 'FOCUS';
      this.queueParryRiposte(e, 'player', key);
      this.say('COUNTER', '#35f0ff', 1, 0.6);
    } else {
      this.sfx.clashPing(0.9); this.shake(0.25);
      const w = e.rivalWeapon ?? 'nunchaku';
      const key = w === 'nunchaku' ? 'NLH' : w === 'katana' || w === 'takamura' ? 'KLLLL'
        : w === 'bat' ? 'B_HOMER' : w === 'dual' ? 'DLLLL' : w === 'axe' ? 'ALLL'
        : w === 'yoyo' ? 'YLLL' : 'S5';
      this.queueParryRiposte(e, 'boss', key);
    }
  }

  damagePlayer(dmg: number, dir: number, knockdown = false) {
    if (this.isAttractMode) return;
    const p = this.player;
    if (this.state !== 'playing') return;
    if (p.iframes > 0 || p.dashT > 0 || p.fatality || p.focusDash || this.silat) return;
    if (p.z > 12) { this.texts.add(p.x, p.y - 26 - p.z, 'JUMPED!', '#9be7ff', 1, 0.5); return; }
    if (p.rageOn && Math.random() < 0.5) { this.texts.add(p.x, p.y - 24, 'RAGE', '#ff2a2a', 1, 0.4); return; }
    if (this.stats.dodgeChance > 0 && Math.random() < this.stats.dodgeChance) {
      this.texts.add(p.x, p.y - 24, 'DODGE', '#9be7ff', 1, 0.6);
      this.particles.ring(p.x, p.y - 6, 4, 12, '#9be7ff', 0.2, 1);
      return;
    }
    p.hp -= dmg;
    this.cancelPlayerAttack();
    p.iframes = 1.0; p.flash = 0.15;
    p.kx += Math.cos(dir) * (knockdown ? 260 : 170); p.ky += Math.sin(dir) * (knockdown ? 260 : 170);
    p.stunT = Math.max(p.stunT, knockdown ? 0.35 : 0.18);
    p.attackPhase = 'none'; p.buffered = null; p.comboStr = ''; p.z = 0; p.runT = 0; p.chain = 0; p.rageDash = null; p.styleHeat = Math.max(0, p.styleHeat - 0.4); p.style = 'none'; p.styleStreak = 0; p.rhythm = [];
    this.shake(0.7); this.hitstop = Math.max(this.hitstop, 0.1);
    this.flash('#ff2020', 0.35);
    this.slow(0.2, 0.35);
    this.sfx.hurt();
    this.particles.blood(p.x, p.y - 6, 6, dir, 130);
    this.blood.spray(p.x, p.y - 6, dir, 2 + dmg, knockdown || dmg >= 2);
    this.blood.pool(p.x, p.y + 1, 3);
    this.blood.screenSplat(knockdown || dmg >= 2);
    this.combo = 0;
    if (p.hp <= 0) this.die();
  }

  tryFocus() {
    const p = this.player;
    if (p.focus < 100) { this.texts.add(p.x, p.y - 22, 'NO FOCUS', '#5a7a80', 1, 0.5); this.sfx.empty(); return; }
    let e = this.nearestEnemy(p.x, p.y, 130, p.aim, 1.2);
    if (e && !lineOfSight(this.level, p.x, p.y, e.x, e.y)) e = this.nearestEnemy(p.x, p.y, 60, p.aim, 1.6);
    if (!e) { this.texts.add(p.x, p.y - 22, 'NO TARGET', '#5a7a80', 1, 0.5); this.sfx.empty(); return; }
    p.focus -= 100;
    const a = Math.atan2(e.y - p.y, e.x - p.x);
    const gap = e.r + p.r + 4;
    p.focusDash = { sx: p.x, sy: p.y, tx: e.x - Math.cos(a) * gap, ty: e.y - Math.sin(a) * gap, t: 0, id: e.id };
    p.attackPhase = 'none'; p.buffered = null; p.dashT = 0; p.aim = a; p.z = 0;
    e.stun = Math.max(e.stun, 0.6); e.state = 'stun';
    this.slow(0.6, 0.3);
    this.sfx.focus();
    this.flash(this.pal.accent, 0.2);
    this.particles.ring(p.x, p.y - 6, 2, 30, this.pal.accent, 0.3, 2);
  }

  /** V2 paints the terrain with STICK FIST's exact biome hexes (100% match); V1 keeps game2's zone palettes.
   *  Story levels walk the biome list by zone, survival picks one per arena seed — just like game1's endless. */
  applyPalette(rebuild = false) {
    const zone = this.level.zone;
    const pal = this.v2 ? G1_BIOMES[(this.mode === 'survival' ? this.level.seed : zone) % G1_BIOMES.length] : ZONES[zone].pal;
    if (pal === this.pal && !rebuild) return;
    this.pal = pal;
    this.levelCanvas = buildLevelCanvas(this.level, this.pal, this.v2);
    this.levelCtx = this.levelCanvas.getContext('2d')!;
    this.pools = [];
    this.blood.resetFloor(this.levelCanvas.width, this.levelCanvas.height);
  }

  /** Switches between the classic look (V1) and the crisp/ragdoll update (V2) so both can be compared live. */
  toggleV2() {
    this.v2 = !this.v2;
    this.applyPalette(true);
    try { localStorage.setItem(V2_KEY, this.v2 ? '1' : '0'); } catch { /* private mode */ }
    this.say(this.v2 ? 'V2 - CRISP PIXELS + RAGDOLL' : 'V1 - CLASSIC LOOK', this.v2 ? '#7df9ff' : '#9a9a9a', 2, 1.6);
    this.sfx.select();
    this.pushUI();
  }

  /** LONG-LIMB mode: badan/tangan/kaki 2.5x panjang normal (tombol L atau tombol HUD). */
  toggleLong() {
    this.longMode = !this.longMode;
    try { localStorage.setItem(LONG_KEY, this.longMode ? '1' : '0'); } catch { /* private mode */ }
    this.say(this.longMode ? 'LONG LIMBS - BADAN/TANGAN/KAKI x2.5' : 'NORMAL LIMBS', this.longMode ? '#ffd27f' : '#9a9a9a', 2, 1.6);
    this.sfx.select();
    this.pushUI();
  }

  /** V2 present: one nearest-neighbour blit per layer straight onto the display-sized backing store. An art pixel
   *  is scaled exactly once, which is what keeps edges hard — V1 scaled twice (zoom blit, then CSS) and that
   *  double resample is what made the image look soft and dirty at BASE_ZOOM 1.4. */
  present(sw: number, sh: number) {
    if (!this.v2) return;
    const dst = this.ctx;
    const bw = this.canvas.width || VIEW_W, bh = this.canvas.height || VIEW_H;
    dst.setTransform(1, 0, 0, 1, 0, 0);
    dst.globalAlpha = 1;
    dst.imageSmoothingEnabled = false;
    dst.drawImage(this.scene, 0, 0, sw, sh, 0, 0, bw, bh);
    dst.drawImage(this.hud, 0, 0, VIEW_W, VIEW_H, 0, 0, bw, bh);
  }

  /** ONE FOR ALL (X) — game1's slow-mo super mode. The world drops to 30%, you run on real time,
   *  every strike auto-locks and blinks to the nearest enemy until the meter burns out. */
  tryOfa() {
    const p = this.player;
    if (p.ofaActive || p.fatality || p.focusDash || p.rageDash || p.holdT > 0 || p.stunT > 0) return;
    if (p.ofa < OFA_COST) { this.texts.add(p.x, p.y - 22, 'OFA NOT READY', '#3a6a78', 1, 0.5); this.sfx.empty(); return; }
    p.ofaActive = true;
    this.ofaReadySaid = true;
    this.say('ONE FOR ALL', OFA_COL, 3, 1.2);
    this.sfx.announce(); this.sfx.focus();
    this.flash(OFA_COL, 0.5); this.shake(0.8); this.slow(0.5, 0.25);
    this.particles.shockwave(p.x, p.y - 4, 60, OFA_COL, 0.5);
    this.particles.ring(p.x, p.y - 6, 2, 26, '#ffffff', 0.35, 2);
    p.iframes = Math.max(p.iframes, 0.6);
    if (!this.cinematic) this.zoomTarget = 0.94 * BASE_ZOOM;   // slight zoom-out, same as game1
  }

  /** ONE FOR ALL upkeep: auto-lock the nearest enemy, burn the meter, throw the lightning aura. */
  updateOfa(raw: number) {
    const p = this.player;
    if (!p.ofaActive) { if (this.lockTarget) this.lockTarget = null; return; }
    let best: Enemy | null = null, bd = 340;
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const d = dist(e.x, e.y, p.x, p.y);
      if (d < bd) { bd = d; best = e; }
    }
    this.lockTarget = best;                       // recomputed every frame: a kill jumps the lock on
    p.ofa = Math.max(0, p.ofa - raw * OFA_DRAIN);
    if (Math.random() < 0.85) {
      const a = rnd(0, Math.PI * 2);
      this.particles.spark(p.x + Math.cos(a) * 6, p.y - 6 - p.z + Math.sin(a) * 6, 1, Math.random() < 0.6 ? '#7df9ff' : '#ffffff', a, 0.8, 45);
    }
    if (Math.random() < 0.35) this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim, scale: 1 }, OFA_COL, { x: Math.cos(p.aim), y: Math.sin(p.aim) });
    if (p.ofa <= 0) {
      p.ofa = 0; p.ofaActive = false; this.lockTarget = null; this.ofaReadySaid = false;
      this.say('ONE FOR ALL END', '#8a8a8a', 1, 0.8);
      this.particles.ring(p.x, p.y - 6, 2, 18, OFA_COL, 0.3, 1);
      if (!this.cinematic) this.zoomTarget = BASE_ZOOM;
    }
  }

  /** Adds ONE FOR ALL charge and announces once when X becomes available. */
  addOfa(n: number) {
    const p = this.player;
    if (p.ofaActive || !(n > 0)) return;
    p.ofa = Math.min(100, p.ofa + n);
    if (p.ofa >= OFA_COST && !this.ofaReadySaid) {
      this.ofaReadySaid = true;
      this.say('ONE FOR ALL READY - PRESS X', OFA_COL, 2, 1.4);
      this.sfx.select();
    }
  }

  // ------------------------------------------------------------------ FATALITY
  tryFatality() {
    const p = this.player;
    if (p.fatality || p.stunT > 0) return;
    const ft = this.fatalityTarget();
    if (!ft) { this.texts.add(p.x, p.y - 22, 'NO TARGET', '#777', 1, 0.5); this.sfx.empty(); return; }
    const best = ft.e;
    const perfect = best.stagger > 0;
    if (!perfect && this.fatalityCd > 0) { this.texts.add(p.x, p.y - 22, `FATALITY IN ${this.fatalityCd.toFixed(1)}S`, '#777', 1, 0.5); this.sfx.empty(); return; }
    if (!perfect) this.fatalityCd = Game.FATALITY_CD;
    const a = Math.atan2(best.y - p.y, best.x - p.x);
    const idx = this.fatalityIdx++;
    let kind: FatalityKind;
    if (p.weapon === 'nunchaku') { const pool: FatalityKind[] = ['n_garrote', 'n_drum', 'n_decap']; kind = best.boss ? (idx % 2 === 0 ? 'n_drum' : 'n_decap') : pool[idx % pool.length]; }
    else if (p.weapon === 'axe' || p.weapon === 'bat') kind = idx % 2 === 0 ? 'k_bisect' : 'k_behead';
    else if (p.weapon === 'dual') kind = idx % 2 === 0 ? 'k_behead' : 'k_impale';
    else if (p.weapon === 'katana' || p.weapon === 'takamura' || p.weapon === 'hayabusa') { const pool: FatalityKind[] = ['k_bisect', 'k_behead', 'k_impale']; kind = best.boss ? (idx % 2 === 0 ? 'k_impale' : 'k_bisect') : pool[idx % pool.length]; }
    else if (ft.far || p.running || p.sinceDash < 0.25) { const far: FatalityKind[] = ['runpunch', 'flykick', 'kneedrop']; kind = far[idx % far.length]; }
    else if (best.boss) { const bossPool: FatalityKind[] = ['rush', 'uppercut', 'hammer', 'spinkick']; kind = bossPool[idx % bossPool.length]; }
    else if (best.down > 0) kind = 'stomp';
    else { const pool: FatalityKind[] = ['uppercut', 'neckbreak', 'flykick', 'spinkick', 'rush', 'hammer', 'runpunch', 'kneedrop', 'stomp']; kind = pool[idx % pool.length]; }
    const F: Fatality = { kind, id: best.id, t: 0, step: 0, stepT: 0, sx: p.x, sy: p.y, tx: best.x, ty: best.y, dir: a, hit: false, hitT: 0, perfect };
    p.fatality = F;
    p.attackPhase = 'none'; p.buffered = null; p.dashT = 0; p.parryT = 0; p.focusDash = null; p.z = 0; p.runT = 0; p.running = false;
    p.aim = a; p.attackAim = a; p.facing = Math.cos(a) >= 0 ? 1 : -1; p.vx = p.vy = p.kx = p.ky = 0; p.moving = false;
    p.holdPose = 'crouch'; p.holdPoseT = 0;
    if (['uppercut', 'rush', 'neckbreak', 'spinkick', 'hammer', 'stomp', 'n_garrote', 'n_drum', 'n_decap', 'k_bisect', 'k_behead', 'k_impale'].includes(kind)) {
      const gap = kind === 'stomp' ? best.r + 1 : kind === 'spinkick' || kind === 'n_decap' ? best.r + p.r + 9 : kind.startsWith('k_') ? best.r + p.r + 12 : best.r + p.r + 3;
      const nx = best.x - Math.cos(a) * gap, ny = best.y - Math.sin(a) * gap;
      if (this.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; }
      F.sx = p.x; F.sy = p.y;
    }
    if (kind === 'stomp') { best.down = 10; best.state = 'down'; best.pose = 'down'; }
    // grab the victim: freeze whatever they were doing
    best.stagger = 10; best.state = kind === 'stomp' ? 'down' : 'stagger'; best.pose = kind === 'stomp' ? 'down' : 'stagger'; best.kx = best.ky = 0; best.vx = best.vy = 0; best.z = 0; best.vz = 0;
    if (kind !== 'stomp') best.down = 0;
    best.stun = 0; best.fuse = -1; best.flinch = 0; best.tele = null; this.releaseToken(best);
    this.cinematic = true; this.zoomTarget = 1.45 * BASE_ZOOM; this.camFocus = { x: (p.x + best.x) / 2, y: (p.y + best.y) / 2 };
    this.slowFactor = 0.45; this.slowT = 0.2;
    p.iframes = 6;
    for (const o of this.enemies) if (o !== best && !o.dead) o.attackCd = Math.max(o.attackCd, 1.5);
    this.sfx.announce();
    if (perfect) this.say('PERFECT FATALITY', '#ffd700', 2, 1.0);
  }

  updateFatality(raw: number) {
    const p = this.player;
    const F = p.fatality!;
    const e = this.enemies.find((en) => en.id === F.id);
    const target = e && !e.dead ? e : null;
    this.slowT = Math.max(this.slowT, 0.2);
    this.slowFactor = F.hit ? 0.3 : 0.45;
    if (!F.hit && !target) { this.endFatality(); return; }
    F.t += raw;
    if (target && !F.hit) { target.stagger = 10; if (F.kind === 'stomp') { target.down = 10; target.pose = 'down'; } else target.pose = 'stagger'; F.tx = target.x; F.ty = target.y; }
    this.camFocus = { x: (p.x + F.tx) / 2, y: (p.y + F.ty) / 2 };
    const dir = F.dir, cd = Math.cos(dir), sd = Math.sin(dir);
    const since = F.t - F.hitT;
    // V2: fatality sepas game1 (~0,97 dtk total) — aftermath dipangkas, build lama tetap 1,6-1,7 dtk
    const ks = this.v2 ? 0.35 : 1;
    switch (F.kind) {
      case 'uppercut': {
        if (F.step === 0) {
          p.holdPose = 'crouch'; p.holdPoseT = Math.min(1, F.t / 0.4);
          if (F.t > 0.06 && Math.random() < 0.85) {
            const a = rnd(0, 6.3), r = rnd(8, 18);
            this.particles.add({ x: p.x + cd * 4 + Math.cos(a) * r, y: p.y - 5 + Math.sin(a) * r * 0.6, vx: -Math.cos(a) * 110, vy: -Math.sin(a) * 70, life: 0.2, c: Math.random() < 0.5 ? '#ffd700' : '#ffffff', k: 0, s: 1 });
          }
          if (F.t >= 0.42) {
            F.step = 1; F.stepT = 0;
            this.say('DRAGON UPPERCUT', '#ffd700', 2, 0.8);
            this.particles.dirBurst(p.x + cd * 6, p.y - 6, 14, '#ffffff', -Math.PI / 2, 0.45, 240, 0.35);
            this.particles.smoke(p.x, p.y, 8, '#888', 40, 0.5);
            this.particles.shockwave(p.x, p.y - 4, 22, '#ffd700', 0.28);
            this.finishBlow(target, F);
          }
        } else if (F.step === 1) {
          F.stepT += raw;
          p.holdPose = 'uppercut'; p.holdPoseT = clamp(0.32 + F.stepT * 2.2, 0.32, 0.72);
          this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: 'uppercut', poseT: p.holdPoseT }, '#ffd700', p.lean);
          if (since > 0.55) { F.step = 2; }
        } else { p.holdPose = 'flex'; p.holdPoseT = 0; }
        if (F.hit && since > 1.85 * ks) this.endFatality();
        break;
      }
      case 'runpunch': {
        if (F.step === 0) {
          const q = Math.min(1, F.t / 0.24);
          const bx = F.sx - cd * 18 * easeOut(q), by = F.sy - sd * 18 * easeOut(q);
          if (this.isFree(bx, by, p.r)) { p.x = bx; p.y = by; }
          p.holdPose = 'runpunch'; p.holdPoseT = 0.22 * q;
          if (q > 0.4 && Math.random() < 0.6) this.particles.smoke(p.x - cd * 3, p.y + 1, 1, '#888', 16, 0.3);
          if (F.t >= 0.26) { F.step = 1; this.sfx.dash(); this.say('IRON FIST', '#ffffff', 2, 0.7); this.particles.dirBurst(p.x, p.y, 10, '#cfcfcf', dir + Math.PI, 0.45, 120, 0.32); }
        } else if (F.step === 1) {
          p.holdPose = 'runpunch'; p.holdPoseT = 0.5;
          const o = { x: p.x, y: p.y, r: p.r };
          const m = moveWithCollision(this.level, o, cd * 460 * raw, sd * 460 * raw);
          p.x = o.x; p.y = o.y;
          this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim, pose: 'runpunch', poseT: 0.5 }, '#ffffff', p.lean);
          this.particles.lines(p.x - cd * 8, p.y - 6, 2, '#ffffff', dir + Math.PI, 240);
          if (Math.random() < 0.8) this.particles.smoke(p.x - cd * 4, p.y + 1, 1, '#888', 22, 0.32);
          if (target && !F.hit && dist(p.x, p.y, target.x, target.y) < p.r + target.r + 4) this.finishBlow(target, F);
          if (F.hit && since > 0.14) F.step = 2;
          if (m.bx || m.by || F.t > 1.45) { if (!F.hit) { this.endFatality(); return; } F.step = 2; }
        } else {
          p.holdPose = since > 0.7 * ks ? 'flex' : 'runpunch'; p.holdPoseT = 0.55;
          if (since > 1.75 * ks) this.endFatality();
        }
        break;
      }
      case 'flykick': {
        if (F.step === 0) {
          p.holdPose = 'crouch'; p.holdPoseT = Math.min(1, F.t / 0.28);
          const q = Math.min(1, F.t / 0.24);
          const bx = F.sx - cd * 12 * easeOut(q), by = F.sy - sd * 12 * easeOut(q);
          if (this.isFree(bx, by, p.r)) { p.x = bx; p.y = by; }
          if (F.t >= 0.28) { F.step = 1; F.stepT = 0; this.sfx.launch(); this.say('FLYING KICK', '#ffffff', 2, 0.7); this.particles.smoke(p.x, p.y, 8, '#888', 34, 0.42); this.particles.dirBurst(p.x, p.y, 10, '#cfcfcf', dir + Math.PI, 0.45, 120, 0.32); }
        } else if (F.step === 1) {
          F.stepT += raw;
          p.holdPose = 'flying'; p.holdPoseT = 0.55;
          p.z = 16 * Math.sin(Math.min(1, F.stepT / 0.58) * Math.PI);
          const o = { x: p.x, y: p.y, r: p.r };
          const m = moveWithCollision(this.level, o, cd * 420 * raw, sd * 420 * raw);
          p.x = o.x; p.y = o.y;
          this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: 'flying', poseT: 0.55 }, '#ffffff', p.lean);
          this.particles.lines(p.x - cd * 10, p.y - 8 - p.z, 2, '#ffffff', dir + Math.PI, 220);
          if (target && !F.hit && dist(p.x, p.y, target.x, target.y) < p.r + target.r + 5) this.finishBlow(target, F);
          if ((F.hit && since > 0.14) || m.bx || m.by || F.stepT > 0.7) {
            p.z = 0;
            if (!F.hit) { this.endFatality(); return; }
            F.step = 2;
            this.particles.smoke(p.x, p.y, 8, '#888', 34, 0.42); this.sfx.land(); this.shake(0.28);
          }
        } else {
          p.holdPose = since > 0.75 * ks ? 'flex' : 'crouch';
          if (since > 1.75 * ks) this.endFatality();
        }
        break;
      }
      case 'neckbreak': {
        if (F.step === 0) {
          p.holdPose = 'grab'; p.holdPoseT = F.t / 0.4;
          if (target) { target.pose = 'stagger'; target.x = lerp(target.x, p.x + cd * (p.r + target.r + 2), 0.2); target.y = lerp(target.y, p.y + sd * (p.r + target.r + 2), 0.2); }
          if (F.t >= 0.42) { F.step = 1; this.sfx.whoosh(); this.say('NECK SNAP', '#ff6b6b', 2, 0.7); this.slow(0.18, 0.2); }
        } else if (F.step === 1) {
          p.holdPose = 'grab'; p.holdPoseT = 1;
          if (target) { target.aim += raw * 18 * p.facing; target.facing = Math.cos(target.aim) >= 0 ? 1 : -1; target.flash = 0.08; }
          if (F.t >= 0.62) { F.step = 2; this.finishBlow(target, F); this.particles.spark(p.x + cd * 8, p.y - 10, 10, '#ffffff', dir, 1.1, 200); }
        } else { p.holdPose = since > 0.65 * ks ? 'flex' : 'grab'; p.holdPoseT = 1; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'kneedrop': {
        // leap high (0-0.45 travel toward the target), drop with the knee onto them
        if (F.step === 0) {
          p.holdPose = 'crouch';
          if (F.t >= 0.18) { F.step = 1; F.stepT = 0; this.sfx.launch(); this.say('KNEE DROP', '#ffffff', 2, 0.65); this.particles.smoke(p.x, p.y, 6, '#888', 30, 0.4); }
        } else if (F.step === 1) {
          F.stepT += raw;
          const T = 0.5, q = Math.min(1, F.stepT / T);
          p.holdPose = 'kneedrop'; p.holdPoseT = 0.44 * q;
          const gap = (target ? target.r : 5) + 2;
          const tx = F.tx - cd * gap * 0.3, ty = F.ty - sd * gap * 0.3;
          const nx = lerp(F.sx, tx, q), ny = lerp(F.sy, ty, q);
          if (this.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; }
          p.z = 26 * Math.sin(q * Math.PI);
          this.addAfterimage({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: 'kneedrop', poseT: 0.3 }, this.pal.accent, p.lean);
          if (q >= 1) { p.z = 0; F.step = 2; p.holdPoseT = 0.6; this.finishBlow(target, F); this.particles.shockwave(p.x, p.y, 34, '#ffffff', 0.3); this.particles.smoke(p.x, p.y, 10, '#777', 40, 0.5); }
        } else { p.holdPose = since > 0.9 * ks ? 'flex' : 'kneedrop'; p.holdPoseT = since > 0.9 * ks ? 0 : 0.6; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'spinkick': {
        if (F.step === 0) {
          p.holdPose = 'spin'; p.holdPoseT = 0.08 + 0.2 * Math.min(1, F.t / 0.28);
          if (F.t >= 0.28) { F.step = 1; F.stepT = 0; this.sfx.swing(0.65); this.say('SPIN KICK', '#ffffff', 2, 0.65); }
        } else if (F.step === 1) {
          F.stepT += raw;
          p.holdPose = 'spin'; p.holdPoseT = 0.18 + 0.55 * Math.min(1, F.stepT / 0.34);
          this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim + F.stepT * 14, pose: 'spin', poseT: p.holdPoseT }, '#ffffff', p.lean);
          if (F.stepT >= 0.34) { F.step = 2; this.finishBlow(target, F); this.particles.dirBurst(p.x + cd * 8, p.y - 6, 10, '#ffffff', dir, 0.8, 180, 0.3); }
        } else { p.holdPose = since > 0.7 * ks ? 'flex' : 'spin'; p.holdPoseT = since > 0.7 * ks ? 0 : 0.7; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'stomp': {
        // victim is on the ground: raise the knee (0-0.4), stomp the head
        if (F.step === 0) {
          p.holdPose = 'stomp'; p.holdPoseT = 0.5 * Math.min(1, F.t / 0.4);
          if (F.t >= 0.42) { F.step = 1; F.stepT = 0; }
        } else if (F.step === 1) {
          F.stepT += raw;
          p.holdPose = 'stomp'; p.holdPoseT = 0.5 + 0.1 * Math.min(1, F.stepT / 0.07);
          if (F.stepT >= 0.07) { F.step = 2; this.finishBlow(target, F); this.particles.shockwave(p.x + cd * 6, p.y, 24, '#ffffff', 0.25); }
        } else { p.holdPose = since > 0.8 * ks ? 'flex' : 'stomp'; p.holdPoseT = since > 0.8 ? 0 : 0.6; if (since > 1.6 * ks) this.endFatality(); }
        break;
      }
      case 'hammer': {
        // both fists overhead (0-0.4), slam down on the skull
        if (F.step === 0) {
          p.holdPose = 'hammer'; p.holdPoseT = 0.45 * Math.min(1, F.t / 0.4);
          if (F.t > 0.1 && Math.random() < 0.6) this.particles.add({ x: p.x + rnd(-6, 6), y: p.y - 16 + rnd(-4, 4), vx: 0, vy: -40, life: 0.2, c: '#ffd700', k: 0, s: 1 });
          if (F.t >= 0.42) { F.step = 1; F.stepT = 0; this.say('HAMMER FIST', '#ffd700', 2, 0.65); }
        } else if (F.step === 1) {
          F.stepT += raw;
          p.holdPose = 'hammer'; p.holdPoseT = 0.45 + 0.15 * Math.min(1, F.stepT / 0.08);
          if (F.stepT >= 0.08) { F.step = 2; this.finishBlow(target, F); this.particles.shockwave(p.x + cd * 8, p.y, 30, '#ffffff', 0.3); }
        } else { p.holdPose = since > 0.8 * ks ? 'flex' : 'hammer'; p.holdPoseT = since > 0.8 ? 0 : 0.6; if (since > 1.6 * ks) this.endFatality(); }
        break;
      }
      case 'n_garrote': {
        // whip the chain around the neck, pull tight (victim thrashes), snap
        if (F.step === 0) {
          p.holdPose = 'n_garrote'; p.holdPoseT = F.t / 0.3;
          if (F.t >= 0.3) { F.step = 1; this.sfx.chainRattle(); }
        } else if (F.step === 1) {
          p.holdPose = 'n_garrote'; p.holdPoseT = 1;
          if (target) { target.x = F.tx + Math.sin(F.t * 40) * 1.5; target.flash = Math.sin(F.t * 30) > 0 ? 0.05 : 0; }
          if (F.t >= 0.95) { F.step = 2; this.finishBlow(target, F); }
        } else { p.holdPose = since > 0.7 * ks ? 'flex' : 'n_garrote'; p.holdPoseT = 1; if (since > 1.6 * ks) this.endFatality(); }
        break;
      }
      case 'n_drum': {
        // skull drum: 10 rapid overhead cracks, then the big one
        p.holdPose = 'n_drum'; p.holdPoseT = F.t;
        if (F.step < 10) {
          if (target && F.t > 0.1 + F.step * 0.07) {
            F.step++; target.flash = 0.05;
            const hx = target.x + rnd(-2, 2), hy = target.y - 12 * target.scale + rnd(-2, 2);
            this.particles.spark(hx, hy, 4, '#ffffff', -Math.PI / 2, 1, 160); this.particles.blood(hx, hy, 4, -Math.PI / 2, 110); this.particles.impact(hx, hy, 3, '#ffffff');
            this.sfx.nunchakuHit(false); this.hitstop = Math.max(this.hitstop, 0.012); this.shake(0.2); this.addCombo();
            target.y += 0.4; // driven into the ground
          }
        } else if (F.step === 10) {
          p.holdPose = 'n_overhead'; p.holdPoseT = 0.2;
          if (F.t > 0.1 + 10 * 0.07 + 0.3) { F.step = 11; p.holdPoseT = 0.45; this.finishBlow(target, F); }
        } else { p.holdPose = since > 0.8 * ks ? 'flex' : 'n_overhead'; p.holdPoseT = 0.5; if (since > 1.6 * ks) this.endFatality(); }
        break;
      }
      case 'n_decap': {
        // helicopter spin-up, then the chain takes the head clean off
        p.holdPose = 'n_helicopter'; p.holdPoseT = F.t;
        if (F.step === 0) { if (F.t >= 0.6) { F.step = 1; this.finishBlow(target, F); } }
        else { p.holdPose = since > 0.8 * ks ? 'flex' : 'n_helicopter'; if (since > 1.6 * ks) this.endFatality(); }
        break;
      }
      case 'k_bisect': {
        // jodan raise (0-0.45), vertical cut; the body splits after a beat
        if (F.step === 0) {
          p.holdPose = 'k_heaven'; p.holdPoseT = 0.3 * Math.min(1, F.t / 0.45);
          p.bladeA = p.aim - 1.5 * p.facing;
          if (F.t >= 0.47) { F.step = 1; F.stepT = 0; this.sfx.slash(0.6); }
        } else if (F.step === 1) {
          F.stepT += raw; p.holdPose = 'k_heaven'; p.holdPoseT = 0.3 + 0.3 * Math.min(1, F.stepT / 0.08); p.bladeA = p.aim + 0.4 * p.facing;
          if (F.stepT >= 0.09) { F.step = 2; this.finishBlow(target, F); }
        } else { p.holdPose = since > 0.9 * ks ? 'k_sheathe' : 'k_heaven'; p.holdPoseT = since > 0.9 * ks ? Math.min(1, (since - 0.9) / 0.5) : 0.62; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'k_behead': {
        // horizontal crescent at neck height
        if (F.step === 0) {
          p.holdPose = 'k_crescent'; p.holdPoseT = 0.28 * Math.min(1, F.t / 0.35); p.bladeA = p.aim + 2.2 * p.facing;
          if (F.t >= 0.37) { F.step = 1; F.stepT = 0; this.sfx.slash(1.1); const sk = solvePose(this.playerStickOpts('k_crescent', 0.4)); this.katana.addArc(p.x + sk.fhand.x, p.y + sk.fhand.y, 30, p.aim + 2.2 * p.facing, p.aim - 1.4 * p.facing, '#ffffff', 0.5, 0.3); }
        } else if (F.step === 1) {
          F.stepT += raw; const q = Math.min(1, F.stepT / 0.08); p.holdPose = 'k_crescent'; p.holdPoseT = 0.28 + 0.32 * q; p.bladeA = p.aim + (2.2 - 3.6 * q) * p.facing;
          if (F.stepT >= 0.09) { F.step = 2; this.finishBlow(target, F); }
        } else { p.holdPose = since > 0.9 * ks ? 'k_sheathe' : 'k_crescent'; p.holdPoseT = since > 0.9 * ks ? Math.min(1, (since - 0.9) / 0.5) : 0.6; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'k_impale': {
        // thrust through the chest, lift them on the blade, flick them off
        if (F.step === 0) {
          p.holdPose = 'k_thrust'; p.holdPoseT = 0.3 * Math.min(1, F.t / 0.3); p.bladeA = p.aim;
          if (F.t >= 0.32) { F.step = 1; F.stepT = 0; this.sfx.slashHit(true); this.particles.blood(F.tx, F.ty - 6, 20, F.dir, 120); this.hitstop = Math.max(this.hitstop, 0.08); this.shake(0.5); }
        } else if (F.step === 1) {
          F.stepT += raw; const q = Math.min(1, F.stepT / 0.6);
          p.holdPose = 'k_impale'; p.holdPoseT = q; p.bladeA = p.aim - 0.9 * q * p.facing * 0.5 - 0.5 * q;
          if (target) { target.z = 10 * q; target.pose = 'launched'; target.rot = 0.6 * q * p.facing; target.x = p.x + cd * (target.r + p.r + 10); target.y = p.y + sd * (target.r + p.r + 10) + 0.01; if (Math.random() < 0.6) this.particles.blood(target.x, target.y - 6 - target.z, 2, Math.PI / 2, 40); }
          if (F.stepT >= 0.65) { F.step = 2; this.finishBlow(target, F); }
        } else { p.holdPose = since > 0.9 * ks ? 'k_sheathe' : 'k_impale'; p.holdPoseT = since > 0.9 * ks ? Math.min(1, (since - 0.9) / 0.5) : 1; if (since > 1.7 * ks) this.endFatality(); }
        break;
      }
      case 'rush': {
        p.holdPose = F.step < 14 ? 'rush' : 'palm'; p.holdPoseT = F.t;
        if (F.step === 0 && F.t < 0.12) this.say('CHAIN PUNCH', '#ffffff', 2, 0.7);
        if (F.step < 14) {
          if (target && F.t > 0.08 + F.step * 0.048) {
            F.step++;
            target.flash = 0.06;
            const hx = target.x - cd * target.r + rnd(-2, 2), hy = target.y - 6 - sd * target.r + rnd(-3, 3);
            this.particles.spark(hx, hy, 6, '#ffffff', dir, 1, 200);
            this.particles.blood(hx, hy, 3, dir, 110);
            this.particles.impact(hx, hy, 4, '#ffffff');
            this.addAfterimage({ x: p.x, y: p.y, facing: p.facing, aim: p.aim, pose: 'rush', poseT: F.t }, '#ffffff', p.lean);
            if (F.step % 2) this.sfx.punch(); else this.sfx.kick();
            this.sfx.hit();
            this.hitstop = Math.max(this.hitstop, 0.016); this.shake(0.22); this.addCombo();
            target.x += cd * 0.7; target.y += sd * 0.7;
          }
        } else if (F.step === 14) {
          p.holdPose = 'palm'; p.holdPoseT = 0.2;
          if (F.t > 0.08 + 14 * 0.048 + 0.28) {
            F.step = 15; p.holdPoseT = 0.5;
            this.say('TWIN PALM', '#ffd700', 2, 0.7);
            this.finishBlow(target, F);
            this.particles.shockwave(p.x + cd * 10, p.y - 4, 44, '#ffffff', 0.38);
          }
        } else {
          p.holdPose = since > 0.7 * ks ? 'flex' : 'palm'; p.holdPoseT = 0.55;
          if (since > 1.7 * ks) this.endFatality();
        }
        break;
      }
    }
  }

  finishBlow(e: Enemy | null, F: Fatality) {
    F.hit = true; F.hitT = F.t;
    const p = this.player;
    const dir = F.dir, cd = Math.cos(dir), sd = Math.sin(dir);
    this.hitstop = Math.max(this.hitstop, 0.14); this.flash('#ffffff', 0.4); this.shake(1); this.zoomKick = 0.1;
    this.sfx.fatality(); this.sfx.heavy(); this.sfx.kill();
    this.fatalityTextT = 1.8;
    if (!e || e.dead) return;
    const hx = e.x - cd * e.r, hy = e.y - 6 - sd * e.r;
    this.particles.impact(hx, hy, 12, '#ffffff');
    this.particles.spark(hx, hy, 16, '#ffffff', dir, 1.2, 260);
    this.blood.arterial(hx, hy, dir, 1.0); this.blood.fountain(e.x, e.y - 6, 16); this.blood.mist(hx, hy, dir, 6);
    p.focus = Math.min(300, p.focus + (F.perfect ? 60 : 30) * this.stats.focusGain);
    this.addOfa(F.perfect ? 10 : 6);
    if (F.perfect) this.heal(1 + this.stats.takedownHeal);
    this.score += F.perfect ? 150 : 75;
    p.iframes = Math.max(p.iframes, 2.5);
    if (e.boss) {
      const pct = F.perfect ? 0.28 : Math.max(0.1, 0.16 * Math.pow(0.75, e.fatalCount));
      e.fatalCount++;
      const dmg = e.maxHp * pct * this.ageDmg();
      e.stagger = 0; e.structure = 0;
      if (e.hp > dmg && e.hp > e.maxHp * 0.22) {
        this.damageEnemy(e, dmg, 0, dir, F.kind === 'runpunch' || F.kind === 'flykick' ? 600 : 250, { knockdown: true, hitstop: 0.1, shake: 0.9, melee: false, launch: F.kind === 'uppercut' ? 280 : 100 });
        this.particles.blood(hx, hy, 48, dir, 220);
        this.particles.fountain(e.x, e.y - 8, 14);
        this.splat(e.x, e.y, 20);
        this.texts.add(e.x, e.y - 30, F.perfect ? 'DEVASTATING!' : `-${Math.round(pct * 100)}%`, '#ffd700', 2, 1.2);
        return;
      }
      // Lethal Fatality on Boss! Trigger boss defeated celebration + full fatality gore below
      this.slow(1.4, 0.2);
      this.flash('#ffffff', 0.6);
      this.shake(1);
      this.say('BOSS DEFEATED!', '#ffd700', 3, 2.2);
      this.deathCounter = 1;
      this.score += 500;
      this.bossBeatenT = 2;
      for (let i = 0; i < 3; i++) this.particles.shockwave(e.x, e.y - 6, 60 + i * 30, this.pal.accent, 0.6 + i * 0.2);
    }
    e.dead = true; this.kills++; this.score += Math.round(e.value * 2 * this.comboMult()); this.addCombo(3); this.dropLoot(e, true);
    this.addPool(e.x, e.y + 1, 7 + e.scale * 3);
    const corpse = (vx: number, vy: number, vz: number, spin: number): Corpse => ({ x: e.x, y: e.y, rot: 0, color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory, vx, vy, spin, t: 0, z: 1, vz, gib: true, bounces: 0 });
    switch (F.kind) {
      case 'uppercut':
        this.particles.blood(hx, hy, 20, -Math.PI / 2, 200);
        this.particles.fountain(e.x, e.y - 8, 16);
        this.corpses.push(corpse(cd * 40, sd * 40, 340, 16));
        this.particles.head(e.x, e.y - 10, cd * 30 + rnd(-20, 20), sd * 30, 300, e.color);
        this.splat(e.x, e.y, 14);
        break;
      case 'runpunch':
        this.gibAt(e.x, e.y, e.color, e.scale, dir, 1.5);
        for (let i = 0; i < 12; i++) this.stamp(e.x + cd * i * 5 + rnd(-3, 3), e.y + sd * i * 5 + rnd(-3, 3), '#8a0000', 2);
        this.particles.head(e.x, e.y - 10, cd * 260, sd * 260, 160, e.color);
        break;
      case 'flykick':
        this.particles.blood(hx, hy, 20, dir, 220);
        this.corpses.push(corpse(cd * 560, sd * 560, 70, 14));
        this.particles.head(e.x, e.y - 10, cd * 200 + rnd(-40, 40), sd * 200, 200, e.color);
        break;
      case 'rush':
        this.gibAt(e.x, e.y, e.color, e.scale, dir, 1.2);
        this.particles.head(e.x, e.y - 10, cd * 150, sd * 150 - 60, 220, e.color);
        break;
      case 'neckbreak': {
        // snap: body crumples in place, head stays at an impossible angle then rolls off
        this.sfx.stagger(); this.sfx.heavy();
        this.particles.blood(hx, hy, 10, dir, 60);
        this.corpses.push({ x: e.x, y: e.y, rot: dir + Math.PI / 2, color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory, vx: cd * 20, vy: sd * 20, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        this.particles.head(e.x, e.y - 10, -cd * 40 + rnd(-15, 15), -sd * 40, 90, e.color);
        this.particles.fountain(e.x, e.y - 8, 10);
        this.splat(e.x, e.y, 12);
        break;
      }
      case 'kneedrop':
        this.gibAt(e.x, e.y, e.color, e.scale, -Math.PI / 2, 1.1);
        this.particles.blood(e.x, e.y - 4, 24, rnd(0, 6.3), 150);
        this.particles.head(e.x, e.y - 10, cd * 60 + rnd(-40, 40), sd * 60 + rnd(-40, 40), 260, e.color);
        break;
      case 'spinkick':
        this.particles.blood(hx, hy, 26, dir + 0.4 * p.facing, 240);
        this.particles.head(e.x, e.y - 10, cd * 330, sd * 330, 140, e.color);
        this.corpses.push(corpse(cd * 300, sd * 300, 160, 18));
        this.splat(e.x, e.y, 10);
        break;
      case 'stomp':
        this.particles.blood(e.x + cd * 6, e.y - 2, 30, dir, 170);
        this.particles.blood(e.x + cd * 6, e.y - 2, 20, dir + Math.PI, 110);
        this.splat(e.x + cd * 6, e.y, 30);
        this.addPool(e.x + cd * 4, e.y + 1, 9);
        this.corpses.push({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: 'none', vx: 0, vy: 0, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        for (let i = 0; i < 5; i++) this.particles.limb(e.x + cd * 6, e.y - 2, rnd(0, 6.3), 120, '#d40000', 2);
        break;
      case 'n_garrote': {
        this.sfx.stagger(); this.sfx.chainRattle();
        this.particles.blood(e.x, e.y - 10, 14, -Math.PI / 2, 80);
        this.corpses.push({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory, vx: cd * 10, vy: sd * 10, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        this.particles.head(e.x, e.y - 10, cd * 20, sd * 20, 140, e.color);
        this.addPool(e.x, e.y + 1, 7);
        break;
      }
      case 'n_drum':
        this.gibAt(e.x, e.y, e.color, e.scale, -Math.PI / 2, 1.2);
        this.particles.fountain(e.x, e.y - 6, 20);
        this.splat(e.x, e.y, 30); this.addPool(e.x, e.y + 1, 10);
        break;
      case 'n_decap': {
        this.sfx.nunchakuHit(true);
        this.particles.fountain(e.x, e.y - 10, 24);
        this.particles.head(e.x, e.y - 10, cd * 260 + rnd(-30, 30), sd * 260, 220, e.color);
        this.corpses.push({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: 'none', vx: cd * 30, vy: sd * 30, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        this.addPool(e.x, e.y + 1, 9);
        break;
      }
      case 'k_bisect': {
        this.sfx.slashHit(true);
        const sa = dir + Math.PI / 2;
        this.particles.blood(e.x, e.y - 8, 30, sa, 170); this.particles.blood(e.x, e.y - 8, 30, sa + Math.PI, 170);
        this.particles.lines(e.x, e.y - 8, 6, '#ffffff', -Math.PI / 2, 120);
        const half = (vx: number, vy: number): Corpse => ({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: e.accessory, vx, vy, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        this.corpses.push(half(Math.cos(sa) * 70, Math.sin(sa) * 70)); this.corpses.push(half(Math.cos(sa + Math.PI) * 70, Math.sin(sa + Math.PI) * 70));
        this.splat(e.x, e.y, 28); this.addPool(e.x, e.y + 1, 10);
        break;
      }
      case 'k_behead': {
        this.sfx.slashHit(true);
        this.particles.fountain(e.x, e.y - 10, 26);
        this.particles.head(e.x, e.y - 10, cd * 120 + rnd(-30, 30), sd * 120, 260, e.color);
        // body stands for a moment then drops
        this.corpses.push({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: 'none', vx: cd * 15, vy: sd * 15, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        this.addPool(e.x, e.y + 1, 9);
        break;
      }
      case 'k_impale': {
        this.sfx.slashHit(true); this.sfx.whoosh();
        this.particles.blood(e.x, e.y - 10, 24, dir, 160);
        this.corpses.push(corpse(cd * 380, sd * 380, 140, 10));
        this.splat(e.x, e.y, 14);
        break;
      }
      case 'hammer':
        this.particles.blood(hx, hy, 34, -Math.PI / 2 + rnd(-0.5, 0.5), 200);
        this.particles.fountain(e.x, e.y - 6, 18);
        this.splat(e.x, e.y, 24);
        this.addPool(e.x, e.y + 1, 9);
        // body hammered flat into the floor
        this.corpses.push({ x: e.x, y: e.y, rot: dir, color: e.color, color2: e.color2, scale: e.scale, accessory: 'none', vx: 0, vy: 0, spin: 0, t: 0, z: 0, vz: 0, gib: false, bounces: 0 });
        for (let i = 0; i < 6; i++) this.particles.limb(e.x, e.y - 4, rnd(0, 6.3), 140, e.color, 3);
        break;
    }
  }

  endFatality() {
    const p = this.player;
    p.fatality = null; p.holdT = 0; p.z = 0; p.iframes = Math.max(0.5, Math.min(p.iframes, 1));
    this.cinematic = false; this.zoomTarget = BASE_ZOOM; this.camFocus = null; this.slowT = 0;
  }

  // ------------------------------------------------------------------ physics
  physics(dt: number) {
    const es = this.enemies;
    for (const e of es) {
      if (e.dead || e.spawnT > 0) continue;
      unstick(this.level, e);
      const kSpeed = Math.hypot(e.kx, e.ky);
      const { bx, by } = moveWithCollision(this.level, e, (e.vx + e.kx) * dt, (e.vy + e.ky) * dt);
      if (bx || by) {
        if (kSpeed > 170 && e.state !== 'parryRecoil') this.wallSlam(e, kSpeed);
        if (e.state === 'charge') {
          e.state = 'stun'; e.stun = 1.4; e.structure += 70; e.pose = 'hurt';
          this.shake(1); this.sfx.slam(); this.hitstop = Math.max(this.hitstop, 0.06);
          this.particles.smoke(e.x, e.y, 16, '#888', 60, 0.7);
          this.particles.burst(e.x, e.y - 6, 20, this.pal.wallTop, 160, 0.6, 2, 3);
          this.say('CRASH!', '#ffd700', 2, 0.8);
          if (e.structure >= e.maxStructure) this.staggerEnemy(e);
        }
        const bounce = this.v2 ? -0.35 : -0.25;   // V2: bodies spring off the wall harder (game1 feel)
        if (bx) e.kx *= bounce;
        if (by) e.ky *= bounce;
      }
      if (kSpeed > 150 && e.state !== 'parryRecoil') {
        for (const pr of this.props) {
          if (pr.dead || pr.hp <= 0 || dist(e.x, e.y, pr.x, pr.y) > e.r + pr.r) continue;
          const a = Math.atan2(e.ky, e.kx);
          this.damageProp(pr, 10, a);
          this.damageEnemy(e, 2, 20, a + Math.PI, 40, { knockdown: true, hitstop: 0.03, shake: 0.2, melee: false });
          e.kx *= 0.3; e.ky *= 0.3;
          this.texts.add(e.x, e.y - 22, 'CRASH!', this.pal.accent2, 1, 0.6);
        }
      }
      // bleeding trail while being knocked around
      if (e.flinch > 0 && kSpeed > 90 && e.z <= 0 && Math.random() < 0.7) this.stamp(e.x + rnd(-3, 3), e.y + rnd(-1, 3), Math.random() < 0.3 ? '#5e0000' : '#8a0000', Math.random() < 0.35 ? 2 : 1);
      const f = Math.max(0, 1 - (e.z > 0 ? 1.2 : 6) * dt);
      e.kx *= f; e.ky *= f;
      if (Math.abs(e.kx) < 1) e.kx = 0;
      if (Math.abs(e.ky) < 1) e.ky = 0;
    }
    for (let i = 0; i < es.length; i++) {
      const a = es[i];
      if (a.dead || a.spawnT > 0) continue;
      for (let j = i + 1; j < es.length; j++) {
        const b = es[j];
        if (b.dead || b.spawnT > 0) continue;
        if ((a.z > 6) !== (b.z > 6)) continue;
        const d = dist(a.x, a.y, b.x, b.y), min = a.r + b.r;
        if (d >= min || d < 0.01) continue;
        const nx = (b.x - a.x) / d, ny = (b.y - a.y) / d, o = (min - d) * 0.5;
        const wa = b.r / (a.r + b.r), wb = a.r / (a.r + b.r);
        if (this.isFree(a.x - nx * o * wa * 2, a.y - ny * o * wa * 2, a.r)) { a.x -= nx * o * wa * 2; a.y -= ny * o * wa * 2; }
        if (this.isFree(b.x + nx * o * wb * 2, b.y + ny * o * wb * 2, b.r)) { b.x += nx * o * wb * 2; b.y += ny * o * wb * 2; }
        const ka = Math.hypot(a.kx, a.ky), kb = Math.hypot(b.kx, b.ky);
        if (ka > 180 && b.flash <= 0) this.bowl(a, b);
        else if (kb > 180 && a.flash <= 0) this.bowl(b, a);
      }
    }
  }
  bowl(mover: Enemy, hit: Enemy) {
    const a = Math.atan2(hit.y - mover.y, hit.x - mover.x);
    const sp = Math.hypot(mover.kx, mover.ky);
    mover.kx *= 0.4; mover.ky *= 0.4;
    this.damageEnemy(hit, 2 + sp / 80, 25, a, sp * 0.8, { knockdown: true, hitstop: 0.03, shake: 0.2, melee: false });
    this.damageEnemy(mover, 1, 10, a + Math.PI, 20, { knockdown: true, hitstop: 0.0, shake: 0, melee: false });
    this.say('BOWLING!', this.pal.accent2, 1, 0.6);
    this.particles.spark(hit.x, hit.y - 6, 6, '#ffffff', a, 1, 150);
    this.particles.impact(hit.x, hit.y - 6, 6, '#ffffff');
  }
  wallSlam(e: Enemy, speed: number) {
    // V2 borrows game1's wall slam: it hurts much more, breaks posture, and leaves the victim wobbling.
    const dmg = this.v2 ? 7 + speed / 26 : 3 + speed / 70;
    e.hp -= dmg;
    e.flash = 0.12;
    e.structure += (this.v2 ? 65 : 35) * this.stats.structureDmg;
    this.sfx.slam();
    this.shake(this.v2 ? 0.9 : 0.5);
    this.hitstop = Math.max(this.hitstop, this.v2 ? 0.09 : 0.05);
    if (this.v2) {
      const dir = Math.atan2(-e.ky, -e.kx);
      this.particles.spark(e.x, e.y - 6 - e.z, 12, '#ffffff', dir, 1.4, 250);
      this.particles.ring(e.x, e.y - 6 - e.z, 2, 16, '#ffffff', 0.2, 1);
    }
    this.particles.smoke(e.x, e.y, 8, '#999', 40, 0.5);
    this.particles.burst(e.x, e.y - 6, 10, this.pal.wallTop, 120, 0.5, 2, 3);
    this.particles.blood(e.x, e.y - 6, 18, Math.atan2(-e.ky, -e.kx), 110);
    this.particles.impact(e.x, e.y - 6 - e.z, 8, '#ffffff');
    // blood splatter on the wall itself
    const kl = Math.hypot(e.kx, e.ky) || 1;
    const wx = e.x + (e.kx / kl) * 8, wy = e.y - 6 + (e.ky / kl) * 8;
    this.splat(wx, wy, 16, '#8a0000', true);
    for (let i = 0; i < 6; i++) this.stamp(wx + rnd(-4, 4), wy + i * 2, '#6e0000', 1, true);
    this.say('WALL SLAM!', this.pal.accent2, this.v2 ? 2 : 1, this.v2 ? 0.9 : 0.7);
    this.score += this.v2 ? 25 : 15;
    this.addCombo();
    if (e.z > 0) e.vz = Math.min(e.vz, 0);
    if (e.hp <= 0) { this.killEnemy(e, Math.atan2(-e.ky, -e.kx), 300, false, true); return; }
    if (e.structure >= e.maxStructure && e.stagger <= 0) this.staggerEnemy(e);
    else if (this.v2 && speed > 240 && !e.boss && e.z <= 0) {
      // V2 hard slam (game1): peeled off the wall and left standing, swaying, stars round the head.
      // Softer slams keep game2's knockdown — and thanks to updateEnemy they wake up dizzy anyway.
      e.stun = Math.max(e.stun, 0.55 + speed / 800);
      e.state = 'stun'; e.pose = 'hurt'; e.down = 0;
      e.sqx = 1.4; e.sqy = 0.6;
      e.attackCd = Math.max(e.attackCd, e.stun + 0.35);
      e.vx = 0; e.vy = 0;
      if (Math.random() < 0.6) this.texts.add(e.x, e.y - 24 - e.z, 'BONK!', '#ffffff', 1, 0.5);
    }
    else if (!e.boss && e.stagger <= 0 && e.z <= 0) { e.down = 1.2; e.state = 'down'; }
    else if (e.boss) { e.stun = Math.max(e.stun, 0.5); e.state = 'stun'; }
  }

  // ------------------------------------------------------------------ bullets
  fireEnemyBullet(e: Enemy, angle: number, speed: number, dmg: number, kind: Bullet['kind'], color: string) {
    const hx = e.x + Math.cos(e.aim) * 8 * e.scale, hy = e.y - 7 * e.scale + Math.sin(e.aim) * 6;
    this.bullets.push({ x: hx, y: hy, px: hx, py: hy, vx: Math.cos(angle) * speed, vy: Math.sin(angle) * speed, r: kind === 'orb' ? 3 : 2, dmg, owner: 'enemy', life: 3, color, pierce: 0, bounce: 0, kind, hitIds: [], structure: 0, kb: 0 });
    this.particles.spark(hx, hy, 3, color, angle, 0.4, 120);
    // enemy muzzle flash
    this.enemyMuzzles.push({ x: hx, y: hy, a: angle, t: 0.06, c: color });
    if (this.enemyMuzzles.length > 24) this.enemyMuzzles.shift();
    if (kind !== 'sniper') this.sfx.enemyShot();
    if (kind !== 'orb') this.particles.casing(e.x, e.y - 6, e.aim, e.facing);
  }
  throwBomb(e: Enemy, tx: number, ty: number, dmg: number) {
    const T = 0.9;
    this.bullets.push({ x: e.x, y: e.y - 8, px: e.x, py: e.y, vx: (tx - e.x) / T, vy: (ty - e.y) / T, r: 3, dmg, owner: 'enemy', life: T, color: '#222', pierce: 0, bounce: 0, kind: 'bomb', hitIds: [], structure: 0, kb: 0, z: 0, vz: 180 });
  }
  updateBullets(dt: number) {
    const p = this.player;
    const bs = this.bullets;
    for (let i = bs.length - 1; i >= 0; i--) {
      const b = bs[i];
      b.px = b.x; b.py = b.y;
      b.life -= dt;
      if (b.kind === 'bomb') {
        b.x += b.vx * dt; b.y += b.vy * dt; b.z = (b.z ?? 0) + (b.vz ?? 0) * dt; b.vz = (b.vz ?? 0) - 400 * dt;
        if (b.life <= 0) {
          this.explode(b.x, b.y, 28, b.dmg, false);
          this.addHazard({ x: b.x, y: b.y, r: 20, maxR: 0.3, life: 2.6, kind: 'fire', dmg: 1 });
          bs.splice(i, 1);
        }
        continue;
      }
      const sp = Math.hypot(b.vx, b.vy);
      const steps = Math.max(1, Math.ceil((sp * dt) / 4));
      let alive = true;
      for (let s = 0; s < steps && alive; s++) {
        b.x += (b.vx * dt) / steps; b.y += (b.vy * dt) / steps;
        if (solidAt(this.level, b.x, b.y)) {
          if (b.bounce > 0) {
            b.bounce--;
            if (solidAt(this.level, b.x - (b.vx * dt) / steps, b.y)) b.vy *= -1; else b.vx *= -1;
            b.x += (b.vx * dt) / steps * 2; b.y += (b.vy * dt) / steps * 2;
            this.particles.spark(b.x, b.y, 4, b.color, Math.atan2(b.vy, b.vx), 0.8, 120);
            this.sfx.ricochet();
          } else {
            const back = Math.atan2(-b.vy, -b.vx);
            this.particles.spark(b.x, b.y, b.owner === 'player' ? 5 : 3, b.color, back, 1, 120);
            this.particles.smoke(b.x - Math.cos(back) * -2, b.y, 1, '#777', 10, 0.35);
            this.particles.burst(b.x, b.y, 3, this.pal.wallTop, 60, 0.3);
            if (b.owner === 'player') {
              this.bulletHole(b.px, b.py);
              // chunky debris + dust puff + tiny white impact star
              this.particles.burst(b.x, b.y, 4, this.pal.wallTop, 110, 0.45, 2, 3);
              this.particles.spark(b.x, b.y, 4, '#fff3a0', back, 0.6, 260);
              this.particles.smoke(b.x, b.y, 2, '#a0a0a0', 18, 0.5);
              this.particles.impact(b.x, b.y, 4, '#ffffff');
              this.gunfx.hitSpark(b.x, b.y, back, b.y + 6, b.kind === 'pistol');
              this.sfx.bulletWall();
              if (Math.random() < 0.2) this.sfx.ricochet();
            }
            alive = false;
          }
          break;
        }
        if (b.owner === 'player') {
          for (const e of this.enemies) {
            if (e.dead || e.spawnT > 0 || b.hitIds.includes(e.id)) continue;
            if (dist(b.x, b.y, e.x, e.y - 4 - e.z * 0.5) > e.r + b.r + 1) continue;
            b.hitIds.push(e.id);
            const a = Math.atan2(b.vy, b.vx);
            if (e.kind === 'shield' && e.stagger <= 0 && e.z <= 0 && Math.abs(angleDiff(Math.atan2(p.y - e.y, p.x - e.x), e.aim)) < 1.3) {
              this.particles.spark(b.x, b.y, 5, '#ffffff', a + Math.PI, 0.8, 150);
              this.particles.impact(b.x, b.y, 3, '#cccccc');
              this.sfx.hit(); this.sfx.ricochet();
              e.structure += 6;
              alive = false; break;
            }
            const hpBefore = e.hp;
            this.damageEnemy(e, b.dmg, b.structure, a, b.kb, { hitstop: b.kind === 'deflect' ? 0.05 : b.kind === 'pistol' ? 0.02 : 0.01, shake: b.kind === 'pistol' ? 0.08 : 0.05, melee: false });
            this.particles.blood(b.x, b.y, 3 + Math.floor(b.dmg * 0.6), a, 110);
            this.blood.spray(b.x, b.y, a, b.dmg * 0.7, false);
            this.stamp(e.x + rnd(-3, 3), e.y + rnd(0, 2), '#8a0000', 1);
            this.particles.spark(b.x, b.y, 4, '#ffffff', a, 0.5, 220);
            this.particles.impact(b.x, b.y, b.kind === 'pistol' ? 5 : 4, '#ffffff');
            // exit wound: blood mist blown out the far side along the bullet path
            this.particles.blood(e.x + Math.cos(a) * 4, e.y - 6 + Math.sin(a) * 3, 4 + Math.floor(b.dmg * 0.5), a, 220);
            this.gunfx.hitSpark(b.x, b.y, a, e.y, b.kind === 'pistol');
            this.sfx.bulletFlesh();
            this.sfx.hit();
            this.addCombo();
            this.hitMarkerT = 0.14; this.hitMarkerKill = e.dead;
            if (e.dead && b.dmg >= hpBefore * 2 && Math.random() < 0.5) this.gibAt(e.x, e.y, e.color, e.scale, a, 0.8);
            if (b.pierce > 0) b.pierce--; else { alive = false; break; }
          }
          if (alive) for (const pr of this.props) {
            if (pr.dead) continue;
            if (dist(b.x, b.y, pr.x, pr.y - 3) > pr.r + b.r) continue;
            this.damageProp(pr, b.dmg, Math.atan2(b.vy, b.vx));
            alive = false; break;
          }
        } else {
          if (dist(b.x, b.y, p.x, p.y - 5) < p.r + b.r + 1) {
            if (p.parryT > 0) { this.deflectBullet(b, p.aim); this.say('PARRY!', '#35f0ff', 2, 0.6); this.slow(0.15, 0.3); break; }
            if (p.dashT > 0 || p.z > 12) {
              if (!b.hitIds.includes(-1)) {
                b.hitIds.push(-1); p.focus = Math.min(300, p.focus + 8 * this.stats.focusGain);
                if (p.z > 12) this.texts.add(p.x, p.y - 24 - p.z, 'HOP!', '#9be7ff', 1, 0.4);
              }
              continue;
            }
            if (p.iframes > 0) continue;
            this.damagePlayer(b.dmg, Math.atan2(b.vy, b.vx));
            alive = false; break;
          }
        }
      }
      if (!alive || b.life <= 0) bs.splice(i, 1);
    }
    for (let i = this.pendingBooms.length - 1; i >= 0; i--) {
      const pb = this.pendingBooms[i];
      pb.t -= dt;
      if (pb.t <= 0) { this.pendingBooms.splice(i, 1); this.explode(pb.x, pb.y, pb.r, pb.dmg, pb.fromPlayer); }
    }
  }

  updatePickups(dt: number) {
    const p = this.player;
    for (let i = this.pickups.length - 1; i >= 0; i--) {
      const k = this.pickups[i];
      k.t += dt;
      const o = { x: k.x, y: k.y, r: 3 };
      moveWithCollision(this.level, o, k.vx * dt, k.vy * dt);
      k.x = o.x; k.y = o.y;
      const f = Math.max(0, 1 - 5 * dt); k.vx *= f; k.vy *= f;
      const d = dist(p.x, p.y, k.x, k.y);
      if (d < 34 || k.magnet) {
        k.magnet = true;
        const sp = 240;
        k.x += ((p.x - k.x) / d) * sp * dt; k.y += ((p.y - k.y) / d) * sp * dt;
      }
      if (d < 9) {
        this.pickups.splice(i, 1);
        this.sfx.pickup();
        this.particles.burst(k.x, k.y - 4, 8, '#ffffff', 60, 0.4);
        let txt = '';
        let col = '#ffffff';
        switch (k.kind) {
          case 'ammoP': p.ammoP = Math.min(Math.round(60 * this.stats.maxAmmo), p.ammoP + 12); txt = '+12 PISTOL'; col = '#ffd166'; break;
          case 'ammoR': p.ammoR = Math.min(Math.round(180 * this.stats.maxAmmo), p.ammoR + 30); txt = '+30 RIFLE'; col = '#7bed9f'; break;
          case 'hp': this.heal(1); break;
          case 'focus': p.focus = Math.min(300, p.focus + 100); txt = '+FOCUS'; col = '#35f0ff'; break;
          case 'rifle': p.hasRifle = true; p.ammoR = Math.min(Math.round(180 * this.stats.maxAmmo), p.ammoR + 60); txt = 'RIFLE! (3)'; col = '#7bed9f'; this.setWeapon('rifle'); break;
          case 'nunchaku': p.hasNunchaku = true; txt = 'NUNCHAKU! (4)'; col = '#ffd166'; this.setWeapon('nunchaku'); this.slow(0.5, 0.3); this.flash('#ffd166', 0.2); break;
          case 'katana': p.hasKatana = true; txt = 'KATANA! (5)'; col = '#bfe8ff'; this.setWeapon('katana'); this.slow(0.5, 0.3); this.flash('#bfe8ff', 0.25); this.sfx.sheathe(); break;
          case 'axe': p.hasAxe = true; txt = 'AXE! (6)'; col = '#ffb347'; this.setWeapon('axe'); this.slow(0.5, 0.3); this.flash('#ffb347', 0.25); this.sfx.axeHit(true); break;
          case 'dual': p.hasDual = true; txt = 'DUAL BLADES! (7)'; col = '#bfe8ff'; this.setWeapon('dual'); this.slow(0.5, 0.3); this.flash('#bfe8ff', 0.25); this.sfx.dualSwing(); break;
        }
        if (txt) this.texts.add(p.x + 22 * p.facing, p.y + 6, txt, col, 1, 0.7);
      }
    }
  }
  updateProps(dt: number) {
    for (const pr of this.props) {
      if (pr.flash > 0) pr.flash -= dt;
      if (pr.hp <= 0 && !pr.dead && pr.flash <= 0) pr.dead = true;
    }
  }
  updateHazards(dt: number) {
    const p = this.player;
    for (let i = this.hazards.length - 1; i >= 0; i--) {
      const h = this.hazards[i];
      h.life -= dt;
      if (h.kind === 'ring') {
        h.r += ((h.maxR + 36) / h.max) * dt;
        if (h.r > 0 && !h.hit) {
          const d = dist(h.x, h.y, p.x, p.y);
          if (Math.abs(d - h.r) < 7) { h.hit = true; this.damagePlayer(h.dmg, Math.atan2(p.y - h.y, p.x - h.x)); }
        }
      } else if (h.kind === 'fire') {
        if (Math.random() < 0.6) this.particles.ember(h.x + rnd(-h.r, h.r) * 0.7, h.y + rnd(-h.r, h.r) * 0.5, 1, Math.random() < 0.5 ? '#ff6a00' : '#ffd27f');
        if (dist(h.x, h.y, p.x, p.y) < h.r) this.damagePlayer(h.dmg, Math.atan2(p.y - h.y, p.x - h.x));
        h.maxR -= dt;
        if (h.maxR <= 0) {
          h.maxR = 0.5;
          for (const e of this.enemies) if (!e.dead && dist(h.x, h.y, e.x, e.y) < h.r) this.damageEnemy(e, 1.5, 5, Math.atan2(e.y - h.y, e.x - h.x), 30, { hitstop: 0, shake: 0, melee: false });
        }
      }
      if (h.life <= 0) this.hazards.splice(i, 1);
    }
  }

  // ------------------------------------------------------------------ camera
  updateCamera(raw: number) {
    const p = this.player;
    if (this.state === 'menu') {
      this.cam.x = this.menuCamera.x; this.cam.y = this.menuCamera.y;
      this.zoom = this.zoomTarget = this.menuCamera.zoom;
      this.shakeX = this.shakeY = 0; this.camKick.x = this.camKick.y = 0;
      return;
    }
    if (this.menuTransition) {
      const transition = this.menuTransition;
      transition.t = Math.min(transition.duration, transition.t + raw);
      const u = transition.t / transition.duration;
      const ease = u * u * u * (u * (u * 6 - 15) + 10);
      const target = this.enemies.find((e) => !e.dead);
      const tx = (target ? (p.x + target.x) / 2 : p.x) - VIEW_W / 2;
      const ty = p.y - 6 - VIEW_H / 2;
      this.zoom = Math.exp(lerp(Math.log(transition.zoom), Math.log(BASE_ZOOM), ease));
      this.cam.x = lerp(transition.x, tx, ease); this.cam.y = lerp(transition.y, ty, ease);
      this.shakeX = this.shakeY = 0; this.zoomKick = 0;
      if (u >= 1) {
        this.menuTransition = null; this.zoom = this.zoomTarget = BASE_ZOOM;
        if (target) {
          this.input.mouse.x = VIEW_W / 2 + (target.x - this.cam.x - VIEW_W / 2) * this.zoom;
          this.input.mouse.y = VIEW_H / 2 + (target.y - 6 - this.cam.y - VIEW_H / 2) * this.zoom;
        }
        this.pushUI();
      }
      return;
    }
    const look = 0.22;
    let tx: number, ty: number;
    if (this.camFocus) { tx = this.camFocus.x - VIEW_W / 2; ty = this.camFocus.y - 6 - VIEW_H / 2; }
    else {
      const mw = this.mouseWorld();
      tx = p.x + (mw.x - p.x) * look - VIEW_W / 2; ty = p.y - 6 + (mw.y - p.y) * look - VIEW_H / 2;
    }
    const k = 1 - Math.exp(-(this.camFocus ? 12 : 9) * raw);
    this.cam.x = lerp(this.cam.x, tx, k); this.cam.y = lerp(this.cam.y, ty, k);
    const lw = this.level.w * TILE, lh = this.level.h * TILE;
    // clamp the *visible* (zoomed) region to the level bounds
    const hw = VIEW_W / (2 * this.zoom), hh = VIEW_H / (2 * this.zoom);
    this.cam.x = lw < 2 * hw ? (lw - VIEW_W) / 2 : clamp(this.cam.x, hw - VIEW_W / 2, lw - VIEW_W / 2 - hw);
    this.cam.y = lh < 2 * hh ? (lh - VIEW_H) / 2 : clamp(this.cam.y, hh - VIEW_H / 2, lh - VIEW_H / 2 - hh);
    const s = this.trauma * this.trauma;
    this.shakeX = rnd(-1, 1) * s * 8; this.shakeY = rnd(-1, 1) * s * 6;
    const kd = Math.exp(-14 * raw);
    this.camKick.x *= kd; this.camKick.y *= kd;
    this.zoomKick = Math.max(0, this.zoomKick - raw * 0.6);
    this.zoom = lerp(this.zoom, this.zoomTarget + this.zoomKick, 1 - Math.exp(-7 * raw));
    if (Math.abs(this.zoom - BASE_ZOOM) < 0.004 && this.zoomTarget === BASE_ZOOM && this.zoomKick === 0) this.zoom = BASE_ZOOM;
  }

  // ------------------------------------------------------------------ render
  render() {
    const v2 = this.v2;
    const ctx = this.wctx;
    const sc = v2 ? this.hctx : this.ctx;
    const p = this.player;
    const pal = this.pal;
    // V2 draws only the slice of the world that is actually visible (VIEW/zoom art pixels) at 1:1, so every
    // primitive lands on whole buffer pixels and nothing gets antialiased by a fractional transform.
    const sw = v2 ? clamp(Math.ceil(VIEW_W / this.zoom), 1, VIEW_W) : VIEW_W;
    const sh = v2 ? clamp(Math.ceil(VIEW_H / this.zoom), 1, VIEW_H) : VIEW_H;
    ctx.imageSmoothingEnabled = false;
    sc.imageSmoothingEnabled = false;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (v2) { sc.setTransform(1, 0, 0, 1, 0, 0); sc.clearRect(0, 0, VIEW_W, VIEW_H); }
    ctx.fillStyle = pal.bg;
    ctx.fillRect(0, 0, sw, sh);
    const half = v2 ? sw / 2 - VIEW_W / 2 : 0, halfY = v2 ? sh / 2 - VIEW_H / 2 : 0;
    const ox = Math.round(half - this.cam.x + this.shakeX + this.camKick.x), oy = Math.round(halfY - this.cam.y + this.shakeY + this.camKick.y);
    // world -> screen-space (HUD buffer) mapping. Identical to the old formula when v2 is off.
    const sxOf = (wx: number) => (v2 ? (wx + ox - sw / 2) * (VIEW_W / sw) + VIEW_W / 2 : (wx + ox - VIEW_W / 2) * this.zoom + VIEW_W / 2);
    const syOf = (wy: number) => (v2 ? (wy + oy - sh / 2) * (VIEW_H / sh) + VIEW_H / 2 : (wy + oy - VIEW_H / 2) * this.zoom + VIEW_H / 2);
    ctx.save();
    ctx.translate(ox, oy);
    ctx.drawImage(this.levelCanvas, 0, 0);
    this.blood.drawStains(ctx);
    for (const h of this.hazards) {
      if (h.kind === 'fire') {
        ctx.globalAlpha = 0.5 * Math.min(1, h.life);
        for (let i = 0; i < 10; i++) px(ctx, h.x + rnd(-h.r, h.r) * 0.8, h.y + rnd(-h.r, h.r) * 0.55, i % 3 ? '#ff6a00' : '#ffd27f');
        pring(ctx, h.x, h.y, h.r, '#ff6a00', 1);
        ctx.globalAlpha = 1;
      } else if (h.kind === 'ring' && h.r > 0) {
        ctx.globalAlpha = clamp(h.life / h.max, 0, 1);
        pring(ctx, h.x, h.y, h.r, '#ffffff', 2);
        pring(ctx, h.x, h.y, Math.max(0, h.r - 3), pal.accent2, 1);
        ctx.globalAlpha = 1;
      }
    }
    if (this.exitOpen) {
      const ex = this.level.exit;
      const t = this.portalT;
      ctx.globalAlpha = 0.18;
      prect(ctx, ex.x - 5, ex.y - 70, 10, 70, pal.accent);
      ctx.globalAlpha = 0.1;
      prect(ctx, ex.x - 9, ex.y - 70, 18, 70, pal.accent);
      ctx.globalAlpha = 0.2;
      pcircle(ctx, ex.x, ex.y, 12 + Math.sin(t * 4) * 2, pal.accent);
      ctx.globalAlpha = 1;
      pring(ctx, ex.x, ex.y, 12 + Math.sin(t * 4) * 2, pal.accent, 2);
      pring(ctx, ex.x, ex.y, 7 + Math.cos(t * 5) * 1.5, '#ffffff', 1);
      for (let i = 0; i < 6; i++) { const a = t * 3 + (i * Math.PI) / 3; px(ctx, ex.x + Math.cos(a) * 10, ex.y + Math.sin(a) * 10 * 0.6, '#ffffff'); }
      pfontO(ctx, 'EXIT', ex.x, ex.y - 26 + Math.sin(t * 3) * 2, '#ffffff', '#000', 1, 'center');
    }
    for (const k of this.pickups) {
      const bob = Math.sin(k.t * 5 + k.x) * 1.5;
      const y = k.y - 4 + bob;
      pellipseShadow(ctx, k.x, k.y + 1);
      const glow = Math.sin(this.time * 6) > 0;
      switch (k.kind) {
        case 'ammoP': prect(ctx, k.x - 2, y - 2, 5, 4, '#1a1200'); prect(ctx, k.x - 1, y - 1, 3, 2, glow ? '#fff2a8' : '#ffd166'); break;
        case 'ammoR': prect(ctx, k.x - 3, y - 2, 7, 4, '#0a1a0e'); prect(ctx, k.x - 2, y - 1, 5, 2, glow ? '#c8ffd4' : '#7bed9f'); break;
        case 'hp': prect(ctx, k.x - 1, y - 3, 3, 7, '#ff3b3b'); prect(ctx, k.x - 3, y - 1, 7, 3, '#ff3b3b'); px(ctx, k.x, y, '#ffffff'); break;
        case 'focus': pline(ctx, k.x, y - 3, k.x + 3, y, '#35f0ff'); pline(ctx, k.x + 3, y, k.x, y + 3, '#35f0ff'); pline(ctx, k.x, y + 3, k.x - 3, y, '#35f0ff'); pline(ctx, k.x - 3, y, k.x, y - 3, '#35f0ff'); px(ctx, k.x, y, '#ffffff'); break;
        case 'rifle': prect(ctx, k.x - 5, y - 1, 10, 2, '#d4d4d4'); prect(ctx, k.x - 5, y + 1, 2, 2, '#8a5a2b'); pfontO(ctx, 'RIFLE', k.x, y - 10, '#7bed9f', '#000', 1, 'center'); break;
        case 'axe': { drawAxeIcon(ctx, k.x, y); ctx.globalAlpha = 0.5 + Math.sin(this.time * 6) * 0.3; pring(ctx, k.x, y, 9, '#ffb347', 1); ctx.globalAlpha = 1; pfontO(ctx, 'AXE', k.x, y - 13, '#ffb347', '#000', 1, 'center'); break; }
        case 'dual': { drawDualIcon(ctx, k.x, y); ctx.globalAlpha = 0.5 + Math.sin(this.time * 6) * 0.3; pring(ctx, k.x, y, 9, '#bfe8ff', 1); ctx.globalAlpha = 1; pfontO(ctx, 'DUAL BLADES', k.x, y - 13, '#bfe8ff', '#000', 1, 'center'); break; }
        case 'katana': {
          pline(ctx, k.x - 8, y + 3, k.x + 7, y - 4, '#000', 3); pline(ctx, k.x - 8, y + 3, k.x + 7, y - 4, '#d9dde3', 1); pline(ctx, k.x - 6, y + 1, k.x - 8, y + 3, '#3b2a6b', 2); px(ctx, k.x - 5, y + 1, '#c9a033');
          ctx.globalAlpha = 0.5 + Math.sin(this.time * 6) * 0.3; pring(ctx, k.x, y, 9, '#bfe8ff', 1); ctx.globalAlpha = 1;
          pfontO(ctx, 'KATANA', k.x, y - 12, '#bfe8ff', '#000', 1, 'center');
          break;
        }
        case 'nunchaku': {
          pline(ctx, k.x - 6, y + 2, k.x - 1, y - 3, '#c9a063', 2); pline(ctx, k.x + 1, y - 3, k.x + 6, y + 2, '#c9a063', 2);
          pline(ctx, k.x - 1, y - 3, k.x + 1, y - 3, '#dcdcdc', 1);
          ctx.globalAlpha = 0.5 + Math.sin(this.time * 6) * 0.3; pring(ctx, k.x, y, 8, '#ffd166', 1); ctx.globalAlpha = 1;
          pfontO(ctx, 'NUNCHAKU', k.x, y - 12, '#ffd166', '#000', 1, 'center');
          break;
        }
      }
    }
    for (const pr of this.props) {
      if (pr.dead) continue;
      pellipseShadow(ctx, pr.x, pr.y + 2, 6);
      const fl = pr.flash > 0 && (pr.hp > 0 || Math.floor(this.time * 18) % 2 === 0);
      if (pr.kind === 'crate') {
        prect(ctx, pr.x - 5, pr.y - 9, 11, 11, fl ? '#fff' : '#3a2410');
        prect(ctx, pr.x - 4, pr.y - 8, 9, 9, fl ? '#fff' : '#8a5a2b');
        pline(ctx, pr.x - 4, pr.y - 8, pr.x + 4, pr.y, fl ? '#fff' : '#5a3a1b');
        pline(ctx, pr.x + 4, pr.y - 8, pr.x - 4, pr.y, fl ? '#fff' : '#5a3a1b');
      } else {
        prect(ctx, pr.x - 4, pr.y - 11, 9, 13, fl ? '#fff' : '#5a0f0f');
        prect(ctx, pr.x - 3, pr.y - 10, 7, 11, fl ? '#fff' : '#c0392b');
        prect(ctx, pr.x - 3, pr.y - 7, 7, 1, '#2a0a0a');
        prect(ctx, pr.x - 3, pr.y - 3, 7, 1, '#2a0a0a');
        prect(ctx, pr.x - 1, pr.y - 6, 3, 2, fl ? '#fff' : '#ffd166');
      }
    }
    for (const c of this.corpses) {
      if (c.z > 0 || this.v2) drawShadow(ctx, c.x, c.y, c.scale, c.z);   // game1: shadow stays under settled bodies
      const fade = this.v2 && c.t > 1.8 ? Math.max(0, 1 - (c.t - 1.8) / 0.5) : 1;
      drawStick(ctx, { x: c.x, y: c.y, c: c.color, c2: c.color2, scale: c.scale, facing: c.face ?? (Math.cos(c.rot) >= 0 ? 1 : -1), aim: c.rot, walk: 0, moving: false, pose: this.v2 ? (c.z > 2 ? 'fly' : 'knock') : c.z > 0 ? 'launched' : 'down', t: 0, acc: c.accessory, weapon: 'none', flash: false, alpha: (c.z > 0 ? 1 : 0.8) * fade, outline: c.z > 0 ? '#000' : null, eyes: '#000', time: this.v2 ? this.time : 0, lean: { x: 1, y: 0 }, rot: this.v2 ? c.rot : c.z > 0 ? c.rot : 0, z: c.z, mood: 'dead', sqx: this.v2 ? (c.sqx ?? 1) : 1, sqy: this.v2 ? (c.sqy ?? 1) : 1 });
    }
    const shadowScale = 1;
    for (const e of this.enemies) if (!e.dead && e.spawnT <= 0) drawShadow(ctx, e.x, e.y, e.scale * shadowScale, e.z + (e.sceneZ ?? 0));
    if (this.state !== 'dead') drawShadow(ctx, p.x, p.y, shadowScale, p.z);
    for (const a of this.isAttractMode ? [] : this.afterimages) {
      drawStick(ctx, { x: a.x, y: a.y, c: a.color, c2: a.color, scale: a.scale, facing: a.facing, aim: a.aim, walk: 0, moving: false, pose: a.pose, t: a.t, acc: 'none', weapon: 'none', flash: a.dancePhase === undefined, alpha: (a.life / a.max) * 0.45, outline: null, eyes: a.color, time: 0, lean: a.lean, limbScale: this.longMode ? 2.5 : 1, dancePhase: a.dancePhase });
    }
    const ftg = this.state === 'playing' && !this.isAttractMode && !p.fatality ? this.fatalityTarget() : null;
    this.fatTargetId = ftg && (ftg.e.stagger > 0 || this.fatalityCd <= 0) ? ftg.e.id : -1;
    const ents: (Enemy | 'player')[] = [...this.enemies.filter((e) => !e.dead)];
    if (this.state !== 'dead') ents.push('player');
    ents.sort((a, b) => (a === 'player' ? p.y : a.y) - (b === 'player' ? p.y : b.y));
    for (const en of ents) {
      if (en === 'player') this.drawPlayer();
      else this.drawEnemy(en);
    }
    for (const b of this.bullets) {
      if (b.kind === 'bomb') {
        const land = { x: b.x + b.vx * b.life, y: b.y + b.vy * b.life };
        ctx.globalAlpha = 0.5 + Math.sin(this.time * 20) * 0.3;
        pring(ctx, land.x, land.y, 20, '#ff4040', 1);
        ctx.globalAlpha = 1;
        pellipseShadow(ctx, b.x, b.y, 3);
        pcircle(ctx, b.x, b.y - (b.z ?? 0), 2.5, '#1a1a1a');
        px(ctx, b.x, b.y - (b.z ?? 0) - 3, Math.floor(this.time * 20) % 2 ? '#fff' : '#ff9f43');
      } else {
        const sp = Math.hypot(b.vx, b.vy) || 1;
        const nx = b.vx / sp, ny = b.vy / sp;
        if (b.kind === 'orb') {
          ctx.globalAlpha = 0.35; pline(ctx, b.x, b.y, b.x - nx * 6, b.y - ny * 6, b.color, 1); ctx.globalAlpha = 1;
          pcircle(ctx, b.x, b.y, 2.5 + Math.sin(this.time * 20) * 0.5, b.color); px(ctx, b.x, b.y, '#ffffff');
        } else if (b.kind === 'sniper') {
          pline(ctx, b.x, b.y, b.x - b.vx * 0.03, b.y - b.vy * 0.03, '#ffffff', 2);
        } else {
          if (b.owner === 'player') {
            this.gunfx.drawTracer(ctx, b.x, b.y, b.vx, b.vy, b.kind === 'pistol', this.time);
          } else {
            const len = 10;
            ctx.globalAlpha = 0.18; pline(ctx, b.x - nx * len * 0.5, b.y - ny * len * 0.5, b.x - nx * len, b.y - ny * len, b.color, 1);
            ctx.globalAlpha = 0.45; pline(ctx, b.x - nx * len * 0.2, b.y - ny * len * 0.2, b.x - nx * len * 0.5, b.y - ny * len * 0.5, b.color, 1);
            ctx.globalAlpha = 0.9; pline(ctx, b.x, b.y, b.x - nx * len * 0.2, b.y - ny * len * 0.2, '#ffffff', 1);
            ctx.globalAlpha = 1;
            prect(ctx, b.x - 1, b.y - 1, 3, 3, b.color); px(ctx, b.x, b.y, '#ffffff');
          }
        }
      }
    }
    this.gunfx.drawBack(ctx);
    if (!this.isAttractMode) this.particles.draw(ctx);
    this.gunfx.drawFront(ctx);
    this.blood.drawDrops(ctx);
    this.katana.drawArcs(ctx);
    // enemy muzzle flashes
    for (let i = this.enemyMuzzles.length - 1; i >= 0; i--) {
      const m = this.enemyMuzzles[i];
      m.t -= this.rawDt;
      if (m.t <= 0) { this.enemyMuzzles.splice(i, 1); continue; }
      const k = m.t / 0.06;
      ctx.globalAlpha = 0.9 * k;
      const len = 5 + rnd(0, 2);
      pline(ctx, m.x, m.y, m.x + Math.cos(m.a) * len, m.y + Math.sin(m.a) * len, m.c, 2);
      pline(ctx, m.x, m.y, m.x + Math.cos(m.a + 0.6) * len * 0.5, m.y + Math.sin(m.a + 0.6) * len * 0.5, m.c, 1);
      pline(ctx, m.x, m.y, m.x + Math.cos(m.a - 0.6) * len * 0.5, m.y + Math.sin(m.a - 0.6) * len * 0.5, m.c, 1);
      pcircle(ctx, m.x, m.y, 1.5, '#ffffff');
      ctx.globalAlpha = 0.12 * k;
      pcircle(ctx, m.x, m.y, 14, m.c);
      ctx.globalAlpha = 1;
    }
    for (const e of this.enemies) {
      if (e.dead || e.spawnT > 0) continue;
      const shooter = e.kind === 'gunner' || e.kind === 'rifleman' || e.kind === 'sniper' || e.kind === 'smg' || e.kind === 'shotgun' || e.boss === 'queen';
      if (e.state === 'windup' && shooter) {
        // aim telegraph: a laser that solidifies as the shot comes; wide cone for shotgun / smg
        const a = clamp(1 - e.stateT / e.poseDur, 0, 1);
        const len = e.kind === 'sniper' ? 320 : e.kind === 'shotgun' ? 70 : 170;
        const hx = e.x + Math.cos(e.aim) * 8 * e.scale, hy = e.y - 7 * e.scale + Math.sin(e.aim) * 6;
        const col = e.kind === 'sniper' ? '#ff2a2a' : e.kind === 'smg' ? '#7fe3ff' : e.kind === 'shotgun' ? '#ffb8b8' : '#ff8080';
        if (e.kind === 'shotgun' || e.kind === 'smg') {
          const spread = e.kind === 'shotgun' ? 0.36 : 0.3;
          ctx.globalAlpha = a * 0.35;
          pline(ctx, hx, hy, hx + Math.cos(e.aim + spread) * len, hy + Math.sin(e.aim + spread) * len, col, 1);
          pline(ctx, hx, hy, hx + Math.cos(e.aim - spread) * len, hy + Math.sin(e.aim - spread) * len, col, 1);
        }
        ctx.globalAlpha = a * (e.kind === 'sniper' ? 0.9 : 0.55);
        const dashLen = a < 0.7 ? 6 : 1000;
        for (let d0 = 0; d0 < len; d0 += dashLen * 2) {
          const d1 = Math.min(len, d0 + dashLen);
          pline(ctx, hx + Math.cos(e.aim) * d0, hy + Math.sin(e.aim) * d0, hx + Math.cos(e.aim) * d1, hy + Math.sin(e.aim) * d1, col, 1);
          if (dashLen > len) break;
        }
        // "!" over the head right before the shot
        if (a > 0.6) pfontO(ctx, '!', e.x, e.y - e.z - 15 * e.scale - 8, Math.floor(this.time * 20) % 2 ? col : '#ffffff', '#000', 1, 'center');
        ctx.globalAlpha = 1;
      }
      if (e.reload > 0 && !e.boss) {
        const def = e.kind !== 'boss' ? (e.reload / 2.2) : 0;
        prect(ctx, e.x - 6, e.y - 15 * e.scale - 6, 12, 2, '#111');
        prect(ctx, e.x - 6, e.y - 15 * e.scale - 6, Math.round(12 * (1 - clamp(def, 0, 1))), 2, '#aaaaaa');
      }
      if (e.state === 'chargewind') {
        ctx.globalAlpha = 0.3 + Math.sin(this.time * 25) * 0.2;
        pline(ctx, e.x, e.y, e.x + Math.cos(e.aim) * 300, e.y + Math.sin(e.aim) * 300, '#ff3030', 3);
        ctx.globalAlpha = 1;
      }
      if (e.state === 'slamwind') {
        ctx.globalAlpha = 0.3 + Math.sin(this.time * 20) * 0.2;
        pring(ctx, e.x, e.y, 34, '#ff3030', 1);
        ctx.globalAlpha = 1;
      }
    }
    this.texts.draw(ctx);
    ctx.restore();

    // ---- present scene (with cinematic zoom) + screen-space layers
    if (!v2) {
      sc.fillStyle = pal.bg;
      sc.fillRect(0, 0, VIEW_W, VIEW_H);
      if (this.zoom !== 1) {
        sc.save();
        sc.translate(VIEW_W / 2, VIEW_H / 2);
        sc.scale(this.zoom, this.zoom);
        sc.translate(-VIEW_W / 2, -VIEW_H / 2);
        sc.drawImage(this.scene, 0, 0);
        sc.restore();
      } else sc.drawImage(this.scene, 0, 0);
    }
    if (this.wipe) {
      const r = Math.max(0, (1 - this.wipe.t) * 560);
      // the scene is presented zoomed (BASE_ZOOM), so map the wipe centre from scene to screen space
      const wx = sxOf(p.x);
      const wy = syOf(p.y - 6);
      sc.fillStyle = '#000';
      sc.beginPath();
      sc.rect(0, 0, VIEW_W, VIEW_H);
      sc.arc(wx, wy, r, 0, Math.PI * 2, true);
      sc.fill('evenodd');
    }
    if (this.flashA > 0) { sc.globalAlpha = Math.min(0.8, this.flashA); sc.fillStyle = this.flashC; sc.fillRect(0, 0, VIEW_W, VIEW_H); sc.globalAlpha = 1; }
    if (!this.isAttractMode) drawVignette(sc, this.vignette);
    if (this.blood.gore && !this.isAttractMode) this.blood.drawScreen(sc, this.player.hp / this.maxHp(), this.time);
    if (this.state === 'playing' && p.hp <= 1) { sc.globalAlpha = 0.08 + Math.sin(this.time * 6) * 0.05; sc.fillStyle = '#ff0000'; sc.fillRect(0, 0, VIEW_W, VIEW_H); sc.globalAlpha = 1; }
    if (this.timeScale < 0.75 || this.cinematic) {
      const h = this.cinematic ? 18 : Math.round((0.75 - this.timeScale) * 40);
      prect(sc, 0, 0, VIEW_W, h, '#000'); prect(sc, 0, VIEW_H - h, VIEW_W, h, '#000');
    }
    if (this.isAttractMode) {
      this.present(sw, sh);
      return;
    }
    drawHUD(sc, this);
    if (this.state === 'playing') {
      const alive = this.enemies.filter((e) => !e.dead);
      const targets: { x: number; y: number; c: string; label?: string }[] = [];
      if (this.mode === 'survival') { for (const e of alive) if (e.boss) targets.push({ x: e.x, y: e.y, c: '#ff2a2a', label: 'BOSS' }); }
      else if (alive.length <= 3 && this.spawnQueue.length === 0) for (const e of alive) targets.push({ x: e.x, y: e.y, c: e.color });
      if (this.exitOpen) targets.push({ x: this.level.exit.x, y: this.level.exit.y, c: pal.accent, label: 'EXIT' });
      for (const t of targets) {
        const sx = v2 ? sxOf(t.x) : t.x - this.cam.x, sy = v2 ? syOf(t.y) : t.y - this.cam.y;
        if (sx >= 0 && sx <= VIEW_W && sy >= 0 && sy <= VIEW_H) continue;
        const m = 14;
        const ax = clamp(sx, m, VIEW_W - m), ay = clamp(sy, m, VIEW_H - m);
        const a = Math.atan2(sy - ay, sx - ax);
        const tipx = ax + Math.cos(a) * 6, tipy = ay + Math.sin(a) * 6;
        const b1x = ax + Math.cos(a + 2.5) * 5, b1y = ay + Math.sin(a + 2.5) * 5;
        const b2x = ax + Math.cos(a - 2.5) * 5, b2y = ay + Math.sin(a - 2.5) * 5;
        sc.globalAlpha = 0.6 + Math.sin(this.time * 8) * 0.3;
        pline(sc, tipx, tipy, b1x, b1y, t.c, 1); pline(sc, tipx, tipy, b2x, b2y, t.c, 1); pline(sc, b1x, b1y, b2x, b2y, t.c, 1);
        if (t.label) pfontO(sc, t.label, ax, ay + (sy > ay ? -14 : 9), t.c, '#000', 1, 'center');
        sc.globalAlpha = 1;
      }
    }
    if (this.bannerT > 0 && this.state === 'playing' && this.mode === 'story') {
      const el = 2.4 - this.bannerT;
      const a = el < 0.25 ? el / 0.25 : this.bannerT < 0.5 ? this.bannerT / 0.5 : 1;
      sc.globalAlpha = a * 0.7;
      prect(sc, 0, VIEW_H / 2 - 26, VIEW_W, 52, '#000');
      sc.globalAlpha = a;
      prect(sc, 0, VIEW_H / 2 - 27, VIEW_W, 1, pal.accent);
      prect(sc, 0, VIEW_H / 2 + 26, VIEW_W, 1, pal.accent);
      const z = ZONES[this.level.zone];
      pfontO(sc, z.name, VIEW_W / 2, VIEW_H / 2 - 18, pal.accent, '#000', 3, 'center');
      pfont(sc, `LEVEL ${this.levelN}${this.level.isBoss ? ' - BOSS' : ''}`, VIEW_W / 2, VIEW_H / 2 + 2, '#ffffff', 2, 'center');
      pfont(sc, z.sub, VIEW_W / 2, VIEW_H / 2 + 15, '#9a9a9a', 1, 'center');
      sc.globalAlpha = 1;
    }
    if (this.state === 'dead') {
      sc.fillStyle = 'rgba(60,0,0,0.35)';
      sc.fillRect(0, 0, VIEW_W, VIEW_H);
    }
    this.present(sw, sh);
  }

  drawPlayer() {
    const ctx = this.wctx;
    const p = this.player;
    let pose: Pose = 'idle';
    let t = 0;
    let trail: string | null = null;
    if (p.fatality || p.holdT > 0) { pose = p.holdPose; t = p.holdPoseT; if (p.fatality) trail = this.pal.accent2; }
    else if (p.rageDash) pose = 'ragedash';
    else if (p.dashT > 0 || p.focusDash) pose = 'dash';
    else if (p.attackPhase !== 'none' && p.moveKey) { const m = MOVES[p.moveKey]; pose = m.pose; t = this.attackPoseT(); if (m.trail) trail = m.yoyo ? this.yoyoV2.skin.aura : this.pal.accent2; }
    else if (p.weapon === 'hayabusa' && this.hay.bodyPose && !p.airborne && p.landT <= 0 && p.stunT <= 0 && p.parryT <= 0) { pose = this.hay.bodyPose; t = this.hay.bodyT; }
    else if (p.weapon === 'takamura' && this.tak.bodyPose && !p.airborne && p.landT <= 0 && p.stunT <= 0 && p.parryT <= 0) { pose = this.tak.bodyPose; t = this.tak.bodyT; }
    else if (p.weapon === 'yoyo' && this.yoyoVer === 1 && this.yoyo.bodyPose && !p.airborne && p.landT <= 0 && p.stunT <= 0 && p.parryT <= 0) { pose = this.yoyo.bodyPose; t = this.yoyo.bodyT; if (this.yoyo.trailCol) trail = this.yoyo.trailCol; }
    else if (p.airborne) { pose = 'jump'; t = p.vz > 60 ? 0.15 + 0.2 * (1 - p.vz / 215) : p.vz > -60 ? 0.45 : clamp(0.55 + 0.3 * (1 - Math.max(0, p.z) / 30), 0.5, 0.84); }
    else if (p.landT > 0) { pose = 'jump'; t = 0.85 + 0.15 * (1 - p.landT / 0.12); }
    else if (p.parryT > 0 || p.parryCd > 0.3) pose = 'parry';
    else if (p.stunT > 0) pose = 'hurt';
    else if (p.weapon === 'pistol' || p.weapon === 'rifle') pose = 'shoot';
    else if (p.moving && p.runT > 0.03) pose = 'run';
    else if (p.weapon === 'yoyo' && this.yoyoVer === 2) pose = 'y2_idle';
    else if (p.weapon === 'nunchaku') pose = 'n_idle';
    else if (p.weapon === 'katana') pose = p.sheatheT > 0 ? 'k_sheathe' : 'k_idle';
    else if (p.weapon === 'axe' && this.lev.bodyPose) { pose = this.lev.bodyPose; t = this.lev.bodyT; }
    else if (p.weapon === 'axe' && this.lev.held) pose = 'a_idle';
    else if (p.weapon === 'bat') pose = 'a_idle';
    else if (p.weapon === 'dual') pose = 'd_idle';
    if (p.weapon === 'bat' && this.batTauntT > 0 && p.attackPhase === 'none' && !p.fatality && !this.silat) { pose = 'b_taunt'; t = 1 - this.batTauntT / 0.9; }
    if (pose === 'k_sheathe') t = 1 - p.sheatheT / 0.45;
    // pose transition blending: whenever the pose changes, cross-fade from the previous skeleton over ~70ms
    if (pose !== p.prevPose && p.blend <= 0.01) { p.prevPoseT = this.lastPoseT; p.blend = pose === 'dash' || pose === 'hurt' ? 0.5 : 1; }
    p.blend = Math.max(0, p.blend - this.rawDt / 0.07);
    const prevPose = p.prevPose;
    if (p.blend <= 0.01) p.prevPose = pose;
    this.lastPoseT = t;
    const blink = p.iframes > 0 && !p.fatality && Math.floor(this.time * 24) % 2 === 0;
    const opts = this.playerStickOpts(pose, t); // SAME skeleton the hit-tester uses
    if (pose === 'ragedash' || p.rageDash) { opts.pose = 'ragedash'; opts.c = '#ff6a6a'; }
    if (p.rageOn) { opts.c2 = '#ff2a2a'; opts.eyes = '#ff2a2a'; }
    opts.alpha = blink ? 0.45 : 1; opts.trail = trail;
    if (p.attackPhase !== 'none' && p.moveKey) {
      const m = MOVES[p.moveKey];
      if (m.limb === 'fhand' || m.limb === 'bhand' || m.limb === 'ffoot' || m.limb === 'bfoot' || m.limb === 'both') { opts.strike = m.id === 'chain' && p.chainSide < 0 ? 'bhand' : m.limb; opts.impact = m.id === 'chain' ? (t <= 0.35 ? 1 : 0) : t >= 0.3 && t <= 0.62 ? 1 : 0; }
      if (m.limb === 'sweep') { opts.strike = 'ffoot'; opts.impact = t >= 0.3 && t <= 0.7 ? 1 : 0; }
    }
    opts.mood = p.stunT > 0 ? 'hurt' : p.fatality || p.attackPhase !== 'none' ? 'angry' : this.combo >= 6 ? 'happy' : 'normal';
    if (this.silat) {
      const beat = this.silat.sc.beats[Math.min(this.silat.i, this.silat.sc.beats.length - 1)];
      const victim = this.enemies.find((enemy) => enemy.id === this.silat!.id);
      if (beat.head && victim) { const r = victim.sceneRot ?? 0, scale = victim.scale; opts.handOverride = { x: victim.x + Math.sin(r) * 6 * scale, y: victim.y - 5 * scale - Math.cos(r) * 6 * scale - (victim.sceneZ ?? 0) - victim.z }; }
      opts.mood = 'angry';
    }
    if ((p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat') && !this.isAttractMode && !this.clashDuel && !this.silat && this.silatLinkT > 0 && !p.fatality) {
      const next = this.silatLinkTarget();
      if (next) { pline(ctx, p.x, p.y - 6, next.x, next.y - 6, 'rgba(255,210,127,0.35)', 1); pfontO(ctx, 'LMB', next.x, next.y - 26 - next.z, '#9be7ff', '#000', 1, 'center'); }
    }
    if ((p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat') && !this.isAttractMode && !this.clashDuel && !this.silat && !p.fatality && this.state === 'playing') {
      const target = this.silatTarget(false);
      if (target) pfontO(ctx, 'G', target.x, target.y - 26 - target.z, '#ffd27f', '#000', 1, 'center');
    }
    if (p.weapon === 'yoyo' && this.yoyoVer === 1 && !this.parryCounterKey && !p.fatality && this.state !== 'dead' && this.yoyo.weldHand) opts.handOverride = { x: this.yoyo.hand.x, y: this.yoyo.hand.y };
    if (this.sfNunOn && !p.fatality && !p.dead && this.sfNun.pts.length === 6) {
      opts.handOverride = { x: this.sfNun.pts[0].x, y: this.sfNun.pts[0].y };
      if (this.sfNun.attacking) opts.mood = 'angry';
    } else if (this.v2 && p.weapon === 'nunchaku' && !p.fatality && !p.dead) {
      // V2: telapak tangan DEPAN dilas ke grip rantai (world) — lengan di-IK ulang oleh solvePose,
      // jadi nunchaku benar-benar dipegang, bukan melayang di samping tangan
      opts.handOverride = { x: this.nunchaku.px[0], y: this.nunchaku.py[0] };
    }
    drawStick(ctx, opts, prevPose !== pose ? { pose: prevPose, t: p.prevPoseT, blend: p.blend } : undefined);
    if (p.parryT > 0 && !this.isAttractMode) pring(ctx, p.x, p.y - 6, 9, '#9be7ff', 1, p.aim - 1, p.aim + 1);
    if (p.weapon === 'yoyo' && !p.fatality && this.state !== 'dead') {
      if (this.yoyoVer === 1 && !this.parryCounterKey) this.yoyo.draw(ctx, this);
      else if (!p.focusDash && !p.dead) {
        const current = solvePose(opts);
        const visible = prevPose !== pose && p.blend > 0.01 ? blendSkeleton(solvePose({ ...opts, pose: prevPose, t: p.prevPoseT }), current, 1 - p.blend) : current;
        const hand = { x: p.x + visible.fhand.x, y: p.y + visible.fhand.y - p.z };
        this.yoyoV2.draw(ctx, p.attackPhase !== 'none' && !!p.moveKey && !!MOVES[p.moveKey].yoyo, hand);
      }
    }
    if (p.weapon === 'takamura' && !this.parryCounterKey && !p.fatality && this.state !== 'dead') this.tak.draw(ctx, this, solvePose(opts));
    if (p.weapon === 'hayabusa' && !this.parryCounterKey && !p.fatality && this.state !== 'dead') this.hay.draw(ctx, this, solvePose(opts));
    if (this.sfNunOn && !p.fatality) this.sfNun.draw(ctx, this.pal.accent2);
    else if (p.weapon === 'nunchaku' && !p.fatality) this.nunchaku.draw(ctx, this.v2 ? '#b3763a' : '#c9a063', this.v2 ? '#aeb8c6' : '#bdbdbd', this.v2 || p.attackPhase !== 'none' ? this.pal.accent2 : null);
    if (p.weapon === 'bat' && !p.fatality) {
      const sk = solvePose(opts);
      const m = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
      const hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
      let angle = p.attackPhase !== 'none' ? p.bladeA : p.aim + Math.PI + 0.9 * p.facing;
      const beat = this.silat ? this.silat.sc.beats[Math.min(this.silat.i, this.silat.sc.beats.length - 1)] : null;
      if (beat) {
        angle = Math.atan2(sk.fhand.y - sk.neck.y, (sk.fhand.x - sk.neck.x) / 0.6);
        if (beat.bat === 'shoulder') angle = p.aim - p.facing * (Math.PI - 0.7);
        if (beat.bat === 'across') angle = p.aim + p.facing * Math.PI / 2;
        if (beat.batSpin) angle += this.time * beat.batSpin * p.facing;
      } else if (p.attackPhase === 'none' && this.batTauntT > 0) angle = p.aim - p.facing * (Math.PI - 0.7);
      else if (p.attackPhase === 'none') {
        this.batTwirlCd -= this.rawDt; this.batTwirl = Math.max(0, this.batTwirl - this.rawDt);
        if (this.batTwirlCd <= 0 && this.batTwirl === 0 && !p.moving) { this.batTwirl = 0.6; this.batTwirlCd = 2 + Math.random() * 1.5; }
        if (this.batTwirl > 0) angle += (1 - this.batTwirl / 0.6) * Math.PI * 4 * p.facing;
      }
      drawBat(ctx, hand, angle, m?.slash?.lift ?? 0, m && this.attackPoseT() > 0.25 && this.attackPoseT() < 0.65 ? '#ffd27f' : null);
    }
    if (p.weapon === 'axe' || p.weapon === 'dual') {
      const sk = solvePose(opts);
      const m = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
      const lift = m?.slash?.lift ?? 0;
      const fh = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z }, bh = { x: p.x + sk.bhand.x, y: p.y + sk.bhand.y - p.z };
      const a1 = p.attackPhase !== 'none' ? p.bladeA : p.weapon === 'axe' ? p.aim + Math.PI + 0.9 * p.facing : p.aim;
      if (p.weapon === 'axe') { if (this.lev.held) drawAxe(ctx, fh, a1, lift); }
      else { drawShortBlade(ctx, fh, a1, lift); drawShortBlade(ctx, bh, p.attackPhase !== 'none' ? p.bladeB : p.aim + Math.PI * 0.85, lift); }
    }
    if (p.weapon === 'axe' && !p.fatality && this.state !== 'dead') this.lev.draw(ctx, this);
    if (p.weapon === 'katana' || ((p.weapon === 'takamura' || p.weapon === 'hayabusa') && (p.fatality || this.parryCounterKey))) {
      const sk = solvePose(opts);
      const hand = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
      const hip = { x: p.x + sk.hip.x, y: p.y + sk.hip.y - p.z };
      const sheathed = pose === 'k_sheathe' && t > 0.6;
      this.katana.drawScabbard(ctx, hip, p.facing);
      const ba = p.fatality ? p.bladeA : (p.attackPhase !== 'none' ? p.bladeA : p.aim);
      const m = p.attackPhase !== 'none' && p.moveKey ? MOVES[p.moveKey] : null;
      const b = this.katana.blade(hand, ba, m?.slash?.lift ?? 0);
      this.katana.drawBlade(ctx, b.base, b.tip, sheathed);
    }
    for (let i = this.wallHits.length - 1; i >= 0; i--) {
      const hit = this.wallHits[i];
      hit.t -= this.rawDt;
      if (hit.t <= 0) { this.wallHits.splice(i, 1); continue; }
      const radius = 2 + (1 - hit.t / 0.09) * 4;
      ctx.globalAlpha = Math.min(1, hit.t / 0.05);
      pline(ctx, hit.x - radius, hit.y, hit.x + radius, hit.y, '#ffffff', 1); pline(ctx, hit.x, hit.y - radius, hit.x, hit.y + radius, '#ffffff', 1);
      pline(ctx, hit.x, hit.y, hit.x + Math.cos(hit.a) * radius * 1.6, hit.y + Math.sin(hit.a) * radius * 1.6, '#fff3a0', 2);
      ctx.globalAlpha = 1;
    }

  }

  drawEnemy(e: Enemy) {
    const ctx = this.wctx;
    const pal = this.pal;
    const LS = this.longMode ? 2.5 : 1;
    if (e.spawnT > 0) {
      const max = 0.85;
      const k = 1 - e.spawnT / max;
      pring(ctx, e.x, e.y - 6, (1 - k) * 16 + 3, e.color || pal.accent, 1);
      if (k > 0.35) drawStick(ctx, { x: e.x, y: e.y, c: e.color, c2: e.color2, scale: e.scale, facing: e.facing, aim: e.aim, walk: 0, moving: false, pose: e.pose, t: 0, acc: e.accessory, weapon: 'none', flash: true, alpha: (k - 0.35) / 0.65, outline: null, eyes: '#000', time: this.time, lean: { x: 1, y: 0 }, limbScale: LS });
      if (e.boss && k > 0.45) pfontO(ctx, e.name, e.x, e.y - 26 * e.scale * LS, e.color, '#000', 1, 'center');
      return;
    }

    let pose: Pose = e.flinch > 0 && e.attackPhase === 'none' && e.z <= 0 ? 'hurt' : e.pose;
    if (this.v2 && e.z > 2 && pose === 'launched') pose = 'fly';
    let face = e.facing;
    if (e.scenePose) pose = e.scenePose;
    if (this.v2 && pose === 'down' && e.down > 0) { pose = (e.fall as Pose) || 'broken'; face = e.facing * (e.fallFlip ?? 1); }

    const pt = e.scenePose ? (e.sceneT ?? 0) : e.attackPhase && e.attackPhase !== 'none' ? bossAttackPoseT(e) : pose === 'k_sheathe' ? 1 - (e.sheatheT ?? 0) / 0.42 : Math.min(1, e.poseT);
    const opts = bossStickOpts(this, e, pose, pt);
    opts.facing = face;
    drawStick(ctx, opts);

    if ((e.parryT ?? 0) > 0) {
      pring(ctx, e.x, e.y - 6, 9, '#ffd700', 1, e.aim - 1, e.aim + 1);
    }

    // Draw Rival Boss's equipped weapon with full physics & trails
    const rw = e.rivalWeapon ?? 'nunchaku';
    if (e.down <= 0) {
      const sk = solvePose(opts);
      const liftZ = e.z + (e.sceneZ ?? 0);
      const fh = { x: e.x + sk.fhand.x, y: e.y + sk.fhand.y - liftZ };
      const bh = { x: e.x + sk.bhand.x, y: e.y + sk.bhand.y - liftZ };
      const hip = { x: e.x + sk.hip.x, y: e.y + sk.hip.y - liftZ };
      const m = e.attackPhase !== 'none' && e.moveKey ? MOVES[e.moveKey] : null;
      const lift = m?.slash?.lift ?? 0;

      if (rw === 'nunchaku' && e.nun) {
        e.nun.draw(ctx, this.v2 ? '#d4943a' : '#ffe66d', '#dcdcdc', e.color);
      } else if ((rw === 'katana' || rw === 'takamura') && e.kat) {
        const sheathed = pose === 'k_sheathe' && pt > 0.6;
        e.kat.drawScabbard(ctx, hip, e.facing);
        const ba = e.attackPhase !== 'none' ? (e.bladeA ?? e.aim) : e.aim;
        const b = e.kat.blade(fh, ba, lift);
        e.kat.drawBlade(ctx, b.base, b.tip, sheathed);
        e.kat.drawArcs(ctx);
      } else if (rw === 'bat') {
        const ba = e.attackPhase !== 'none' ? (e.bladeA ?? e.aim) : e.aim + Math.PI + 0.9 * e.facing;
        drawBat(ctx, fh, ba, lift, e.attackPhase === 'active' ? e.color : null);
        e.kat?.drawArcs(ctx);
      } else if (rw === 'axe') {
        const ba = e.attackPhase !== 'none' ? (e.bladeA ?? e.aim) : e.aim + Math.PI + 0.9 * e.facing;
        drawAxe(ctx, fh, ba, lift);
        e.kat?.drawArcs(ctx);
      } else if (rw === 'dual') {
        const a1 = e.attackPhase !== 'none' ? (e.bladeA ?? e.aim) : e.aim;
        const a2 = e.attackPhase !== 'none' ? (e.bladeB ?? e.aim) : e.aim + Math.PI * 0.85;
        drawShortBlade(ctx, fh, a1, lift);
        drawShortBlade(ctx, bh, a2, lift);
        e.kat?.drawArcs(ctx);
      } else if (rw === 'yoyo' && e.yoyo2) {
        e.yoyo2.draw(ctx, e.attackPhase !== 'none' && !!m?.yoyo, fh);
      }
    }

    if (this.isAttractMode) return;
    if (this.clashDuel && this.clashDuel.id === e.id) {
      const C = this.clashDuel;
      const pulse = Math.sin(this.time * 40) * 2.5;
      pring(ctx, C.cx, C.cy - 6, 8 + pulse, '#ffd700', 1);
      pring(ctx, C.cx, C.cy - 6, 5 - pulse * 0.5, '#35f0ff', 1);
      return;
    }

    const top = e.y - e.z - 15 * e.scale * LS;
    const dizzy = this.v2 && e.stun > 0 && e.z <= 0;
    if (dizzy) {
      for (let i = 0; i < 3; i++) {
        const a = this.time * 9 + (i * Math.PI * 2) / 3;
        const stx = e.x + Math.cos(a) * 5, sty = top - 4 + Math.sin(a) * 2;
        px(ctx, stx, sty, i % 2 ? '#9ff8ff' : '#ffffff');
        px(ctx, stx - 1, sty, '#2a6a78'); px(ctx, stx + 1, sty, '#2a6a78');
      }
      if (Math.floor(this.time * 7) % 2 === 0) pfontO(ctx, '?', e.x, top - 13, '#9ff8ff', '#000', 1, 'center');
    } else if (e.stagger > 0) {
      for (let i = 0; i < 3; i++) { const a = this.time * 7 + (i * Math.PI * 2) / 3; px(ctx, e.x + Math.cos(a) * 6, top - 3 + Math.sin(a) * 2, '#ffd700'); }
      if (Math.floor(this.time * 6) % 2 === 0) pfontO(ctx, 'F', e.x, top - 12, '#ffd700', '#000', 1, 'center');
    } else if (e.id === this.fatTargetId) {
      const yy = top - 11 + Math.round(Math.sin(this.time * 7) * 1.5);
      prect(ctx, e.x - 3, yy - 1, 7, 7, '#000');
      prect(ctx, e.x - 2, yy, 5, 5, Math.floor(this.time * 8) % 2 ? '#ff1a1a' : '#b30000');
      pfont(ctx, 'F', e.x - 1, yy, '#ffffff', 1);
    }
    if ((e.rallyWindow ?? 0) > 0 && (e.attackPhase === 'windup' || e.attackPhase === 'active')) {
      const flash = Math.floor(this.time * 18) % 2 === 0;
      pring(ctx, e.x, e.y - 6, 11, flash ? '#ffd700' : '#35f0ff', 1);
      pfontO(ctx, 'C', e.x, top - 11, '#35f0ff', '#000', 1, 'center');
    } else if (e.attackPhase === 'windup') {
      pfontO(ctx, '!', e.x, top - 9, e.color, '#000', 1, 'center');
    }
  }
}

function pellipseShadow(ctx: CanvasRenderingContext2D, x: number, y: number, r = 4) {
  ctx.fillStyle = 'rgba(0,0,0,0.35)';
  ctx.fillRect(Math.round(x - r), Math.round(y), r * 2, 1);
  ctx.fillRect(Math.round(x - r + 1), Math.round(y - 1), r * 2 - 2, 1);
}

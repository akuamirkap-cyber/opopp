import { flowDir } from './level';
import { Katana } from './katana';
import { MOVES, type Move } from './moves';
import { Nunchaku } from './nunchaku';
import { SFNunchaku } from './sfnunchaku';
import { solvePose, type StickOpts } from './stick';
import { AXE_LEN, BAT_LEN, DUAL_LEN } from './weapons';
import { YoyoV2 } from './yoyoV2';
import { angleDiff, clamp, dist, rnd, type Rng } from './rng';
import type { BossKind, Enemy, EnemyKind, Pose, Vec, WeaponKind } from './types';
import type { Game } from './game';

export interface EnemyDef {
  hp: number; speed: number; r: number; dmg: number; structure: number; color: string; color2: string; scale: number;
  acc: string; weapon: string; minLevel: number; weight: number; value: number; kbRes: number; armor: boolean;
  canParry: boolean; range: number; cd: number; windup: number; recover: number; role: 'melee' | 'ranged';
  minD: number; maxD: number; mag: number; reload: number;
}

export const DEFS: Record<Exclude<EnemyKind, 'boss'>, EnemyDef> = {
  thug: { hp: 10, speed: 62, r: 5, dmg: 1, structure: 41, color: '#ff9f43', color2: '#ffe66d', scale: 1, acc: 'mohawk', weapon: 'none', minLevel: 1, weight: 10, value: 10, kbRes: 0.25, armor: false, canParry: false, range: 15, cd: 1.1, windup: 0.42, recover: 0.45, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  knife: { hp: 7, speed: 92, r: 5, dmg: 1, structure: 30, color: '#ffe66d', color2: '#ffffff', scale: 1, acc: 'none', weapon: 'knife', minLevel: 3, weight: 7, value: 15, kbRes: 0.15, armor: false, canParry: false, range: 12, cd: 1.4, windup: 0.34, recover: 0.5, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  gunner: { hp: 8, speed: 52, r: 5, dmg: 1, structure: 35, color: '#c56cf0', color2: '#ffffff', scale: 1, acc: 'glasses', weapon: 'pistol', minLevel: 6, weight: 6, value: 15, kbRes: 0.2, armor: false, canParry: false, range: 150, cd: 1.3, windup: 0.55, recover: 0.35, role: 'ranged', minD: 75, maxD: 135, mag: 4, reload: 1.5 },
  bomber: { hp: 5, speed: 104, r: 5, dmg: 2, structure: 20, color: '#ff4757', color2: '#5a0a12', scale: 1, acc: 'hood', weapon: 'bomb', minLevel: 12, weight: 4, value: 20, kbRes: 0, armor: false, canParry: false, range: 18, cd: 1, windup: 0.5, recover: 0.5, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  smg: { hp: 8, speed: 60, r: 5, dmg: 1, structure: 32, color: '#4dd2ff', color2: '#0b3a4a', scale: 1, acc: 'mask', weapon: 'smg', minLevel: 15, weight: 5, value: 20, kbRes: 0.2, armor: false, canParry: false, range: 140, cd: 1.0, windup: 0.5, recover: 0.4, role: 'ranged', minD: 60, maxD: 120, mag: 3, reload: 1.8 },
  rifleman: { hp: 11, speed: 46, r: 5, dmg: 1, structure: 41, color: '#7bed9f', color2: '#2d6b3f', scale: 1, acc: 'hat', weapon: 'rifle', minLevel: 18, weight: 5, value: 20, kbRes: 0.25, armor: false, canParry: false, range: 180, cd: 1.5, windup: 0.6, recover: 0.4, role: 'ranged', minD: 95, maxD: 165, mag: 3, reload: 1.9 },
  brute: { hp: 36, speed: 38, r: 5.5, dmg: 2, structure: 122, color: '#ff6b81', color2: '#6b1f2b', scale: 1.1, acc: 'horns', weapon: 'none', minLevel: 24, weight: 3, value: 40, kbRes: 0.85, armor: true, canParry: false, range: 22, cd: 1.8, windup: 0.68, recover: 0.7, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  monk: { hp: 16, speed: 76, r: 5, dmg: 1, structure: 68, color: '#70a1ff', color2: '#ff6b35', scale: 1, acc: 'band', weapon: 'none', minLevel: 30, weight: 4, value: 30, kbRes: 0.3, armor: false, canParry: true, range: 16, cd: 1.2, windup: 0.3, recover: 0.4, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  shotgun: { hp: 13, speed: 50, r: 5, dmg: 1, structure: 43, color: '#ffb8b8', color2: '#5a1e1e', scale: 1, acc: 'hat', weapon: 'shotgun', minLevel: 34, weight: 4, value: 28, kbRes: 0.3, armor: false, canParry: false, range: 90, cd: 1.8, windup: 0.6, recover: 0.6, role: 'ranged', minD: 40, maxD: 75, mag: 2, reload: 2.2 },
  shield: { hp: 15, speed: 44, r: 5.5, dmg: 1, structure: 61, color: '#eccc68', color2: '#8a6a22', scale: 1, acc: 'helmet', weapon: 'shield', minLevel: 40, weight: 3, value: 30, kbRes: 0.55, armor: false, canParry: false, range: 16, cd: 1.5, windup: 0.45, recover: 0.5, role: 'melee', minD: 0, maxD: 0, mag: 0, reload: 0 },
  sniper: { hp: 8, speed: 50, r: 5, dmg: 2, structure: 32, color: '#ff7f50', color2: '#ffffff', scale: 1, acc: 'glasses', weapon: 'rifle', minLevel: 55, weight: 2, value: 35, kbRes: 0.2, armor: false, canParry: false, range: 260, cd: 2.6, windup: 1.2, recover: 0.8, role: 'ranged', minD: 150, maxD: 240, mag: 1, reload: 2.4 },
};

export interface BossDef {
  name: string;
  title: string;
  rivalWeapon: WeaponKind;
  hp: number;
  speed: number;
  r: number;
  dmg: number;
  structure: number;
  color: string;
  color2: string;
  scale: number;
  acc: string;
  weapon: string;
  kbRes: number;
  armor: boolean;
  canParry: boolean;
  value: number;
}

export const BOSS_DEFS: Record<BossKind, BossDef> = {
  nunchaku: {
    name: 'MASTER RYU',
    title: 'NUNCHAKU GRANDMASTER',
    rivalWeapon: 'nunchaku',
    hp: 105,
    speed: 118,
    r: 5,
    dmg: 1,
    structure: 165,
    color: '#ffe66d',
    color2: '#ff3b3b',
    scale: 1,
    acc: 'headband',
    weapon: 'none',
    kbRes: 0.32,
    armor: false,
    canParry: true,
    value: 500,
  },
  katana: {
    name: 'MASTER KENSHIN',
    title: 'IAI KATANA GRANDMASTER',
    rivalWeapon: 'katana',
    hp: 115,
    speed: 122,
    r: 5,
    dmg: 1,
    structure: 180,
    color: '#ff4d6d',
    color2: '#35f0ff',
    scale: 1,
    acc: 'headband',
    weapon: 'none',
    kbRes: 0.34,
    armor: false,
    canParry: true,
    value: 550,
  },
  fist: {
    name: 'MASTER SANJIRO',
    title: 'WING CHUN & BLACK LEG',
    rivalWeapon: 'fist',
    hp: 120,
    speed: 125,
    r: 5,
    dmg: 1,
    structure: 190,
    color: '#ff9f43',
    color2: '#ffffff',
    scale: 1,
    acc: 'band',
    weapon: 'none',
    kbRes: 0.36,
    armor: false,
    canParry: true,
    value: 600,
  },
  bat: {
    name: 'MASTER KAZUMA',
    title: 'STREET BAT SLUGGER',
    rivalWeapon: 'bat',
    hp: 125,
    speed: 115,
    r: 5,
    dmg: 1,
    structure: 195,
    color: '#ffd166',
    color2: '#ff5a36',
    scale: 1,
    acc: 'mohawk',
    weapon: 'none',
    kbRes: 0.4,
    armor: false,
    canParry: true,
    value: 650,
  },
  dual: {
    name: 'MASTER HANZO',
    title: 'TWIN BLADE PHANTOM',
    rivalWeapon: 'dual',
    hp: 122,
    speed: 128,
    r: 5,
    dmg: 1,
    structure: 185,
    color: '#c77dff',
    color2: '#5ff0ff',
    scale: 1,
    acc: 'mask',
    weapon: 'none',
    kbRes: 0.32,
    armor: false,
    canParry: true,
    value: 700,
  },
  yoyo: {
    name: 'MASTER KAI',
    title: 'B-BOY YO-YO FREESTYLER',
    rivalWeapon: 'yoyo',
    hp: 125,
    speed: 122,
    r: 5,
    dmg: 1,
    structure: 190,
    color: '#3dffa0',
    color2: '#ff3df2',
    scale: 1,
    acc: 'glasses',
    weapon: 'none',
    kbRes: 0.34,
    armor: false,
    canParry: true,
    value: 750,
  },
  axe: {
    name: 'MASTER VIKTOR',
    title: 'LEVIATHAN AXE MASTER',
    rivalWeapon: 'axe',
    hp: 135,
    speed: 114,
    r: 5,
    dmg: 1,
    structure: 210,
    color: '#ff6b81',
    color2: '#ffd700',
    scale: 1,
    acc: 'horns',
    weapon: 'none',
    kbRes: 0.44,
    armor: false,
    canParry: true,
    value: 800,
  },
  takamura: {
    name: 'MASTER TAKAMURA',
    title: 'SWORD SAINT OF THE VOID',
    rivalWeapon: 'takamura',
    hp: 145,
    speed: 130,
    r: 5,
    dmg: 1,
    structure: 225,
    color: '#e6edf5',
    color2: '#ff1a1a',
    scale: 1,
    acc: 'hat',
    weapon: 'none',
    kbRes: 0.4,
    armor: false,
    canParry: true,
    value: 1000,
  },
  bull: { name: 'MASTER RYU', title: 'NUNCHAKU GRANDMASTER', rivalWeapon: 'nunchaku', hp: 105, speed: 118, r: 5, dmg: 1, structure: 165, color: '#ffe66d', color2: '#ff3b3b', scale: 1, acc: 'headband', weapon: 'none', kbRes: 0.32, armor: false, canParry: true, value: 500 },
  queen: { name: 'MASTER KENSHIN', title: 'IAI KATANA GRANDMASTER', rivalWeapon: 'katana', hp: 115, speed: 122, r: 5, dmg: 1, structure: 180, color: '#ff4d6d', color2: '#35f0ff', scale: 1, acc: 'headband', weapon: 'none', kbRes: 0.34, armor: false, canParry: true, value: 550 },
  shadow: { name: 'MASTER SANJIRO', title: 'WING CHUN & BLACK LEG', rivalWeapon: 'fist', hp: 120, speed: 125, r: 5, dmg: 1, structure: 190, color: '#ff9f43', color2: '#ffffff', scale: 1, acc: 'band', weapon: 'none', kbRes: 0.36, armor: false, canParry: true, value: 600 },
  priest: { name: 'MASTER KAZUMA', title: 'STREET BAT SLUGGER', rivalWeapon: 'bat', hp: 125, speed: 115, r: 5, dmg: 1, structure: 195, color: '#ffd166', color2: '#ff5a36', scale: 1, acc: 'mohawk', weapon: 'none', kbRes: 0.4, armor: false, canParry: true, value: 650 },
  dancer: { name: 'MASTER HANZO', title: 'TWIN BLADE PHANTOM', rivalWeapon: 'dual', hp: 122, speed: 128, r: 5, dmg: 1, structure: 185, color: '#c77dff', color2: '#5ff0ff', scale: 1, acc: 'mask', weapon: 'none', kbRes: 0.32, armor: false, canParry: true, value: 700 },
};

export const BOSS_ORDER: BossKind[] = ['nunchaku', 'katana', 'fist', 'bat', 'dual', 'yoyo', 'axe', 'takamura'];

export function bossForLevel(n: number): BossKind {
  const idx = Math.max(0, n - 1) % BOSS_ORDER.length;
  return BOSS_ORDER[idx];
}

const TIER_PREFIX = ['', 'ELDER ', 'GRAND ', 'IMMORTAL '];

export function pickKind(n: number, rng: Rng): Exclude<EnemyKind, 'boss'> {
  void n;
  void rng;
  return 'monk';
}

let nextId = 1;
export function makeEnemy(kind: EnemyKind, boss: BossKind | undefined, x: number, y: number, n: number, elite: boolean): Enemy {
  const bossKind: BossKind = boss ?? bossForLevel(n);
  const bd = BOSS_DEFS[bossKind] ?? BOSS_DEFS.nunchaku;
  void kind;
  void elite;
  const cycle = Math.floor(Math.max(0, n - 1) / BOSS_ORDER.length);
  const tier = Math.min(3, cycle);
  const hpMul = 1 + cycle * 0.35 + Math.max(0, n - 1) * 0.06;
  const name = TIER_PREFIX[tier] + bd.name;
  const speed = bd.speed * (1 + Math.min(0.25, cycle * 0.06));
  const nun = new Nunchaku();
  nun.v2 = true;
  nun.reset(x, y - 8);
  const sfNun = new SFNunchaku();
  sfNun.reset(x, y - 8);
  const kat = new Katana();
  const yoyo2 = new YoyoV2();
  yoyo2.setSkin('eclipse');
  yoyo2.reset(x, y - 7);

  return {
    id: nextId++,
    kind: 'boss',
    boss: bossKind,
    name,
    title: bd.title,
    rivalWeapon: bd.rivalWeapon,
    x,
    y,
    vx: 0,
    vy: 0,
    kx: 0,
    ky: 0,
    r: bd.r,
    hp: Math.round(bd.hp * hpMul),
    maxHp: Math.round(bd.hp * hpMul),
    dead: false,
    flash: 0,
    facing: -1,
    aim: Math.PI,
    walk: 0,
    moving: false,
    speed,
    dmg: bd.dmg,
    color: bd.color,
    color2: bd.color2,
    scale: bd.scale,
    structure: 0,
    maxStructure: Math.round(bd.structure * (1 + cycle * 0.25)),
    stagger: 0,
    down: 0,
    stun: 0,
    state: 'chase',
    stateT: 0,
    attackCd: 0.45,
    pose: bd.rivalWeapon === 'nunchaku' ? 'n_idle' : bd.rivalWeapon === 'katana' || bd.rivalWeapon === 'takamura' ? 'k_idle' : bd.rivalWeapon === 'bat' || bd.rivalWeapon === 'axe' ? 'a_idle' : bd.rivalWeapon === 'dual' ? 'd_idle' : bd.rivalWeapon === 'yoyo' ? 'y2_idle' : 'idle',
    poseT: 0,
    poseDur: 1,
    elite: false,
    spawnT: 0.85,
    accessory: bd.acc,
    weapon: 'none',
    kbRes: bd.kbRes,
    armor: false,
    canParry: true,
    burst: 0,
    phase: 0,
    value: bd.value,
    hitDone: false,
    strafeDir: Math.random() < 0.5 ? 1 : -1,
    strafeT: rnd(0.5, 1.2),
    summonCd: 999,
    fuse: -1,
    chargeDir: 0,
    tele: null,
    attackRange: 26,
    lastDist: 9999,
    stuckT: 0,
    shockR: [],
    parryCd: 0,
    cdMul: Math.max(0.6, 1 - cycle * 0.08),
    wMul: Math.max(0.68, 1 - cycle * 0.06),
    z: 0,
    vz: 0,
    flinch: 0,
    rot: 0,
    fatalCount: 0,
    role: 'melee',
    slot: 0,
    slotAng: 0,
    token: true,
    tokenT: 999,
    wantDist: 28,
    reload: 0,
    ammo: 0,
    aimLine: 0,
    sepx: 0,
    sepy: 0,
    repos: null,
    reposT: 0,
    pose2: 'idle',
    strideHalf: 3,
    bodyAim: Math.PI,
    bleed: 0,
    bleedT: 0,
    doom: 0,
    moveKey: null,
    attackPhase: 'none',
    attackT: 0,
    comboQueue: [],
    dashT: 0,
    dashCd: 0.8,
    dashDir: { x: -1, y: 0 },
    parryT: 0,
    bladeA: Math.PI,
    bladeB: 0,
    bladePrevA: Math.PI,
    sheatheT: 0,
    prevLimb: null,
    travelHit: false,
    chainSide: 1,
    runT: 0,
    running: false,
    flourishT: 0,
    flourishCd: 0.6,
    rallyStreak: 0,
    rallyWindow: 0,
    playerSpamCount: 0,
    backstepCd: 0,
    feintCd: 0,
    nun,
    sfNun,
    kat,
    yoyo2,
  };
}

export function friendlyInLine(g: Game, e: Enemy, ang: number, maxD: number) {
  void g;
  void e;
  void ang;
  void maxD;
  return false;
}

export function bossIdlePose(w: WeaponKind | undefined, sheatheT = 0): Pose {
  switch (w) {
    case 'nunchaku': return 'n_idle';
    case 'katana':
    case 'takamura':
    case 'hayabusa': return sheatheT > 0 ? 'k_sheathe' : 'k_idle';
    case 'bat':
    case 'axe': return 'a_idle';
    case 'dual': return 'd_idle';
    case 'yoyo': return 'y2_idle';
    default: return 'idle';
  }
}

export function bossAttackPoseT(e: Enemy): number {
  if (!e.moveKey || !MOVES[e.moveKey]) return 0;
  const m = MOVES[e.moveKey];
  const t = e.attackT ?? 0;
  if (e.attackPhase === 'windup') {
    const wu = Math.max(0.01, e.poseDur);
    return 0.3 * clamp(1 - t / wu, 0, 1);
  }
  if (e.attackPhase === 'active') return 0.3 + 0.3 * clamp(1 - t / Math.max(0.01, m.active), 0, 1);
  if (e.attackPhase === 'recover') return 0.6 + 0.4 * clamp(1 - t / Math.max(0.01, m.recover), 0, 1);
  return 0;
}

export function bossStickOpts(g: Game, e: Enemy, poseOverride?: Pose, tOverride?: number): StickOpts {
  const pose = poseOverride ?? e.pose;
  const t = tOverride ?? (e.scenePose ? (e.sceneT ?? 0) : Math.min(1, e.poseT));
  const moving = e.moving && (pose === 'idle' || pose === 'run' || pose === 'n_idle' || pose === 'k_idle' || pose === 'a_idle' || pose === 'd_idle' || pose === 'y2_idle');
  const m = e.attackPhase !== 'none' && e.moveKey ? MOVES[e.moveKey] : null;
  let strike: StickOpts['strike'] = null;
  let impact = 0;
  if (m) {
    if (m.limb === 'fhand' || m.limb === 'bhand' || m.limb === 'ffoot' || m.limb === 'bfoot' || m.limb === 'both') {
      strike = m.id === 'chain' && (e.chainSide ?? 1) < 0 ? 'bhand' : m.limb;
      impact = m.id === 'chain' ? (t <= 0.4 ? 1 : 0) : t >= 0.3 && t <= 0.65 ? 1 : 0;
    } else if (m.limb === 'sweep') {
      strike = 'ffoot';
      impact = t >= 0.3 && t <= 0.7 ? 1 : 0;
    }
  } else if (e.scenePose) {
    strike = 'fhand';
    impact = 1;
  }
  const dizzy = g.v2 && e.stun > 0 && e.z <= 0;
  const dizzyRot = dizzy ? Math.sin(g.time * 9) * 0.16 : 0;
  let trail: string | null = null;
  if (m && (m.trail || m.finisher)) trail = e.color2;
  if (e.scenePose) trail = e.color;

  const opts: StickOpts = {
    x: e.x,
    y: e.y,
    c: e.color,
    c2: e.color2,
    scale: e.scale,
    facing: e.facing,
    aim: moving && pose === 'run' ? e.bodyAim : e.aim,
    look: e.aim,
    walk: e.walk,
    moving,
    pose,
    t,
    acc: e.accessory,
    weapon: 'none',
    flash: e.flash > 0,
    alpha: 1,
    outline: '#000000',
    eyes: e.hp < e.maxHp * 0.5 ? '#ff2a2a' : e.color2,
    time: g.time,
    lean: { x: Math.cos(e.aim), y: Math.sin(e.aim) },
    z: e.z + (e.sceneZ ?? 0),
    rot: e.scenePose ? (e.sceneRot ?? 0) : e.z > 0 ? e.rot : dizzyRot,
    run: clamp((e.runT ?? 0) / 0.2, 0, 1),
    sqx: g.v2 ? (e.sqx ?? 1) : 1,
    sqy: g.v2 ? (e.sqy ?? 1) : 1,
    vel: g.moveDirOf(e.vx + e.kx * 0.3, e.vy + e.ky * 0.3),
    stride: e.strideHalf,
    chainSide: e.chainSide ?? 1,
    strike,
    impact,
    trail,
    anime: g.v2,
    brake: e.state === 'parryRecoil' ? clamp(e.stun / 0.28, 0, 1) : g.clashDuel?.id === e.id ? clamp(g.clashDuel.recoilT / 0.32, 0, 1) : 0,
    limbScale: g.longMode ? 2.5 : 1,
    dancePhase: e.rivalWeapon === 'yoyo' && e.yoyo2 ? e.yoyo2.spin : undefined,
    seed: e.id * 1.7,
    mood: e.stagger > 0 || e.down > 0 || e.flinch > 0 ? 'hurt' : e.attackPhase !== 'none' || e.scenePose || e.hp < e.maxHp * 0.5 ? 'angry' : 'normal',
  };
  if (e.rivalWeapon === 'nunchaku' && e.nun && e.down <= 0 && e.stagger <= 0) {
    opts.handOverride = { x: e.nun.px[0], y: e.nun.py[0] };
  }
  return opts;
}

// ------------------------------------------------------------------ steering helpers
function applyMove(g: Game, e: Enemy, dx: number, dy: number, speed: number) {
  let x = dx, y = dy;
  const l = Math.hypot(x, y) || 1;
  x /= l; y /= l;
  if (!g.isFree(e.x + x * 8, e.y + y * 8, e.r)) {
    const cands = [[x, 0], [0, y], [-y, x], [y, -x]];
    let found = false;
    for (const [cx, cy] of cands) {
      const cl = Math.hypot(cx, cy) || 1;
      if (g.isFree(e.x + (cx / cl) * 8, e.y + (cy / cl) * 8, e.r)) { x = cx / cl; y = cy / cl; found = true; break; }
    }
    if (!found) { x = 0; y = 0; }
  }
  e.vx = x * speed; e.vy = y * speed; e.moving = Math.abs(x) + Math.abs(y) > 0.01;
}

function steer(g: Game, e: Enemy, tx: number, ty: number, speed: number, useFlow: boolean) {
  let dir: Vec | null = null;
  if (useFlow) dir = flowDir(g.level, g.flow, e.x, e.y);
  if (!dir) {
    const dx = tx - e.x, dy = ty - e.y;
    const d = Math.hypot(dx, dy) || 1;
    dir = { x: dx / d, y: dy / d };
  }
  applyMove(g, e, dir.x, dir.y, speed);
}

function strafe(g: Game, e: Enemy, ang: number, dt: number, speed: number) {
  e.strafeT -= dt;
  if (e.strafeT <= 0) { e.strafeT = rnd(0.45, 1.1); e.strafeDir *= Math.random() < 0.7 ? -1 : 1; }
  const a = ang + (Math.PI / 2) * e.strafeDir;
  if (!g.isFree(e.x + Math.cos(a) * 10, e.y + Math.sin(a) * 10, e.r)) e.strafeDir *= -1;
  applyMove(g, e, Math.cos(a), Math.sin(a), speed);
}

function lerpAngle(a: number, b: number, t: number) {
  return a + angleDiff(b, a) * Math.min(1, t);
}

// ------------------------------------------------------------------ Rival Boss Weapon Physics & Hitboxes
export function updateBossWeaponPhysics(g: Game, e: Enemy, dt: number) {
  const w = e.rivalWeapon ?? 'nunchaku';
  const LS = g.longMode ? 2.5 : 1;
  const move = (e.attackPhase !== 'none' || (g.clashDuel && g.clashDuel.id === e.id)) && e.moveKey ? MOVES[e.moveKey] : null;
  const pt = e.scenePose ? (e.sceneT ?? 0.5) : bossAttackPoseT(e);
  const lift = e.z + (e.sceneZ ?? 0);
  const poseOptions = bossStickOpts(g, e, e.scenePose ?? e.pose, pt);
  delete poseOptions.handOverride;
  const skeleton = solvePose(poseOptions);

  if (w === 'nunchaku' && e.nun) {
    e.nun.v2 = g.v2;
    const sk = skeleton;
    let hand = { x: e.x + sk.fhand.x, y: e.y + sk.fhand.y - lift };
    let ndx = sk.fhand.x - sk.neck.x, ndy = sk.fhand.y - sk.neck.y;
    const nl = Math.hypot(ndx, ndy) || 1;
    ndx /= nl; ndy /= nl;
    let spin = 0;
    let boost: Vec | null = null;
    const sh = { x: e.x, y: e.y - 4 * LS - lift };
    const sweep = (u: number, from: number, to: number, snap = 0.5) => {
      if (u < 0.18) return from - Math.sign(to - from) * 0.5 * (u / 0.18);
      const v = Math.min(1, (u - 0.18) / snap);
      const ease = 1 - Math.pow(1 - v, 3);
      return from + (to - from) * ease + Math.sin(v * Math.PI) * 0.12 * Math.sign(to - from);
    };

    if (move && move.nunchaku) {
      switch (move.id) {
        case 'n_helicopter': case 'n_flyspin': spin = 26 * e.facing; break;
        case 'n_lowsweep': spin = -22 * e.facing; break;
        case 'n_tornado': spin = 30 * e.facing; break;
        case 'n_dragonlash': if (pt >= 0.28) boost = { x: Math.cos(e.aim) * 1500, y: Math.sin(e.aim) * 900 + 300 }; break;
        case 'n_tri1': case 'n_tri2': case 'n_tri3': case 'n_tri4': {
          if (pt >= 0.28 && pt <= 0.5) {
            const side = { x: -Math.sin(e.aim), y: Math.cos(e.aim) };
            const f = e.facing;
            if (move.id === 'n_tri1') boost = { x: Math.cos(e.aim) * 900 - side.x * f * 500, y: Math.sin(e.aim) * 540 + 700 };
            else if (move.id === 'n_tri2') boost = { x: Math.cos(e.aim) * 1300, y: Math.sin(e.aim) * 500 - 900 };
            else if (move.id === 'n_tri3') boost = { x: Math.cos(e.aim) * 1000 + side.x * f * 700, y: Math.sin(e.aim) * 600 + 80 };
            else boost = { x: Math.cos(e.aim) * 700 + side.x * f * 200, y: Math.sin(e.aim) * 420 + 900 };
          }
          break;
        }
        default: {
          if (pt >= 0.28 && pt <= 0.48) {
            const pow = move.id === 'n_whipcrack' ? 1400 : move.id === 'n_overhead' ? 1100 : 900;
            boost = { x: Math.cos(e.aim) * pow, y: Math.sin(e.aim) * pow * 0.6 + (move.id === 'n_overhead' ? 500 : 0) };
          }
          break;
        }
      }
      const u = Math.min(1, pt);
      let ang = e.aim, rad = (8 + 5 * u) * LS;
      switch (move.id) {
        case 'n_tri2': case 'n_cross': ang = e.aim + sweep(u, 2.0, -1.0); break;
        case 'n_whipcrack': case 'n_overhead': ang = e.aim + sweep(u, -2.3, 0.8, 0.34); rad = (6 + 8 * Math.min(1, Math.max(0, (u - 0.18) / 0.34))) * LS; break;
        case 'n_choke': ang = e.aim + sweep(u, -1.6, 0.6, 0.3); break;
        case 'n_tri4': ang = e.aim + sweep(u, 1.8, -0.6, 0.3); break;
        case 'n_helicopter': case 'n_flyspin': case 'n_tornado': case 'n_lowsweep': ang = e.aim + u * Math.PI * 3; rad = 12 * LS; break;
        case 'n_dragonlash': ang = e.aim + sweep(u, -2.4, 1.2, 0.3); rad = (9 + 6 * u) * LS; break;
        default: ang = e.aim + sweep(u, -2.0, 1.0); break;
      }
      hand = { x: sh.x + Math.cos(ang) * rad, y: sh.y + Math.sin(ang) * rad };
    } else if ((e.dashT ?? 0) > 0) {
      hand = { x: sh.x - Math.cos(e.aim) * 6 * LS, y: sh.y + 3 * LS };
    } else if (e.scenePose || (e.parryT ?? 0) > 0 || e.state === 'parried' || e.state === 'parryRecoil') {
      // A defensive grip follows the posed palm, not an idle flourish or the old rope anchor.
      boost = null;
    } else {
      e.flourishCd = (e.flourishCd ?? 1) - dt;
      e.flourishT = Math.max(0, (e.flourishT ?? 0) - dt);
      if (e.flourishCd <= 0 && e.flourishT === 0 && e.attackPhase === 'none') {
        e.flourishT = 0.55;
        e.flourishCd = 1.2 + Math.random() * 0.9;
      }
      if ((e.flourishT ?? 0) > 0) {
        const fu = 1 - (e.flourishT ?? 0) / 0.55;
        const ga = e.aim + fu * Math.PI * 4 * e.facing;
        hand = { x: sh.x + Math.cos(ga) * 7.5 * LS, y: sh.y + Math.sin(ga) * 7.5 * LS };
        boost = null;
      } else {
        hand = { x: sh.x + Math.cos(e.aim) * 6.5 * LS, y: sh.y + (2.5 + Math.sin(e.aim) * 3) * LS };
        boost = null;
      }
    }
    if (spin !== 0 && e.nun.spinSpeed === 0) e.nun.spinAng = Math.atan2(ndy, ndx);
    e.nun.spinSpeed = spin;
    e.nun.update(hand, { x: ndx, y: ndy }, dt, spin, boost, e.attackPhase !== 'none' || !!g.clashDuel);
    if (e.nun.tipSpeed > 280 && Math.random() < 0.2) g.sfx.chainRattle();
  }

  if ((w === 'katana' || w === 'takamura' || w === 'bat' || w === 'axe' || w === 'dual') && e.kat) {
    e.kat.update(dt);
    if ((e.sheatheT ?? 0) > 0) e.sheatheT = Math.max(0, (e.sheatheT ?? 0) - dt);
    e.bladePrevA = e.bladeA ?? e.aim;
    if (move && move.slash) {
      const s = move.slash;
      const k = pt < 0.3 ? 0 : pt < 0.6 ? (pt - 0.3) / 0.3 : 1;
      const ease = k < 1 ? 1 - Math.pow(1 - k, 2.2) : 1;
      const rel = s.from + (s.to - s.from) * ease;
      const settle = pt > 0.6 ? clamp((pt - 0.6) / 0.4, 0, 1) : 0;
      e.bladeA = e.aim + rel * e.facing * (1 - settle);
      e.bladeB = e.aim - rel * e.facing * (1 - settle);
      if (pt >= 0.3 && pt < 0.36 && !e.travelHit && s.from !== s.to) {
        const sk = skeleton;
        const hx = e.x + sk.fhand.x, hy = e.y + sk.fhand.y - lift;
        const col = w === 'bat' || w === 'axe' ? '#ffd27f' : e.color2;
        e.kat.addArc(hx, hy, s.r, e.aim + s.from * e.facing, e.aim + s.to * e.facing, col, s.lift ?? 0, 0.22);
        if (w === 'dual') {
          const bx = e.x + sk.bhand.x, by = e.y + sk.bhand.y - lift;
          e.kat.addArc(bx, by, s.r, e.aim - s.from * e.facing, e.aim - s.to * e.facing, col, s.lift ?? 0, 0.22);
        }
        e.travelHit = true;
      }
    } else {
      e.bladeA = lerpAngle(e.bladeA ?? e.aim, e.aim, dt * 16);
      e.bladeB = lerpAngle(e.bladeB ?? e.aim, e.aim + Math.PI * 0.85, dt * 16);
    }
  }

  if (w === 'yoyo' && e.yoyo2) {
    const sk = skeleton;
    const hand = { x: e.x + sk.fhand.x, y: e.y + sk.fhand.y - lift };
    const origin = { x: e.x, y: e.y - 6 - lift };
    const yoMove = move?.yoyo ? move : null;
    const phase = e.attackPhase ?? 'none';
    e.yoyo2.update(dt, hand, origin, e.aim, yoMove?.id ?? null, phase, pt, (yoMove?.range ?? 78) * (g.longMode ? 2.2 : 1));
  }
}

function bossBladeSeg(g: Game, e: Enemy, move: Move, second = false): { base: Vec; tip: Vec } {
  const sk = solvePose(bossStickOpts(g, e, move.pose, bossAttackPoseT(e)));
  const hand = second ? { x: e.x + sk.bhand.x, y: e.y + sk.bhand.y - e.z } : { x: e.x + sk.fhand.x, y: e.y + sk.fhand.y - e.z };
  const len = (move.bat ? BAT_LEN : move.axe ? AXE_LEN : move.dual ? DUAL_LEN : (e.kat?.len ?? 18)) * (g.longMode ? 2.5 : 1);
  const ang = second ? (e.bladeB ?? e.aim) : (e.bladeA ?? e.aim);
  const lift = move.slash?.lift ?? 0;
  return { base: hand, tip: { x: hand.x + Math.cos(ang) * len, y: hand.y + Math.sin(ang) * len * 0.6 - lift * 10 } };
}

function bossStrikePoint(g: Game, e: Enemy, move: Move): { pt: Vec; r: number; seg?: { base: Vec; tip: Vec }; seg2?: { base: Vec; tip: Vec } } {
  const LS = g.longMode ? 2.5 : 1;
  if (move.limb === 'nunchaku' && e.nun) {
    const tip = e.nun.tip();
    const mid = e.nun.farMid();
    return { pt: { x: (tip.x + mid.x) / 2, y: (tip.y + mid.y) / 2 }, r: move.hitR * LS, seg: { base: { x: e.nun.px[0], y: e.nun.py[0] }, tip } };
  }
  if (move.limb === 'blade' || move.limb === 'blade2') {
    const b = bossBladeSeg(g, e, move, false);
    return { pt: { x: (b.base.x + b.tip.x * 2) / 3, y: (b.base.y + b.tip.y * 2) / 3 }, r: move.hitR, seg: b, seg2: move.limb === 'blade2' ? bossBladeSeg(g, e, move, true) : undefined };
  }
  if (move.limb === 'yoyo' && e.yoyo2) {
    const pt = { ...e.yoyo2.position };
    return { pt, r: move.hitR, seg: { base: { ...e.yoyo2.hand }, tip: pt } };
  }
  const sk = solvePose(bossStickOpts(g, e, move.pose, bossAttackPoseT(e)));
  const at = (v: Vec): Vec => ({ x: e.x + v.x, y: e.y + v.y - e.z });
  if (move.id === 'chain') return { pt: at((e.chainSide ?? 1) < 0 ? sk.bhand : sk.fhand), r: move.hitR };
  switch (move.limb) {
    case 'fhand': return { pt: at(sk.fhand), r: move.hitR };
    case 'bhand': return { pt: at(sk.bhand), r: move.hitR };
    case 'ffoot': return { pt: at(sk.ffoot), r: move.hitR };
    case 'bfoot': return { pt: at(sk.bfoot), r: move.hitR };
    case 'both': { const a = at(sk.fhand), b = at(sk.bhand); return { pt: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, r: move.hitR + 1.5 }; }
    case 'sweep': return { pt: at(sk.ffoot), r: move.hitR + 1 };
    default: return { pt: { x: e.x, y: e.y - 6 }, r: move.hitR + 3 };
  }
}

function segDist(ax: number, ay: number, bx: number, by: number, cx: number, cy: number) {
  const dx = bx - ax, dy = by - ay;
  const l2 = dx * dx + dy * dy;
  const t = clamp(l2 > 0 ? ((cx - ax) * dx + (cy - ay) * dy) / l2 : 0, 0, 1);
  return Math.hypot(cx - (ax + dx * t), cy - (ay + dy * t));
}

function resolveBossMelee(g: Game, e: Enemy, move: Move) {
  if (e.hitDone || !g.hasLOS(e)) return;
  const p = g.player;
  const sp = bossStrikePoint(g, e, move);
  const cur = sp.pt;
  const prev = e.prevLimb ?? cur;
  e.prevLimb = cur;
  const pt = bossAttackPoseT(e);
  const wide = move.limb === 'nunchaku' || move.limb === 'yoyo' || move.limb === 'blade' || move.rehit || move.id === 'spinback' || move.id === 'sweep' || move.id === 'dragontail';
  const impactWindow = move.id === 'chain' ? pt >= 0.1 && pt <= 0.65 : wide ? pt >= 0.28 && pt <= 0.74 : pt >= 0.32 && pt <= 0.65;
  if (!impactWindow && !move.travel) return;

  const LS = g.longMode ? 2.5 : 1;
  const reach = (move.range + 8) * LS;
  if (dist(e.x, e.y, p.x, p.y) > reach + p.r) return;

  const top = p.y - 13 * LS - p.z;
  const bottom = p.y + 1 - p.z;
  let dmin = 1e9;
  for (let k = 0; k <= 4; k++) {
    const yy = top + ((bottom - top) * k) / 4;
    dmin = Math.min(dmin, segDist(prev.x, prev.y, cur.x, cur.y, p.x, yy));
    if (sp.seg) dmin = Math.min(dmin, segDist(sp.seg.base.x, sp.seg.base.y, sp.seg.tip.x, sp.seg.tip.y, p.x, yy));
    if (sp.seg2) dmin = Math.min(dmin, segDist(sp.seg2.base.x, sp.seg2.base.y, sp.seg2.tip.x, sp.seg2.tip.y, p.x, yy));
  }
  if (move.travel && dist(e.x + Math.cos(e.aim) * 8, e.y - 5 - e.z + Math.sin(e.aim) * 4, p.x, p.y - 5 - p.z) < p.r + 8) {
    dmin = 0;
  }
  if (dmin > sp.r + p.r + 1.5) return;

  e.hitDone = true;
  const a = Math.atan2(p.y - e.y, p.x - e.x);
  if (g.isAttractMode) { g.previewContact(e); return; }

  // 1) Player active Parry (C) OR Counter-Parry during Rally Window!
  const rallyTap = (e.rallyWindow ?? 0) > 0 && g.input.mouse.pressed && p.stunT <= 0 && p.holdT <= 0 && !p.airborne &&
    Math.abs(angleDiff(Math.atan2(e.y - p.y, e.x - p.x), p.aim)) <= 1.7;
  if (g.canPlayerParry(e) || rallyTap) {
    g.perfectParry(e, a);
    return;
  }

  // 2) Simultaneous Strike -> Trigger ADU SPAM (Clash Duel) or Ping-Pong Parry!
  const playerSwinging = p.attackPhase === 'active' || p.attackPhase === 'windup' || (g.sfNunOn && g.sfNun.attacking);
  if (playerSwinging && !p.airborne && p.z <= 4 && Math.abs(angleDiff(p.aim, a + Math.PI)) < 1.5) {
    if (g.clashCd <= 0 && ((e.rallyStreak ?? 0) >= 2 || Math.random() < 0.65)) {
      g.startClash(e);
      return;
    }
    // Otherwise trigger a high-speed mutual Parry Deflect!
    g.mutualClashDeflect(e, a);
    return;
  }

  // 3) Player Shadow Step dodge counter
  if (p.dashT > 0) {
    g.say('SHADOW STEP!', '#9be7ff', 2, 0.6);
    g.slow(0.15, 0.35);
    p.focus = Math.min(300, p.focus + 20 * g.stats.focusGain);
    if ((p.weapon === 'fist' || p.weapon === 'nunchaku' || p.weapon === 'bat') && !g.silat && !p.fatality && !g.silatPending) {
      g.silatPending = { id: e.id, t: 0.06, kind: 'counter' };
    }
    return;
  }

  // 4) Player jumped over low/ground strike
  if (p.z > 12 && e.z < 6 && !move.air) {
    g.texts.add(p.x, p.y - 26 - p.z, 'JUMPED!', '#9be7ff', 1, 0.5);
    return;
  }

  // 5) Hit lands on the player! Reset rally streak
  e.rallyStreak = 0;
  const heavy = !!move.finisher || move.knockdown;
  if (move.sfx === 'nunchaku') g.sfx.nunchakuHit(heavy);
  else if (move.sfx === 'slash') g.sfx.slashHit(heavy);
  else if (move.sfx === 'axe') { g.sfx.axeHit(heavy); if (move.bat) g.sfx.batCrack(); }
  else if (move.sfx === 'dual') g.sfx.dualHit();
  else if (move.sfx === 'yoyo') g.sfx.yoyoHit(heavy);
  else if (move.sfx === 'kick') g.sfx.kick();
  else if (move.sfx === 'punch') g.sfx.punch();
  else g.sfx.heavy();

  const hx = p.x - Math.cos(a) * p.r, hy = p.y - 6 - p.z;
  g.particles.spark(hx, hy, heavy ? 9 : 5, '#ffffff', a, 0.9, 200);
  g.particles.impact(hx, hy, heavy ? 7 : 5, e.color);
  g.damagePlayer(heavy ? 2 : 1, a, heavy);
}

export function pickBossCombo(e: Enemy, d: number, enraged: boolean, playerAirborne = false): string[] {
  const w = e.rivalWeapon ?? 'nunchaku';
  const r = Math.random();
  switch (w) {
    case 'nunchaku': {
      if (playerAirborne) return ['NLL', 'NLH'];
      if (d > 48) {
        if (r < 0.48) return ['NRUN'];
        if (r < 0.82) return ['NDASH', 'NL', 'NLL', 'NLH'];
        return ['NL', 'NLL', 'NLLL', 'NLLLL'];
      }
      if (r < 0.34) return enraged ? ['NL', 'NLL', 'NLLL', 'NLLLL', 'NLLLLL'] : ['NL', 'NLL', 'NLLL', 'NLLLL'];
      if (r < 0.56) return ['NL', 'NLL', 'NLH'];
      if (r < 0.74) return ['NH', 'NHL'];
      if (r < 0.88) return ['NL', 'NLLH'];
      return ['NHL', 'NHH'];
    }
    case 'katana': {
      if (playerAirborne) return ['KLH', 'KLLL'];
      if (d > 50) {
        if (r < 0.52) return ['KRUN'];
        return ['KDASH', 'KL', 'KLL', 'KSHEATH'];
      }
      if (r < 0.32) return ['KL', 'KLL', 'KLLL', 'KLLLL'];
      if (r < 0.55) return ['KL', 'KLL', 'KSHEATH'];
      if (r < 0.75) return ['KL', 'KLH', 'KLLL'];
      if (r < 0.88) return ['KH', 'KHL'];
      return ['KLLH', 'KHH'];
    }
    case 'fist': {
      if (playerAirborne) return ['LLLH', 'HLH'];
      if (d > 44) {
        if (r < 0.45) return ['TKD'];
        if (r < 0.75) return ['DASH', 'L', 'LL', 'LH'];
        return ['RUNPUNCH', 'HHL'];
      }
      if (r < 0.28) return ['S1', 'S2', 'S3', 'S4', enraged ? 'S8' : 'S5'];
      if (r < 0.52) return ['CHAIN', 'CHAIN', 'CHAIN', 'CHAIN', 'CHAINEND'];
      if (r < 0.72) return ['L', 'LL', 'LLL', 'LLLL', 'LLLLL'];
      if (r < 0.86) return ['H', 'HL', 'HLL', 'HH'];
      return ['LLH', 'LLLH'];
    }
    case 'bat': {
      if (playerAirborne) return ['B_POP', 'B_PEPPER', 'B_SPIKE'];
      if (d > 50) {
        return r < 0.55 ? ['BRUN'] : ['BDASH', 'SB_F', 'SB_SMASH'];
      }
      if (r < 0.34) return ['SB_F', 'SB_B', 'B_BEHIND', 'B_SLAM'];
      if (r < 0.6) return ['B_BUNT', 'B_POP', 'B_PEPPER', 'B_SPIKE'];
      if (r < 0.82) return ['SB_F', 'SB_B', 'SB_UPPER', 'B_HOMER'];
      return ['SB_SPIN', 'BH'];
    }
    case 'dual': {
      if (playerAirborne) return ['DLH', 'DLLLL'];
      if (d > 48) {
        return r < 0.55 ? ['DRUN'] : ['DDASH', 'DL', 'DLLL'];
      }
      if (r < 0.38) return ['DL', 'DLL', 'DLLL', 'DLLLL'];
      if (r < 0.68) return ['DL', 'DLH', 'DLL'];
      return ['DH', 'DLLLL'];
    }
    case 'yoyo': {
      if (r < 0.42) return ['YL', 'YLL', 'YLLL', 'YLLLL', 'YLLLLL'];
      if (r < 0.72) return ['YH', 'YLH'];
      return ['YL', 'YHL', 'YLLL'];
    }
    case 'axe': {
      if (playerAirborne) return ['ALH', 'ALLL'];
      if (d > 50) {
        return r < 0.55 ? ['ARUN'] : ['ADASH', 'AL', 'ALL'];
      }
      if (r < 0.38) return ['AL', 'ALL', 'ALLL'];
      if (r < 0.7) return ['AHL', 'ALH', 'ALLH'];
      return ['AH'];
    }
    case 'takamura':
    default: {
      if (d > 52) {
        return r < 0.6 ? ['KRUN', 'KL', 'KSHEATH'] : ['KDASH', 'KLLL', 'KLLLL'];
      }
      if (r < 0.35) return ['KL', 'KLL', 'KLLL', 'KSHEATH'];
      if (r < 0.68) return ['KH', 'KHL', 'KHH'];
      return ['KLLH', 'KLH', 'KRUN'];
    }
  }
}

export function startBossMove(g: Game, e: Enemy, key: string, firstInChain: boolean, fastRiposte = false) {
  const move = MOVES[key];
  if (!move) return;
  const p = g.player;
  const enraged = e.hp < e.maxHp * 0.5;
  e.attackSerial = (e.attackSerial ?? 0) + 1;
  e.moveKey = key;
  e.attackPhase = 'windup';
  const baseWu = fastRiposte
    ? Math.max(0.18, move.windup * 1.45)
    : firstInChain
      ? Math.max(0.16, move.windup * 1.55) * (enraged ? 0.85 : 1)
      : Math.max(0.05, move.windup * 1.05) * (enraged ? 0.85 : 1);
  e.attackT = baseWu;
  e.poseDur = baseWu;
  e.pose = move.pose;
  e.poseT = 0;
  e.hitDone = false;
  e.travelHit = false;
  e.prevLimb = null;
  if (move.id === 'chain') e.chainSide = (e.chainSide ?? 1) * -1;
  e.aim = Math.atan2(p.y - e.y, p.x - e.x);
  e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
  if (move.katana || move.axe || move.dual || move.bat) {
    e.sheatheT = 0;
    e.bladeA = e.aim + (move.slash ? move.slash.from * e.facing : 0);
    e.bladePrevA = e.bladeA;
    e.bladeB = e.aim - (move.slash ? move.slash.from * e.facing : 0);
  }
}

export function updateEnemy(g: Game, e: Enemy, dt: number) {
  const p = g.player;
  // When locked in an exchange duel, Game.updateClash drives both characters directly at the current beat tempo
  if (g.clashDuel && g.clashDuel.id === e.id) {
    return;
  }

  e.poseT += dt / Math.max(0.01, e.poseDur);
  e.sqx = (e.sqx ?? 1) + (1 - (e.sqx ?? 1)) * Math.min(1, dt * 10);
  e.sqy = (e.sqy ?? 1) + (1 - (e.sqy ?? 1)) * Math.min(1, dt * 10);
  if (e.flash > 0) e.flash -= dt;
  if (e.flinch > 0) e.flinch -= dt;
  if (e.parryCd > 0) e.parryCd -= dt;
  if ((e.dashCd ?? 0) > 0) e.dashCd = (e.dashCd ?? 0) - dt;
  if ((e.parryT ?? 0) > 0) e.parryT = (e.parryT ?? 0) - dt;
  e.counterLockT = Math.max(0, (e.counterLockT ?? 0) - dt);
  if ((e.rallyWindow ?? 0) > 0) {
    e.rallyWindow = (e.rallyWindow ?? 0) - dt;
    if ((e.rallyWindow ?? 0) <= 0 && e.attackPhase === 'none') e.rallyStreak = 0;
  }
  if ((e.backstepCd ?? 0) > 0) e.backstepCd = (e.backstepCd ?? 0) - dt;
  if ((e.feintCd ?? 0) > 0) e.feintCd = (e.feintCd ?? 0) - dt;
  if ((e.playerSpamCount ?? 0) > 0) e.playerSpamCount = Math.max(0, (e.playerSpamCount ?? 0) - dt * 1.4);

  e.moving = false;
  e.vx = 0; e.vy = 0;
  if (e.spawnT > 0) {
    e.spawnT -= dt;
    e.aim = Math.atan2(p.y - e.y, p.x - e.x);
    e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
    updateBossWeaponPhysics(g, e, dt);
    return;
  }

  // Awakening announcement at 50% HP
  if (e.hp <= e.maxHp * 0.5 && e.phase === 0) {
    e.phase = 1;
    g.say(`${e.name} AWAKENED!`, e.color, 2, 1.3);
    g.particles.shockwave(e.x, e.y - 4, 44, e.color, 0.4);
    g.particles.ring(e.x, e.y - 6, 3, 22, '#ffffff', 0.25, 2);
    g.sfx.focus();
    g.shake(0.45);
  }
  if (e.phase === 1 && Math.random() < 0.35) {
    g.particles.add({ x: e.x + rnd(-5, 5), y: e.y - 6 + rnd(-8, 4), vx: rnd(-10, 10), vy: rnd(-45, -18), life: rnd(0.25, 0.5), c: Math.random() < 0.5 ? e.color : e.color2, k: 7 });
  }

  // Bleeding DoT
  if (e.bleed > 0) {
    e.bleedT -= dt;
    if (e.bleedT <= 0) {
      e.bleedT = 0.35; e.bleed--; e.hp -= 1;
      g.particles.blood(e.x, e.y - 6 - e.z, 2, rnd(0, 6.3), 50);
      if (Math.random() < 0.5) g.stamp(e.x + rnd(-3, 3), e.y + rnd(0, 3), '#8a0000', 1);
      if (e.hp <= 0) { g.killEnemy(e, rnd(0, 6.3), 80, false, true); return; }
    }
  }
  if (e.doom > 0) {
    e.doom -= dt; e.pose = 'stagger'; e.vx = e.vy = 0;
    if (e.doom <= 0) g.iaiKill(e);
    return;
  }
  // Airborne ragdoll launch (when knocked into the air)
  if ((e.z > 0 || e.vz !== 0) && e.attackPhase === 'none') {
    e.vz -= 520 * dt;
    e.z += e.vz * dt;
    e.pose = 'launched';
    e.rot = Math.max(-0.9, Math.min(0.9, -e.vz / 350)) * e.facing;
    if (e.z <= 0) { const impact = -e.vz; e.z = 0; e.vz = 0; e.rot = 0; g.enemyLand(e, impact); }
    updateBossWeaponPhysics(g, e, dt);
    return;
  }

  const ddx = p.x - e.x, ddy = p.y - e.y;
  const d = Math.hypot(ddx, ddy) || 1;
  const ang = Math.atan2(ddy, ddx);

  if (e.stagger > 0) {
    e.stagger -= dt; e.pose = 'stagger'; e.attackPhase = 'none'; e.comboQueue = []; e.rallyStreak = 0;
    if (e.stagger <= 0) { e.structure = 0; e.state = 'chase'; e.attackCd = 0.35; }
    updateBossWeaponPhysics(g, e, dt);
    return;
  }
  if (e.down > 0) {
    e.down -= dt; e.pose = 'down'; e.attackPhase = 'none'; e.comboQueue = []; e.rallyStreak = 0;
    if (e.down <= 0) {
      e.structure *= 0.6;
      if (g.v2) { e.stun = 0.55; e.state = 'stun'; e.pose = 'hurt'; e.attackCd = 0.65; e.getupT = 0.24; e.fall = undefined; }
      else { e.state = 'chase'; e.attackCd = 0.4; }
    }
    updateBossWeaponPhysics(g, e, dt);
    return;
  }
  if (e.stun > 0) {
    e.stun -= dt; e.attackPhase = 'none'; e.comboQueue = [];
    if ((e.getupT ?? 0) > 0) { e.getupT = (e.getupT ?? 0) - dt; e.pose = 'getup'; }
    else e.pose = e.state === 'parryRecoil' ? 'parry' : 'hurt';
    if (e.stun <= 0) e.state = 'chase';
    updateBossWeaponPhysics(g, e, dt);
    return;
  }
  if ((e.counterLockT ?? 0) > 0) {
    e.pose = bossIdlePose(e.rivalWeapon);
    updateBossWeaponPhysics(g, e, dt);
    return;
  }

  // Grandmaster Bullet Deflection: if player shoots from afar, Boss deflects the bullet with their weapon!
  for (const b of g.bullets) {
    if (b.owner === 'player' && dist(b.x, b.y, e.x, e.y - 5) < e.r + 22) {
      b.owner = 'enemy';
      const sp = Math.hypot(b.vx, b.vy) * 0.65;
      const da = ang + rnd(-0.18, 0.18);
      b.vx = Math.cos(da) * sp;
      b.vy = Math.sin(da) * sp;
      b.color = e.color;
      b.dmg = 1;
      e.parryT = 0.16;
      e.flourishT = 0.35;
      g.sfx.clashPing(1.25);
      g.particles.spark(b.x, b.y, 7, e.color, da, 0.9, 190);
      g.particles.ring(e.x, e.y - 6, 3, 13, e.color, 0.16, 1);
      g.texts.add(e.x, e.y - 22, 'DEFLECT!', e.color, 1, 0.45);
      break;
    }
  }

  if (e.structure > 0 && e.attackPhase === 'none') {
    e.structure = Math.max(0, e.structure - e.maxStructure * 0.045 * dt);
  }
  if (e.attackCd > 0) e.attackCd -= dt;

  aiRivalBoss(g, e, dt, d, ang);
  updateBossWeaponPhysics(g, e, dt);

  const gs = Math.hypot(e.vx + e.kx * 0.3, e.vy + e.ky * 0.3);
  if (e.attackPhase === 'none' && (e.dashT ?? 0) <= 0 && gs > 5) {
    e.runT = (e.runT ?? 0) + dt;
    const stepsPerSec = 3 + 2.5 * Math.min(1, gs / 160);
    e.strideHalf = Math.min(5.6 * e.scale, Math.max(2.4 * e.scale, gs / (4 * stepsPerSec)));
    e.walk += dt * stepsPerSec * Math.PI;
  } else {
    e.runT = 0;
    if (!e.moving) e.walk = 0;
  }
  if (e.attackPhase === 'none' && e.moving && gs > 35 && Math.abs(e.vx) > 6) {
    e.facing = e.vx >= 0 ? 1 : -1;
    e.bodyAim = Math.atan2(e.vy, e.vx);
  } else {
    e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
    e.bodyAim = e.aim;
  }
}

function aiRivalBoss(g: Game, e: Enemy, dt: number, d: number, ang: number) {
  const p = g.player;
  const los = g.hasLOS(e);
  const enraged = e.hp < e.maxHp * 0.5;
  const LS = g.longMode ? 2.5 : 1;

  // 1) Shadow Step dash in progress
  if ((e.dashT ?? 0) > 0) {
    e.dashT = (e.dashT ?? 0) - dt;
    const dir = e.dashDir ?? { x: Math.cos(ang), y: Math.sin(ang) };
    e.vx = dir.x * 390;
    e.vy = dir.y * 390;
    e.moving = true;
    e.pose = 'dash';
    e.aim = ang;
    g.addAfterimage({ x: e.x, y: e.y - e.z, facing: e.facing, aim: e.aim, pose: 'dash', poseT: 0 }, e.color, dir);
    if ((e.dashT ?? 0) <= 0 && d < 72 * LS) {
      // Instant counter combo right out of Shadow Step!
      const combo = pickBossCombo(e, d / LS, enraged, p.airborne);
      const first = combo.shift()!;
      e.comboQueue = combo;
      startBossMove(g, e, first, true);
    }
    return;
  }

  // 2) Active Parry stance
  if ((e.parryT ?? 0) > 0) {
    e.pose = 'parry';
    e.aim = ang;
    return;
  }

  // 3) Executing a Player Move from MOVES[e.moveKey]
  if (e.attackPhase && e.attackPhase !== 'none' && e.moveKey) {
    const attackKey = e.moveKey;
    const move = MOVES[attackKey];
    if (!move) { e.attackPhase = 'none'; e.moveKey = null; return; }
    const spdMul = enraged ? 1.16 : 1.02;
    e.attackT = (e.attackT ?? 0) - dt * spdMul;
    e.pose = move.pose;

    if (e.attackPhase === 'windup') {
      e.aim = lerpAngle(e.aim, ang, dt * 10);
      e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
      if ((e.attackT ?? 0) <= 0) {
        e.attackPhase = 'active';
        e.attackT = move.active;
        e.kx += Math.cos(e.aim) * move.lunge * 0.92;
        e.ky += Math.sin(e.aim) * move.lunge * 0.92;
        g.sfx.swing(move.sfx === 'heavy' ? 0.7 : move.sfx === 'kick' ? 0.85 : move.sfx === 'nunchaku' ? 1.4 : 1.1);
        if (move.id === 'n_whipcrack' || move.id === 'n_overhead' || move.id === 'n_dragonlash' || move.id === 'k_iaijutsu') {
          g.sfx.whoosh();
        }
        if (move.showName && (!e.comboQueue || e.comboQueue.length === 0)) {
          g.texts.add(e.x, e.y - 24 - e.z, move.name, e.color, 1, 0.55);
        }
      }
      return;
    }

    if (e.attackPhase === 'active') {
      if (move.travel) {
        const prog = clamp(1 - (e.attackT ?? 0) / Math.max(0.01, move.active), 0, 1);
        if (!move.air) e.z = (move.jump ?? 0) * Math.sin(Math.PI * prog);
        const sp = move.travel * (e.hitDone ? 0.25 : 0.9);
        e.vx = Math.cos(e.aim) * sp;
        e.vy = Math.sin(e.aim) * sp;
        e.moving = true;
        g.addAfterimage({ x: e.x, y: e.y - e.z, facing: e.facing, aim: e.aim, pose: move.pose, poseT: 0.5 }, e.color, { x: Math.cos(e.aim), y: Math.sin(e.aim) });
      } else if (d > 17 * LS) {
        e.vx = Math.cos(e.aim) * e.speed * 0.48;
        e.vy = Math.sin(e.aim) * e.speed * 0.48;
        e.moving = true;
      }
      if (move.id === 's_diable' && Math.random() < 0.7) {
        g.particles.ember(e.x + Math.cos(e.aim) * 10, e.y - 6, 2, '#ff6a00');
      }
      resolveBossMelee(g, e, move);
      if (g.clashDuel || e.attackPhase !== 'active' || e.moveKey !== attackKey || e.stun > 0 || e.stagger > 0) return;
      if ((e.attackT ?? 0) <= 0) {
        e.attackPhase = 'recover';
        e.attackT = move.recover;
        e.z = 0;
        if (move.id === 'n_dragonlash' || move.id === 'b_spike' || move.id === 'sb_smash' || move.id === 'a_overhead') {
          const gx = e.x + Math.cos(e.aim) * 14, gy = e.y + Math.sin(e.aim) * 6;
          g.particles.shockwave(gx, gy, 24, e.color, 0.28);
          g.particles.smoke(gx, gy, 5, '#888', 32, 0.4);
          g.sfx.slam();
          g.shake(0.3);
        }
        if (move.katana && (!e.comboQueue || e.comboQueue.length === 0)) {
          e.sheatheT = 0.42;
          if (move.id === 'k_sheatheflash') {
            g.particles.ring(e.x, e.y - 6, 4, 20, '#ffffff', 0.24, 1);
            g.sfx.sheathe();
          }
        }
      }
      return;
    }

    if (e.attackPhase === 'recover') {
      // Smart Recovery Cancel: if player tries to counter-attack during boss recovery, Boss can Shadow-Step or Parry!
      const playerCountering = (p.attackPhase === 'windup' || p.attackPhase === 'active') && d < 36 * LS;
      if (playerCountering && e.parryCd <= 0 && Math.random() < 1 - Math.exp(-(enraged ? 4 : 2.5) * dt)) {
        e.attackPhase = 'none';
        e.comboQueue = [];
        e.parryT = 0.22;
        e.pose = 'parry';
        g.particles.ring(e.x, e.y - 6, 3, 11, '#ffd700', 0.16, 1);
        return;
      }
      if (e.comboQueue && e.comboQueue.length > 0 && (e.attackT ?? 0) <= move.recover * 0.58) {
        const nextKey = e.comboQueue.shift()!;
        const maxD = e.rivalWeapon === 'yoyo' ? 95 * LS : 60 * LS;
        if (d <= maxD || MOVES[nextKey]?.travel) {
          startBossMove(g, e, nextKey, false);
          return;
        }
        e.comboQueue = [];
      }
      if ((e.attackT ?? 0) <= 0) {
        e.attackPhase = 'none';
        e.moveKey = null;
        e.comboQueue = [];
        e.attackCd = (enraged ? rnd(0.24, 0.48) : rnd(0.36, 0.68)) * e.cdMul;
      }
      return;
    }
  }

  // 4) Smart Grandmaster Tactical Reactions in Neutral
  e.aim = ang;
  const idealDist = (e.rivalWeapon === 'yoyo' ? 54 : 25) * LS;
  const playerAttacking = p.attackPhase === 'windup' || p.attackPhase === 'active' || (g.sfNunOn && g.sfNun.attacking);

  // TACTIC A: Whiff-Punish Backstep -> Lunge Counter!
  if (playerAttacking && d > 18 * LS && d < 38 * LS && (e.backstepCd ?? 0) <= 0 && Math.random() < 0.32) {
    e.backstepCd = 3.2;
    e.kx -= Math.cos(ang) * 230;
    e.ky -= Math.sin(ang) * 230;
    g.addAfterimage({ x: e.x, y: e.y, facing: e.facing, aim: e.aim, pose: 'dash', poseT: 0 }, e.color);
    g.particles.smoke(e.x, e.y, 4, '#aaa', 22, 0.3);
    g.texts.add(e.x, e.y - 22, 'BACKSTEP!', '#ffffff', 1, 0.45);
    g.sfx.dash();
    const rw = e.rivalWeapon ?? 'nunchaku';
    const lungeKey = rw === 'nunchaku' ? 'NRUN' : rw === 'katana' || rw === 'takamura' ? 'KRUN' : rw === 'bat' ? 'BRUN' : rw === 'dual' ? 'DRUN' : rw === 'axe' ? 'ARUN' : rw === 'yoyo' ? 'YLLL' : 'TKD';
    e.comboQueue = [];
    startBossMove(g, e, lungeKey, true);
    return;
  }

  // TACTIC B: Shadow-Step Cross-Up Behind Player's Back!
  if ((e.feintCd ?? 0) <= 0 && d < 58 * LS && d > 16 * LS && los && Math.random() < (enraged ? 0.045 : 0.025)) {
    e.feintCd = enraged ? 3.4 : 4.8;
    const behindX = p.x + Math.cos(ang) * 18 * LS;
    const behindY = p.y + Math.sin(ang) * 18 * LS;
    if (g.isFree(behindX, behindY, e.r)) {
      for (let i = 1; i <= 4; i++) {
        const f = i / 5;
        g.addAfterimage({ x: e.x + (behindX - e.x) * f, y: e.y + (behindY - e.y) * f, facing: e.facing, aim: e.aim, pose: 'dash', poseT: 0 }, e.color);
      }
      e.x = behindX;
      e.y = behindY;
      e.aim = Math.atan2(p.y - e.y, p.x - e.x);
      e.facing = Math.cos(e.aim) >= 0 ? 1 : -1;
      g.sfx.dash();
      g.particles.ring(e.x, e.y - 6, 2, 14, e.color, 0.2, 1);
      g.texts.add(e.x, e.y - 24, 'BLINK STEP!', e.color, 1, 0.55);
      const combo = pickBossCombo(e, 18, enraged, p.airborne);
      const first = combo.shift()!;
      e.comboQueue = combo;
      startBossMove(g, e, first, true);
      return;
    }
  }

  // TACTIC C: Side-Flank Shadow Step
  if ((e.dashCd ?? 0) <= 0 && los) {
    const closeGap = d > 90 * LS && d < 170 * LS && e.attackCd <= 0.1;
    if ((playerAttacking && d < 46 * LS && Math.random() < 0.35) || (closeGap && Math.random() < 0.4)) {
      e.dashT = 0.15;
      e.dashCd = enraged ? 1.4 : 2.1;
      const sideAng = ang + (Math.PI / 2.6) * e.strafeDir;
      e.dashDir = playerAttacking
        ? { x: Math.cos(sideAng), y: Math.sin(sideAng) }
        : { x: Math.cos(ang), y: Math.sin(ang) };
      g.sfx.dash();
      g.particles.smoke(e.x, e.y, 4, e.color, 24, 0.35);
      g.particles.ring(e.x, e.y - 6, 2, 10, e.color, 0.18, 1);
      return;
    }
  }

  // Movement: sprint when far, weave/strafe in martial-arts stance when close
  if (d > idealDist + 10) {
    const sprintMul = d > 65 ? 1.2 : 1.0;
    steer(g, e, p.x, p.y, e.speed * sprintMul, !los);
  } else if (d < idealDist - 12 && e.rivalWeapon === 'yoyo') {
    applyMove(g, e, -Math.cos(ang), -Math.sin(ang), e.speed * 0.75);
  } else {
    strafe(g, e, ang, dt, e.speed * 0.72);
  }

  e.pose = e.moving && (e.runT ?? 0) > 0.06 && d > idealDist + 14
    ? 'run'
    : bossIdlePose(e.rivalWeapon, e.sheatheT ?? 0);

  // Start a combo when cooldown is ready!
  const triggerDist = (e.rivalWeapon === 'yoyo' ? 90 : 96) * LS;
  if (e.attackCd <= 0 && los && d <= triggerDist) {
    const combo = pickBossCombo(e, d / LS, enraged, p.airborne);
    const first = combo.shift()!;
    e.comboQueue = combo;
    startBossMove(g, e, first, true);
  }
}

import {
  WATER_SURFACE_Y,
  VIRTUAL_HEIGHT,
  VIRTUAL_WIDTH,
  type AquariumSettings,
  type Bubble,
  type DecorItemKind,
  type DecorPlacement,
  type HoverTarget,
  type InteractiveStates,
  type LightPulse,
  type Spore,
  type SubstrateProfile,
  type SurfaceSplash,
} from './types';
import {
  FLORA_RAMPS,
  SAND_PALETTES,
  bayerThreshold,
  getAtmosphereAtTime,
  hexToRgb,
  lerpColor,
  type WaterAtmospherePalette,
} from './palettes';
import { getSpriteSet, isSpriteKind, type CompiledSprite } from './sprites';

const GRID_COLS = 30;
const GRID_ROWS = 17;
const CELL_SIZE = 16;

function seededRand(seed: number): () => number {
  let s = (seed | 0) || 1337;
  return () => {
    s = (s * 1664525 + 1013904223) | 0;
    return ((s >>> 0) % 100000) / 100000;
  };
}

export class PixelAquariumEngine {
  private buffer: HTMLCanvasElement;
  private bctx: CanvasRenderingContext2D;

  // Offscreen static backdrop cache (sky/water gradient + distant silhouettes + sandbed)
  private bgCache: HTMLCanvasElement;
  private bgCtx: CanvasRenderingContext2D;
  private bgDirty = true;
  private lastBgSignature = '';

  // Offscreen hardscape cache for static rocks & driftwood
  private hardscapeCache: Map<string, { canvas: HTMLCanvasElement; ax: number; ay: number }> =
    new Map();

  // Simulation time
  private time = 0;
  private cycleTime = 0;

  // Fluid current field
  private vx = new Float32Array(GRID_COLS * GRID_ROWS);
  private vy = new Float32Array(GRID_COLS * GRID_ROWS);

  // Surface waves (1D spring model along 480 columns)
  private waveY = new Float32Array(VIRTUAL_WIDTH);
  private waveV = new Float32Array(VIRTUAL_WIDTH);

  // Dynamic particles
  private bubbles: Bubble[] = [];
  private spores: Spore[] = [];
  private splashes: SurfaceSplash[] = [];
  private pulses: LightPulse[] = [];

  // Scene data
  private substrate: SubstrateProfile;
  private placements: DecorPlacement[] = [];
  private interactive: InteractiveStates = {
    chestOpen: true,
    clamOpen: true,
    lanternLit: true,
    volcanoBoost: 0.4,
    crystalPulse: 0,
    runesBoost: 0.3,
    helmetBubbles: 0,
  };

  // Placement ghost preview
  public previewBrush: { kind: DecorItemKind; x: number; y: number; height?: number } | null =
    null;

  constructor(substrate: SubstrateProfile, placements: DecorPlacement[]) {
    this.buffer = document.createElement('canvas');
    this.buffer.width = VIRTUAL_WIDTH;
    this.buffer.height = VIRTUAL_HEIGHT;
    this.bctx = this.buffer.getContext('2d', { alpha: false })!;
    this.bctx.imageSmoothingEnabled = false;

    this.bgCache = document.createElement('canvas');
    this.bgCache.width = VIRTUAL_WIDTH;
    this.bgCache.height = VIRTUAL_HEIGHT;
    this.bgCtx = this.bgCache.getContext('2d', { alpha: false })!;
    this.bgCtx.imageSmoothingEnabled = false;

    this.substrate = substrate;
    this.placements = placements;

    this.initSpores();
    this.seedInitialBubbles();
  }

  public setScene(substrate: SubstrateProfile, placements: DecorPlacement[]): void {
    this.substrate = substrate;
    this.placements = placements;
    this.bgDirty = true;
    this.bubbles = [];
    this.seedInitialBubbles();
    this.initSpores();
  }

  public updatePlacements(placements: DecorPlacement[]): void {
    this.placements = placements;
  }

  public getSubstrateY(x: number): number {
    const ix = Math.max(0, Math.min(VIRTUAL_WIDTH - 1, Math.round(x)));
    return this.substrate.heights[ix] ?? 225;
  }

  public getInteractiveStates(): InteractiveStates {
    return { ...this.interactive };
  }

  public getStats(): { bubbles: number; spores: number; items: number } {
    return {
      bubbles: this.bubbles.length,
      spores: this.spores.length,
      items: this.placements.length,
    };
  }

  private initSpores(): void {
    this.spores = [];
    const rand = seededRand(90210);
    const colors = [
      { c: '#ccfbff', g: '#22d3ee' },
      { c: '#d9f99d', g: '#84cc16' },
      { c: '#f5d0fe', g: '#e879f9' },
      { c: '#fef08a', g: '#f59e0b' },
    ];
    for (let i = 0; i < 64; i++) {
      const pick = colors[i % colors.length];
      this.spores.push({
        x: rand() * VIRTUAL_WIDTH,
        y: WATER_SURFACE_Y + 12 + rand() * (VIRTUAL_HEIGHT - WATER_SURFACE_Y - 46),
        vx: (rand() - 0.5) * 4,
        vy: (rand() - 0.5) * 3,
        phase: rand() * Math.PI * 2,
        color: pick.c,
        glowColor: pick.g,
        size: rand() > 0.82 ? 2 : 1,
      });
    }
  }

  private seedInitialBubbles(): void {
    for (let i = 0; i < 24; i++) {
      this.bubbles.push({
        x: 30 + Math.random() * (VIRTUAL_WIDTH - 60),
        y: WATER_SURFACE_Y + 10 + Math.random() * 190,
        vx: 0,
        vy: -(16 + Math.random() * 20),
        size: Math.random() > 0.72 ? 2 : 1,
        wobblePhase: Math.random() * Math.PI * 2,
        wobbleSpeed: 2.5 + Math.random() * 2.5,
        tint: 'cyan',
        age: Math.random() * 4,
      });
    }
  }

  public stirWater(
    vxPixel: number,
    vyPixel: number,
    forceX: number,
    forceY: number
  ): void {
    const gx = Math.floor(vxPixel / CELL_SIZE);
    const gy = Math.floor(vyPixel / CELL_SIZE);
    for (let dy = -2; dy <= 2; dy++) {
      for (let dx = -2; dx <= 2; dx++) {
        const cx = gx + dx;
        const cy = gy + dy;
        if (cx >= 0 && cx < GRID_COLS && cy >= 0 && cy < GRID_ROWS) {
          const dist = Math.hypot(dx, dy);
          const weight = Math.max(0, 1 - dist / 2.6);
          const idx = cy * GRID_COLS + cx;
          this.vx[idx] = Math.max(-75, Math.min(75, this.vx[idx] + forceX * weight));
          this.vy[idx] = Math.max(-75, Math.min(75, this.vy[idx] + forceY * weight));
        }
      }
    }

    // Ripple surface if near top
    if (vyPixel < WATER_SURFACE_Y + 55) {
      const strength = Math.max(0.2, 1 - Math.abs(vyPixel - WATER_SURFACE_Y) / 55);
      const sx = Math.max(2, Math.min(VIRTUAL_WIDTH - 3, Math.round(vxPixel)));
      for (let k = -6; k <= 6; k++) {
        const idx = sx + k;
        if (idx > 0 && idx < VIRTUAL_WIDTH - 1) {
          this.waveV[idx] += (forceY * 0.08 + 18) * strength * (1 - Math.abs(k) / 7);
        }
      }
    }

    // Spawn tiny stirred micro-bubbles occasionally
    if (Math.random() < 0.32 && this.bubbles.length < 180) {
      this.bubbles.push({
        x: vxPixel + (Math.random() - 0.5) * 10,
        y: Math.max(WATER_SURFACE_Y + 6, vyPixel + (Math.random() - 0.5) * 8),
        vx: forceX * 0.35,
        vy: -(18 + Math.random() * 20),
        size: 1,
        wobblePhase: Math.random() * Math.PI * 2,
        wobbleSpeed: 3 + Math.random() * 2,
        tint: 'silver',
        age: 0,
      });
    }
  }

  public addRippleAt(x: number, y: number): void {
    const sx = Math.max(4, Math.min(VIRTUAL_WIDTH - 5, Math.round(x)));
    for (let k = -8; k <= 8; k++) {
      const idx = sx + k;
      if (idx > 0 && idx < VIRTUAL_WIDTH - 1) {
        this.waveV[idx] -= Math.cos((k / 8) * Math.PI * 0.5) * 28;
      }
    }
    this.pulses.push({
      x,
      y: Math.max(WATER_SURFACE_Y + 6, y),
      radius: 2,
      maxRadius: 28,
      color: '#99f6ff',
      alpha: 0.7,
    });
  }

  public findHoverTarget(vxPixel: number, vyPixel: number): HoverTarget | null {
    // Check interactive items in reverse front-to-back order
    for (let i = this.placements.length - 1; i >= 0; i--) {
      const p = this.placements[i];
      if (!p.interactive && !this.isNaturallyInteractive(p.kind)) continue;
      const box = this.getItemHitbox(p);
      if (
        vxPixel >= box.x1 &&
        vxPixel <= box.x2 &&
        vyPixel >= box.y1 &&
        vyPixel <= box.y2
      ) {
        return {
          id: p.id,
          kind: p.kind,
          label: p.label ?? this.defaultLabelFor(p.kind),
          hint: this.hintFor(p.kind),
          x: p.x,
          y: box.y1,
        };
      }
    }
    return null;
  }

  private isNaturallyInteractive(kind: DecorItemKind): boolean {
    return [
      'treasureChest',
      'pearlClam',
      'stoneLantern',
      'volcanoVent',
      'diverHelmet',
      'crystalCyan',
      'crystalAmethyst',
      'ancientPillar',
      'ancientArch',
    ].includes(kind);
  }

  private defaultLabelFor(kind: DecorItemKind): string {
    switch (kind) {
      case 'treasureChest':
        return 'Peti Harta Karun';
      case 'pearlClam':
        return 'Kerang Mutiara';
      case 'stoneLantern':
        return 'Lentera Batu Tōrō';
      case 'volcanoVent':
        return 'Kawah Gelembung';
      case 'diverHelmet':
        return 'Helm Penyelam';
      case 'crystalCyan':
        return 'Kristal Akuamarin';
      case 'crystalAmethyst':
        return 'Kristal Ametis';
      case 'ancientPillar':
        return 'Pilar Rune Kuno';
      case 'ancientArch':
        return 'Gerbang Kuil Kuno';
      default:
        return 'Hiasan Akuarium';
    }
  }

  private hintFor(kind: DecorItemKind): string {
    switch (kind) {
      case 'treasureChest':
        return this.interactive.chestOpen ? 'Klik untuk tutup peti' : 'Klik untuk buka harta karun';
      case 'pearlClam':
        return this.interactive.clamOpen ? 'Klik untuk tutup cangkang' : 'Klik untuk ungkap mutiara';
      case 'stoneLantern':
        return this.interactive.lanternLit ? 'Klik untuk redupkan lentera' : 'Klik untuk nyalakan lentera';
      case 'volcanoVent':
        return 'Klik untuk semburan gelembung!';
      case 'diverHelmet':
        return 'Klik untuk hembuskan gelembung';
      case 'crystalCyan':
      case 'crystalAmethyst':
        return 'Klik untuk resonansi cahaya kristal';
      case 'ancientPillar':
      case 'ancientArch':
        return 'Klik untuk bangkitkan cahaya rune';
      default:
        return 'Klik untuk berinteraksi';
    }
  }

  private getItemHitbox(p: DecorPlacement): {
    x1: number;
    y1: number;
    x2: number;
    y2: number;
  } {
    const s = p.scale ?? 1;
    let w = 22 * s;
    let h = 20 * s;
    if (p.kind === 'ancientArch') {
      w = 42 * s;
      h = 24 * s;
    } else if (p.kind === 'ancientPillar') {
      w = 16 * s;
      h = 20 * s;
    } else if (p.kind === 'stoneLantern') {
      w = 18 * s;
      h = 22 * s;
    }
    return {
      x1: p.x - w / 2 - 4,
      x2: p.x + w / 2 + 4,
      y1: p.y - h - 4,
      y2: p.y + 4,
    };
  }

  public triggerInteraction(
    target: HoverTarget
  ): { sound: 'chest-open' | 'chest-close' | 'crystal' | 'bubble' | 'none'; index: number } {
    const p = this.placements.find((item) => item.id === target.id);
    const px = p ? p.x : target.x;
    const py = p ? p.y - 10 : target.y;

    switch (target.kind) {
      case 'treasureChest': {
        this.interactive.chestOpen = !this.interactive.chestOpen;
        this.spawnBubbleBurst(px, py - 2, 16, 'gold');
        this.stirWater(px, py - 6, 0, -45);
        this.pulses.push({
          x: px,
          y: py,
          radius: 4,
          maxRadius: 48,
          color: '#fde047',
          alpha: 0.9,
        });
        return {
          sound: this.interactive.chestOpen ? 'chest-open' : 'chest-close',
          index: 2,
        };
      }
      case 'pearlClam': {
        this.interactive.clamOpen = !this.interactive.clamOpen;
        this.spawnBubbleBurst(px, py, 10, 'cyan');
        this.pulses.push({
          x: px,
          y: py,
          radius: 3,
          maxRadius: 42,
          color: '#a5f3fc',
          alpha: 0.85,
        });
        return { sound: 'crystal', index: 4 };
      }
      case 'stoneLantern': {
        this.interactive.lanternLit = !this.interactive.lanternLit;
        this.pulses.push({
          x: px,
          y: py - 2,
          radius: 3,
          maxRadius: 46,
          color: '#fb923c',
          alpha: 0.85,
        });
        return { sound: 'crystal', index: 1 };
      }
      case 'volcanoVent': {
        this.interactive.volcanoBoost = 1.0;
        this.spawnBubbleBurst(px, py - 3, 24, 'silver');
        this.stirWater(px, py - 10, 0, -65);
        this.pulses.push({
          x: px,
          y: py - 4,
          radius: 3,
          maxRadius: 40,
          color: '#fb923c',
          alpha: 0.8,
        });
        return { sound: 'bubble', index: 0 };
      }
      case 'diverHelmet': {
        this.interactive.helmetBubbles = 1.0;
        this.spawnBubbleBurst(px + 2, py - 4, 14, 'cyan');
        this.stirWater(px, py - 8, 12, -35);
        return { sound: 'bubble', index: 1 };
      }
      case 'crystalCyan':
      case 'crystalAmethyst': {
        this.interactive.crystalPulse = 1.0;
        this.pulses.push({
          x: px,
          y: py,
          radius: 4,
          maxRadius: 72,
          color: target.kind === 'crystalCyan' ? '#67e8f9' : '#e879f9',
          alpha: 0.95,
        });
        return {
          sound: 'crystal',
          index: target.kind === 'crystalCyan' ? 3 : 5,
        };
      }
      case 'ancientPillar':
      case 'ancientArch': {
        this.interactive.runesBoost = 1.0;
        this.pulses.push({
          x: px,
          y: py - 6,
          radius: 5,
          maxRadius: 85,
          color: '#38bdf8',
          alpha: 0.9,
        });
        return { sound: 'crystal', index: 0 };
      }
      default:
        return { sound: 'none', index: 0 };
    }
  }

  public spawnBubbleBurst(
    x: number,
    y: number,
    count: number,
    tint: Bubble['tint'] = 'cyan'
  ): void {
    for (let i = 0; i < count; i++) {
      if (this.bubbles.length >= 210) break;
      const sizeRoll = Math.random();
      const size: 1 | 2 | 3 = sizeRoll > 0.84 ? 3 : sizeRoll > 0.42 ? 2 : 1;
      this.bubbles.push({
        x: x + (Math.random() - 0.5) * 10,
        y: y + (Math.random() - 0.5) * 4,
        vx: (Math.random() - 0.5) * 14,
        vy: -(18 + Math.random() * 24),
        size,
        wobblePhase: Math.random() * Math.PI * 2,
        wobbleSpeed: 3 + Math.random() * 3,
        tint,
        age: 0,
      });
    }
  }

  private sampleFlow(x: number, y: number): [number, number] {
    const gx = Math.max(0, Math.min(GRID_COLS - 1, Math.floor(x / CELL_SIZE)));
    const gy = Math.max(0, Math.min(GRID_ROWS - 1, Math.floor(y / CELL_SIZE)));
    const idx = gy * GRID_COLS + gx;
    return [this.vx[idx], this.vy[idx]];
  }

  public step(dtRaw: number, settings: AquariumSettings): void {
    if (settings.paused) return;
    const dt = Math.min(0.05, dtRaw);
    this.time += dt;
    this.cycleTime += dt;

    // Decay interactive boosts gracefully
    this.interactive.volcanoBoost = Math.max(
      0.28,
      this.interactive.volcanoBoost - dt * 0.14
    );
    this.interactive.crystalPulse = Math.max(
      0,
      this.interactive.crystalPulse - dt * 0.45
    );
    this.interactive.runesBoost = Math.max(
      0.25,
      this.interactive.runesBoost - dt * 0.18
    );
    this.interactive.helmetBubbles = Math.max(
      0,
      this.interactive.helmetBubbles - dt * 0.65
    );

    // 1. Update fluid velocity grid with ambient circulating current + damping
    const currentNorm = settings.currentStrength / 100;
    const ambientFlow = Math.sin(this.time * 0.35) * 4.5 + 6.5 * currentNorm;
    for (let r = 0; r < GRID_ROWS; r++) {
      const depthFactor = 1 - r / GRID_ROWS;
      for (let c = 0; c < GRID_COLS; c++) {
        const idx = r * GRID_COLS + c;
        const targetVx =
          ambientFlow * (0.4 + 0.6 * depthFactor) +
          Math.sin(this.time * 0.8 + r * 0.5 + c * 0.3) * 3.2 * currentNorm;
        const targetVy =
          Math.cos(this.time * 0.6 + c * 0.4) * 1.4 * currentNorm;
        this.vx[idx] += (targetVx - this.vx[idx]) * dt * 1.6;
        this.vy[idx] += (targetVy - this.vy[idx]) * dt * 1.8;
      }
    }

    // 2. Update surface wave physics
    const waveTension = 42;
    const waveDamp = 2.4;
    for (let x = 1; x < VIRTUAL_WIDTH - 1; x++) {
      const lap = this.waveY[x - 1] + this.waveY[x + 1] - 2 * this.waveY[x];
      const accel =
        lap * 110 -
        this.waveY[x] * waveTension * 0.15 -
        this.waveV[x] * waveDamp;
      this.waveV[x] += accel * dt;
    }
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      this.waveY[x] += this.waveV[x] * dt;
      // Gentle persistent wave oscillation
      const ambientWave =
        Math.sin(x * 0.045 + this.time * 2.1) * 1.15 +
        Math.sin(x * 0.11 - this.time * 3.1) * 0.45;
      this.waveY[x] = this.waveY[x] * 0.985 + ambientWave * 0.015;
      this.waveY[x] = Math.max(-5, Math.min(5, this.waveY[x]));
    }

    // 3. Spawn ambient bubbles from volcano vents, open treasure chest, coral vents
    const densityMult = settings.bubbleDensity / 100;
    for (const p of this.placements) {
      if (p.kind === 'volcanoVent') {
        const rate = (3.5 + this.interactive.volcanoBoost * 16) * densityMult;
        if (Math.random() < rate * dt) {
          const sizeRoll = Math.random();
          const size: 1 | 2 | 3 = sizeRoll > 0.78 ? 3 : sizeRoll > 0.35 ? 2 : 1;
          this.bubbles.push({
            x: p.x + (Math.random() - 0.5) * 4,
            y: p.y - 12 * (p.scale ?? 1),
            vx: (Math.random() - 0.5) * 6,
            vy: -(22 + Math.random() * 20 + this.interactive.volcanoBoost * 14),
            size,
            wobblePhase: Math.random() * Math.PI * 2,
            wobbleSpeed: 3 + Math.random() * 2.5,
            tint: 'silver',
            age: 0,
          });
        }
      } else if (p.kind === 'treasureChest' && this.interactive.chestOpen) {
        if (Math.random() < 2.2 * densityMult * dt) {
          this.bubbles.push({
            x: p.x + (Math.random() - 0.5) * 8,
            y: p.y - 9 * (p.scale ?? 1),
            vx: 0,
            vy: -(16 + Math.random() * 14),
            size: Math.random() > 0.65 ? 2 : 1,
            wobblePhase: Math.random() * Math.PI * 2,
            wobbleSpeed: 3.4,
            tint: 'gold',
            age: 0,
          });
        }
      } else if (p.kind === 'pearlClam' && this.interactive.clamOpen) {
        if (Math.random() < 0.75 * densityMult * dt) {
          this.bubbles.push({
            x: p.x + (Math.random() - 0.5) * 4,
            y: p.y - 6,
            vx: 0,
            vy: -(14 + Math.random() * 10),
            size: 1,
            wobblePhase: Math.random() * Math.PI * 2,
            wobbleSpeed: 4,
            tint: 'cyan',
            age: 0,
          });
        }
      } else if (p.kind === 'diverHelmet' && this.interactive.helmetBubbles > 0.1) {
        if (Math.random() < 12 * dt) {
          this.bubbles.push({
            x: p.x + 2,
            y: p.y - 11,
            vx: 3 + Math.random() * 5,
            vy: -(20 + Math.random() * 14),
            size: Math.random() > 0.5 ? 2 : 1,
            wobblePhase: Math.random() * Math.PI * 2,
            wobbleSpeed: 4.5,
            tint: 'cyan',
            age: 0,
          });
        }
      }
    }

    // Subtle oxygen pearling bubbles rising from aquatic plants!
    if (Math.random() < 4.5 * densityMult * dt && this.bubbles.length < 180) {
      const flora = this.placements.filter((p) =>
        ['giantKelp', 'vallisneria', 'redLudwigia', 'javaFern', 'staghornCoral'].includes(
          p.kind
        )
      );
      if (flora.length > 0) {
        const pick = flora[Math.floor(Math.random() * flora.length)];
        this.bubbles.push({
          x: pick.x + (Math.random() - 0.5) * 10,
          y: pick.y - 8 - Math.random() * ((pick.height ?? 30) * 0.65),
          vx: 0,
          vy: -(12 + Math.random() * 10),
          size: 1,
          wobblePhase: Math.random() * Math.PI * 2,
          wobbleSpeed: 3.2,
          tint: 'cyan',
          age: 0,
        });
      }
    }

    // 4. Update bubbles
    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      const b = this.bubbles[i];
      b.age += dt;
      const [fx, fy] = this.sampleFlow(b.x, b.y);
      const wobble = Math.sin(b.age * b.wobbleSpeed + b.wobblePhase) * 9;
      b.x += (b.vx + fx * 0.55 + wobble) * dt;
      b.y += (b.vy + fy * 0.25) * dt;
      b.vx *= 0.94;

      if (b.x < 4) b.x = 4;
      if (b.x > VIRTUAL_WIDTH - 4) b.x = VIRTUAL_WIDTH - 4;

      const surfIx = Math.max(0, Math.min(VIRTUAL_WIDTH - 1, Math.round(b.x)));
      const surfaceAtX = WATER_SURFACE_Y + this.waveY[surfIx];
      if (b.y <= surfaceAtX) {
        if (b.size >= 2) {
          this.splashes.push({
            x: b.x,
            y: surfaceAtX,
            age: 0,
            maxAge: 0.35,
            radius: b.size === 3 ? 4 : 3,
          });
          const ix = Math.max(1, Math.min(VIRTUAL_WIDTH - 2, Math.round(b.x)));
          this.waveV[ix] -= b.size * 3.5;
        }
        this.bubbles.splice(i, 1);
      }
    }

    // 5. Update bioluminescent spores / plankton motes
    for (const s of this.spores) {
      const [fx, fy] = this.sampleFlow(s.x, s.y);
      const driftX = Math.sin(this.time * 0.9 + s.phase) * 3.5;
      const driftY = Math.cos(this.time * 0.7 + s.phase * 1.3) * 2.2;
      s.x += (s.vx + fx * 0.25 + driftX) * dt;
      s.y += (s.vy + fy * 0.2 + driftY) * dt;

      if (s.x < 4) s.x = VIRTUAL_WIDTH - 6;
      if (s.x > VIRTUAL_WIDTH - 4) s.x = 6;
      const maxY = this.getSubstrateY(s.x) - 6;
      if (s.y < WATER_SURFACE_Y + 8) s.y = maxY - 4;
      if (s.y > maxY) s.y = WATER_SURFACE_Y + 12;
    }

    // 6. Update surface splashes & light pulses
    for (let i = this.splashes.length - 1; i >= 0; i--) {
      this.splashes[i].age += dt;
      if (this.splashes[i].age >= this.splashes[i].maxAge) {
        this.splashes.splice(i, 1);
      }
    }
    for (let i = this.pulses.length - 1; i >= 0; i--) {
      const p = this.pulses[i];
      p.radius += dt * 78;
      p.alpha -= dt * 1.1;
      if (p.alpha <= 0 || p.radius >= p.maxRadius) {
        this.pulses.splice(i, 1);
      }
    }
  }

  public render(
    targetCanvas: HTMLCanvasElement,
    settings: AquariumSettings
  ): void {
    const atmo = getAtmosphereAtTime(settings.lighting, this.cycleTime);
    const sig = `${atmo.topColor}|${atmo.bottomColor}|${this.substrate.sandStyle}|${this.substrate.backdropStyle}`;
    if (this.bgDirty || sig !== this.lastBgSignature) {
      this.rebuildStaticBackground(atmo);
      this.lastBgSignature = sig;
      this.bgDirty = false;
    }

    const ctx = this.bctx;

    // 1. Copy dithered water gradient + distant silhouette backdrop + sandbed
    ctx.drawImage(this.bgCache, 0, 0);

    // 2. Volumetric pixel god-rays
    if (settings.godRaysEnabled && atmo.godRayAlpha > 0.02) {
      this.drawGodRays(ctx, atmo);
    }

    // 3. Animated water caustics dancing across substrate ridges
    if (settings.causticsEnabled && atmo.causticAlpha > 0.03) {
      this.drawCaustics(ctx, atmo);
    }

    // 4. Sort and render placements by layer (back -> mid -> front)
    const back = this.placements.filter((p) => p.layer === 'back');
    const mid = this.placements.filter((p) => !p.layer || p.layer === 'mid');
    const front = this.placements.filter((p) => p.layer === 'front');

    for (const p of back) this.drawPlacement(ctx, p, atmo);

    // Subtle midwater fog separation between back ruins/kelp & foreground centerpiece
    if (atmo.fogAlpha > 0.02) {
      ctx.fillStyle = atmo.fogColor;
      ctx.globalAlpha = atmo.fogAlpha * 0.45;
      ctx.fillRect(0, WATER_SURFACE_Y, VIRTUAL_WIDTH, VIRTUAL_HEIGHT - WATER_SURFACE_Y);
      ctx.globalAlpha = 1;
    }

    for (const p of mid) this.drawPlacement(ctx, p, atmo);
    for (const p of front) this.drawPlacement(ctx, p, atmo);

    // 5. Rising pixel bubbles
    this.drawBubbles(ctx);

    // 6. Floating spores / plankton motes
    this.drawSpores(ctx, atmo, settings.bioluminescenceBoost);

    // Twinkling plankton sparkles for extra underwater magic
    this.drawSparkles(ctx, atmo);

    // 7. Ambient night/abyss darkening tint BEFORE luminous pixel glow layer
    if (atmo.ambientDarkness > 0.02) {
      ctx.fillStyle = atmo.ambientTint;
      ctx.globalAlpha = atmo.ambientDarkness * 0.48;
      ctx.fillRect(0, WATER_SURFACE_Y, VIRTUAL_WIDTH, VIRTUAL_HEIGHT - WATER_SURFACE_Y);
      ctx.globalAlpha = 1;
    }

    // 8. 18-bit Pixel-Quantized Bioluminescent & Lantern Glow Layer
    this.drawGlowLayer(ctx, atmo, settings.bioluminescenceBoost);

    // 9. Animated water surface meniscus & splashes
    this.drawWaterSurface(ctx, atmo);

    // 10. Light ripple pulses from clicks
    this.drawLightPulses(ctx);

    // 11. Placement preview ghost if user is placing a decoration
    if (this.previewBrush) {
      this.drawPreviewGhost(ctx, atmo);
    }

    // 12. Subtle crisp glass edge highlights (left/right vertical tank rim glint)
    this.drawGlassHighlights(ctx, atmo);

    // 13. Cinematic depth vignette toward the tank edges
    this.drawDepthVignette(ctx, atmo);

    // Blit virtual 480x270 canvas to target canvas with nearest-neighbor crisp pixels
    const tctx = targetCanvas.getContext('2d');
    if (tctx) {
      tctx.imageSmoothingEnabled = false;
      tctx.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
      tctx.drawImage(
        this.buffer,
        0,
        0,
        VIRTUAL_WIDTH,
        VIRTUAL_HEIGHT,
        0,
        0,
        targetCanvas.width,
        targetCanvas.height
      );
    }
  }

  public exportPngDataUrl(): string {
    // Upscale 3x crisp pixel PNG for crisp downloadable wallpaper!
    const exportCanvas = document.createElement('canvas');
    exportCanvas.width = VIRTUAL_WIDTH * 3;
    exportCanvas.height = VIRTUAL_HEIGHT * 3;
    const ectx = exportCanvas.getContext('2d')!;
    ectx.imageSmoothingEnabled = false;
    ectx.drawImage(
      this.buffer,
      0,
      0,
      VIRTUAL_WIDTH,
      VIRTUAL_HEIGHT,
      0,
      0,
      exportCanvas.width,
      exportCanvas.height
    );
    return exportCanvas.toDataURL('image/png');
  }

  // ============================================================
  // STATIC BACKDROP BUILDER (Bayer Dithered Sky/Water + Silhouettes + Terraced Sand)
  // ============================================================
  private rebuildStaticBackground(atmo: WaterAtmospherePalette): void {
    const ctx = this.bgCtx;
    const img = ctx.createImageData(VIRTUAL_WIDTH, VIRTUAL_HEIGHT);
    const data = img.data;

    const topRgb = hexToRgb(atmo.topColor);
    const upperRgb = hexToRgb(atmo.upperMidColor);
    const lowerRgb = hexToRgb(atmo.lowerMidColor);
    const botRgb = hexToRgb(atmo.bottomColor);

    // Subtle dark header space above the water meniscus (tank air rim)
    const airTop = hexToRgb(lerpColor(atmo.bottomColor, '#030812', 0.72));
    const airBot = hexToRgb(lerpColor(atmo.topColor, '#041421', 0.65));

    const stops = [topRgb, upperRgb, lowerRgb, botRgb];

    for (let y = 0; y < VIRTUAL_HEIGHT; y++) {
      for (let x = 0; x < VIRTUAL_WIDTH; x++) {
        const idx = (y * VIRTUAL_WIDTH + x) * 4;
        if (y < WATER_SURFACE_Y) {
          const t = y / WATER_SURFACE_Y;
          const dither = (bayerThreshold(x, y) - 0.5) * 0.25;
          const pick = Math.max(0, Math.min(1, t + dither));
          const c = pick > 0.5 ? airBot : airTop;
          data[idx] = c[0];
          data[idx + 1] = c[1];
          data[idx + 2] = c[2];
          data[idx + 3] = 255;
        } else {
          // Smooth 4-stop depth gradient with a subtle 18-bit ordered-dither texture
          const depth = (y - WATER_SURFACE_Y) / (VIRTUAL_HEIGHT - WATER_SURFACE_Y);
          const scaled = depth * (stops.length - 1);
          const seg = Math.min(stops.length - 2, Math.floor(scaled));
          const frac = scaled - seg;
          const a = stops[seg];
          const b = stops[seg + 1];
          const jitter = (bayerThreshold(x, y) - 0.5) * 0.1;
          const t = frac < 0 ? 0 : frac > 1 ? 1 : frac + jitter;
          data[idx] = a[0] + (b[0] - a[0]) * t;
          data[idx + 1] = a[1] + (b[1] - a[1]) * t;
          data[idx + 2] = a[2] + (b[2] - a[2]) * t;
          data[idx + 3] = 255;
        }
      }
    }
    ctx.putImageData(img, 0, 0);

    // Distant sunken canyon & ruined aqueduct silhouettes (zero fish!)
    this.drawDistantSilhouettes(ctx, atmo);

    // Back sand terrace & foreground detailed quartz/river/obsidian sandbed
    this.drawSandbed(ctx);
  }

  private drawDistantSilhouettes(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    // Nature Aquarium backdrop: no temple ruins, just foliage + backlight
    if (this.substrate.backdropStyle === 'nature') {
      this.drawNatureBackdrop(ctx, atmo);
      return;
    }

    // Far reef/ridge skyline
    ctx.fillStyle = atmo.silhouetteFar;
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      const h =
        168 -
        Math.round(
          Math.sin(x * 0.018) * 18 +
            Math.cos(x * 0.045 + 1.2) * 10 +
            Math.sin(x * 0.09) * 4
        );
      ctx.fillRect(x, h, 1, VIRTUAL_HEIGHT - h);
    }

    // Distant sunken temple viaduct arches in silhouette
    ctx.fillStyle = atmo.silhouetteFar;
    const archStart = 128;
    const archSpan = 36;
    for (let i = 0; i < 6; i++) {
      const ax = archStart + i * archSpan;
      ctx.fillRect(ax, 108, 7, 72);
      ctx.fillRect(ax + 7, 108, archSpan - 7, 7);
      // Carve arch curve
      ctx.fillRect(ax + 7, 115, 4, 4);
      ctx.fillRect(ax + archSpan - 4, 115, 4, 4);
    }

    // Near atmospheric basalt spires & distant kelp silhouettes
    ctx.fillStyle = atmo.silhouetteNear;
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      const h =
        186 -
        Math.round(
          Math.cos(x * 0.024 + 0.5) * 14 + Math.sin(x * 0.07) * 6
        );
      ctx.fillRect(x, h, 1, VIRTUAL_HEIGHT - h);
    }

    // Distant hazy kelp strands
    const kelpSpots = [52, 62, 108, 290, 398, 412, 434];
    for (let i = 0; i < kelpSpots.length; i++) {
      const kx = kelpSpots[i];
      const kh = 54 + (i % 3) * 18;
      for (let dy = 0; dy < kh; dy++) {
        const sx = kx + Math.round(Math.sin(dy * 0.14 + i) * 2.5);
        const w = dy % 5 < 3 ? 2 : 1;
        ctx.fillRect(sx, 190 - dy, w, 1);
      }
    }
  }

  private drawNatureBackdrop(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    // Bright tropical backlight halo behind the tree canopy (pixel-stepped)
    const bx = 230;
    const by = 146;
    const rings = 10;
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (let r = rings; r >= 1; r--) {
      const rad = Math.round((130 * r) / rings);
      ctx.globalAlpha = 0.085 * (1 - r / rings) + 0.018;
      ctx.fillStyle = atmo.surfaceGlow;
      for (let dy = -rad; dy <= rad; dy += 2) {
        const span = Math.round(Math.sqrt(Math.max(0, rad * rad - dy * dy)));
        ctx.fillRect(bx - span, by + dy, span * 2, 2);
      }
    }
    ctx.restore();

    // Distant leafy foliage masses hugging the back wall (no temple ruins!)
    const bushes = [
      { cx: 20, r: 30 },
      { cx: 56, r: 22 },
      { cx: 90, r: 33 },
      { cx: 126, r: 21 },
      { cx: 158, r: 26 },
      { cx: 300, r: 24 },
      { cx: 342, r: 21 },
      { cx: 384, r: 31 },
      { cx: 422, r: 23 },
      { cx: 458, r: 29 },
    ];
    ctx.fillStyle = atmo.silhouetteFar;
    for (const b of bushes) {
      for (let dy = -b.r; dy <= Math.round(b.r * 0.5); dy++) {
        const half = Math.round(
          b.r * Math.sqrt(Math.max(0, 1 - (dy / b.r) ** 2))
        );
        ctx.fillRect(b.cx - half, 198 + dy, half * 2, 1);
      }
    }

    // Thin distant stem plants rising between the foliage masses
    ctx.fillStyle = atmo.silhouetteFar;
    const stems = [34, 70, 104, 140, 172, 318, 356, 400, 436, 470];
    for (let i = 0; i < stems.length; i++) {
      const sx = stems[i];
      const sh = 26 + (i % 4) * 12;
      for (let dy = 0; dy < sh; dy++) {
        const bend = Math.round(Math.sin(dy * 0.13 + i) * 2.2);
        ctx.fillRect(sx + bend, 200 - dy, 1, 1);
        if (dy % 6 === 2) {
          ctx.fillRect(sx + bend + 1, 200 - dy, 2, 1);
        }
      }
    }
  }

  private drawSandbed(ctx: CanvasRenderingContext2D): void {
    const pal = SAND_PALETTES[this.substrate.sandStyle];
    const rand = seededRand(4411);

    // 1. Back sand terrace
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      const topY = this.substrate.backHeights[x];
      ctx.fillStyle = pal.backRidge;
      ctx.fillRect(x, topY, 1, 3);
      ctx.fillStyle = pal.backDeep;
      ctx.fillRect(x, topY + 3, 1, VIRTUAL_HEIGHT - topY - 3);
      // Subtle aquasoil gravel texture on the raised back bank
      const gr = rand();
      if (gr > 0.968) {
        ctx.fillStyle = pal.speckA;
        ctx.globalAlpha = 0.5;
        ctx.fillRect(x, topY + 2, 1, 1);
        ctx.globalAlpha = 1;
      } else if (gr < 0.018) {
        ctx.fillStyle = '#000000';
        ctx.globalAlpha = 0.3;
        ctx.fillRect(x, topY + 5, 1, 1);
        ctx.globalAlpha = 1;
      }
    }

    // 2. Foreground layered dune sandbed — smooth depth shading, elegant curved
    //    ripples and only a sparse sprinkle of shell / quartz fragments.
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      const topY = this.substrate.heights[x];
      const slope =
        (this.substrate.heights[Math.min(VIRTUAL_WIDTH - 1, x + 2)] -
          this.substrate.heights[Math.max(0, x - 2)]) *
        0.5;

      // Pre-compute the ripple phase for this column so the bands stay smooth
      const ripplePhase = x * 0.075;

      for (let y = topY; y < VIRTUAL_HEIGHT; y++) {
        const dy = y - topY;

        let color: string;
        if (dy <= 1) {
          // Bright sunlit crest along the very top of the dune
          color = slope < 0.35 ? pal.highlight : pal.light;
        } else {
          // Smooth multi-stop depth shading across the sand face with only a
          // whisper of ordered dither, so the sand stays clean and sculpted
          // instead of turning into a visible checkerboard.
          const sandRamp = [pal.light, pal.mid, pal.shadow, pal.deep];
          const st = Math.max(0, Math.min(1, (dy - 2) / 30));
          const scaled = st * (sandRamp.length - 1);
          const seg = Math.min(sandRamp.length - 2, Math.floor(scaled));
          const frac = scaled - seg;
          const jitter = (bayerThreshold(x, y) - 0.5) * 0.07;
          const tt = frac < 0 ? 0 : frac > 1 ? 1 : frac + jitter;
          color = lerpColor(sandRamp[seg], sandRamp[seg + 1], tt);
        }

        // Elegant curved dune ripple bands (smooth sine crests, no noise)
        if (dy > 3 && dy < 26) {
          const rippleWave = Math.sin(ripplePhase + dy * 0.34);
          if (rippleWave > 0.86) {
            color = pal.light;
          } else if (rippleWave < -0.9 && dy > 6) {
            color = pal.shadow;
          }
        }

        // Sparse, deliberate shell & quartz fragments (kept very subtle so the
        // sand reads as clean sculpted sand rather than TV static)
        if (dy > 3 && dy < 22) {
          const r = rand();
          if (r > 0.9972) color = pal.speckA;
          else if (r > 0.9944) color = pal.speckB;
          else if (r < 0.0022) color = pal.speckC;
        }

        ctx.fillStyle = color;
        ctx.fillRect(x, y, 1, 1);
      }
    }
  }

  // ============================================================
  // VOLUMETRIC PIXEL GOD-RAYS & CAUSTICS
  // ============================================================
  private drawGodRays(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    const rays = [
      { x: 34, w: 22, speed: 0.52, phase: 0.2 },
      { x: 88, w: 30, speed: 0.42, phase: 1.4 },
      { x: 148, w: 38, speed: 0.34, phase: 2.3 },
      { x: 212, w: 46, speed: 0.29, phase: 3.6 },
      { x: 278, w: 34, speed: 0.4, phase: 4.9 },
      { x: 338, w: 40, speed: 0.33, phase: 5.8 },
      { x: 404, w: 28, speed: 0.47, phase: 0.9 },
      { x: 452, w: 22, speed: 0.55, phase: 2.1 },
    ];

    for (const ray of rays) {
      const shimmer =
        0.6 + 0.4 * Math.sin(this.time * ray.speed + ray.phase);
      const sway = Math.sin(this.time * 0.26 + ray.phase) * 10;
      const topX = Math.round(ray.x + sway);
      const alpha = atmo.godRayAlpha * shimmer;
      if (alpha <= 0.01) continue;

      ctx.fillStyle = atmo.godRayColor;
      // Quantized 2-pixel vertical strips fading smoothly downward
      const maxLen = 210;
      for (let dy = 0; dy < maxLen; dy += 2) {
        const progress = dy / maxLen;
        const bandAlpha = alpha * (1 - progress) * (1 - progress * 0.35);
        if (bandAlpha < 0.012) break;
        ctx.globalAlpha = bandAlpha;
        const rx = topX + Math.round(dy * 0.36);
        const rw = Math.max(4, Math.round(ray.w * (1 + progress * 0.6)));
        ctx.fillRect(rx, WATER_SURFACE_Y + dy, rw, 2);
        // Bright inner core for the strongest shafts
        if (progress < 0.35 && ray.w >= 34) {
          ctx.globalAlpha = bandAlpha * 0.85;
          ctx.fillRect(rx + Math.round(rw * 0.3), WATER_SURFACE_Y + dy, Math.max(2, Math.round(rw * 0.3)), 2);
        }
      }
    }
    ctx.restore();
  }

  // ============================================================
  // ANIMATED SPARKLES & DEPTH VIGNETTE (adds "wow" polish)
  // ============================================================
  private drawSparkles(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    // Twinkling plankton glints scattered through the lit water column
    const spots = 46;
    for (let i = 0; i < spots; i++) {
      // Stable pseudo-random anchor per index
      const ax = ((i * 73) % 97) / 97;
      const ay = ((i * 149) % 89) / 89;
      const px = Math.round(6 + ax * (VIRTUAL_WIDTH - 12));
      const py = Math.round(
        WATER_SURFACE_Y + 10 + ay * (VIRTUAL_HEIGHT - WATER_SURFACE_Y - 24)
      );
      const twinkle = Math.sin(this.time * (2.2 + (i % 5) * 0.45) + i * 1.7);
      if (twinkle < 0.55) continue;
      const a = (twinkle - 0.55) / 0.45;
      ctx.globalAlpha = Math.min(0.9, a * 0.8) * atmo.glowIntensity;
      ctx.fillStyle = i % 4 === 0 ? atmo.surfaceLineBright : atmo.surfaceGlow;
      ctx.fillRect(px, py, 1, 1);
      if (a > 0.75) {
        ctx.fillRect(px - 1, py, 3, 1);
        ctx.fillRect(px, py - 1, 1, 3);
      }
    }

    // Bright shimmer band dancing just under the water surface
    for (let x = 0; x < VIRTUAL_WIDTH; x += 2) {
      const s = Math.sin(x * 0.19 + this.time * 3.4);
      if (s < 0.88) continue;
      ctx.globalAlpha = 0.3 * atmo.glowIntensity;
      ctx.fillStyle = atmo.surfaceLineBright;
      ctx.fillRect(x, WATER_SURFACE_Y + 6 + Math.round(s * 2), 2, 1);
    }
    ctx.restore();
  }

  private drawDepthVignette(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    // Soft darkening toward the bottom corners for cinematic depth
    ctx.save();
    ctx.globalCompositeOperation = 'source-over';
    const strength = 0.3 + atmo.ambientDarkness * 0.4;
    ctx.fillStyle = '#01060e';
    // Bottom edge
    ctx.globalAlpha = strength * 0.5;
    ctx.fillRect(0, VIRTUAL_HEIGHT - 16, VIRTUAL_WIDTH, 16);
    // Left / right edges
    ctx.globalAlpha = strength * 0.3;
    ctx.fillRect(0, WATER_SURFACE_Y, 10, VIRTUAL_HEIGHT - WATER_SURFACE_Y);
    ctx.fillRect(
      VIRTUAL_WIDTH - 10,
      WATER_SURFACE_Y,
      10,
      VIRTUAL_HEIGHT - WATER_SURFACE_Y
    );
    ctx.restore();
  }

  private drawCaustics(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    ctx.fillStyle = atmo.causticColor;

    // Dancing caustic light-net across the sand crest and down the sand face
    for (let x = 1; x < VIRTUAL_WIDTH - 1; x++) {
      const sy = this.substrate.heights[x];
      const w1 = Math.sin(x * 0.13 + this.time * 2.1);
      const w2 = Math.cos(x * 0.21 - this.time * 1.6);
      const w3 = Math.sin(x * 0.07 + this.time * 1.15);
      const intensity = (w1 + w2 + w3) / 3;
      if (intensity > 0.4) {
        const a = atmo.causticAlpha * Math.min(1, (intensity - 0.38) * 2);
        ctx.globalAlpha = a;
        ctx.fillRect(x, sy, 1, 1);
        // Filaments of light trailing down the sand face
        if (intensity > 0.6) {
          ctx.globalAlpha = a * 0.7;
          ctx.fillRect(x, sy + 2, 1, 2);
          ctx.fillRect(x, sy + 5, 1, 1);
        }
      }
      // Secondary shimmer on the raised back terrace
      const by = this.substrate.backHeights[x];
      const bi =
        Math.sin(x * 0.17 + this.time * 2.6) *
        Math.cos(x * 0.11 - this.time * 1.9);
      if (bi > 0.48) {
        ctx.globalAlpha = atmo.causticAlpha * 0.42;
        ctx.fillRect(x, by, 1, 1);
      }
    }

    // Bright elliptical light pools where the god rays concentrate on the sand
    const pools = [
      { x: 118, r: 44 },
      { x: 252, r: 60 },
      { x: 382, r: 48 },
    ];
    for (const pool of pools) {
      const wobble = Math.sin(this.time * 1.25 + pool.x * 0.05) * 7;
      const cx = Math.round(pool.x + wobble);
      const sy = this.substrate.heights[Math.max(0, Math.min(VIRTUAL_WIDTH - 1, cx))];
      for (let dy = -3; dy <= 5; dy++) {
        for (let dx = -pool.r; dx <= pool.r; dx++) {
          const n = (dx * dx) / (pool.r * pool.r) + (dy * dy) / 15;
          if (n > 1) continue;
          const a = atmo.causticAlpha * (1 - n) * 0.55;
          if (a < 0.02) continue;
          ctx.globalAlpha = a;
          ctx.fillRect(cx + dx, sy + dy, 1, 1);
        }
      }
    }
    ctx.restore();
  }

  // ============================================================
  // DISPATCH PLACEMENTS (Sprites, Hardscapes, Swaying Flora)
  // ============================================================
  private drawPlacement(
    ctx: CanvasRenderingContext2D,
    p: DecorPlacement,
    atmo: WaterAtmospherePalette
  ): void {
    const x = Math.round(p.x);
    const y = Math.round(p.y);

    if (isSpriteKind(p.kind)) {
      this.drawSpritePlacement(ctx, p, x, y, atmo);
      return;
    }

    switch (p.kind) {
      case 'bonsaiDriftwood':
        this.drawCachedHardscape(ctx, `bonsai:${p.seed ?? 1}:${p.flipX ? 1 : 0}`, x, y, () =>
          this.buildBonsaiDriftwood(p.seed ?? 1, Boolean(p.flipX))
        );
        // Add tiny living moss fronds swaying softly on the bonsai canopy
        this.drawBonsaiSwayingMoss(ctx, x, y, p.seed ?? 1, Boolean(p.flipX));
        break;
      case 'driftwoodLog':
        this.drawCachedHardscape(ctx, `log:${p.seed ?? 1}:${p.flipX ? 1 : 0}`, x, y, () =>
          this.buildDriftwoodLog(p.seed ?? 1, Boolean(p.flipX))
        );
        break;
      case 'basaltSpire':
        this.drawCachedHardscape(ctx, `spire:${p.seed ?? 1}:${p.flipX ? 1 : 0}`, x, y, () =>
          this.buildBasaltSpire(p.seed ?? 1, Boolean(p.flipX))
        );
        break;
      case 'layeredRock':
        this.drawCachedHardscape(ctx, `rock:${p.seed ?? 1}:${p.flipX ? 1 : 0}`, x, y, () =>
          this.buildLayeredRock(p.seed ?? 1, Boolean(p.flipX))
        );
        break;
      case 'mossyBoulder':
        this.drawCachedHardscape(ctx, `boulder:${p.seed ?? 1}`, x, y, () =>
          this.buildMossyBoulder(p.seed ?? 1)
        );
        break;
      case 'giantKelp':
        this.drawGiantKelp(ctx, x, y, p.height ?? 140, p.seed ?? 1);
        break;
      case 'vallisneria':
        this.drawVallisneria(ctx, x, y, p.height ?? 95, p.seed ?? 1);
        break;
      case 'redLudwigia':
        this.drawRedLudwigia(ctx, x, y, p.height ?? 78, p.seed ?? 1);
        break;
      case 'seaFanMagenta':
        this.drawSeaFan(ctx, x, y, p.height ?? 48, p.seed ?? 1, FLORA_RAMPS.seaFanMagenta);
        break;
      case 'seaFanGold':
        this.drawSeaFan(ctx, x, y, p.height ?? 48, p.seed ?? 1, FLORA_RAMPS.seaFanGold);
        break;
      case 'anemoneCyan':
        this.drawAnemone(ctx, x, y, p.height ?? 22, p.seed ?? 1, FLORA_RAMPS.anemoneCyan);
        break;
      case 'anemoneMagenta':
        this.drawAnemone(ctx, x, y, p.height ?? 22, p.seed ?? 1, FLORA_RAMPS.anemoneMagenta);
        break;
      case 'anemoneCoral':
        this.drawAnemone(ctx, x, y, p.height ?? 22, p.seed ?? 1, FLORA_RAMPS.anemoneCoral);
        break;
      case 'javaFern':
        this.drawJavaFern(ctx, x, y, p.height ?? 28, p.seed ?? 1);
        break;
      case 'hairgrass':
        this.drawHairgrass(ctx, x, y, p.height ?? 14, p.seed ?? 1);
        break;
      case 'glowMushroom':
        this.drawGlowMushroom(ctx, x, y, p.height ?? 18, p.seed ?? 1);
        break;
      case 'bonsaiTreeAncient':
        this.drawBonsaiTreeAncient(ctx, x, y, p.seed ?? 7, Boolean(p.flipX));
        break;
      case 'seiryuStone':
        this.drawSeiryuStone(ctx, x, y, p.seed ?? 3, Boolean(p.flipX));
        break;
      case 'lavaRockCluster':
        this.drawLavaRockCluster(ctx, x, y, p.seed ?? 5, Boolean(p.flipX));
        break;
      case 'dwarfHairgrassCarpet':
        this.drawDwarfHairgrassCarpet(
          ctx,
          x,
          y,
          p.spread ?? 90,
          p.seed ?? 11
        );
        break;
      case 'monteCarloCarpet':
        this.drawMonteCarloCarpet(ctx, x, y, p.spread ?? 70, p.seed ?? 13);
        break;
      case 'anubiasNana':
        this.drawAnubiasNana(ctx, x, y, p.height ?? 20, p.seed ?? 17);
        break;
      case 'hygrophilaBush':
        this.drawFoliageBush(
          ctx,
          x,
          y,
          p.spread ?? 30,
          p.height ?? 46,
          FLORA_RAMPS.hygrophila,
          p.seed ?? 19
        );
        break;
      case 'rotalaBush':
        this.drawFoliageBush(
          ctx,
          x,
          y,
          p.spread ?? 26,
          p.height ?? 46,
          FLORA_RAMPS.rotala,
          p.seed ?? 23
        );
        break;
      case 'javaMossStone':
        this.drawJavaMossStone(ctx, x, y, p.seed ?? 29);
        break;
    }
  }

  private drawSpritePlacement(
    ctx: CanvasRenderingContext2D,
    p: DecorPlacement,
    x: number,
    y: number,
    _atmo: WaterAtmospherePalette
  ): void {
    const sprites = getSpriteSet();
    let sprite: CompiledSprite;

    switch (p.kind) {
      case 'treasureChest':
        sprite = this.interactive.chestOpen
          ? sprites.treasureChestOpen
          : sprites.treasureChestClosed;
        break;
      case 'pearlClam':
        sprite = this.interactive.clamOpen
          ? sprites.pearlClamOpen
          : sprites.pearlClamClosed;
        break;
      case 'stoneLantern':
        sprite = this.interactive.lanternLit
          ? sprites.stoneLanternLit
          : sprites.stoneLanternUnlit;
        break;
      case 'diverHelmet':
        sprite = sprites.diverHelmet;
        break;
      case 'sunkenAnchor':
        sprite = sprites.sunkenAnchor;
        break;
      case 'amphoraUrn':
        sprite = sprites.amphoraUrn;
        break;
      case 'crystalCyan':
        sprite = sprites.crystalCyan;
        break;
      case 'crystalAmethyst':
        sprite = sprites.crystalAmethyst;
        break;
      case 'volcanoVent':
        sprite = sprites.volcanoVent;
        break;
      case 'ancientPillar':
        sprite = sprites.ancientPillar;
        break;
      case 'ancientArch':
        sprite = sprites.ancientArch;
        break;
      case 'pagodaMini':
        sprite = sprites.pagodaMini;
        break;
      case 'brainCoral':
        sprite = sprites.brainCoral;
        break;
      case 'staghornCoral':
        sprite = sprites.staghornCoral;
        break;
      case 'pipeOrganCoral':
        sprite = sprites.pipeOrganCoral;
        break;
      case 'mushroomCoral':
        sprite = sprites.mushroomCoral;
        break;
      case 'conchShell':
        sprite = sprites.conchShell;
        break;
      case 'spiralShell':
        sprite = sprites.spiralShell;
        break;
      case 'marimoBall':
        sprite = sprites.marimoBall;
        break;
      case 'pebbleCluster':
        sprite = sprites.pebbleCluster;
        break;
      default:
        return;
    }

    const scale = p.scale ?? 1;
    const drawW = sprite.width * scale;
    const drawH = sprite.height * scale;
    const dx = Math.round(x - sprite.anchorX * scale);
    const dy = Math.round(y - sprite.anchorY * scale);

    // Subtle ground contact shadow beneath sprites
    ctx.fillStyle = 'rgba(4, 14, 24, 0.38)';
    ctx.fillRect(dx + 2, y - 1, Math.max(6, drawW - 4), 2);

    if (p.flipX) {
      ctx.save();
      ctx.translate(dx + drawW, dy);
      ctx.scale(-1, 1);
      ctx.drawImage(sprite.canvas, 0, 0, sprite.width, sprite.height, 0, 0, drawW, drawH);
      ctx.restore();
    } else {
      ctx.drawImage(sprite.canvas, 0, 0, sprite.width, sprite.height, dx, dy, drawW, drawH);
    }

    // Animated glints & spilled golden coins on open treasure chest
    if (p.kind === 'treasureChest') {
      // Scattered sunken gold coins & gems in the sand nearby
      ctx.fillStyle = '#eab308';
      ctx.fillRect(x - 14 * scale, y + 1, 2, 1);
      ctx.fillRect(x + 12 * scale, y + 1, 2, 1);
      ctx.fillStyle = '#fde047';
      ctx.fillRect(x - 10 * scale, y + 2, 2, 1);
      ctx.fillRect(x + 15 * scale, y, 1, 1);

      if (this.interactive.chestOpen && Math.sin(this.time * 5 + x) > 0.55) {
        ctx.fillStyle = '#ffffff';
        const gx = dx + Math.round((8 + ((Math.floor(this.time * 2) * 5) % 8)) * scale);
        const gy = dy + Math.round(7 * scale);
        ctx.fillRect(gx, gy, 1, 1);
        ctx.fillRect(gx - 1, gy, 3, 1);
        ctx.fillRect(gx, gy - 1, 1, 3);
      }
    }

    // Hanging swaying moss vines from the Ancient Temple Archway
    if (p.kind === 'ancientArch') {
      const vines = [-16, -7, 8, 17];
      for (let i = 0; i < vines.length; i++) {
        const vx = x + vines[i];
        const vTop = y - 16 * scale;
        const vLen = 7 + (i % 3) * 3;
        for (let dy = 0; dy < vLen; dy++) {
          const sway = Math.round(Math.sin(this.time * 2.1 + dy * 0.4 + i) * 0.9);
          ctx.fillStyle = dy < 3 ? '#65a30d' : '#3f6212';
          ctx.fillRect(vx + sway, vTop + dy, 1, 1);
        }
      }
    }

    if (p.kind === 'pearlClam' && this.interactive.clamOpen) {
      if (Math.cos(this.time * 3.8) > 0.45) {
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(x - 1, y - 5 * scale, 3, 1);
        ctx.fillRect(x, y - 6 * scale, 1, 3);
      }
    }
  }

  // ============================================================
  // PROCEDURAL HARDSCAPES (CACHED PIXEL ART)
  // ============================================================
  private drawCachedHardscape(
    ctx: CanvasRenderingContext2D,
    key: string,
    x: number,
    y: number,
    builder: () => { canvas: HTMLCanvasElement; ax: number; ay: number }
  ): void {
    let cached = this.hardscapeCache.get(key);
    if (!cached) {
      cached = builder();
      this.hardscapeCache.set(key, cached);
    }
    ctx.drawImage(cached.canvas, Math.round(x - cached.ax), Math.round(y - cached.ay));
  }

  private buildBonsaiDriftwood(seed: number, flipX: boolean) {
    const w = 84;
    const h = 74;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed);

    const drawBranch = (
      x0: number,
      y0: number,
      angle: number,
      len: number,
      thick: number,
      depth: number
    ) => {
      const steps = Math.max(4, Math.round(len));
      let cx = x0;
      let cy = y0;
      let a = angle;
      for (let i = 0; i < steps; i++) {
        const t = i / steps;
        a += Math.sin(t * 4 + seed + depth) * 0.07;
        cx += Math.cos(a) * 1.05;
        cy += Math.sin(a) * 1.05;
        const r = Math.max(1, Math.round(thick * (1 - t * 0.45)));
        const px = Math.round(cx);
        const py = Math.round(cy);

        // Selective dark outline
        ctx.fillStyle = '#29150d';
        ctx.fillRect(px - r - 1, py - 1, r * 2 + 2, 3);

        // Bark shading
        ctx.fillStyle = '#633822';
        ctx.fillRect(px - r, py, r * 2, 2);
        ctx.fillStyle = '#995c37';
        ctx.fillRect(px - r, py, Math.max(1, Math.floor(r * 1.1)), 1);
        if (i % 4 === 0) {
          ctx.fillStyle = '#ba794c';
          ctx.fillRect(px - r, py, 1, 1);
        }
      }

      if (depth > 0) {
        drawBranch(
          cx,
          cy,
          a - 0.55 - rand() * 0.25,
          len * 0.68,
          Math.max(1, thick * 0.65),
          depth - 1
        );
        drawBranch(
          cx,
          cy,
          a + 0.48 + rand() * 0.25,
          len * 0.7,
          Math.max(1, thick * 0.65),
          depth - 1
        );
      } else {
        // Lush emerald moss pad canopy!
        const mw = 11 + Math.floor(rand() * 7);
        const mh = 6 + Math.floor(rand() * 3);
        const mx = Math.round(cx);
        const my = Math.round(cy);
        for (let dy = -mh; dy <= mh * 0.45; dy++) {
          for (let dx = -mw; dx <= mw; dx++) {
            const norm = (dx * dx) / (mw * mw) + (dy * dy) / (mh * mh);
            if (norm > 1 + (rand() - 0.5) * 0.22) continue;
            const px = mx + dx;
            const py = my + dy;
            if (px < 1 || px >= w - 1 || py < 1 || py >= h - 1) continue;
            let col = '#2d6a22';
            if (dy < -mh * 0.45) col = '#a3e635';
            else if (dy < -mh * 0.1) col = '#65a30d';
            else if (dy > mh * 0.15) col = '#1b4319';
            if (norm > 0.85 && dy > 0) col = '#112a12';
            ctx.fillStyle = col;
            ctx.fillRect(px, py, 1, 1);
          }
        }
      }
    };

    const baseX = flipX ? w - 34 : 34;
    const baseY = h - 3;
    const lean = flipX ? -0.35 : 0.35;

    // Spreading roots
    drawBranch(baseX, baseY - 2, Math.PI - 0.28, 12, 2.2, 0);
    drawBranch(baseX, baseY - 2, 0.28, 14, 2.2, 0);
    // Main trunk + secondary crown branches
    drawBranch(baseX, baseY, -Math.PI / 2 + lean * 0.55, 24, 3.6, 2);
    drawBranch(baseX + (flipX ? 2 : -2), baseY - 8, -Math.PI / 2 - lean * 1.1, 16, 2.2, 1);

    if (flipX) {
      const flipped = document.createElement('canvas');
      flipped.width = w;
      flipped.height = h;
      const fctx = flipped.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: flipped, ax: Math.floor(w / 2), ay: h - 3 };
    }

    return { canvas: c, ax: baseX, ay: h - 3 };
  }

  private drawBonsaiSwayingMoss(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    seed: number,
    flipX: boolean
  ): void {
    const dir = flipX ? -1 : 1;
    const [fx] = this.sampleFlow(x, y - 34);
    const sway = Math.round(Math.sin(this.time * 2.2 + seed) * 1.2 + fx * 0.04);
    ctx.fillStyle = '#a3e635';
    ctx.fillRect(x + dir * 4 + sway, y - 44, 2, 1);
    ctx.fillRect(x - dir * 8 + sway, y - 36, 2, 1);
    ctx.fillStyle = '#65a30d';
    ctx.fillRect(x + dir * 10 + sway, y - 39, 1, 2);
  }

  private buildDriftwoodLog(seed: number, flipX: boolean) {
    const w = 68;
    const h = 26;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 77);

    // Arched sunken log tunnel
    for (let x = 4; x < w - 4; x++) {
      const t = (x - 4) / (w - 8);
      const archY = Math.round(h - 4 - Math.sin(t * Math.PI) * 11);
      const thick = 4 + Math.round(Math.sin(t * Math.PI * 0.8) * 2);

      ctx.fillStyle = '#24130c';
      ctx.fillRect(x, archY - thick - 1, 1, thick + 3);

      for (let dy = -thick; dy <= 0; dy++) {
        const py = archY + dy;
        let col = '#693d28';
        if (dy === -thick) col = '#a6653f';
        else if (dy === -thick + 1) col = '#874f32';
        else if (dy === 0) col = '#3d2015';
        if (dy === -thick && rand() > 0.55) col = '#65a30d';
        ctx.fillStyle = col;
        ctx.fillRect(x, py, 1, 1);
      }
    }

    if (flipX) {
      const f = document.createElement('canvas');
      f.width = w;
      f.height = h;
      const fctx = f.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: f, ax: Math.floor(w / 2), ay: h - 3 };
    }
    return { canvas: c, ax: Math.floor(w / 2), ay: h - 3 };
  }

  private buildBasaltSpire(seed: number, flipX: boolean) {
    const w = 44;
    const h = 92;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 303);

    // Three stepped volcanic rock columns
    const cols = [
      { cx: 12, cw: 12, ch: 56 },
      { cx: 22, cw: 14, ch: 86 },
      { cx: 33, cw: 10, ch: 46 },
    ];
    for (const col of cols) {
      for (let y = h - col.ch; y < h; y++) {
        const prog = (y - (h - col.ch)) / col.ch;
        const halfW = Math.round((col.cw * 0.45) * (0.65 + 0.45 * prog));
        for (let dx = -halfW; dx <= halfW; dx++) {
          const px = col.cx + dx;
          let color = '#2f3a4d';
          if (dx === -halfW || dx === halfW || y === h - col.ch) {
            color = '#121822';
          } else if (y < h - col.ch + 4 && rand() > 0.35) {
            color = '#558730';
          } else if (dx < -halfW + 3 || (y - (h - col.ch)) % 13 === 1) {
            color = '#63748c';
          } else if (dx > halfW - 3) {
            color = '#1e2636';
          } else if ((px + y) % 5 === 0) {
            color = '#435169';
          }
          ctx.fillStyle = color;
          ctx.fillRect(px, y, 1, 1);
        }
      }
    }

    if (flipX) {
      const f = document.createElement('canvas');
      f.width = w;
      f.height = h;
      const fctx = f.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: f, ax: Math.floor(w / 2), ay: h - 2 };
    }
    return { canvas: c, ax: Math.floor(w / 2), ay: h - 2 };
  }

  private buildLayeredRock(seed: number, flipX: boolean) {
    const w = 48;
    const h = 34;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 555);

    for (let y = 3; y < h - 1; y++) {
      const t = y / h;
      const half = Math.round(6 + t * 17 + Math.sin(y * 0.4 + seed) * 2);
      const center = Math.round(24 - (1 - t) * 4);
      for (let dx = -half; dx <= half; dx++) {
        const px = center + dx;
        if (px < 1 || px >= w - 1) continue;
        let col = '#4a5a70';
        const diagonalBand = (px + y * 2) % 9;
        if (dx === -half || dx === half || y === 3) col = '#141c26';
        else if (y < 9 && dx < 4 && rand() > 0.35) col = '#65a30d';
        else if (diagonalBand === 0 || dx < -half + 3) col = '#8aa0b8';
        else if (diagonalBand === 4 || dx > half - 4) col = '#2c3747';
        ctx.fillStyle = col;
        ctx.fillRect(px, y, 1, 1);
      }
    }

    if (flipX) {
      const f = document.createElement('canvas');
      f.width = w;
      f.height = h;
      const fctx = f.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: f, ax: Math.floor(w / 2), ay: h - 2 };
    }
    return { canvas: c, ax: Math.floor(w / 2), ay: h - 2 };
  }

  private buildMossyBoulder(seed: number) {
    const w = 26;
    const h = 16;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 888);

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const dx = (x - w / 2) / (w / 2 - 1);
        const dy = (y - (h - 3)) / (h - 4);
        const d = dx * dx + dy * dy;
        if (d > 1) continue;
        let col = '#48576b';
        if (d > 0.82) col = '#141b24';
        else if (dy < -0.42 && rand() > 0.2) col = dy < -0.65 ? '#84cc16' : '#4d7c2b';
        else if (dx < -0.25 && dy < -0.1) col = '#75879c';
        else if (dx > 0.35 || dy > -0.05) col = '#2a3545';
        ctx.fillStyle = col;
        ctx.fillRect(x, y, 1, 1);
      }
    }
    return { canvas: c, ax: Math.floor(w / 2), ay: h - 2 };
  }

  // ============================================================
  // PROCEDURAL SWAYING FLORA & CORALS (18-BIT SHADED PIXEL ART)
  // ============================================================
  private drawGiantKelp(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.kelp;
    const [fx] = this.sampleFlow(x, y - height * 0.5);
    const wind = fx * 0.14;

    let prevX = x;
    for (let dy = 0; dy < height; dy++) {
      const t = dy / height;
      const sway =
        Math.sin(this.time * 1.45 - t * 4.5 + seed * 1.7) * (3 + t * 7.5) +
        wind * t * t * 1.8;
      const sx = Math.round(x + sway);
      const sy = y - dy;
      if (sy <= WATER_SURFACE_Y + 2) break;

      // Central stalk
      ctx.fillStyle = ramp[3];
      ctx.fillRect(sx, sy, 2, 1);
      if (dy % 2 === 0) {
        ctx.fillStyle = ramp[2];
        ctx.fillRect(sx, sy, 1, 1);
      }

      // Alternating undulating kelp fronds + buoyant bladders
      if (dy > 10 && dy % 9 === 0) {
        const side = ((dy / 9) | 0) % 2 === 0 ? 1 : -1;
        // Buoyant golden-lime air bladder at leaf base
        ctx.fillStyle = ramp[0];
        ctx.fillRect(sx + side * 2, sy - 1, 2, 2);
        // Frond blade
        const leafLen = Math.round(9 + (1 - t) * 5);
        for (let lx = 2; lx <= leafLen; lx++) {
          const lt = lx / leafLen;
          const ly =
            sy -
            Math.round(
              Math.sin(lt * Math.PI * 0.85) * 4 +
                Math.sin(this.time * 2.3 + lx * 0.5 + seed) * 1.1
            );
          const thickness = lt < 0.65 ? 2 : 1;
          ctx.fillStyle = lt < 0.35 ? ramp[1] : lt < 0.75 ? ramp[2] : ramp[3];
          ctx.fillRect(sx + side * lx, ly, 1, thickness);
          if (lt < 0.55) {
            ctx.fillStyle = ramp[0];
            ctx.fillRect(sx + side * lx, ly - 1, 1, 1);
          }
        }
      }
      prevX = sx;
    }
    void prevX;
  }

  private drawVallisneria(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.vallisneria;
    const [fx] = this.sampleFlow(x, y - height * 0.5);
    const blades = 6;
    for (let b = 0; b < blades; b++) {
      const bx = x + (b - 2.5) * 3;
      const bh = Math.round(height * (0.65 + ((b * 37 + seed) % 10) * 0.04));
      for (let dy = 0; dy < bh; dy++) {
        const t = dy / bh;
        const twist =
          Math.sin(this.time * 1.9 - t * 5.2 + b * 0.9 + seed) * (2.5 + t * 5.5) +
          fx * 0.14 * t * t;
        const px = Math.round(bx + twist);
        const py = y - dy;
        if (py <= WATER_SURFACE_Y + 3) break;
        const ribbonW = Math.abs(Math.cos(t * 7 + b)) > 0.35 ? 2 : 1;
        ctx.fillStyle = t > 0.78 ? ramp[0] : t > 0.35 ? ramp[1] : ramp[2];
        ctx.fillRect(px, py, ribbonW, 1);
        if (ribbonW === 2) {
          ctx.fillStyle = ramp[3];
          ctx.fillRect(px + 1, py, 1, 1);
        }
      }
    }
  }

  private drawRedLudwigia(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.ludwigia;
    const [fx] = this.sampleFlow(x, y - height * 0.5);
    const stems = 3;
    for (let s = 0; s < stems; s++) {
      const sx0 = x + (s - 1) * 5;
      const sh = Math.round(height * (0.72 + s * 0.14));
      for (let dy = 0; dy < sh; dy++) {
        const t = dy / sh;
        const sway =
          Math.sin(this.time * 1.7 - t * 3.8 + s * 1.3 + seed) * (1.8 + t * 4.5) +
          fx * 0.12 * t * t;
        const px = Math.round(sx0 + sway);
        const py = y - dy;
        ctx.fillStyle = ramp[3];
        ctx.fillRect(px, py, 1, 1);

        if (dy > 6 && dy % 6 === 0) {
          // Pair of vibrant ruby-pink leaves with positive rect widths
          ctx.fillStyle = ramp[2];
          ctx.fillRect(px - 4, py - 1, 3, 2);
          ctx.fillRect(px + 1, py - 1, 3, 2);
          ctx.fillStyle = t > 0.6 ? ramp[0] : ramp[1];
          ctx.fillRect(px - 3, py - 2, 2, 1);
          ctx.fillRect(px + 2, py - 2, 2, 1);
        }
      }
    }
  }

  private drawSeaFan(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number,
    ramp: string[]
  ): void {
    const [fx] = this.sampleFlow(x, y - height * 0.5);
    const drawBranch = (
      bx: number,
      by: number,
      angle: number,
      len: number,
      depth: number,
      phase: number
    ) => {
      const steps = Math.max(3, Math.round(len));
      let cx = bx;
      let cy = by;
      const sway =
        Math.sin(this.time * 2.0 + phase + seed) * 0.11 + fx * 0.0025;
      const a = angle + sway;

      for (let i = 0; i < steps; i++) {
        cx += Math.cos(a);
        cy += Math.sin(a);
        const px = Math.round(cx);
        const py = Math.round(cy);
        ctx.fillStyle =
          depth === 3 ? ramp[3] : depth === 2 ? ramp[2] : depth === 1 ? ramp[1] : ramp[0];
        ctx.fillRect(px, py, depth >= 2 ? 2 : 1, 1);
      }
      if (depth > 0) {
        drawBranch(cx, cy, a - 0.48, len * 0.72, depth - 1, phase + 0.5);
        drawBranch(cx, cy, a + 0.45, len * 0.72, depth - 1, phase + 1.1);
      } else {
        // Luminous polyp dot at tip
        ctx.fillStyle = ramp[0];
        ctx.fillRect(Math.round(cx), Math.round(cy), 1, 1);
      }
    };

    drawBranch(x, y, -Math.PI / 2, height * 0.34, 3, 0);
  }

  private drawAnemone(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number,
    ramp: string[]
  ): void {
    // Stony coral base
    ctx.fillStyle = ramp[4];
    ctx.fillRect(x - 6, y - 4, 12, 4);
    ctx.fillStyle = ramp[3];
    ctx.fillRect(x - 5, y - 5, 10, 3);

    const [fx] = this.sampleFlow(x, y - 10);
    const tentacles = 9;
    for (let i = 0; i < tentacles; i++) {
      const spread = (i - (tentacles - 1) / 2) * 1.45;
      const len = height * (0.72 + ((i * 19 + seed) % 5) * 0.07);
      for (let s = 0; s < len; s++) {
        const t = s / len;
        const wave =
          Math.sin(this.time * 2.8 - t * 3.5 + i * 0.8 + seed) * (1.5 + t * 3) +
          fx * 0.1 * t * t;
        const px = Math.round(x + spread * (0.3 + t * 0.85) + wave);
        const py = Math.round(y - 4 - s);
        ctx.fillStyle = t > 0.78 ? ramp[1] : t > 0.3 ? ramp[2] : ramp[3];
        ctx.fillRect(px, py, 1, 1);
        if (s >= len - 1) {
          // Glowing bulb tip
          ctx.fillStyle = ramp[0];
          ctx.fillRect(px, py - 1, 2, 2);
        }
      }
    }
  }

  private drawJavaFern(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.javaFern;
    const [fx] = this.sampleFlow(x, y - 10);
    const fronds = 7;
    for (let f = 0; f < fronds; f++) {
      const angle = -Math.PI / 2 + (f - 3) * 0.28;
      const len = height * (0.65 + ((f * 13 + seed) % 5) * 0.08);
      for (let s = 0; s < len; s++) {
        const t = s / len;
        const sway =
          Math.sin(this.time * 1.8 + f + seed) * t * 2.5 + fx * 0.08 * t;
        const px = Math.round(x + Math.cos(angle) * s + sway);
        const py = Math.round(y + Math.sin(angle) * s);
        const leafWidth = Math.round(Math.sin(t * Math.PI) * 2.4) + 1;
        ctx.fillStyle = t > 0.65 ? ramp[0] : t > 0.3 ? ramp[1] : ramp[2];
        ctx.fillRect(px - Math.floor(leafWidth / 2), py, leafWidth, 1);
      }
    }
  }

  private drawHairgrass(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.hairgrass;
    const [fx] = this.sampleFlow(x, y - 4);
    for (let i = -9; i <= 9; i += 2) {
      const bh = Math.round(height * (0.65 + ((Math.abs(i) * 17 + seed) % 5) * 0.09));
      for (let dy = 0; dy < bh; dy++) {
        const t = dy / bh;
        const sway =
          Math.sin(this.time * 2.5 + i * 0.4 + seed) * t * 2 + fx * 0.08 * t;
        const px = Math.round(x + i + sway);
        const py = y - dy;
        ctx.fillStyle = t > 0.7 ? ramp[0] : t > 0.35 ? ramp[1] : ramp[2];
        ctx.fillRect(px, py, 1, 1);
      }
    }
  }

  private drawGlowMushroom(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.glowMushroom;
    const caps = [
      { ox: -4, h: Math.round(height * 0.72), w: 5 },
      { ox: 1, h: height, w: 7 },
      { ox: 6, h: Math.round(height * 0.58), w: 4 },
    ];
    for (let i = 0; i < caps.length; i++) {
      const cap = caps[i];
      const sway = Math.round(Math.sin(this.time * 2 + i + seed) * 0.8);
      const sx = x + cap.ox + sway;
      // Thin luminous stem
      ctx.fillStyle = ramp[3];
      ctx.fillRect(sx, y - cap.h + 2, 1, cap.h - 2);
      // Mushroom cap dome
      const half = Math.floor(cap.w / 2);
      ctx.fillStyle = ramp[2];
      ctx.fillRect(sx - half, y - cap.h + 1, cap.w, 2);
      ctx.fillStyle = ramp[1];
      ctx.fillRect(sx - half + 1, y - cap.h, cap.w - 2, 1);
      ctx.fillStyle = ramp[0];
      ctx.fillRect(sx, y - cap.h, 1, 1);
    }
  }

  // ============================================================
  // NATURE AQUARIUM: ANCIENT MOSSY BONSAI TREE CENTERPIECE
  // ============================================================
  private drawBonsaiTreeAncient(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    seed: number,
    flipX: boolean
  ): void {
    this.drawCachedHardscape(
      ctx,
      `ancientBonsai:${seed}:${flipX ? 1 : 0}`,
      x,
      y,
      () => this.buildAncientBonsaiTree(seed, flipX)
    );
    // Living moss fronds on the canopy tips swaying with the current
    const dir = flipX ? -1 : 1;
    const [fx] = this.sampleFlow(x, y - 80);
    const sway = Math.round(Math.sin(this.time * 1.9 + seed) * 1.2 + fx * 0.05);
    ctx.fillStyle = '#e2fca0';
    ctx.fillRect(x + dir * 36 + sway, y - 116, 2, 1);
    ctx.fillRect(x - dir * 40 + sway, y - 92, 2, 1);
    ctx.fillStyle = '#bef264';
    ctx.fillRect(x + dir * 54 + sway, y - 78, 1, 2);
    ctx.fillRect(x - dir * 58 + sway, y - 102, 1, 2);
  }

  private buildAncientBonsaiTree(
    seed: number,
    flipX: boolean
  ): { canvas: HTMLCanvasElement; ax: number; ay: number } {
    const w = 300;
    const h = 196;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 4211);

    // 18-bit bark + moss foliage ramps
    const barkDark = '#1d0f05';
    const barkMid = '#432915';
    const barkLight = '#6e4426';
    const barkHi = '#9c6a3a';
    const leafLight = '#eafcc0';
    const leafBright = '#c4f46e';
    const leafMid = '#8ccd2e';
    const leafDark = '#4f7c17';

    const baseX = 150;
    const baseY = h - 12;

    // Every major branch keeps its own path so foliage pads can be placed along it
    const branchPaths: Array<Array<{ x: number; y: number; thick: number }>> = [];

    const drawBranch = (
      x0: number,
      y0: number,
      angle: number,
      len: number,
      thick: number,
      depth: number
    ): void => {
      const steps = Math.max(3, Math.round(len));
      let cx = x0;
      let cy = y0;
      let a = angle;
      const path: Array<{ x: number; y: number; thick: number }> = [];

      for (let i = 0; i < steps; i++) {
        const t = i / steps;
        // Gnarled, organic wander
        a +=
          Math.sin(t * 2.6 + seed + depth * 2.1) * 0.085 +
          Math.sin(t * 6.3 + seed) * 0.03;
        cx += Math.cos(a) * 1.12;
        cy += Math.sin(a) * 1.12;
        const r = Math.max(1, Math.round(thick * (1 - t * 0.5)));
        const px = Math.round(cx);
        const py = Math.round(cy);
        // Branches never dip below the soil line
        if (py > baseY + 1) continue;

        path.push({ x: px, y: py, thick: r });

        // Dark bark outline
        ctx.fillStyle = barkDark;
        ctx.fillRect(px - r - 1, py - 1, r * 2 + 2, 3);
        // Bark body + lit upper edge
        ctx.fillStyle = barkMid;
        ctx.fillRect(px - r, py, r * 2, 2);
        ctx.fillStyle = barkLight;
        ctx.fillRect(px - r, py, Math.max(1, Math.round(r * 1.25)), 1);
        // Vertical bark grain
        if (i % 3 === 0) {
          ctx.fillStyle = barkDark;
          ctx.fillRect(px - r + (i % (r * 2 + 1)), py, 1, 2);
        }
        if (i % 4 === 0) {
          ctx.fillStyle = barkHi;
          ctx.fillRect(px - r, py, 1, 1);
        }
        // Lichen flecks clinging to the bark
        if (i % 7 === 3 && rand() > 0.6) {
          ctx.fillStyle = rand() > 0.5 ? leafMid : leafDark;
          ctx.fillRect(px + (rand() > 0.5 ? r + 1 : -r - 2), py, 2, 1);
        }
      }

      if (depth >= 3) branchPaths.push(path);

      if (depth > 0) {
        drawBranch(
          cx,
          cy,
          a - 0.56 - rand() * 0.3,
          len * 0.7,
          Math.max(1, thick * 0.63),
          depth - 1
        );
        drawBranch(
          cx,
          cy,
          a + 0.5 + rand() * 0.3,
          len * 0.72,
          Math.max(1, thick * 0.63),
          depth - 1
        );
      }
    };

    // Rounded, lit-from-above foliage cloud pad — clean tones, minimal speckle
    const drawLeafPad = (mx: number, my: number, mr: number): void => {
      for (let dy = -mr; dy <= Math.round(mr * 0.72); dy++) {
        for (let dx = -mr; dx <= mr; dx++) {
          const n = (dx * dx) / (mr * mr) + (dy * dy) / (mr * mr);
          if (n > 1 + (rand() - 0.5) * 0.3) continue;
          const px = Math.round(mx + dx);
          const py = Math.round(my + dy);
          if (px < 1 || px >= w - 1 || py < 1 || py >= h - 1) continue;
          const lit = -dy / mr; // 1 = top of pad, -1 = bottom
          let col: string;
          if (lit > 0.42) col = leafLight;
          else if (lit > 0.05) col = leafBright;
          else if (lit > -0.32) col = leafMid;
          else col = leafDark;
          const r = rand();
          if (r > 0.95) col = leafLight;
          else if (r < 0.05) col = leafDark;
          ctx.fillStyle = col;
          ctx.fillRect(px, py, 1, 1);
        }
      }
      // A few fine leaf filaments around the rim for an organic silhouette
      const fil = Math.round(mr * 0.8);
      for (let i = 0; i < fil; i++) {
        const ang = rand() * Math.PI * 2;
        const rad = mr * (0.88 + rand() * 0.26);
        const px = Math.round(mx + Math.cos(ang) * rad);
        const py = Math.round(my + Math.sin(ang) * rad * 0.8);
        if (px < 1 || px >= w - 1 || py < 1 || py >= h - 1) continue;
        ctx.fillStyle = rand() > 0.5 ? leafBright : leafMid;
        ctx.fillRect(px, py, 1, 1);
      }
    };

    // ---- Nebari: wide flared surface root base anchoring the tree ----
    for (let ry = 0; ry < 16; ry++) {
      const t = ry / 16;
      const rootHalf = Math.round(6 + t * 42);
      const rootY = baseY - ry;
      ctx.fillStyle = barkDark;
      ctx.fillRect(baseX - rootHalf - 1, rootY - 1, rootHalf * 2 + 2, 3);
      ctx.fillStyle = barkMid;
      ctx.fillRect(baseX - rootHalf, rootY, rootHalf * 2, 2);
      ctx.fillStyle = barkLight;
      ctx.fillRect(baseX - rootHalf, rootY, Math.round(rootHalf * 1.05), 1);
      if (ry % 3 === 0) {
        ctx.fillStyle = barkDark;
        ctx.fillRect(baseX - rootHalf + (ry % (rootHalf * 2)), rootY, 1, 2);
      }
      if (ry > 9 && rand() > 0.26) {
        ctx.fillStyle = rand() > 0.5 ? leafMid : leafDark;
        ctx.fillRect(
          baseX - rootHalf + Math.round(rand() * rootHalf * 2),
          rootY,
          2,
          1
        );
      }
    }

    // ---- Main gnarled trunk ----
    drawBranch(baseX, baseY - 10, -Math.PI / 2 + 0.1, 44, 10, 0);

    // ---- Five sweeping crown branches (classic Iwagumi silhouette) ----
    const crownX = baseX + 6;
    const crownY = baseY - 48;
    drawBranch(crownX - 2, crownY, Math.PI + 0.34, 46, 6, 4);
    drawBranch(crownX + 2, crownY, -0.36, 38, 6, 4);
    drawBranch(crownX, crownY, -Math.PI / 2 - 0.03, 32, 5.5, 3);
    drawBranch(crownX - 8, crownY + 18, Math.PI + 0.18, 28, 4.5, 3);
    drawBranch(crownX + 8, crownY + 18, -0.18, 32, 4.5, 3);

    // ---- Dense moss mantle following every branch ----
    // Heavily overlapping leaf pads blanket the woody framework so the tree reads
    // as a solid moss mass, then the limbs are re-stroked at full thickness on
    // top so the dark branch structure stays clearly visible through the moss.
    for (const path of branchPaths) {
      for (let i = 0; i < path.length; i += 1) {
        const pt = path[i];
        if (pt.y > baseY - 22) continue;
        const mr = 5 + Math.round(pt.thick * 0.85);
        drawLeafPad(
          pt.x + (rand() - 0.5) * 2,
          pt.y - 1 + (rand() - 0.5) * 1.5,
          mr
        );
      }
    }

    // Re-stroke the limbs on top at full thickness so they emerge from the moss
    for (const path of branchPaths) {
      for (const pt of path) {
        if (pt.y > baseY - 22) continue;
        const r = Math.max(1, pt.thick - 1);
        ctx.fillStyle = barkDark;
        ctx.fillRect(pt.x - r - 1, pt.y - 1, r * 2 + 2, 3);
        ctx.fillStyle = barkMid;
        ctx.fillRect(pt.x - r, pt.y, r * 2, 2);
        ctx.fillStyle = barkLight;
        ctx.fillRect(pt.x - r, pt.y, Math.max(1, Math.round(r * 1.25)), 1);
      }
    }

    if (flipX) {
      const f = document.createElement('canvas');
      f.width = w;
      f.height = h;
      const fctx = f.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: f, ax: w - baseX, ay: h - 12 };
    }
    return { canvas: c, ax: baseX, ay: h - 12 };
  }
  // NATURE AQUARIUM: ROUNDED MOSSY BOULDER CLUSTERS (IWAGUMI)
  // ============================================================
  private drawSeiryuStone(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    seed: number,
    flipX: boolean
  ): void {
    this.drawCachedHardscape(
      ctx,
      `seiryu:${seed}:${flipX ? 1 : 0}`,
      x,
      y,
      () => this.buildStoneCluster(seed, flipX, 'seiryu')
    );
  }

  private drawLavaRockCluster(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    seed: number,
    flipX: boolean
  ): void {
    this.drawCachedHardscape(
      ctx,
      `lava:${seed}:${flipX ? 1 : 0}`,
      x,
      y,
      () => this.buildStoneCluster(seed, flipX, 'lava')
    );
  }

  private buildStoneCluster(
    seed: number,
    flipX: boolean,
    style: 'seiryu' | 'lava'
  ): { canvas: HTMLCanvasElement; ax: number; ay: number } {
    const w = 104;
    const h = 78;
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + (style === 'seiryu' ? 8123 : 9123));

    const pal =
      style === 'seiryu'
        ? {
            edge: '#1e2836',
            mid: '#546577',
            light: '#8ba1b8',
            shadow: '#333f4e',
            hi: '#b3c4d6',
          }
        : {
            edge: '#141010',
            mid: '#3a2c24',
            light: '#5c463a',
            shadow: '#271d17',
            hi: '#7b5f4b',
          };

    // Rounded boulder mounds — heavy moss crust on the sunlit upper surfaces
    const stones = [
      { cx: 24, base: h - 7, rw: 20, rh: 16 },
      { cx: 48, base: h - 4, rw: 27, rh: 22 },
      { cx: 74, base: h - 12, rw: 18, rh: 18 },
      { cx: 90, base: h - 21, rw: 13, rh: 14 },
    ];

    for (const st of stones) {
      for (let yy = 0; yy < st.rh * 2; yy++) {
        const t = (yy - st.rh) / st.rh; // -1 top .. +1 bottom
        const half = Math.max(
          1,
          Math.round(
            st.rw *
              Math.sqrt(Math.max(0, 1 - t * t)) *
              (0.92 + rand() * 0.16)
          )
        );
        const y = st.base - st.rh + yy;
        for (let dx = -half; dx <= half; dx++) {
          const px = st.cx + dx;
          if (px < 1 || px >= w - 1) continue;
          let col = pal.mid;
          if (Math.abs(dx) >= half - 1) col = pal.edge;
          else if (t < -0.15 && dx < 0) col = pal.light;
          else if (t > 0.35 || dx > 0) col = pal.shadow;
          else if (rand() > 0.86) col = pal.hi;

          // Moss crust only on the sunlit crown — the rock body stays visible
          const mossChance =
            t < 0.05 ? 0.42 : t < 0.35 ? 0.2 : t < 0.7 ? 0.06 : 0.02;
          if (rand() < mossChance) {
            col = t < -0.2 ? '#a3e635' : t < 0.3 ? '#84cc16' : '#65a30d';
            if (rand() > 0.82) col = '#e2fca0';
            else if (rand() > 0.68) col = '#4d7c1a';
          }
          ctx.fillStyle = col;
          ctx.fillRect(px, y, 1, 1);
        }
      }
    }

    // Soft dark contact shadow where the stones meet the substrate
    ctx.fillStyle = 'rgba(16, 11, 5, 0.45)';
    ctx.fillRect(10, h - 6, w - 20, 6);

    if (flipX) {
      const f = document.createElement('canvas');
      f.width = w;
      f.height = h;
      const fctx = f.getContext('2d')!;
      fctx.translate(w, 0);
      fctx.scale(-1, 1);
      fctx.drawImage(c, 0, 0);
      return { canvas: f, ax: Math.floor(w / 2), ay: h - 4 };
    }
    return { canvas: c, ax: Math.floor(w / 2), ay: h - 4 };
  }

  // ============================================================
  // NATURE AQUARIUM: DENSE FOREGROUND CARPET PLANTS (CACHED)
  // ============================================================
  private drawDwarfHairgrassCarpet(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    spread: number,
    seed: number
  ): void {
    const key = `carpetHc:${Math.round(spread)}:${seed}`;
    let cached = this.hardscapeCache.get(key);
    if (!cached) {
      const canvas = this.buildCarpetTexture(
        Math.round(spread),
        seed,
        FLORA_RAMPS.dwarfHairgrass
      );
      cached = {
        canvas,
        ax: Math.round(canvas.width / 2),
        ay: canvas.height - 1,
      };
      this.hardscapeCache.set(key, cached);
    }
    const [fx] = this.sampleFlow(x, y - 5);
    const sway = Math.round(Math.sin(this.time * 1.5 + seed) * 1.5 + fx * 0.1);
    ctx.drawImage(
      cached.canvas,
      Math.round(x - cached.ax + sway),
      Math.round(y - cached.ay)
    );
  }

  private buildCarpetTexture(
    spread: number,
    seed: number,
    ramp: string[]
  ): HTMLCanvasElement {
    const c = document.createElement('canvas');
    c.width = spread + 10;
    c.height = 24;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 61);

    // Solid mossy under-layer so no substrate shows through the carpet
    for (let i = 0; i < c.width; i++) {
      const topVar = Math.round(Math.sin(i * 0.38 + seed) * 1.3 + rand() * 1.8);
      ctx.fillStyle = '#1c6b2e';
      ctx.fillRect(i, c.height - 4 + topVar, 1, 5);
      ctx.fillStyle = '#2c9c46';
      ctx.fillRect(i, c.height - 7 + topVar, 1, 4);
    }
    // Dense blade field
    const blades = Math.round(spread * 1.15);
    for (let i = 0; i < blades; i++) {
      const bx = 5 + rand() * spread;
      const bh = 6 + rand() * 10;
      for (let dy = 0; dy < bh; dy++) {
        const t = dy / bh;
        const s = Math.sin(bx * 0.24 + dy * 0.4 + seed) * t * 2.3;
        const px = Math.round(bx + s);
        const py = c.height - 3 - dy;
        if (px < 1 || px >= c.width - 1) continue;
        ctx.fillStyle = t > 0.68 ? ramp[1] : t > 0.32 ? ramp[2] : ramp[3];
        ctx.fillRect(px, py, 1, 1);
        if (t > 0.85) {
          ctx.fillStyle = ramp[0];
          ctx.fillRect(px, py - 1, 1, 1);
        }
      }
    }
    return c;
  }

  private drawMonteCarloCarpet(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    spread: number,
    seed: number
  ): void {
    const key = `carpetMc:${Math.round(spread)}:${seed}`;
    let cached = this.hardscapeCache.get(key);
    if (!cached) {
      const canvas = this.buildMonteCarloTexture(Math.round(spread), seed);
      cached = {
        canvas,
        ax: Math.round(canvas.width / 2),
        ay: canvas.height - 1,
      };
      this.hardscapeCache.set(key, cached);
    }
    const [fx] = this.sampleFlow(x, y - 5);
    const sway = Math.round(Math.sin(this.time * 1.7 + seed) * 1.3 + fx * 0.09);
    ctx.drawImage(
      cached.canvas,
      Math.round(x - cached.ax + sway),
      Math.round(y - cached.ay)
    );
  }

  private buildMonteCarloTexture(spread: number, seed: number): HTMLCanvasElement {
    const c = document.createElement('canvas');
    c.width = spread + 10;
    c.height = 18;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 97);

    for (let i = 0; i < c.width; i++) {
      const topVar = Math.round(Math.sin(i * 0.42 + seed) * 1.1 + rand() * 1.4);
      ctx.fillStyle = '#4d7c1a';
      ctx.fillRect(i, c.height - 3 + topVar, 1, 4);
      ctx.fillStyle = '#7cb518';
      ctx.fillRect(i, c.height - 6 + topVar, 1, 4);
    }
    const clumps = Math.round(spread * 0.6);
    for (let i = 0; i < clumps; i++) {
      const bx = 5 + rand() * spread;
      const bh = 3 + rand() * 5;
      const px = Math.round(bx);
      const py = c.height - 2 - bh;
      // Rounded little leaf cluster
      ctx.fillStyle = '#4d7c1a';
      ctx.fillRect(px - 1, py + 1, 4, 3);
      ctx.fillStyle = '#a3e635';
      ctx.fillRect(px - 1, py - 1, 3, 3);
      ctx.fillStyle = '#e2fca0';
      ctx.fillRect(px, py - 2, 1, 1);
      ctx.fillRect(px + 2, py, 1, 1);
    }
    return c;
  }

  // ============================================================
  // NATURE AQUARIUM: ANUBIAS NANA & DENSE FOLIAGE MASSES
  // ============================================================
  private drawAnubiasNana(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    height: number,
    seed: number
  ): void {
    const ramp = FLORA_RAMPS.anubias;
    const [fx] = this.sampleFlow(x, y - height * 0.4);
    const leaves = 11;
    for (let i = 0; i < leaves; i++) {
      const ang = -Math.PI / 2 + (i - (leaves - 1) / 2) * 0.3;
      const len = height * (0.6 + ((i * 17 + seed) % 5) * 0.11);
      for (let s = 0; s < len; s++) {
        const t = s / len;
        const sway =
          Math.sin(this.time * 1.7 + i * 0.9 + seed) * t * 1.6 + fx * 0.07 * t;
        const px = Math.round(x + Math.cos(ang) * s + sway);
        const py = Math.round(y + Math.sin(ang) * s);
        const lw = Math.round(Math.sin(t * Math.PI) * 3) + 2;
        ctx.fillStyle = t > 0.7 ? ramp[1] : t > 0.3 ? ramp[2] : ramp[3];
        ctx.fillRect(px - Math.floor(lw / 2), py, lw, 1);
        if (t > 0.5) {
          ctx.fillStyle = ramp[0];
          ctx.fillRect(px, py, 1, 1);
        }
      }
    }
  }

  private drawFoliageBush(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    w: number,
    h: number,
    ramp: string[],
    seed: number
  ): void {
    const key = `bush:${Math.round(w)}x${Math.round(h)}:${ramp[2]}:${seed}`;
    let cached = this.hardscapeCache.get(key);
    if (!cached) {
      const canvas = this.buildFoliageMass(
        Math.round(w),
        Math.round(h),
        ramp,
        seed
      );
      cached = {
        canvas,
        ax: Math.round(canvas.width / 2),
        ay: canvas.height - 4,
      };
      this.hardscapeCache.set(key, cached);
    }
    const [fx] = this.sampleFlow(x, y - h * 0.5);
    const sway = Math.round(Math.sin(this.time * 1.6 + seed) * 1.5 + fx * 0.09);
    ctx.drawImage(
      cached.canvas,
      Math.round(x - cached.ax + sway),
      Math.round(y - cached.ay)
    );
  }

  private buildFoliageMass(
    w: number,
    h: number,
    ramp: string[],
    seed: number
  ): HTMLCanvasElement {
    const c = document.createElement('canvas');
    c.width = w + 8;
    c.height = h + 8;
    const ctx = c.getContext('2d')!;
    const rand = seededRand(seed + 307);

    for (let dy = 0; dy < h; dy++) {
      for (let dx = 0; dx < w; dx++) {
        const nx = (dx - w / 2) / (w / 2);
        const ny = (dy - h) / h;
        const d = nx * nx + ny * ny * 1.25;
        if (d > 1 + (rand() - 0.5) * 0.4) continue;
        let col = ramp[2];
        if (ny < -0.55) col = ramp[1];
        else if (ny < -0.1) col = ramp[2];
        else if (ny < 0.4) col = ramp[3];
        else col = ramp[4];
        const r = rand();
        if (r > 0.94) col = ramp[0];
        else if (r < 0.06) col = ramp[4];
        ctx.fillStyle = col;
        ctx.fillRect(dx + 4, dy + 4, 1, 1);
      }
    }
    // Fine leaf filaments for an organic, lush silhouette
    for (let i = 0; i < Math.round(w * 0.5); i++) {
      const ang = rand() * Math.PI * 2;
      const rad = 0.72 + rand() * 0.32;
      const px =
        Math.round(w / 2 + Math.cos(ang) * (w / 2) * rad) + 4;
      const py =
        Math.round(h + Math.sin(ang) * h * rad * 0.85) + 4;
      if (px < 1 || px >= c.width - 1 || py < 1 || py >= c.height - 1) continue;
      ctx.fillStyle = rand() > 0.5 ? ramp[1] : ramp[2];
      ctx.fillRect(px, py, 1, 1);
    }
    return c;
  }

  private drawJavaMossStone(
    ctx: CanvasRenderingContext2D,
    x: number,
    y: number,
    seed: number
  ): void {
    // Small weathered pebble base
    ctx.fillStyle = '#4a5a70';
    ctx.fillRect(x - 6, y - 5, 12, 5);
    ctx.fillStyle = '#2a3545';
    ctx.fillRect(x - 5, y, 10, 1);
    ctx.fillStyle = '#8aa0b8';
    ctx.fillRect(x - 4, y - 5, 5, 1);

    // Dense java moss tufts swaying in the current
    const rand = seededRand(seed + 13);
    for (let i = 0; i < 30; i++) {
      const mx = x - 8 + rand() * 16;
      const mh = 2 + rand() * 5;
      const sway = Math.sin(this.time * 2.4 + mx * 0.4 + seed) * 1.1;
      const px = Math.round(mx + sway);
      ctx.fillStyle = rand() > 0.5 ? '#84cc16' : '#65a30d';
      ctx.fillRect(px, y - 5 - mh, 1, mh + 1);
      ctx.fillStyle = '#e2fca0';
      ctx.fillRect(px, y - 5 - mh, 1, 1);
    }
  }

  // ============================================================
  // BUBBLES, SPORES, GLOW HALOS & SURFACE WAVES
  // ============================================================
  private drawBubbles(ctx: CanvasRenderingContext2D): void {
    const tints = {
      cyan: { rim: '#67e8f9', body: '#cffafe', hi: '#ffffff' },
      silver: { rim: '#7dd3fc', body: '#e0f2fe', hi: '#ffffff' },
      gold: { rim: '#f59e0b', body: '#fef08a', hi: '#ffffff' },
      violet: { rim: '#c084fc', body: '#f3e8ff', hi: '#ffffff' },
    };
    // Soft additive glow pass so larger bubbles feel luminous
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (const b of this.bubbles) {
      if (b.size < 2) continue;
      const pal = tints[b.tint];
      const g = b.size === 3 ? 2 : 1;
      ctx.fillStyle = pal.rim;
      ctx.globalAlpha = 0.15;
      ctx.fillRect(
        Math.round(b.x) - g,
        Math.round(b.y) - g,
        g * 2 + 2,
        g * 2 + 2
      );
    }
    ctx.restore();

    for (const b of this.bubbles) {
      const px = Math.round(b.x);
      const py = Math.round(b.y);
      const pal = tints[b.tint];
      if (b.size === 1) {
        ctx.fillStyle = pal.hi;
        ctx.fillRect(px, py, 1, 1);
      } else if (b.size === 2) {
        ctx.fillStyle = pal.rim;
        ctx.fillRect(px, py, 2, 2);
        ctx.fillStyle = pal.hi;
        ctx.fillRect(px, py, 1, 1);
      } else {
        // 3x3 pixel ring bubble with hollow cyan center + crisp specular pixel
        ctx.fillStyle = pal.rim;
        ctx.fillRect(px - 1, py - 1, 3, 3);
        ctx.fillStyle = pal.body;
        ctx.fillRect(px, py, 1, 1);
        ctx.fillStyle = pal.hi;
        ctx.fillRect(px - 1, py - 1, 1, 1);
      }
    }
  }

  private drawSpores(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette,
    bioBoost: number
  ): void {
    const mult = atmo.glowIntensity * (0.45 + (bioBoost / 100) * 0.85);
    for (const s of this.spores) {
      const pulse = 0.5 + 0.5 * Math.sin(this.time * 2.8 + s.phase);
      const alpha = Math.min(1, mult * (0.35 + 0.65 * pulse));
      if (alpha < 0.08) continue;
      const px = Math.round(s.x);
      const py = Math.round(s.y);
      ctx.globalAlpha = alpha;
      ctx.fillStyle = s.color;
      ctx.fillRect(px, py, s.size, s.size);
    }
    ctx.globalAlpha = 1;
  }

  private drawGlowLayer(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette,
    bioBoost: number
  ): void {
    const intensity =
      atmo.glowIntensity *
      (0.55 + (bioBoost / 100) * 0.75) *
      (1 + this.interactive.crystalPulse * 0.5);
    if (intensity <= 0.12) return;

    ctx.save();
    ctx.globalCompositeOperation = 'screen';

    const drawPixelHalo = (
      cx: number,
      cy: number,
      radius: number,
      color: string,
      alpha: number
    ) => {
      const a = Math.min(0.62, alpha * intensity);
      if (a <= 0.02) return;
      ctx.fillStyle = color;
      // Stepped pixel rings for authentic 18-bit glow without vector blur
      const rings = 3;
      for (let r = rings; r >= 1; r--) {
        const rad = Math.round((radius * r) / rings);
        ctx.globalAlpha = a * (0.32 / r);
        for (let dy = -rad; dy <= rad; dy += 2) {
          const span = Math.round(Math.sqrt(Math.max(0, rad * rad - dy * dy)));
          ctx.fillRect(Math.round(cx - span), Math.round(cy + dy), span * 2, 2);
        }
      }
    };

    for (const p of this.placements) {
      const s = p.scale ?? 1;
      if (p.kind === 'crystalCyan') {
        drawPixelHalo(p.x, p.y - 8 * s, 20 * s, '#22d3ee', 0.52);
      } else if (p.kind === 'crystalAmethyst') {
        drawPixelHalo(p.x, p.y - 8 * s, 20 * s, '#c084fc', 0.52);
      } else if (p.kind === 'stoneLantern' && this.interactive.lanternLit) {
        const flicker = 0.88 + 0.12 * Math.sin(this.time * 7.5 + p.x);
        drawPixelHalo(p.x, p.y - 11 * s, 26 * s, '#fb923c', 0.62 * flicker);
      } else if (p.kind === 'pearlClam' && this.interactive.clamOpen) {
        drawPixelHalo(p.x, p.y - 5 * s, 16 * s, '#a5f3fc', 0.48);
      } else if (p.kind === 'treasureChest' && this.interactive.chestOpen) {
        drawPixelHalo(p.x, p.y - 8 * s, 18 * s, '#facc15', 0.42);
      } else if (p.kind === 'volcanoVent') {
        drawPixelHalo(
          p.x,
          p.y - 10 * s,
          16 * s,
          '#f97316',
          0.35 + this.interactive.volcanoBoost * 0.25
        );
      } else if (p.kind === 'ancientPillar' || p.kind === 'ancientArch') {
        drawPixelHalo(
          p.x,
          p.y - 12 * s,
          p.kind === 'ancientArch' ? 28 : 14,
          '#22d3ee',
          0.24 + this.interactive.runesBoost * 0.35
        );
      } else if (p.kind === 'anemoneCyan') {
        drawPixelHalo(p.x, p.y - 12, 16, '#22d3ee', 0.38);
      } else if (p.kind === 'anemoneMagenta') {
        drawPixelHalo(p.x, p.y - 12, 16, '#e879f9', 0.38);
      } else if (p.kind === 'anemoneCoral') {
        drawPixelHalo(p.x, p.y - 12, 14, '#fb7185', 0.32);
      } else if (p.kind === 'glowMushroom' || p.kind === 'mushroomCoral') {
        drawPixelHalo(p.x, p.y - 8, 16, '#67e8f9', 0.45);
      } else if (p.kind === 'anubiasNana') {
        drawPixelHalo(p.x, p.y - 7, 12, '#4ade80', 0.17);
      } else if (p.kind === 'javaMossStone') {
        drawPixelHalo(p.x, p.y - 5, 13, '#84cc16', 0.27);
      } else if (p.kind === 'monteCarloCarpet') {
        drawPixelHalo(p.x, p.y - 3, 15, '#a3e635', 0.21);
      } else if (p.kind === 'dwarfHairgrassCarpet') {
        drawPixelHalo(p.x, p.y - 4, 16, '#86efac', 0.17);
      } else if (p.kind === 'bonsaiTreeAncient') {
        drawPixelHalo(p.x, p.y - 62, 34, '#a3e635', 0.15);
      }
    }

    // Spore glow dots
    for (const sp of this.spores) {
      if (sp.size === 2) {
        ctx.fillStyle = sp.glowColor;
        ctx.globalAlpha = Math.min(0.45, 0.22 * intensity);
        ctx.fillRect(Math.round(sp.x) - 1, Math.round(sp.y) - 1, 3, 3);
      }
    }

    ctx.restore();
  }

  private drawWaterSurface(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    // Sub-surface luminous meniscus ribbon
    for (let x = 0; x < VIRTUAL_WIDTH; x++) {
      const wy = Math.round(WATER_SURFACE_Y + this.waveY[x]);
      ctx.fillStyle = atmo.surfaceGlow;
      ctx.globalAlpha = 0.24;
      ctx.fillRect(x, wy + 2, 1, 3);

      ctx.globalAlpha = 0.92;
      ctx.fillStyle = atmo.surfaceLineMid;
      ctx.fillRect(x, wy + 1, 1, 1);

      // Crisp specular crest highlight
      const crest =
        this.waveY[x] < -0.5 ||
        Math.sin(x * 0.22 + this.time * 4.2) > 0.72;
      ctx.fillStyle = crest ? atmo.surfaceLineBright : atmo.surfaceLineMid;
      ctx.fillRect(x, wy, 1, 1);
    }
    ctx.globalAlpha = 1;

    // Delicate floating surface frogbit / mini lily pads with fine dangling roots
    const floaters = [36, 48, 88, 174, 344, 408, 438, 452];
    for (let i = 0; i < floaters.length; i++) {
      const fx = Math.round(
        floaters[i] + Math.sin(this.time * 0.45 + i * 1.4) * 3.5
      );
      const ix = Math.max(2, Math.min(VIRTUAL_WIDTH - 4, fx));
      const fy = Math.round(WATER_SURFACE_Y + this.waveY[ix]);
      const padW = i % 2 === 0 ? 7 : 5;
      // Fine translucent hanging water roots
      const rootLen = 6 + (i % 3) * 3;
      for (let ry = 1; ry <= rootLen; ry++) {
        const sway = Math.round(Math.sin(this.time * 1.9 + ry * 0.45 + i) * 0.9);
        ctx.fillStyle = '#86efac';
        ctx.globalAlpha = Math.max(0.18, 0.58 - ry * 0.04);
        ctx.fillRect(ix + Math.floor(padW / 2) + sway, fy + ry, 1, 1);
      }
      // Crisp emerald floating pad silhouette
      ctx.globalAlpha = 0.92;
      ctx.fillStyle = '#365314';
      ctx.fillRect(ix, fy, padW, 1);
      ctx.fillStyle = '#84cc16';
      ctx.fillRect(ix + 1, fy - 1, Math.max(2, padW - 2), 1);
    }
    ctx.globalAlpha = 1;

    // Bubble pop surface splashes
    for (const sp of this.splashes) {
      const t = sp.age / sp.maxAge;
      const spread = Math.round(sp.radius * t + 1);
      ctx.fillStyle = atmo.surfaceLineBright;
      ctx.globalAlpha = 1 - t;
      ctx.fillRect(Math.round(sp.x - spread), Math.round(sp.y - 1), 1, 1);
      ctx.fillRect(Math.round(sp.x + spread), Math.round(sp.y - 1), 1, 1);
    }
    ctx.globalAlpha = 1;
  }

  private drawLightPulses(ctx: CanvasRenderingContext2D): void {
    ctx.save();
    ctx.globalCompositeOperation = 'screen';
    for (const p of this.pulses) {
      ctx.fillStyle = p.color;
      ctx.globalAlpha = Math.max(0, p.alpha * 0.65);
      const r = Math.round(p.radius);
      const steps = Math.max(16, r * 3);
      for (let i = 0; i < steps; i++) {
        const ang = (i / steps) * Math.PI * 2;
        const px = Math.round(p.x + Math.cos(ang) * r);
        const py = Math.round(p.y + Math.sin(ang) * r * 0.75);
        if (py > WATER_SURFACE_Y) {
          ctx.fillRect(px, py, 1, 1);
        }
      }
    }
    ctx.restore();
  }

  private drawPreviewGhost(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    if (!this.previewBrush) return;
    const { kind, x, y, height } = this.previewBrush;
    const clampedX = Math.max(16, Math.min(VIRTUAL_WIDTH - 16, Math.round(x)));
    const snappedY = Math.round(y);

    ctx.save();
    ctx.globalAlpha = 0.65;
    this.drawPlacement(
      ctx,
      {
        id: '__preview__',
        kind,
        x: clampedX,
        y: snappedY,
        height,
        seed: 77,
      },
      atmo
    );

    // Pixel crosshair marker at anchor point
    ctx.globalAlpha = 0.9;
    ctx.fillStyle = '#22d3ee';
    ctx.fillRect(clampedX - 4, snappedY, 9, 1);
    ctx.fillRect(clampedX, snappedY - 4, 1, 9);
    ctx.restore();
  }

  private drawGlassHighlights(
    ctx: CanvasRenderingContext2D,
    atmo: WaterAtmospherePalette
  ): void {
    // Crisp 1-pixel inner aquarium glass edge sheen
    ctx.fillStyle = atmo.surfaceLineBright;
    ctx.globalAlpha = 0.16;
    ctx.fillRect(1, WATER_SURFACE_Y, 1, VIRTUAL_HEIGHT - WATER_SURFACE_Y - 2);
    ctx.fillRect(
      VIRTUAL_WIDTH - 2,
      WATER_SURFACE_Y,
      1,
      VIRTUAL_HEIGHT - WATER_SURFACE_Y - 2
    );

    // Delicate diagonal corner glass shimmer pixels
    ctx.globalAlpha = 0.12;
    for (let i = 0; i < 18; i++) {
      ctx.fillRect(6 + i, WATER_SURFACE_Y + 24 - i, 1, 1);
      ctx.fillRect(VIRTUAL_WIDTH - 24 + i, VIRTUAL_HEIGHT - 12 - i, 1, 1);
    }
    ctx.globalAlpha = 1;
  }
}

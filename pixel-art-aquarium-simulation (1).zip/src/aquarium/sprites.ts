import type { SpriteKind } from './types';

export interface CompiledSprite {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  anchorX: number;
  anchorY: number;
}

function compileMatrix(
  rows: string[],
  palette: Record<string, string>,
  anchorX?: number,
  anchorY?: number
): CompiledSprite {
  const height = rows.length;
  const width = Math.max(...rows.map((r) => r.length));
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  ctx.imageSmoothingEnabled = false;

  for (let y = 0; y < height; y++) {
    const row = rows[y];
    for (let x = 0; x < row.length; x++) {
      const ch = row[x];
      if (ch === '.' || ch === ' ') continue;
      const color = palette[ch];
      if (!color) continue;
      ctx.fillStyle = color;
      ctx.fillRect(x, y, 1, 1);
    }
  }

  return {
    canvas,
    width,
    height,
    anchorX: anchorX ?? Math.floor(width / 2),
    anchorY: anchorY ?? height - 2,
  };
}

// ============================================================
// 1. TREASURE CHEST (Closed & Open with gold coins & gems)
// ============================================================
const CHEST_PALETTE: Record<string, string> = {
  o: '#22130e', // dark wood outline
  d: '#4d2817', // wood shadow
  m: '#753f23', // wood mid
  l: '#9c5b34', // wood light
  h: '#bd7a4a', // wood top highlight
  B: '#6e4910', // brass dark
  G: '#c98e1a', // brass mid
  Y: '#facc15', // gold bright
  W: '#fef9c3', // sparkle white-gold
  k: '#1a202c', // keyhole dark
  r: '#f43f5e', // ruby gem
  c: '#22d3ee', // diamond cyan
  e: '#4ade80', // emerald gem
  s: '#65a30d', // moss spot
};

const CHEST_CLOSED_ROWS = [
  '.....oooooooooooooo.....',
  '...ooBBBBYYYYYYBBBBoo...',
  '..oBYGhhhllllllhhhGYBo..',
  '.oBYmhGGGGGGGGGGGGhmYBo.',
  '.oBlmGmmmmmmmmmmmmGmlBo.',
  'oBYmGmdmmmmmmmmmmmdGmYBo',
  'oBmGssddddddddddddssGmBo',
  'oBBBBYYYYYYYYYYYYYYBBBBo',
  'oGGGGYYYYWWYYWWYYYYGGGGo',
  'oBmmGmmmGYYkkYYGmmmGmmBo',
  'oBmmGmmmGYYkkYYGmmmGmmBo',
  'oBddGdddGBBYYBBGdddGddBo',
  'oBmmGmmmGmmmmmmGmmmGmmBo',
  'oBddGdddGddddddGdddGddBo',
  'oBssGdddGddddddGdddGssBo',
  '.oooooooooooooooooooooo.',
];

const CHEST_OPEN_ROWS = [
  '.....oooooooooooooo.....',
  '...ooBBBBYYYYYYBBBBoo...',
  '..oBYGhhhllllllhhhGYBo..',
  '.oBYmhGGGGGGGGGGGGhmYBo.',
  '.oBddddddddddddddddddBo.',
  '.oBBBBBBBBBBBBBBBBBBBBo.',
  '.ooomWYYcYYrYYYeYYWmooo.',
  'oBGYWYrYYYYWWYYYYcYYWGBo',
  'oBYYYYcYYeYYYYrYYWYYYYBo',
  'oGGGGYYYYWWYYWWYYYYGGGGo',
  'oBmmGmmmGYYkkYYGmmmGmmBo',
  'oBmmGmmmGYYkkYYGmmmGmmBo',
  'oBddGdddGBBYYBBGdddGddBo',
  'oBmmGmmmGmmmmmmGmmmGmmBo',
  'oBddGdddGddddddGdddGddBo',
  'oBssGdddGddddddGdddGssBo',
  '.oooooooooooooooooooooo.',
];

// ============================================================
// 2. ANTIQUE BRASS DIVER HELMET
// ============================================================
const HELMET_PALETTE: Record<string, string> = {
  o: '#1f1610',
  d: '#593b1c',
  m: '#8f622c',
  l: '#c48d42',
  h: '#f2c96d',
  w: '#fff3c4',
  g: '#0c3547', // dark viewport glass
  c: '#18718c', // mid glass
  q: '#5ce1e6', // bright cyan reflection
  s: '#5c913b', // moss patina
  p: '#3b8266', // verdigris copper patina
};

const DIVER_HELMET_ROWS = [
  '.......oooooooo.......',
  '.....ooBBllllBBoo.....',
  '....oBllhhhhhhllBo....',
  '...oBlhhwwwwhhmllBo...',
  '..oBllhmmmmmmmmlmpBo..',
  '.oBmlmmGGGGGGGGmmmpBo.',
  '.oBmlmGqqccccggGmmpBo.',
  'oBhlmGqccccggggGmmllBo',
  'oBhlmGccggggcggGmmllBo',
  'oBmlmGgggggggggGmmmpBo',
  'oBmllGGggggggggGGmmpBo',
  '.oBmllGGGGGGGGGGmmpBo.',
  '.oBmssmmmmmmmmmmsspBo.',
  '..oBppppmmmmmmppppBo..',
  '..oBllhhllllllhhllBo..',
  '.ooBmmmmddddddmmmmBoo.',
  'oBBllllllllllllllllBBo',
  '.oooooooooooooooooooo.',
];

// Check palette keys used in DIVER_HELMET_ROWS (B and G)
HELMET_PALETTE['B'] = '#422c16';
HELMET_PALETTE['G'] = '#785124';

// ============================================================
// 3. MOSSY JAPANESE STONE LANTERN (TŌRŌ)
// ============================================================
const LANTERN_PALETTE: Record<string, string> = {
  o: '#1c2430',
  d: '#3d4959',
  m: '#627285',
  l: '#8fa1b5',
  h: '#c2d1e0',
  g: '#4d7c2b', // moss dark
  G: '#84cc16', // moss bright
  f: '#f97316', // lantern warm outer
  y: '#fde047', // lantern yellow flame
  w: '#fffbeb', // lantern core
  k: '#1e293b', // dark inner cavity
};

const LANTERN_LIT_ROWS = [
  '.......oooo.......',
  '......ohllho......',
  '.....ooGGGGoo.....',
  '...ooollllllooo...',
  '..ohllllllllllho..',
  '.ohmmmmGGGGmmmmho.',
  'oddddddddddddddddo',
  '..oooodllllldoooo.',
  '...odmkfyyfkmmdo..',
  '...odmkywwykmmdo..',
  '...odmkffffkmmdo..',
  '..oooodmmmmmdoooo.',
  '..ohllllGGllllho..',
  '...oddddddddddo...',
  '....oodmmmdmoo....',
  '.....odmmmdo......',
  '.....odmmmdo......',
  '....oodGGddoo.....',
  '...olllllllmdo....',
  '..odddddddddmdo...',
  '..ooooooooooooo...',
];

const LANTERN_UNLIT_ROWS = LANTERN_LIT_ROWS.map((row) =>
  row.replace(/[fyw]/g, 'k')
);

// ============================================================
// 4. GIANT PEARL CLAM SHELL ORNAMENT (Closed & Open)
// ============================================================
const CLAM_PALETTE: Record<string, string> = {
  o: '#291c33',
  d: '#63486b',
  m: '#9b789e',
  l: '#d1b0cf',
  h: '#f5dff0',
  i: '#2e163d', // dark interior
  r: '#b04879', // rose pink interior rim
  P: '#e0f2fe', // pearl rim
  p: '#f8fafc', // pearl mid
  W: '#ffffff', // pearl gleam
  q: '#67e8f9', // iridescent glint
};

const CLAM_CLOSED_ROWS = [
  '.....ooooooooooooo.....',
  '...oohhlmllmllmlmhhoo..',
  '..ohlmlmllmlmllmlmlmho.',
  '.olmmllmmllmmllmmllmmlo',
  '.omddmmddmmddmmddmmddmo',
  'odddddddddddddddddddddo',
  '.ooolllllllllllllllooo.',
  '..odddddddddddddddddo..',
  '...ooooooooooooooooo...',
];

const CLAM_OPEN_ROWS = [
  '....ooooooooooooooo....',
  '..oohhlmllmmmllmlmhhoo.',
  '.ohlmlmlhlllllhmlmlmlho',
  '.omllmlmllmmmllmllmlmmo',
  '.omdmmddmmdddmmddmmddmo',
  '.oiiiiiiiiiiiiiiiiiiiio',
  'ooriiiqPPPWWPPPqiiiirro',
  'oohriiiPPpppppPiiiirhoo',
  'ooolriiiPPPPPPiiiirlloo',
  '.omlriiiiiiiiiiiirlmlo.',
  '..omddddddmmddddddmmo..',
  '...ooooooooooooooooo...',
];

// ============================================================
// 5. SUNKEN SHIP ANCHOR
// ============================================================
const ANCHOR_PALETTE: Record<string, string> = {
  o: '#151c24',
  d: '#313d4a',
  m: '#4e5d6e',
  l: '#75879c',
  h: '#9fb1c4',
  r: '#7c3f2c', // rust mid
  R: '#a85a3a', // rust light
  g: '#4d7c2b', // moss/algae
  G: '#7bc447',
};

const ANCHOR_ROWS = [
  '.......oooooo.......',
  '......ohllmmho......',
  '.....olmo..omlo.....',
  '.....olmo..omlo.....',
  '......ommddmmo......',
  '.......omddmo.......',
  '..oooooomddmoooooo..',
  '.ohlllmmmmrrmmllldo.',
  '..ooooooommdoooooo..',
  '.......omddmo.......',
  '.......omRrmo.......',
  '.......omddmo.......',
  '.oo....omddmo....oo.',
  'olmo...omgdmo...omlo',
  'ollmo..omGdmo..omllo',
  '.odmmo.omddmo.ommdo.',
  '..odmmmomddmommdmo..',
  '...oodmmmmmmmmddo...',
  '....oodddddddddo....',
  '......oooooooo......',
];

// ============================================================
// 6. SUNKEN TERRACOTTA AMPHORA URN
// ============================================================
const AMPHORA_PALETTE: Record<string, string> = {
  o: '#291512',
  d: '#693225',
  m: '#9c4c34',
  l: '#c96f49',
  h: '#eba173',
  k: '#1e0e0c', // dark mouth interior
  g: '#4f8034', // algae crust
  G: '#82bf52',
  c: '#e879f9', // tiny coral encrustation
};

const AMPHORA_ROWS = [
  '.........ooooo.........',
  '.......ookkkkkoo.......',
  '......olhmmmmmdo.......',
  '.....oohmddddmmdo......',
  '......oooommddoommo....',
  '......ohllmmmmddmmdo...',
  '.....ohllmmmmmmdddmdo..',
  '....ohlmmmmmmmddddmdo..',
  '...oolmmmmGggmmdddmdo..',
  '..oohlmmmmmgmmddddmoo..',
  '..ohlllmmmmmmdddmmo....',
  '.oohllmmmmcmmmddmo.....',
  '.ohmllmmmmmmmddmo......',
  '.ommmdddddddddmo.......',
  '..oodddddddddoo........',
  '...ooooooooooo.........',
];

// ============================================================
// 7. LUMINOUS CRYSTAL CLUSTERS (Cyan & Amethyst)
// ============================================================
const CRYSTAL_CYAN_PALETTE: Record<string, string> = {
  o: '#0a2236',
  d: '#0e617d',
  m: '#0ea5c6',
  l: '#5ce8f5',
  h: '#ccfbff',
  W: '#ffffff',
  r: '#2e3847', // stone base
  R: '#4b5b70',
};

const CRYSTAL_AMETHYST_PALETTE: Record<string, string> = {
  o: '#1c0f33',
  d: '#54218a',
  m: '#8b42d4',
  l: '#c785ff',
  h: '#f3d9ff',
  W: '#ffffff',
  r: '#2e3847',
  R: '#4b5b70',
};

const CRYSTAL_ROWS = [
  '.........oo.........',
  '........oWho........',
  '........ohlo........',
  '.......ohllmo.......',
  '....oo.ohllmo.oo....',
  '...oWhoohllmooWho...',
  '...ohloohllmoohlo...',
  '..ohlmoohlmdoohlmo..',
  '..olmdoohlmdoolmdo..',
  '.oolmdoolmmdoolmdoo.',
  'oWhlmmdolmmdoolmmdho',
  'ohlmmddolmmdoolmmddo',
  'olmmddoolmddoolmmddo',
  'oRmmddoRmmddoRmmddRo',
  'oRRRrrRRRRrrRRRRrrRo',
  '.oooooooooooooooooo.',
];

// ============================================================
// 8. VOLCANIC BASALT BUBBLE VENT
// ============================================================
const VOLCANO_PALETTE: Record<string, string> = {
  o: '#0e1117',
  d: '#232834',
  m: '#394254',
  l: '#56647d',
  h: '#7888a3',
  f: '#ea580c', // warm magma crack
  y: '#fbbf24', // crater ember
  W: '#fef08a',
  g: '#4d7c2b',
};

const VOLCANO_ROWS = [
  '........oooooo........',
  '.......oyWWWWyo.......',
  '......offyyyyffo......',
  '.....olmmffffmmlo.....',
  '....ohlmmddddmmlho....',
  '...ohlmmmdddmmmmldo...',
  '..ohlmmmmfmmmdddmmho..',
  '..olmggmmyfmmddddmdo..',
  '.ohlmmmmmffmmmmddmdmo.',
  '.olmdddmmmmmmdddmmmmdo',
  'ohmmdddddmmdddddmmmmdd',
  'omdddddddddddddddddddd',
  'oooooooooooooooooooooo',
];

// ============================================================
// 9. ANCIENT TEMPLE PILLAR & SUNKEN ARCHWAY (with Glowing Runes)
// ============================================================
const RUIN_PALETTE: Record<string, string> = {
  o: '#17202e',
  d: '#364457',
  m: '#576980',
  l: '#8397ad',
  h: '#b7c8db',
  w: '#dce8f2',
  g: '#4a7c2c',
  G: '#83c948',
  r: '#22d3ee', // glowing rune cyan
  R: '#cffafe', // rune bright center
};

const ANCIENT_PILLAR_ROWS = [
  '..ooooooooooo..',
  '.owhhlllllhhdo.',
  '.olmmmmmmmmmmdo',
  '..oommmGGmmdoo.',
  '...ommlmmddo...',
  '...olmmRmmmo...',
  '...olmrmrmdo...',
  '...ommmRmmmo...',
  '...omlmmmmmo...',
  '...omlmmgmmo...',
  '...ommmGmmmo...',
  '...olmmRmmmo...',
  '...omlrmrmdo...',
  '...ommmRmmmo...',
  '...omddddddo...',
  '..oommmmmmdoo..',
  '.ohllllllllmdo.',
  '.oddddddddddmdo',
  '.ooooooooooooo.',
];

const ANCIENT_ARCH_ROWS = [
  '......oooooooooooooooooooooooooooooo......',
  '....oowhhhllllllllllllllllllllllhhhdoo....',
  '...owhhllllGGGGmmmmmmmmmmmmGGGllllhhmdo...',
  '..ollllmmmmmmmmmmRRrrrrRRmmmmmmmmmmmmdmo..',
  '..ommddddddddddmmrRwwwwRrmmdddddddddddmo..',
  '..ooommmmddddddmmmmmmmmmmddddddmmmmdooo...',
  '...ollllmdoo................ooolllmdo.....',
  '...ommddmo....................ommddmo.....',
  '...olmmRmo....................olmmRmo.....',
  '...olmrmmo....................olmrmmo.....',
  '...olmmRmo....................olmmRmo.....',
  '...ommggmo....................ommddmo.....',
  '...ommGddo....................ommggmo.....',
  '...olmmmmo....................olmmGmo.....',
  '...olmmRmo....................olmmRmo.....',
  '...olmrrmo....................olmrrmo.....',
  '...ommmRmo....................ommmRmo.....',
  '...omddddo....................omddddo.....',
  '..oommmmmdoo................oommmmmdoo....',
  '.ohllllllllmdo............ohllllllllmdo...',
  '.oddddddddddddo..........oddddddddddddo...',
  '.oooooooooooooo..........oooooooooooooo...',
];

// ============================================================
// 10. MINI SUNKEN PAGODA
// ============================================================
const PAGODA_ROWS = [
  '.........oo.........',
  '........ohho........',
  '........omdo........',
  '.....ooohllhooo.....',
  '..ooollllllllllooo..',
  '.ohmmmmGGmmmmmmmmho.',
  '..ooooddddddddoooo..',
  '.....ommllllmmo.....',
  '....ohllmmmmllho....',
  '..ooollllllllllooo..',
  '.ohmmmmmmmmGGmmmmho.',
  '..ooooddddddddoooo..',
  '.....omkkmmkkmo.....',
  '....ohmmmmmmmmho....',
  '..ooollllllllllooo..',
  '.ohmmGGGGmmmmmmmmho.',
  '..oooddddddddddooo..',
  '....olllllllllmdo...',
  '...odddddddddddmdo..',
  '...ooooooooooooooo..',
];
const PAGODA_PALETTE: Record<string, string> = {
  ...LANTERN_PALETTE,
  k: '#111827',
};

// ============================================================
// 11. CORALS (Brain, Staghorn, Pipe Organ, Mushroom)
// ============================================================
const BRAIN_CORAL_PALETTE: Record<string, string> = {
  o: '#291026',
  d: '#701d52',
  m: '#ab2e73',
  l: '#e35699',
  h: '#ffa6cd',
  c: '#fff0f7',
};

const BRAIN_CORAL_ROWS = [
  '.....oooooooooo.....',
  '...oohhhllllhhhoo...',
  '..ohhllmmddmmllhho..',
  '.ohlmmddhlhhddmmlho.',
  '.olmdhlmmddmmlhdmmo.',
  'olmdhlmddhhddmlhdmmo',
  'omdhlmdhmmmmhdmlhdmo',
  'omdmmddmmddmmddmmdmo',
  'odddhhddmmmmddhhdddo',
  '.odddmmmmddmmmmdddo.',
  '..oooddddddddddooo..',
  '....oooooooooooo....',
];

const STAGHORN_PALETTE: Record<string, string> = {
  o: '#2b0d09',
  d: '#7d2218',
  m: '#c94328',
  l: '#f57642',
  h: '#ffb878',
  w: '#ffe8bd',
};

const STAGHORN_ROWS = [
  '..oo......oo......oo..',
  '.owho....owho....owho.',
  '.ohlo....ohlo....ohlo.',
  '..olmo..ooohlo..olmo..',
  '..olmmo.olllmo.olmmo..',
  '...olmmoolmdmoolmmo...',
  'oo..olmmmlmmdolmmo..oo',
  'who..olmmdmmdlmmo..owh',
  'hlo..oolmdmmmldoo..olh',
  '.olmo.olmmddmdmo..olmo',
  '..olmoommmddmddo.olmo.',
  '...olmmmmmdddmmmolmo..',
  '....olmmmmddddmmmmo...',
  '.....oommmddddmmoo....',
  '......oodddddddoo.....',
  '.......ooooooooo......',
];

const PIPE_CORAL_PALETTE: Record<string, string> = {
  o: '#122926',
  d: '#0e695c',
  m: '#15a38d',
  l: '#4ee0c5',
  h: '#b5fff0',
  k: '#093832',
};

const PIPE_CORAL_ROWS = [
  '....ooo....ooo....',
  '...ohkho..ohkho...',
  '...olmmo..olmmo...',
  '.ooolmdooolmmdooo.',
  'ohkholmdoohkholmdo',
  'olmmolmdoolmmolmdo',
  'olmdolmdoolmdolmdo',
  'olmdodddoolmdodddo',
  'omddomddoomddomddo',
  '.ooddddddddddddoo.',
  '..oooooooooooooo..',
];

const MUSHROOM_CORAL_PALETTE: Record<string, string> = {
  o: '#1f0b33',
  d: '#631d8a',
  m: '#9b30c9',
  l: '#d66eff',
  h: '#f7bdff',
  w: '#ffffff',
  s: '#3a4f5e',
  S: '#1d2833',
};

const MUSHROOM_CORAL_ROWS = [
  '....oooooooo....',
  '..oohllllllhhoo.',
  '.ohlmmwllwmmlho.',
  'ohlmlmmmmmmlmlho',
  'omddddmmmmddddmo',
  '.oooossSSssoooo.',
  '.....osSSso.....',
  '....ooSSSooo....',
  '..oohllllllhhoo.',
  '.ohlmlmwwmlmlho.',
  '.omddddmmddddmo.',
  '..oooossSssooo..',
  '.....osSSso.....',
  '.....oooooo.....',
];

// ============================================================
// 12. DECORATIVE SEASHELLS, MARIMO MOSS BALL & PEBBLE CLUSTER
// ============================================================
const SHELL_PALETTE: Record<string, string> = {
  o: '#2e1b18',
  d: '#8a5245',
  m: '#c4836e',
  l: '#eab59d',
  h: '#ffe3d1',
  p: '#f4a2b8',
};

const CONCH_ROWS = [
  '.......ooo......',
  '.....oohlho.....',
  '....ohllmmho....',
  '...olmmppmlho...',
  '..olmpphppmmho..',
  '.ohlmpphpmmdddo.',
  'oohlmmppmmdddo..',
  '.oodddddddddo...',
  '...ooooooooo....',
];

const SPIRAL_SHELL_ROWS = [
  '....oooooo....',
  '..oohllllhoo..',
  '.ohllmmddllho.',
  'ohlmdhhllmdmho',
  'olmdhlmmdmdmmo',
  'odmmddmmmddmdo',
  '.ooddddddddoo.',
  '..oooooooooo..',
];

const MARIMO_PALETTE: Record<string, string> = {
  o: '#0d2612',
  d: '#1d5422',
  m: '#348731',
  l: '#5ec248',
  h: '#a6ed79',
};

const MARIMO_ROWS = [
  '...oooooo...',
  '..ohllllho..',
  '.ohllmmllho.',
  'ohllmmmmllho',
  'ollmmmmddmlo',
  'olmmmdddddlo',
  '.oddddddddo.',
  '..oooooooo..',
];

const PEBBLE_PALETTE: Record<string, string> = {
  o: '#171d26',
  d: '#374252',
  m: '#5a6a80',
  l: '#8496ad',
  h: '#b4c3d6',
  r: '#7d5b49',
  R: '#b58b72',
  g: '#5c913b',
};

const PEBBLE_ROWS = [
  '.....oooo.......oooo...',
  '...oohllho....oohRrho..',
  '..ohlmmmldo..ohRRrrmdo.',
  '.ooolmddddoooolmrddrmo.',
  'ohllhhdddmmhhllmmddddo.',
  'omdddddddgmmddddddmdo..',
  '.ooooooooooooooooooo...',
];

export interface SpriteSet {
  treasureChestClosed: CompiledSprite;
  treasureChestOpen: CompiledSprite;
  diverHelmet: CompiledSprite;
  stoneLanternLit: CompiledSprite;
  stoneLanternUnlit: CompiledSprite;
  pearlClamClosed: CompiledSprite;
  pearlClamOpen: CompiledSprite;
  sunkenAnchor: CompiledSprite;
  amphoraUrn: CompiledSprite;
  crystalCyan: CompiledSprite;
  crystalAmethyst: CompiledSprite;
  volcanoVent: CompiledSprite;
  ancientPillar: CompiledSprite;
  ancientArch: CompiledSprite;
  pagodaMini: CompiledSprite;
  brainCoral: CompiledSprite;
  staghornCoral: CompiledSprite;
  pipeOrganCoral: CompiledSprite;
  mushroomCoral: CompiledSprite;
  conchShell: CompiledSprite;
  spiralShell: CompiledSprite;
  marimoBall: CompiledSprite;
  pebbleCluster: CompiledSprite;
}

let cachedSprites: SpriteSet | null = null;

export function getSpriteSet(): SpriteSet {
  if (cachedSprites) return cachedSprites;
  cachedSprites = {
    treasureChestClosed: compileMatrix(CHEST_CLOSED_ROWS, CHEST_PALETTE, 12, 15),
    treasureChestOpen: compileMatrix(CHEST_OPEN_ROWS, CHEST_PALETTE, 12, 16),
    diverHelmet: compileMatrix(DIVER_HELMET_ROWS, HELMET_PALETTE, 11, 17),
    stoneLanternLit: compileMatrix(LANTERN_LIT_ROWS, LANTERN_PALETTE, 9, 20),
    stoneLanternUnlit: compileMatrix(LANTERN_UNLIT_ROWS, LANTERN_PALETTE, 9, 20),
    pearlClamClosed: compileMatrix(CLAM_CLOSED_ROWS, CLAM_PALETTE, 11, 8),
    pearlClamOpen: compileMatrix(CLAM_OPEN_ROWS, CLAM_PALETTE, 11, 11),
    sunkenAnchor: compileMatrix(ANCHOR_ROWS, ANCHOR_PALETTE, 10, 19),
    amphoraUrn: compileMatrix(AMPHORA_ROWS, AMPHORA_PALETTE, 11, 15),
    crystalCyan: compileMatrix(CRYSTAL_ROWS, CRYSTAL_CYAN_PALETTE, 10, 15),
    crystalAmethyst: compileMatrix(
      CRYSTAL_ROWS,
      CRYSTAL_AMETHYST_PALETTE,
      10,
      15
    ),
    volcanoVent: compileMatrix(VOLCANO_ROWS, VOLCANO_PALETTE, 11, 12),
    ancientPillar: compileMatrix(ANCIENT_PILLAR_ROWS, RUIN_PALETTE, 7, 18),
    ancientArch: compileMatrix(ANCIENT_ARCH_ROWS, RUIN_PALETTE, 21, 21),
    pagodaMini: compileMatrix(PAGODA_ROWS, PAGODA_PALETTE, 10, 19),
    brainCoral: compileMatrix(BRAIN_CORAL_ROWS, BRAIN_CORAL_PALETTE, 10, 11),
    staghornCoral: compileMatrix(STAGHORN_ROWS, STAGHORN_PALETTE, 11, 15),
    pipeOrganCoral: compileMatrix(PIPE_CORAL_ROWS, PIPE_CORAL_PALETTE, 9, 10),
    mushroomCoral: compileMatrix(
      MUSHROOM_CORAL_ROWS,
      MUSHROOM_CORAL_PALETTE,
      8,
      13
    ),
    conchShell: compileMatrix(CONCH_ROWS, SHELL_PALETTE, 8, 8),
    spiralShell: compileMatrix(SPIRAL_SHELL_ROWS, SHELL_PALETTE, 7, 7),
    marimoBall: compileMatrix(MARIMO_ROWS, MARIMO_PALETTE, 6, 7),
    pebbleCluster: compileMatrix(PEBBLE_ROWS, PEBBLE_PALETTE, 11, 6),
  };
  return cachedSprites;
}

export function isSpriteKind(kind: string): kind is SpriteKind {
  return [
    'treasureChest',
    'diverHelmet',
    'stoneLantern',
    'pearlClam',
    'sunkenAnchor',
    'amphoraUrn',
    'crystalCyan',
    'crystalAmethyst',
    'volcanoVent',
    'ancientPillar',
    'ancientArch',
    'pagodaMini',
    'brainCoral',
    'staghornCoral',
    'pipeOrganCoral',
    'mushroomCoral',
    'conchShell',
    'spiralShell',
    'marimoBall',
    'pebbleCluster',
  ].includes(kind);
}

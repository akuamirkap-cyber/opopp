import {
  VIRTUAL_WIDTH,
  type AquascapePreset,
  type PlaceableBrush,
  type PresetId,
  type SubstrateProfile,
} from './types';

function interpolateHeights(
  points: Array<{ x: number; y: number }>,
  width: number
): number[] {
  const sorted = [...points].sort((a, b) => a.x - b.x);
  const heights = new Array<number>(width);
  for (let x = 0; x < width; x++) {
    let left = sorted[0];
    let right = sorted[sorted.length - 1];
    for (let i = 0; i < sorted.length - 1; i++) {
      if (x >= sorted[i].x && x <= sorted[i + 1].x) {
        left = sorted[i];
        right = sorted[i + 1];
        break;
      }
    }
    if (right.x === left.x) {
      heights[x] = Math.round(left.y);
    } else {
      const t = (x - left.x) / (right.x - left.x);
      // Cosine smooth interpolation for natural underwater sand dunes
      const smooth = (1 - Math.cos(t * Math.PI)) * 0.5;
      heights[x] = Math.round(left.y + (right.y - left.y) * smooth);
    }
  }
  return heights;
}

export function buildSubstrateProfile(preset: AquascapePreset): SubstrateProfile {
  return {
    heights: interpolateHeights(preset.moundControlPoints, VIRTUAL_WIDTH),
    backHeights: interpolateHeights(
      preset.backMoundControlPoints,
      VIRTUAL_WIDTH
    ),
    sandStyle: preset.sandStyle,
    backdropStyle: preset.backdropStyle,
  };
}

export const AQUASCAPE_PRESETS: Record<PresetId, AquascapePreset> = {
  atlantis: {
    id: 'atlantis',
    name: 'Kuil Terumbu Atlantis',
    subtitle: 'Reruntuhan Kuno & Taman Koral Lengkap',
    description:
      'Komposisi lengkap kuil tenggelam berukir rune, akar bonsai berlumut, peti harta karun, helm penyelam antik, kawah gelembung, kerang mutiara, kristal bercahaya, serta puluhan flora & terumbu karang.',
    defaultLighting: 'day',
    sandStyle: 'coralGold',
    backdropStyle: 'temple',
    moundControlPoints: [
      { x: 0, y: 222 },
      { x: 45, y: 214 },
      { x: 105, y: 224 },
      { x: 165, y: 234 },
      { x: 235, y: 238 },
      { x: 300, y: 228 },
      { x: 375, y: 215 },
      { x: 435, y: 221 },
      { x: 480, y: 216 },
    ],
    backMoundControlPoints: [
      { x: 0, y: 196 },
      { x: 75, y: 192 },
      { x: 155, y: 204 },
      { x: 240, y: 210 },
      { x: 335, y: 195 },
      { x: 420, y: 188 },
      { x: 480, y: 194 },
    ],
    placements: [
      // === BACKGROUND LAYER (Tall Kelp, Ruins, Rock Spires) ===
      { id: 'at-spire-1', kind: 'basaltSpire', x: 38, y: 216, scale: 1, seed: 11, layer: 'back' },
      { id: 'at-spire-2', kind: 'basaltSpire', x: 436, y: 219, scale: 1, flipX: true, seed: 22, layer: 'back' },
      { id: 'at-kelp-1', kind: 'giantKelp', x: 20, y: 222, height: 165, seed: 1, layer: 'back' },
      { id: 'at-kelp-2', kind: 'giantKelp', x: 34, y: 218, height: 145, seed: 2, layer: 'back' },
      { id: 'at-kelp-3', kind: 'giantKelp', x: 446, y: 220, height: 170, seed: 3, layer: 'back' },
      { id: 'at-kelp-4', kind: 'giantKelp', x: 462, y: 218, height: 140, seed: 4, layer: 'back' },
      { id: 'at-val-1', kind: 'vallisneria', x: 96, y: 223, height: 105, seed: 5, layer: 'back' },
      { id: 'at-val-2', kind: 'vallisneria', x: 114, y: 226, height: 92, seed: 6, layer: 'back' },
      { id: 'at-val-3', kind: 'vallisneria', x: 356, y: 218, height: 110, seed: 7, layer: 'back' },
      { id: 'at-lud-1', kind: 'redLudwigia', x: 142, y: 228, height: 78, seed: 8, layer: 'back' },
      { id: 'at-lud-2', kind: 'redLudwigia', x: 330, y: 222, height: 84, seed: 9, layer: 'back' },

      // === ANCIENT SUNKEN TEMPLE ARCH & PILLARS ===
      { id: 'at-arch', kind: 'ancientArch', x: 248, y: 234, scale: 2, layer: 'back', interactive: true, label: 'Gerbang Kuil Atlantis' },
      { id: 'at-pillar-1', kind: 'ancientPillar', x: 184, y: 235, scale: 1, layer: 'back', interactive: true, label: 'Pilar Rune Kuno' },
      { id: 'at-pillar-2', kind: 'ancientPillar', x: 312, y: 227, scale: 1, flipX: true, layer: 'back', interactive: true, label: 'Pilar Rune Kuno' },

      // === MIDGROUND FOCAL HARDSCAPE & DRIFTWOOD ===
      { id: 'at-bonsai', kind: 'bonsaiDriftwood', x: 86, y: 222, scale: 1, seed: 31, layer: 'mid' },
      { id: 'at-rock-l', kind: 'layeredRock', x: 58, y: 220, scale: 1, seed: 41, layer: 'mid' },
      { id: 'at-rock-r', kind: 'layeredRock', x: 392, y: 218, scale: 1, flipX: true, seed: 42, layer: 'mid' },
      { id: 'at-boulder-1', kind: 'mossyBoulder', x: 158, y: 236, seed: 51, layer: 'mid' },
      { id: 'at-boulder-2', kind: 'mossyBoulder', x: 344, y: 224, seed: 52, layer: 'mid' },

      // === INTERACTIVE CENTERPIECE ORNAMENTS ===
      { id: 'at-chest', kind: 'treasureChest', x: 218, y: 239, scale: 1, layer: 'mid', interactive: true, label: 'Peti Harta Karun' },
      { id: 'at-helmet', kind: 'diverHelmet', x: 132, y: 233, scale: 1, layer: 'mid', interactive: true, label: 'Helm Penyelam Kuningan' },
      { id: 'at-volcano', kind: 'volcanoVent', x: 280, y: 234, scale: 1, layer: 'mid', interactive: true, label: 'Kawah Gelembung Vulkanik' },
      { id: 'at-clam', kind: 'pearlClam', x: 250, y: 241, scale: 1, layer: 'front', interactive: true, label: 'Kerang Mutiara Raksasa' },
      { id: 'at-lantern', kind: 'stoneLantern', x: 374, y: 217, scale: 1, layer: 'mid', interactive: true, label: 'Lentera Batu Berlumut' },
      { id: 'at-anchor', kind: 'sunkenAnchor', x: 412, y: 222, scale: 1, layer: 'mid' },
      { id: 'at-amphora', kind: 'amphoraUrn', x: 170, y: 239, scale: 1, layer: 'front' },

      // === GLOWING CRYSTALS & CORAL REEF ECOSYSTEM ===
      { id: 'at-crys-c1', kind: 'crystalCyan', x: 46, y: 217, scale: 1, layer: 'mid', interactive: true, label: 'Kristal Akuamarin' },
      { id: 'at-crys-a1', kind: 'crystalAmethyst', x: 398, y: 218, scale: 1, layer: 'mid', interactive: true, label: 'Kristal Ametis' },
      { id: 'at-crys-c2', kind: 'crystalCyan', x: 304, y: 232, scale: 1, layer: 'front', interactive: true, label: 'Kristal Akuamarin' },

      { id: 'at-seafan-1', kind: 'seaFanMagenta', x: 74, y: 218, height: 48, seed: 10, layer: 'mid' },
      { id: 'at-seafan-2', kind: 'seaFanGold', x: 422, y: 221, height: 52, seed: 11, layer: 'mid' },
      { id: 'at-seafan-3', kind: 'seaFanMagenta', x: 338, y: 222, height: 42, seed: 12, layer: 'mid' },

      { id: 'at-staghorn', kind: 'staghornCoral', x: 356, y: 224, scale: 1, layer: 'mid' },
      { id: 'at-brain-1', kind: 'brainCoral', x: 112, y: 230, scale: 1, layer: 'front' },
      { id: 'at-pipe-1', kind: 'pipeOrganCoral', x: 294, y: 237, scale: 1, layer: 'front' },
      { id: 'at-mush-1', kind: 'mushroomCoral', x: 54, y: 224, scale: 1, layer: 'front' },

      // === WAVING ANEMONES & LUSH FOREGROUND FLORA ===
      { id: 'at-anem-1', kind: 'anemoneCyan', x: 95, y: 227, height: 22, seed: 21, layer: 'front' },
      { id: 'at-anem-2', kind: 'anemoneMagenta', x: 325, y: 228, height: 24, seed: 22, layer: 'front' },
      { id: 'at-anem-3', kind: 'anemoneCoral', x: 382, y: 225, height: 20, seed: 23, layer: 'front' },
      { id: 'at-fern-1', kind: 'javaFern', x: 64, y: 217, height: 28, seed: 24, layer: 'mid' },
      { id: 'at-fern-2', kind: 'javaFern', x: 152, y: 234, height: 26, seed: 25, layer: 'front' },
      { id: 'at-glowmush', kind: 'glowMushroom', x: 194, y: 237, height: 18, seed: 26, layer: 'front' },

      // === FOREGROUND SHELLS, MARIMO & CARPET HAIRGRASS ===
      { id: 'at-grass-1', kind: 'hairgrass', x: 18, y: 226, height: 14, seed: 31, layer: 'front' },
      { id: 'at-grass-2', kind: 'hairgrass', x: 145, y: 239, height: 13, seed: 32, layer: 'front' },
      { id: 'at-grass-3', kind: 'hairgrass', x: 238, y: 245, height: 12, seed: 33, layer: 'front' },
      { id: 'at-grass-4', kind: 'hairgrass', x: 365, y: 226, height: 14, seed: 34, layer: 'front' },
      { id: 'at-grass-5', kind: 'hairgrass', x: 454, y: 223, height: 14, seed: 35, layer: 'front' },
      { id: 'at-marimo-1', kind: 'marimoBall', x: 78, y: 227, layer: 'front' },
      { id: 'at-marimo-2', kind: 'marimoBall', x: 432, y: 226, layer: 'front' },
      { id: 'at-conch', kind: 'conchShell', x: 202, y: 243, layer: 'front' },
      { id: 'at-spiral', kind: 'spiralShell', x: 274, y: 242, layer: 'front' },
      { id: 'at-pebble-1', kind: 'pebbleCluster', x: 28, y: 229, layer: 'front' },
      { id: 'at-pebble-2', kind: 'pebbleCluster', x: 348, y: 231, layer: 'front' },
    ],
  },

  zen: {
    id: 'zen',
    name: 'Taman Bonsai & Lentera Zen',
    subtitle: 'Aquascape Hutan Akar & Kuil Pagoda',
    description:
      'Gaya aquascape alami berbalut dua pohon bonsai driftwood berlumut zamrud, pagoda batu, lentera Tōrō hangat, hamparan rumput hijau, bola lumut Marimo, dan tirai Vallisneria.',
    defaultLighting: 'golden',
    sandStyle: 'riverDark',
    backdropStyle: 'temple',
    moundControlPoints: [
      { x: 0, y: 212 },
      { x: 65, y: 205 },
      { x: 140, y: 220 },
      { x: 240, y: 236 },
      { x: 340, y: 222 },
      { x: 415, y: 206 },
      { x: 480, y: 213 },
    ],
    backMoundControlPoints: [
      { x: 0, y: 185 },
      { x: 90, y: 180 },
      { x: 195, y: 204 },
      { x: 285, y: 204 },
      { x: 390, y: 182 },
      { x: 480, y: 188 },
    ],
    placements: [
      { id: 'zn-val-1', kind: 'vallisneria', x: 22, y: 212, height: 135, seed: 1, layer: 'back' },
      { id: 'zn-val-2', kind: 'vallisneria', x: 42, y: 209, height: 125, seed: 2, layer: 'back' },
      { id: 'zn-lud-1', kind: 'redLudwigia', x: 120, y: 218, height: 105, seed: 3, layer: 'back' },
      { id: 'zn-lud-2', kind: 'redLudwigia', x: 358, y: 218, height: 108, seed: 4, layer: 'back' },
      { id: 'zn-val-3', kind: 'vallisneria', x: 438, y: 210, height: 132, seed: 5, layer: 'back' },
      { id: 'zn-val-4', kind: 'vallisneria', x: 458, y: 213, height: 120, seed: 6, layer: 'back' },
      { id: 'zn-kelp-1', kind: 'giantKelp', x: 158, y: 225, height: 130, seed: 7, layer: 'back' },
      { id: 'zn-kelp-2', kind: 'giantKelp', x: 320, y: 225, height: 134, seed: 8, layer: 'back' },

      { id: 'zn-rock-l', kind: 'layeredRock', x: 64, y: 210, seed: 10, layer: 'mid' },
      { id: 'zn-rock-r', kind: 'layeredRock', x: 406, y: 210, flipX: true, seed: 11, layer: 'mid' },
      { id: 'zn-bonsai-l', kind: 'bonsaiDriftwood', x: 96, y: 214, seed: 12, layer: 'mid' },
      { id: 'zn-bonsai-r', kind: 'bonsaiDriftwood', x: 382, y: 214, flipX: true, seed: 13, layer: 'mid' },
      { id: 'zn-log', kind: 'driftwoodLog', x: 240, y: 236, seed: 14, layer: 'mid' },

      { id: 'zn-pagoda', kind: 'pagodaMini', x: 240, y: 226, scale: 2, layer: 'back' },
      { id: 'zn-lantern-1', kind: 'stoneLantern', x: 175, y: 228, layer: 'mid', interactive: true, label: 'Lentera Batu Barat' },
      { id: 'zn-lantern-2', kind: 'stoneLantern', x: 305, y: 228, layer: 'mid', interactive: true, label: 'Lentera Batu Timur' },
      { id: 'zn-clam', kind: 'pearlClam', x: 218, y: 239, layer: 'front', interactive: true, label: 'Kerang Mutiara Zen' },
      { id: 'zn-volcano', kind: 'volcanoVent', x: 266, y: 238, layer: 'mid', interactive: true, label: 'Batu Gelembung Udara' },
      { id: 'zn-crys-1', kind: 'crystalCyan', x: 144, y: 226, layer: 'mid', interactive: true, label: 'Kristal Ketenangan' },
      { id: 'zn-amphora', kind: 'amphoraUrn', x: 334, y: 226, layer: 'mid' },

      { id: 'zn-fern-1', kind: 'javaFern', x: 56, y: 212, height: 32, seed: 21, layer: 'front' },
      { id: 'zn-fern-2', kind: 'javaFern', x: 136, y: 223, height: 28, seed: 22, layer: 'front' },
      { id: 'zn-fern-3', kind: 'javaFern', x: 344, y: 224, height: 28, seed: 23, layer: 'front' },
      { id: 'zn-fern-4', kind: 'javaFern', x: 424, y: 213, height: 32, seed: 24, layer: 'front' },

      { id: 'zn-marimo-1', kind: 'marimoBall', x: 196, y: 236, layer: 'front' },
      { id: 'zn-marimo-2', kind: 'marimoBall', x: 209, y: 238, layer: 'front' },
      { id: 'zn-marimo-3', kind: 'marimoBall', x: 285, y: 237, layer: 'front' },
      { id: 'zn-boulder-1', kind: 'mossyBoulder', x: 80, y: 214, seed: 25, layer: 'front' },
      { id: 'zn-boulder-2', kind: 'mossyBoulder', x: 400, y: 214, seed: 26, layer: 'front' },

      { id: 'zn-grass-1', kind: 'hairgrass', x: 36, y: 216, height: 15, seed: 30, layer: 'front' },
      { id: 'zn-grass-2', kind: 'hairgrass', x: 112, y: 222, height: 15, seed: 31, layer: 'front' },
      { id: 'zn-grass-3', kind: 'hairgrass', x: 168, y: 234, height: 14, seed: 32, layer: 'front' },
      { id: 'zn-grass-4', kind: 'hairgrass', x: 242, y: 241, height: 14, seed: 33, layer: 'front' },
      { id: 'zn-grass-5', kind: 'hairgrass', x: 322, y: 231, height: 14, seed: 34, layer: 'front' },
      { id: 'zn-grass-6', kind: 'hairgrass', x: 374, y: 220, height: 15, seed: 35, layer: 'front' },
      { id: 'zn-grass-7', kind: 'hairgrass', x: 446, y: 216, height: 15, seed: 36, layer: 'front' },
      { id: 'zn-peb-1', kind: 'pebbleCluster', x: 156, y: 232, layer: 'front' },
      { id: 'zn-peb-2', kind: 'pebbleCluster', x: 324, y: 232, layer: 'front' },
    ],
  },

  crystal: {
    id: 'crystal',
    name: 'Gua Kristal Bioluminesen',
    subtitle: 'Palung Cahaya Neon & Terumbu Bercahaya',
    description:
      'Palung laut malam yang dipenuhi gugusan kristal ametis & akuamarin raksasa, anemon berpendar, kipas laut magenta, kawah gelembung vulkanik, peti harta karun, dan spora cahaya mistis.',
    defaultLighting: 'night',
    sandStyle: 'obsidianSpark',
    backdropStyle: 'reef',
    moundControlPoints: [
      { x: 0, y: 218 },
      { x: 55, y: 209 },
      { x: 120, y: 225 },
      { x: 185, y: 234 },
      { x: 245, y: 229 },
      { x: 315, y: 236 },
      { x: 395, y: 216 },
      { x: 480, y: 210 },
    ],
    backMoundControlPoints: [
      { x: 0, y: 186 },
      { x: 75, y: 180 },
      { x: 170, y: 202 },
      { x: 255, y: 196 },
      { x: 350, y: 186 },
      { x: 430, y: 176 },
      { x: 480, y: 182 },
    ],
    placements: [
      { id: 'cr-spire-1', kind: 'basaltSpire', x: 34, y: 216, seed: 1, layer: 'back' },
      { id: 'cr-spire-2', kind: 'basaltSpire', x: 245, y: 228, seed: 2, layer: 'back' },
      { id: 'cr-spire-3', kind: 'basaltSpire', x: 446, y: 214, flipX: true, seed: 3, layer: 'back' },

      { id: 'cr-big-c1', kind: 'crystalCyan', x: 64, y: 214, scale: 2, layer: 'back', interactive: true, label: 'Menara Kristal Akuamarin' },
      { id: 'cr-big-a1', kind: 'crystalAmethyst', x: 414, y: 216, scale: 2, layer: 'back', interactive: true, label: 'Menara Kristal Ametis' },
      { id: 'cr-pillar-1', kind: 'ancientPillar', x: 162, y: 231, layer: 'back', interactive: true, label: 'Monolit Rune Kuno' },
      { id: 'cr-pillar-2', kind: 'ancientPillar', x: 320, y: 234, flipX: true, layer: 'back', interactive: true, label: 'Monolit Rune Kuno' },

      { id: 'cr-kelp-1', kind: 'giantKelp', x: 18, y: 218, height: 155, seed: 4, layer: 'back' },
      { id: 'cr-kelp-2', kind: 'giantKelp', x: 464, y: 214, height: 160, seed: 5, layer: 'back' },
      { id: 'cr-fan-1', kind: 'seaFanMagenta', x: 108, y: 222, height: 60, seed: 6, layer: 'mid' },
      { id: 'cr-fan-2', kind: 'seaFanGold', x: 204, y: 233, height: 55, seed: 7, layer: 'mid' },
      { id: 'cr-fan-3', kind: 'seaFanMagenta', x: 372, y: 221, height: 58, seed: 8, layer: 'mid' },

      { id: 'cr-volcano', kind: 'volcanoVent', x: 244, y: 230, scale: 1, layer: 'mid', interactive: true, label: 'Kawah Magma Gelembung' },
      { id: 'cr-chest', kind: 'treasureChest', x: 136, y: 230, scale: 1, layer: 'mid', interactive: true, label: 'Peti Kristal Tenggelam' },
      { id: 'cr-clam', kind: 'pearlClam', x: 294, y: 236, scale: 1, layer: 'front', interactive: true, label: 'Kerang Mutiara Bercahaya' },
      { id: 'cr-helmet', kind: 'diverHelmet', x: 348, y: 230, scale: 1, layer: 'mid', interactive: true, label: 'Helm Penyelam Tua' },

      { id: 'cr-crys-m1', kind: 'crystalAmethyst', x: 192, y: 235, layer: 'front', interactive: true, label: 'Kristal Ametis' },
      { id: 'cr-crys-m2', kind: 'crystalCyan', x: 274, y: 233, layer: 'front', interactive: true, label: 'Kristal Akuamarin' },
      { id: 'cr-crys-m3', kind: 'crystalCyan', x: 392, y: 220, layer: 'front', interactive: true, label: 'Kristal Akuamarin' },

      { id: 'cr-anem-1', kind: 'anemoneCyan', x: 84, y: 218, height: 24, seed: 11, layer: 'front' },
      { id: 'cr-anem-2', kind: 'anemoneMagenta', x: 170, y: 236, height: 26, seed: 12, layer: 'front' },
      { id: 'cr-anem-3', kind: 'anemoneCyan', x: 224, y: 235, height: 22, seed: 13, layer: 'front' },
      { id: 'cr-anem-4', kind: 'anemoneCoral', x: 332, y: 236, height: 25, seed: 14, layer: 'front' },
      { id: 'cr-anem-5', kind: 'anemoneMagenta', x: 434, y: 218, height: 24, seed: 15, layer: 'front' },

      { id: 'cr-mush-1', kind: 'mushroomCoral', x: 48, y: 219, layer: 'front' },
      { id: 'cr-mush-2', kind: 'mushroomCoral', x: 368, y: 227, layer: 'front' },
      { id: 'cr-brain', kind: 'brainCoral', x: 264, y: 237, layer: 'front' },
      { id: 'cr-pipe', kind: 'pipeOrganCoral', x: 114, y: 228, layer: 'front' },
      { id: 'cr-stag', kind: 'staghornCoral', x: 400, y: 222, layer: 'mid' },
      { id: 'cr-glowm-1', kind: 'glowMushroom', x: 154, y: 234, height: 20, seed: 21, layer: 'front' },
      { id: 'cr-glowm-2', kind: 'glowMushroom', x: 312, y: 239, height: 22, seed: 22, layer: 'front' },
      { id: 'cr-conch', kind: 'conchShell', x: 216, y: 238, layer: 'front' },
      { id: 'cr-peb', kind: 'pebbleCluster', x: 246, y: 237, layer: 'front' },
    ],
  },

  natureGarden: {
    id: 'natureGarden',
    name: 'Taman Alam Bonsai Iwagumi',
    subtitle: 'Nature Aquarium · Pohon Lumut & Batu Seiryu',
    description:
      'Komposisi Nature Aquarium ala Takashi Amano: pohon bonsai driftwood raksasa dengan kanopi lumut zamraud yang sangat padat, akar nebari menyebar, gugusan batu Seiryu & lava rock berbundar berlumut, hamparan karpet Dwarf Hairgrass dan Monte Carlo yang rapat, semak Anubias Nana, serta dinding tanaman Hygrophila hijau pekat di atas lapisan aquasoil gelap.',
    defaultLighting: 'sunlight',
    sandStyle: 'natureAquasoil',
    backdropStyle: 'nature',
    moundControlPoints: [
      { x: 0, y: 251 },
      { x: 55, y: 249 },
      { x: 125, y: 252 },
      { x: 205, y: 253 },
      { x: 285, y: 252 },
      { x: 360, y: 249 },
      { x: 435, y: 251 },
      { x: 480, y: 250 },
    ],
    backMoundControlPoints: [
      { x: 0, y: 213 },
      { x: 55, y: 204 },
      { x: 130, y: 218 },
      { x: 205, y: 227 },
      { x: 275, y: 224 },
      { x: 355, y: 210 },
      { x: 430, y: 202 },
      { x: 480, y: 211 },
    ],
    placements: [
      // === BACKGROUND: DENSE GREEN FOLIAGE WALL ACROSS THE WHOLE BACK ===
      { id: 'ng-bg-1', kind: 'hygrophilaBush', x: 20, y: 222, height: 66, spread: 46, seed: 101, layer: 'back' },
      { id: 'ng-bg-2', kind: 'hygrophilaBush', x: 56, y: 220, height: 54, spread: 38, seed: 102, layer: 'back' },
      { id: 'ng-bg-3', kind: 'hygrophilaBush', x: 92, y: 224, height: 70, spread: 48, seed: 103, layer: 'back' },
      { id: 'ng-bg-4', kind: 'hygrophilaBush', x: 128, y: 221, height: 50, spread: 36, seed: 104, layer: 'back' },
      { id: 'ng-bg-5', kind: 'hygrophilaBush', x: 162, y: 219, height: 58, spread: 34, seed: 105, layer: 'back' },
      { id: 'ng-bg-6', kind: 'hygrophilaBush', x: 190, y: 226, height: 44, spread: 28, seed: 106, layer: 'back' },
      { id: 'ng-bg-7', kind: 'hygrophilaBush', x: 242, y: 226, height: 46, spread: 30, seed: 107, layer: 'back' },
      { id: 'ng-bg-8', kind: 'hygrophilaBush', x: 276, y: 221, height: 52, spread: 34, seed: 108, layer: 'back' },
      { id: 'ng-bg-9', kind: 'hygrophilaBush', x: 310, y: 224, height: 62, spread: 42, seed: 109, layer: 'back' },
      { id: 'ng-bg-10', kind: 'hygrophilaBush', x: 348, y: 220, height: 56, spread: 38, seed: 110, layer: 'back' },
      { id: 'ng-bg-11', kind: 'hygrophilaBush', x: 386, y: 223, height: 68, spread: 46, seed: 111, layer: 'back' },
      { id: 'ng-bg-12', kind: 'hygrophilaBush', x: 426, y: 220, height: 54, spread: 38, seed: 112, layer: 'back' },
      { id: 'ng-bg-13', kind: 'hygrophilaBush', x: 462, y: 223, height: 58, spread: 40, seed: 113, layer: 'back' },

      // Tall dark edge accents framing the composition
      { id: 'ng-kelp-l', kind: 'giantKelp', x: 6, y: 229, height: 124, seed: 1, layer: 'back' },
      { id: 'ng-val-r', kind: 'vallisneria', x: 476, y: 227, height: 104, seed: 2, layer: 'back' },

      // Small warm-red accents at the extreme edges only (as in the reference)
      { id: 'ng-rot-1', kind: 'rotalaBush', x: 10, y: 234, height: 30, spread: 14, seed: 114, layer: 'back' },
      { id: 'ng-rot-2', kind: 'rotalaBush', x: 470, y: 235, height: 28, spread: 13, seed: 115, layer: 'back' },

      // === MIDGROUND: ROUNDED MOSSY BOULDER CLUSTERS (IWAGUMI) ===
      { id: 'ng-seiryu-l', kind: 'seiryuStone', x: 108, y: 224, seed: 41, layer: 'mid' },
      { id: 'ng-lava-l', kind: 'lavaRockCluster', x: 152, y: 233, seed: 42, layer: 'mid' },
      { id: 'ng-seiryu-r', kind: 'seiryuStone', x: 374, y: 216, flipX: true, seed: 43, layer: 'mid' },
      { id: 'ng-lava-r', kind: 'lavaRockCluster', x: 404, y: 227, flipX: true, seed: 44, layer: 'mid' },
      { id: 'ng-oyaishi', kind: 'seiryuStone', x: 298, y: 235, seed: 45, layer: 'mid' },

      // === MIDGROUND: ANUBIAS NANA, JAVA FERN & MOSSY STONES ===
      { id: 'ng-fern-1', kind: 'javaFern', x: 104, y: 212, height: 30, seed: 51, layer: 'mid' },
      { id: 'ng-fern-2', kind: 'javaFern', x: 372, y: 206, height: 28, seed: 52, layer: 'mid' },
      { id: 'ng-anu-1', kind: 'anubiasNana', x: 82, y: 216, height: 22, seed: 53, layer: 'mid' },
      { id: 'ng-anu-2', kind: 'anubiasNana', x: 128, y: 220, height: 20, seed: 54, layer: 'mid' },
      { id: 'ng-anu-3', kind: 'anubiasNana', x: 162, y: 225, height: 18, seed: 55, layer: 'mid' },
      { id: 'ng-anu-4', kind: 'anubiasNana', x: 348, y: 210, height: 22, seed: 56, layer: 'mid' },
      { id: 'ng-anu-5', kind: 'anubiasNana', x: 394, y: 214, height: 20, seed: 57, layer: 'mid' },
      { id: 'ng-anu-6', kind: 'anubiasNana', x: 424, y: 218, height: 18, seed: 58, layer: 'mid' },
      { id: 'ng-anu-7', kind: 'anubiasNana', x: 296, y: 231, height: 17, seed: 59, layer: 'mid' },
      { id: 'ng-anu-8', kind: 'anubiasNana', x: 220, y: 238, height: 16, seed: 60, layer: 'mid' },
      { id: 'ng-moss-1', kind: 'javaMossStone', x: 138, y: 231, seed: 61, layer: 'mid' },
      { id: 'ng-moss-2', kind: 'javaMossStone', x: 252, y: 233, seed: 62, layer: 'mid' },
      { id: 'ng-moss-3', kind: 'javaMossStone', x: 330, y: 229, seed: 63, layer: 'mid' },

      // === CENTERPIECE: ANCIENT MOSSY BONSAI TREE ===
      { id: 'ng-tree', kind: 'bonsaiTreeAncient', x: 206, y: 231, seed: 31, layer: 'mid', label: 'Pohon Bonsai Lumut Raksasa' },

      // Small sunken branch resting on the substrate
      { id: 'ng-log', kind: 'driftwoodLog', x: 258, y: 240, seed: 46, layer: 'mid' },

      // === FOREGROUND: LUSH DENSE CARPET & BRIGHT SAND PATH ===
      { id: 'ng-hc-1', kind: 'dwarfHairgrassCarpet', x: 118, y: 253, spread: 205, seed: 71, layer: 'front' },
      { id: 'ng-hc-2', kind: 'dwarfHairgrassCarpet', x: 336, y: 253, spread: 185, seed: 72, layer: 'front' },
      { id: 'ng-hc-3', kind: 'dwarfHairgrassCarpet', x: 26, y: 252, spread: 56, seed: 73, layer: 'front' },
      { id: 'ng-hc-4', kind: 'dwarfHairgrassCarpet', x: 456, y: 252, spread: 56, seed: 74, layer: 'front' },
      { id: 'ng-mc-1', kind: 'monteCarloCarpet', x: 214, y: 252, spread: 96, seed: 75, layer: 'front' },
      { id: 'ng-mc-2', kind: 'monteCarloCarpet', x: 396, y: 251, spread: 76, seed: 76, layer: 'front' },
      { id: 'ng-mc-3', kind: 'monteCarloCarpet', x: 60, y: 251, spread: 48, seed: 77, layer: 'front' },

      // Foreground hairgrass tufts breaking the carpet line
      { id: 'ng-grass-1', kind: 'hairgrass', x: 56, y: 255, height: 13, seed: 81, layer: 'front' },
      { id: 'ng-grass-2', kind: 'hairgrass', x: 186, y: 256, height: 12, seed: 82, layer: 'front' },
      { id: 'ng-grass-3', kind: 'hairgrass', x: 300, y: 255, height: 13, seed: 83, layer: 'front' },
      { id: 'ng-grass-4', kind: 'hairgrass', x: 434, y: 255, height: 12, seed: 84, layer: 'front' },

      // Tiny pale pebbles scattered along the bright sand path
      { id: 'ng-peb-1', kind: 'pebbleCluster', x: 18, y: 262, seed: 91, layer: 'front' },
      { id: 'ng-peb-2', kind: 'pebbleCluster', x: 462, y: 261, seed: 92, layer: 'front' },
    ],
  },
};

export const PLACEABLE_BRUSHES: PlaceableBrush[] = [
  {
    kind: 'crystalCyan',
    name: 'Kristal Akuamarin',
    category: 'ornament',
    description: 'Kristal biru berpendar lembut',
  },
  {
    kind: 'crystalAmethyst',
    name: 'Kristal Ametis',
    category: 'ornament',
    description: 'Kristal ungu mistis',
  },
  {
    kind: 'treasureChest',
    name: 'Peti Harta Karun',
    category: 'ornament',
    description: 'Dapat diklik untuk membuka peti',
  },
  {
    kind: 'pearlClam',
    name: 'Kerang Mutiara',
    category: 'ornament',
    description: 'Ornamen kerang bermutiara berkilau',
  },
  {
    kind: 'stoneLantern',
    name: 'Lentera Batu Tōrō',
    category: 'ornament',
    description: 'Lentera kuil berlumut hangat',
  },
  {
    kind: 'diverHelmet',
    name: 'Helm Penyelam',
    category: 'ornament',
    description: 'Helm kuningan antik klasik',
  },
  {
    kind: 'volcanoVent',
    name: 'Kawah Gelembung',
    category: 'ornament',
    description: 'Ventilasi batu vulkanik bergelembung',
  },
  {
    kind: 'amphoraUrn',
    name: 'Guci Amphora',
    category: 'ornament',
    description: 'Guci terakota kuno berlumut',
  },
  {
    kind: 'sunkenAnchor',
    name: 'Jangkar Kapal',
    category: 'ornament',
    description: 'Jangkar besi tua bergaya klasik',
  },
  {
    kind: 'ancientPillar',
    name: 'Pilar Rune Kuno',
    category: 'ornament',
    description: 'Pilar reruntuhan berukir rune',
  },
  {
    kind: 'staghornCoral',
    name: 'Koral Tanduk Rusa',
    category: 'coral',
    description: 'Terumbu karang oranye menyala',
  },
  {
    kind: 'brainCoral',
    name: 'Koral Otak Merah',
    category: 'coral',
    description: 'Koral kubah bermotif lekuk',
  },
  {
    kind: 'pipeOrganCoral',
    name: 'Koral Pipa Zamrud',
    category: 'coral',
    description: 'Koloni tabung karang pirus',
  },
  {
    kind: 'mushroomCoral',
    name: 'Koral Jamur Violet',
    category: 'coral',
    description: 'Koral bertingkat ungu bercahaya',
  },
  {
    kind: 'seaFanMagenta',
    name: 'Kipas Laut Magenta',
    category: 'coral',
    description: 'Kipas gorgonian melambai lembut',
  },
  {
    kind: 'seaFanGold',
    name: 'Kipas Laut Emas',
    category: 'coral',
    description: 'Kipas gorgonian keemasan',
  },
  {
    kind: 'anemoneCyan',
    name: 'Anemon Sian',
    category: 'coral',
    description: 'Tentakel anemon berpendar sian',
  },
  {
    kind: 'anemoneMagenta',
    name: 'Anemon Magenta',
    category: 'coral',
    description: 'Tentakel anemon ungu-merah muda',
  },
  {
    kind: 'giantKelp',
    name: 'Kelp Raksasa',
    category: 'plant',
    defaultHeight: 135,
    description: 'Rumput laut tinggi melambai',
  },
  {
    kind: 'vallisneria',
    name: 'Vallisneria Pita',
    category: 'plant',
    defaultHeight: 98,
    description: 'Pita daun zamrud bergelombang',
  },
  {
    kind: 'redLudwigia',
    name: 'Ludwigia Merah',
    category: 'plant',
    defaultHeight: 80,
    description: 'Tanaman air daun merah delima',
  },
  {
    kind: 'javaFern',
    name: 'Pakis Jawa',
    category: 'plant',
    defaultHeight: 28,
    description: 'Rumpun pakis hijau segar',
  },
  {
    kind: 'glowMushroom',
    name: 'Jamur Cahaya',
    category: 'plant',
    defaultHeight: 20,
    description: 'Jamur air bioluminesen mini',
  },
  {
    kind: 'hairgrass',
    name: 'Karpet Rumput Mini',
    category: 'plant',
    defaultHeight: 14,
    description: 'Hamparan rumput dasar akuarium',
  },
  {
    kind: 'marimoBall',
    name: 'Bola Lumut Marimo',
    category: 'plant',
    description: 'Bola alga beludru hijau imut',
  },
  {
    kind: 'bonsaiDriftwood',
    name: 'Pohon Bonsai Akar',
    category: 'rock',
    description: 'Kayu akar berlumut ala aquascape',
  },
  {
    kind: 'mossyBoulder',
    name: 'Batu Berlumut',
    category: 'rock',
    description: 'Batu sungai diselimuti lumut',
  },
  {
    kind: 'conchShell',
    name: 'Cangkang Keong',
    category: 'rock',
    description: 'Hiasan cangkang laut mutiara',
  },
  {
    kind: 'bonsaiTreeAncient',
    name: 'Pohon Bonsai Lumut Raksasa',
    category: 'rock',
    description: 'Centerpiece driftwood berlumut ala Amano',
  },
  {
    kind: 'seiryuStone',
    name: 'Batu Seiryu Iwagumi',
    category: 'rock',
    description: 'Kelompok batu biru-abu bergaris',
  },
  {
    kind: 'lavaRockCluster',
    name: 'Kelompok Lava Rock',
    category: 'rock',
    description: 'Batu lava gelap berpori berlumut',
  },
  {
    kind: 'javaMossStone',
    name: 'Batu Berlumut Jawa',
    category: 'rock',
    description: 'Kerikil diselimuti java moss',
  },
  {
    kind: 'dwarfHairgrassCarpet',
    name: 'Karpet Dwarf Hairgrass',
    category: 'plant',
    defaultHeight: 10,
    description: 'Karpet rumput pendek terang',
  },
  {
    kind: 'monteCarloCarpet',
    name: 'Karpet Monte Carlo',
    category: 'plant',
    defaultHeight: 6,
    description: 'Karpet daun bulat hijau cerah',
  },
  {
    kind: 'anubiasNana',
    name: 'Anubias Nana',
    category: 'plant',
    defaultHeight: 20,
    description: 'Semak daun lebar hijau tua',
  },
  {
    kind: 'hygrophilaBush',
    name: 'Semak Hygrophila',
    category: 'plant',
    defaultHeight: 48,
    description: 'Dinding tanaman batang hijau',
  },
  {
    kind: 'rotalaBush',
    name: 'Semak Rotala Merah',
    category: 'plant',
    defaultHeight: 48,
    description: 'Batang merah muda kontras',
  },
];

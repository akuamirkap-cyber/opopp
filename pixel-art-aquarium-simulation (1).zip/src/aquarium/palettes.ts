import type { LightingMode } from './types';

export interface WaterAtmospherePalette {
  topColor: string;
  upperMidColor: string;
  lowerMidColor: string;
  bottomColor: string;
  silhouetteFar: string;
  silhouetteNear: string;
  surfaceLineBright: string;
  surfaceLineMid: string;
  surfaceGlow: string;
  godRayColor: string;
  godRayAlpha: number;
  causticColor: string;
  causticAlpha: number;
  ambientDarkness: number; // 0 (bright daylight) .. 0.78 (deep abyss)
  ambientTint: string;
  glowIntensity: number; // 0.25 (day) .. 1.0 (night/abyss)
  fogColor: string;
  fogAlpha: number;
}

export const BAYER_4X4 = [
  [0, 8, 2, 10],
  [12, 4, 14, 6],
  [3, 11, 1, 9],
  [15, 7, 13, 5],
];

export function bayerThreshold(x: number, y: number): number {
  return BAYER_4X4[y & 3][x & 3] / 16;
}

export function hexToRgb(hex: string): [number, number, number] {
  const clean = hex.replace('#', '');
  const n = parseInt(clean, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function rgbToHex(r: number, g: number, b: number): string {
  const clamp = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return (
    '#' +
    ((1 << 24) + (clamp(r) << 16) + (clamp(g) << 8) + clamp(b))
      .toString(16)
      .slice(1)
  );
}

export function lerpColor(hexA: string, hexB: string, t: number): string {
  const clamped = Math.max(0, Math.min(1, t));
  const [r1, g1, b1] = hexToRgb(hexA);
  const [r2, g2, b2] = hexToRgb(hexB);
  return rgbToHex(
    r1 + (r2 - r1) * clamped,
    g1 + (g2 - g1) * clamped,
    b1 + (b2 - b1) * clamped
  );
}

export const ATMOSPHERE_PALETTES: Record<
  Exclude<LightingMode, 'auto'>,
  WaterAtmospherePalette
> = {
  sunlight: {
    topColor: '#f4ffd6',
    upperMidColor: '#d2f77f',
    lowerMidColor: '#8ed957',
    bottomColor: '#2f8a4e',
    silhouetteFar: '#2a7a4a',
    silhouetteNear: '#1d5c39',
    surfaceLineBright: '#ffffff',
    surfaceLineMid: '#fdfff0',
    surfaceGlow: '#e8fcb0',
    godRayColor: '#fbffd9',
    godRayAlpha: 0.24,
    causticColor: '#fdfff0',
    causticAlpha: 0.32,
    ambientDarkness: 0.0,
    ambientTint: '#0a3a22',
    glowIntensity: 0.5,
    fogColor: '#4aa866',
    fogAlpha: 0.08,
  },
  day: {
    topColor: '#4af3f7',
    upperMidColor: '#14b4cc',
    lowerMidColor: '#0a6484',
    bottomColor: '#04243a',
    silhouetteFar: '#0c5170',
    silhouetteNear: '#073650',
    surfaceLineBright: '#ffffff',
    surfaceLineMid: '#a5fbff',
    surfaceGlow: '#b6f9e8',
    godRayColor: '#ccfffe',
    godRayAlpha: 0.34,
    causticColor: '#d8ffff',
    causticAlpha: 0.44,
    ambientDarkness: 0.04,
    ambientTint: '#042538',
    glowIntensity: 0.42,
    fogColor: '#0d7090',
    fogAlpha: 0.18,
  },
  golden: {
    topColor: '#ffd480',
    upperMidColor: '#e08b67',
    lowerMidColor: '#37677e',
    bottomColor: '#122242',
    silhouetteFar: '#274363',
    silhouetteNear: '#1c314f',
    surfaceLineBright: '#fff4c2',
    surfaceLineMid: '#ffbe6b',
    surfaceGlow: '#fed7aa',
    godRayColor: '#ffe08a',
    godRayAlpha: 0.28,
    causticColor: '#ffd791',
    causticAlpha: 0.32,
    ambientDarkness: 0.2,
    ambientTint: '#1e1633',
    glowIntensity: 0.58,
    fogColor: '#2e4766',
    fogAlpha: 0.24,
  },
  night: {
    topColor: '#134e6f',
    upperMidColor: '#0b2f52',
    lowerMidColor: '#071b36',
    bottomColor: '#030b1c',
    silhouetteFar: '#081f3c',
    silhouetteNear: '#06162d',
    surfaceLineBright: '#a5f3fc',
    surfaceLineMid: '#38bdf8',
    surfaceGlow: '#22d3ee',
    godRayColor: '#67e8f9',
    godRayAlpha: 0.14,
    causticColor: '#5eead4',
    causticAlpha: 0.18,
    ambientDarkness: 0.52,
    ambientTint: '#030b1d',
    glowIntensity: 1.0,
    fogColor: '#061933',
    fogAlpha: 0.3,
  },
  abyss: {
    topColor: '#0b2e47',
    upperMidColor: '#081b33',
    lowerMidColor: '#050f22',
    bottomColor: '#020510',
    silhouetteFar: '#061228',
    silhouetteNear: '#040c1c',
    surfaceLineBright: '#67e8f9',
    surfaceLineMid: '#0891b2',
    surfaceGlow: '#2dd4bf',
    godRayColor: '#38bdf8',
    godRayAlpha: 0.08,
    causticColor: '#22d3ee',
    causticAlpha: 0.12,
    ambientDarkness: 0.68,
    ambientTint: '#020614',
    glowIntensity: 1.18,
    fogColor: '#030b1a',
    fogAlpha: 0.36,
  },
};

export function getAtmosphereAtTime(
  mode: LightingMode,
  cycleTimeSec: number
): WaterAtmospherePalette {
  if (mode !== 'auto') {
    return ATMOSPHERE_PALETTES[mode];
  }
  const order: Array<Exclude<LightingMode, 'auto'>> = [
    'day',
    'sunlight',
    'golden',
    'night',
    'abyss',
  ];
  const period = 60; // 60 seconds full ambient cycle
  const norm = ((cycleTimeSec % period) / period) * order.length;
  const idxA = Math.floor(norm) % order.length;
  const idxB = (idxA + 1) % order.length;
  const frac = norm - Math.floor(norm);
  // Smoothstep easing so each lighting phase lingers gracefully
  const t = frac * frac * (3 - 2 * frac);

  const a = ATMOSPHERE_PALETTES[order[idxA]];
  const b = ATMOSPHERE_PALETTES[order[idxB]];

  return {
    topColor: lerpColor(a.topColor, b.topColor, t),
    upperMidColor: lerpColor(a.upperMidColor, b.upperMidColor, t),
    lowerMidColor: lerpColor(a.lowerMidColor, b.lowerMidColor, t),
    bottomColor: lerpColor(a.bottomColor, b.bottomColor, t),
    silhouetteFar: lerpColor(a.silhouetteFar, b.silhouetteFar, t),
    silhouetteNear: lerpColor(a.silhouetteNear, b.silhouetteNear, t),
    surfaceLineBright: lerpColor(a.surfaceLineBright, b.surfaceLineBright, t),
    surfaceLineMid: lerpColor(a.surfaceLineMid, b.surfaceLineMid, t),
    surfaceGlow: lerpColor(a.surfaceGlow, b.surfaceGlow, t),
    godRayColor: lerpColor(a.godRayColor, b.godRayColor, t),
    godRayAlpha: a.godRayAlpha + (b.godRayAlpha - a.godRayAlpha) * t,
    causticColor: lerpColor(a.causticColor, b.causticColor, t),
    causticAlpha: a.causticAlpha + (b.causticAlpha - a.causticAlpha) * t,
    ambientDarkness:
      a.ambientDarkness + (b.ambientDarkness - a.ambientDarkness) * t,
    ambientTint: lerpColor(a.ambientTint, b.ambientTint, t),
    glowIntensity: a.glowIntensity + (b.glowIntensity - a.glowIntensity) * t,
    fogColor: lerpColor(a.fogColor, b.fogColor, t),
    fogAlpha: a.fogAlpha + (b.fogAlpha - a.fogAlpha) * t,
  };
}

export const SAND_PALETTES = {
  coralGold: {
    highlight: '#fef3c7',
    light: '#f3d9a4',
    mid: '#d9b578',
    shadow: '#b08552',
    deep: '#7c5634',
    speckA: '#fffbeb',
    speckB: '#f4a29e',
    speckC: '#6b442b',
    backRidge: '#9b7b56',
    backDeep: '#6a503a',
  },
  riverDark: {
    highlight: '#d6ccb8',
    light: '#b5a88f',
    mid: '#8f826c',
    shadow: '#665b4a',
    deep: '#41392e',
    speckA: '#e7e0cf',
    speckB: '#94a3b8',
    speckC: '#2b251d',
    backRidge: '#6a6252',
    backDeep: '#453f35',
  },
  obsidianSpark: {
    highlight: '#7dd3fc',
    light: '#526780',
    mid: '#38485e',
    shadow: '#232f42',
    deep: '#131b29',
    speckA: '#67e8f9',
    speckB: '#c084fc',
    speckC: '#0a0f1a',
    backRidge: '#2c3a4f',
    backDeep: '#182130',
  },
  natureAquasoil: {
    // Bright pale front sand path (Amazonia-style white sand foreground)
    highlight: '#ffffff',
    light: '#fefcf4',
    mid: '#f4ecd6',
    shadow: '#dbcdac',
    deep: '#b3a284',
    speckA: '#ffffff',
    speckB: '#e6d8b4',
    speckC: '#8f805f',
    // Dark nutrient-rich aquasoil bank rising at the back
    backRidge: '#3a3020',
    backDeep: '#1a150f',
  },
};

export const FLORA_RAMPS = {
  kelp: ['#e2fc9a', '#8fd14f', '#4e9631', '#2b6127', '#14381c'],
  vallisneria: ['#c4ffbe', '#62d97b', '#279e59', '#146642', '#0a382c'],
  ludwigia: ['#ffd1dc', '#ff6e91', '#d62f64', '#8c1648', '#4a0c2c'],
  seaFanMagenta: ['#ffe0ff', '#f08cff', '#c43bdb', '#811da3', '#420d5c'],
  seaFanGold: ['#fff5bd', '#ffbe55', '#eb7a28', '#a64319', '#571e12'],
  anemoneCyan: ['#e6ffff', '#73f7ff', '#19c2e6', '#0c789e', '#073c5c'],
  anemoneMagenta: ['#ffe8fb', '#ff8ae6', '#db35b7', '#87187b', '#470a4a'],
  anemoneCoral: ['#ffe4cc', '#ff9d6e', '#ed563b', '#9e2624', '#521018'],
  javaFern: ['#b8f593', '#5ec251', '#2c8a3c', '#18592d', '#0b2e1c'],
  hairgrass: ['#d8ff8a', '#7cd44e', '#3c9638', '#205e2a'],
  glowMushroom: ['#ffffff', '#99f6ff', '#22d3ee', '#0e7490', '#083344'],
  dwarfHairgrass: ['#f7fff0', '#c5f88a', '#6ee07a', '#2fa84a', '#14622c'],
  monteCarlo: ['#fbfff5', '#e4fca0', '#b6e63a', '#7cb518', '#3f5c0d'],
  anubias: ['#d9fbe0', '#7ee08a', '#2e9b4a', '#12622f', '#07331a'],
  hygrophila: ['#f2ffd6', '#caf06a', '#93c93a', '#5b8c1c', '#2a4409'],
  rotala: ['#ffe3ea', '#ff9db4', '#e8457a', '#a81a52', '#4d0a26'],
};

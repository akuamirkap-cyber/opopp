export const VIRTUAL_WIDTH = 480;
export const VIRTUAL_HEIGHT = 270;
export const WATER_SURFACE_Y = 24;

export type LightingMode =
  | 'day'
  | 'sunlight'
  | 'golden'
  | 'night'
  | 'abyss'
  | 'auto';

export type PresetId = 'atlantis' | 'zen' | 'crystal' | 'natureGarden';

export type SpriteKind =
  | 'treasureChest'
  | 'diverHelmet'
  | 'stoneLantern'
  | 'pearlClam'
  | 'sunkenAnchor'
  | 'amphoraUrn'
  | 'crystalCyan'
  | 'crystalAmethyst'
  | 'volcanoVent'
  | 'ancientPillar'
  | 'ancientArch'
  | 'pagodaMini'
  | 'brainCoral'
  | 'staghornCoral'
  | 'pipeOrganCoral'
  | 'mushroomCoral'
  | 'conchShell'
  | 'spiralShell'
  | 'marimoBall'
  | 'pebbleCluster';

export type FloraKind =
  | 'giantKelp'
  | 'vallisneria'
  | 'redLudwigia'
  | 'seaFanMagenta'
  | 'seaFanGold'
  | 'anemoneCyan'
  | 'anemoneMagenta'
  | 'anemoneCoral'
  | 'javaFern'
  | 'hairgrass'
  | 'glowMushroom'
  | 'bonsaiTreeAncient'
  | 'seiryuStone'
  | 'lavaRockCluster'
  | 'dwarfHairgrassCarpet'
  | 'monteCarloCarpet'
  | 'anubiasNana'
  | 'hygrophilaBush'
  | 'rotalaBush'
  | 'javaMossStone';

export type HardscapeKind =
  | 'bonsaiDriftwood'
  | 'driftwoodLog'
  | 'basaltSpire'
  | 'layeredRock'
  | 'mossyBoulder';

export type DecorItemKind = SpriteKind | FloraKind | HardscapeKind;

export interface DecorPlacement {
  id: string;
  kind: DecorItemKind;
  x: number; // virtual pixel x (0..480)
  y: number; // virtual pixel y (base anchor on substrate/rock)
  scale?: number; // integer 1 or 2, or height multiplier for plants
  height?: number; // for kelp / vallisneria / ludwigia / seaFan
  spread?: number; // horizontal width for carpet plants
  flipX?: boolean;
  seed?: number;
  layer?: 'back' | 'mid' | 'front';
  interactive?: boolean;
  label?: string;
}

export interface SubstrateProfile {
  /** Base sand height profile across 0..480 */
  heights: number[];
  /** Terraced background mound heights */
  backHeights: number[];
  /** Sand palette variant */
  sandStyle: 'coralGold' | 'riverDark' | 'obsidianSpark' | 'natureAquasoil';
  /** Distant backdrop silhouette style */
  backdropStyle: 'temple' | 'nature' | 'reef';
}

export interface AquascapePreset {
  id: PresetId;
  name: string;
  subtitle: string;
  description: string;
  defaultLighting: Exclude<LightingMode, 'auto'>;
  sandStyle: 'coralGold' | 'riverDark' | 'obsidianSpark' | 'natureAquasoil';
  backdropStyle: 'temple' | 'nature' | 'reef';
  placements: DecorPlacement[];
  moundControlPoints: Array<{ x: number; y: number }>;
  backMoundControlPoints: Array<{ x: number; y: number }>;
}

export interface InteractiveStates {
  chestOpen: boolean;
  clamOpen: boolean;
  lanternLit: boolean;
  volcanoBoost: number; // 0..1 decays over time or toggled high
  crystalPulse: number; // 0..1 resonance wave
  runesBoost: number; // 0..1 glow boost
  helmetBubbles: number; // 0..1 burst timer
}

export interface Bubble {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: 1 | 2 | 3;
  wobblePhase: number;
  wobbleSpeed: number;
  tint: 'cyan' | 'silver' | 'gold' | 'violet';
  age: number;
}

export interface Spore {
  x: number;
  y: number;
  vx: number;
  vy: number;
  phase: number;
  color: string;
  glowColor: string;
  size: 1 | 2;
}

export interface SurfaceSplash {
  x: number;
  y: number;
  age: number;
  maxAge: number;
  radius: number;
}

export interface LightPulse {
  x: number;
  y: number;
  radius: number;
  maxRadius: number;
  color: string;
  alpha: number;
}

export interface AquariumSettings {
  lighting: LightingMode;
  currentStrength: number; // 0..100
  bubbleDensity: number; // 0..100
  causticsEnabled: boolean;
  godRaysEnabled: boolean;
  bioluminescenceBoost: number; // 0..100
  pixelGridOverlay: boolean;
  paused: boolean;
}

export interface PlaceableBrush {
  kind: DecorItemKind;
  name: string;
  category: 'ornament' | 'coral' | 'plant' | 'rock';
  defaultHeight?: number;
  description: string;
}

export interface HoverTarget {
  id: string;
  kind: DecorItemKind;
  label: string;
  hint: string;
  x: number;
  y: number;
}

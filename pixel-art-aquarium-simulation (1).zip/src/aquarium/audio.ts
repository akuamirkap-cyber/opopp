export class UnderwaterAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private murmurGain: GainNode | null = null;
  private enabled = false;
  private bubbleTimer: number | null = null;
  private volume = 0.45;

  public isEnabled(): boolean {
    return this.enabled;
  }

  public getVolume(): number {
    return this.volume;
  }

  public setVolume(v: number): void {
    this.volume = Math.max(0, Math.min(1, v));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(
        this.enabled ? this.volume * 0.65 : 0,
        this.ctx.currentTime,
        0.12
      );
    }
  }

  public async toggle(): Promise<boolean> {
    if (this.enabled) {
      this.stop();
      return false;
    } else {
      await this.start();
      return true;
    }
  }

  public async start(): Promise<void> {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      this.ctx = new AudioCtx();
      this.setupMurmur();
    }
    if (this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
    this.enabled = true;
    if (this.masterGain) {
      this.masterGain.gain.setTargetAtTime(
        this.volume * 0.65,
        this.ctx.currentTime,
        0.25
      );
    }
    this.scheduleBubbleSound();
  }

  public stop(): void {
    this.enabled = false;
    if (this.bubbleTimer !== null) {
      window.clearTimeout(this.bubbleTimer);
      this.bubbleTimer = null;
    }
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.15);
    }
  }

  private setupMurmur(): void {
    if (!this.ctx) return;
    this.masterGain = this.ctx.createGain();
    this.masterGain.gain.value = 0;
    this.masterGain.connect(this.ctx.destination);

    // Create 3-second seamless brown-pink noise loop for calm water ambience
    const bufferSize = this.ctx.sampleRate * 3;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let lastOut = 0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      data[i] = (lastOut + 0.025 * white) / 1.025;
      lastOut = data[i];
      data[i] *= 2.8;
    }
    // Crossfade start/end to avoid loop clicks
    const fadeLen = Math.floor(this.ctx.sampleRate * 0.15);
    for (let i = 0; i < fadeLen; i++) {
      const k = i / fadeLen;
      data[i] = data[i] * k + data[bufferSize - fadeLen + i] * (1 - k);
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    noise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 260;
    filter.Q.value = 0.85;

    this.murmurGain = this.ctx.createGain();
    this.murmurGain.gain.value = 0.22;

    noise.connect(filter);
    filter.connect(this.murmurGain);
    this.murmurGain.connect(this.masterGain);
    noise.start();
  }

  private scheduleBubbleSound(): void {
    if (!this.enabled) return;
    const delay = 450 + Math.random() * 1450;
    this.bubbleTimer = window.setTimeout(() => {
      if (this.enabled) {
        this.playBubblePop(0.35 + Math.random() * 0.4);
        this.scheduleBubbleSound();
      }
    }, delay);
  }

  public playBubblePop(intensity = 0.5): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    const baseFreq = 290 + Math.random() * 380;
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 2.15, now + 0.085);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.08 * intensity, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.095);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.11);
  }

  public playCrystalChime(pitchIndex = 0): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const pentatonic = [523.25, 587.33, 659.25, 783.99, 987.77, 1046.5];
    const freq = pentatonic[Math.abs(pitchIndex) % pentatonic.length];
    const now = this.ctx.currentTime;

    [1, 1.5].forEach((mult, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = idx === 0 ? 'sine' : 'triangle';
      osc.frequency.setValueAtTime(freq * mult, now);

      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(idx === 0 ? 0.14 : 0.05, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.15);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 1.2);
    });
  }

  public playChestCreak(opening: boolean): void {
    if (!this.enabled || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(opening ? 150 : 220, now);
    osc.frequency.exponentialRampToValueAtTime(opening ? 320 : 120, now + 0.22);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.11, now + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.25);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.26);

    if (opening) {
      window.setTimeout(() => this.playCrystalChime(3), 90);
      window.setTimeout(() => this.playCrystalChime(5), 180);
    }
  }

  public dispose(): void {
    this.stop();
    if (this.ctx) {
      this.ctx.close().catch(() => {});
      this.ctx = null;
    }
  }
}

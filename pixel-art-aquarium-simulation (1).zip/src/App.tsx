import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import {
  type AquariumSettings,
  type DecorPlacement,
  type InteractiveStates,
  type LightingMode,
  type PlaceableBrush,
  type PresetId,
} from './aquarium/types';
import { AQUASCAPE_PRESETS, buildSubstrateProfile } from './aquarium/presets';
import { PixelAquariumEngine } from './aquarium/engine';
import { UnderwaterAudioEngine } from './aquarium/audio';
import { AquariumCanvas } from './components/AquariumCanvas';
import { ControlDock } from './components/ControlDock';
import {
  CameraPixelIcon,
  CoralIcon,
  CrystalIcon,
  EyePixelIcon,
  MoonPixelIcon,
  SoundPixelIcon,
  SunPixelIcon,
  SunsetPixelIcon,
  WavePixelIcon,
} from './components/PixelIcons';

export default function App() {
  const [activePreset, setActivePreset] = useState<PresetId>('atlantis');
  const [customPlacements, setCustomPlacements] = useState<DecorPlacement[]>([]);
  const [settings, setSettings] = useState<AquariumSettings>({
    lighting: 'day',
    currentStrength: 42,
    bubbleDensity: 65,
    causticsEnabled: true,
    godRaysEnabled: true,
    bioluminescenceBoost: 72,
    pixelGridOverlay: false,
    paused: false,
  });

  const [selectedBrush, setSelectedBrush] = useState<PlaceableBrush | null>(
    null
  );
  const [zenMode, setZenMode] = useState(false);
  const [audioEnabled, setAudioEnabled] = useState(false);
  const [stats, setStats] = useState({ bubbles: 24, spores: 64, items: 46 });
  const [feedback, setFeedback] = useState<string>('Siap dijelajahi · Gerakkan kursor di air');
  const [interactiveStates, setInteractiveStates] = useState<InteractiveStates>({
    chestOpen: true,
    clamOpen: true,
    lanternLit: true,
    volcanoBoost: 0.4,
    crystalPulse: 0,
    runesBoost: 0.3,
    helmetBubbles: 0,
  });

  const preset = AQUASCAPE_PRESETS[activePreset];
  const substrate = useMemo(() => buildSubstrateProfile(preset), [preset]);
  const allPlacements = useMemo(
    () => [...preset.placements, ...customPlacements],
    [preset, customPlacements]
  );

  const engineRef = useRef<PixelAquariumEngine | null>(null);
  if (!engineRef.current && typeof document !== 'undefined') {
    engineRef.current = new PixelAquariumEngine(substrate, allPlacements);
  }

  const audioRef = useRef<UnderwaterAudioEngine | null>(null);
  if (!audioRef.current && typeof window !== 'undefined') {
    audioRef.current = new UnderwaterAudioEngine();
  }

  useEffect(() => {
    return () => {
      audioRef.current?.dispose();
    };
  }, []);

  // Sync placements to engine whenever custom additions change
  useEffect(() => {
    engineRef.current?.updatePlacements(allPlacements);
  }, [allPlacements]);

  const handleSelectPreset = useCallback((id: PresetId) => {
    const nextPreset = AQUASCAPE_PRESETS[id];
    const nextSubstrate = buildSubstrateProfile(nextPreset);
    setActivePreset(id);
    setCustomPlacements([]);
    setSelectedBrush(null);
    setSettings((prev) => ({ ...prev, lighting: nextPreset.defaultLighting }));
    engineRef.current?.setScene(nextSubstrate, nextPreset.placements);
    setFeedback(`Tema beralih ke ${nextPreset.name}`);
  }, []);

  const handleChangeSettings = useCallback((patch: Partial<AquariumSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const handlePlaceDecoration = useCallback((placement: DecorPlacement) => {
    setCustomPlacements((prev) => [...prev, placement]);
  }, []);

  const handleUndoPlacement = useCallback(() => {
    setCustomPlacements((prev) => prev.slice(0, -1));
    setFeedback('Hiasan terakhir dihapus');
  }, []);

  const handleResetLayout = useCallback(() => {
    setCustomPlacements([]);
    setSelectedBrush(null);
    engineRef.current?.setScene(substrate, preset.placements);
    setFeedback('Tata letak dikembalikan ke setelan awal');
  }, [substrate, preset.placements]);

  const handleStatsTick = useCallback(
    (nextStats: { bubbles: number; spores: number; items: number }) => {
      setStats(nextStats);
      if (engineRef.current) {
        setInteractiveStates(engineRef.current.getInteractiveStates());
      }
    },
    []
  );

  const handleToggleAudio = useCallback(async () => {
    if (!audioRef.current) return;
    const active = await audioRef.current.toggle();
    setAudioEnabled(active);
    setFeedback(active ? 'Suara ambient bawah air aktif' : 'Suara dimatikan');
  }, []);

  const handleCapturePng = useCallback(() => {
    const engine = engineRef.current;
    if (!engine) return;
    const url = engine.exportPngDataUrl();
    const a = document.createElement('a');
    a.href = url;
    a.download = `akuarium-piksel-18bit-${activePreset}.png`;
    a.click();
    setFeedback('Gambar piksel 18-bit HD (1440×810) berhasil diunduh!');
  }, [activePreset]);

  const handleQuickTrigger = useCallback(
    (action: 'chest' | 'clam' | 'lantern' | 'volcano' | 'crystal') => {
      const engine = engineRef.current;
      if (!engine) return;
      const findByKind = (kinds: string[]) =>
        allPlacements.find((p) => kinds.includes(p.kind));

      if (action === 'chest') {
        const item = findByKind(['treasureChest']);
        if (item) {
          const out = engine.triggerInteraction({
            id: item.id,
            kind: item.kind,
            label: 'Peti Harta Karun',
            hint: '',
            x: item.x,
            y: item.y,
          });
          audioRef.current?.playChestCreak(out.sound === 'chest-open');
          setFeedback('Peti Harta Karun diubah');
        }
      } else if (action === 'clam') {
        const item = findByKind(['pearlClam']);
        if (item) {
          engine.triggerInteraction({
            id: item.id,
            kind: item.kind,
            label: 'Kerang Mutiara',
            hint: '',
            x: item.x,
            y: item.y,
          });
          audioRef.current?.playCrystalChime(4);
          setFeedback('Cangkang Kerang Mutiara digerakkan');
        }
      } else if (action === 'lantern') {
        const item = findByKind(['stoneLantern']);
        if (item) {
          engine.triggerInteraction({
            id: item.id,
            kind: item.kind,
            label: 'Lentera Batu',
            hint: '',
            x: item.x,
            y: item.y,
          });
          audioRef.current?.playCrystalChime(1);
          setFeedback('Cahaya Lentera Batu diubah');
        }
      } else if (action === 'volcano') {
        const item = findByKind(['volcanoVent']);
        if (item) {
          engine.triggerInteraction({
            id: item.id,
            kind: item.kind,
            label: 'Kawah Gelembung',
            hint: '',
            x: item.x,
            y: item.y,
          });
          audioRef.current?.playBubblePop(1);
          setFeedback('Semburan gelembung kawah aktif!');
        }
      } else if (action === 'crystal') {
        const item = findByKind(['crystalCyan', 'crystalAmethyst']);
        if (item) {
          engine.triggerInteraction({
            id: item.id,
            kind: item.kind,
            label: 'Kristal',
            hint: '',
            x: item.x,
            y: item.y,
          });
          audioRef.current?.playCrystalChime(3);
          setFeedback('Resonansi cahaya kristal berdenyut');
        }
      }
      setInteractiveStates(engine.getInteractiveStates());
    },
    [allPlacements]
  );

  // Keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (e.key === 'h' || e.key === 'H') {
        setZenMode((v) => !v);
      } else if (e.key === 'Escape') {
        if (selectedBrush) setSelectedBrush(null);
        else if (zenMode) setZenMode(false);
      } else if (e.key === ' ') {
        e.preventDefault();
        setSettings((p) => ({ ...p, paused: !p.paused }));
      } else if (e.key === 'm' || e.key === 'M') {
        handleToggleAudio();
      } else if (e.key === '1') {
        handleChangeSettings({ lighting: 'day' });
      } else if (e.key === '2') {
        handleChangeSettings({ lighting: 'sunlight' });
      } else if (e.key === '3') {
        handleChangeSettings({ lighting: 'golden' });
      } else if (e.key === '4') {
        handleChangeSettings({ lighting: 'night' });
      } else if (e.key === '5') {
        handleChangeSettings({ lighting: 'abyss' });
      } else if (e.key === '6') {
        handleChangeSettings({ lighting: 'auto' });
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [selectedBrush, zenMode, handleToggleAudio, handleChangeSettings]);

  const lightingQuickPills: Array<{
    id: LightingMode;
    label: string;
    icon: ReactNode;
  }> = [
    { id: 'day', label: 'Siang', icon: <SunPixelIcon className="h-3.5 w-3.5 text-amber-300" /> },
    { id: 'sunlight', label: 'Terang', icon: <SunPixelIcon className="h-3.5 w-3.5 text-lime-300" /> },
    { id: 'golden', label: 'Senja', icon: <SunsetPixelIcon className="h-3.5 w-3.5 text-orange-300" /> },
    { id: 'night', label: 'Malam', icon: <MoonPixelIcon className="h-3.5 w-3.5 text-cyan-300" /> },
    { id: 'abyss', label: 'Palung', icon: <CrystalIcon className="h-3.5 w-3.5 text-purple-300" /> },
    { id: 'auto', label: 'Auto', icon: <WavePixelIcon className="h-3.5 w-3.5 text-emerald-300" /> },
  ];

  // Dynamic subtle LED hood accent matching active lighting
  const rimAccentClass =
    settings.lighting === 'golden'
      ? 'shadow-[0_0_55px_-12px_rgba(251,146,60,0.42)] border-amber-400/35'
      : settings.lighting === 'sunlight'
      ? 'shadow-[0_0_65px_-10px_rgba(163,230,53,0.5)] border-lime-400/40'
      : settings.lighting === 'night' || settings.lighting === 'abyss'
      ? 'shadow-[0_0_60px_-10px_rgba(34,211,238,0.45)] border-cyan-400/40'
      : 'shadow-[0_0_60px_-10px_rgba(45,212,191,0.38)] border-cyan-400/35';

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-[#040811] text-slate-100">
      {/* Subtle underwater ambient radial glow behind tank */}
      <div
        className="pointer-events-none fixed inset-0 opacity-60"
        style={{
          background:
            'radial-gradient(circle at 50% 35%, rgba(14, 116, 144, 0.22), rgba(4, 8, 17, 0.96) 72%)',
        }}
      />

      <main
        className={`relative z-10 mx-auto flex min-h-screen w-full flex-col items-center justify-center ${
          zenMode ? 'max-w-none p-2 sm:p-4' : 'max-w-6xl gap-3 px-3 py-4 sm:px-5 sm:py-5'
        }`}
      >
        {/* TOP GALLERY HEADER (Hidden in Zen Mode) */}
        {!zenMode && (
          <header className="flex w-full flex-wrap items-center justify-between gap-2.5 border border-cyan-500/20 bg-[#071121]/85 px-3.5 py-2.5 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center border border-cyan-400/45 bg-cyan-950/70 shadow-[inset_0_0_12px_rgba(34,211,238,0.25)]">
                <CoralIcon className="h-5 w-5 text-cyan-300" />
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="font-pixel-title text-sm tracking-wide text-cyan-100 sm:text-base">
                    AKUARIUM PIKSEL 18-BIT
                  </h1>
                  <span className="border border-emerald-400/45 bg-emerald-500/15 px-2 py-0.5 font-pixel-title text-[9px] tracking-wider text-emerald-200">
                    TANPA IKAN · FULL HIASAN
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  {preset.name} — {preset.subtitle}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-1.5">
              {/* Quick Lighting Mode Selector */}
              <div className="mr-1 hidden items-center gap-1 border border-slate-800 bg-slate-950/70 p-0.5 lg:flex">
                {lightingQuickPills.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => handleChangeSettings({ lighting: opt.id })}
                    className={`flex items-center gap-1 px-2 py-1 text-[11px] transition ${
                      settings.lighting === opt.id
                        ? 'bg-cyan-500/25 text-cyan-100'
                        : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {opt.icon}
                    <span>{opt.label}</span>
                  </button>
                ))}
              </div>

              <button
                type="button"
                onClick={handleToggleAudio}
                title="Suara Ambient Bawah Air (M)"
                className={`flex items-center gap-1.5 border px-2.5 py-1.5 text-xs transition ${
                  audioEnabled
                    ? 'border-cyan-400/65 bg-cyan-500/20 text-cyan-100'
                    : 'border-slate-700 bg-slate-900/75 text-slate-300 hover:border-cyan-400/45'
                }`}
              >
                <SoundPixelIcon className="h-3.5 w-3.5" muted={!audioEnabled} />
                <span className="hidden sm:inline">
                  {audioEnabled ? 'Suara Aktif' : 'Suara'}
                </span>
              </button>

              <button
                type="button"
                onClick={() =>
                  handleChangeSettings({ paused: !settings.paused })
                }
                title="Jeda / Jalankan Simulasi (Spasi)"
                className={`border px-2.5 py-1.5 text-xs transition ${
                  settings.paused
                    ? 'border-amber-400/70 bg-amber-500/20 text-amber-200'
                    : 'border-slate-700 bg-slate-900/75 text-slate-300 hover:border-cyan-400/45'
                }`}
              >
                {settings.paused ? 'Lanjutkan' : 'Jeda'}
              </button>

              <button
                type="button"
                onClick={handleCapturePng}
                title="Unduh Gambar PNG Piksel HD"
                className="flex items-center gap-1.5 border border-slate-700 bg-slate-900/75 px-2.5 py-1.5 text-xs text-slate-200 transition hover:border-cyan-400/50 hover:text-cyan-100"
              >
                <CameraPixelIcon className="h-3.5 w-3.5 text-cyan-300" />
                <span className="hidden md:inline">Simpan PNG</span>
              </button>

              <button
                type="button"
                onClick={() => setZenMode(true)}
                title="Mode Zen Layar Penuh (H)"
                className="flex items-center gap-1.5 border border-purple-400/50 bg-purple-500/15 px-2.5 py-1.5 text-xs text-purple-100 transition hover:bg-purple-500/25"
              >
                <EyePixelIcon className="h-3.5 w-3.5 text-purple-300" />
                <span className="hidden sm:inline">Mode Zen</span>
              </button>
            </div>
          </header>
        )}

        {/* MUSEUM GLASS AQUARIUM TANK FRAME */}
        <section
          className={`relative w-full overflow-hidden border-2 bg-[#030b17] transition-shadow duration-500 ${rimAccentClass} ${
            zenMode ? 'max-w-[1440px]' : ''
          }`}
        >
          {/* Top LED Aquarium Hood Bar */}
          <div className="flex items-center justify-between border-b border-cyan-500/25 bg-gradient-to-r from-[#071526] via-[#0d2842] to-[#071526] px-3 py-1">
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
              <span className="font-pixel-title text-[9px] tracking-widest text-cyan-200/80">
                480×270 · 18-BIT PIXEL AQUASCAPE
              </span>
            </div>
            <div className="flex items-center gap-3 text-[11px] text-cyan-200/75">
              <span>{stats.items} Elemen Terumbu & Hiasan</span>
              <span className="hidden sm:inline">·</span>
              <span className="hidden sm:inline">
                {stats.bubbles} Gelembung
              </span>
              <span className="hidden md:inline">·</span>
              <span className="hidden md:inline">
                {stats.spores} Spora Cahaya
              </span>
            </div>
          </div>

          {/* 18-Bit Pixel Simulation Canvas */}
          <AquariumCanvas
            engineRef={engineRef}
            audioRef={audioRef}
            settings={settings}
            selectedBrush={selectedBrush}
            onPlaceDecoration={handlePlaceDecoration}
            onCancelBrush={() => setSelectedBrush(null)}
            onStatsTick={handleStatsTick}
            onInteractionFeedback={setFeedback}
          />

          {/* Bottom Tank Brass Plaque & Status Strip */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-cyan-500/20 bg-[#050e1c] px-3 py-1 text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="font-pixel-title text-[9px] text-emerald-300">
                STATUS:
              </span>
              <span className="text-cyan-100/90">{feedback}</span>
            </div>
            <div className="flex items-center gap-3 text-[10px] text-slate-400">
              <span>Klik ornamen untuk interaksi · Seret air untuk arus</span>
              {zenMode && (
                <button
                  type="button"
                  onClick={() => setZenMode(false)}
                  className="border border-cyan-400/50 bg-cyan-500/20 px-2 py-0.5 font-pixel-title text-[9px] text-cyan-100 hover:bg-cyan-500/30"
                >
                  KELUAR ZEN (H)
                </button>
              )}
            </div>
          </div>
        </section>

        {/* STUDIO CONTROLS DOCK (Hidden in Zen Mode) */}
        {!zenMode && (
          <ControlDock
            activePreset={activePreset}
            onSelectPreset={handleSelectPreset}
            settings={settings}
            onChangeSettings={handleChangeSettings}
            selectedBrush={selectedBrush}
            onSelectBrush={setSelectedBrush}
            onUndoPlacement={handleUndoPlacement}
            onResetLayout={handleResetLayout}
            canUndo={customPlacements.length > 0}
            customCount={customPlacements.length}
            interactiveStates={interactiveStates}
            onQuickTrigger={handleQuickTrigger}
          />
        )}
      </main>
    </div>
  );
}

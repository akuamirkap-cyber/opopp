import React from 'react';

interface IconProps {
  className?: string;
}

export const CoralIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="7" y="9" width="2" height="6" fill="currentColor" />
    <rect x="4" y="6" width="2" height="4" fill="currentColor" />
    <rect x="5" y="9" width="3" height="2" fill="currentColor" />
    <rect x="10" y="5" width="2" height="5" fill="currentColor" />
    <rect x="8" y="8" width="3" height="2" fill="currentColor" />
    <rect x="6" y="3" width="2" height="5" fill="currentColor" />
    <rect x="2" y="4" width="2" height="3" fill="currentColor" />
    <rect x="12" y="3" width="2" height="3" fill="currentColor" />
    <rect x="5" y="14" width="6" height="1" fill="currentColor" opacity="0.7" />
  </svg>
);

export const CrystalIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="7" y="2" width="2" height="2" fill="#ccfbff" />
    <rect x="6" y="4" width="4" height="3" fill="#67e8f9" />
    <rect x="5" y="7" width="6" height="5" fill="#06b6d4" />
    <rect x="2" y="8" width="2" height="4" fill="#67e8f9" />
    <rect x="12" y="7" width="2" height="5" fill="#67e8f9" />
    <rect x="3" y="12" width="10" height="2" fill="#0e7490" />
  </svg>
);

export const SunPixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="6" y="5" width="4" height="6" fill="currentColor" />
    <rect x="5" y="6" width="6" height="4" fill="currentColor" />
    <rect x="7" y="1" width="2" height="2" fill="currentColor" />
    <rect x="7" y="13" width="2" height="2" fill="currentColor" />
    <rect x="1" y="7" width="2" height="2" fill="currentColor" />
    <rect x="13" y="7" width="2" height="2" fill="currentColor" />
    <rect x="3" y="3" width="2" height="2" fill="currentColor" />
    <rect x="11" y="3" width="2" height="2" fill="currentColor" />
    <rect x="3" y="11" width="2" height="2" fill="currentColor" />
    <rect x="11" y="11" width="2" height="2" fill="currentColor" />
  </svg>
);

export const SunsetPixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="5" y="4" width="6" height="4" fill="currentColor" />
    <rect x="4" y="6" width="8" height="3" fill="currentColor" />
    <rect x="7" y="1" width="2" height="2" fill="currentColor" />
    <rect x="2" y="5" width="2" height="1" fill="currentColor" />
    <rect x="12" y="5" width="2" height="1" fill="currentColor" />
    <rect x="2" y="10" width="12" height="2" fill="currentColor" opacity="0.8" />
    <rect x="4" y="13" width="8" height="1" fill="currentColor" opacity="0.55" />
  </svg>
);

export const MoonPixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="6" y="2" width="4" height="2" fill="currentColor" />
    <rect x="4" y="4" width="4" height="2" fill="currentColor" />
    <rect x="3" y="6" width="3" height="4" fill="currentColor" />
    <rect x="4" y="10" width="4" height="2" fill="currentColor" />
    <rect x="6" y="12" width="6" height="2" fill="currentColor" />
    <rect x="10" y="10" width="3" height="2" fill="currentColor" />
    <rect x="11" y="4" width="2" height="2" fill="currentColor" opacity="0.7" />
  </svg>
);

export const BubblePixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="4" y="2" width="4" height="1" fill="currentColor" />
    <rect x="3" y="3" width="1" height="4" fill="currentColor" />
    <rect x="8" y="3" width="1" height="4" fill="currentColor" />
    <rect x="4" y="7" width="4" height="1" fill="currentColor" />
    <rect x="5" y="4" width="1" height="1" fill="currentColor" />
    <rect x="10" y="7" width="3" height="1" fill="currentColor" />
    <rect x="9" y="8" width="1" height="2" fill="currentColor" />
    <rect x="13" y="8" width="1" height="2" fill="currentColor" />
    <rect x="10" y="10" width="3" height="1" fill="currentColor" />
    <rect x="5" y="11" width="2" height="2" fill="currentColor" />
  </svg>
);

export const SoundPixelIcon: React.FC<IconProps & { muted?: boolean }> = ({
  className = 'w-4 h-4',
  muted = false,
}) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="2" y="6" width="3" height="4" fill="currentColor" />
    <rect x="5" y="4" width="2" height="8" fill="currentColor" />
    <rect x="7" y="2" width="2" height="12" fill="currentColor" />
    {muted ? (
      <>
        <rect x="11" y="5" width="1" height="2" fill="#f43f5e" />
        <rect x="13" y="5" width="1" height="2" fill="#f43f5e" />
        <rect x="12" y="7" width="1" height="2" fill="#f43f5e" />
        <rect x="11" y="9" width="1" height="2" fill="#f43f5e" />
        <rect x="13" y="9" width="1" height="2" fill="#f43f5e" />
      </>
    ) : (
      <>
        <rect x="11" y="6" width="1" height="4" fill="currentColor" />
        <rect x="13" y="4" width="1" height="8" fill="currentColor" />
      </>
    )}
  </svg>
);

export const CameraPixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="5" y="3" width="6" height="2" fill="currentColor" />
    <rect x="2" y="5" width="12" height="8" fill="currentColor" />
    <rect x="6" y="7" width="4" height="4" fill="#082f49" />
    <rect x="7" y="8" width="2" height="2" fill="#67e8f9" />
  </svg>
);

export const EyePixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="5" y="4" width="6" height="1" fill="currentColor" />
    <rect x="3" y="5" width="2" height="1" fill="currentColor" />
    <rect x="11" y="5" width="2" height="1" fill="currentColor" />
    <rect x="1" y="6" width="2" height="4" fill="currentColor" />
    <rect x="13" y="6" width="2" height="4" fill="currentColor" />
    <rect x="3" y="10" width="2" height="1" fill="currentColor" />
    <rect x="11" y="10" width="2" height="1" fill="currentColor" />
    <rect x="5" y="11" width="6" height="1" fill="currentColor" />
    <rect x="6" y="6" width="4" height="4" fill="currentColor" />
    <rect x="7" y="7" width="2" height="2" fill="#082f49" />
  </svg>
);

export const ShellPixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="5" y="3" width="6" height="2" fill="currentColor" />
    <rect x="3" y="5" width="10" height="4" fill="currentColor" />
    <rect x="4" y="9" width="8" height="2" fill="currentColor" />
    <rect x="6" y="11" width="4" height="2" fill="currentColor" />
    <rect x="7" y="4" width="2" height="5" fill="#082f49" opacity="0.35" />
  </svg>
);

export const WavePixelIcon: React.FC<IconProps> = ({ className = 'w-4 h-4' }) => (
  <svg
    viewBox="0 0 16 16"
    fill="none"
    shapeRendering="crispEdges"
    className={className}
  >
    <rect x="2" y="5" width="3" height="2" fill="currentColor" />
    <rect x="5" y="4" width="3" height="2" fill="currentColor" />
    <rect x="8" y="6" width="3" height="2" fill="currentColor" />
    <rect x="11" y="5" width="3" height="2" fill="currentColor" />
    <rect x="2" y="10" width="3" height="2" fill="currentColor" opacity="0.7" />
    <rect x="5" y="9" width="3" height="2" fill="currentColor" opacity="0.7" />
    <rect x="8" y="11" width="3" height="2" fill="currentColor" opacity="0.7" />
    <rect x="11" y="10" width="3" height="2" fill="currentColor" opacity="0.7" />
  </svg>
);

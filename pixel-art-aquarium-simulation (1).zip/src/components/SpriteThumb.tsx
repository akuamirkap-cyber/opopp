import React, { useEffect, useRef } from 'react';
import type { DecorItemKind } from '../aquarium/types';
import { getSpriteSet, isSpriteKind } from '../aquarium/sprites';
import { FLORA_RAMPS } from '../aquarium/palettes';

interface SpriteThumbProps {
  kind: DecorItemKind;
}

export const SpriteThumb: React.FC<SpriteThumbProps> = ({ kind }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.imageSmoothingEnabled = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (isSpriteKind(kind)) {
      const sprites = getSpriteSet();
      const map: Record<string, HTMLCanvasElement> = {
        treasureChest: sprites.treasureChestOpen.canvas,
        diverHelmet: sprites.diverHelmet.canvas,
        stoneLantern: sprites.stoneLanternLit.canvas,
        pearlClam: sprites.pearlClamOpen.canvas,
        sunkenAnchor: sprites.sunkenAnchor.canvas,
        amphoraUrn: sprites.amphoraUrn.canvas,
        crystalCyan: sprites.crystalCyan.canvas,
        crystalAmethyst: sprites.crystalAmethyst.canvas,
        volcanoVent: sprites.volcanoVent.canvas,
        ancientPillar: sprites.ancientPillar.canvas,
        ancientArch: sprites.ancientArch.canvas,
        pagodaMini: sprites.pagodaMini.canvas,
        brainCoral: sprites.brainCoral.canvas,
        staghornCoral: sprites.staghornCoral.canvas,
        pipeOrganCoral: sprites.pipeOrganCoral.canvas,
        mushroomCoral: sprites.mushroomCoral.canvas,
        conchShell: sprites.conchShell.canvas,
        spiralShell: sprites.spiralShell.canvas,
        marimoBall: sprites.marimoBall.canvas,
        pebbleCluster: sprites.pebbleCluster.canvas,
      };
      const src = map[kind];
      if (src) {
        const scale = Math.min(
          22 / src.width,
          22 / src.height
        );
        const dw = Math.max(8, Math.round(src.width * scale));
        const dh = Math.max(8, Math.round(src.height * scale));
        const dx = Math.floor((24 - dw) / 2);
        const dy = Math.floor((24 - dh) / 2);
        ctx.drawImage(src, 0, 0, src.width, src.height, dx, dy, dw, dh);
      }
      return;
    }

    // Simple iconic pixel thumbnail for procedural flora & hardscape
    if (kind === 'giantKelp') {
      const r = FLORA_RAMPS.kelp;
      ctx.fillStyle = r[2];
      ctx.fillRect(11, 3, 2, 19);
      ctx.fillStyle = r[1];
      ctx.fillRect(7, 6, 4, 3);
      ctx.fillRect(13, 10, 4, 3);
      ctx.fillRect(7, 14, 4, 3);
      ctx.fillStyle = r[0];
      ctx.fillRect(9, 6, 2, 1);
      ctx.fillRect(13, 10, 2, 1);
    } else if (kind === 'vallisneria') {
      const r = FLORA_RAMPS.vallisneria;
      ctx.fillStyle = r[2];
      ctx.fillRect(7, 6, 2, 16);
      ctx.fillRect(11, 3, 2, 19);
      ctx.fillRect(15, 7, 2, 15);
      ctx.fillStyle = r[0];
      ctx.fillRect(11, 3, 1, 5);
    } else if (kind === 'redLudwigia') {
      const r = FLORA_RAMPS.ludwigia;
      ctx.fillStyle = r[3];
      ctx.fillRect(11, 5, 2, 17);
      ctx.fillStyle = r[1];
      ctx.fillRect(7, 7, 4, 3);
      ctx.fillRect(13, 7, 4, 3);
      ctx.fillRect(7, 13, 4, 3);
      ctx.fillRect(13, 13, 4, 3);
    } else if (kind === 'seaFanMagenta' || kind === 'seaFanGold') {
      const r = kind === 'seaFanMagenta' ? FLORA_RAMPS.seaFanMagenta : FLORA_RAMPS.seaFanGold;
      ctx.fillStyle = r[3];
      ctx.fillRect(11, 14, 2, 8);
      ctx.fillStyle = r[2];
      ctx.fillRect(7, 9, 10, 2);
      ctx.fillRect(6, 5, 2, 5);
      ctx.fillRect(11, 4, 2, 10);
      ctx.fillRect(16, 5, 2, 5);
      ctx.fillStyle = r[0];
      ctx.fillRect(6, 4, 2, 1);
      ctx.fillRect(11, 3, 2, 1);
      ctx.fillRect(16, 4, 2, 1);
    } else if (kind === 'anemoneCyan' || kind === 'anemoneMagenta') {
      const r = kind === 'anemoneCyan' ? FLORA_RAMPS.anemoneCyan : FLORA_RAMPS.anemoneMagenta;
      ctx.fillStyle = r[3];
      ctx.fillRect(6, 17, 12, 4);
      ctx.fillStyle = r[2];
      ctx.fillRect(7, 10, 2, 7);
      ctx.fillRect(11, 7, 2, 10);
      ctx.fillRect(15, 10, 2, 7);
      ctx.fillStyle = r[0];
      ctx.fillRect(7, 8, 2, 2);
      ctx.fillRect(11, 5, 2, 2);
      ctx.fillRect(15, 8, 2, 2);
    } else if (kind === 'javaFern' || kind === 'hairgrass') {
      const r = FLORA_RAMPS.javaFern;
      ctx.fillStyle = r[2];
      ctx.fillRect(5, 14, 14, 6);
      ctx.fillStyle = r[1];
      ctx.fillRect(7, 9, 2, 8);
      ctx.fillRect(11, 7, 2, 10);
      ctx.fillRect(15, 10, 2, 7);
      ctx.fillStyle = r[0];
      ctx.fillRect(11, 6, 2, 2);
    } else if (kind === 'glowMushroom') {
      const r = FLORA_RAMPS.glowMushroom;
      ctx.fillStyle = r[3];
      ctx.fillRect(8, 14, 1, 7);
      ctx.fillRect(13, 10, 2, 11);
      ctx.fillStyle = r[1];
      ctx.fillRect(6, 12, 5, 2);
      ctx.fillRect(10, 7, 8, 3);
      ctx.fillStyle = r[0];
      ctx.fillRect(12, 6, 4, 1);
    } else if (kind === 'bonsaiDriftwood') {
      ctx.fillStyle = '#633822';
      ctx.fillRect(10, 12, 4, 10);
      ctx.fillRect(7, 10, 10, 3);
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(4, 6, 8, 5);
      ctx.fillRect(11, 4, 9, 5);
      ctx.fillStyle = '#a3e635';
      ctx.fillRect(5, 5, 6, 2);
      ctx.fillRect(12, 3, 7, 2);
    } else if (kind === 'bonsaiTreeAncient') {
      ctx.fillStyle = '#2a1a10';
      ctx.fillRect(5, 19, 5, 3);
      ctx.fillRect(14, 19, 5, 3);
      ctx.fillStyle = '#543722';
      ctx.fillRect(11, 8, 2, 13);
      ctx.fillRect(9, 12, 6, 2);
      ctx.fillStyle = '#7f5533';
      ctx.fillRect(11, 8, 1, 13);
      ctx.fillStyle = '#3d8c26';
      ctx.fillRect(3, 5, 9, 6);
      ctx.fillRect(13, 4, 8, 6);
      ctx.fillStyle = '#a3e635';
      ctx.fillRect(4, 4, 7, 2);
      ctx.fillRect(14, 3, 6, 2);
    } else if (kind === 'seiryuStone' || kind === 'lavaRockCluster') {
      const isSeiryu = kind === 'seiryuStone';
      const mid = isSeiryu ? '#5a6b7e' : '#3d2e26';
      const light = isSeiryu ? '#8ea4ba' : '#5f4a3c';
      const edge = isSeiryu ? '#232e3c' : '#181210';
      ctx.fillStyle = edge;
      ctx.fillRect(4, 12, 7, 9);
      ctx.fillRect(10, 8, 10, 13);
      ctx.fillRect(19, 14, 5, 7);
      ctx.fillStyle = light;
      ctx.fillRect(5, 12, 3, 4);
      ctx.fillRect(12, 9, 3, 4);
      ctx.fillStyle = mid;
      ctx.fillRect(6, 14, 4, 5);
      ctx.fillRect(13, 12, 6, 7);
      ctx.fillRect(20, 16, 3, 4);
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(6, 11, 3, 1);
      ctx.fillRect(13, 7, 4, 1);
    } else if (kind === 'javaMossStone') {
      ctx.fillStyle = '#4a5a70';
      ctx.fillRect(6, 15, 12, 5);
      ctx.fillStyle = '#8aa0b8';
      ctx.fillRect(7, 15, 5, 1);
      ctx.fillStyle = '#65a30d';
      for (let i = 0; i < 6; i++) ctx.fillRect(7 + i * 2, 11 + (i % 3), 1, 5);
      ctx.fillStyle = '#a3e635';
      for (let i = 0; i < 6; i++) ctx.fillRect(7 + i * 2, 11 + (i % 3), 1, 1);
    } else if (kind === 'dwarfHairgrassCarpet') {
      ctx.fillStyle = '#2fa84a';
      ctx.fillRect(3, 16, 18, 5);
      ctx.fillStyle = '#6ee07a';
      for (let i = 0; i < 12; i++) ctx.fillRect(3 + i * 1.5, 12 + (i % 4), 1, 5);
      ctx.fillStyle = '#c5f88a';
      for (let i = 0; i < 6; i++) ctx.fillRect(4 + i * 3, 10 + (i % 3), 1, 3);
    } else if (kind === 'monteCarloCarpet') {
      ctx.fillStyle = '#7cb518';
      ctx.fillRect(3, 15, 18, 6);
      ctx.fillStyle = '#b6e63a';
      ctx.fillRect(5, 12, 4, 4);
      ctx.fillRect(11, 11, 4, 5);
      ctx.fillRect(17, 13, 3, 4);
      ctx.fillStyle = '#e4fca0';
      ctx.fillRect(6, 11, 2, 1);
      ctx.fillRect(12, 10, 2, 1);
    } else if (kind === 'anubiasNana') {
      ctx.fillStyle = '#12622f';
      ctx.fillRect(10, 16, 4, 5);
      ctx.fillStyle = '#2e9b4a';
      ctx.fillRect(5, 10, 5, 3);
      ctx.fillRect(14, 10, 5, 3);
      ctx.fillRect(8, 6, 4, 4);
      ctx.fillRect(13, 6, 4, 4);
      ctx.fillStyle = '#7ee08a';
      ctx.fillRect(9, 6, 2, 1);
      ctx.fillRect(14, 6, 2, 1);
    } else if (kind === 'hygrophilaBush' || kind === 'rotalaBush') {
      const isHygro = kind === 'hygrophilaBush';
      ctx.fillStyle = isHygro ? '#5b8c1c' : '#a81a52';
      for (let i = 0; i < 5; i++) ctx.fillRect(4 + i * 4, 8 + (i % 3), 1, 13);
      ctx.fillStyle = isHygro ? '#93c93a' : '#e8457a';
      for (let i = 0; i < 5; i++) {
        ctx.fillRect(3 + i * 4, 8 + (i % 3), 2, 3);
        ctx.fillRect(6 + i * 4, 8 + (i % 3), 2, 3);
      }
      ctx.fillStyle = isHygro ? '#caf06a' : '#ff9db4';
      for (let i = 0; i < 5; i++) ctx.fillRect(4 + i * 4, 6 + (i % 3), 1, 2);
    } else {
      ctx.fillStyle = '#5a6a80';
      ctx.fillRect(5, 12, 14, 9);
      ctx.fillStyle = '#65a30d';
      ctx.fillRect(7, 10, 10, 3);
    }
  }, [kind]);

  return (
    <canvas
      ref={canvasRef}
      width={24}
      height={24}
      className="h-6 w-6 shrink-0 pixelated"
    />
  );
};

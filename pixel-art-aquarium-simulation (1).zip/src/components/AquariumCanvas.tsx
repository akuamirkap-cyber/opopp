import React, { useEffect, useRef, useState } from 'react';
import {
  WATER_SURFACE_Y,
  VIRTUAL_HEIGHT,
  VIRTUAL_WIDTH,
  type AquariumSettings,
  type DecorPlacement,
  type HoverTarget,
  type PlaceableBrush,
} from '../aquarium/types';
import { PixelAquariumEngine } from '../aquarium/engine';
import type { UnderwaterAudioEngine } from '../aquarium/audio';

interface AquariumCanvasProps {
  engineRef: React.MutableRefObject<PixelAquariumEngine | null>;
  audioRef: React.MutableRefObject<UnderwaterAudioEngine | null>;
  settings: AquariumSettings;
  selectedBrush: PlaceableBrush | null;
  onPlaceDecoration: (placement: DecorPlacement) => void;
  onCancelBrush: () => void;
  onStatsTick: (stats: { bubbles: number; spores: number; items: number }) => void;
  onInteractionFeedback: (message: string) => void;
}

export const AquariumCanvas: React.FC<AquariumCanvasProps> = ({
  engineRef,
  audioRef,
  settings,
  selectedBrush,
  onPlaceDecoration,
  onCancelBrush,
  onStatsTick,
  onInteractionFeedback,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  const brushRef = useRef(selectedBrush);
  brushRef.current = selectedBrush;

  const [hoverTarget, setHoverTarget] = useState<HoverTarget | null>(null);
  const lastPointerRef = useRef<{ x: number; y: number; down: boolean }>({
    x: 0,
    y: 0,
    down: false,
  });

  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();
    let statsAccum = 0;

    const loop = (now: number) => {
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      const engine = engineRef.current;
      const canvas = canvasRef.current;
      if (engine && canvas) {
        engine.step(dt, settingsRef.current);
        engine.render(canvas, settingsRef.current);

        statsAccum += dt;
        if (statsAccum >= 0.45) {
          statsAccum = 0;
          onStatsTick(engine.getStats());
        }
      }
      rafId = window.requestAnimationFrame(loop);
    };

    rafId = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(rafId);
  }, [engineRef, onStatsTick]);

  // Clear preview ghost when brush is deselected
  useEffect(() => {
    if (!selectedBrush && engineRef.current) {
      engineRef.current.previewBrush = null;
    }
  }, [selectedBrush, engineRef]);

  const toVirtualCoords = (clientX: number, clientY: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return { vx: 0, vy: 0 };
    const rect = canvas.getBoundingClientRect();
    const vx = ((clientX - rect.left) / rect.width) * VIRTUAL_WIDTH;
    const vy = ((clientY - rect.top) / rect.height) * VIRTUAL_HEIGHT;
    return {
      vx: Math.max(0, Math.min(VIRTUAL_WIDTH, vx)),
      vy: Math.max(0, Math.min(VIRTUAL_HEIGHT, vy)),
    };
  };

  const snapPlacementY = (vx: number, vy: number): number => {
    const engine = engineRef.current;
    if (!engine) return vy;
    const sandY = engine.getSubstrateY(vx);
    // Snap cleanly onto the sand terrace or allow slight foreground placement
    if (vy <= sandY + 4) return sandY;
    return Math.min(VIRTUAL_HEIGHT - 6, Math.round(vy));
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const engine = engineRef.current;
    if (!engine) return;
    const { vx, vy } = toVirtualCoords(e.clientX, e.clientY);

    if (brushRef.current) {
      const snappedY = snapPlacementY(vx, vy);
      engine.previewBrush = {
        kind: brushRef.current.kind,
        x: vx,
        y: snappedY,
        height: brushRef.current.defaultHeight,
      };
      if (hoverTarget) setHoverTarget(null);
      return;
    }

    const dx = vx - lastPointerRef.current.x;
    const dy = vy - lastPointerRef.current.y;
    lastPointerRef.current.x = vx;
    lastPointerRef.current.y = vy;

    // Gentle water stirring when moving cursor through water (stronger when dragging)
    if (vy >= WATER_SURFACE_Y - 4 && (Math.abs(dx) > 0.3 || Math.abs(dy) > 0.3)) {
      const mult = lastPointerRef.current.down ? 5.2 : 1.6;
      engine.stirWater(vx, vy, dx * mult, dy * mult);
    }

    const hit = engine.findHoverTarget(vx, vy);
    setHoverTarget(hit);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const engine = engineRef.current;
    if (!engine) return;

    if (e.button === 2) {
      if (brushRef.current) {
        e.preventDefault();
        onCancelBrush();
      }
      return;
    }

    const { vx, vy } = toVirtualCoords(e.clientX, e.clientY);
    lastPointerRef.current = { x: vx, y: vy, down: true };

    // 1. Place decoration if brush is active
    if (brushRef.current) {
      const brush = brushRef.current;
      const clampedX = Math.max(16, Math.min(VIRTUAL_WIDTH - 16, Math.round(vx)));
      const snappedY = snapPlacementY(clampedX, vy);
      const layer: DecorPlacement['layer'] =
        brush.kind === 'giantKelp' ||
        brush.kind === 'vallisneria' ||
        brush.kind === 'redLudwigia' ||
        brush.kind === 'ancientPillar' ||
        brush.kind === 'bonsaiTreeAncient' ||
        brush.kind === 'hygrophilaBush' ||
        brush.kind === 'rotalaBush'
          ? 'back'
          : brush.kind === 'hairgrass' ||
            brush.kind === 'marimoBall' ||
            brush.kind === 'conchShell' ||
            brush.kind === 'glowMushroom' ||
            brush.kind === 'dwarfHairgrassCarpet' ||
            brush.kind === 'monteCarloCarpet' ||
            brush.kind === 'javaMossStone'
          ? 'front'
          : 'mid';

      const newPlacement: DecorPlacement = {
        id: `custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        kind: brush.kind,
        x: clampedX,
        y: snappedY,
        height: brush.defaultHeight,
        spread:
          brush.kind === 'dwarfHairgrassCarpet'
            ? 110
            : brush.kind === 'monteCarloCarpet'
            ? 80
            : undefined,
        seed: Math.floor(Math.random() * 9999),
        layer,
        interactive: [
          'treasureChest',
          'pearlClam',
          'stoneLantern',
          'volcanoVent',
          'diverHelmet',
          'crystalCyan',
          'crystalAmethyst',
          'ancientPillar',
        ].includes(brush.kind),
        label: brush.name,
      };
      onPlaceDecoration(newPlacement);
      engine.spawnBubbleBurst(clampedX, snappedY - 8, 8, 'cyan');
      engine.addRippleAt(clampedX, snappedY - 8);
      audioRef.current?.playBubblePop(0.75);
      onInteractionFeedback(`Menambahkan ${brush.name}`);
      return;
    }

    // 2. Otherwise check interactive ornament click
    const hit = engine.findHoverTarget(vx, vy);
    if (hit) {
      const outcome = engine.triggerInteraction(hit);
      if (outcome.sound === 'chest-open') {
        audioRef.current?.playChestCreak(true);
      } else if (outcome.sound === 'chest-close') {
        audioRef.current?.playChestCreak(false);
      } else if (outcome.sound === 'crystal') {
        audioRef.current?.playCrystalChime(outcome.index);
      } else if (outcome.sound === 'bubble') {
        audioRef.current?.playBubblePop(1);
      }
      onInteractionFeedback(hit.label);
      return;
    }

    // 3. Otherwise stir water + ripple at click point
    if (vy >= WATER_SURFACE_Y - 6) {
      engine.addRippleAt(vx, vy);
      engine.spawnBubbleBurst(vx, Math.max(WATER_SURFACE_Y + 12, vy), 5, 'silver');
      engine.stirWater(vx, vy, (Math.random() - 0.5) * 35, -35);
      audioRef.current?.playBubblePop(0.5);
    }
  };

  const handlePointerUp = () => {
    lastPointerRef.current.down = false;
  };

  const handlePointerLeave = () => {
    lastPointerRef.current.down = false;
    setHoverTarget(null);
    if (engineRef.current) {
      engineRef.current.previewBrush = null;
    }
  };

  return (
    <div
      className="relative w-full aspect-[16/9] select-none overflow-hidden bg-[#030a16]"
      onContextMenu={(e) => {
        if (selectedBrush) {
          e.preventDefault();
          onCancelBrush();
        }
      }}
    >
      <canvas
        ref={canvasRef}
        width={VIRTUAL_WIDTH}
        height={VIRTUAL_HEIGHT}
        onPointerMove={handlePointerMove}
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerLeave}
        className={`block h-full w-full pixelated ${
          selectedBrush
            ? 'cursor-crosshair'
            : hoverTarget
            ? 'cursor-pointer'
            : 'cursor-grab active:cursor-grabbing'
        }`}
      />

      {/* Optional subtle CRT / 18-bit sub-pixel sheen */}
      {settings.pixelGridOverlay && (
        <div className="pointer-events-none absolute inset-0 crt-scanlines opacity-55" />
      )}

      {/* Interactive Hover Tooltip snapped cleanly inside tank */}
      {hoverTarget && !selectedBrush && (
        <div
          className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-full pb-2 transition-all duration-75"
          style={{
            left: `${Math.max(12, Math.min(88, (hoverTarget.x / VIRTUAL_WIDTH) * 100))}%`,
            top: `${Math.max(18, (hoverTarget.y / VIRTUAL_HEIGHT) * 100)}%`,
          }}
        >
          <div className="border border-cyan-300/60 bg-slate-950/90 px-2.5 py-1 text-center shadow-lg backdrop-blur-xs">
            <div className="font-pixel-title text-[10px] tracking-wide text-cyan-200">
              {hoverTarget.label}
            </div>
            <div className="text-[11px] text-cyan-300/80">{hoverTarget.hint}</div>
          </div>
        </div>
      )}

      {/* Brush placement active banner */}
      {selectedBrush && (
        <div className="pointer-events-none absolute left-3 top-3 z-20 border border-emerald-400/60 bg-slate-950/85 px-3 py-1.5 text-xs text-emerald-200 shadow-lg">
          <span className="font-pixel-title text-[10px] text-emerald-300">
            MODE PASANG:
          </span>{' '}
          Klik di dasar akuarium untuk meletakkan <strong>{selectedBrush.name}</strong>{' '}
          <span className="text-slate-400">(Klik kanan / ESC batal)</span>
        </div>
      )}
    </div>
  );
};

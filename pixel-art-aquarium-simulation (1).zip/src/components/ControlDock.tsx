import React, { useState } from 'react';
import type {
  AquariumSettings,
  InteractiveStates,
  LightingMode,
  PlaceableBrush,
  PresetId,
} from '../aquarium/types';
import { AQUASCAPE_PRESETS, PLACEABLE_BRUSHES } from '../aquarium/presets';
import {
  BubblePixelIcon,
  CoralIcon,
  CrystalIcon,
  MoonPixelIcon,
  ShellPixelIcon,
  SunPixelIcon,
  SunsetPixelIcon,
  WavePixelIcon,
} from './PixelIcons';
import { SpriteThumb } from './SpriteThumb';

interface ControlDockProps {
  activePreset: PresetId;
  onSelectPreset: (id: PresetId) => void;
  settings: AquariumSettings;
  onChangeSettings: (patch: Partial<AquariumSettings>) => void;
  selectedBrush: PlaceableBrush | null;
  onSelectBrush: (brush: PlaceableBrush | null) => void;
  onUndoPlacement: () => void;
  onResetLayout: () => void;
  canUndo: boolean;
  customCount: number;
  interactiveStates: InteractiveStates;
  onQuickTrigger: (
    action: 'chest' | 'clam' | 'lantern' | 'volcano' | 'crystal'
  ) => void;
}

type StudioTab = 'themes' | 'decor' | 'atmosphere';
type DecorCategory = 'all' | 'ornament' | 'coral' | 'plant' | 'rock';

export const ControlDock: React.FC<ControlDockProps> = ({
  activePreset,
  onSelectPreset,
  settings,
  onChangeSettings,
  selectedBrush,
  onSelectBrush,
  onUndoPlacement,
  onResetLayout,
  canUndo,
  customCount,
  interactiveStates,
  onQuickTrigger,
}) => {
  const [tab, setTab] = useState<StudioTab>('themes');
  const [category, setCategory] = useState<DecorCategory>('all');

  const filteredBrushes = PLACEABLE_BRUSHES.filter((b) =>
    category === 'all' ? true : b.category === category
  );

  const lightingOptions: Array<{
    id: LightingMode;
    label: string;
    icon: React.ReactNode;
  }> = [
    { id: 'day', label: 'Siang Cerah', icon: <SunPixelIcon className="h-3.5 w-3.5 text-amber-300" /> },
    { id: 'sunlight', label: 'Matahari Terang', icon: <SunPixelIcon className="h-3.5 w-3.5 text-lime-300" /> },
    { id: 'golden', label: 'Senja Emas', icon: <SunsetPixelIcon className="h-3.5 w-3.5 text-orange-300" /> },
    { id: 'night', label: 'Bioluminesen', icon: <MoonPixelIcon className="h-3.5 w-3.5 text-cyan-300" /> },
    { id: 'abyss', label: 'Palung Dalam', icon: <CrystalIcon className="h-3.5 w-3.5 text-purple-300" /> },
    { id: 'auto', label: 'Siklus Otomatis', icon: <WavePixelIcon className="h-3.5 w-3.5 text-emerald-300" /> },
  ];

  return (
    <div className="pixel-panel w-full border border-cyan-500/25 bg-[#071121]/92 backdrop-blur-md">
      {/* Studio Tabs Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-cyan-500/20 px-3 py-2 sm:px-4">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setTab('themes')}
            className={`flex items-center gap-1.5 border px-3 py-1.5 text-xs transition ${
              tab === 'themes'
                ? 'border-cyan-400/70 bg-cyan-500/20 text-cyan-100'
                : 'border-slate-700/80 bg-slate-900/60 text-slate-300 hover:border-cyan-500/40 hover:text-cyan-100'
            }`}
          >
            <ShellPixelIcon className="h-3.5 w-3.5 text-cyan-300" />
            <span className="font-pixel-title text-[10px]">TEMA & INTERAKSI</span>
          </button>

          <button
            type="button"
            onClick={() => setTab('decor')}
            className={`flex items-center gap-1.5 border px-3 py-1.5 text-xs transition ${
              tab === 'decor'
                ? 'border-emerald-400/70 bg-emerald-500/20 text-emerald-100'
                : 'border-slate-700/80 bg-slate-900/60 text-slate-300 hover:border-emerald-500/40 hover:text-emerald-100'
            }`}
          >
            <CoralIcon className="h-3.5 w-3.5 text-emerald-300" />
            <span className="font-pixel-title text-[10px]">
              TAMBAH HIASAN ({PLACEABLE_BRUSHES.length})
            </span>
          </button>

          <button
            type="button"
            onClick={() => setTab('atmosphere')}
            className={`flex items-center gap-1.5 border px-3 py-1.5 text-xs transition ${
              tab === 'atmosphere'
                ? 'border-purple-400/70 bg-purple-500/20 text-purple-100'
                : 'border-slate-700/80 bg-slate-900/60 text-slate-300 hover:border-purple-500/40 hover:text-purple-100'
            }`}
          >
            <BubblePixelIcon className="h-3.5 w-3.5 text-purple-300" />
            <span className="font-pixel-title text-[10px]">AIR & CAHAYA</span>
          </button>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          {selectedBrush && (
            <button
              type="button"
              onClick={() => onSelectBrush(null)}
              className="border border-rose-400/50 bg-rose-500/15 px-2.5 py-1 text-[11px] text-rose-200 hover:bg-rose-500/25"
            >
              Batalkan Pasang ({selectedBrush.name})
            </button>
          )}
          <span className="hidden sm:inline text-[11px] text-cyan-300/75">
            Tip: Gerakkan atau klik air untuk mengaduk arus & riak permukaan
          </span>
        </div>
      </div>

      {/* TAB 1: THEMES & INTERACTIVE ORNAMENTS */}
      {tab === 'themes' && (
        <div className="space-y-3 p-3 sm:p-4">
          <div className="grid grid-cols-1 gap-2.5 md:grid-cols-3">
            {(Object.keys(AQUASCAPE_PRESETS) as PresetId[]).map((id) => {
              const preset = AQUASCAPE_PRESETS[id];
              const isActive = activePreset === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectPreset(id)}
                  className={`group flex flex-col items-start border p-3 text-left transition ${
                    isActive
                      ? 'border-cyan-400/75 bg-cyan-500/12 shadow-[inset_0_0_20px_rgba(34,211,238,0.12)]'
                      : 'border-slate-800 bg-slate-900/55 hover:border-cyan-500/40 hover:bg-slate-900/85'
                  }`}
                >
                  <div className="flex w-full items-center justify-between gap-2">
                    <span className="font-pixel-title text-[11px] text-cyan-200">
                      {preset.name}
                    </span>
                    {isActive && (
                      <span className="border border-cyan-400/50 bg-cyan-400/20 px-1.5 py-0.5 font-pixel-title text-[9px] text-cyan-200">
                        AKTIF
                      </span>
                    )}
                  </div>
                  <div className="mt-0.5 text-xs font-medium text-emerald-300/90">
                    {preset.subtitle}
                  </div>
                  <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">
                    {preset.description}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Quick Interactive Ornament Remote Controls */}
          <div className="flex flex-wrap items-center justify-between gap-2 border-t border-slate-800/80 pt-3">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="mr-1 font-pixel-title text-[10px] text-slate-400">
                AKSI ORNAMEN:
              </span>
              <button
                type="button"
                onClick={() => onQuickTrigger('chest')}
                className={`border px-2.5 py-1 text-xs transition ${
                  interactiveStates.chestOpen
                    ? 'border-amber-400/60 bg-amber-500/15 text-amber-200'
                    : 'border-slate-700 bg-slate-900/70 text-slate-300 hover:border-amber-400/50'
                }`}
              >
                Peti Harta: {interactiveStates.chestOpen ? 'Terbuka' : 'Tertutup'}
              </button>

              <button
                type="button"
                onClick={() => onQuickTrigger('clam')}
                className={`border px-2.5 py-1 text-xs transition ${
                  interactiveStates.clamOpen
                    ? 'border-cyan-400/60 bg-cyan-500/15 text-cyan-200'
                    : 'border-slate-700 bg-slate-900/70 text-slate-300 hover:border-cyan-400/50'
                }`}
              >
                Kerang Mutiara: {interactiveStates.clamOpen ? 'Terbuka' : 'Tertutup'}
              </button>

              <button
                type="button"
                onClick={() => onQuickTrigger('lantern')}
                className={`border px-2.5 py-1 text-xs transition ${
                  interactiveStates.lanternLit
                    ? 'border-orange-400/60 bg-orange-500/15 text-orange-200'
                    : 'border-slate-700 bg-slate-900/70 text-slate-300 hover:border-orange-400/50'
                }`}
              >
                Lentera Batu: {interactiveStates.lanternLit ? 'Menyala' : 'Redup'}
              </button>

              <button
                type="button"
                onClick={() => onQuickTrigger('volcano')}
                className="border border-rose-400/50 bg-rose-500/15 px-2.5 py-1 text-xs text-rose-200 transition hover:bg-rose-500/25"
              >
                Semburan Gelembung Kawah
              </button>

              <button
                type="button"
                onClick={() => onQuickTrigger('crystal')}
                className="border border-purple-400/50 bg-purple-500/15 px-2.5 py-1 text-xs text-purple-200 transition hover:bg-purple-500/25"
              >
                Resonansi Kristal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: PLACE DECORATIONS */}
      {tab === 'decor' && (
        <div className="space-y-3 p-3 sm:p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-1.5">
              {(
                [
                  { id: 'all', label: 'Semua' },
                  { id: 'ornament', label: 'Ornamen & Kristal' },
                  { id: 'coral', label: 'Koral & Anemon' },
                  { id: 'plant', label: 'Flora Air' },
                  { id: 'rock', label: 'Kayu, Batu & Kerang' },
                ] as const
              ).map((cat) => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setCategory(cat.id)}
                  className={`border px-2.5 py-1 text-xs transition ${
                    category === cat.id
                      ? 'border-emerald-400/70 bg-emerald-500/20 text-emerald-100'
                      : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-emerald-500/40'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              {customCount > 0 && (
                <span className="text-xs text-emerald-300/80">
                  +{customCount} tambahan
                </span>
              )}
              <button
                type="button"
                disabled={!canUndo}
                onClick={onUndoPlacement}
                className="border border-slate-700 bg-slate-900/80 px-2.5 py-1 text-xs text-slate-200 transition hover:border-cyan-400/50 disabled:cursor-not-allowed disabled:opacity-40"
              >
                Undo
              </button>
              <button
                type="button"
                onClick={onResetLayout}
                className="border border-amber-500/40 bg-amber-500/10 px-2.5 py-1 text-xs text-amber-200 transition hover:bg-amber-500/20"
              >
                Reset Tata Letak
              </button>
            </div>
          </div>

          <div className="grid max-h-52 grid-cols-2 gap-1.5 overflow-y-auto pr-1 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {filteredBrushes.map((brush) => {
              const active = selectedBrush?.kind === brush.kind;
              return (
                <button
                  key={brush.kind}
                  type="button"
                  onClick={() => onSelectBrush(active ? null : brush)}
                  title={brush.description}
                  className={`flex items-center gap-2 border p-1.5 text-left transition ${
                    active
                      ? 'border-emerald-400 bg-emerald-500/20 text-emerald-100'
                      : 'border-slate-800 bg-slate-900/60 text-slate-200 hover:border-cyan-500/40 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center border border-slate-700/80 bg-[#04101e]">
                    <SpriteThumb kind={brush.kind} />
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-xs font-medium leading-tight">
                      {brush.name}
                    </div>
                    <div className="truncate text-[10px] text-slate-400">
                      {brush.description}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: ATMOSPHERE, WATER & PIXEL EFFECTS */}
      {tab === 'atmosphere' && (
        <div className="grid grid-cols-1 gap-4 p-3 sm:p-4 md:grid-cols-2">
          <div className="space-y-3">
            <div className="font-pixel-title text-[10px] text-cyan-300">
              MODE PENCAHAYAAN AKUARIUM
            </div>
            <div className="flex flex-wrap gap-1.5">
              {lightingOptions.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeSettings({ lighting: opt.id })}
                  className={`flex items-center gap-1.5 border px-2.5 py-1.5 text-xs transition ${
                    settings.lighting === opt.id
                      ? 'border-cyan-400/75 bg-cyan-500/20 text-cyan-100'
                      : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-cyan-500/40'
                  }`}
                >
                  {opt.icon}
                  <span>{opt.label}</span>
                </button>
              ))}
            </div>

            <div className="flex flex-wrap gap-2 pt-1">
              <button
                type="button"
                onClick={() =>
                  onChangeSettings({ godRaysEnabled: !settings.godRaysEnabled })
                }
                className={`border px-2.5 py-1 text-xs transition ${
                  settings.godRaysEnabled
                    ? 'border-cyan-400/60 bg-cyan-500/15 text-cyan-100'
                    : 'border-slate-700 bg-slate-900/60 text-slate-400'
                }`}
              >
                Sinar Cahaya Air: {settings.godRaysEnabled ? 'ON' : 'OFF'}
              </button>

              <button
                type="button"
                onClick={() =>
                  onChangeSettings({ causticsEnabled: !settings.causticsEnabled })
                }
                className={`border px-2.5 py-1 text-xs transition ${
                  settings.causticsEnabled
                    ? 'border-cyan-400/60 bg-cyan-500/15 text-cyan-100'
                    : 'border-slate-700 bg-slate-900/60 text-slate-400'
                }`}
              >
                Kaustik Pasir: {settings.causticsEnabled ? 'ON' : 'OFF'}
              </button>

              <button
                type="button"
                onClick={() =>
                  onChangeSettings({
                    pixelGridOverlay: !settings.pixelGridOverlay,
                  })
                }
                className={`border px-2.5 py-1 text-xs transition ${
                  settings.pixelGridOverlay
                    ? 'border-purple-400/60 bg-purple-500/15 text-purple-100'
                    : 'border-slate-700 bg-slate-900/60 text-slate-400'
                }`}
              >
                Tekstur Layar 18-Bit: {settings.pixelGridOverlay ? 'ON' : 'OFF'}
              </button>
            </div>
          </div>

          <div className="space-y-3">
            <label className="block">
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-slate-300">Kekuatan Arus Air</span>
                <span className="font-pixel-title text-[10px] text-cyan-300">
                  {settings.currentStrength}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={settings.currentStrength}
                onChange={(e) =>
                  onChangeSettings({ currentStrength: Number(e.target.value) })
                }
                className="h-1.5 w-full cursor-pointer accent-cyan-400"
              />
            </label>

            <label className="block">
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-slate-300">Kepadatan Gelembung</span>
                <span className="font-pixel-title text-[10px] text-cyan-300">
                  {settings.bubbleDensity}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={settings.bubbleDensity}
                onChange={(e) =>
                  onChangeSettings({ bubbleDensity: Number(e.target.value) })
                }
                className="h-1.5 w-full cursor-pointer accent-cyan-400"
              />
            </label>

            <label className="block">
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-slate-300">Cahaya Bioluminesen</span>
                <span className="font-pixel-title text-[10px] text-purple-300">
                  {settings.bioluminescenceBoost}%
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={settings.bioluminescenceBoost}
                onChange={(e) =>
                  onChangeSettings({
                    bioluminescenceBoost: Number(e.target.value),
                  })
                }
                className="h-1.5 w-full cursor-pointer accent-purple-400"
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
};

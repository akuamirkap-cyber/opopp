import MaxkungfuGame from './games/maxkungfu/App';

export default function App() {
  return <MaxkungfuGame />;
}
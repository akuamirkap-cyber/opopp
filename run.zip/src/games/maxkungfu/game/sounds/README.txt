SUARA PAKET (V2 / V3)
=====================

Taruh file suara di folder ini dengan nama PERSIS seperti di bawah, lalu build ulang.
File otomatis ikut terbundel (di-inline), jadi tidak perlu setting apa pun lagi.

PUKULAN
  Punch Hit 1.wav
  Punch Hit 2.wav
  Punch Hit 3.wav
  punch (1).mp3      (sudah ada)
  punch (2).mp3      (sudah ada)
  punch (3).mp3      (sudah ada)

TENDANGAN
  kick type1 02.wav
  kick type1 03.wav
  kick type1 04.wav
  kick type2 02.wav

PENTUNGAN / HANTAMAN BERAT
  kick type3 02.wav
  kick type3 03.wav
  kick type3 04.wav
  kick type3 05.wav

Cara kerja versi suara:
  V1 = suara asli game (tertanam di soundData.ts).
  V2 = suara V1 DICAMPUR file di folder ini. File yang sudah ada di V1 tidak dimuat dobel.
  V3 = HANYA file di folder ini, tanpa V1.

Kategori yang filenya belum ada akan memakai suara synth bawaan game.
Daftar nama file bisa diubah di ../soundPacks.ts.

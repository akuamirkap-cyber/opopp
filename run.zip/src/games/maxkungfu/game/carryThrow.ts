import { clamp, dist, rnd } from './rng';
import { solidAt } from './level';
import { solvePose } from './draw';
import { drawStaticProp } from './propsPlay';
import { pcircle, pfontO, pline, prect, pring, type Ctx } from './pixel';

/** RMB ambil pot/meja, LMB lempar secepat peluru. Pot pecah, meja terbelah saat kena bot. */
type G = any;
interface Carried { kind: 'pot' | 'table'; prop: any; t: number }
interface Shot { kind: 'pot' | 'table'; x: number; y: number; vx: number; vy: number; life: number; spin: number; hitIds: number[] }
interface Debris { x: number; y: number; vx: number; vy: number; rot: number; spin: number; life: number; side: number }

export class CarryThrow {
  carried: Carried | null = null;
  shots: Shot[] = [];
  debris: Debris[] = [];
  time = 0;

  get carrying() { return this.carried !== null; }
  get moveMul() { return !this.carried ? 1 : this.carried.kind === 'table' ? 0.7 : 0.9; }
  poseOverride(): { pose: string; t: number } | null {
    if (!this.carried) return null;
    return this.carried.kind === 'table' ? { pose: 'grab', t: 0.5 } : { pose: 'shoot', t: 0.3 };
  }
  reset(g?: G) {
    if (this.carried && g) { this.carried.prop.dead = false; this.carried.prop.x = g.player.x + 8; this.carried.prop.y = g.player.y + 4; }
    this.carried = null; this.shots = []; this.debris = [];
  }
  nearProp(g: G): any | null {
    const p = g.player;
    let best: any = null, bd = 1e9;
    for (const pr of g.props) {
      if (pr.dead || (pr.kind !== 'pot' && pr.kind !== 'table')) continue;
      const d = dist(p.x, p.y, pr.x, pr.y);
      const reach = pr.kind === 'table' ? 44 : 38;
      if (d < reach && d < bd) { bd = d; best = pr; }
    }
    return best;
  }
  update(g: G, dt: number) {
    this.time += dt;
    if (g.state === 'playing') this.handleInput(g);
    this.updateShots(g, dt);
    this.updateDebris(dt);
  }
  handleInput(g: G) {
    const p = g.player, inp = g.input;
    if (p.fatality || p.stunT > 0 || p.holdT > 0 || g.botPunch?.active || g.propsPlay?.scene) return;
    if (this.carried) {
      if (inp.mouse.rpressed) {
        // RMB lagi = taruh kembali
        const pr = this.carried.prop;
        pr.dead = false; pr.x = p.x + Math.cos(p.aim) * 12; pr.y = p.y + 4;
        this.carried = null;
        inp.mouse.rpressed = false; inp.mouse.rdown = false;
        g.sfx?.select?.(); g.say?.('DROP', '#9a9a9a', 1, 0.5);
        return;
      }
      if (inp.mouse.pressed) {
        this.throw(g);
        inp.mouse.pressed = false; inp.mouse.down = false;
        return;
      }
      this.carried.t += g.rawDt;
      return;
    }
    if (inp.mouse.rpressed) {
      const pr = this.nearProp(g);
      if (!pr) return;
      this.carried = { kind: pr.kind, prop: pr, t: 0 };
      pr.dead = true;
      p.attackPhase = 'none'; p.buffered = null; p.comboStr = '';
      inp.mouse.rpressed = false; inp.mouse.rdown = false;
      g.sfx?.pickup?.(); g.say?.(pr.kind === 'table' ? 'TABLE LIFT (2 HANDS)' : 'POT LIFT (RIGHT HAND)', '#ffd27f', 1, 0.6);
    }
  }
  throw(g: G) {
    const c = this.carried;
    if (!c) return;
    const p = g.player;
    const mw = g.mouseWorld?.() ?? { x: p.x + Math.cos(p.aim) * 100, y: p.y + Math.sin(p.aim) * 100 };
    const target = g.nearestEnemy?.(p.x, p.y, 260, p.aim, 1.7) ?? null;
    const tx = target ? target.x : mw.x, ty = target ? target.y - 5 : mw.y;
    const a = Math.atan2(ty - (p.y - 8), tx - p.x);
    const sp = c.kind === 'pot' ? 1450 : 1300;
    this.shots.push({
      kind: c.kind, x: p.x + Math.cos(a) * 10, y: p.y - 8 + Math.sin(a) * 6,
      vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: 0.75, spin: 0, hitIds: [],
    });
    c.prop.dead = true;
    this.carried = null;
    g.sfx?.shot?.('rifle'); g.sfx?.whoosh?.();
    g.say?.('FAST THROW!', '#9be7ff', 2, 0.5);
    g.flash?.('#ffffff', 0.05); g.shake?.(0.08);
  }
  updateShots(g: G, dt: number) {
    for (let i = this.shots.length - 1; i >= 0; i--) {
      const sh = this.shots[i];
      sh.life -= dt; sh.spin += dt * 22;
      const steps = Math.max(1, Math.ceil(Math.hypot(sh.vx, sh.vy) * dt / 3));
      let gone = sh.life <= 0;
      for (let s = 0; s < steps && !gone; s++) {
        sh.x += sh.vx * dt / steps; sh.y += sh.vy * dt / steps;
        if (solidAt(g.level, sh.x, sh.y)) { this.impact(g, sh, null); gone = true; break; }
        for (const e of g.enemies) {
          if (e.dead || e.spawnT > 0 || sh.hitIds.includes(e.id)) continue;
          if (dist(sh.x, sh.y, e.x, e.y - 5 - e.z) > e.r + 7) continue;
          sh.hitIds.push(e.id);
          this.impact(g, sh, e);
          gone = true; break;
        }
      }
      if (gone) this.shots.splice(i, 1);
    }
  }
  impact(g: G, sh: Shot, e: any) {
    const a = Math.atan2(sh.vy, sh.vx);
    if (sh.kind === 'pot') {
      g.propsPlay?.shatterPot?.(g, sh.x, sh.y, a, !!e);
      if (e) {
        g.damageEnemy(e, 5, 35, a, 220, { hitstop: 0.05, shake: 0.18, melee: false });
        e.down = Math.max(e.down ?? 0, 0.55); e.state = 'down'; e.pose = 'down'; e.stun = 0.2;
      }
      return;
    }
    this.splitTable(g, sh.x, sh.y, a, !!e);
    if (e) {
      for (const q of g.enemies) {
        if (q.dead || dist(sh.x, sh.y, q.x, q.y) > 36) continue;
        g.damageEnemy(q, 8, 55, a, 420, { knockdown: true, hitstop: 0.08, shake: 0.35, melee: false, launch: 120 });
        q.down = Math.max(q.down ?? 0, 0.8); q.state = 'down'; q.pose = 'down';
      }
    }
  }
  splitTable(g: G, x: number, y: number, a: number, onBot: boolean) {
    for (let i = 0; i < 2; i++) {
      const ang = a + (i === 0 ? -0.65 : 0.65) + rnd(-0.2, 0.2);
      this.debris.push({
        x, y, vx: Math.cos(ang) * rnd(180, 300), vy: Math.sin(ang) * rnd(120, 220) - 80,
        rot: a, spin: (i === 0 ? -1 : 1) * rnd(6, 11), life: 0.75, side: i === 0 ? -1 : 1,
      });
    }
    g.particles?.burst?.(x, y, 22, '#8a5a2b', 190, 0.6, 2, 3);
    for (let i = 0; i < 5; i++) g.particles?.limb?.(x, y, a + rnd(-1.2, 1.2), rnd(120, 260), i % 2 ? '#c79a5a' : '#3a2410', 4);
    g.particles?.spark?.(x, y, 12, '#ffffff', a, 1.2, 260);
    g.particles?.smoke?.(x, y + 2, 5, '#9a8f7d', 30, 0.4);
    g.particles?.ring?.(x, y, 2, onBot ? 26 : 18, '#ffffff', 0.24, 2);
    g.particles?.shockwave?.(x, y, onBot ? 34 : 24, '#ffd27f', 0.28);
    g.sfx?.explosion?.(); g.sfx?.slam?.(); g.sfx?.kick?.();
    g.flash?.('#ffffff', onBot ? 0.14 : 0.07); g.shake?.(onBot ? 0.25 : 0.14);
    g.hitstop = Math.max(g.hitstop ?? 0, onBot ? 0.06 : 0.025);
    g.say?.(onBot ? 'TABLE SPLIT!' : 'CRASH!', '#ffd27f', 2, 0.7);
  }
  updateDebris(dt: number) {
    for (let i = this.debris.length - 1; i >= 0; i--) {
      const d = this.debris[i];
      d.life -= dt; d.x += d.vx * dt; d.y += d.vy * dt;
      d.vy += 340 * dt; d.vx *= 0.985; d.rot += d.spin * dt;
      if (d.life <= 0) this.debris.splice(i, 1);
    }
  }
  draw(g: G, ctx: Ctx) {
    for (const sh of this.shots) {
      ctx.save();
      ctx.globalAlpha = 0.35;
      pline(ctx, sh.x - sh.vx * 0.025, sh.y - sh.vy * 0.025, sh.x, sh.y, sh.kind === 'pot' ? '#ff6b81' : '#ffd27f', 2);
      ctx.globalAlpha = 1;
      ctx.translate(sh.x, sh.y); ctx.rotate(sh.spin);
      drawStaticProp(ctx, { kind: sh.kind, x: 0, y: 0 }, false, g.time);
      ctx.restore();
    }
    for (const d of this.debris) {
      ctx.save(); ctx.globalAlpha = clamp(d.life / 0.75, 0, 1);
      ctx.translate(d.x, d.y); ctx.rotate(d.rot);
      prect(ctx, -8, -2, 9, 4, '#24160d'); prect(ctx, -7, -3, 8, 3, '#8a5a2b');
      pline(ctx, -6, -3, 1, -3, '#c79a5a', 1);
      pline(ctx, d.side * 5, 0, d.side * 7, 3, '#3a2410', 2);
      ctx.restore();
    }
    ctx.save(); ctx.globalAlpha = 1;
    if (this.carried) {
      const p = g.player;
      const sk = solvePose(g.playerStickOpts(this.carried.kind === 'table' ? 'grab' : 'shoot', 0.4));
      const fh = { x: p.x + sk.fhand.x, y: p.y + sk.fhand.y - p.z };
      const bh = { x: p.x + sk.bhand.x, y: p.y + sk.bhand.y - p.z };
      if (this.carried.kind === 'pot') {
        drawStaticProp(ctx, { kind: 'pot', x: fh.x + 2, y: fh.y + 4 }, false, g.time);
        pcircle(ctx, fh.x, fh.y, 1.5, '#ffffff');
      } else {
        const cx = (fh.x + bh.x) / 2, cy = (fh.y + bh.y) / 2 + 2;
        ctx.translate(cx, cy); ctx.scale(1.15, 1.15);
        drawStaticProp(ctx, { kind: 'table', x: 0, y: 0 }, false, g.time);
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        pcircle(ctx, fh.x, fh.y, 1.6, '#ffffff'); pcircle(ctx, bh.x, bh.y, 1.6, '#ffffff');
        pline(ctx, fh.x, fh.y, cx - 7, cy, '#ffffff88', 1);
        pline(ctx, bh.x, bh.y, cx + 7, cy, '#ffffff88', 1);
      }
      pfontO(ctx, 'LMB THROW', p.x, p.y - 32 - p.z, '#9be7ff', '#000', 1, 'center');
    } else if (g.state === 'playing') {
      const pr = this.nearProp(g);
      if (pr) {
        pring(ctx, pr.x, pr.y - 5, 12, '#ffd27f', 2);
        pcircle(ctx, pr.x, pr.y - 5, 2, '#ffffff');
        pline(ctx, g.player.x, g.player.y - 6, pr.x, pr.y - 5, '#ffd27f66', 1);
        prect(ctx, Math.round(pr.x - 34), Math.round(pr.y - 29), 68, 7, '#000000aa');
        pfontO(ctx, pr.kind === 'pot' ? 'RMB: AMBIL POT' : 'RMB: MEJA 2 TANGAN', pr.x, pr.y - 28, '#ffd27f', '#000', 1, 'center');
      }
    }
    ctx.restore();
  }
}

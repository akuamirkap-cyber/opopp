// NUNCHAKU V2 — 1:1 port of STICK FIST's nunchaku (verlet chain, 4-hit combo, sweep arcs, flourish, trail).
import { pline, prect, type Ctx } from './pixel';

export interface SFAttack { name: string; dmg: number; range: number; arc: number; dur: number; lunge: number; kb: number; posture: number; heavy?: boolean }

export const SF_NUNCHAKU: SFAttack[] = [
  { name: 'NUN SWING', dmg: 6, range: 28, arc: 3.6, dur: 0.145, lunge: 30, kb: 90, posture: 15 },
  { name: 'NUN CROSS', dmg: 6, range: 28, arc: 3.6, dur: 0.145, lunge: 30, kb: 90, posture: 15 },
  { name: 'NUN SPIN', dmg: 5, range: 30, arc: 6.3, dur: 0.3, lunge: 10, kb: 70, posture: 13 },
  { name: 'WHIP CRACK', dmg: 15, range: 29, arc: 2.4, dur: 0.26, lunge: 60, kb: 260, posture: 32, heavy: true },
];

const TAU = Math.PI * 2;
type P = { x: number; y: number; px: number; py: number };

export class SFNunchaku {
  pts: P[] = [];
  anchor = { x: 0, y: 0 };
  prevEnd = { x: 0, y: 0 };
  trail: { x: number; y: number }[] = [];
  flourish = 0; flourishCd = 1; endSpeed = 0;
  // combo state (mirrors game1's player.state === 'attack' for weapon 3)
  cur: SFAttack | null = null;
  t = 0; idx = 0; comboTimer = 0; didHit = false; buffered = false;

  reset(x: number, y: number) {
    this.pts = Array.from({ length: 6 }, () => ({ x, y, px: x, py: y }));
    this.anchor = { x, y }; this.trail = []; this.cur = null; this.idx = 0;
  }
  get attacking() { return !!this.cur; }
  start(heavy = false) {
    if (heavy) this.idx = 3;
    this.cur = SF_NUNCHAKU[this.idx]; this.t = 0; this.didHit = false; this.buffered = false;
  }
  /** advance combo; returns 'hit' on the hit frame */
  step(dt: number): 'hit' | null {
    this.comboTimer -= dt;
    if (!this.cur) { if (this.comboTimer <= 0) this.idx = 0; return null; }
    this.t += dt;
    const u = this.t / this.cur.dur;
    let ev: 'hit' | null = null;
    if (!this.didHit && u >= 0.45) { this.didHit = true; ev = 'hit'; }
    if (u >= 1) {
      this.idx = (this.idx + 1) % SF_NUNCHAKU.length; this.comboTimer = 1.05; this.cur = null;
      if (this.buffered) this.start();
    }
    return ev;
  }
  lungeK() { return this.cur ? Math.max(0, 1 - (this.t / this.cur.dur) * 1.5) : 0; }

  update(dt: number, shX: number, shY: number, facing: number, time: number, mode: 'idle' | 'dash', LS = 1, hand?: { x: number; y: number }) {
    if (this.pts.length !== 6) this.reset(shX, shY);
    this.flourishCd -= dt; this.flourish = Math.max(0, this.flourish - dt);
    let tx: number, ty: number, rate = 1;
    const attacking = !!this.cur || !!hand;
    void time;
    if (hand) { tx = hand.x; ty = hand.y; rate = 1; }
    else if (attacking) {
      const a = this.cur!, u = Math.min(1, this.t / a.dur);
      const sweep = (from: number, to: number, snap = 0.5) => {
        if (u < 0.18) return from - Math.sign(to - from) * 0.5 * (u / 0.18);
        const v = Math.min(1, (u - 0.18) / snap);
        const e = 1 - Math.pow(1 - v, 3);
        return from + (to - from) * e + Math.sin(v * Math.PI) * 0.12 * Math.sign(to - from);
      };
      let ang = facing, rad = 11;
      switch (a.name) {
        case 'NUN CROSS': ang = facing + sweep(2.0, -1.0); rad = 8 + 5 * u; break;
        case 'NUN SPIN': ang = facing + u * TAU * 1.5; rad = 12; break;
        case 'WHIP CRACK': ang = facing + sweep(-2.3, 0.8, 0.34); rad = 6 + 8 * Math.min(1, Math.max(0, (u - 0.18) / 0.34)); break;
        default: ang = facing + sweep(-2.0, 1.0); rad = 8 + 5 * u;
      }
      tx = shX + Math.cos(ang) * rad * LS; ty = shY + Math.sin(ang) * rad * LS; rate = 0.7;
    } else if (mode === 'dash') {
      tx = shX - Math.cos(facing) * 6 * LS; ty = shY + 3 * LS; rate = 0.3;
    } else {
      if (this.flourishCd <= 0 && this.flourish === 0) { this.flourish = 0.55; this.flourishCd = 1.6 + Math.random() * 1.2; }
      if (this.flourish > 0) {
        const fu = 1 - this.flourish / 0.55, ga = facing + fu * TAU * 2;
        tx = shX + Math.cos(ga) * 7.5 * LS; ty = shY + Math.sin(ga) * 7.5 * LS; rate = 0.45;
      } else { tx = shX + Math.cos(facing) * 6.5 * LS; ty = shY + (2.5 + Math.sin(facing) * 3) * LS; }
    }
    const N = this;
    if (Math.hypot(N.anchor.x - tx, N.anchor.y - ty) > 46 * LS) { N.anchor.x = tx; N.anchor.y = ty; }
    const kk = 1 - Math.pow(1 - rate, dt * 60);
    N.anchor.x += (tx - N.anchor.x) * kk; N.anchor.y += (ty - N.anchor.y) * kk;
    const rest = [2.2, 2.2, 2.2, 2.2, 7].map((r) => r * LS);
    const last = N.pts[5];
    N.prevEnd = { x: last.x, y: last.y };
    const sub = 3, sdt = dt / sub;
    for (let s = 0; s < sub; s++) {
      N.pts[0].x = N.anchor.x; N.pts[0].y = N.anchor.y; N.pts[0].px = N.anchor.x; N.pts[0].py = N.anchor.y;
      for (let i = 1; i < 6; i++) {
        const q = N.pts[i];
        const damp = attacking ? 0.994 : 0.985, grav = attacking ? 6 : 55;
        const vx = (q.x - q.px) * damp, vy = (q.y - q.py) * damp;
        q.px = q.x; q.py = q.y;
        q.x += vx; q.y += vy + grav * sdt * sdt * 60;
      }
      for (let it = 0; it < 4; it++) {
        N.pts[0].x = N.anchor.x; N.pts[0].y = N.anchor.y;
        for (let i = 0; i < 5; i++) {
          const a = N.pts[i], b = N.pts[i + 1];
          const dx = b.x - a.x, dy = b.y - a.y;
          const d = Math.hypot(dx, dy) || 0.001, diff = (d - rest[i]) / d;
          if (i === 0) { b.x -= dx * diff; b.y -= dy * diff; }
          else { a.x += dx * diff * 0.5; a.y += dy * diff * 0.5; b.x -= dx * diff * 0.5; b.y -= dy * diff * 0.5; }
        }
      }
    }
    const end = N.pts[5];
    N.endSpeed = Math.hypot(end.x - N.prevEnd.x, end.y - N.prevEnd.y) / Math.max(dt, 0.001);
    N.trail.unshift({ x: end.x, y: end.y });
    if (N.trail.length > 8) N.trail.pop();
  }

  /** distance from point to the free stick segment */
  stickDist(x: number, y: number) {
    const a = this.pts[4], b = this.pts[5];
    const dx = b.x - a.x, dy = b.y - a.y, L2 = dx * dx + dy * dy || 1;
    const t = Math.max(0, Math.min(1, ((x - a.x) * dx + (y - a.y) * dy) / L2));
    return Math.hypot(x - (a.x + dx * t), y - (a.y + dy * t));
  }

  draw(ctx: Ctx, accent: string, showTrail = true) {
    const pts = this.pts;
    if (pts.length !== 6) return;
    for (let i = showTrail ? this.trail.length - 1 : 0; i >= 1; i--) {
      const t = 1 - i / this.trail.length;
      ctx.globalAlpha = t * 0.55;
      pline(ctx, this.trail[i].x, this.trail[i].y, this.trail[i - 1].x, this.trail[i - 1].y, accent, Math.max(1, Math.round(0.5 + t * 2.2)));
    }
    ctx.globalAlpha = 1;
    const end = pts[5];
    {
      const dx = pts[1].x - pts[0].x, dy = pts[1].y - pts[0].y, d = Math.hypot(dx, dy) || 1;
      const hx = pts[0].x + dx / d * 4.5, hy = pts[0].y + dy / d * 4.5;
      pline(ctx, pts[0].x, pts[0].y, hx, hy, '#000', 4);
      pline(ctx, pts[0].x, pts[0].y, hx, hy, '#9c6a33', 2);
    }
    for (let i = 1; i < 4; i++) {
      pline(ctx, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, '#000', 3);
      pline(ctx, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y, '#aeb8c6', 1);
    }
    pline(ctx, pts[4].x, pts[4].y, end.x, end.y, '#000', 4);
    // saat mode api, tongkat ikut membara (bukan batang gelap di tengah kobaran)
    pline(ctx, pts[4].x, pts[4].y, end.x, end.y, showTrail ? '#b3763a' : '#8a4a1e', 2);
    if (!showTrail) pline(ctx, pts[4].x, pts[4].y, end.x, end.y, '#ff8a2a', 1);
    prect(ctx, end.x - 1.5, end.y - 1.5, 3, 3, '#000');
    prect(ctx, end.x - 1, end.y - 1, 2, 2, accent);
  }
}

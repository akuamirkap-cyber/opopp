import type { ReactNode } from "react";
import { MAX_HP, TEAMS, TEAM_SIZE, WEAPONS, WEAPON_ORDER, WIN_ROUNDS } from "../game/defs";
import type { HudState } from "../game/engine";
import { weaponIcon } from "../game/sprites";
import { ITEMS } from "../game/bugs";

const TONE = { gold: "#f5c542", red: "#ff4d5e", white: "#ffffff" };

function Pips({ n, alive, color, reverse }: { n: number; alive: number; color: string; reverse?: boolean }) {
  return (
    <div className={`flex gap-[3px] ${reverse ? "flex-row-reverse" : ""}`}>
      {Array.from({ length: n }, (_, i) => (
        <div key={i} className="h-2 w-2 sm:h-2.5 sm:w-2.5" style={{ background: i < alive ? color : "#2a2732", boxShadow: "0 0 0 1px #0a0a0f" }} />
      ))}
    </div>
  );
}

function Box({ children, accent, className = "" }: { children: ReactNode; accent?: string; className?: string }) {
  return (
    <div className={`flex items-center gap-2 bg-[#0c0a10]/85 px-2 py-1.5 ${className}`} style={{ boxShadow: `0 0 0 2px #0a0a0f${accent ? `, inset 0 -3px 0 ${accent}` : ""}` }}>
      {children}
    </div>
  );
}

function TeamBox({ team, score, alive, mine }: { team: number; score: number; alive: number; mine: boolean }) {
  const t = TEAMS[team];
  return (
    <Box accent={t.dark} className={team === 1 ? "flex-row-reverse" : ""}>
      <div className={`flex flex-col gap-1 ${team === 1 ? "items-end" : ""}`}>
        <div className="text-[7px] sm:text-[8px]" style={{ color: t.color }}>
          {t.name}
          {mine && <span className="text-white/60"> (TIM KAMU)</span>}
        </div>
        <Pips n={TEAM_SIZE} alive={alive} color={t.color} reverse={team === 1} />
      </div>
      <div className="ts text-lg sm:text-2xl" style={{ color: t.color }}>{score}</div>
    </Box>
  );
}

interface Props {
  hud: HudState;
  onSelect: (i: number) => void;
  onPause: () => void;
  onMute: () => void;
  onStrat: (n: number) => void;
}

export function Hud({ hud, onSelect, onPause, onMute, onStrat }: Props) {
  const w = WEAPONS[hud.weapon];
  const bugs = hud.game === "bugs";
  const m = Math.floor(hud.time / 60), s = hud.time % 60;
  const low = hud.hp > 0 && hud.hp < 35;
  const hint = hud.round === 1 && hud.phase === "freeze" && !hud.touch;

  return (
    <div className="pointer-events-none absolute inset-0 z-20 font-pixel text-white">
      {/* scoreboard */}
      {bugs ? (
        <div className="absolute left-1/2 top-2 flex -translate-x-1/2 flex-col items-center gap-1.5">
          <div className="flex items-stretch gap-1.5">
            <Box accent="#a97a1c">
              <div className="flex flex-col gap-1">
                <div className="text-[7px] text-[#f5c542] sm:text-[8px]">SKUAD</div>
                <Pips n={4} alive={hud.alive[0]} color="#f5c542" />
              </div>
            </Box>
            <div className="flex min-w-[170px] flex-col items-center justify-center gap-1 bg-[#0c0a10]/85 px-3 py-1.5 sm:min-w-[236px]" style={{ boxShadow: "0 0 0 2px #0a0a0f" }}>
              <div className="text-[5px] text-white/50 sm:text-[6px]">TUJUAN - {hud.weather}{hud.floor ? ` - LANTAI ${hud.floor}` : ""}</div>
              <div className={`ts text-[7px] sm:text-[9px] ${hud.stage >= 2 ? "text-[#ff6b7a]" : hud.stage === 1 ? "text-[#7dff9a]" : "text-[#f5c542]"}`}>{hud.obj}</div>
              {hud.evac >= 0 ? (
                <div className="ts blink text-[9px] text-[#8af0ff] sm:text-[11px]">
                  HELI TIBA {Math.floor(hud.evac / 60)}:{hud.evac % 60 < 10 ? "0" : ""}{hud.evac % 60}
                </div>
              ) : (
                <div className="flex gap-1.5">
                  {ITEMS.map((it, i) => (
                    <span key={it.name} className="px-1 py-0.5 text-[5px] sm:text-[6px]" style={{ background: hud.items[i] ? it.col : "#23212c", color: hud.items[i] ? "#0a0a0f" : "#6b6878", boxShadow: "0 0 0 1px #0a0a0f" }}>
                      {it.name}
                    </span>
                  ))}
                </div>
              )}
            </div>
            <Box accent="#9c1f33">
              <div className="flex flex-col items-end gap-1">
                <div className="text-[7px] text-[#ff4d5e] sm:text-[8px]">DIBASMI</div>
                <div className="ts text-[10px] text-[#ff4d5e] sm:text-sm">{hud.kills}</div>
                <div className="text-[5px] text-[#ff9aa5] sm:text-[6px]">HEADSHOT {hud.heads}</div>
              </div>
            </Box>
          </div>
          {hud.boss >= 0 && (
            <div className="flex w-[260px] flex-col items-center gap-1 sm:w-[360px]">
              <div className="ts text-[7px] text-[#c8ff4a] sm:text-[9px]">MUTAN RAKSASA</div>
              <div className="h-3 w-full bg-[#0a0a0f] p-[2px]" style={{ boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #6fdc3e" }}>
                <div className="h-full bg-[#c8ff4a]" style={{ width: `${hud.boss * 100}%` }} />
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="absolute left-1/2 top-2 flex -translate-x-1/2 items-stretch gap-1.5">
          <TeamBox team={0} score={hud.score[0]} alive={hud.alive[0]} mine />
          <div className="flex min-w-[64px] flex-col items-center justify-center bg-[#0c0a10]/85 px-2 py-1" style={{ boxShadow: "0 0 0 2px #0a0a0f" }}>
            <div className="text-[6px] text-white/60 sm:text-[7px]">RONDE {hud.round}</div>
            <div className={`ts text-[11px] sm:text-sm ${hud.time <= 10 && hud.phase === "live" ? "blink text-[#ff4d5e]" : ""}`}>
              {m}:{s < 10 ? "0" : ""}{s}
            </div>
            <div className="text-[5px] text-[#f5c542]/80 sm:text-[6px]">MENANG {WIN_ROUNDS} RONDE</div>
          </div>
          <TeamBox team={1} score={hud.score[1]} alive={hud.alive[1]} mine={false} />
        </div>
      )}

      {/* buttons + kill feed */}
      <div className="absolute right-2 top-2 flex flex-col items-end gap-1.5">
        <div className="pointer-events-auto flex gap-2 pr-0.5 pt-0.5">
          <button className="btn btn-dark px-2 py-1.5 text-[7px]" onClick={onMute}>{hud.muted ? "SFX OFF" : "SFX ON"}</button>
          <button className="btn btn-dark px-2 py-1.5 text-[7px]" onClick={onPause}>II</button>
        </div>
        <div className="mt-1 flex flex-col items-end gap-1">
          {hud.feed.map((k) => (
            <div key={k.id} className="slide-in flex items-center gap-1.5 bg-[#0c0a10]/85 px-1.5 py-1 text-[6px] sm:text-[8px]" style={{ boxShadow: k.me ? "0 0 0 2px #f5c542" : "0 0 0 1px #0a0a0f" }}>
              <span style={{ color: k.weapon === "bug" ? "#ff9a3c" : TEAMS[k.killerTeam].color }}>{k.killer}</span>
              {k.weapon === "boom" ? (
                <span className="text-[#ff9a3c]">BOOM</span>
              ) : k.weapon === "bug" ? (
                <span className="text-[#ff6b7a]">GIGIT</span>
              ) : (
                <img src={weaponIcon(k.weapon, k.killerTeam)} className="px h-[10px] w-[26px] sm:h-[15px] sm:w-[39px]" alt="" />
              )}
              {k.tag && <span className="text-[#ff9df0]">{k.tag}</span>}
              <span style={{ color: bugs && k.victimTeam === 1 ? "#ff9a3c" : TEAMS[k.victimTeam].color }}>{k.victim}</span>
            </div>
          ))}
        </div>
      </div>

      {/* banner / countdown */}
      <div className={`absolute inset-x-0 flex flex-col items-center gap-2 px-2 text-center ${bugs && hud.boss >= 0 ? "top-[24%]" : "top-[17%]"}`}>
        {hud.banner && (
          <div key={hud.banner.id} className="pop flex flex-col items-center gap-2">
            <div className="ts-big text-xl sm:text-4xl" style={{ color: TONE[hud.banner.tone] }}>{hud.banner.title}</div>
            <div className="ts bg-[#0c0a10]/70 px-2 py-1 text-[7px] sm:text-[10px]">{hud.banner.sub}</div>
          </div>
        )}
        {hud.count > 0 && <div key={hud.count} className="pop ts-big mt-1 text-3xl text-[#f5c542] sm:text-5xl">{hud.count}</div>}
      </div>

      {hud.streak && (
        <div key={hud.streak.id} className="absolute inset-x-0 top-[62%] flex justify-center">
          <div className="streak ts-big text-base text-[#ff4d5e] sm:text-2xl">{hud.streak.text}</div>
        </div>
      )}

      {hud.dead && hud.phase !== "over" && (
        <div className="absolute inset-x-0 bottom-[25%] flex flex-col items-center gap-2 text-center">
          <div className="ts text-xs text-[#ff4d5e] sm:text-base">KAMU TUMBANG!</div>
          {bugs && hud.bleed >= 0 && <div className="ts bg-[#0c0a10]/70 px-2 py-1 text-[6px] text-[#8af0ff] sm:text-[8px]">TEMAN SEDANG MENUJU KAMU - BERTAHAN {hud.bleed} DETIK</div>}
          {hud.spectating && <div className="ts bg-[#0c0a10]/70 px-2 py-1 text-[6px] sm:text-[8px]">MENONTON {hud.spectating} - {hud.touch ? "TAP" : "KLIK"} UNTUK GANTI</div>}
        </div>
      )}

      {hint && (
        <div className="absolute inset-x-0 bottom-[21%] flex justify-center px-2">
          <div className="ts bg-[#0c0a10]/80 px-3 py-2 text-center text-[7px] leading-[1.9] sm:text-[9px]">
            <span className="text-[#f5c542]">WASD</span> GERAK | <span className="text-[#f5c542]">MOUSE</span> BIDIK | <span className="text-[#f5c542]">KLIK</span> TEMBAK
            <br />
            <span className="text-[#f5c542]">SPACE</span> DASH | <span className="text-[#f5c542]">1-6 / Q</span> GANTI SENJATA | <span className="text-[#f5c542]">R</span> RELOAD
            {bugs && (
              <>
                <br />
                <span className="text-[#ff6b7a]">E</span> SERANGAN RUDAL | <span className="text-[#8af0ff]">F</span> TURRET
                <br />
                MASUK RUMAH, <span className="text-[#f5c542]">DEKATI LEMARI / KULKAS</span> UNTUK MENGGELEDAH
                <br />
                BIDIK <span className="text-[#ff6b7a]">KEPALA</span> = HEADSHOT | <span className="text-[#8af0ff]">BASEBALL</span> PUKULAN KE-3 = HANTAM KEPALA
              </>
            )}
          </div>
        </div>
      )}

      {/* stratagems (bug mode) + HP + dash */}
      <div className="absolute bottom-3 left-3 flex flex-col gap-1.5">
        {bugs && hud.chat.length > 0 && (
          <div className="mb-1 flex max-w-[260px] flex-col gap-1 sm:max-w-[340px]">
            {hud.chat.map((c) => (
              <div key={c.id} className="slide-in bg-[#0c0a10]/75 px-1.5 py-1 text-[6px] leading-[1.7] sm:text-[8px]" style={{ boxShadow: `inset 2px 0 0 ${c.col}` }}>
                <span style={{ color: c.col }}>{c.who}: </span>
                <span className="text-[#e9e2d2]">{c.text}</span>
              </div>
            ))}
          </div>
        )}
        {bugs && (
          <div className="pointer-events-auto mb-1 flex gap-2">
            {[
              { key: "E", name: "RUDAL", col: "#ff6b7a" },
              { key: "F", name: "TURRET", col: "#8af0ff" },
            ].map((st, i) => {
              const ready = hud.strat[i] >= 1;
              return (
                <button key={st.key} onClick={() => onStrat(i)} className="relative flex w-[58px] flex-col items-center gap-1 overflow-hidden bg-[#0c0a10]/85 px-1 py-1.5 sm:w-[72px]" style={{ boxShadow: `0 0 0 2px #0a0a0f, 0 0 0 3px ${ready ? st.col : "#3b3848"}`, cursor: "inherit" }}>
                  <div className="absolute inset-x-0 bottom-0 opacity-30" style={{ height: `${hud.strat[i] * 100}%`, background: st.col }} />
                  <span className="relative text-[8px] sm:text-[10px]" style={{ color: ready ? st.col : "#6b6878" }}>[{st.key}]</span>
                  <span className={`relative text-[5px] sm:text-[6px] ${ready ? "text-white" : "text-white/40"}`}>{st.name}</span>
                  <span className={`relative text-[5px] ${ready ? "blink text-[#7dff9a]" : "text-white/40"}`}>{ready ? "SIAP" : `${Math.round(hud.strat[i] * 100)}%`}</span>
                </button>
              );
            })}
          </div>
        )}
        <div className="flex items-end gap-2">
          <div className={`ts text-xl sm:text-3xl ${low ? "blink text-[#ff4d5e]" : "text-[#7dff9a]"}`}>{hud.hp}</div>
          <div className="ts pb-1 text-[7px] text-white/70 sm:text-[9px]">HP</div>
        </div>
        <div className="h-2.5 w-24 bg-[#0a0a0f] p-[2px] sm:w-36" style={{ boxShadow: "0 0 0 2px #0a0a0f" }}>
          <div className="h-full" style={{ width: `${(hud.hp / MAX_HP) * 100}%`, background: low ? "#ff4d5e" : "#7dff9a" }} />
        </div>
        <div className="flex items-center gap-1.5">
          <div className="h-1.5 w-16 bg-[#0a0a0f] p-[1px] sm:w-24" style={{ boxShadow: "0 0 0 2px #0a0a0f" }}>
            <div className="h-full" style={{ width: `${hud.dash * 100}%`, background: hud.dash >= 1 ? "#8af0ff" : "#3b6b78" }} />
          </div>
          <div className={`ts text-[6px] sm:text-[7px] ${hud.dash >= 1 ? "text-[#8af0ff]" : "text-white/40"}`}>DASH</div>
        </div>
      </div>

      {/* weapon bar */}
      <div className="pointer-events-auto absolute bottom-3 left-1/2 flex -translate-x-1/2 gap-1 sm:gap-1.5">
        {WEAPON_ORDER.map((id, i) => {
          const on = id === hud.weapon;
          return (
            <button key={id} onClick={() => onSelect(i)} className={`relative flex flex-col items-center px-1 pb-1 pt-2.5 transition-transform sm:px-2 ${on ? "-translate-y-1.5 bg-[#f5c542]/25" : "bg-[#0c0a10]/80"}`} style={{ boxShadow: on ? "0 0 0 2px #0a0a0f, 0 0 0 4px #f5c542" : "0 0 0 2px #0a0a0f", cursor: "inherit" }}>
              <span className={`absolute left-1 top-0.5 text-[6px] ${on ? "text-[#f5c542]" : "text-white/50"}`}>{i + 1}</span>
              <img src={weaponIcon(id)} className={`px h-[15px] w-[39px] sm:h-[20px] sm:w-[52px] ${on ? "" : "opacity-60"}`} alt={WEAPONS[id].name} />
              <span className={`mt-1 hidden text-[6px] sm:block ${on ? "text-[#f5c542]" : "text-white/40"}`}>{WEAPONS[id].name}</span>
            </button>
          );
        })}
      </div>

      {/* ammo */}
      <div className="absolute bottom-3 right-3 flex flex-col items-end gap-1">
        <div className="ts text-[7px] text-[#f5c542] sm:text-[9px]">{w.name}</div>
        {w.melee ? (
          <div className="ts text-sm sm:text-xl">MELEE</div>
        ) : hud.reload >= 0 ? (
          <>
            <div className="ts blink text-[9px] text-[#8af0ff] sm:text-sm">RELOAD</div>
            <div className="h-2 w-20 bg-[#0a0a0f] p-[2px] sm:w-28" style={{ boxShadow: "0 0 0 2px #0a0a0f" }}>
              <div className="h-full bg-[#8af0ff]" style={{ width: `${hud.reload * 100}%` }} />
            </div>
          </>
        ) : (
          <>
            <div className="ts text-xl sm:text-3xl">
              <span className={hud.ammo === 0 ? "text-[#ff4d5e]" : ""}>{hud.ammo}</span>
              <span className="text-[9px] text-white/50 sm:text-sm">/{hud.mag}</span>
            </div>
            <div className="flex gap-[2px]">
              {Array.from({ length: hud.mag }, (_, i) => (
                <div key={i} className="h-2.5 w-1 sm:w-1.5" style={{ background: i < hud.ammo ? "#f5c542" : "#2a2732", boxShadow: "0 0 0 1px #0a0a0f" }} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

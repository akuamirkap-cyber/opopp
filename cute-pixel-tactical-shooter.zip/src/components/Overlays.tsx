import { useRef, useState } from "react";
import type { TouchEvent as RTouchEvent } from "react";
import { TEAMS } from "../game/defs";
import type { Game, MatchResult } from "../game/engine";
import { portrait } from "../game/sprites";

/* ───────────── match result ───────────── */
export function Results({ result, onAgain, onMenu }: { result: MatchResult; onAgain: () => void; onMenu: () => void }) {
  const bugs = result.game === "bugs";
  return (
    <div className="scroll-thin absolute inset-0 z-30 overflow-y-auto bg-[#0b0910]/85 font-pixel text-white">
      <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col items-center justify-center gap-6 px-4 py-6">
        <div className="pop flex flex-col items-center gap-4 text-center">
          <h1 className="ts-big text-3xl sm:text-5xl" style={{ color: result.win ? "#f5c542" : "#ff4d5e" }}>
            {bugs ? (result.win ? "BERHASIL KABUR!" : "MISI GAGAL") : result.win ? "MENANG!" : "KALAH..."}
          </h1>
          {bugs ? (
            <div className="ts mt-2 flex flex-col items-center gap-3 text-[10px] sm:text-sm">
              <span>BARANG DITEMUKAN <span className="text-[#f5c542]">{result.wave}/{result.waves}</span></span>
              <span><span className="text-[#ff9a3c]">{result.kills}</span> ZOMBIE DIBASMI</span>
            </div>
          ) : (
            <div className="ts mt-2 text-xl sm:text-3xl">
              <span style={{ color: TEAMS[0].color }}>{result.score[0]}</span>
              <span className="px-3 text-white/50">-</span>
              <span style={{ color: TEAMS[1].color }}>{result.score[1]}</span>
            </div>
          )}
          <p className="text-[8px] text-white/70 sm:text-[10px]">
            {bugs
              ? result.win ? "Helikopter lepas landas. Kalian selamat!" : "Kota ini menelan timmu. Coba lagi!"
              : result.win ? "Semua musuh berhasil dilumpuhkan. Mantap!" : "Musuh lebih gesit kali ini. Coba lagi!"}
          </p>
        </div>

        <div className={`grid w-full gap-5 ${bugs ? "max-w-md" : "sm:grid-cols-2"}`}>
          {(bugs ? [0] : [0, 1]).map((team) => (
            <section key={team} className={`panel p-3 ${team === 1 ? "panel-red" : ""}`}>
              <div className="mb-2 flex items-center justify-between text-[8px]" style={{ color: TEAMS[team].color }}>
                <span>{bugs ? "SKUAD" : `TIM ${TEAMS[team].name}`}</span>
                <span className="text-white/50">K / D / DMG</span>
              </div>
              <ul className="flex flex-col gap-1.5">
                {result.rows
                  .filter((r) => r.team === team)
                  .sort((a, b) => b.kills - a.kills || b.dmg - a.dmg)
                  .map((r) => (
                    <li key={r.name} className={`flex items-center gap-2 px-1.5 py-1 text-[8px] ${r.me ? "bg-[#f5c542]/20" : "bg-[#1a1822]"}`} style={{ boxShadow: r.me ? "0 0 0 2px #f5c542" : "none" }}>
                      <img src={portrait(r.skin, bugs ? 2 : team)} alt="" className="px h-[33px] w-6 flex-none" />
                      <span className="min-w-0 flex-1 truncate">
                        {r.name}
                        {r.name === result.mvp && <span className="ml-2 bg-[#f5c542] px-1 py-0.5 text-[6px] text-[#0a0a0f]">MVP</span>}
                      </span>
                      <span className="flex-none tabular-nums text-white/85">
                        {r.kills} / {r.deaths} / {r.dmg}
                      </span>
                    </li>
                  ))}
              </ul>
            </section>
          ))}
        </div>

        <div className="flex gap-5 pb-2">
          <button className="btn px-5 py-3 text-xs sm:text-sm" onClick={onAgain}>MAIN LAGI</button>
          <button className="btn btn-dark px-5 py-3 text-xs sm:text-sm" onClick={onMenu}>MENU</button>
        </div>
      </div>
    </div>
  );
}

/* ───────────── pause ───────────── */
export function Pause({ muted, onResume, onMute, onQuit }: { muted: boolean; onResume: () => void; onMute: () => void; onQuit: () => void }) {
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0b0910]/80 font-pixel text-white">
      <div className="panel flex w-64 flex-col items-stretch gap-4 p-5 text-center">
        <h2 className="ts-big mb-3 text-2xl text-[#f5c542]">PAUSE</h2>
        <button className="btn px-3 py-3 text-xs" onClick={onResume}>LANJUT</button>
        <button className="btn btn-dark px-3 py-3 text-[10px]" onClick={onMute}>SUARA: {muted ? "OFF" : "ON"}</button>
        <button className="btn btn-dark mb-1.5 px-3 py-3 text-[10px]" onClick={onQuit}>KELUAR KE MENU</button>
      </div>
    </div>
  );
}

/* ───────────── touch controls (twin stick) ───────────── */
const R = 46;

function Stick({ side, label, onChange }: { side: "left" | "right"; label: string; onChange: (x: number, y: number, active: boolean) => void }) {
  const id = useRef<number | null>(null);
  const origin = useRef({ x: 0, y: 0 });
  const [st, setSt] = useState<{ ox: number; oy: number; x: number; y: number } | null>(null);

  const start = (e: RTouchEvent) => {
    if (id.current !== null) return;
    const t = e.changedTouches[0];
    id.current = t.identifier;
    origin.current = { x: t.clientX, y: t.clientY };
    setSt({ ox: t.clientX, oy: t.clientY, x: 0, y: 0 });
    onChange(0, 0, true);
  };
  const move = (e: RTouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      const t = e.changedTouches[i];
      if (t.identifier !== id.current) continue;
      let dx = t.clientX - origin.current.x, dy = t.clientY - origin.current.y;
      const l = Math.hypot(dx, dy);
      if (l > R) { dx = (dx / l) * R; dy = (dy / l) * R; }
      setSt({ ox: origin.current.x, oy: origin.current.y, x: dx, y: dy });
      onChange(dx / R, dy / R, true);
    }
  };
  const end = (e: RTouchEvent) => {
    for (let i = 0; i < e.changedTouches.length; i++) {
      if (e.changedTouches[i].identifier !== id.current) continue;
      id.current = null;
      setSt(null);
      onChange(0, 0, false);
    }
  };

  return (
    <div className={`absolute bottom-0 top-[28%] ${side === "left" ? "left-0 right-1/2" : "left-1/2 right-0"}`} style={{ touchAction: "none" }} onTouchStart={start} onTouchMove={move} onTouchEnd={end} onTouchCancel={end}>
      {st ? (
        <div className="pointer-events-none fixed" style={{ left: st.ox - R, top: st.oy - R, width: R * 2, height: R * 2 }}>
          <div className="absolute inset-0 rounded-full border-2 border-white/40 bg-black/25" />
          <div className="absolute h-10 w-10 rounded-full border-2 border-[#0a0a0f]" style={{ left: R - 20 + st.x, top: R - 20 + st.y, background: side === "left" ? "#e9e2d2" : "#f5c542" }} />
        </div>
      ) : (
        <div className={`pointer-events-none absolute bottom-20 flex h-20 w-20 items-center justify-center rounded-full border-2 border-dashed border-white/25 text-[6px] text-white/40 ${side === "left" ? "left-8" : "right-8"}`}>{label}</div>
      )}
    </div>
  );
}

export function TouchControls({ game }: { game: Game }) {
  return (
    <div className="absolute inset-0 z-[15] select-none font-pixel">
      <Stick side="left" label="GERAK" onChange={(x, y, a) => game.setTouchMove(a ? x : 0, a ? y : 0)} />
      <Stick side="right" label="BIDIK" onChange={(x, y, a) => game.setTouchAim(x, y, a, a && Math.hypot(x, y) > 0.4)} />
      <div className="absolute right-2 top-[30%] flex flex-col gap-3">
        {(["dash", "next", "reload"] as const).map((a) => (
          <button key={a} className="btn btn-dark px-2 py-2.5 text-[7px]" style={{ touchAction: "none" }} onTouchStart={(e) => { e.stopPropagation(); game.action(a); }}>
            {a === "dash" ? "DASH" : a === "next" ? "GANTI" : "RELOAD"}
          </button>
        ))}
      </div>
    </div>
  );
}

import type { ReactNode } from "react";
import { DIFFS, SKINS, SURVIVORS, WEAPONS, WEAPON_ORDER, WIN_ROUNDS } from "../game/defs";
import type { DiffId, GameMode, WeatherId } from "../game/defs";
import { PERSONA } from "../game/talk";
import { portrait, weaponIcon } from "../game/sprites";

const SKIN_TAG = ["NINJA", "TANK", "VISOR", "TENGKORAK", "BAYANGAN"];
const KEYS: [string, string][] = [
  ["WASD", "Gerak"],
  ["MOUSE", "Bidik"],
  ["KLIK KIRI", "Tembak / tebas"],
  ["SPACE", "Dash (kebal sesaat)"],
  ["1-6 / SCROLL / Q", "Ganti senjata"],
  ["R", "Reload"],
  ["E / F", "Rudal / turret (mode zombie)"],
  ["ESC", "Pause"],
];

function Panel({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`panel p-3 sm:p-4 ${className}`}>
      <h2 className="mb-3 text-[9px] text-[#f5c542] sm:text-[10px]">
        <span className="text-[#ff4d5e]">//</span> {title}
      </h2>
      {children}
    </section>
  );
}

interface Props {
  skin: number;
  setSkin: (s: number) => void;
  diff: DiffId;
  setDiff: (d: DiffId) => void;
  mode: GameMode;
  setMode: (m: GameMode) => void;
  weather: WeatherId;
  setWeather: (w: WeatherId) => void;
  onPlay: () => void;
}

const SKY: [WeatherId, string][] = [["auto", "DINAMIS"], ["rain", "HUJAN DERAS"], ["fog", "KABUT"], ["clear", "CERAH"]];

export function Menu({ skin, setSkin, diff, setDiff, mode, setMode, weather, setWeather, onPlay }: Props) {
  const bugs = mode === "bugs";
  return (
    <div className="scroll-thin absolute inset-0 z-20 overflow-y-auto font-pixel text-white" style={{ background: "radial-gradient(ellipse at center, rgba(11,9,16,0.5) 0%, rgba(11,9,16,0.86) 85%)" }}>
      <div className="mx-auto flex min-h-full w-full max-w-5xl flex-col items-center justify-center gap-4 px-4 py-3">
        <header className="flex flex-col items-center text-center">
          <div className="mb-3 bg-[#ff4d5e] px-2 py-1 text-[7px] text-[#0a0a0f] sm:text-[9px]">{bugs ? "CO-OP 4 PENYINTAS - KABUR DARI KOTA ZOMBIE" : "5 VS 5 - TEAM ELIMINATION"}</div>
          <h1 className="ts-big text-3xl leading-tight text-[#f5c542] sm:text-4xl lg:text-6xl">
            CHIBI <span className="text-white">STRIKE</span>
          </h1>
          <p className="ts mt-4 text-[8px] text-[#e9e2d2] sm:text-[10px]">MINI WARFARE - TAKTIS TAPI IMUT</p>
        </header>

        <div className="grid w-full gap-5 md:grid-cols-2">
          <div className="flex flex-col gap-5">
            <Panel title={bugs ? "PILIH PENYINTAS" : "PILIH OPERATOR"}>
              <div className="grid grid-cols-5 gap-2">
                {(bugs ? SURVIVORS : SKINS).map((name, i) => {
                  const on = i === skin;
                  return (
                    <button key={name} onClick={() => setSkin(i)} className={`flex cursor-pointer flex-col items-center gap-1.5 px-1 py-2 ${on ? "bg-[#f5c542]/20" : "bg-[#1a1822] hover:bg-[#262330]"}`} style={{ boxShadow: on ? "0 0 0 2px #f5c542" : "0 0 0 2px #0a0a0f" }}>
                      <img src={portrait(i, bugs ? 2 : 0)} alt={name} className={`px h-[44px] w-8 sm:h-[66px] sm:w-12 ${on ? "hop" : "opacity-70"}`} />
                      <span className={`text-[6px] sm:text-[8px] ${on ? "text-[#f5c542]" : "text-white/70"}`}>{name}</span>
                      <span className="hidden text-[5px] text-white/40 sm:block">{bugs ? PERSONA[i].trait : SKIN_TAG[i]}</span>
                    </button>
                  );
                })}
              </div>
            </Panel>

            <Panel title="TINGKAT KESULITAN">
              <div className="grid grid-cols-3 gap-3 pb-1.5">
                {(Object.keys(DIFFS) as DiffId[]).map((d) => (
                  <button key={d} onClick={() => setDiff(d)} className={`btn px-1 py-2.5 text-[8px] sm:text-[10px] ${d === diff ? "btn-on" : "btn-dark"}`}>
                    {DIFFS[d].label}
                  </button>
                ))}
              </div>
            </Panel>

            {bugs && (
              <Panel title="CUACA">
                <div className="grid grid-cols-4 gap-2 pb-1.5">
                  {SKY.map(([id, label]) => (
                    <button key={id} onClick={() => setWeather(id)} className={`btn px-0.5 py-2.5 text-[6px] sm:text-[8px] ${id === weather ? "btn-on" : "btn-dark"}`}>
                      {label}
                    </button>
                  ))}
                </div>
              </Panel>
            )}

            <button onClick={onPlay} className="btn mx-1 mb-2 px-4 py-4 text-sm sm:text-lg">
              <span className="blink">&gt;</span> {bugs ? "MASUK KE KOTA" : "MULAI MATCH"}
            </button>
          </div>

          <div className="flex flex-col gap-5">
            <Panel title="PILIH MODE" className="panel-red">
              <div className="grid grid-cols-2 gap-3 pb-1.5">
                <button onClick={() => setMode("pvp")} className={`btn flex flex-col items-center gap-1.5 px-1 py-2.5 ${!bugs ? "btn-on" : "btn-dark"}`}>
                  <span className="text-[8px] sm:text-[10px]">DUEL TIM</span>
                  <span className="text-[6px] opacity-70">5 VS 5</span>
                </button>
                <button onClick={() => setMode("bugs")} className={`btn flex flex-col items-center gap-1.5 px-1 py-2.5 ${bugs ? "btn-on" : "btn-dark"}`}>
                  <span className="text-[8px] sm:text-[10px]">KOTA ZOMBIE</span>
                  <span className="text-[6px] opacity-70">CO-OP MISI KABUR</span>
                </button>
              </div>
              {bugs ? (
                <p className="mt-3 text-[7px] leading-[2] text-[#e9e2d2] sm:text-[8px]">
                  Jelajahi <span className="text-[#f5c542]">rumah besar dua lantai & minimarket</span> untuk cari <span className="text-[#5ff0e0]">baterai</span>,{" "}
                  <span className="text-[#ff6b7a]">bensin</span>, dan <span className="text-[#ffb347]">suar</span>. Bawa ke{" "}
                  <span className="text-[#7dff9a]">zona evac</span>, panggil helikopter, bertahan, lalu kabur! Temanmu punya sifat sendiri: mereka ngobrol, khawatir, dan saling menolong.
                </p>
              ) : (
                <p className="mt-3 text-[7px] leading-[2] text-[#e9e2d2] sm:text-[8px]">
                  Lumpuhkan <span className="text-[#ff4d5e]">semua musuh</span> untuk menang ronde. Tim pertama yang menang{" "}
                  <span className="text-[#f5c542]">{WIN_ROUNDS} ronde</span> jadi juara. Sekali tumbang, tunggu ronde berikutnya!
                </p>
              )}
            </Panel>

            <Panel title="ARSENAL">
              <ul className="flex flex-col gap-2">
                {WEAPON_ORDER.map((id, i) => (
                  <li key={id} className="flex items-center gap-3">
                    <span className="w-3 text-[8px] text-[#f5c542]">{i + 1}</span>
                    <img src={weaponIcon(id)} alt="" className="px h-[20px] w-[52px] flex-none" />
                    <div className="flex min-w-0 flex-col gap-1">
                      <span className="text-[8px] text-white">{WEAPONS[id].name}</span>
                      <span className="text-[6px] leading-[1.7] text-white/55 sm:text-[7px]">{WEAPONS[id].desc}</span>
                    </div>
                  </li>
                ))}
              </ul>
            </Panel>

          </div>

          <Panel title="KONTROL" className="md:col-span-2">
            <ul className="flex flex-wrap gap-x-5 gap-y-2.5">
              {KEYS.map(([k, v]) => (
                <li key={k} className="flex items-center gap-2 text-[7px]">
                  <span className="flex-none bg-[#23212c] px-1.5 py-1 text-[#f5c542]" style={{ boxShadow: "0 0 0 1px #0a0a0f, 0 2px 0 1px #3b3848" }}>{k}</span>
                  <span className="text-white/70">{v}</span>
                </li>
              ))}
              <li className="flex items-center text-[7px] text-white/40">Di HP: stik kiri gerak, stik kanan bidik + tembak</li>
            </ul>
          </Panel>
        </div>
      </div>
    </div>
  );
}

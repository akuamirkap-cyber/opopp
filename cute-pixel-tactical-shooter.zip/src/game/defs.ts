export const TILE = 16;
/** how many px wall tops are lifted to fake the 3/4 RPG perspective */
export const RAISE = 8;
export const WIN_ROUNDS = 4;
export const ROUND_TIME = 90;
export const TEAM_SIZE = 5;
export const MAX_HP = 100;

export type WeaponId = "sniper" | "shotgun" | "pistol" | "bazooka" | "karambit" | "bat";
export const WEAPON_ORDER: WeaponId[] = ["sniper", "shotgun", "pistol", "bazooka", "karambit", "bat"];

export interface WeaponDef {
  id: WeaponId;
  name: string;
  desc: string;
  melee: boolean;
  dmg: number;
  cd: number;
  mag: number;
  reload: number;
  speed: number;
  spread: number;
  pellets: number;
  life: number;
  pierce: boolean;
  kick: number;
  shake: number;
  moveMul: number;
  knock: number;
  /** distance from grip to muzzle in sprite px */
  len: number;
  tail: number;
  // melee only
  range: number;
  arc: number;
  lunge: number;
  swing: number;
}

const gun = { melee: false, range: 0, arc: 0, lunge: 0, swing: 0 };
const blade = { melee: true, mag: 0, reload: 0, speed: 0, spread: 0, pellets: 0, life: 0, pierce: false, kick: 0, len: 8, tail: 0 };

export const WEAPONS: Record<WeaponId, WeaponDef> = {
  sniper: {
    ...gun, id: "sniper", name: "SNIPER", desc: "Sekali kena langsung KO. Peluru tembus musuh.",
    dmg: 100, cd: 0.7, mag: 4, reload: 1.3, speed: 1300, spread: 0, pellets: 1, life: 0.45, pierce: true,
    kick: 9, shake: 5, moveMul: 0.85, knock: 260, len: 19, tail: 30,
  },
  shotgun: {
    ...gun, id: "shotgun", name: "SHOTGUN", desc: "7 peluru sekaligus. Ganas di jarak dekat.",
    dmg: 14, cd: 0.42, mag: 6, reload: 1.0, speed: 500, spread: 0.2, pellets: 7, life: 0.27, pierce: false,
    kick: 7, shake: 4, moveMul: 0.96, knock: 50, len: 12, tail: 6,
  },
  pistol: {
    ...gun, id: "pistol", name: "PISTOL", desc: "Rentetan cepat dan akurat. Serba bisa.",
    dmg: 22, cd: 0.1, mag: 14, reload: 0.7, speed: 580, spread: 0.05, pellets: 1, life: 0.8, pierce: false,
    kick: 2.2, shake: 1.4, moveMul: 1, knock: 50, len: 8, tail: 8,
  },
  bazooka: {
    ...gun, id: "bazooka", name: "BAZOOKA", desc: "Roket meledak sapu banyak musuh. Awas kena sendiri!",
    dmg: 105, cd: 0.45, mag: 1, reload: 1.5, speed: 170, spread: 0, pellets: 1, life: 1.6, pierce: false,
    kick: 13, shake: 7, moveMul: 0.8, knock: 340, len: 14, tail: 0,
  },
  karambit: {
    ...blade, id: "karambit", name: "KARAMBIT", desc: "Kombo 3 tebasan: yang ke-3 berputar! Belakang = 3x.",
    dmg: 50, cd: 0.2, shake: 2, moveMul: 1.22, knock: 70, range: 30, arc: 2.5, lunge: 170, swing: 0.18,
  },
  bat: {
    ...blade, id: "bat", name: "BASEBALL", desc: "Kombo 3 pukulan: yang ke-3 hantam kepala! Mantulin peluru.",
    dmg: 65, cd: 0.38, shake: 4, moveMul: 1.1, knock: 380, range: 36, arc: 2.9, lunge: 90, swing: 0.26,
  },
};

export type BugKind = "scav" | "warrior" | "spitter" | "charger" | "titan" | "dog";
/** weather of the zombie city: changing with the mission, or locked */
export type WeatherId = "auto" | "rain" | "fog" | "clear";
export type GameMode = "pvp" | "bugs";
/** anything that can hurt: a weapon, an explosion or a bug */
export type Hurt = WeaponId | "boom" | "bug";

export const TEAMS = [
  { name: "GOLD", color: "#f5c542", dark: "#a97a1c", bullet: "#ffe58a" },
  { name: "CRIMSON", color: "#ff4d5e", dark: "#9c1f33", bullet: "#ff9aa5" },
];

export const SKINS = ["VIPER", "BRICK", "ONI", "GHOST", "SHADE"];
/** civilians of the zombie mode */
export const SURVIVORS = ["JAKA", "SARI", "BIMO", "NADIA", "BARA"];
export const ENEMY_NAMES = ["RAZOR", "MAMBA", "KOBRA", "HYENA", "JACKAL"];

export type DiffId = "easy" | "normal" | "hard";
export interface Difficulty {
  id: DiffId;
  label: string;
  react: number;
  aimErr: number;
  dmgMul: number;
  dodge: number;
}
export const DIFFS: Record<DiffId, Difficulty> = {
  easy: { id: "easy", label: "SANTAI", react: 0.6, aimErr: 0.24, dmgMul: 0.42, dodge: 0 },
  normal: { id: "normal", label: "NORMAL", react: 0.4, aimErr: 0.14, dmgMul: 0.6, dodge: 0.5 },
  hard: { id: "hard", label: "BRUTAL", react: 0.24, aimErr: 0.07, dmgMul: 0.9, dodge: 1 },
};

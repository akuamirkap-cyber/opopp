type Cv = HTMLCanvasElement;
type Ctx = CanvasRenderingContext2D;

export interface Weather { dark: number; fog: number; rain: number; bolt: number; name: string }

const rand = Math.random;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

function canvas(w: number, h: number): [Cv, Ctx] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!];
}

function radial(r: number, g: number, b: number, a0: number): Cv {
  const [c, x] = canvas(64, 64);
  const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, `rgba(${r},${g},${b},${a0})`);
  gr.addColorStop(0.45, `rgba(${r},${g},${b},${a0 * 0.7})`);
  gr.addColorStop(1, `rgba(${r},${g},${b},0)`);
  x.fillStyle = gr;
  x.fillRect(0, 0, 64, 64);
  return c;
}

/**
 * Night, flashlights, drifting fog, acid rain and lightning for the alien planet.
 * Darkness lives on its own canvas; lights punch holes into it.
 */
export class Atmosphere {
  cur: Weather = { dark: 0.6, fog: 0.25, rain: 0, bolt: 0.02, name: "MALAM" };
  flash = 0;
  /** set when thunder should be heard; the engine consumes it */
  thunder = false;
  private W = 480;
  private H = 270;
  private lc: Cv;
  private lx: Ctx;
  private glow = radial(255, 255, 255, 1);
  private cone: Cv;
  private fogTex: Cv;
  private tints: Record<string, Cv> = {
    b: radial(70, 120, 255, 0.6), y: radial(255, 190, 60, 0.6), m: radial(255, 95, 210, 0.55), c: radial(95, 240, 224, 0.5), o: radial(255, 122, 60, 0.6), r: radial(255, 48, 48, 0.6), g: radial(140, 255, 90, 0.55), w: radial(255, 240, 200, 0.5),
  };
  private flick = 0;
  private thunderT = -1;
  private bolt: number[] = [];
  private boltLife = 0;
  private drops: number[] = [];

  constructor() {
    [this.lc, this.lx] = canvas(this.W, this.H);
    // flashlight cone: stacked wedges give a soft edge without ctx.filter
    const [cc, cx] = canvas(160, 160);
    for (let k = 0; k < 8; k++) {
      const half = 0.52 - k * 0.036;
      const gr = cx.createRadialGradient(0, 80, 0, 0, 80, 160);
      gr.addColorStop(0, "rgba(255,255,255,0.24)");
      gr.addColorStop(0.6, "rgba(255,255,255,0.16)");
      gr.addColorStop(1, "rgba(255,255,255,0)");
      cx.fillStyle = gr;
      cx.beginPath();
      cx.moveTo(0, 80);
      cx.arc(0, 80, 160, -half, half);
      cx.closePath();
      cx.fill();
    }
    this.cone = cc;
    // tileable chunky fog texture
    const [fc, fx] = canvas(128, 128);
    const img = fx.createImageData(128, 128), d = img.data;
    const W8 = [[1, 0, 0.5, 0.3], [0, 1, 0.5, 1.9], [1, 1, 0.4, 4.1], [2, -1, 0.3, 2.2], [-1, 2, 0.3, 5.3], [3, 1, 0.2, 0.7], [1, 3, 0.2, 3.3], [2, 2, 0.15, 1.1]];
    for (let y = 0; y < 128; y += 2)
      for (let x = 0; x < 128; x += 2) {
        let v = 0;
        for (const w of W8) v += w[2] * Math.sin((Math.PI * 2 * (w[0] * x + w[1] * y)) / 128 + w[3]);
        const a = Math.round(clamp((v / 2.55 + 0.18) * 0.95, 0, 1) * 4) / 4;
        for (let j = 0; j < 2; j++)
          for (let i = 0; i < 2; i++) {
            const o = ((y + j) * 128 + x + i) * 4;
            d[o] = 172; d[o + 1] = 196; d[o + 2] = 228; d[o + 3] = a * 190;
          }
      }
    fx.putImageData(img, 0, 0);
    this.fogTex = fc;
  }

  resize(W: number, H: number) {
    this.W = W;
    this.H = H;
    this.lc.width = W;
    this.lc.height = H;
    this.drops = [];
    for (let i = 0; i < 260; i++) this.drops.push(rand() * (W + 80), rand() * H);
  }

  update(dt: number, target: Weather) {
    const c = this.cur, k = 1 - Math.exp(-dt * 0.9);
    c.dark += (target.dark - c.dark) * k;
    c.fog += (target.fog - c.fog) * k;
    c.rain += (target.rain - c.rain) * k;
    c.bolt = target.bolt;
    c.name = target.name;
    const d = this.drops;
    for (let i = 0; i < d.length; i += 2) {
      d[i] -= (120 + 70 * c.rain) * dt;
      d[i + 1] += (430 + 110 * c.rain) * dt;
      if (d[i + 1] > this.H) { d[i + 1] -= this.H + 8; d[i] = rand() * (this.W + 80); }
    }
    this.flash *= Math.exp(-dt * 7);
    if (this.flick > 0 && (this.flick -= dt) <= 0) this.flash = Math.max(this.flash, 0.85);
    if (this.boltLife > 0) this.boltLife -= dt;
    if (this.thunderT > 0 && (this.thunderT -= dt) <= 0) this.thunder = true;
    if (rand() < c.bolt * dt) this.strike();
  }

  strike() {
    this.flash = 1;
    this.flick = 0.11;
    this.thunderT = 0.2 + rand() * 0.5;
    this.boltLife = 0.13;
    let x = this.W * (0.1 + rand() * 0.8), y = 0;
    const end = this.H * (0.35 + rand() * 0.5);
    this.bolt = [x, y];
    while (y < end) {
      x += (rand() - 0.5) * 26;
      y += 8 + rand() * 16;
      this.bolt.push(x, y);
    }
  }

  /** fog banks and rain, drawn over the world but under the darkness */
  weather(ctx: Ctx, cl: number, ct: number, t: number) {
    const f = this.cur.fog, W = this.W, H = this.H;
    if (f > 0.02) {
      const mod = (v: number, m: number) => ((v % m) + m) % m;
      ctx.globalAlpha = Math.min(0.62, f * 0.5);
      let ox = -mod(cl + t * 15, 128), oy = -mod(ct + t * 5, 128);
      for (let x = ox; x < W; x += 128) for (let y = oy; y < H; y += 128) ctx.drawImage(this.fogTex, x, y);
      ctx.globalAlpha = Math.min(0.5, f * 0.38);
      ox = -mod(cl * 0.8 - t * 10, 256); oy = -mod(ct * 0.8 + t * 8, 256);
      for (let x = ox; x < W; x += 256) for (let y = oy; y < H; y += 256) ctx.drawImage(this.fogTex, x, y, 256, 256);
      ctx.globalAlpha = 1;
    }
    const r = this.cur.rain;
    if (r > 0.03) {
      const d = this.drops, n = (((d.length / 2) * Math.min(1, Math.pow(r / 2, 1.6))) | 0) * 2, heavy = r > 1.3, len = heavy ? 7 : 5;
      ctx.fillStyle = heavy ? "rgba(200,220,255,0.55)" : "rgba(190,212,255,0.5)";
      for (let i = 0; i < n; i += 2) {
        const x = d[i] | 0, y = d[i + 1] | 0;
        ctx.fillRect(x, y, 1, len);
        ctx.fillRect(x - 1, y + len, 1, 3);
        if (heavy) ctx.fillRect(x - 2, y + len + 3, 1, 2);
      }
      // splashes where the drops hit the ground
      ctx.fillStyle = "rgba(215,230,255,0.6)";
      const sp = heavy ? n / 3 : n / 6;
      for (let i = 0; i < sp; i++) {
        const x = (rand() * W) | 0, y = (rand() * H) | 0;
        ctx.fillRect(x, y, 2, 1);
        if (heavy && i % 2) { ctx.fillRect(x - 1, y - 1, 1, 1); ctx.fillRect(x + 2, y - 1, 1, 1); }
      }
      if (heavy) {
        // a sheet of water in the air
        ctx.fillStyle = "rgba(170,190,230,0.07)";
        ctx.fillRect(0, 0, W, H);
      }
    }
  }

  /** start a darkness pass */
  begin() {
    const x = this.lx;
    x.globalCompositeOperation = "source-over";
    x.globalAlpha = 1;
    x.clearRect(0, 0, this.W, this.H);
    x.fillStyle = `rgba(7,4,20,${(this.cur.dark * (1 - 0.85 * this.flash)).toFixed(3)})`;
    x.fillRect(0, 0, this.W, this.H);
    x.globalCompositeOperation = "destination-out";
  }

  /** round light at screen position */
  light(x: number, y: number, r: number, a = 1) {
    if (a <= 0.01 || x < -r || y < -r || x > this.W + r || y > this.H + r) return;
    this.lx.globalAlpha = a > 1 ? 1 : a;
    this.lx.drawImage(this.glow, x - r, y - r, r * 2, r * 2);
  }

  /** flashlight cone */
  beam(x: number, y: number, ang: number, len: number, a = 1) {
    const c = this.lx;
    c.save();
    c.translate(x, y);
    c.rotate(ang);
    c.globalAlpha = a > 1 ? 1 : a;
    c.drawImage(this.cone, 0, -len / 2, len, len);
    c.restore();
  }

  /** run light draws clipped to a screen-space polygon, so walls cast shadows */
  clip(poly: number[], fn: () => void) {
    const c = this.lx;
    c.save();
    c.beginPath();
    c.moveTo(poly[0], poly[1]);
    for (let i = 2; i < poly.length; i += 2) c.lineTo(poly[i], poly[i + 1]);
    c.closePath();
    c.clip();
    fn();
    c.restore();
  }

  /** black out everything outside a screen rectangle (you are indoors: the street is out of sight) */
  shade(x0: number, y0: number, x1: number, y1: number, a: number) {
    const c = this.lx, W = this.W, H = this.H;
    c.globalCompositeOperation = "source-over";
    c.globalAlpha = 1;
    c.fillStyle = `rgba(5,3,12,${a.toFixed(3)})`;
    if (y0 > 0) c.fillRect(0, 0, W, y0);
    if (y1 < H) c.fillRect(0, y1, W, H - y1);
    if (x0 > 0) c.fillRect(0, y0, x0, y1 - y0);
    if (x1 < W) c.fillRect(x1, y0, W - x1, y1 - y0);
    c.globalCompositeOperation = "destination-out";
  }

  /** composite the darkness (and lightning) onto the frame */
  end(ctx: Ctx) {
    ctx.drawImage(this.lc, 0, 0);
    if (this.flash > 0.02) {
      ctx.fillStyle = `rgba(205,225,255,${(0.16 * this.flash).toFixed(3)})`;
      ctx.fillRect(0, 0, this.W, this.H);
    }
    if (this.boltLife > 0) {
      const b = this.bolt;
      for (let pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass ? "#ffffff" : "rgba(170,200,255,0.6)";
        ctx.lineWidth = pass ? 1.5 : 4;
        ctx.beginPath();
        ctx.moveTo(b[0], b[1]);
        for (let i = 2; i < b.length; i += 2) ctx.lineTo(b[i], b[i + 1]);
        ctx.stroke();
      }
    }
  }

  /** coloured additive glow (bioluminescence, alarms, eyes) */
  tint(ctx: Ctx, x: number, y: number, r: number, key: string, a: number) {
    if (a <= 0.01 || x < -r || y < -r || x > this.W + r || y > this.H + r) return;
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = a > 1 ? 1 : a;
    ctx.drawImage(this.tints[key], x - r, y - r, r * 2, r * 2);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }
}

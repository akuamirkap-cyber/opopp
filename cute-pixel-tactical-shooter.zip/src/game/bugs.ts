import { TILE, WEAPONS, WEAPON_ORDER } from "./defs";
import type { BugKind, Hurt, WeaponDef, WeatherId } from "./defs";
import { CRATES, HOUSES, MH, MW, NESTS, PAD, blockAt, findPath, houseAtPx, kindAt, los, portalAt, roomAtPx, solidAt, walkClear } from "./map";
import { zombieSprites } from "./city";
import { drawText } from "./sprites";
import type { Bullet, Fighter, Game, Sortable } from "./engine";
import type { Atmosphere, Weather } from "./atmo";

const STRAT_CD = [16, 34];
const POD_T = 0.5;
const SEARCH_T = 0.85;
/** the three things needed to call the evac helicopter */
export const ITEMS = [
  { name: "BATERAI", col: "#5ff0e0" },
  { name: "BENSIN", col: "#ff6b7a" },
  { name: "SUAR", col: "#ffb347" },
];
const GOAL = ["GELEDAH RUMAH BERTANDA", "KEMBALI KE ZONA EVAC", "BERTAHAN SAMPAI HELI TIBA", "NAIK HELIKOPTER!"];

export const BUG: Record<BugKind, { name: string; hp: number; speed: number; dmg: number; r: number; cd: number; mass: number; heart: number }> = {
  scav: { name: "ZOMBIE", hp: 45, speed: 62, dmg: 9, r: 5, cd: 0.7, mass: 1, heart: 0.05 },
  warrior: { name: "PELARI", hp: 55, speed: 108, dmg: 11, r: 5, cd: 0.6, mass: 1.2, heart: 0.1 },
  spitter: { name: "PEMUNTAH", hp: 80, speed: 55, dmg: 14, r: 6, cd: 2.2, mass: 1.6, heart: 0.12 },
  charger: { name: "BRUTAL", hp: 480, speed: 50, dmg: 36, r: 9, cd: 3.2, mass: 12, heart: 1 },
  titan: { name: "MUTAN", hp: 3000, speed: 30, dmg: 30, r: 15, cd: 1.6, mass: 1e6, heart: 1 },
  dog: { name: "ANJING", hp: 34, speed: 132, dmg: 12, r: 5, cd: 1.1, mass: 0.8, heart: 0.06 },
};

/** eyes that glow in the dark: [pixel colour, tint key] */
const EYE: Record<BugKind, [string, string]> = {
  scav: ["#ffe9a0", "w"], warrior: ["#ff4a4a", "r"], spitter: ["#c8ff4a", "g"], charger: ["#ff4a4a", "r"], titan: ["#c8ff4a", "g"], dog: ["#ff4a4a", "r"],
};

/** the night gets nastier as the mission goes on */
const SKY: Weather[] = [
  { dark: 0.7, fog: 0.28, rain: 0, bolt: 0.02, name: "MALAM" },
  { dark: 0.77, fog: 0.55, rain: 0, bolt: 0.04, name: "BERKABUT" },
  { dark: 0.8, fog: 0.4, rain: 1, bolt: 0.2, name: "HUJAN BADAI" },
  { dark: 0.84, fog: 0.95, rain: 0.3, bolt: 0.06, name: "KABUT TEBAL" },
  { dark: 0.85, fog: 0.6, rain: 1.8, bolt: 0.42, name: "BADAI PETIR" },
];
/** weather locked from the menu */
const FIXED: Record<Exclude<WeatherId, "auto">, Weather> = {
  rain: { dark: 0.86, fog: 0.5, rain: 2, bolt: 0.5, name: "HUJAN DERAS" },
  fog: { dark: 0.82, fog: 1.1, rain: 0, bolt: 0.03, name: "KABUT TEBAL" },
  clear: { dark: 0.6, fog: 0.08, rain: 0, bolt: 0, name: "MALAM CERAH" },
};

/** crisp pixel line */
function pline(ctx: CanvasRenderingContext2D, x0: number, y0: number, x1: number, y1: number, w: number) {
  const dx = x1 - x0, dy = y1 - y0, n = Math.max(1, Math.round(Math.max(Math.abs(dx), Math.abs(dy)))), o = w >> 1;
  for (let i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + (dx * i) / n) - o, Math.round(y0 + (dy * i) / n) - o, w, w);
}

export interface Bug {
  id: number; kind: BugKind; team: number; x: number; y: number; vx: number; vy: number; kx: number; ky: number;
  hp: number; max: number; alive: boolean; aim: number; t: number; atk: number; t2: number; t3: number;
  state: "emerge" | "walk" | "wind" | "charge" | "stun" | "sleep" | "down"; stT: number; path: number[]; pi: number; pathT: number;
  target: Fighter | null; thinkT: number; flash: number; hit: number[]; rot: number; vrot: number; deadT: number; strafe: number; bite: number;
  /** look variant + personal speed multiplier */
  v: number; sm: number;
  /** stagger after a hit, body tilt, ragdoll height, and whether the head is still on */
  hitT: number; tilt: number; z: number; vz: number; rest: boolean; noHead: boolean;
  /** spring state of both hands, and how high a dog is in its leap */
  arm: number[]; lz: number; onStair: boolean;
}
export interface Turret { x: number; y: number; aim: number; life: number; cd: number; flash: number; by: Fighter }
export interface Pod { x: number; y: number; t: number; landed: boolean }
interface Glob { x: number; y: number; dx: number; dy: number; life: number }
interface Mortar { x: number; y: number; sx: number; sy: number; t: number; dur: number }
interface Breach { x: number; y: number; t: number; n: number }
interface Strike { x: number; y: number; t: number; n: number; beeps: number; by: Fighter; hits: number[] }
/** searchable furniture */
interface Box { x: number; y: number; house: number; looted: boolean; item: number }
interface Gib { x: number; y: number; z: number; vx: number; vy: number; vz: number; rot: number; vrot: number; kind: number; b: Bug | null; n: number }

const rand = Math.random;
const PI2 = Math.PI * 2;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const angDiff = (a: number, b: number) => {
  let d = (b - a) % PI2;
  if (d > Math.PI) d -= PI2;
  if (d < -Math.PI) d += PI2;
  return d;
};
const GOO = ["#a8202c", "#6e1420", "#d04a4a"];
const BILE = ["#c8ff4a", "#6fdc3e", "#3f9a2c"];
const RUBBLE = ["#4a4c56", "#6a6c76", "#22242b"];

/** Co-op zombie mission: search houses for three items, call the helicopter, hold out, escape. */
export class BugMode {
  bugs: Bug[] = [];
  corpses: Bug[] = [];
  globs: Glob[] = [];
  mortars: Mortar[] = [];
  pods: Pod[] = [];
  turrets: Turret[] = [];
  strikes: Strike[] = [];
  breaches: Breach[] = [];
  queue: BugKind[] = [];
  spawnT = 0;
  queueT = 0;
  breachT = 20;
  pingT = 0;
  stepT = 0;
  lastArmor = -9;
  cd = [0, 0];
  combo = 0;
  comboT = 0;
  kills = 0;
  heads = 0;
  gibs: Gib[] = [];
  boss: Bug | null = null;
  // mission state
  live = false;
  /** 0 search houses, 1 return to evac, 2 hold out, 3 board the helicopter */
  stage = 0;
  found = [false, false, false];
  boxes: Box[] = [];
  objHouses: number[] = [];
  evacT = 0;
  heliT = 0;
  bossT = -1;
  bruteT = 0;
  rotorT = 0;
  search: Box | null = null;
  searchT = 0;
  /** weather locked from the menu (null = it changes with the mission) */
  fixed: Weather | null = null;
  private mx = 0;
  private my = 0;
  private g: Game;
  private sp = zombieSprites();

  constructor(g: Game) {
    this.g = g;
  }

  reset() {
    this.bugs = []; this.corpses = []; this.globs = []; this.mortars = []; this.pods = []; this.turrets = []; this.strikes = []; this.breaches = [];
    this.queue = []; this.cd = [0, 0]; this.combo = 0; this.kills = 0; this.heads = 0; this.gibs = []; this.boss = null;
    this.live = false; this.stage = 0; this.found = [false, false, false]; this.boxes = []; this.objHouses = [];
    this.evacT = 0; this.heliT = 0; this.bossT = -1; this.search = null; this.searchT = 0;
  }

  setWeather(id: WeatherId) {
    this.fixed = id === "auto" ? null : FIXED[id];
  }

  private get padX() { return (PAD.x + PAD.w / 2) * TILE; }
  private get padY() { return (PAD.y + PAD.h / 2) * TILE; }
  private count() { return this.found.filter(Boolean).length; }

  /** mission setup: hide the items, fill the houses with sleeping dead */
  start() {
    const g = this.g;
    this.reset();
    this.boxes = CRATES.map((c) => ({ x: (c.tx + 0.5) * TILE, y: (c.ty + 0.5) * TILE, house: c.house, looted: false, item: -1 }));
    const order = HOUSES.map((_, i) => i).filter((i) => HOUSES[i].under === undefined);
    for (let i = order.length - 1; i > 0; i--) { const j = (rand() * (i + 1)) | 0; [order[i], order[j]] = [order[j], order[i]]; }
    this.objHouses = order.slice(0, 3);
    this.objHouses.forEach((h, i) => {
      const inside = this.boxes.filter((b) => (HOUSES[b.house].under ?? b.house) === h); // either floor
      if (inside.length) inside[(rand() * inside.length) | 0].item = i;
    });
    HOUSES.forEach((h, i) => {
      const obj = this.objHouses.includes(h.under ?? i), n = Math.round(((h.w - 2) * (h.h - 2)) / 46) + (obj ? 3 : 0) + ((rand() * 2) | 0);
      for (let k = 0; k < n; k++)
        for (let tries = 0; tries < 20; tries++) {
          const tx = h.x + 1 + ((rand() * (h.w - 2)) | 0), ty = h.y + 1 + ((rand() * (h.h - 2)) | 0);
          if (kindAt(tx, ty) !== 0 || portalAt(tx, ty) >= 0) continue;
          this.spawn(obj && k < 2 ? "warrior" : h.shop && k === 2 ? "spitter" : k === n - 1 && rand() < 0.5 ? "dog" : "scav", (tx + 0.5) * TILE, (ty + 0.5) * TILE, true);
          break;
        }
    });
    g.setBanner("KOTA MATI", "Cari jalan keluar dari kota ini!", "gold", 2.8);
  }

  /** the countdown is over */
  go() {
    const g = this.g;
    this.live = true;
    this.spawnT = 5;
    this.breachT = 26;
    g.setBanner("CARI 3 BARANG!", "Geledah rumah bertanda: baterai, bensin, suar", "white", 3.6);
    g.snd("start", g.cam.x, g.cam.y, 1);
    g.talk.say("start", { force: true, cd: 0, reply: "start" });
    g.hudDirty = true;
  }

  spawn(kind: BugKind, x: number, y: number, sleep = false): Bug {
    const g = this.g, info = BUG[kind];
    const hpMul = g.diff.id === "hard" ? 1.2 : g.diff.id === "easy" ? 0.85 : 1;
    const b: Bug = {
      id: g.ids++, kind, team: 1, x, y, vx: 0, vy: 0, kx: 0, ky: 0, hp: info.hp * hpMul, max: info.hp * hpMul, alive: true,
      aim: sleep ? rand() * PI2 : Math.atan2((MH * TILE) / 2 - y, (MW * TILE) / 2 - x), t: rand() * 3, atk: 0.4, t2: 3 + rand() * 2, t3: 5,
      state: sleep ? "sleep" : "emerge", stT: 0.5, path: [], pi: 0, pathT: 0, target: null, thinkT: rand() * 0.3, flash: 0, hit: [], rot: 0, vrot: 0, deadT: 0,
      strafe: rand() < 0.5 ? -1 : 1, bite: 0, hitT: 0, tilt: 0, z: 0, vz: 0, rest: false, noHead: false, arm: [0, 5, 0, 0, 0, 5, 0, 0], lz: 0, onStair: false,
      v: (rand() * 24) | 0, sm: kind === "scav" ? 0.75 + rand() * 0.55 : kind === "warrior" || kind === "spitter" || kind === "dog" ? 0.9 + rand() * 0.2 : 1,
    };
    this.bugs.push(b);
    if (sleep) return b;
    if (kind === "titan") { this.boss = b; g.shake(8, x, y); g.talk.say("boss", { force: true, cd: 5 }); }
    else if (kind === "dog") g.talk.say("dog", { cd: 45, near: b });
    else if (kind === "charger") g.talk.say("brute", { cd: 45 });
    g.puff(x, y, kind === "scav" ? 4 : 8, RUBBLE, 55, { z: 0, vz: 60, max: 0.5, size: 2, grav: 260 });
    if (rand() < 0.3) g.snd("groan", x, y, 0.9);
    return b;
  }

  /** a street hole close to the squad, but never right on top of it */
  private hole() {
    const g = this.g, p = g.player && g.player.alive ? g.player : g.fighters.find((f) => f.alive);
    if (!p) return NESTS[0];
    const at = g.gpos(p.x, p.y), d = (n: { x: number; y: number }) => Math.hypot(n.x - at[0], n.y - at[1]);
    const far = NESTS.filter((n) => d(n) > 170).sort((a, b) => d(a) - d(b));
    return far[(rand() * Math.min(3, far.length)) | 0] ?? NESTS[0];
  }

  private roll(k: number, hold: boolean): BugKind {
    const r = rand(), run = hold ? 0.28 : 0.08 + 0.08 * k, spit = hold ? 0.12 : k ? 0.04 + 0.03 * k : 0, dog = hold ? 0.13 : 0.05 + 0.04 * k;
    return r < run ? "warrior" : r < run + spit ? "spitter" : r < run + spit + dog ? "dog" : "scav";
  }

  /** an item was found: the noise brings a horde */
  private gain(i: number, b: Box) {
    const g = this.g, p = g.player;
    this.found[i] = true;
    for (const f of g.fighters) f.joy = 3;
    const k = this.count();
    g.say(b.x, b.y - 22, `${ITEMS[i].name}!`, ITEMS[i].col);
    g.rings.push({ x: b.x, y: b.y, life: 0.05, r: 26 });
    g.snd("win", b.x, b.y, 1);
    g.zoom = Math.max(g.zoom, 0.05);
    for (let n = 0; n < 7 + 4 * k; n++) this.queue.push(this.roll(k, false));
    if (k >= 2) this.queue.push("charger");
    this.queue.push("dog", "dog");
    g.talk.item(k);
    this.queueT = 2;
    this.breachT = Math.min(this.breachT, 3.5);
    if (k >= 3) {
      this.stage = 1;
      g.setBanner("SEMUA BARANG DAPAT!", "Kembali ke ZONA EVAC dan panggil helikopter", "gold", 3.6);
    } else g.setBanner(`${ITEMS[i].name} DAPAT! ${k}/3`, "Suaranya memancing GEROMBOLAN!", "gold", 3);
    if (p) g.snd("alarm", p.x, p.y, 0.8);
    g.hudDirty = true;
  }

  /** ordinary loot from cupboards, fridges and lockers */
  private loot(b: Box) {
    const g = this.g, p = g.player!;
    const r = rand();
    if (r < 0.42) {
      if (p.hp < 100) { p.hp = Math.min(100, p.hp + 40); g.say(b.x, b.y - 22, "OBAT +40", "#7dff9a"); }
      else { g.pickups.push({ x: p.x, y: p.y, t: 0.5 }); g.say(b.x, b.y - 22, "OBAT", "#7dff9a"); }
      g.snd("pick", b.x, b.y, 1);
      g.talk.say("healed", { cd: 30 });
    } else if (r < 0.66) {
      const n = this.cd[0] > this.cd[1] || this.cd[1] <= 0 ? 0 : 1;
      this.cd[n] = 0;
      g.say(b.x, b.y - 22, n ? "TURRET SIAP!" : "RUDAL SIAP!", n ? "#8af0ff" : "#ff6b7a");
      g.snd("pick", b.x, b.y, 1);
    } else {
      g.say(b.x, b.y - 22, "KOSONG", "#9a9aa8");
      g.snd("click", b.x, b.y, 1);
      if (rand() < 0.4) g.talk.say("empty", { cd: 25 });
    }
    g.hudDirty = true;
  }

  /** objectives, spawning, win / lose */
  private director(dt: number) {
    const g = this.g, p = g.player;
    if (!g.fighters.some((f) => f.alive)) { g.endMission(false); return; }
    const k = this.count(), hold = this.stage >= 2;
    const m = g.diff.id === "hard" ? 1.3 : g.diff.id === "easy" ? 0.75 : 1;
    let awake = 0;
    for (const b of this.bugs) if (b.state !== "sleep") awake++;

    // steady trickle from the street holes
    this.spawnT -= dt;
    if (this.spawnT <= 0 && awake < (hold ? 44 : Math.round((8 + 6 * k + (this.stage ? 6 : 0)) * m))) {
      const h = this.hole(), n = hold ? 2 + ((rand() * 2) | 0) : 1 + ((rand() * 2) | 0);
      for (let i = 0; i < n; i++) this.spawn(this.roll(k, hold), h.x + (rand() - 0.5) * 14, h.y + (rand() - 0.5) * 8);
      this.spawnT = (hold ? 0.6 : Math.max(1, 2.6 - 0.45 * k)) / m;
    }
    // hordes
    if (this.queue.length && (this.queueT -= dt) <= 0 && awake < 52) {
      const h = this.hole();
      this.spawn(this.queue.shift()!, h.x + (rand() - 0.5) * 14, h.y + (rand() - 0.5) * 8);
      this.queueT = 0.3;
    }
    // they tunnel up right next to the squad
    this.breachT -= dt;
    if ((k >= 1 || hold) && this.breachT <= 0 && awake < 46) {
      const live = g.fighters.filter((f) => f.alive), f = live[(rand() * live.length) | 0];
      for (let tries = 0; tries < 12 && f; tries++) {
        const a = rand() * PI2, d = 70 + rand() * 70, bx = f.x + Math.cos(a) * d, by = f.y + Math.sin(a) * d;
        if (bx < 30 || by < 30 || bx > MW * TILE - 30 || by > MH * TILE - 30 || houseAtPx(bx, by) >= 0) continue;
        if (solidAt(bx, by) || solidAt(bx + 9, by) || solidAt(bx - 9, by) || solidAt(bx, by + 7) || solidAt(bx, by - 7)) continue;
        this.breaches.push({ x: bx, y: by, t: 0, n: 3 + k + (hold ? 2 : 0) });
        g.say(bx, by - 18, "MEREKA MUNCUL!", "#ff9a3c");
        g.talk.say("breach", { cd: 22 });
        g.snd("rumble", bx, by, 1.3);
        break;
      }
      this.breachT = (hold ? 11 : 24 - 3 * k) + rand() * 8;
    }

    if (this.stage === 1) {
      if (p && p.alive && Math.abs(p.x - this.padX) < 72 && Math.abs(p.y - this.padY) < 72) {
        this.stage = 2;
        this.evacT = g.diff.id === "hard" ? 85 : g.diff.id === "easy" ? 55 : 70;
        this.bossT = 14;
        this.bruteT = 30;
        g.setBanner("HELIKOPTER DIPANGGIL!", `Bertahan ${this.evacT} detik di zona evac!`, "red", 3.6);
        g.snd("alarm", this.padX, this.padY, 1.2);
        g.talk.say("evacCall", { force: true, cd: 0 });
        g.hudDirty = true;
      }
    } else if (this.stage === 2) {
      this.evacT -= dt;
      if (this.bossT > 0 && (this.bossT -= dt) <= 0) {
        const far = NESTS.slice().sort((a, b) => Math.hypot(b.x - this.padX, b.y - this.padY) - Math.hypot(a.x - this.padX, a.y - this.padY))[(rand() * 4) | 0];
        this.spawn("titan", far.x, far.y);
        g.setBanner("MUTAN RAKSASA DATANG!", "Jangan sampai terkepung!", "red", 2.6);
        g.snd("roar", g.cam.x, g.cam.y, 1.2);
      }
      if ((this.bruteT -= dt) <= 0) { this.queue.push("charger"); this.bruteT = 24; }
      if (this.evacT <= 0) {
        this.stage = 3;
        g.setBanner("HELIKOPTER TIBA!", "Naik sekarang juga!", "gold", 3.2);
        g.snd("win", this.padX, this.padY, 1.2);
        g.talk.say("heli", { force: true, cd: 0 });
        g.hudDirty = true;
      }
    } else if (this.stage === 3 && this.heliT >= 1) {
      if (p && p.alive && Math.hypot(p.x - this.padX, p.y - this.padY) < 34) { g.talk.say("win", { force: true, cd: 0 }); g.endMission(true); }
    }
  }

  /** player stands next to unsearched furniture: rummage through it */
  private rummage(dt: number) {
    const g = this.g, p = g.player;
    let near: Box | null = null;
    if (p && p.alive && g.phase === "live") {
      const h = houseAtPx(p.x, p.y);
      if (h >= 0) {
        let bd = 19;
        for (const b of this.boxes) {
          if (b.looted || b.house !== h) continue;
          const d = Math.hypot(b.x - p.x, b.y - p.y);
          if (d < bd) { bd = d; near = b; }
        }
      }
    }
    if (near !== this.search) { this.search = near; this.searchT = 0; }
    if (!near) return;
    const before = Math.floor(this.searchT * 6);
    this.searchT += dt;
    if (Math.floor(this.searchT * 6) !== before) g.snd("click", near.x, near.y, 0.5);
    if (this.searchT >= SEARCH_T) {
      near.looted = true;
      this.search = null;
      if (near.item >= 0) this.gain(near.item, near);
      else this.loot(near);
    }
  }

  /** downed survivors bleed out unless a friend stays with them */
  private medic(dt: number) {
    const g = this.g;
    for (const f of g.fighters) {
      if (!f.down) continue;
      let helper: Fighter | null = null;
      if (f.deadT > 0.8) for (const m of g.fighters) if (m.alive && Math.hypot(m.x - f.x, m.y - f.y) < 22) { helper = m; break; }
      if (helper) {
        f.rev += dt * (helper.look === 2 && helper.skin === 1 ? 1.6 : 1); // Sari is the medic of the group
        if (f.rev >= 2) { this.revive(f, 50); g.talk.revived(f, helper); }
      } else {
        f.rev = Math.max(0, f.rev - dt);
        f.bleed -= dt;
        if (f.bleed <= 0) {
          f.down = false;
          g.say(f.x, f.y - 20, "GUGUR...", "#ff6b7a");
          g.snd("lose", f.x, f.y, 0.8);
          g.hudDirty = true;
          if (f.isPlayer) g.endMission(false);
          else g.talk.dead(f);
        }
      }
    }
  }

  private revive(f: Fighter, hp: number) {
    const g = this.g;
    f.alive = true; f.down = false; f.gone = false; f.hp = hp; f.rev = 0;
    f.vx = f.vy = f.kx = f.ky = 0;
    f.z = f.vz = f.rot = f.vrot = 0; f.rest = true;
    f.cd = f.reloadT = f.swingT = f.dashT = f.dashCd = f.tilt = f.deadT = f.hitFlash = 0;
    for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
    for (const id of WEAPON_ORDER) f.ammo[id] = WEAPONS[id].mag;
    if (f.ai) { f.ai.target = null; f.ai.path = []; f.ai.pathT = 0; }
    if (f.isPlayer) g.spec = null;
    // shove the dead away so the survivor gets a second to breathe
    for (const b of this.bugs) {
      const dx = b.x - f.x, dy = b.y - f.y, d = Math.hypot(dx, dy) || 1;
      if (d < 44) { b.kx += ((dx / d) * 260) / Math.min(BUG[b.kind].mass, 6); b.ky += ((dy / d) * 260) / Math.min(BUG[b.kind].mass, 6); b.atk = Math.max(b.atk, 0.9); }
    }
    g.say(f.x, f.y - 26, "BANGKIT!", "#7dff9a");
    g.rings.push({ x: f.x, y: f.y, life: 0.05, r: 24 });
    g.snd("pick", f.x, f.y, 1.2);
    g.hudDirty = true;
  }

  /** where a squad bot should run to: a downed friend first, otherwise back to the player if it strayed */
  rally(f: Fighter): { x: number; y: number } | null {
    const g = this.g;
    let best: Fighter | null = null, bd = 360;
    for (const m of g.fighters) {
      if (!m.down || m === f) continue;
      const d = Math.hypot(m.x - f.x, m.y - f.y);
      if (d < bd) { bd = d; best = m; }
    }
    if (best) return best;
    const p = g.player;
    return p && p.alive && Math.hypot(p.x - f.x, p.y - f.y) > 130 ? p : null;
  }

  /** everyone sleeping in the same house wakes up together */
  private wake(b: Bug) {
    const g = this.g, r = roomAtPx(b.x, b.y);
    let n = 0;
    for (const o of this.bugs) {
      if (o.state !== "sleep" || (o !== b && !(r >= 0 && roomAtPx(o.x, o.y) === r) && Math.hypot(o.x - b.x, o.y - b.y) > 64)) continue;
      o.state = "walk"; o.thinkT = 0; o.atk = 0.5 + rand() * 0.4;
      if (n++ < 2) g.say(o.x, o.y - 22, "!", "#ff6b7a");
    }
    g.snd("groan", b.x, b.y, 1.3);
    if (n > 1) g.snd("screech", b.x, b.y, 0.8);
    g.talk.say("wake", { cd: 14, near: b });
  }

  update(dt: number) {
    const g = this.g;
    if (g.phase === "live" && this.live) { this.director(dt); this.rummage(dt); this.medic(dt); }
    // helicopter
    if (this.stage >= 3) {
      this.heliT = Math.min(1, this.heliT + dt / 2.6);
      if ((this.rotorT -= dt) <= 0) { this.rotorT = 0.11; g.snd("whoosh", this.padX, this.padY, 0.5 + 0.4 * this.heliT); }
      if (this.heliT < 1 && rand() < dt * 30) g.dust(this.padX + (rand() - 0.5) * 70, this.padY + (rand() - 0.5) * 50, 1);
    }
    for (let i = this.bugs.length - 1; i >= 0; i--) this.tick(this.bugs[i], dt);
    // bodies push each other
    const bs = this.bugs;
    for (let i = 0; i < bs.length; i++) {
      const a = bs[i];
      if (a.kind === "titan" || a.state === "sleep") continue;
      const ra = BUG[a.kind].r;
      for (let j = i + 1; j < bs.length; j++) {
        const b = bs[j];
        if (b.kind === "titan") continue;
        const dx = b.x - a.x, dy = b.y - a.y, min = ra + BUG[b.kind].r;
        if (Math.abs(dx) > min || Math.abs(dy) > min) continue;
        const d = Math.hypot(dx, dy);
        if (d < min && d > 0.01) {
          const o = (min - d) / 2, nx = dx / d, ny = dy / d;
          g.slide(a, -nx * o, -ny * o);
          g.slide(b, nx * o, ny * o);
        }
      }
    }
    for (const f of g.fighters) {
      if (!f.alive) continue;
      for (const b of bs) {
        const min = BUG[b.kind].r + 4;
        const dx = f.x - b.x, dy = f.y - b.y;
        if (Math.abs(dx) > min || Math.abs(dy) > min) continue;
        const d = Math.hypot(dx, dy);
        if (d < min && d > 0.01) {
          const heavy = BUG[b.kind].mass > 5, o = min - d, nx = dx / d, ny = dy / d;
          g.slide(f, nx * o * (heavy ? 1 : 0.5), ny * o * (heavy ? 1 : 0.5));
          if (!heavy) g.slide(b, -nx * o * 0.5, -ny * o * 0.5);
        }
      }
    }
    // bodies: a short, heavy fall - then they twitch and bleed out before they become part of the floor
    for (let i = this.corpses.length - 1; i >= 0; i--) {
      const c = this.corpses[i], titan = c.kind === "titan";
      c.deadT += dt;
      this.arms(c, dt, true);
      c.t2 *= Math.exp(-dt * 10);
      if (titan && rand() < dt * 14) g.puff(c.x + (rand() - 0.5) * 40, c.y + (rand() - 0.5) * 30, 5, BILE, 90, { vz: 80, max: 0.5, size: 3, grav: 220, stamp: true });
      if (c.rest) {
        if ((c.stT -= dt) > 0) {
          // death throes: a leg kicks, an arm jerks, the pool spreads
          if (rand() < dt * 4.5) { c.t2 = 2.4; const n = rand() < 0.5 ? 0 : 4; c.arm[n + 2] += (rand() - 0.5) * 110; c.arm[n + 3] += (rand() - 0.5) * 110; }
          if ((c.t3 -= dt) <= 0) { c.t3 = 0.2; this.pool(c.x, c.y + 2, (titan ? 22 : c.kind === "charger" ? 12 : 7) * clamp(1.15 - c.stT, 0.35, 1)); }
          continue;
        }
        const fc = g.fctx;
        fc.save();
        fc.translate(c.x | 0, c.y | 0);
        fc.rotate(c.rot);
        fc.globalAlpha = 0.9;
        this.figure(fc, 0, 0, c, true, false);
        fc.restore();
        this.corpses.splice(i, 1);
        continue;
      }
      const sp = Math.hypot(c.kx, c.ky);
      if (g.slide(c, c.kx * dt, c.ky * dt, 0.25) && sp > 60) {
        // slams into a wall
        this.bleed(c.x, c.y, Math.atan2(-c.ky, -c.kx), 4, 50);
        g.snd("thunk", c.x, c.y, 0.5);
        c.vrot *= 0.4;
      }
      if (c.atk > 0) {
        // the moment before it goes down: it sways on buckling knees
        c.atk -= dt;
        c.rot = Math.sin(c.deadT * 40) * 0.07;
        const fr = Math.exp(-dt * 10);
        c.kx *= fr; c.ky *= fr;
        continue;
      }
      c.z += c.vz * dt;
      c.vz -= 620 * dt;
      c.rot += c.vrot * dt;
      if (c.z > 0) { const fr = Math.exp(-dt * 1.2); c.kx *= fr; c.ky *= fr; continue; }
      c.z = 0;
      if (c.vz < -90) {
        // lands with one dull bounce
        c.vz *= -0.2; c.kx *= 0.5; c.ky *= 0.5; c.vrot *= 0.35;
        this.bleed(c.x, c.y, Math.atan2(c.ky, c.kx), 3, 40);
        g.dust(c.x, c.y + 3, 2);
        g.snd("thunk", c.x, c.y, 0.45);
        continue;
      }
      c.vz = 0;
      const fr = Math.exp(-dt * 10);
      c.kx *= fr; c.ky *= fr;
      const flat = c.kind === "dog" ? Math.round(c.rot / Math.PI) * Math.PI : Math.round((c.rot - Math.PI / 2) / Math.PI) * Math.PI + Math.PI / 2;
      const d = flat - c.rot;
      if (Math.abs(d) > 0.04) {
        // tipping over: slowly at first, then all at once
        c.vrot += Math.sign(d) * 36 * dt;
        if (Math.sign(flat - (c.rot + c.vrot * dt)) !== Math.sign(d)) {
          c.rot = flat; c.vrot = 0; c.t2 = 2;
          g.dust(c.x, c.y + 3, 2);
          g.snd("thunk", c.x, c.y, 0.4);
          this.bleed(c.x, c.y, rand() * PI2, 2, 30);
        }
      } else { c.rot = flat; c.vrot = 0; }
      if (sp > 25 && rand() < dt * 40 && !solidAt(c.x, c.y + 3)) { g.fctx.fillStyle = "rgba(122,14,24,0.5)"; g.fctx.fillRect(c.x | 0, (c.y + 3) | 0, 3, 2); }
      if ((sp < 8 && c.rot === flat && c.deadT > (titan ? 1.3 : 0.2)) || c.deadT > 4) { c.rot = flat; c.rest = true; c.stT = titan ? 0.3 : 0.7 + rand() * 1.1; c.t3 = 0; }
    }
    // bile spit
    for (let i = this.globs.length - 1; i >= 0; i--) {
      const s = this.globs[i];
      s.life -= dt;
      let dead = s.life <= 0;
      for (let k = 0; k < 2 && !dead; k++) {
        s.x += s.dx * 100 * dt; s.y += s.dy * 100 * dt;
        if (blockAt(s.x, s.y)) dead = true;
        for (const f of g.fighters) {
          if (!f.alive || f.dashT > 0) continue;
          const dx = f.x - s.x, dy = f.y - 1 - s.y;
          if (dx * dx + dy * dy < 40) {
            g.mobName = BUG.spitter.name;
            g.damage(f, BUG.spitter.dmg, null, "bug", Math.atan2(s.dy, s.dx), 40, "", true);
            dead = true;
            break;
          }
        }
      }
      if (rand() < dt * 30) g.puff(s.x, s.y, 1, BILE, 6, { z: 4, vz: 0, max: 0.3, size: 1, grav: 60, stamp: true });
      if (dead) {
        g.puff(s.x, s.y, 6, BILE, 55, { max: 0.35, stamp: true });
        g.snd("squish", s.x, s.y, 0.6);
        this.globs.splice(i, 1);
      }
    }
    // mutant mortars
    for (let i = this.mortars.length - 1; i >= 0; i--) {
      const m = this.mortars[i];
      m.t += dt;
      if (m.t < m.dur) continue;
      g.puff(m.x, m.y, 14, BILE, 110, { vz: 70, max: 0.5, size: 3, grav: 220, stamp: true });
      g.rings.push({ x: m.x, y: m.y, life: 0.05, r: 28 });
      g.shake(4, m.x, m.y);
      g.snd("squish", m.x, m.y, 1.3);
      g.fctx.fillStyle = "rgba(63,154,44,0.45)";
      for (let k = 0; k < 10; k++) g.fctx.fillRect((m.x + (rand() - 0.5) * 34) | 0, (m.y + (rand() - 0.5) * 22) | 0, 3 + ((rand() * 6) | 0), 2 + ((rand() * 3) | 0));
      for (const f of g.fighters) {
        if (!f.alive) continue;
        const d = Math.hypot(f.x - m.x, f.y - m.y);
        if (d < 28) { g.mobName = BUG.titan.name; g.damage(f, 30 * (1 - d / 48), null, "bug", Math.atan2(f.y - m.y, f.x - m.x), 160, "", true); }
      }
      this.mortars.splice(i, 1);
    }
    // supply pods (turrets)
    for (let i = this.pods.length - 1; i >= 0; i--) {
      const p = this.pods[i];
      p.t += dt;
      if (!p.landed && p.t >= POD_T) {
        p.landed = true;
        g.shake(7, p.x, p.y);
        g.dust(p.x, p.y + 4, 10);
        g.rings.push({ x: p.x, y: p.y, life: 0.05, r: 30 });
        g.glows.push({ x: p.x, y: p.y, r: 40, life: 0.15, max: 0.15 });
        g.snd("pod", p.x, p.y, 1.2);
        this.blast(p.x, p.y, null, 34, 90, 260, "boom");
        g.fctx.fillStyle = "rgba(12,8,20,0.4)";
        for (let k = 0; k < 10; k++) g.fctx.fillRect((p.x + (rand() - 0.5) * 22) | 0, (p.y + 3 + (rand() - 0.5) * 12) | 0, 2 + ((rand() * 5) | 0), 2 + ((rand() * 2) | 0));
        this.turrets.push({ x: p.x, y: p.y, aim: g.player ? g.player.aim : 0, life: 22, cd: 0.6, flash: 0, by: g.player ?? g.fighters[0] });
      }
      if (p.t > 0.9) {
        g.puff(p.x, p.y, 6, ["#ffffff", "#c9cdd9", "#8d949e"], 30, { vz: 30, max: 0.5, size: 3, grav: -10 });
        this.pods.splice(i, 1);
      }
    }
    // sentry turrets
    for (let i = this.turrets.length - 1; i >= 0; i--) {
      const t = this.turrets[i];
      t.life -= dt; t.cd -= dt;
      if (t.flash > 0) t.flash -= dt;
      let best: Bug | null = null, bd = 190;
      for (const b of bs) {
        if (b.state === "sleep") continue;
        const d = Math.hypot(b.x - t.x, b.y - t.y);
        if (d < bd && los(t.x, t.y, b.x, b.y)) { bd = d; best = b; }
      }
      if (best) {
        const want = Math.atan2(best.y - t.y, best.x - t.x);
        t.aim += clamp(angDiff(t.aim, want), -11 * dt, 11 * dt);
        if (t.cd <= 0 && Math.abs(angDiff(t.aim, want)) < 0.2) {
          t.cd = 0.1; t.flash = 0.05;
          const a = t.aim + (rand() - 0.5) * 0.08, c = Math.cos(a), s = Math.sin(a), bx = t.x + c * 9, by = t.y + s * 9;
          g.bullets.push({ x: bx, y: by, dx: c, dy: s, speed: 620, team: 0, owner: t.by, dmg: 15, life: 0.45, max: 0.45, pierce: false, hit: [], wid: "pistol", ox: bx, oy: by, trav: 0 });
          g.glows.push({ x: bx, y: by - 5, r: 11, life: 0.06, max: 0.06 });
          g.snd("pistol", t.x, t.y, 0.5);
        }
      } else t.aim += dt * 1.2;
      if (t.life <= 0) {
        g.puff(t.x, t.y, 8, ["#ffffff", "#c9cdd9", "#f5c542"], 50, { vz: 50, max: 0.5 });
        this.turrets.splice(i, 1);
      }
    }
    // rocket strikes
    for (let i = this.strikes.length - 1; i >= 0; i--) {
      const s = this.strikes[i];
      s.t += dt;
      if (s.t < 1.2 && s.t > s.beeps * 0.24) { s.beeps++; g.snd("beep", s.x, s.y, 1); }
      while (s.n < 5 && s.t >= 1.2 + s.n * 0.13) {
        const a = rand() * PI2, r = s.n === 0 ? 0 : 14 + rand() * 24;
        const hx = s.x + Math.cos(a) * r, hy = s.y + Math.sin(a) * r * 0.8;
        g.blast(hx, hy, s.by, 50, 180, 320, "boom", false);
        s.hits.push(hx, hy, s.t);
        s.n++;
      }
      if (s.t > 2.1) this.strikes.splice(i, 1);
    }
    // the street splits open
    for (let i = this.breaches.length - 1; i >= 0; i--) {
      const br = this.breaches[i];
      br.t += dt;
      if (rand() < dt * 34) g.puff(br.x + (rand() - 0.5) * 22, br.y + (rand() - 0.5) * 12, 1, [...RUBBLE, "#ff9a3c"], 40, { z: 0, vz: 80, max: 0.5, size: 2, grav: 280 });
      if (rand() < dt * 6) g.shake(2.2, br.x, br.y);
      if (br.t < 1.6) continue;
      const fc = g.fctx;
      for (let j = -8; j <= 8; j++) {
        const w = Math.round(14 * Math.sqrt(1 - (j * j) / 64));
        fc.fillStyle = j < -4 ? "#5a5c66" : "#07070a";
        fc.fillRect((br.x - w) | 0, (br.y + j) | 0, w * 2, 1);
      }
      for (let k = 0; k < br.n; k++) this.spawn(rand() < 0.22 ? "warrior" : rand() < 0.2 ? "dog" : "scav", br.x + (rand() - 0.5) * 20, br.y + (rand() - 0.5) * 10);
      g.shake(7, br.x, br.y); g.dust(br.x, br.y, 12); g.rings.push({ x: br.x, y: br.y, life: 0.05, r: 30 });
      g.snd("groan", br.x, br.y, 1.3); g.snd("thunk", br.x, br.y, 1.2);
      this.breaches.splice(i, 1);
    }
    // flying pieces: drip, bounce, then soak into the floor
    for (let i = this.gibs.length - 1; i >= 0; i--) {
      const q = this.gibs[i];
      const nx = q.x + q.vx * dt, ny = q.y + q.vy * dt;
      if (solidAt(nx, ny)) { q.vx *= -0.4; q.vy *= -0.4; } else { q.x = nx; q.y = ny; }
      q.z += q.vz * dt;
      q.vz -= 600 * dt;
      q.rot += q.vrot * dt;
      if (q.z > 2 && rand() < dt * 22) g.puff(q.x, q.y, 1, GOO, 6, { z: q.z, vz: 0, max: 0.4, size: 1, grav: 300, stamp: true });
      if (q.z > 0) continue;
      q.z = 0;
      if (q.vz < -70 && q.n < 2) {
        q.n++;
        q.vz *= -0.42; q.vx *= 0.55; q.vy *= 0.55; q.vrot *= 0.6;
        this.bleed(q.x, q.y - 2, Math.atan2(q.vy, q.vx), 2, 30);
        if (q.kind === 0) g.snd("thunk", q.x, q.y, 0.5);
      } else {
        const fc = g.fctx;
        fc.save();
        fc.translate(q.x | 0, q.y | 0);
        fc.rotate(q.rot);
        this.drawGib(fc, q);
        fc.restore();
        this.gibs.splice(i, 1);
      }
    }
    // the dead are never quiet
    if (bs.length && rand() < dt * 0.5) { const z = bs[(rand() * bs.length) | 0]; g.snd("groan", z.x, z.y, 0.85); }
    // motion tracker: pings speed up as they close in (it also hears the ones hiding indoors)
    const pl = g.player;
    if (pl && pl.alive && bs.length) {
      this.pingT -= dt;
      if (this.pingT <= 0) {
        let nd = 1e9;
        for (const b of bs) { const d = Math.hypot(b.x - pl.x, b.y - pl.y); if (d < nd) nd = d; }
        if (nd < 330) g.snd("ping", g.cam.x, g.cam.y, 0.35 + 0.55 * clamp(1 - nd / 260, 0, 1));
        this.pingT = clamp(nd / 230, 0.17, 1.4);
      }
    }
    for (let i = 0; i < 2; i++) if (this.cd[i] > 0) { this.cd[i] -= dt; if (this.cd[i] <= 0) g.hudDirty = true; }
    if (this.comboT > 0 && (this.comboT -= dt) <= 0) this.combo = 0;
  }

  /* ───────────── zombie brains ───────────── */
  private seek(b: Bug, tx: number, ty: number, d: number, dt: number) {
    if (d < 130 && walkClear(b.x, b.y, tx, ty, 4.5)) {
      this.mx = (tx - b.x) / d; this.my = (ty - b.y) / d;
      b.pathT = 0;
      return;
    }
    b.pathT -= dt;
    if (b.pathT <= 0) { b.path = findPath(b.x, b.y, tx, ty); b.pi = 0; b.pathT = 0.6 + rand() * 0.6; }
    const p = b.path;
    while (b.pi < p.length && Math.hypot(p[b.pi] - b.x, p[b.pi + 1] - b.y) < 6) b.pi += 2;
    let gx = tx, gy = ty;
    if (b.pi < p.length) { gx = p[b.pi]; gy = p[b.pi + 1]; }
    const dx = gx - b.x, dy = gy - b.y, l = Math.hypot(dx, dy) || 1;
    this.mx = dx / l; this.my = dy / l;
  }

  private bite(b: Bug, t: Fighter, dmg: number, ang: number, knock: number) {
    const g = this.g;
    b.atk = BUG[b.kind].cd;
    b.bite = 0.18;
    b.kx += Math.cos(ang) * 50; b.ky += Math.sin(ang) * 50;
    g.mobName = BUG[b.kind].name;
    g.damage(t, dmg, null, "bug", ang, knock, "", true);
  }

  private tick(b: Bug, dt: number) {
    const g = this.g, info = BUG[b.kind];
    b.t += dt;
    if (b.flash > 0) b.flash -= dt;
    if (b.hitT > 0) b.hitT -= dt;
    b.tilt *= Math.exp(-dt * 9);
    b.lz = b.kind === "dog" && b.state === "charge" ? Math.sin(clamp(1 - b.stT / 0.34, 0, 1) * Math.PI) * 7 : 0;
    this.arms(b, dt, b.state === "down");
    if (b.state === "down") {
      // knocked flat: it lies there for a moment, then drags itself back up
      b.stT -= dt;
      b.rot += ((b.stT > 0.35 ? b.vrot * 1.5708 : 0) - b.rot) * Math.min(1, dt * (b.stT > 0.35 ? 16 : 8));
      const fd = Math.exp(-dt * 7);
      b.kx *= fd; b.ky *= fd; b.vx = b.vy = 0;
      g.slide(b, b.kx * dt, b.ky * dt);
      if (b.stT <= 0) { b.state = "walk"; b.rot = 0; b.atk = 0.4; }
      return;
    }
    if (b.state === "sleep") {
      // standing in the dark until someone comes too close
      if ((b.thinkT -= dt) > 0) return;
      b.thinkT = 0.2 + rand() * 0.15;
      const hb = houseAtPx(b.x, b.y), rb = roomAtPx(b.x, b.y);
      for (const f of g.fighters) {
        if (!f.alive) continue;
        const d = Math.hypot(f.x - b.x, f.y - b.y);
        // they notice you in the same room, up close, or when a gun goes off in the house (melee is quiet!)
        if ((rb >= 0 && roomAtPx(f.x, f.y) === rb) || (d < 58 && los(b.x, b.y, f.x, f.y))) { this.wake(b); break; }
        // heavy rain drowns out the shots
        if (hb >= 0 && f.loud > 0 && d < (g.atmo.cur.rain > 1.2 ? 100 : 190) && houseAtPx(f.x, f.y) === hb) {
          this.wake(b);
          if (f.isPlayer) g.talk.say("loud", { cd: 70 });
          break;
        }
      }
      return;
    }
    b.atk -= dt; b.t2 -= dt; b.t3 -= dt;
    if (b.bite > 0) b.bite -= dt;
    const fr = Math.exp(-dt * 8);
    b.kx *= fr; b.ky *= fr;
    if (b.state === "emerge") { b.stT -= dt; if (b.stT <= 0) b.state = "walk"; return; }
    b.thinkT -= dt;
    if (b.thinkT <= 0 || !b.target || !b.target.alive) {
      b.thinkT = 0.4 + rand() * 0.3;
      let best: Fighter | null = null, bd = 1e9;
      for (const f of g.fighters) {
        if (!f.alive) continue;
        const d = Math.hypot(f.x - b.x, f.y - b.y);
        if (d < bd) { bd = d; best = f; }
      }
      b.target = best;
    }
    const t = b.target;
    let mx = 0, my = 0;
    if (t) {
      const dx = t.x - b.x, dy = t.y - b.y, d = Math.hypot(dx, dy) || 1, nx = dx / d, ny = dy / d, ang = Math.atan2(dy, dx);
      const reach = info.r + 8;
      if (b.kind === "scav" || b.kind === "warrior") {
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        if (b.kind === "scav") { const wob = Math.sin(b.t * 7 + b.id) * 0.45, ox = mx; mx += -my * wob; my += ox * wob; }
        if (d < reach && b.atk <= 0) this.bite(b, t, info.dmg, ang, 60);
      } else if (b.kind === "spitter") {
        const see = d < 180 && los(b.x, b.y, t.x, t.y);
        if (b.state === "wind") {
          b.aim = ang;
          b.stT -= dt;
          if (b.stT <= 0) {
            b.state = "walk";
            b.atk = info.cd * (0.8 + rand() * 0.4);
            const a = ang + (rand() - 0.5) * 0.16;
            this.globs.push({ x: b.x + Math.cos(a) * 6, y: b.y - 2 + Math.sin(a) * 6, dx: Math.cos(a), dy: Math.sin(a), life: 1.3 });
            g.snd("squish", b.x, b.y, 0.9);
          }
        } else {
          if (!see) { this.seek(b, t.x, t.y, d, dt); mx = this.mx; my = this.my; }
          else if (d < 85) { mx = -nx; my = -ny; }
          else { mx = -ny * b.strafe * 0.7; my = nx * b.strafe * 0.7; if (rand() < dt * 0.5) b.strafe = -b.strafe; }
          if (see && b.atk <= 0) { b.state = "wind"; b.stT = 0.45; }
        }
      } else if (b.kind === "dog") {
        if (b.state === "wind") {
          // crouch... then pounce
          b.stT -= dt;
          b.aim = ang;
          b.vx = b.vy = 0;
          if (b.stT <= 0) { b.state = "charge"; b.stT = 0.34; b.hit = []; g.snd("bark", b.x, b.y, 1); }
          return;
        }
        if (b.state === "charge") {
          b.stT -= dt;
          const c = Math.cos(b.aim), s = Math.sin(b.aim);
          const wall = g.slide(b, c * 290 * dt, s * 290 * dt, 0);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0 || b.hit.includes(f.id)) continue;
            if (Math.hypot(f.x - b.x, f.y - b.y) < 12) {
              b.hit.push(f.id);
              b.bite = 0.2;
              g.mobName = info.name;
              g.damage(f, info.dmg, null, "bug", b.aim, 130, "", true);
            }
          }
          if (wall || b.stT <= 0) { b.state = "walk"; b.atk = 0.9 + rand() * 0.6; }
          return;
        }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        // circle the prey instead of running straight in
        if (d < 110 && d > 30) { mx += -ny * b.strafe * 0.6; my += nx * b.strafe * 0.6; if (rand() < dt * 0.6) b.strafe = -b.strafe; }
        if (b.atk <= 0 && d < 80 && d > 16 && los(b.x, b.y, t.x, t.y)) { b.state = "wind"; b.stT = 0.28; g.snd("groan", b.x, b.y, 0.5); }
        else if (d < reach && b.atk <= 0) this.bite(b, t, info.dmg, ang, 60);
      } else if (b.kind === "charger") {
        if (b.state === "wind") {
          b.stT -= dt;
          if (b.stT > 0.15) b.aim = ang;
          if (b.stT <= 0) { b.state = "charge"; b.stT = 0.9; b.hit = []; g.snd("dash", b.x, b.y, 1.3); }
          b.vx = b.vy = 0;
          return;
        }
        if (b.state === "charge") {
          b.stT -= dt;
          const c = Math.cos(b.aim), s = Math.sin(b.aim);
          const wall = g.slide(b, c * 320 * dt, s * 320 * dt, 0);
          if (rand() < dt * 40) g.dust(b.x - c * 8, b.y + 5, 1);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0 || b.hit.includes(f.id)) continue;
            if (Math.hypot(f.x - b.x, f.y - b.y) < info.r + 7) {
              b.hit.push(f.id);
              g.mobName = info.name;
              g.damage(f, info.dmg, null, "bug", b.aim + (rand() - 0.5) * 0.7, 430, "", true);
            }
          }
          if (wall) {
            b.state = "stun"; b.stT = 1.4; b.atk = info.cd;
            g.shake(6, b.x, b.y); g.dust(b.x + c * 8, b.y, 8); g.snd("thunk", b.x, b.y, 1.3);
            g.say(b.x, b.y - 20, "PUSING!", "#8af0ff");
          } else if (b.stT <= 0) { b.state = "walk"; b.atk = info.cd; }
          return;
        }
        if (b.state === "stun") { b.stT -= dt; if (b.stT <= 0) b.state = "walk"; b.vx = b.vy = 0; return; }
        this.seek(b, t.x, t.y, d, dt);
        mx = this.mx; my = this.my;
        if (d < reach + 2 && b.t2 <= 0) { this.bite(b, t, 20, ang, 220); b.t2 = 1; }
        else if (b.atk <= 0 && d < 210 && d > 36 && los(b.x, b.y, t.x, t.y)) { b.state = "wind"; b.stT = 0.75; g.snd("roar", b.x, b.y, 0.8); }
      } else {
        // mutant: slow walking fortress
        if (d > 24) { this.seek(b, t.x, t.y, d, dt); mx = this.mx; my = this.my; }
        b.aim += clamp(angDiff(b.aim, ang), -1.6 * dt, 1.6 * dt);
        if (d < 36 && b.atk <= 0) {
          b.atk = info.cd; b.bite = 0.25;
          g.shake(8, b.x, b.y); g.rings.push({ x: b.x, y: b.y + 6, life: 0.05, r: 38 }); g.dust(b.x, b.y + 8, 12); g.snd("thunk", b.x, b.y, 1.5);
          for (const f of g.fighters) {
            if (!f.alive || f.dashT > 0) continue;
            const fd = Math.hypot(f.x - b.x, f.y - b.y);
            if (fd < 40) { g.mobName = info.name; g.damage(f, info.dmg, null, "bug", Math.atan2(f.y - b.y, f.x - b.x), 320, "", true); }
          }
        }
        if (b.t2 <= 0) {
          b.t2 = 4.2;
          g.snd("roar", b.x, b.y, 1.2);
          const live = g.fighters.filter((f) => f.alive);
          for (let i = 0; i < 4; i++) {
            const f = live[i % Math.max(1, live.length)];
            if (!f) break;
            const spread = i < live.length ? 6 : 34;
            this.mortars.push({ x: f.x + f.vx * 0.5 + (rand() - 0.5) * spread, y: f.y + f.vy * 0.5 + (rand() - 0.5) * spread, sx: b.x, sy: b.y - 14, t: -i * 0.18, dur: 1.05 });
          }
        }
        if (b.t3 <= 0) {
          b.t3 = 6.5;
          if (this.bugs.length < 60) for (let i = 0; i < 3; i++) this.spawn("scav", b.x + (rand() - 0.5) * 30, b.y + 10 + rand() * 8);
        }
      }
    }
    const l = Math.hypot(mx, my);
    if (l > 1) { mx /= l; my /= l; }
    if (b.hitT > 0) { mx *= 0.15; my *= 0.15; } // staggering
    const a = 1 - Math.exp(-dt * 9);
    b.vx += (mx * info.speed * b.sm - b.vx) * a;
    b.vy += (my * info.speed * b.sm - b.vy) * a;
    if (b.kind === "titan") {
      g.slide(b, b.vx * dt, b.vy * dt);
      if (l > 0.1 && (this.stepT -= dt) <= 0) {
        this.stepT = 0.55;
        g.shake(3.5, b.x, b.y); g.snd("thunk", b.x, b.y, 0.9); g.dust(b.x + (rand() - 0.5) * 36, b.y + 10, 3);
      }
    } else {
      g.slide(b, (b.vx + b.kx) * dt, (b.vy + b.ky) * dt);
      if (g.stairs(b)) { b.pathT = 0; b.path = []; } // up or down the stairs after its prey
      if (Math.abs(b.kx) + Math.abs(b.ky) > 150 && rand() < dt * 24) g.dust(b.x, b.y + 4, 1); // skidding backwards
      if (l > 0.1 && b.state === "walk") b.aim += clamp(angDiff(b.aim, Math.atan2(my, mx)), -9 * dt, 9 * dt);
    }
  }

  /* ───────────── taking damage ───────────── */
  private scale(b: Bug) {
    const vs = this.sp[b.kind];
    return vs[b.v % vs.length].s;
  }

  /** blood: a spray of drops in the direction of the hit, plus splats that soak into the floor */
  private bleed(x: number, y: number, ang: number, n: number, sp = 110) {
    const g = this.g, c = Math.cos(ang), s = Math.sin(ang), fc = g.fctx;
    g.puff(x, y - 3, n, GOO, sp * 0.45, { z: 7, vx: c * sp, vy: s * sp, vz: 55, max: 0.5, size: 2, grav: 320, drag: 1.5, stamp: true });
    for (let i = 0; i < n * 2; i++) {
      const d = 4 + rand() * (12 + n * 4), a = ang + (rand() - 0.5) * 0.9, px = x + Math.cos(a) * d, py = y + 4 + Math.sin(a) * d * 0.8;
      if (solidAt(px, py)) continue;
      fc.fillStyle = i % 3 ? "rgba(122,14,24,0.7)" : "rgba(170,30,42,0.75)";
      fc.fillRect(px | 0, py | 0, 1 + ((rand() * 3) | 0), 1 + ((rand() * 2) | 0));
    }
  }

  /** a pool spreading under a body */
  private pool(x: number, y: number, r: number) {
    const fc = this.g.fctx;
    for (let k = 0; k < 3; k++) {
      const cx = x + (rand() - 0.5) * r, cy = y + (rand() - 0.5) * r * 0.5, rr = r * (0.5 + rand() * 0.5), ry = Math.max(2, Math.round(rr * 0.55));
      fc.fillStyle = k ? "rgba(112,12,22,0.5)" : "rgba(140,18,30,0.6)";
      for (let j = -ry; j <= ry; j++) {
        const w = Math.round(rr * Math.sqrt(1 - (j * j) / (ry * ry)));
        if (!solidAt(cx, cy + j)) fc.fillRect((cx - w) | 0, (cy + j) | 0, w * 2, 1);
      }
    }
    fc.fillStyle = "rgba(210,70,70,0.5)";
    fc.fillRect((x - r * 0.3) | 0, (y - 1) | 0, 2, 1);
  }

  /** a flying piece: kind 0 head, 1 flesh, 2 bone, 3 brain */
  private gib(x: number, y: number, kind: number, ang: number, sp: number, vz: number, b: Bug | null = null) {
    if (this.gibs.length > 70) return;
    const a = ang + (rand() - 0.5) * (kind ? 1.6 : 0.3), v = sp * (kind ? 0.4 + rand() * 0.8 : 1);
    this.gibs.push({ x, y, z: kind ? 6 : 12, vx: Math.cos(a) * v, vy: Math.sin(a) * v, vz: vz * (0.7 + rand() * 0.6), rot: rand() * PI2, vrot: (rand() - 0.5) * 30, kind, b, n: 0 });
  }

  hurt(b: Bug, amt: number, by: Fighter | null, wid: Hurt, ang: number, knock: number, explosive = false, head = false) {
    if (!b.alive) return;
    const g = this.g, info = BUG[b.kind], S = this.scale(b);
    if (b.state === "sleep") this.wake(b);
    if (by && by.ai && by.look === 2 && by.skin === 4) amt *= g.talk.rageT > 0 ? 1.6 : 1.15; // Bara hits hard, harder when angry
    if (b.kind === "charger" && !explosive) {
      if (b.state === "stun") amt *= 1.6;
      else if (Math.cos(angDiff(ang, b.aim)) < -0.35) {
        // riot armour on the front: flank it, stun it or blow it up
        amt *= 0.3;
        g.sparks.push({ x: b.x + Math.cos(b.aim) * 8, y: b.y - 4 + Math.sin(b.aim) * 8, life: 0.08 });
        if (g.t - this.lastArmor > 0.5) { this.lastArmor = g.t; g.say(b.x, b.y - 22, "ARMOR!", "#c9cdd9"); g.snd("deflect", b.x, b.y, 0.5); }
      }
    }
    amt = Math.max(1, Math.round(amt));
    if (by) by.dmg += Math.min(amt, b.hp);
    b.hp -= amt;
    b.flash = 0.035;
    const c = Math.cos(ang), s = Math.sin(ang);
    b.kx += (c * knock * 0.6) / info.mass; b.ky += (s * knock * 0.6) / info.mass;
    const kv = Math.hypot(b.kx, b.ky), cap = wid === "bat" || explosive ? 200 : 120; // shoved, not launched
    if (kv > cap) { b.kx *= cap / kv; b.ky *= cap / kv; }
    // the body is knocked back, the loose arms are left behind and then swing
    const imp = 50 + Math.min(110, amt * 2.2);
    for (let i = 0; i < 8; i += 4) { b.arm[i + 2] -= c * imp * (0.7 + rand() * 0.6); b.arm[i + 3] += (-s * 0.6 - 0.4) * imp * (0.6 + rand() * 0.6); }
    if (b.kind === "dog" && b.state === "wind") b.state = "walk"; // a hit interrupts the pounce
    if (info.mass < 5) {
      // stagger: the bite is interrupted, the body snaps back, the arms fly up
      b.hitT = Math.max(b.hitT, 0.14 + Math.min(0.24, amt / 200));
      b.tilt = clamp(b.tilt + (c >= 0 ? 1 : -1) * (0.4 + Math.min(0.5, amt / 80)), -1, 1);
      b.atk = Math.max(b.atk, 0.3);
      if (b.state === "walk" && rand() < 0.3) b.aim += (rand() - 0.5) * 1.8; // the impact twists it round
      // a really heavy hit puts it on the floor - and it gets up again
      if (b.hp > 0 && b.kind !== "dog" && b.state !== "down" && (wid === "bat" || explosive || amt >= 55)) {
        b.state = "down"; b.stT = 1 + rand() * 0.7; b.vrot = c >= 0 ? 1 : -1; b.rot = 0;
        if (by?.isPlayer) g.talk.say("knockdown", { cd: 50 });
      }
    }
    this.bleed(b.x, b.y - (head ? 9 * S : 2), ang, head ? 6 : 2 + Math.min(3, (amt / 20) | 0));
    if (head) g.sparks.push({ x: b.x, y: b.y - 9 * S, life: 0.07 });
    const col = head ? "#ff6b7a" : by?.isPlayer ? "#fff0a8" : "#ffffff";
    const old = g.texts.find((t) => t.v === b && t.life < 0.3);
    if (old) { old.amt += amt; old.text = String(old.amt); old.life = 0; old.color = col; }
    else if (g.texts.length < 40) g.texts.push({ x: b.x, y: b.y - info.r - 12, text: String(amt), color: col, life: 0, v: b, amt });
    if (by?.isPlayer) g.hitMark = 0.14;
    g.snd("hit", b.x, b.y, by?.isPlayer ? 0.8 : 0.4);
    if (b.hp <= 0) this.kill(b, by, wid, ang, head);
  }

  private kill(b: Bug, by: Fighter | null, wid: Hurt, ang: number, head: boolean) {
    const g = this.g, info = BUG[b.kind], S = this.scale(b);
    b.alive = false;
    const i = this.bugs.indexOf(b);
    if (i >= 0) this.bugs.splice(i, 1);
    const big = b.kind === "charger" || b.kind === "titan";
    const boom = wid === "boom" || wid === "bazooka", bat = wid === "bat", smash = bat && head;
    const power = ((bat ? 125 : boom ? 120 : wid === "sniper" ? 95 : wid === "shotgun" ? 85 : wid === "karambit" ? 28 : 42) * (0.75 + rand() * 0.5)) / Math.min(info.mass, 6);
    const dir = ang + (rand() - 0.5) * 0.3, side = Math.cos(ang) >= 0 ? 1 : -1;
    this.kills++;
    if (by) { by.kills++; by.roundKills++; if (bat) by.bloody = 8; g.talk.kill(by, b.x, b.y); by.joy = Math.max(by.joy, head ? 1.4 : 0.5); }
    g.snd("squish", b.x, b.y, by?.isPlayer ? 1.1 : 0.6);
    if (rand() < info.heart) g.pickups.push({ x: b.x, y: b.y, t: 0 });
    this.bleed(b.x, b.y, ang, big ? 12 : 5, big ? 150 : 120);
    if (boom && !big && rand() < 0.65) {
      // blown to pieces: nothing left to fall over
      for (let k = 0; k < 8; k++) this.gib(b.x, b.y, k < 5 ? 1 : k < 7 ? 2 : 3, rand() * PI2, 105, 150);
      this.gib(b.x, b.y, 0, rand() * PI2, 85, 160, b);
      for (let k = 0; k < 3; k++) this.bleed(b.x, b.y, rand() * PI2, 4, 90);
      this.pool(b.x, b.y + 3, 9);
    } else {
      // ragdoll: thrown off its feet in the direction of the hit
      // how a body falls depends on what hit it
      const heavy = bat || boom || wid === "shotgun" || wid === "sniper", wasDown = b.state === "down";
      b.kx = Math.cos(dir) * power; b.ky = Math.sin(dir) * power;
      b.rest = false; b.deadT = wasDown ? 0.2 : 0; b.hitT = 0; b.atk = 0; b.t2 = 0; b.t3 = 0; b.stT = 0; b.z = 0; b.vz = 0;
      if (wasDown) b.vrot = 0; // already on the floor: it just goes limp
      else if (heavy && !smash) {
        // thrown off its feet: one short, heavy arc, timed to land flat on its back - or its face
        b.rot = 0; b.z = 1; b.vz = 52 + power * 0.28;
        b.vrot = (side * (b.kind === "dog" ? Math.PI : Math.PI / 2 + (bat && rand() < 0.3 ? Math.PI : 0))) / ((2 * b.vz) / 620);
      } else {
        // crumples: it sways for a heartbeat, the knees give way and it tips over - sometimes towards you
        b.rot = 0;
        b.atk = smash ? 0 : 0.1 + rand() * 0.16;
        b.vrot = (!head && rand() < 0.3 ? -side : side) * (smash ? 9 : 2 + rand() * 2);
      }
      if (smash) { b.kx *= 0.3; b.ky *= 0.3; }
      if (!big && b.kind !== "dog" && (head || (bat && rand() < 0.55) || (wid === "sniper" && rand() < 0.5))) {
        // the head comes off
        b.noHead = true;
        this.heads++;
        if (smash) {
          for (let k = 0; k < 7; k++) this.gib(b.x, b.y - 2, k < 3 ? 3 : k < 6 ? 1 : 2, rand() * PI2, 95, 150);
          for (let k = 0; k < 3; k++) this.bleed(b.x, b.y, rand() * PI2, 4, 80);
          this.pool(b.x, b.y + 2, 8);
          g.say(b.x, b.y - 30, "REMUK!", "#ff6b7a");
        } else {
          this.gib(b.x, b.y, 0, ang, bat ? 190 : 105, bat ? 170 : 150, b);
          for (let k = 0; k < 2; k++) this.gib(b.x, b.y, 3, ang, 110, 150);
          g.say(b.x, b.y - 30, bat ? "HOMERUN!" : "HEADSHOT!", bat ? "#8af0ff" : "#ff6b7a");
        }
        g.puff(b.x, b.y - 8 * S, 9, GOO, 34, { z: 10, vz: 140, max: 0.7, size: 2, grav: 330, stamp: true });
        g.snd("crack", b.x, b.y, 1);
        if (by?.isPlayer) {
          g.talk.headshot(smash);
          g.hitStop = Math.max(g.hitStop, smash ? 0.07 : 0.04);
          if (this.heads % 10 === 0) { g.streak = { id: g.ids++, text: `${this.heads} HEADSHOT!` }; g.streakT = 1.6; }
        }
        g.hudDirty = true;
      }
      this.corpses.push(b);
    }
    if (big) {
      g.shake(b.kind === "titan" ? 10 : 6, b.x, b.y);
      g.rings.push({ x: b.x, y: b.y, life: 0, r: b.kind === "titan" ? 60 : 30 });
      g.say(b.x, b.y - 30, `${info.name} TUMBANG!`, "#ffe45c");
      g.feed.push({ id: g.ids++, killer: by ? by.name : "LEDAKAN", killerTeam: 0, victim: info.name, victimTeam: 1, weapon: wid, tag: "", me: !!by?.isPlayer, t: g.t });
      if (g.feed.length > 5) g.feed.shift();
      if (b.kind === "titan") {
        this.boss = null;
        g.slowT = 1.4; g.zoom = 0.08; g.whiteT = 0.12;
        for (let k = 0; k < 2; k++) g.pickups.push({ x: b.x + (rand() - 0.5) * 30, y: b.y + (rand() - 0.5) * 20, t: 0 });
        g.setBanner("MUTAN TUMBANG!", "Tetap bertahan!", "gold", 2.4);
        g.talk.say("bossDead", { force: true, cd: 0 });
      }
      g.hudDirty = true;
    }
    if (by?.isPlayer) {
      g.killMark = 0.25;
      if (big) { g.zoom = Math.max(g.zoom, 0.05); g.hitStop = Math.max(g.hitStop, 0.08); }
      this.combo++;
      this.comboT = 2.6;
      const n = this.combo;
      if (n === 10) g.talk.say("combo", { cd: 30 });
      if (n === 5 || n === 10 || n === 15 || (n >= 20 && n % 10 === 0)) {
        g.streak = { id: g.ids++, text: `COMBO x${n}!` };
        g.streakT = 1.6;
        g.hudDirty = true;
      }
    }
    if (this.kills % 3 === 0) g.hudDirty = true;
  }

  /** bullet vs zombies; returns true when the bullet is consumed. A path through the head is a headshot. */
  hitBullet(b: Bullet): boolean {
    for (const m of this.bugs) {
      if (b.hit.includes(m.id)) continue;
      const S = this.scale(m), R = BUG[m.kind].r + 3, hr = 3.8 * S;
      const dx = m.x - b.x, dy = m.y - 2 - b.y, hy = m.y - 9 * S - b.y;
      const dogK = m.kind === "dog", inHead = !dogK && dx * dx + hy * hy < hr * hr;
      if (!inHead && dx * dx + dy * dy >= R * R) continue;
      if (b.wid === "bazooka") return true;
      const w = WEAPONS[b.wid];
      // brutes wear riot helmets
      const head = m.kind !== "charger" && !dogK && (inHead || Math.abs(dx * b.dy - hy * b.dx) < hr * 0.75);
      const mul = !head ? 1 : m.kind === "titan" ? 1.8 : b.wid === "shotgun" ? 2 : 3;
      const fall = w.pellets > 1 ? 0.55 + 0.45 * clamp(b.life / b.max, 0, 1) : 1;
      this.hurt(m, b.dmg * fall * mul, b.owner, b.wid, Math.atan2(b.dy, b.dx), w.knock, false, head);
      if (b.pierce) { b.hit.push(m.id); continue; }
      return true;
    }
    return false;
  }

  /** explosions shred zombies and ignore armour */
  blast(x: number, y: number, by: Fighter | null, R: number, dmg: number, knock: number, wid: Hurt) {
    if (dmg > 0) {
      for (const m of this.bugs.slice()) {
        const dx = m.x - x, dy = m.y - y, d = Math.hypot(dx, dy), rr = R + BUG[m.kind].r;
        if (d < rr) this.hurt(m, dmg * 1.5 * (1 - d / (rr * 1.5)), by, wid, Math.atan2(dy, dx), knock, true);
      }
    }
    for (const c of this.corpses) {
      const dx = c.x - x, dy = c.y - y, d = Math.hypot(dx, dy) || 1;
      if (d < R && c.kind !== "titan") { c.kx += (dx / d) * 110; c.ky += (dy / d) * 110; c.vz = 120; c.z = Math.max(c.z, 1); c.rest = false; c.vrot = (rand() - 0.5) * 30; }
    }
  }

  /** melee vs zombies. kind 2 = overhead smash (narrow, always the head), 3 = spin (all around). Each zombie is hit once per swing. */
  melee(f: Fighter, w: WeaponDef, kind: number, skip: number[]): boolean {
    const g = this.g, smash = kind === 2, spin = kind === 3, range = w.range + (smash ? 6 : spin ? 7 : 0), arc = smash ? 1.2 : spin ? 7 : w.arc;
    let hit = false;
    for (const m of this.bugs.slice()) {
      if (skip.includes(m.id)) continue;
      const dx = m.x - f.x, dy = m.y - f.y, d = Math.hypot(dx, dy);
      if (d > range + BUG[m.kind].r + 5) continue;
      if (d > 10 && Math.abs(angDiff(f.aim, Math.atan2(dy, dx))) > arc / 2) continue;
      if (!los(f.x, f.y, m.x, m.y)) continue;
      skip.push(m.id);
      const back = w.id === "karambit" && Math.cos(angDiff(f.aim, m.aim)) > 0.35;
      g.cut(m.x, m.y - 5, f.aim + f.swingDir * 1.1, w.id === "bat");
      this.hurt(m, w.dmg * (back ? 3 : smash ? 2.6 : spin ? 1.8 : 1.2), f, w.id, Math.atan2(dy, dx), smash ? 30 : spin ? w.knock * 1.6 : w.knock, back || smash, smash && m.kind !== "charger");
      hit = true;
    }
    return hit;
  }

  /** shockwave: everything close by staggers and gets shoved away */
  shock(x: number, y: number, R: number) {
    for (const m of this.bugs) {
      const dx = m.x - x, dy = m.y - y, d = Math.hypot(dx, dy) || 1, info = BUG[m.kind];
      if (d > R + info.r || info.mass > 5 || m.state === "sleep") continue;
      m.kx += (dx / d) * 150; m.ky += (dy / d) * 150;
      m.hitT = Math.max(m.hitT, 0.35); m.tilt = dx >= 0 ? 0.7 : -0.7; m.atk = Math.max(m.atk, 0.5);
      if (m.kind !== "dog" && m.state !== "down") { m.state = "down"; m.stT = 0.8 + rand() * 0.5; m.vrot = dx >= 0 ? 1 : -1; m.rot = 0; } // the shockwave floors them
    }
  }

  /* ───────────── air support ───────────── */
  useStrat(n: number) {
    const g = this.g, p = g.player;
    if (!p || !p.alive || g.phase !== "live" || g.paused || this.cd[n] > 0) return;
    const c = Math.cos(p.aim), s = Math.sin(p.aim);
    if (n === 0) {
      let tx = g.useTouch ? p.x + c * 100 : g.mx + g.cl, ty = g.useTouch ? p.y + s * 100 : g.my + g.ct;
      const d = Math.hypot(tx - p.x, ty - p.y);
      if (d > 230) { tx = p.x + ((tx - p.x) / d) * 230; ty = p.y + ((ty - p.y) / d) * 230; }
      tx = clamp(tx, 20, MW * TILE - 20); ty = clamp(ty, 20, MH * TILE - 20);
      this.strikes.push({ x: tx, y: ty, t: 0, n: 0, beeps: 0, by: p, hits: [] });
      g.say(p.x, p.y - 30, "RUDAL!", "#ff6b7a");
    } else {
      let tx = p.x + c * 24, ty = p.y + s * 24;
      if (solidAt(tx, ty)) { tx = p.x; ty = p.y + 3; }
      this.pods.push({ x: tx, y: ty, t: -0.15, landed: false });
      g.say(p.x, p.y - 30, "TURRET!", "#8af0ff");
    }
    this.cd[n] = STRAT_CD[n];
    g.snd("start", p.x, p.y, 0.8);
    g.hudDirty = true;
  }

  private sky() {
    return this.stage === 0 ? Math.min(2, this.count()) : this.stage === 1 ? 3 : 4;
  }

  hudInfo() {
    const p = this.g.player, ph = p ? houseAtPx(p.x, p.y) : -1;
    return {
      stage: this.stage, items: this.found.slice(), obj: GOAL[this.stage], evac: this.stage === 2 ? Math.max(0, Math.ceil(this.evacT)) : -1,
      kills: this.kills, strat: [clamp(1 - this.cd[0] / STRAT_CD[0], 0, 1), clamp(1 - this.cd[1] / STRAT_CD[1], 0, 1)] as [number, number],
      boss: this.boss && this.boss.alive ? clamp(this.boss.hp / this.boss.max, 0, 1) : -1,
      weather: (this.fixed ?? SKY[this.sky()]).name, bleed: p && p.down ? Math.max(0, Math.ceil(p.bleed)) : -1, heads: this.heads, floor: ph < 0 ? 0 : HOUSES[ph].under !== undefined ? 2 : HOUSES[ph].up !== undefined ? 1 : 0,
    };
  }

  /* ───────────── rendering ───────────── */
  drawGround() {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    // street holes glow toxic green
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < NESTS.length; i++) {
      const n = NESTS[i], k = 0.07 + 0.04 * Math.sin(t * 3 + i);
      ctx.fillStyle = `rgba(110,255,90,${k.toFixed(3)})`;
      for (let q = 1; q <= 3; q++) { ctx.beginPath(); ctx.ellipse(n.x - cl, n.y + 2 - ct, 8 * q, 5 * q, 0, 0, PI2); ctx.fill(); }
    }
    ctx.globalCompositeOperation = "source-over";
    // the evac zone calls you back
    if (this.stage === 1 || (this.stage === 3 && this.heliT >= 1)) {
      const x = Math.round(this.padX) - cl, y = Math.round(this.padY) - ct, k = (t * 0.8) % 1;
      ctx.strokeStyle = "#7dff9a";
      ctx.lineWidth = 2;
      ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.ellipse(x, y, 30 + 46 * k, 22 + 34 * k, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    // mortar landing zones
    for (const m of this.mortars) {
      if (m.t < 0) continue;
      const k = m.t / m.dur, x = Math.round(m.x) - cl, y = Math.round(m.y) - ct;
      ctx.fillStyle = `rgba(134,240,78,${(0.12 + 0.25 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y, 28 * k, 20 * k, 0, 0, PI2); ctx.fill();
      ctx.strokeStyle = Math.sin(t * 30) > 0 ? "#d9ffa0" : "#6fdc3e";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 28, 20, 0, 0, PI2); ctx.stroke();
    }
    // rocket target markers
    for (const s of this.strikes) {
      if (s.t > 1.3) continue;
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct, k = (s.t * 3) % 1;
      ctx.strokeStyle = "#ff4d5e";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 50, 38, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1 - k;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 0.5, 50 * k, 38 * k, 0, 0, PI2); ctx.stroke();
      ctx.globalAlpha = 1;
      ctx.fillStyle = "#ff4d5e";
      ctx.fillRect(x - 6, y, 13, 1); ctx.fillRect(x, y - 6, 1, 13);
    }
    // ground splitting open
    for (const br of this.breaches) {
      const k = br.t / 1.6, x = Math.round(br.x) - cl + Math.round(Math.sin(t * 50)), y = Math.round(br.y) - ct;
      ctx.fillStyle = "#120a1c";
      ctx.beginPath(); ctx.ellipse(x, y, 6 + 12 * k, 4 + 8 * k, 0, 0, PI2); ctx.fill();
      ctx.fillStyle = `rgba(255,122,60,${(0.3 + 0.5 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 1, 3 + 7 * k, 2 + 4 * k, 0, 0, PI2); ctx.fill();
      ctx.fillStyle = "#120a1c";
      for (let i = 0; i < 7; i++) { const a = i * 0.9 + br.x; ctx.fillRect(x + Math.round(Math.cos(a) * (10 + 16 * k)), y + Math.round(Math.sin(a) * (7 + 10 * k)), 4, 1); }
    }
    // incoming pod shadows
    for (const p of this.pods) {
      if (p.landed || p.t < -0.25) continue;
      const k = clamp((p.t + 0.25) / (POD_T + 0.25), 0, 1), x = Math.round(p.x) - cl, y = Math.round(p.y) - ct;
      ctx.fillStyle = `rgba(0,0,0,${(0.15 + 0.3 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 4, 4 + 8 * k, 2 + 4 * k, 0, 0, PI2); ctx.fill();
      ctx.strokeStyle = "#f5c542";
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.ellipse(x + 0.5, y + 4.5, 14, 9, 0, 0, PI2); ctx.stroke();
    }
    // helicopter shadow
    if (this.stage >= 3) {
      const k = this.heliT, x = Math.round(this.padX) - cl, y = Math.round(this.padY) - ct;
      ctx.fillStyle = `rgba(0,0,0,${(0.12 + 0.3 * k).toFixed(3)})`;
      ctx.beginPath(); ctx.ellipse(x, y + 8, 18 + 22 * k, 7 + 9 * k, 0, 0, PI2); ctx.fill();
    }
  }

  addSortables(list: Sortable[]) {
    for (const b of this.bugs) list.push({ y: b.y + (b.kind === "titan" ? 8 : 0), bug: b });
    for (const c of this.corpses) list.push({ y: c.y, bug: c });
    for (const t of this.turrets) list.push({ y: t.y, tur: t });
    for (const p of this.pods) if (p.landed) list.push({ y: p.y, pod: p });
  }

  drawSortable(it: Sortable) {
    const g = this.g, ctx = g.ctx;
    if (it.bug) { this.drawBug(it.bug); return; }
    if (it.tur) {
      const t = it.tur, x = Math.round(t.x) - g.cl, y = Math.round(t.y) - g.ct;
      const blink = t.life < 4 && Math.sin(g.t * 20) > 0;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x - 7, y + 3, 14, 3);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 7, y + 1, 3, 4); ctx.fillRect(x + 4, y + 1, 3, 4); ctx.fillRect(x - 5, y - 5, 10, 8);
      ctx.fillStyle = "#5c6675";
      ctx.fillRect(x - 6, y + 2, 1, 2); ctx.fillRect(x + 5, y + 2, 1, 2); ctx.fillRect(x - 4, y - 4, 8, 6);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 4, y, 8, 1);
      ctx.fillStyle = blink ? "#ff4d5e" : "#5ff0e0";
      ctx.fillRect(x - 1, y - 3, 2, 2);
      ctx.save();
      ctx.translate(x, y - 6);
      ctx.rotate(t.aim);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(-4, -3, 15, 6);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(-3, -2, 7, 4);
      ctx.fillStyle = "#737a96";
      ctx.fillRect(4, -1, 6, 2);
      if (t.flash > 0) { ctx.fillStyle = "#ffd75e"; ctx.fillRect(10, -2, 5, 4); ctx.fillStyle = "#ffffff"; ctx.fillRect(10, -1, 3, 2); }
      ctx.restore();
      return;
    }
    if (it.pod) {
      // landed supply pod shell
      const p = it.pod, x = Math.round(p.x) - g.cl, y = Math.round(p.y) - g.ct;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 6, y - 14, 12, 19);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(x - 5, y - 13, 10, 17);
      ctx.fillStyle = "#8d949e";
      ctx.fillRect(x + 1, y - 13, 4, 17);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 5, y - 9, 10, 3);
      ctx.fillStyle = "#1a1a22";
      ctx.fillRect(x - 3, y - 4, 6, 7);
      ctx.fillStyle = "#5ff0e0";
      ctx.fillRect(x - 1, y - 12, 2, 2);
    }
  }

  private drawBug(b: Bug) {
    const g = this.g, ctx = g.ctx;
    const x = Math.round(b.x) - g.cl, y = Math.round(b.y) - g.ct;
    if (x < -70 || x > g.W + 70 || y < -70 || y > g.H + 70) return;
    const vs = this.sp[b.kind], S = vs[b.v % vs.length].s, dead = !b.alive;
    const white = b.flash > 0 || (b.state === "wind" && Math.sin(b.t * 45) > 0);
    const sw = Math.max(3, Math.round(5 * S - (dead ? b.z * 0.1 : 0)));
    ctx.fillStyle = "rgba(0,0,0,0.32)";
    ctx.fillRect(x - sw, y + 4, sw * 2, Math.max(2, Math.round(2 * S)));
    if (dead) {
      // ragdoll: tumbling through the air, then sliding to a stop
      ctx.save();
      ctx.translate(x, y + (b.atk > 0 ? 2 : 0) - Math.round(b.z + 4 * S * (1 - Math.min(1, b.deadT / 0.2))));
      ctx.rotate(b.rot);
      this.figure(ctx, 0, 0, b, true, false);
      ctx.restore();
      return;
    }
    if (b.state === "down") {
      // flat on the floor, then pushing itself back up
      ctx.save();
      ctx.translate(x, y + 2 - Math.round(4 * S * (1 - Math.abs(b.rot) / 1.5708)));
      ctx.rotate(b.rot);
      this.figure(ctx, 0, 0, b, true, white);
      ctx.restore();
      return;
    }
    let ox = 0, oy = 0;
    if (b.state === "wind") ox = Math.round(Math.sin(b.t * 60) * 1.3);
    if (b.bite > 0) { ox += Math.round(Math.cos(b.aim) * 3); oy += Math.round(Math.sin(b.aim) * 2); }
    if (b.state === "emerge") { ctx.globalAlpha = 1 - (b.stT / 0.5) * 0.5; oy += Math.round(b.stT * 18); }
    this.figure(ctx, x + ox, y + 5 + oy, b, false, white);
    ctx.globalAlpha = 1;
    const top = y + 3 - Math.round(20 * S);
    if (b.state === "stun")
      for (let i = 0; i < 3; i++) {
        const a = g.t * 6 + i * 2.094;
        ctx.fillStyle = i ? "#ffe45c" : "#ffffff";
        ctx.fillRect(x + Math.round(Math.cos(a) * 9), top + Math.round(Math.sin(a) * 3), 2, 2);
      }
    if (b.kind === "spitter" && b.state === "wind") {
      ctx.fillStyle = "#d9ffa0";
      ctx.fillRect(x + (Math.cos(b.aim) < 0 ? -5 : 3), y + 5 - Math.round(11 * S), 3, 3);
    }
    if (b.hp < b.max && b.kind !== "scav" && b.kind !== "titan" && b.kind !== "dog") {
      const bw = b.kind === "charger" ? 18 : 12;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - bw / 2 - 1, top - 3, bw + 2, 3);
      ctx.fillStyle = "#ff9a3c";
      ctx.fillRect(x - bw / 2, top - 2, Math.max(1, Math.round((b.hp / b.max) * bw)), 1);
    }
  }

  /** a human zombie: shambling legs, swaying body, arms stretched out towards its prey. (x, y) = feet, or body centre when dead */
  private figure(ctx: CanvasRenderingContext2D, x: number, y: number, b: Bug, dead: boolean, white: boolean) {
    if (b.kind === "dog") { this.dog(ctx, x, y, b, dead, white); return; }
    const vs = this.sp[b.kind], v = vs[b.v % vs.length], S = v.s, img = white ? v.white : v.img, t = this.g.t;
    const w = img.width, h = img.height, hh = Math.round(10 * S), face = Math.cos(b.aim) < 0 ? -1 : 1;
    const asleep = b.state === "sleep", hit = !dead && b.hitT > 0, fl = dead && !b.rest && b.z > 0 ? 1 : 0;
    const run = b.kind === "warrior" || b.state === "charge";
    const moving = !dead && (Math.hypot(b.vx, b.vy) > 6 || b.state === "charge");
    const step = moving ? Math.sin(b.t * (run ? 22 : b.kind === "titan" ? 5 : 10)) : 0;
    const leg = Math.round(3 * S), lw = Math.max(2, Math.round(2 * S)), o1 = Math.round(S), dark = white ? "#ffffff" : "#0d0a0c";
    ctx.save();
    ctx.translate(Math.round(x), Math.round(y) + (dead ? (leg + h) >> 1 : 0));
    if (!dead) ctx.rotate(b.tilt * 0.6 + (asleep ? Math.sin(b.t * 1.6 + b.id) * 0.07 : run ? face * 0.26 : Math.sin(b.t * 4.2 + b.id) * 0.11 + (b.bite > 0 ? face * 0.22 : 0)) / Math.sqrt(S));
    // legs: shuffle when walking, kick while flying through the air
    const lx = Math.round(step * 1.5 * S), k1 = fl * Math.round(Math.sin(t * 24 + b.id) * 2 * S) + (dead && b.rest ? Math.round(b.t2 * S) : 0), k2 = fl * Math.round(Math.cos(t * 21 + b.id) * 2 * S);
    ctx.fillStyle = white ? "#ffffff" : v.pants;
    ctx.fillRect(-Math.round(3 * S) + lx + k1, -leg - (step > 0.4 ? 1 : 0), lw, leg);
    ctx.fillRect(o1 - lx + k2, -leg - (step < -0.4 ? 1 : 0), lw, leg);
    // torso, then the head: it snaps back when hit, and it may be gone altogether
    const ty = -leg - (h - hh) + (moving && Math.abs(step) > 0.55 ? 1 : 0) + (asleep ? 1 : 0);
    ctx.save();
    ctx.scale(face, 1);
    ctx.drawImage(img, 0, hh, w, h - hh, -(w >> 1), ty, w, h - hh);
    if (!b.noHead) {
      const hx = -(w >> 1) + (hit ? Math.round(face * Math.sign(b.tilt) * 2 * S) : 0), hy = ty - hh - (hit ? o1 : 0), P = (n: number) => Math.round(n * S);
      ctx.drawImage(img, 0, 0, w, hh, hx, hy, w, hh);
      if (!white) {
        // the face: jaws work when it bites or moans, eyes screw shut when it is hurt, brows drop when it attacks
        const pain = hit || dead || b.state === "down", gape = pain || b.bite > 0 || run || Math.sin(b.t * 2.6 + b.id) > 0.45;
        if (gape) { ctx.fillStyle = "#3a0810"; ctx.fillRect(hx + P(4), hy + P(8), P(6), Math.max(1, P(pain || b.bite > 0 ? 2 : 1))); }
        if (pain || asleep) { ctx.fillStyle = "#241014"; ctx.fillRect(hx + P(2), hy + P(5), P(3), o1); ctx.fillRect(hx + P(8), hy + P(5), P(3), o1); }
        else if (b.bite > 0 || b.state === "wind" || b.state === "charge" || run) { ctx.fillStyle = "#0d0a0c"; ctx.fillRect(hx + P(2), hy + P(4), P(2), o1); ctx.fillRect(hx + P(9), hy + P(4), P(2), o1); }
      }
    }
    ctx.restore();
    if (b.noHead) {
      ctx.fillStyle = white ? "#ffffff" : "#6e1420";
      ctx.fillRect(-Math.round(2 * S), ty - o1, Math.round(4 * S), o1 + 1);
      ctx.fillStyle = white ? "#ffffff" : "#d04a4a";
      ctx.fillRect(-o1, ty - o1, o1 * 2, o1);
    }
    // arms: loose two-part limbs driven by a little spring (see arms()), so they dangle, swing and flop instead of sticking out
    const sy = -leg - Math.round(5 * S), LEN = 6.4 * S, at = Math.max(2, Math.round(1.6 * S));
    for (let i = 0; i < 2; i++) {
      const o = i ? 1 : -1, x0 = o * Math.round(4 * S);
      const ex = b.arm[i * 4] * S, ey = b.arm[i * 4 + 1] * S, d = Math.hypot(ex, ey) || 0.01;
      const x1 = x0 + ex, y1 = sy + ey;
      // elbow: the arm folds when the hand is closer than its full length
      const bend = d < LEN ? Math.sqrt((LEN * LEN - d * d) / 4) * 0.8 : 0;
      let nx = -ey / d, ny = ex / d;
      if (ny < 0) { nx = -nx; ny = -ny; }
      const xm = (x0 + x1) / 2 + nx * bend, ym = (sy + y1) / 2 + ny * bend;
      ctx.fillStyle = dark;
      pline(ctx, x0, sy, xm, ym, at + 2);
      pline(ctx, xm, ym, x1, y1, at + 2);
      ctx.fillStyle = white ? "#ffffff" : v.sleeve;
      pline(ctx, x0, sy, xm, ym, at);
      ctx.fillStyle = white ? "#ffffff" : v.skin;
      pline(ctx, xm, ym, x1, y1, at);
    }
    ctx.restore();
  }

  /** spring-driven hands in body space, [x, y, vx, vy] per arm: they reach for prey, go limp when hit, flail in the air and flop down at rest */
  private arms(b: Bug, dt: number, dead: boolean) {
    if (b.kind === "dog") return;
    const A = b.arm, t = this.g.t, air = dead && !b.rest && b.z > 0;
    for (let i = 0; i < 2; i++) {
      const o = i ? 1 : -1, n = i * 4;
      let tx: number, ty: number, k = 70, c = 8;
      if (dead) {
        if (air) {
          const sp = Math.min(1, Math.abs(b.vrot) / 12);
          tx = o * (1.5 + 4.5 * sp) + Math.sin(t * 11 + i * 2.3 + b.id) * 1.5; ty = 4.5 - 6 * sp + Math.cos(t * 9 + i + b.id) * 1.5; k = 40; c = 5;
        } else if ((b.id + i) % 2) { tx = o * 3.5; ty = -4.5; } // one arm ends up beside the head...
        else { tx = o * 2.5; ty = 4.5; }                       // ...the other along the body
      } else if (b.state === "sleep") { tx = o; ty = 5.5; k = 30; }
      else if (b.hitT > 0) { tx = o * 1.5; ty = 5; k = 34; c = 5; } // limp: the impulse of the hit throws them around
      else {
        const al = b.bite > 0 ? 8 : 6;
        tx = Math.cos(b.aim) * al; ty = Math.sin(b.aim) * 0.5 * al + Math.sin(b.t * 6 + o * 1.3 + b.id); k = 120; c = 14;
      }
      A[n + 2] += (k * (tx - A[n]) - c * A[n + 2]) * dt;
      A[n + 3] += (k * (ty - A[n + 1]) - c * A[n + 3]) * dt;
      A[n] += A[n + 2] * dt;
      A[n + 1] += A[n + 3] * dt;
      const d = Math.hypot(A[n], A[n + 1]);
      if (d > 8.5) { A[n] *= 8.5 / d; A[n + 1] *= 8.5 / d; }
    }
  }

  /** zombie dog: galloping legs, a crouch before the pounce, a leap. (x, y) = paws */
  private dog(ctx: CanvasRenderingContext2D, x: number, y: number, b: Bug, dead: boolean, white: boolean) {
    const vs = this.sp.dog, v = vs[b.v % vs.length], img = white ? v.white : v.img;
    const face = Math.cos(b.aim) < 0 ? -1 : 1, dark = white ? "#ffffff" : "#0d0a0c", fur = white ? "#ffffff" : v.skin;
    const moving = !dead && (Math.hypot(b.vx, b.vy) > 8 || b.state === "charge"), lying = b.state === "sleep";
    ctx.save();
    ctx.translate(Math.round(x), Math.round(y) + (dead ? 5 : 0) - Math.round(b.lz));
    if (!dead && b.state === "wind") ctx.rotate(face * 0.24);
    if (!dead && b.state === "charge") ctx.rotate(-face * 0.26);
    ctx.scale(face, dead ? -1 : 1);
    const leg = lying ? 0 : 4, ph = b.t * 26;
    if (leg)
      for (let i = 0; i < 4; i++) {
        const lx = i < 2 ? -6 + i * 2 : 4 + (i - 2) * 2;
        const sw = moving ? Math.sin(ph + (i < 2 ? 0 : Math.PI) + (i % 2) * 0.9) * 3 : dead ? (i % 2 ? 2 : -1) : 0;
        ctx.fillStyle = dark;
        pline(ctx, lx, -leg, lx + sw, 0, 3);
        ctx.fillStyle = fur;
        pline(ctx, lx, -leg, lx + sw, -1, 1);
      }
    ctx.drawImage(img, -9, -leg - 8 + (lying ? 2 : 0));
    ctx.restore();
  }

  private drawGib(ctx: CanvasRenderingContext2D, q: Gib) {
    if (q.kind === 0 && q.b) {
      const vs = this.sp[q.b.kind], v = vs[q.b.v % vs.length], hh = Math.round(10 * v.s), w = v.img.width;
      ctx.drawImage(v.img, 0, 0, w, hh, -(w >> 1), -(hh >> 1), w, hh);
      ctx.fillStyle = "#8a1420";
      ctx.fillRect(-2, (hh >> 1) - 1, 4, 2);
    } else if (q.kind === 2) {
      ctx.fillStyle = "#0d0a0c"; ctx.fillRect(-3, -1, 7, 3);
      ctx.fillStyle = "#e9e2c8"; ctx.fillRect(-2, 0, 5, 1);
      ctx.fillStyle = "#a8202c"; ctx.fillRect(2, 0, 1, 1);
    } else {
      ctx.fillStyle = "#0d0a0c"; ctx.fillRect(-2, -2, 5, 5);
      ctx.fillStyle = q.kind === 3 ? "#e88aa0" : "#a8202c"; ctx.fillRect(-1, -1, 3, 3);
      ctx.fillStyle = q.kind === 3 ? "#ffc0cc" : "#d04a4a"; ctx.fillRect(-1, -1, 2, 1);
    }
  }

  /* ───────────── atmosphere hooks ───────────── */
  /** current target weather (muffled while indoors) */
  weather(): Weather {
    const w = this.fixed ?? SKY[this.sky()];
    return this.g.inside ? { ...w, rain: w.rain * 0.12, fog: w.fog * 0.35, dark: Math.min(0.88, w.dark + 0.04) } : w;
  }

  /** 0..1 pulsing during the hold-out (alarm lights) */
  alarm() {
    return this.stage >= 2 ? 0.5 + 0.5 * Math.sin(this.g.t * 6) : 0;
  }

  /** everything that pushes the darkness back */
  lights(A: Atmosphere) {
    const g = this.g, cl = g.cl, ct = g.ct, t = g.t;
    NESTS.forEach((n, i) => A.light(n.x - cl, n.y - ct, 36, 0.35 + 0.12 * Math.sin(t * 3 + i)));
    for (const tu of this.turrets) { A.light(tu.x - cl, tu.y - ct - 4, 50, 0.9); A.beam(tu.x - cl, tu.y - ct - 6, tu.aim, 130, 0.9); }
    for (const p of this.pods) {
      if (p.t < 0) continue;
      if (p.landed) A.light(p.x - cl, p.y - ct, 58, 1);
      else A.light(p.x - cl, p.y - (1 - p.t / POD_T) * 300 - ct - 20, 46, 1);
    }
    for (const s of this.strikes) if (s.t < 1.25) A.light(s.x - cl, s.y - ct, 52, 0.55 + 0.25 * Math.sin(t * 20));
    for (const s of this.globs) A.light(s.x - cl, s.y - ct, 16, 0.8);
    for (const m of this.mortars) if (m.t >= 0) A.light(m.x - cl, m.y - ct, 30, 0.35 + 0.4 * (m.t / m.dur));
    for (const br of this.breaches) A.light(br.x - cl, br.y - ct, 44, 0.5 + 0.3 * Math.sin(t * 16));
    for (const b of this.bugs) if (b.state === "wind") A.light(b.x - cl, b.y - ct - 4, 24, 0.6);
    if (this.stage >= 3) A.light(this.padX - cl, this.padY - ct, 130, 0.5 + 0.5 * this.heliT);
    if (this.search) A.light(this.search.x - cl, this.search.y - ct - 6, 26, 0.7);
  }

  /** glowing things drawn on top of the darkness: dead eyes in the night, toxic holes, bile */
  glowPass(A: Atmosphere) {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    NESTS.forEach((n, i) => A.tint(ctx, n.x - cl, n.y + 2 - ct, 28, "g", 0.3 + 0.1 * Math.sin(t * 3 + i)));
    for (const br of this.breaches) A.tint(ctx, br.x - cl, br.y - ct, 34, "o", 0.5 + 0.3 * Math.sin(t * 16));
    for (const s of this.globs) A.tint(ctx, s.x - cl, s.y - ct, 12, "g", 0.6);
    for (const s of this.strikes) if (s.t < 1.25) A.tint(ctx, s.x - cl, s.y - ct, 40, "r", 0.3);
    const fo = g.focus();
    for (const b of this.bugs) {
      if (b.state === "emerge" || b.state === "down" || b.hitT > 0 || g.hidden(b.x, b.y)) continue;
      const x = Math.round(b.x) - cl, y = Math.round(b.y) - ct;
      if (x < -40 || x > g.W + 40 || y < -20 || y > g.H + 70) continue;
      if (g.inK > 0.5 && houseAtPx(b.x, b.y) !== g.inHouse && !(fo && los(fo.x, fo.y, b.x, b.y))) continue; // indoors, the street is out of sight
      if (b.state === "sleep") {
        // eyes shut: only a soft snore gives it away
        if (fo && !los(fo.x, fo.y, b.x, b.y)) continue;
        const k = (t * 0.8 + b.id * 0.37) % 1;
        ctx.globalAlpha = 0.8 * (1 - k);
        drawText(ctx, "Z", x + 5 + k * 5, y - 16 - k * 9, "#9ab0ff");
        ctx.globalAlpha = 1;
        continue;
      }
      if (b.kind === "dog") {
        const fd = Math.cos(b.aim) < 0 ? -1 : 1, ey = y - 4 - Math.round(b.lz);
        ctx.fillStyle = "#ff4a4a";
        ctx.fillRect(x + fd * 5, ey, 1, 1);
        A.tint(ctx, x + fd * 5, ey, 6, "r", 0.4);
        continue;
      }
      const vs = this.sp[b.kind], S = vs[b.v % vs.length].s, face = Math.cos(b.aim) < 0 ? -1 : 1, eye = EYE[b.kind];
      const ey = y + 5 - Math.round(3 * S) - Math.round(10.5 * S), e = Math.max(1, Math.round(S));
      ctx.fillStyle = eye[0];
      ctx.fillRect(x + Math.round(face * -3.5 * S) - (e >> 1), ey, e, e);
      ctx.fillRect(x + Math.round(face * 2.5 * S) - (e >> 1), ey, e, e);
      A.tint(ctx, x, ey, 6 * S + 2, eye[1], 0.4);
    }
  }

  /** flying things and mission markers drawn above the whole world */
  drawTop() {
    const g = this.g, ctx = g.ctx, cl = g.cl, ct = g.ct, t = g.t;
    for (const s of this.globs) {
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      ctx.fillStyle = "#16300f";
      ctx.fillRect(x - 3, y - 3, 6, 6);
      ctx.fillStyle = "#6fdc3e";
      ctx.fillRect(x - 2, y - 2, 4, 4);
      ctx.fillStyle = "#e6ffc0";
      ctx.fillRect(x - 1, y - 2, 2, 1);
    }
    for (const m of this.mortars) {
      if (m.t < 0) continue;
      const k = m.t / m.dur;
      const x = Math.round(m.sx + (m.x - m.sx) * k) - cl, y = Math.round(m.sy + (m.y - m.sy) * k - Math.sin(k * Math.PI) * 90) - ct;
      ctx.fillStyle = "#16300f";
      ctx.fillRect(x - 3, y - 5, 6, 10); ctx.fillRect(x - 5, y - 3, 10, 6); ctx.fillRect(x - 4, y - 4, 8, 8);
      ctx.fillStyle = "#6fdc3e";
      ctx.fillRect(x - 2, y - 4, 4, 8); ctx.fillRect(x - 4, y - 2, 8, 4); ctx.fillRect(x - 3, y - 3, 6, 6);
      ctx.fillStyle = "#e6ffc0";
      ctx.fillRect(x - 2, y - 3, 3, 2);
    }
    for (const p of this.pods) {
      if (p.landed || p.t < 0) continue;
      const hgt = (1 - p.t / POD_T) * 300;
      const x = Math.round(p.x) - cl, y = Math.round(p.y - hgt) - ct;
      ctx.fillStyle = Math.sin(t * 60) > 0 ? "#ffe45c" : "#ff9a3c";
      ctx.fillRect(x - 3, y - 40, 6, 24);
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(x - 1, y - 30, 2, 14);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 6, y - 16, 12, 21);
      ctx.fillStyle = "#c9cdd9";
      ctx.fillRect(x - 5, y - 15, 10, 19);
      ctx.fillStyle = "#8d949e";
      ctx.fillRect(x + 1, y - 15, 4, 19);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 5, y - 10, 10, 3);
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 3, y + 4, 6, 3);
    }
    for (const s of this.strikes) {
      const x = Math.round(s.x) - cl, y = Math.round(s.y) - ct;
      if (s.t < 1.25) {
        ctx.fillStyle = `rgba(255,77,94,${(0.25 + 0.2 * Math.sin(t * 24)).toFixed(3)})`;
        ctx.fillRect(x - 1, 0, 3, Math.max(0, y));
        ctx.fillStyle = "#ff9aa5";
        ctx.fillRect(x, 0, 1, Math.max(0, y));
      }
      for (let i = 0; i < s.hits.length; i += 3) {
        const age = s.t - s.hits[i + 2];
        if (age > 0.14) continue;
        const hx = Math.round(s.hits[i]) - cl, hy = Math.round(s.hits[i + 1]) - ct, w = age < 0.06 ? 9 : 4;
        ctx.fillStyle = "rgba(160,235,255,0.75)";
        ctx.fillRect(hx - w, 0, w * 2, Math.max(0, hy));
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(hx - (w >> 1), 0, w, Math.max(0, hy));
      }
    }
    for (const q of this.gibs) {
      if (g.hidden(q.x, q.y)) continue;
      const x = Math.round(q.x) - cl, y = Math.round(q.y) - ct;
      ctx.fillStyle = "rgba(0,0,0,0.3)";
      ctx.fillRect(x - 2, y + 2, 4, 2);
      ctx.save();
      ctx.translate(x, y - Math.round(q.z));
      ctx.rotate(q.rot);
      this.drawGib(ctx, q);
      ctx.restore();
    }
    // furniture that can still be searched twinkles once you are inside
    this.boxes.forEach((b, i) => {
      if (b.looted || g.roofA[b.house] > 0.4) return;
      const x = Math.round(b.x) - cl, y = Math.round(b.y) - ct - 10;
      if (x < -10 || x > g.W + 10 || y < -10 || y > g.H + 10) return;
      const ph = (t * 1.6 + i * 0.37) % 1;
      if (ph > 0.45) return;
      const n = ph < 0.15 || ph > 0.3 ? 1 : 2;
      ctx.fillStyle = "#fff0a8";
      ctx.fillRect(x - n, y, n * 2 + 1, 1);
      ctx.fillRect(x, y - n, 1, n * 2 + 1);
    });
    if (this.search) {
      const b = this.search, x = Math.round(b.x) - cl, y = Math.round(b.y) - ct - 20;
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 9, y - 1, 18, 5);
      ctx.fillStyle = "#3b3848";
      ctx.fillRect(x - 8, y, 16, 3);
      ctx.fillStyle = "#f5c542";
      ctx.fillRect(x - 8, y, Math.round(16 * clamp(this.searchT / SEARCH_T, 0, 1)), 3);
    }
    // stairs: which way they lead
    HOUSES.forEach((H, i) => {
      if (!H.stair || g.roofA[i] > 0.4) return;
      const x = H.stair.tx * TILE + 8 - cl, y = H.stair.ty * TILE - ct - 4 + Math.round(Math.sin(t * 5) * 2), up = H.up !== undefined;
      if (x < -20 || x > g.W + 20 || y < -20 || y > g.H + 20) return;
      drawText(ctx, up ? "NAIK" : "TURUN", x, y - 8, "#f5c542");
      ctx.fillStyle = "#f5c542";
      for (let k = 0; k < 3; k++) ctx.fillRect(x - k - 1, y + (up ? k : 2 - k), 2 + k * 2, 1);
    });
    // marked houses: a bobbing sign above the roof
    if (this.stage === 0)
      this.objHouses.forEach((h, i) => {
        if (this.found[i] || g.roofA[h] < 0.5) return;
        const H = HOUSES[h], x = Math.round((H.x + H.w / 2) * TILE) - cl, y = Math.round((H.y + H.h / 2) * TILE) - ct - 14 + Math.round(Math.sin(t * 4 + i) * 2);
        if (x < -20 || x > g.W + 20 || y < -20 || y > g.H + 20) return;
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 7, y - 9, 14, 14); ctx.fillRect(x - 3, y + 5, 6, 3); ctx.fillRect(x - 1, y + 8, 2, 2);
        ctx.fillStyle = "#f5c542";
        ctx.fillRect(x - 6, y - 8, 12, 12); ctx.fillRect(x - 2, y + 4, 4, 3);
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 1, y - 6, 2, 5); ctx.fillRect(x - 1, y, 2, 2);
      });
    // downed survivors call for help
    for (const f of g.fighters) {
      if (!f.down || f.deadT < 0.6) continue;
      const x = Math.round(f.x) - cl, y = Math.round(f.y) - ct - 18;
      if (Math.sin(t * 8) > -0.3) {
        ctx.fillStyle = "#0a0a0f";
        ctx.fillRect(x - 5, y - 9, 10, 10);
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(x - 4, y - 8, 8, 8);
        ctx.fillStyle = "#e0483e";
        ctx.fillRect(x - 1, y - 7, 2, 6); ctx.fillRect(x - 3, y - 5, 6, 2);
      }
      ctx.fillStyle = "#0a0a0f";
      ctx.fillRect(x - 9, y + 2, 18, 4);
      ctx.fillStyle = f.rev > 0 ? "#7dff9a" : "#e0483e";
      ctx.fillRect(x - 8, y + 3, Math.round(16 * (f.rev > 0 ? clamp(f.rev / 2, 0, 1) : clamp(f.bleed / 45, 0, 1))), 2);
    }
    if (this.stage >= 3) this.drawHeli();
  }

  private drawHeli() {
    const g = this.g, ctx = g.ctx, t = g.t;
    const k = this.heliT, alt = (1 - k) * (1 - k) * 230;
    const x = Math.round(this.padX) - g.cl, y = Math.round(this.padY - 12 - alt) - g.ct + (k >= 1 ? 0 : Math.round(Math.sin(t * 5) * 2));
    const INK = "#0a0a0f";
    // skids
    ctx.fillStyle = INK;
    ctx.fillRect(x - 20, y + 13, 42, 3); ctx.fillRect(x - 12, y + 8, 2, 6); ctx.fillRect(x + 10, y + 8, 2, 6);
    ctx.fillStyle = "#8d949e";
    ctx.fillRect(x - 19, y + 14, 40, 1);
    // tail boom + tail rotor
    ctx.fillStyle = INK;
    ctx.fillRect(x - 52, y - 5, 32, 8); ctx.fillRect(x - 56, y - 14, 7, 16);
    ctx.fillStyle = "#3d5a44";
    ctx.fillRect(x - 51, y - 4, 31, 6); ctx.fillRect(x - 55, y - 13, 5, 14);
    ctx.fillStyle = "#57785e";
    ctx.fillRect(x - 51, y - 4, 31, 1);
    ctx.fillStyle = "#e0483e";
    ctx.fillRect(x - 55, y - 13, 5, 3);
    ctx.fillStyle = "rgba(210,220,235,0.7)";
    const ta = t * 50;
    pline(ctx, x - 53 - Math.cos(ta) * 2, y - 6 - Math.sin(ta) * 7, x - 53 + Math.cos(ta) * 2, y - 6 + Math.sin(ta) * 7, 1);
    // cabin
    ctx.fillStyle = INK;
    ctx.fillRect(x - 22, y - 12, 44, 22); ctx.fillRect(x - 19, y - 14, 38, 26); ctx.fillRect(x + 20, y - 8, 6, 14);
    ctx.fillStyle = "#3d5a44";
    ctx.fillRect(x - 21, y - 11, 42, 20); ctx.fillRect(x - 18, y - 13, 36, 24); ctx.fillRect(x + 20, y - 7, 5, 12);
    ctx.fillStyle = "#57785e";
    ctx.fillRect(x - 18, y - 13, 36, 2);
    ctx.fillStyle = "#2c4233";
    ctx.fillRect(x - 21, y + 5, 42, 4);
    // cockpit glass, open door, markings
    ctx.fillStyle = INK;
    ctx.fillRect(x + 6, y - 10, 17, 12);
    ctx.fillStyle = "#8fd0e0";
    ctx.fillRect(x + 7, y - 9, 15, 10);
    ctx.fillStyle = "#d9f5f9";
    ctx.fillRect(x + 8, y - 8, 5, 2); ctx.fillRect(x + 8, y - 6, 2, 3);
    ctx.fillStyle = INK;
    ctx.fillRect(x - 12, y - 8, 14, 17);
    ctx.fillStyle = "#1c2a20";
    ctx.fillRect(x - 11, y - 7, 12, 16);
    ctx.fillStyle = "#f5c542";
    ctx.fillRect(x - 11, y + 7, 12, 2);
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(x - 19, y - 6, 6, 6);
    ctx.fillStyle = "#e0483e";
    ctx.fillRect(x - 17, y - 5, 2, 4); ctx.fillRect(x - 18, y - 4, 4, 2);
    ctx.fillStyle = Math.sin(t * 10) > 0 ? "#ff4d5e" : "#5a1a20";
    ctx.fillRect(x - 1, y - 15, 2, 2);
    // main rotor: a spinning blur
    ctx.fillStyle = INK;
    ctx.fillRect(x - 2, y - 19, 4, 6);
    const ra = t * 38;
    for (let i = 0; i < 2; i++) {
      const a = ra + i * 1.571, rx = Math.cos(a) * 50, ry = Math.sin(a) * 9;
      ctx.fillStyle = "rgba(10,10,15,0.75)";
      pline(ctx, x - rx, y - 19 - ry, x + rx, y - 19 + ry, 2);
      ctx.fillStyle = "rgba(210,220,235,0.5)";
      pline(ctx, x - rx * 0.96, y - 20 - ry, x + rx * 0.96, y - 20 + ry, 1);
    }
  }

  /** blips on the radar; the engine has already clipped and translated to tile coordinates. Upper floors show at their house. */
  drawRadar() {
    const g = this.g, ctx = g.ctx, blink = Math.sin(g.t * 8) > 0;
    const T = (x: number, y: number) => { const q = g.gpos(x, y); q[0] = Math.floor(q[0] / TILE); q[1] = Math.floor(q[1] / TILE); return q; };
    ctx.fillStyle = "#3f9a2c";
    for (const n of NESTS) ctx.fillRect(Math.floor(n.x / TILE) - 1, Math.floor(n.y / TILE) - 1, 3, 2);
    const frame = (x: number, y: number, w: number, h: number) => {
      ctx.fillRect(x, y, w, 1); ctx.fillRect(x, y + h - 1, w, 1); ctx.fillRect(x, y, 1, h); ctx.fillRect(x + w - 1, y, 1, h);
    };
    if (this.stage === 0) {
      this.objHouses.forEach((h, i) => {
        if (this.found[i]) return;
        ctx.fillStyle = blink ? "#f5c542" : "#a97a1c";
        frame(HOUSES[h].x, HOUSES[h].y, HOUSES[h].w, HOUSES[h].h);
      });
    } else {
      ctx.fillStyle = blink ? "#7dff9a" : "#2f8a4a";
      frame(PAD.x, PAD.y, PAD.w, PAD.h);
    }
    for (const b of this.bugs) {
      if (b.state === "sleep") continue;
      const s = b.kind === "titan" ? 3 : b.kind === "charger" ? 2 : 1, q = T(b.x, b.y);
      ctx.fillStyle = b.kind === "titan" || b.kind === "charger" ? "#ff4d5e" : b.kind === "dog" ? "#ffd75e" : "#ff9a3c";
      ctx.fillRect(q[0], q[1], s, s);
    }
    ctx.fillStyle = "#5ff0e0";
    for (const t of this.turrets) { const q = T(t.x, t.y); ctx.fillRect(q[0], q[1], 2, 2); }
    for (const f of g.fighters) if (f.down && blink) { const q = T(f.x, f.y); ctx.fillStyle = "#ffffff"; ctx.fillRect(q[0] - 1, q[1] - 1, 3, 3); }
  }

  /** arrows at the screen edge: where to go, who needs help, what is coming */
  pointers() {
    const g = this.g;
    if (this.stage === 0) {
      this.objHouses.forEach((h, i) => {
        if (this.found[i]) return;
        const H = HOUSES[h];
        g.pointer((H.x + H.w / 2) * TILE, (H.y + H.h / 2) * TILE, "#f5c542", "#fff0a8");
      });
    } else g.pointer(this.padX, this.padY, "#7dff9a", "#ffffff");
    for (const f of g.fighters) if (f.down) g.pointer(f.x, f.y, "#5ff0e0", "#ffffff");
    for (const b of this.bugs) if ((b.kind === "titan" || b.kind === "charger") && b.state !== "sleep") g.pointer(b.x, b.y, "#ff4d5e", "#ffd0d0");
  }
}

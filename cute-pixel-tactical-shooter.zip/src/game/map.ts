import { TILE } from "./defs";

const MAXW = 128, MAXH = 100;
/** current map size in tiles (the city is much bigger than the 5v5 arena) */
export let MW = 60;
export let MH = 38;
/** height of the city itself: the rows below it hold the upper floors of two-storey houses */
export let CH = 38;
/** 0 = floor, 1 = wall, 2 = tall obstacle (crate, car, cupboard), 3 = low cover (blocks walking, bullets fly over), 4 = lamp / tree footing */
export const grid = new Uint8Array(MAXW * MAXH);
/** roof / wall / furniture style per tile */
export const style = new Uint8Array(MAXW * MAXH);
const houseIdx = new Int8Array(MAXW * MAXH);
const roomIdx = new Int16Array(MAXW * MAXH);
const roomKind = new Uint8Array(MAXW * MAXH);
/** ground type in the city: 0 road, 1 sidewalk, 2 plaza, 5 alley / yard concrete, 6 grass */
const zone = new Uint8Array(MAXW * MAXH);
/** stairs: index of the linked tile on the other floor, or -1 */
const portal = new Int32Array(MAXW * MAXH).fill(-1);
export interface Building { x: number; y: number; w: number; h: number; style: number }
export interface Pt { x: number; y: number }
export interface Flag extends Pt { team: number }
/** standing prop on a kind-4 tile. k: 0 palm / street lamp, 1 tree, 2 traffic light */
export interface Prop extends Pt { k: number }
/** type: 1 living room, 2 bedroom, 3 kitchen, 4 bathroom, 5 storage, 6 shop floor */
export interface Room { x: number; y: number; w: number; h: number; type: number }
/** an enterable building: perimeter walls with doors, rooms and furniture inside */
export interface House { x: number; y: number; w: number; h: number; style: number; shop: boolean; doors: { tx: number; ty: number; ox: number; oy: number }[]; rooms: Room[];
  /** two-storey houses: top of the staircase, index of the floor above / below, and where the upper floor sits relative to the house (tiles) */
  stair?: { tx: number; ty: number }; up?: number; under?: number; dx: number; dy: number;
}
/** searchable furniture */
export interface Crate { tx: number; ty: number; house: number }

// per-map data, swapped by loadMap() (ES module live bindings keep importers up to date)
export let BUILDINGS: Building[] = [];
export let SPAWNS: Pt[][] = [[], []];
export let LANES: Pt[] = [];
export let BARREL_SPOTS: Pt[] = [];
export let PALMS: Prop[] = [];
export let FLAGS: Flag[] = [];
/** holes the zombies crawl out of (city only) */
export let NESTS: Pt[] = [];
export let HOUSES: House[] = [];
export let CRATES: Crate[] = [];
/** evac zone (city only), in tiles */
export let PAD = { x: 25, y: 14, w: 10, h: 10 };
let roomCount = 0;

function put(x: number, y: number, k: number, st: number) {
  if (x < 0 || y < 0 || x >= MW || y >= MH) return;
  grid[y * MW + x] = k;
  style[y * MW + x] = st;
}
/** place a rect and its 180deg-rotated twin so the map stays balanced */
function rect(x: number, y: number, w: number, h: number, k: number, st = 0) {
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      put(x + i, y + j, k, st);
      put(MW - 1 - (x + i), CH - 1 - (y + j), k, st);
    }
}
const tp = (tx: number, ty: number): Pt => ({ x: tx * TILE, y: ty * TILE });
const mirror = (p: Pt): Pt => ({ x: MW * TILE - p.x, y: CH * TILE - p.y });
const both = (a: Pt[]): Pt[] => [...a, ...a.map(mirror)];
function hsh(a: number, b: number, c: number): number {
  let n = Math.imul(a + 11, 374761393) ^ Math.imul(b + 7, 668265263) ^ Math.imul(c + 3, 982451653);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

/** map 0 – dusty town for 5v5 */
function dustTown() {
  rect(0, 0, MW, 1, 1, 2);
  rect(0, 0, 1, MH, 1, 2);
  const WALLS: number[][] = [
    [9, 11, 1, 5, 3], [9, 22, 1, 5, 3], [9, 11, 3, 1, 3], [9, 26, 3, 1, 3],
    [13, 7, 8, 2, 0], [13, 29, 8, 2, 3],
    [15, 13, 4, 4, 1], [15, 21, 4, 4, 0],
    [24, 3, 2, 2, 2], [24, 33, 2, 2, 2],
    [26, 10, 2, 5, 3],
    [29, 6, 2, 3, 1],
    [28, 18, 4, 2, 1],
  ];
  const CRATE: number[][] = [
    [11, 4, 2, 1], [12, 5, 1, 1], [11, 33, 2, 1],
    [21, 12, 1, 2], [20, 25, 2, 1], [22, 18, 1, 2],
    [6, 9, 1, 1], [6, 28, 1, 1], [17, 3, 1, 2], [18, 33, 2, 1], [28, 14, 1, 1],
  ];
  const SANDBAGS: number[][] = [[11, 18, 1, 2], [24, 8, 2, 1], [24, 29, 2, 1], [25, 20, 1, 2]];
  const PLANTERS: number[][] = [[3, 3], [3, 34], [12, 13], [12, 24], [21, 1], [38, 1]];
  for (const r of WALLS) {
    rect(r[0], r[1], r[2], r[3], 1, r[4]);
    BUILDINGS.push({ x: r[0], y: r[1], w: r[2], h: r[3], style: r[4] });
    if (!(r[0] === 28 && r[1] === 18)) BUILDINGS.push({ x: MW - r[0] - r[2], y: MH - r[1] - r[3], w: r[2], h: r[3], style: r[4] });
  }
  for (const r of CRATE) rect(r[0], r[1], r[2], r[3], 2);
  for (const r of SANDBAGS) rect(r[0], r[1], r[2], r[3], 3);
  for (const r of PLANTERS) rect(r[0], r[1], 1, 1, 4);

  const A: Pt[] = [tp(4.5, 16.5), tp(4.5, 19), tp(4.5, 21.5), tp(6.5, 17.75), tp(6.5, 20.25)];
  SPAWNS = [A, A.map(mirror)];
  LANES = [tp(29.5, 4.5), tp(29.5, 15.5), tp(30.5, 22.5), tp(30.5, 33.5)];
  BARREL_SPOTS = both([tp(21.5, 5.5), tp(21.5, 32.5), tp(24.5, 15.5), tp(19.5, 19), tp(13.5, 10.5), tp(27, 27.5)]);
  const F: Pt[] = [tp(1.6, 14.4), tp(1.6, 24.2)];
  FLAGS = [...F.map((p) => ({ ...p, team: 0 })), ...F.map(mirror).map((p) => ({ ...p, team: 1 }))];
}

/**
 * Build one enterable building: the interior is split into rooms (each partition has a doorway) and furnished by room type.
 * Furniture styles - tall & searchable (kind 2): 10 wardrobe, 11 fridge, 12 bookshelf, 13 medicine cabinet, 14 shop shelf;
 * 15 glass-door drinks fridge; low (kind 3): 20 table, 21 sofa, 22/23 bed, 24 counter, 25 boxes, 26 toilet, 27 bathtub, 28 TV, 29 plant,
 * 30 checkout, 31 shopping cart, 32 produce crate, 33 freezer chest.
 */
function house(x: number, y: number, w: number, h: number, st: number, doors: number[][], shop: boolean, stair = false, upper = false): number {
  const id = HOUSES.length;
  const H: House = { x, y, w, h, style: st, shop, doors: [], rooms: [], dx: 0, dy: 0 };
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      const edge = i === 0 || j === 0 || i === w - 1 || j === h - 1;
      put(x + i, y + j, edge ? 1 : 0, edge ? st : 0);
      houseIdx[(y + j) * MW + x + i] = id;
    }
  const key = (tx: number, ty: number) => ty * MW + tx;
  const keep = new Set<number>(); // tiles that must stay walkable (both sides of every doorway)
  for (const d of doors) {
    put(d[0], d[1], 0, 0);
    const ox = d[0] === x ? -1 : d[0] === x + w - 1 ? 1 : 0, oy = d[1] === y ? -1 : d[1] === y + h - 1 ? 1 : 0;
    H.doors.push({ tx: d[0], ty: d[1], ox, oy });
    keep.add(key(d[0] - ox, d[1] - oy));
  }
  if (stair) {
    // staircase in the north-west corner: two tiles of steps, the top one leads to the other floor
    H.stair = { tx: x + 1, ty: y + 1 };
    for (const [i, j] of [[1, 1], [1, 2], [2, 1], [2, 2], [1, 3]]) keep.add(key(x + i, y + j));
  }
  // binary space partition: walls never cover a "keep" tile, so no doorway can be sealed off
  const leaves: number[][] = [];
  const split = (a: number, b: number, c: number, d: number, depth: number) => {
    const rw = c - a + 1, rh = d - b + 1, canV = rw >= 7, canH = rh >= 7;
    if (shop || depth >= 3 || (!canV && !canH)) { leaves.push([a, b, c, d]); return; }
    if (canV && (!canH || rw >= rh)) {
      const p = a + 3 + ((hsh(id, depth, a * 31 + b) * (rw - 6)) | 0), gap = b + ((hsh(id, p, 11 + depth) * rh) | 0);
      for (let ty = b; ty <= d; ty++) {
        if (ty !== gap && !keep.has(key(p, ty))) put(p, ty, 1, st);
        else { keep.add(key(p - 1, ty)); keep.add(key(p + 1, ty)); } // an opening in this wall: keep both sides clear
      }
      keep.add(key(p - 1, gap)); keep.add(key(p, gap)); keep.add(key(p + 1, gap));
      split(a, b, p - 1, d, depth + 1);
      split(p + 1, b, c, d, depth + 1);
    } else {
      const p = b + 3 + ((hsh(id, depth, a * 17 + b * 5) * (rh - 6)) | 0), gap = a + ((hsh(id, p, 23 + depth) * rw) | 0);
      for (let tx = a; tx <= c; tx++) {
        if (tx !== gap && !keep.has(key(tx, p))) put(tx, p, 1, st);
        else { keep.add(key(tx, p - 1)); keep.add(key(tx, p + 1)); }
      }
      keep.add(key(gap, p - 1)); keep.add(key(gap, p)); keep.add(key(gap, p + 1));
      split(a, b, c, p - 1, depth + 1);
      split(a, p + 1, c, d, depth + 1);
    }
  };
  split(x + 1, y + 1, x + w - 2, y + h - 2, 0);

  const place = (tx: number, ty: number, k: number, s: number, search = true) => {
    if (tx < x + 1 || ty < y + 1 || tx > x + w - 2 || ty > y + h - 2) return;
    if (grid[key(tx, ty)] !== 0 || keep.has(key(tx, ty))) return;
    put(tx, ty, k, s);
    if (k === 2 && search) CRATES.push({ tx, ty, house: id });
  };
  const furnish = (a: number, b: number, c: number, d: number, type: number, n: number) => {
    const rw = c - a + 1, rh = d - b + 1, mx = (a + c) >> 1, my = (b + d) >> 1, v = hsh(id, n, 3);
    if (type === 1) {
      place(mx, b, 3, 28);
      place(mx, my, 3, 20);
      if (rh >= 4) { place(mx, my + 1, 3, 21); if (rw >= 5) place(mx - 1, my + 1, 3, 21); }
      place(a, b, 2, 12);
      place(c, b, 2, v > 0.5 ? 12 : 10);
      place(c, d, 3, 29);
      if (rw * rh >= 30) place(a, d, 2, 13);
    } else if (type === 2) {
      place(a, d - 1, 3, 22); place(a, d, 3, 23);
      place(c, b, 2, 10);
      if (rw >= 5) { place(c, d - 1, 3, 22); place(c, d, 3, 23); } else place(c, d, 3, 29);
      if (rw * rh >= 20) place(a, b, 2, v > 0.5 ? 13 : 12);
    } else if (type === 3) {
      place(a, b, 2, 11);
      for (let i = a + 1; i <= Math.min(c - 1, a + 4); i++) place(i, b, 3, 24);
      place(c, b, 2, 10);
      if (rh >= 4) { place(mx, d - 1, 3, 20); if (rw >= 5) place(mx + 1, d - 1, 3, 20); }
    } else if (type === 4) {
      place(a, b, 3, 26); place(c, b, 2, 13); place(c, d, 3, 27);
    } else if (type === 5) {
      place(a, b, 2, 13); place(c, b, 2, 10); place(a, d, 3, 25); place(c, d, 3, 25);
      if (rw >= 4) place(a + 1, d, 3, 25);
    } else {
      // supermarket: drinks fridges on the north wall, checkouts at the entrance, aisles of shelves, freezer chests on the south wall
      const ex = Math.min(doors[0][0], doors[1][0]), south = H.doors[0].oy === 1, e = south ? -1 : 1, er = south ? d : b;
      const lane = (tx: number) => tx >= ex - 3 && tx <= ex + 4;
      for (let tx = a; tx <= c; tx++) if (south || !lane(tx)) place(tx, b, 2, 15, hsh(tx, b, 9) > 0.55);
      for (let tx = a + 1; tx <= c - 1; tx++) if (tx % 4 !== 0 && (!south || !lane(tx))) place(tx, d, 3, 33);
      for (const tx of [ex - 2, ex - 1, ex + 2, ex + 3]) place(tx, er + 2 * e, 3, 30);
      for (let tx = a + 1; tx <= a + 3; tx++) place(tx, er + 2 * e, 3, 32);
      place(c - 2, er + 2 * e, 3, 31); place(c - 4, er + 3 * e, 3, 31); place(ex + 1, er + 7 * e, 3, 31);
      for (let j = 4; j <= rh - 4; j += 2)
        for (let tx = a + 1; tx <= c - 1; tx++) if ((tx < ex - 1 || tx > ex + 2) && (tx - a) % 8 !== 7) place(tx, er + j * e, 2, 14, hsh(tx, j, 9) > 0.6);
    }
  };
  // biggest room is the living room, then the kitchen...; the smallest one is the bathroom
  const TYPES = upper ? [2, 1, 2, 2, 5, 2, 5, 5] : [1, 3, 2, 2, 5, 2, 5, 5];
  const order = leaves.map((_, i) => i).sort((p, q) => (leaves[q][2] - leaves[q][0] + 1) * (leaves[q][3] - leaves[q][1] + 1) - (leaves[p][2] - leaves[p][0] + 1) * (leaves[p][3] - leaves[p][1] + 1));
  order.forEach((li, rank) => {
    const [a, b, c, d] = leaves[li];
    const type = shop ? 6 : rank === order.length - 1 && order.length >= 3 ? 4 : TYPES[rank] ?? 5;
    const rid = roomCount++;
    for (let ty = b; ty <= d; ty++) for (let tx = a; tx <= c; tx++) { roomIdx[key(tx, ty)] = rid; roomKind[key(tx, ty)] = type; }
    H.rooms.push({ x: a, y: b, w: c - a + 1, h: d - b + 1, type });
    furnish(a, b, c, d, type, li);
  });
  HOUSES.push(H);
  return id;
}

/** a wrecked car: two tiles, style 1/3 = head of a horizontal/vertical car (5 = police car), 2/4 = its tail. Mirrored like everything else. */
function car(x: number, y: number, horiz: boolean, police = false) {
  const set = (hx: number, hy: number) => {
    put(hx, hy, 2, horiz ? (police ? 5 : 1) : 3);
    put(hx + (horiz ? 1 : 0), hy + (horiz ? 0 : 1), 2, horiz ? 2 : 4);
  };
  set(x, y);
  set(MW - 1 - x - (horiz ? 1 : 0), CH - 1 - y - (horiz ? 0 : 1));
}
function zrect(x: number, y: number, w: number, h: number, z: number) {
  for (let j = 0; j < h; j++)
    for (let i = 0; i < w; i++) {
      zone[(y + j) * MW + x + i] = z;
      zone[(CH - 1 - y - j) * MW + (MW - 1 - x - i)] = z;
    }
}

/**
 * map 1 - a night city overrun by zombies, laid out as a real street grid:
 * 4-tile roads (x 1-4, 35-38, 61-64, 87-90, 121-124 / y 1-4, 26-29, 48-51, 73-76), city blocks ringed by a sidewalk,
 * alleys and back yards inside the blocks, a big square with the evac zone in the middle - and two-storey houses,
 * whose upper floors live in a hidden strip below the city and are reached by stairs.
 */
function zombieCity() {
  rect(0, 0, MW, 1, 1, 2);
  rect(0, 0, 1, CH, 1, 2);
  for (let ty = CH; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) put(tx, ty, 1, 9); // void around the upper floors
  PAD = { x: 58, y: 34, w: 10, h: 10 };
  // city blocks (left half, mirrored): sidewalk ring, concrete inside
  for (const b of [[5, 5, 30, 21], [39, 5, 22, 21], [5, 30, 30, 18], [5, 52, 30, 21], [39, 52, 22, 21]]) {
    zrect(b[0], b[1], b[2], b[3], 1);
    zrect(b[0] + 1, b[1] + 1, b[2] - 2, b[3] - 2, 5);
  }
  zrect(39, 30, 48, 18, 2);
  // back yards
  for (const y of [[6, 19, 20, 6], [40, 17, 20, 2], [40, 65, 20, 7]]) zrect(y[0], y[1], y[2], y[3], 6);
  // enterable buildings [x, y, w, h, style, doors, shop, two storeys]; front doors open onto the sidewalk, back doors onto yards and alleys
  const HOME: [number, number, number, number, number, number[][], boolean, boolean][] = [
    [6, 6, 20, 13, 5, [[14, 6], [6, 12], [20, 18]], false, true],
    [40, 6, 20, 11, 6, [[49, 6], [40, 11], [59, 11], [45, 16]], false, false],
    [17, 31, 17, 16, 7, [[33, 38], [24, 31], [17, 42], [26, 46]], false, true],
    [40, 53, 20, 12, 6, [[49, 53], [59, 58], [40, 59], [46, 64]], false, false],
    [6, 53, 28, 16, 8, [[19, 53], [20, 53], [33, 60], [11, 68]], true, false],
  ];
  // solid buildings [x, y, w, h, style]
  const BLOCKS: number[][] = [[28, 6, 6, 9, 2], [28, 16, 6, 9, 3], [40, 19, 20, 6, 3], [6, 31, 9, 7, 0], [6, 39, 9, 8, 4]];
  // military checkpoint: four L-shaped corners around the evac zone
  const CHECKPOINT: number[][] = [[57, 33, 4, 1], [57, 33, 1, 3], [65, 33, 4, 1], [68, 33, 1, 3]];
  const BARRICADE: number[][] = [[62, 32, 2, 1], [55, 38, 1, 2], [57, 37, 1, 1], [34, 27, 1, 2]];
  // cars are parked along the curbs, facing along the road [x, y, horizontal]
  const CARS: [number, number, boolean][] = [
    [12, 4, true], [26, 1, true], [44, 4, true], [52, 1, true],
    [8, 26, true], [16, 29, true], [44, 26, true], [52, 29, true],
    [10, 51, true], [24, 48, true], [42, 51, true], [50, 48, true],
    [14, 73, true], [28, 76, true], [46, 73, true], [54, 76, true],
    [4, 10, false], [4, 34, false], [4, 58, false], [1, 44, false], [1, 18, false],
    [35, 9, false], [38, 16, false], [35, 56, false], [38, 64, false], [35, 36, false],
    [61, 10, false], [64, 18, false],
  ];
  const DUMPSTERS: number[][] = [[26, 9], [27, 20], [15, 34], [16, 44], [9, 70], [24, 70], [30, 15], [9, 38]];
  // street lamps stand on the sidewalk, traffic lights on the corners of the big intersections, trees in yards and on the square
  const LAMPS: number[][] = [
    [10, 5], [24, 5], [5, 18], [34, 10], [34, 20], [12, 25], [26, 25],
    [44, 5], [55, 5], [39, 18], [60, 18], [45, 25], [55, 25],
    [10, 30], [30, 30], [5, 35], [34, 33], [34, 43], [12, 47], [30, 47],
    [10, 52], [28, 52], [5, 60], [34, 56], [34, 66], [14, 72], [28, 72],
    [44, 52], [55, 52], [39, 66], [60, 66], [46, 72], [55, 72],
  ];
  const SIGNALS: number[][] = [[34, 25], [39, 25], [34, 30], [60, 25], [34, 47], [34, 52], [39, 52], [39, 47]];
  const TREES: number[][] = [[9, 21], [16, 22], [22, 20], [43, 17], [56, 18], [43, 67], [50, 69], [56, 66], [47, 70], [42, 32], [42, 45], [48, 31], [48, 46]];
  for (const r of BLOCKS) {
    rect(r[0], r[1], r[2], r[3], 1, r[4]);
    BUILDINGS.push({ x: r[0], y: r[1], w: r[2], h: r[3], style: r[4] }, { x: MW - r[0] - r[2], y: CH - r[1] - r[3], w: r[2], h: r[3], style: r[4] });
  }
  const ground: number[] = [];
  for (const d of HOME) ground.push(house(d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7]));
  for (const d of HOME) ground.push(house(MW - d[0] - d[2], CH - d[1] - d[3], d[2], d[3], d[4] === 8 ? 8 : 5 + ((d[4] - 4) % 3), d[5].map((q) => [MW - 1 - q[0], CH - 1 - q[1]]), d[6], d[7]));
  // upper floors: same footprint as the house below, linked by the staircase
  let ux = 3;
  for (const gi of ground) {
    const G = HOUSES[gi];
    if (!G.stair) continue;
    const ui = house(ux, CH + 3, G.w, G.h, G.style, [], false, true, true), U = HOUSES[ui];
    G.up = ui; U.under = gi; U.dx = U.x - G.x; U.dy = U.y - G.y;
    const a = G.stair.ty * MW + G.stair.tx, b = U.stair!.ty * MW + U.stair!.tx;
    portal[a] = b; portal[b] = a;
    ux += G.w + 3;
  }
  for (const r of CHECKPOINT) rect(r[0], r[1], r[2], r[3], 1, 1);
  for (const r of BARRICADE) rect(r[0], r[1], r[2], r[3], 3);
  for (const c of CARS) car(c[0], c[1], c[2]);
  // a crash in the middle of an intersection: a police car rammed by a sedan
  car(35, 27, true, true);
  car(37, 27, false);
  for (const r of DUMPSTERS) rect(r[0], r[1], 1, 1, 2, 0);
  rect(14, 70, 2, 1, 3, 25);
  for (const r of LAMPS) rect(r[0], r[1], 1, 1, 4, 0);
  for (const r of SIGNALS) rect(r[0], r[1], 1, 1, 4, 2);
  for (const r of TREES) rect(r[0], r[1], 1, 1, 4, 1);

  const squad: Pt[] = [tp(61.5, 37.5), tp(64.5, 37.5), tp(61.5, 40.5), tp(64.5, 40.5), tp(63, 39)];
  SPAWNS = [squad, squad];
  LANES = [tp(63, 39)];
  BARREL_SPOTS = both([tp(59.5, 35.5), tp(54.5, 41.5), tp(63, 31.5), tp(27, 12.5), tp(15.5, 40.5), tp(20.5, 70.5)]);
  FLAGS = [{ ...tp(63, 34.4), team: 0 }];
  NESTS = both([tp(3, 3), tp(3, 75), tp(63, 3), tp(3, 39), tp(37, 50), tp(20, 28)]);
}

let current = -1;
/** switch the active map (0 = dust town, 1 = zombie city) */
export function loadMap(id: number) {
  if (id === current) return;
  current = id;
  MW = id === 0 ? 60 : 126;
  CH = id === 0 ? 38 : 78;
  MH = id === 0 ? 38 : 99;
  grid.fill(0);
  style.fill(0);
  houseIdx.fill(-1);
  roomIdx.fill(-1);
  roomKind.fill(0);
  zone.fill(0);
  portal.fill(-1);
  roomCount = 0;
  BUILDINGS = [];
  NESTS = [];
  HOUSES = [];
  CRATES = [];
  if (id === 0) dustTown();
  else zombieCity();
  PALMS = [];
  for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) if (grid[ty * MW + tx] === 4) PALMS.push({ ...tp(tx + 0.5, ty + 0.5), k: style[ty * MW + tx] });
}
loadMap(0);

const off = (tx: number, ty: number) => tx < 0 || ty < 0 || tx >= MW || ty >= MH;
export const kindAt = (tx: number, ty: number) => (off(tx, ty) ? 1 : grid[ty * MW + tx]);
export const styleAt = (tx: number, ty: number) => (off(tx, ty) ? 2 : style[ty * MW + tx]);
/** index into HOUSES for a tile (walls and doors included), or -1 */
export const houseAt = (tx: number, ty: number) => (off(tx, ty) ? -1 : houseIdx[ty * MW + tx]);
/** house index at a pixel position */
export const houseAtPx = (x: number, y: number) => houseAt(Math.floor(x / TILE), Math.floor(y / TILE));
/** ground type of a city tile */
export const zoneAt = (tx: number, ty: number) => (off(tx, ty) ? 0 : zone[ty * MW + tx]);
/** stairs: tile index this tile leads to on the other floor, or -1 */
export const portalAt = (tx: number, ty: number) => (off(tx, ty) ? -1 : portal[ty * MW + tx]);
/** room type of a tile (0 = not inside a room) */
export const roomTypeAt = (tx: number, ty: number) => (off(tx, ty) ? 0 : roomKind[ty * MW + tx]);
/** unique room id at a pixel position, or -1 (doorways and walls belong to no room) */
export const roomAtPx = (x: number, y: number) => {
  const tx = Math.floor(x / TILE), ty = Math.floor(y / TILE);
  return off(tx, ty) ? -1 : roomIdx[ty * MW + tx];
};
/** blocks walking */
export const solidAt = (x: number, y: number) => kindAt(Math.floor(x / TILE), Math.floor(y / TILE)) !== 0;
/** blocks bullets and sight (low cover does not) */
export const blockAt = (x: number, y: number) => {
  const k = kindAt(Math.floor(x / TILE), Math.floor(y / TILE));
  return k !== 0 && k !== 3;
};

/** bullet / sight line test */
export function los(x0: number, y0: number, x1: number, y1: number): boolean {
  const dx = x1 - x0, dy = y1 - y0;
  const n = Math.ceil(Math.hypot(dx, dy) / 4);
  for (let i = 1; i < n; i++) if (blockAt(x0 + (dx * i) / n, y0 + (dy * i) / n)) return false;
  return true;
}

/** can a body of half-size h walk the straight line */
export function walkClear(x0: number, y0: number, x1: number, y1: number, h = 5): boolean {
  const dx = x1 - x0, dy = y1 - y0;
  const n = Math.max(1, Math.ceil(Math.hypot(dx, dy) / 4));
  for (let i = 0; i <= n; i++) {
    const x = x0 + (dx * i) / n, y = y0 + (dy * i) / n;
    if (solidAt(x - h, y - h) || solidAt(x + h, y - h) || solidAt(x - h, y + h) || solidAt(x + h, y + h)) return false;
  }
  return true;
}

/** distance a ray travels before hitting something solid */
export function rayEnd(x: number, y: number, ang: number, max: number): number {
  const c = Math.cos(ang), s = Math.sin(ang);
  for (let d = 0; d < max; d += 3) if (blockAt(x + c * d, y + s * d)) return d;
  return max;
}

const prev = new Int32Array(MAXW * MAXH);
const queue = new Int32Array(MAXW * MAXH);
const DIRS = [1, 0, -1, 0, 0, 1, 0, -1, 1, 1, 1, -1, -1, 1, -1, -1];

/** BFS on the tile grid. Returns flat [x0,y0,x1,y1,...] of pixel waypoints. */
export function findPath(sx: number, sy: number, gx: number, gy: number): number[] {
  const stx = Math.floor(sx / TILE), sty = Math.floor(sy / TILE);
  const gtx = Math.floor(gx / TILE), gty = Math.floor(gy / TILE);
  if (kindAt(stx, sty) || kindAt(gtx, gty)) return [];
  const start = sty * MW + stx, goal = gty * MW + gtx;
  if (start === goal) return [gx, gy];
  prev.fill(-1);
  let head = 0, tail = 0;
  queue[tail++] = start;
  prev[start] = start;
  let found = false;
  while (head < tail) {
    const cur = queue[head++];
    if (cur === goal) { found = true; break; }
    const cx = cur % MW, cy = (cur / MW) | 0;
    for (let d = 0; d < 16; d += 2) {
      const ox = DIRS[d], oy = DIRS[d + 1];
      const nx = cx + ox, ny = cy + oy;
      if (kindAt(nx, ny)) continue;
      if (ox && oy && (kindAt(cx + ox, cy) || kindAt(cx, cy + oy))) continue;
      const ni = ny * MW + nx;
      if (prev[ni] !== -1) continue;
      prev[ni] = cur;
      queue[tail++] = ni;
    }
    // stairs lead to the other floor
    const pt = portal[cur];
    if (pt >= 0 && prev[pt] === -1) { prev[pt] = cur; queue[tail++] = pt; }
  }
  if (!found) return [];
  const out: number[] = [];
  let cur = goal;
  while (cur !== start) {
    out.push((((cur / MW) | 0) + 0.5) * TILE, ((cur % MW) + 0.5) * TILE);
    cur = prev[cur];
  }
  out.reverse();
  return out;
}

import { RAISE, TILE } from "./defs";
import type { BugKind } from "./defs";
import { BUILDINGS, CH, HOUSES, MH, MW, NESTS, PAD, PALMS, houseAt, kindAt, loadMap, portalAt, roomTypeAt, styleAt, zoneAt } from "./map";
import { buildFloor, buildMini, buildPalm, buildWalls, fromMap, glyphs, h2, mk, roofProps, whiten } from "./sprites";

type Cv = HTMLCanvasElement;
type Paint = (col: string, a: number, b: number, w: number, h: number) => void;
/** fx: 1 broken flicker, 2/3 police red/blue, 4 slow blink. beam: a headlight cone pointing that way */
export interface Lamp { x: number; y: number; r: number; a: number; col: string; pad: boolean; house?: number; fx?: number; beam?: number }

/** pixel-perfect filled ellipse (optionally only rows y0..y1) */
function ell(R: Paint, cx: number, cy: number, rx: number, ry: number, col: string, y0 = -ry, y1 = ry) {
  for (let j = y0; j <= y1; j++) {
    const w = Math.round(rx * Math.sqrt(Math.max(0, 1 - (j * j) / (ry * ry))));
    R(col, cx - w, cy + j, w * 2 + 1, 1);
  }
}
const tall = (tx: number, ty: number) => {
  const k = kindAt(tx, ty);
  return k !== 0 && k !== 3;
};
const onPad = (tx: number, ty: number) => tx >= PAD.x && tx < PAD.x + PAD.w && ty >= PAD.y && ty < PAD.y + PAD.h;
/** 0 road, 1 sidewalk, 2 square, 3 wall, 4 house interior, 5 alley concrete, 6 grass */
function cls(tx: number, ty: number): number {
  if (houseAt(tx, ty) >= 0) return kindAt(tx, ty) === 1 ? 3 : 4;
  if (kindAt(tx, ty) === 1) return 3;
  return zoneAt(tx, ty);
}
/** first tile of every 4-tile road */
const VR = () => [1, 35, 61, MW - 39, MW - 5];
const HR = () => [1, 26, CH - 30, CH - 5];
/** step colours from the far end to the near end: stairs going up, and stairs going down into the dark */
const STAIR_UP = ["#c9a36e", "#bb9562", "#ad8757", "#9f7a4d", "#916d43", "#83613a", "#765531", "#694a29"];
const STAIR_DN = ["#0d0907", "#1a120d", "#2a1d14", "#3a281b", "#4a3423", "#5c402b", "#6e4d33", "#805a3c"];
const GOODS = ["#d8433b", "#f5c542", "#3b6ea8", "#3f8a5a", "#e6e0d0", "#d07a2a"];
const INK = "#0b0b10";

/* ───────────── streets, yards and house floors ───────────── */
function buildFloorCity(): Cv {
  const W = MW * TILE, H = MH * TILE;
  const [c, x] = mk(W, H);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  const grid: number[] = [];
  for (let ty = 0; ty < MH; ty++) for (let tx = 0; tx < MW; tx++) grid.push(cls(tx, ty));
  const at = (tx: number, ty: number) => (tx < 0 || ty < 0 || tx >= MW || ty >= MH ? 3 : grid[ty * MW + tx]);
  const atPx = (px: number, py: number) => at((px / TILE) | 0, (py / TILE) | 0);

  R("#2b2d35", 0, 0, W, H);
  for (let i = 0; i < 260; i++) {
    const bx = h2(i, 1, 50) * W, by = h2(i, 2, 51) * H, col = i % 2 ? "rgba(58,60,72,0.35)" : "rgba(14,14,20,0.35)";
    for (let j = 0; j < 8; j++) {
      const a = h2(i, j, 52) * 6.283, r = h2(i, j, 53) * 22;
      R(col, (bx + Math.cos(a) * r) | 0, (by + Math.sin(a) * r * 0.7) | 0, 6 + ((h2(i, j, 54) * 12) | 0), 3 + ((h2(i, j, 55) * 5) | 0));
    }
  }
  R("#07050c", 0, CH * TILE, W, H - CH * TILE); // nothing but dark around the upper floors
  const CURB = "#8a8c98";
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      const k = at(tx, ty);
      if (k === 3 || onPad(tx, ty)) continue;
      const px = tx * TILE, py = ty * TILE, v = h2(tx, ty, 20);
      if (k === 4) {
        const hs = HOUSES[houseAt(tx, ty)], rt = roomTypeAt(tx, ty);
        const door = hs.doors.some((d) => d.tx === tx && d.ty === ty);
        const tiled = !door && (rt === 3 || rt === 4 || rt === 6);
        if (tiled) {
          // kitchen / bathroom / shop tiles
          const lite = rt === 6 ? ["#98a1ab", "#b3bbc4"] : rt === 4 ? ["#7fa6ae", "#9cc0c6"] : ["#8d939c", "#a4aab2"];
          for (let r = 0; r < 2; r++)
            for (let q = 0; q < 2; q++) {
              R(lite[(q + r) % 2], px + q * 8, py + r * 8, 8, 8);
              R(rt === 6 ? "#7a828c" : "#6c727b", px + q * 8 + 7, py + r * 8, 1, 8); R(rt === 6 ? "#7a828c" : "#6c727b", px + q * 8, py + r * 8 + 7, 8, 1);
            }
        } else {
          // wooden planks
          R(door ? "#4a3626" : hs.under !== undefined ? "#6e5347" : "#74583a", px, py, TILE, TILE);
          for (let r = 0; r < 4; r++) {
            R(door ? "#33241a" : "#5a422a", px, py + r * 4 + 3, TILE, 1);
            R(door ? "#33241a" : "#5a422a", px + ((tx * 7 + ty * 3 + r * 5) % 16), py + r * 4, 1, 3);
            if (h2(tx, ty, r) > 0.6) R(door ? "#5c4430" : "#8a6c48", px + ((h2(tx, ty, r + 4) * 11) | 0), py + r * 4 + 1, 4, 1);
          }
        }
        const sTop = portalAt(tx, ty) >= 0, sLow = portalAt(tx, ty - 1) >= 0;
        if (sTop || sLow) {
          // staircase against the north wall: up on the ground floor, down into the dark on the upper floor
          const down = hs.under !== undefined, C = down ? STAIR_DN : STAIR_UP;
          R("#140e0a", px, py, TILE, TILE);
          for (let i = 0; i < 4; i++) {
            R(C[(sTop ? 0 : 4) + i], px + 2, py + i * 4, 12, 4);
            R(down ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.22)", px + 2, py + i * 4, 12, 1);
            R("rgba(0,0,0,0.35)", px + 2, py + i * 4 + 3, 12, 1);
          }
          R("#3a2816", px, py, 2, TILE); R("#3a2816", px + 14, py, 2, TILE); R("#8a6844", px, py, 1, TILE); R("#8a6844", px + 14, py, 1, TILE);
          if (sLow) for (let i = 0; i < 3; i++) R("#f5c542", px + 7 - i, py + (down ? 13 - i : 10 + i), 2 + i * 2, 1);
        } else if (!door && v > 0.9) { ell(R, px + 8, py + 8, 4, 3, "rgba(120,18,30,0.6)"); R("rgba(120,18,30,0.4)", px + 11, py + 9, 4, 1); }
        else if (!door && v > 0.84) { R("#d8d8d0", px + 5, py + 6, 4, 3); R("#b0b0a8", px + 6, py + 7, 3, 1); }
        else if (!door && v < 0.05) { R("#3a2a1c", px + 4, py + 5, 3, 1); R("#3a2a1c", px + 6, py + 6, 1, 4); }
      } else if (k === 2) {
        // paved square
        R("#3f4049", px, py, TILE, TILE);
        for (let r = 0; r < 2; r++)
          for (let q = 0; q < 2; q++) {
            const w = h2(tx * 2 + q, ty * 2 + r, 1), sx = px + q * 8, sy = py + r * 8;
            R(w > 0.7 ? "#5c5d68" : w > 0.35 ? "#555661" : "#4e4f5a", sx, sy, 7, 7);
            R("rgba(255,255,255,0.08)", sx, sy, 7, 1);
            if (w > 0.95) { R("#3f6a3a", sx + 3, sy + 4, 2, 2); R("#5a8a4a", sx + 3, sy + 4, 1, 1); }
          }
        if (at(tx, ty - 1) === 0) R(CURB, px, py, TILE, 2);
        if (at(tx, ty + 1) === 0) { R(CURB, px, py + 13, TILE, 2); R("#1c1d24", px, py + 15, TILE, 1); }
        if (at(tx - 1, ty) === 0) R(CURB, px, py, 2, TILE);
        if (at(tx + 1, ty) === 0) { R(CURB, px + 13, py, 2, TILE); R("#1c1d24", px + 15, py, 1, TILE); }
      } else if (k === 1) {
        // sidewalk slab with curbs facing the road
        R("#4d4f5a", px, py, TILE, TILE);
        R("#5b5d69", px, py, 15, 1); R("#5b5d69", px, py, 1, 15);
        R("#3c3e48", px + 15, py, 1, TILE); R("#3c3e48", px, py + 15, TILE, 1);
        if (v > 0.8) { R("#3c3e48", px + 4, py + 6, 5, 1); R("#3c3e48", px + 8, py + 7, 1, 4); }
        else if (v < 0.07) { R("#b9b9b0", px + 4, py + 5, 5, 4); R("#8a8a84", px + 5, py + 6, 3, 1); R("#8a8a84", px + 5, py + 8, 2, 1); } // old newspaper
        if (at(tx, ty - 1) === 0) R(CURB, px, py, TILE, 2);
        if (at(tx, ty + 1) === 0) { R(CURB, px, py + 13, TILE, 2); R("#1c1d24", px, py + 15, TILE, 1); }
        if (at(tx - 1, ty) === 0) R(CURB, px, py, 2, TILE);
        if (at(tx + 1, ty) === 0) { R(CURB, px + 13, py, 2, TILE); R("#1c1d24", px + 15, py, 1, TILE); }
      } else if (k === 5) {
        // back alley: stained concrete
        R("#33343c", px, py, TILE, TILE);
        R("#3b3c45", px + ((tx + ty) % 2 ? 0 : 8), py, 8, 8); R("#2c2d34", px + ((tx + ty) % 2 ? 8 : 0), py + 8, 8, 8);
        R("#26272e", px, py + 15, TILE, 1);
        if (v > 0.9) { R("#111117", px + 3, py + 5, 8, 7); R("#111117", px + 5, py + 3, 5, 3); R("#2a2a33", px + 4, py + 6, 3, 2); R("#f5c542", px + 7, py + 3, 1, 1); } // rubbish bag
        else if (v > 0.83) { R("#8a6a40", px + 3, py + 4, 9, 7); R("#a8834c", px + 3, py + 4, 9, 1); R("#6a4f2e", px + 7, py + 4, 1, 7); } // cardboard
        else if (v < 0.07) ell(R, px + 8, py + 9, 5, 2, "#1a2030");
        else if (v < 0.12) { R("rgba(120,18,30,0.5)", px + 4, py + 6, 6, 3); R("rgba(120,18,30,0.35)", px + 9, py + 8, 4, 1); }
      } else if (k === 6) {
        // overgrown yard
        R("#22362a", px, py, TILE, TILE);
        for (let i = 0; i < 6; i++) R(i % 2 ? "#2f4c35" : "#1a2a20", px + ((h2(tx, ty, i) * 14) | 0), py + ((h2(tx, ty, i + 9) * 14) | 0), 1, 2 + (i % 2));
        if (v > 0.9) { R("#e6e0d0", px + 5, py + 6, 1, 1); R("#f5c542", px + 9, py + 9, 1, 1); R("#e6e0d0", px + 11, py + 4, 1, 1); }
        else if (v < 0.1) { R("#3a3026", px + 3, py + 5, 8, 5); R("#4a3e30", px + 4, py + 6, 4, 2); }
        // hedge where the yard meets the pavement
        if (at(tx, ty - 1) === 1) R("#14241a", px, py, TILE, 3);
        if (at(tx, ty + 1) === 1) { R("#14241a", px, py + 13, TILE, 3); R("#2a4a30", px, py + 13, TILE, 1); }
        if (at(tx - 1, ty) === 1) R("#14241a", px, py, 3, TILE);
        if (at(tx + 1, ty) === 1) R("#14241a", px + 13, py, 3, TILE);
      } else {
        // asphalt
        for (let i = 0; i < 5; i++) R(i % 2 ? "#393b45" : "#1f2027", px + ((h2(tx, ty, i) * 14) | 0), py + ((h2(tx, ty, i + 9) * 15) | 0), i === 0 ? 3 : 2, 1);
        const ox = 3 + ((h2(tx, ty, 21) * 9) | 0), oy = 3 + ((h2(tx, ty, 22) * 9) | 0);
        if (v > 0.95) { R("#17181e", px + 3, py + oy, 5, 1); R("#17181e", px + 7, py + oy + 1, 1, 3); R("#17181e", px + 8, py + oy + 3, 5, 1); }
        else if (v > 0.91) ell(R, px + 8, py + 8, 5, 3, "rgba(10,10,14,0.5)");
        else if (v > 0.88) { R("#b9b9b0", px + ox, py + oy, 3, 2); R("#8a8a84", px + ox + 1, py + oy + 1, 2, 1); }
        else if (v < 0.025) { ell(R, px + ox, py + oy, 3, 2, "rgba(120,18,30,0.6)"); R("rgba(120,18,30,0.45)", px + ox + 3, py + oy + 1, 4, 1); }
      }
    }

  // ── road markings: centre lines, edge lines and zebra crossings at every intersection ──
  const vr = VR(), hr = HR();
  const nearV = (tx: number) => vr.some((v0) => tx >= v0 - 3 && tx <= v0 + 6);
  const nearH = (ty: number) => hr.some((h0) => ty >= h0 - 3 && ty <= h0 + 6);
  hr.forEach((y0, n) => {
    const main = n === 1 || n === 2, py = (y0 + 2) * TILE;
    for (let tx = 1; tx < MW - 1; tx++) {
      if (nearV(tx) || at(tx, y0 + 1) !== 0 || at(tx, y0 + 2) !== 0) continue;
      if (main) { R("rgba(235,190,70,0.75)", tx * TILE + 2, py - 2, 12, 1); R("rgba(235,190,70,0.75)", tx * TILE + 2, py + 1, 12, 1); }
      else if (tx % 2) R("rgba(225,225,235,0.5)", tx * TILE + 2, py - 1, 12, 2);
    }
  });
  vr.forEach((x0, n) => {
    const main = n >= 1 && n <= 3, px = (x0 + 2) * TILE;
    for (let ty = 1; ty < MH - 1; ty++) {
      if (nearH(ty) || at(x0 + 1, ty) !== 0 || at(x0 + 2, ty) !== 0) continue;
      if (main) { R("rgba(235,190,70,0.75)", px - 2, ty * TILE + 2, 1, 12); R("rgba(235,190,70,0.75)", px + 1, ty * TILE + 2, 1, 12); }
      else if (ty % 2) R("rgba(225,225,235,0.5)", px - 1, ty * TILE + 2, 2, 12);
    }
  });
  const ZEB = "rgba(225,225,235,0.62)";
  for (const x0 of vr)
    for (const y0 of hr) {
      for (const ax of [x0 - 2, x0 + 4]) {
        if (at(ax, y0 + 1) !== 0 || at(ax + 1, y0 + 1) !== 0) continue;
        for (let y = y0 * TILE + 3; y < (y0 + 4) * TILE - 4; y += 6) R(ZEB, ax * TILE + 5, y, 22, 3);
        R(ZEB, (ax < x0 ? ax : ax + 2) * TILE - 1, y0 * TILE + 2, 2, 60); // stop line
      }
      for (const ay of [y0 - 2, y0 + 4]) {
        if (at(x0 + 1, ay) !== 0 || at(x0 + 1, ay + 1) !== 0) continue;
        for (let xx = x0 * TILE + 3; xx < (x0 + 4) * TILE - 4; xx += 6) R(ZEB, xx, ay * TILE + 5, 3, 22);
        R(ZEB, x0 * TILE + 2, (ay < y0 ? ay : ay + 2) * TILE - 1, 60, 2);
      }
    }
  // manholes in the lanes
  const hole = (a: number, b: number) => {
    if (atPx(a + 6, b + 6) !== 0) return;
    R("#15151b", a + 2, b, 8, 12); R("#15151b", a, b + 2, 12, 8); R("#15151b", a + 1, b + 1, 10, 10);
    R("#555762", a + 2, b + 1, 8, 10); R("#555762", a + 1, b + 2, 10, 8);
    R("#3c3e48", a + 3, b + 3, 6, 1); R("#3c3e48", a + 3, b + 6, 6, 1); R("#3c3e48", a + 3, b + 9, 6, 1); R("#7d7f8a", a + 2, b + 2, 3, 1);
  };
  for (const y0 of hr) for (let tx = 9; tx < MW - 6; tx += 13) if (!nearV(tx)) hole(tx * TILE + 2, (y0 + 1) * TILE - 6);
  for (const x0 of vr) for (let ty = 11; ty < MH - 6; ty += 12) if (!nearH(ty)) hole((x0 + 2) * TILE + 10, ty * TILE + 2);
  // storm drains along the curbs
  for (let ty = 1; ty < MH - 1; ty++)
    for (let tx = 1; tx < MW - 1; tx++) {
      if (at(tx, ty) !== 0 || at(tx, ty + 1) !== 1 || h2(tx, ty, 61) > 0.1) continue;
      R("#0d0d12", tx * TILE + 2, ty * TILE + 12, 12, 4);
      for (let i = 0; i < 4; i++) R("#44464f", tx * TILE + 3 + i * 3, ty * TILE + 13, 1, 2);
    }
  // puddles, skid marks, old blood
  for (let i = 0; i < 34; i++) {
    const cx = (40 + h2(i, 6, 64) * (W - 80)) | 0, cy = (40 + h2(i, 7, 65) * (H - 80)) | 0;
    if (atPx(cx, cy) !== 0 || atPx(cx - 9, cy) !== 0 || atPx(cx + 9, cy) !== 0) continue;
    ell(R, cx, cy, 9, 4, "#161a26"); ell(R, cx - 1, cy - 1, 6, 2, "#27324a"); R("#5a6f96", cx - 4, cy - 2, 3, 1);
  }
  for (let i = 0; i < 20; i++) {
    const sx = (40 + h2(i, 8, 66) * (W - 130)) | 0, sy = (40 + h2(i, 9, 67) * (H - 80)) | 0;
    if (atPx(sx, sy - 4) !== 0 || atPx(sx + 34, sy - 4) !== 0 || atPx(sx, sy + 12) !== 0 || atPx(sx + 34, sy + 12) !== 0) continue;
    for (let t = 0; t < 34; t++) {
      const yy = sy + Math.round(Math.sin(t * 0.09 + i) * 4);
      R("rgba(6,6,10,0.4)", sx + t, yy, 1, 2); R("rgba(6,6,10,0.4)", sx + t, yy + 7, 1, 2);
    }
  }
  for (let i = 0; i < 40; i++) {
    const bx = (30 + h2(i, 10, 68) * (W - 70)) | 0, by = (30 + h2(i, 11, 69) * (H - 60)) | 0;
    if (atPx(bx, by) >= 3 || atPx(bx + 14, by) >= 3 || onPad((bx / TILE) | 0, (by / TILE) | 0)) continue;
    ell(R, bx, by, 4, 3, "rgba(120,18,30,0.55)");
    for (let t = 0; t < 12; t++) R("rgba(120,18,30,0.32)", bx + 3 + t, by + Math.round(Math.sin(t * 0.5 + i) * 1.5), 2, 2);
    R("rgba(170,34,44,0.6)", bx - 1, by - 1, 2, 2);
  }
  // fire hydrants and bins on the pavement, never in front of a door
  const doorFront = new Set<number>();
  for (const hs of HOUSES) for (const d of hs.doors) doorFront.add((d.ty + d.oy) * MW + d.tx + d.ox);
  for (let ty = 1; ty < MH - 1; ty++)
    for (let tx = 1; tx < MW - 1; tx++) {
      if (at(tx, ty) !== 1 || kindAt(tx, ty) !== 0 || doorFront.has(ty * MW + tx)) continue;
      const v = h2(tx, ty, 77), px = tx * TILE, py = ty * TILE;
      if (v < 0.03) {
        R("rgba(0,0,6,0.35)", px + 5, py + 11, 8, 3);
        R(INK, px + 5, py + 3, 6, 10); R(INK, px + 3, py + 6, 10, 4);
        R("#c0392b", px + 6, py + 4, 4, 8); R("#c0392b", px + 4, py + 7, 8, 2); R("#e8604c", px + 6, py + 4, 4, 1); R("#f5c542", px + 7, py + 7, 2, 2);
      } else if (v < 0.055) {
        R("rgba(0,0,6,0.35)", px + 5, py + 12, 8, 2);
        R(INK, px + 4, py + 3, 8, 10); R("#3f6a50", px + 5, py + 4, 6, 8); R("#5a8a6a", px + 5, py + 4, 6, 1); R("#14241a", px + 6, py + 6, 4, 1);
      }
    }
  // benches on the square
  for (const [bx, by] of [[44, 34], [44, 43], [51, 31], [51, 46]]) {
    for (const [tx, ty] of [[bx, by], [MW - 1 - bx, CH - 1 - by]]) {
      const px = tx * TILE, py = ty * TILE + 4;
      R("rgba(0,0,6,0.35)", px + 1, py + 7, 16, 3);
      R(INK, px - 1, py - 1, 18, 9); R("#6a4a2e", px, py, 16, 7); R("#8a6844", px, py, 16, 1); R("#553a22", px, py + 3, 16, 1); R("#3a3a46", px + 2, py + 6, 2, 2); R("#3a3a46", px + 12, py + 6, 2, 2);
    }
  }

  // ── inside the houses: rugs and doormats; inside the mart: floor graphics and spilled goods ──
  HOUSES.forEach((hs, hi) => {
    for (const rm of hs.rooms) {
      if (rm.type !== 1 || rm.w < 5 || rm.h < 4) continue;
      const cx = (rm.x + rm.w / 2) * TILE, cy = (rm.y + rm.h / 2) * TILE, col = hi % 2 ? ["#7a2a34", "#a84450"] : ["#2a4a6a", "#44709a"];
      R("#1a1210", cx - 27, cy - 19, 54, 38); R(col[0], cx - 26, cy - 18, 52, 36); R("#e0c070", cx - 24, cy - 16, 48, 1); R("#e0c070", cx - 24, cy + 15, 48, 1);
      R("#e0c070", cx - 24, cy - 16, 1, 32); R("#e0c070", cx + 23, cy - 16, 1, 32); R(col[1], cx - 20, cy - 12, 40, 24);
      for (let i = -16; i <= 16; i += 8) R("#e0c070", cx + i - 1, cy - 1, 3, 3);
    }
    for (const d of hs.doors) {
      if (cls(d.tx + d.ox, d.ty + d.oy) === 6) continue;
      const mx = (d.tx + d.ox) * TILE, my = (d.ty + d.oy) * TILE;
      R("#15151b", mx + 2, my + 3, 12, 10); R("#8a5a2a", mx + 3, my + 4, 10, 8); R("#c08a44", mx + 4, my + 5, 8, 1); R("#c08a44", mx + 4, my + 10, 8, 1);
    }
    if (!hs.shop) return;
    const X0 = (hs.x + 1) * TILE, Y0 = (hs.y + 1) * TILE, X1 = (hs.x + hs.w - 1) * TILE, Y1 = (hs.y + hs.h - 1) * TILE;
    const d0 = hs.doors[0], ex = Math.min(d0.tx, hs.doors[1].tx), dir = -d0.oy, ey = d0.ty + dir;
    // cold glow under the drinks fridges, warm stripe along the freezers
    R("rgba(95,240,224,0.2)", X0, Y0 + TILE - 2, X1 - X0, 5);
    R("rgba(192,57,43,0.55)", X0, Y1 - TILE - 3, X1 - X0, 2); R("rgba(245,197,66,0.5)", X0, Y1 - TILE - 5, X1 - X0, 1);
    // entrance mat
    const mx0 = ex * TILE + 1, my0 = ey * TILE + 2;
    R("#15151b", mx0 - 1, my0 - 1, 32, 14); R("#7a1f28", mx0, my0, 30, 12); R("#a8323a", mx0 + 1, my0 + 1, 28, 10);
    x.fillStyle = "#f3d9a0";
    glyphs(x, "MART", mx0 + 8, my0 + 4, 1);
    // guide line and arrows down the main aisle, checkout label
    const ax = (ex + 1) * TILE - 1;
    for (let py = Math.min(ey + 2 * dir, ey + 9 * dir) * TILE; py < (Math.max(ey + 2 * dir, ey + 9 * dir) + 1) * TILE; py += 10) R("rgba(245,197,66,0.7)", ax, py, 2, 6);
    for (const j of [4, 7]) {
      const ay = (ey + j * dir) * TILE + 6;
      for (let i = 0; i < 4; i++) R("rgba(245,197,66,0.7)", ax - 3 - i + (i ? 0 : 0), ay + (dir > 0 ? 3 - i : i), 2 * i + 8 - 2 * i, 1);
      for (let i = 0; i < 4; i++) { R("rgba(245,197,66,0.7)", ax - i, ay + (dir > 0 ? 4 + (3 - i) : -1 - (3 - i)) , 1, 1); R("rgba(245,197,66,0.7)", ax + 1 + i, ay + (dir > 0 ? 4 + (3 - i) : -1 - (3 - i)), 1, 1); }
    }
    x.fillStyle = "rgba(245,197,66,0.85)";
    glyphs(x, "KASIR", ax - 9, (ey + dir) * TILE + 5, 1);
    // spilled cans, a puddle, something that was dragged away
    for (let i = 0; i < 34; i++) {
      const sx = (X0 + h2(i, hs.x, 80) * (X1 - X0 - 4)) | 0, sy = (Y0 + 18 + h2(i, hs.x, 81) * (Y1 - Y0 - 40)) | 0;
      R("rgba(0,0,6,0.4)", sx, sy + 2, 3, 1); R(GOODS[i % 6], sx, sy, 3, 2); R("rgba(255,255,255,0.35)", sx, sy, 1, 1);
    }
    const pcx = ((X0 + X1) >> 1) + 46, pcy = ((Y0 + Y1) >> 1) + 9;
    ell(R, pcx, pcy, 9, 4, "#5a84a8"); ell(R, pcx - 1, pcy - 1, 6, 2, "#8fb6d6"); R("#d9f5f9", pcx - 4, pcy - 2, 3, 1);
    for (let t = 0; t < 52; t++) R("rgba(120,18,30,0.42)", ax - 40 + t, (ey + 3 * dir) * TILE + 7 + Math.round(Math.sin(t * 0.3) * 2), 2, 2 + (t % 3 === 0 ? 1 : 0));
    ell(R, ax - 42, (ey + 3 * dir) * TILE + 8, 5, 3, "rgba(120,18,30,0.6)");
  });

  // evac zone in the middle of the square
  const PX = PAD.x * TILE, PY = PAD.y * TILE, PW = PAD.w * TILE, PH = PAD.h * TILE;
  R("#15151b", PX - 2, PY - 2, PW + 4, PH + 4);
  R("#3a3c46", PX, PY, PW, PH);
  for (let ty = 0; ty < PAD.h; ty++)
    for (let tx = 0; tx < PAD.w; tx++) {
      const px = PX + tx * TILE, py = PY + ty * TILE;
      if ((tx + ty) % 2) R("#353741", px, py, TILE, TILE);
      R("#474955", px, py, TILE, 1); R("#474955", px, py, 1, TILE);
      R("#2a2b33", px + 15, py, 1, TILE); R("#2a2b33", px, py + 15, TILE, 1);
    }
  for (let i = 0; i < PW; i += 8) {
    R("#f5c542", PX + i, PY, 4, 3); R("#1a1a22", PX + i + 4, PY, 4, 3);
    R("#f5c542", PX + i, PY + PH - 3, 4, 3); R("#1a1a22", PX + i + 4, PY + PH - 3, 4, 3);
    R("#f5c542", PX, PY + i, 3, 4); R("#1a1a22", PX, PY + i + 4, 3, 4);
    R("#f5c542", PX + PW - 3, PY + i, 3, 4); R("#1a1a22", PX + PW - 3, PY + i + 4, 3, 4);
  }
  const cx = PX + PW / 2, cy = PY + PH / 2;
  for (let a = 0; a < 6.283; a += 0.02) {
    R("rgba(245,197,66,0.9)", (cx + Math.cos(a) * 34) | 0, (cy + Math.sin(a) * 34) | 0, 2, 2);
    if (Math.floor(a / 0.2) % 2) R("rgba(245,197,66,0.6)", (cx + Math.cos(a) * 40) | 0, (cy + Math.sin(a) * 40) | 0, 2, 2);
  }
  x.fillStyle = "rgba(245,197,66,0.85)";
  glyphs(x, "H", cx - 9, cy - 15, 6);
  glyphs(x, "EVAC", cx - 15, PY + 9, 2);
  glyphs(x, "EVAC", cx - 15, PY + PH - 19, 2);
  for (const [lx, ly] of [[PX + 6, PY + 6], [PX + PW - 9, PY + 6], [PX + 6, PY + PH - 9], [PX + PW - 9, PY + PH - 9]]) {
    R("rgba(95,240,224,0.25)", lx - 2, ly - 2, 7, 7); R("#1a1a22", lx - 1, ly - 1, 5, 5); R("#5ff0e0", lx, ly, 3, 3); R("#ffffff", lx, ly, 1, 1);
  }

  // collapsed street holes the dead crawl out of
  for (let n = 0; n < NESTS.length; n++) {
    const p = NESTS[n];
    ell(R, p.x, p.y + 1, 20, 13, "rgba(0,0,0,0.5)");
    ell(R, p.x, p.y, 18, 11, "#4a4c56");
    ell(R, p.x, p.y, 18, 11, "#666872", -11, -5);
    ell(R, p.x, p.y + 1, 13, 7, "#050507");
    ell(R, p.x, p.y + 3, 10, 4, "#143a14", 1, 4);
    ell(R, p.x, p.y + 4, 6, 2, "#3fa832", 1, 2);
    for (let k = 0; k < 8; k++) {
      const a = k * 0.8 + n, sx = Math.round(p.x + Math.cos(a) * 21) - 2, sy = Math.round(p.y + Math.sin(a) * 13) - 1;
      R("#17181e", sx - 1, sy - 1, 7, 5); R("#3a3c46", sx, sy, 5, 3); R("#6a6c76", sx, sy, 4, 1);
    }
  }
  // directional contact shadows
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      if (kindAt(tx, ty)) continue;
      const px = tx * TILE, py = ty * TILE;
      const up = tall(tx, ty - 1), left = tall(tx - 1, ty);
      if (up) { R("rgba(0,0,6,0.45)", px, py, TILE, 4); R("rgba(0,0,6,0.22)", px, py + 4, TILE, 3); }
      else if (kindAt(tx, ty - 1) === 3) R("rgba(0,0,6,0.4)", px, py, TILE, 2);
      if (left) { R("rgba(0,0,6,0.32)", px, py + (up ? 7 : 0), 3, TILE - (up ? 7 : 0)); R("rgba(0,0,6,0.16)", px + 3, py + (up ? 7 : 0), 2, TILE - (up ? 7 : 0)); }
      if (!up && !left && tall(tx - 1, ty - 1)) { R("rgba(0,0,6,0.32)", px, py, 3, 4); R("rgba(0,0,6,0.16)", px, py + 4, 3, 3); }
    }
  return c;
}

/* ───────────── buildings, houses, furniture, wrecked cars ───────────── */
const CS = [
  { top: "#4a3a3a", a: "#574545", b: "#3d3030", hi: "#8a6a64", lo: "#2a2020", front: "#8a4a3c", fdark: "#4a241c", fline: "#6e382c" }, // red brick
  { top: "#34363f", a: "#3e404a", b: "#2a2c34", hi: "#666a78", lo: "#1c1d24", front: "#555866", fdark: "#2a2c36", fline: "#454856" }, // (checkpoint, unused)
  { top: "#34363f", a: "#3e404a", b: "#2a2c34", hi: "#666a78", lo: "#1c1d24", front: "#555866", fdark: "#2a2c36", fline: "#454856" }, // dark concrete
  { top: "#4d4a42", a: "#59564d", b: "#403d36", hi: "#8a8576", lo: "#2b2924", front: "#a39a80", fdark: "#5c563f", fline: "#8a826a" }, // beige flats
  { top: "#2f3d4d", a: "#394959", b: "#263240", hi: "#6a84a0", lo: "#18212c", front: "#3f6a8a", fdark: "#1f3a50", fline: "#2f5672" }, // glass office
];
/** enterable houses: wall cap, outside facade, inside wallpaper */
const HS = [
  { cap: "#9a9182", hi: "#beb6a6", lo: "#5a5348", ext: "#8a4a3c", extD: "#4a241c", extL: "#6e382c", paper: "#c9b890", paperD: "#a8966e" },
  { cap: "#8c939b", hi: "#b4bbc3", lo: "#4e555e", ext: "#7d8c9a", extD: "#3f4a56", extL: "#66747f", paper: "#8fb0b8", paperD: "#6f9098" },
  { cap: "#9a8c76", hi: "#bead94", lo: "#5c5140", ext: "#a8946a", extD: "#5c4f34", extL: "#8a7852", paper: "#c0909a", paperD: "#a0707a" },
  { cap: "#7d8590", hi: "#a3abb6", lo: "#454c56", ext: "#4f6a8a", extD: "#263a50", extL: "#3f5672", paper: "#c9d0d8", paperD: "#aab2bb" }, // supermarket
];
const ROOF = [
  { a: "#7a3b30", b: "#5e2b23", hi: "#a05a48", lo: "#3d1a15" },
  { a: "#3f4a5c", b: "#313a49", hi: "#63718a", lo: "#1e2430" },
  { a: "#4a5a44", b: "#3a4836", hi: "#6f8466", lo: "#232c20" },
  { a: "#5c4a38", b: "#48392b", hi: "#86705a", lo: "#2b2118" },
];
const NEON_COL: [string, string, string][] = [["m", "#ff5fd2", "#ffd0f4"], ["c", "#5ff0e0", "#d9fffa"], ["r", "#ff4d5e", "#ffd0d0"], ["g", "#86f04e", "#e6ffc0"]];
const CAR_COL: [string, string, string][] = [
  ["#b03a3a", "#d86060", "#6e2020"], ["#3b6ea8", "#6a9ad0", "#1f3f66"], ["#c9c9c0", "#f0f0e8", "#77776f"],
  ["#d8b02a", "#f5d85a", "#8a6c10"], ["#4a4d60", "#6a6e86", "#22242e"], ["#3f8a5a", "#62b07e", "#1f4a2e"],
];
const NEON: Lamp[] = [];

function carH(R: Paint, px: number, py: number, v: number, police = false) {
  const [b, hi, dk] = police ? ["#e6e6de", "#ffffff", "#8a8a84"] : CAR_COL[(v * 6) | 0], fy = py + TILE;
  R(INK, px + 1, py + 2, 30, 14); R(INK, px, py + 4, 32, 12);
  R(b, px + 2, py + 3, 28, 12); R(b, px + 1, py + 5, 30, 9); R(hi, px + 2, py + 3, 28, 1);
  R("#141c2a", px + 8, py + 4, 15, 10); R("#2c3a55", px + 8, py + 4, 15, 1);
  R(police ? "#1c1c24" : b, px + 11, py + 5, 9, 8); R(police ? "#3a3a48" : hi, px + 11, py + 5, 9, 1);
  if (police) { R(INK, px + 13, py + 6, 6, 6); R("#d8433b", px + 14, py + 7, 2, 4); R("#3b6ea8", px + 16, py + 7, 2, 4); R("#1c1c24", px + 3, py + 6, 4, 7); R("#1c1c24", px + 25, py + 6, 4, 7); }
  else if (v > 0.5) { R("#8fa8c8", px + 21, py + 7, 2, 1); R("#8fa8c8", px + 20, py + 8, 1, 3); }
  R("#ffe9a8", px + 30, py + 5, 1, 3); R("#ffe9a8", px + 30, py + 11, 1, 3); R("#d8433b", px + 1, py + 5, 1, 3); R("#d8433b", px + 1, py + 11, 1, 3);
  R(dk, px + 1, fy, 30, 5); R(INK, px + 1, fy + 5, 30, 1); R(INK, px + 15, fy, 1, 5); R(hi, px + 17, fy + 1, 2, 1);
  if (police) R("#1c1c24", px + 9, fy + 1, 13, 3);
  R(INK, px + 4, fy + 2, 7, 6); R("#4a4a55", px + 6, fy + 4, 3, 2); R(INK, px + 21, fy + 2, 7, 6); R("#4a4a55", px + 23, fy + 4, 3, 2);
}
function carV(R: Paint, px: number, py: number, v: number) {
  const [b, hi, dk] = CAR_COL[(v * 6) | 0], fy = py + TILE * 2;
  R(INK, px + 1, py + 1, 14, 31);
  R(b, px + 2, py + 2, 12, 30); R(hi, px + 2, py + 2, 1, 30);
  R("#141c2a", px + 3, py + 8, 10, 16); R("#2c3a55", px + 3, py + 8, 10, 1);
  R(b, px + 4, py + 11, 8, 9); R(hi, px + 4, py + 11, 8, 1);
  if (v > 0.5) { R("#8fa8c8", px + 5, py + 9, 3, 1); R("#8fa8c8", px + 7, py + 8, 1, 2); }
  R("#ffe9a8", px + 3, py + 2, 3, 1); R("#ffe9a8", px + 10, py + 2, 3, 1);
  R(dk, px + 1, fy, 14, 5); R("#d8433b", px + 2, fy + 1, 3, 2); R("#d8433b", px + 11, fy + 1, 3, 2); R("#c9c9c0", px + 6, fy + 2, 4, 2);
  R(INK, px + 1, fy + 5, 14, 2); R(INK, px + 2, fy + 5, 3, 3); R(INK, px + 11, fy + 5, 3, 3);
}
function dumpster(R: Paint, px: number, py: number) {
  const fy = py + TILE;
  R(INK, px + 1, py + 3, 14, 13);
  R("#2f6a4a", px + 2, py + 4, 12, 12); R("#4a9a6c", px + 2, py + 4, 12, 2); R("#1f4a32", px + 2, py + 9, 12, 1); R("#1f4a32", px + 8, py + 4, 1, 12);
  R(INK, px + 8, py, 6, 5); R("#22222a", px + 9, py + 1, 4, 3); R("#3a3a46", px + 9, py + 1, 2, 1);
  R(INK, px + 1, fy, 14, RAISE); R("#25563c", px + 2, fy, 12, RAISE - 1);
  R("#1b3f2c", px + 4, fy + 1, 1, 5); R("#1b3f2c", px + 8, fy + 1, 1, 5); R("#1b3f2c", px + 11, fy + 1, 1, 5); R("#c9c9c0", px + 5, fy + 2, 2, 2);
}

/** tall, searchable furniture: 10 wardrobe, 11 fridge, 12 bookshelf, 13 medicine cabinet, 14 shop shelf, 15 glass-door drinks fridge */
function cupboard(R: Paint, px: number, py: number, st: number) {
  const fy = py + TILE;
  R(INK, px, py + 3, TILE, 13 + RAISE);
  if (st === 11) {
    R("#c3cad4", px + 1, py + 4, 14, 12); R("#eef2f6", px + 1, py + 4, 14, 1); R("#a9b2be", px + 1, py + 15, 14, 1);
    R("#dfe5ec", px + 1, fy, 14, RAISE - 1); R("#9aa3b0", px + 1, fy + 2, 14, 1); R("#6a7280", px + 11, fy + 3, 1, 3); R("#6a7280", px + 11, fy, 1, 1); R("#ffffff", px + 2, fy + 3, 1, 3);
  } else if (st === 12) {
    R("#6a4a2e", px + 1, py + 4, 14, 12); R("#8a6844", px + 1, py + 4, 14, 1);
    R("#2e2016", px + 1, fy, 14, RAISE - 1);
    const BK = ["#b03a3a", "#3b6ea8", "#3f8a5a", "#d8b02a", "#8a5aa8", "#c9c9c0"];
    for (let i = 0; i < 6; i++) R(BK[(i + px) % 6], px + 2 + i * 2, fy + 1 + (i % 3 === 1 ? 1 : 0), 2, 5 - (i % 3 === 1 ? 1 : 0));
    R("#6a4a2e", px + 1, fy + 6, 14, 1);
  } else if (st === 13) {
    R("#aab2bd", px + 1, py + 4, 14, 12); R("#d9dee8", px + 1, py + 4, 14, 1);
    R("#d9dee8", px + 1, fy, 14, RAISE - 1); R("#8d949e", px + 8, fy, 1, 7);
    R("#d8433b", px + 3, fy + 1, 2, 5); R("#d8433b", px + 2, fy + 3, 4, 1); R("#d8433b", px + 11, fy + 1, 2, 5); R("#d8433b", px + 10, fy + 3, 4, 1);
  } else if (st === 14) {
    // gondola shelf: every one stocks something different
    const kind = ((px >> 4) * 3 + (py >> 4)) % 4, top = ["#b03a3a", "#3b6ea8", "#3f8a5a", "#d07a2a"][kind];
    R("#8d949e", px + 1, py + 4, 14, 12); R("#c3cad4", px + 1, py + 4, 14, 1); R(top, px + 1, py + 5, 14, 1);
    for (let i = 0; i < 6; i++) {
      R(GOODS[(i + kind + (px >> 4)) % 6], px + 2 + i * 2, py + 7, 2, 3);
      R(GOODS[(i * 5 + kind + (py >> 4)) % 6], px + 2 + i * 2, py + 12, 2, 3);
    }
    R("#5d6470", px + 1, fy, 14, RAISE - 1); R("#3c424c", px + 1, fy + 3, 14, 1);
    for (let i = 0; i < 6; i++) { R(GOODS[(i * 3 + kind) % 6], px + 2 + i * 2, fy + 1, 2, 2); R(GOODS[(i + 2 + kind) % 6], px + 2 + i * 2, fy + 4, 2, 2); }
    R("#f3ead8", px + 5, fy + 3, 5, 1); // price strip
  } else if (st === 15) {
    // glass-door fridge, lit from inside
    R("#565c68", px + 1, py + 4, 14, 12); R("#7a8290", px + 1, py + 4, 14, 1); R("#3c414b", px + 3, py + 7, 10, 6);
    R("#1c2a30", px + 1, fy, 14, RAISE - 1); R("#5ff0e0", px + 1, fy, 14, 1);
    R("#17343a", px + 2, fy + 1, 5, 5); R("#17343a", px + 9, fy + 1, 5, 5);
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { R(GOODS[(i + j * 2 + (px >> 4)) % 6], px + 2 + i * 3, fy + 1 + j * 3, 2, 2); R(GOODS[(i * 3 + j + (px >> 4) + 2) % 6], px + 9 + i * 3, fy + 1 + j * 3, 2, 2); }
    R("#9be8f0", px + 7, fy + 1, 1, 5); R("#9be8f0", px + 14, fy + 1, 1, 5);
  } else {
    R("#6a4a2e", px + 1, py + 4, 14, 12); R("#8a6844", px + 1, py + 4, 14, 1); R("#553a22", px + 1, py + 15, 14, 1);
    R("#7a5636", px + 1, fy, 14, RAISE - 1); R("#4a3220", px + 7, fy, 2, 7); R("#96704a", px + 2, fy + 1, 4, 1); R("#96704a", px + 10, fy + 1, 4, 1);
    R("#f5c542", px + 5, fy + 3, 1, 2); R("#f5c542", px + 10, fy + 3, 1, 2);
  }
}

/** low furniture: 20 table, 21 sofa, 22/23 bed, 24 counter, 25 boxes, 26 toilet, 27 bathtub, 28 TV, 29 plant, 30 checkout, 31 cart, 32 produce, 33 freezer */
function lowFurniture(R: Paint, px: number, py: number, st: number, v: number) {
  const oy = py + RAISE - 3;
  const COL = v > 0.66 ? ["#3f6a9a", "#5a8cc0"] : v > 0.33 ? ["#9a4a4a", "#c06a6a"] : ["#4a8a5a", "#6ab07a"];
  if (st === 20) {
    R(INK, px + 1, oy + 1, 14, 14 + 3); R("#8a6238", px + 2, oy + 2, 12, 12); R("#a87c4c", px + 2, oy + 2, 12, 1); R("#5a3e22", px + 2, oy + 14, 12, 2);
    R("#e6e0d0", px + 4, oy + 5, 4, 4); R("#b8b2a2", px + 5, oy + 6, 2, 2); R("#d8433b", px + 10, oy + 8, 2, 3); R("#f5c542", px + 10, oy + 4, 2, 2);
  } else if (st === 21) {
    R(INK, px, oy + 1, TILE, 14 + 3); R(COL[0], px + 1, oy + 2, 14, 12); R(COL[1], px + 1, oy + 6, 14, 7); R(COL[1], px + 1, oy + 2, 14, 1);
    R(INK, px + 7, oy + 6, 1, 7); R(COL[0], px + 1, oy + 13, 14, 3); R("#f3ead8", px + 3, oy + 8, 3, 3);
  } else if (st === 22) {
    R(INK, px + 1, oy, 14, TILE + 3); R("#5a3e22", px + 2, oy + 1, 12, 15); R("#e6e6de", px + 3, oy + 3, 10, 6); R("#ffffff", px + 3, oy + 3, 10, 1); R("#b8b8b0", px + 3, oy + 8, 10, 1);
    R(COL[0], px + 2, oy + 10, 12, 9); R(COL[1], px + 2, oy + 10, 12, 2);
  } else if (st === 23) {
    R(INK, px + 1, oy - 3, 14, TILE + 6); R(COL[0], px + 2, oy - 3, 12, 15); R(COL[1], px + 4, oy, 2, 9); R(COL[1], px + 9, oy + 2, 2, 8);
    R("#5a3e22", px + 2, oy + 12, 12, 3); R("#3a2816", px + 2, oy + 15, 12, 3);
  } else if (st === 24) {
    R(INK, px, oy + 1, TILE, 14 + 3); R("#b9b3a4", px + 1, oy + 2, 14, 12); R("#dedacd", px + 1, oy + 2, 14, 1); R("#7a7468", px + 1, oy + 14, 14, 2);
    if (v > 0.5) { R("#5d6470", px + 3, oy + 5, 8, 6); R("#2c3038", px + 4, oy + 6, 6, 4); R("#c9cdd9", px + 11, oy + 4, 2, 4); }
    else { R("#2c3038", px + 3, oy + 4, 4, 4); R("#2c3038", px + 9, oy + 4, 4, 4); R("#2c3038", px + 3, oy + 9, 4, 4); R("#2c3038", px + 9, oy + 9, 4, 4); R("#ff7a3c", px + 4, oy + 5, 2, 2); }
  } else if (st === 26) {
    R(INK, px + 3, oy + 1, 10, 16); R("#e6eaee", px + 4, oy + 2, 8, 5); R("#ffffff", px + 4, oy + 2, 8, 1);
    R("#e6eaee", px + 4, oy + 8, 8, 7); R("#aab2bd", px + 5, oy + 9, 6, 5); R("#5fb6cc", px + 6, oy + 10, 4, 3); R("#b8bec6", px + 4, oy + 15, 8, 1);
  } else if (st === 27) {
    R(INK, px, oy + 1, TILE, 17); R("#e6eaee", px + 1, oy + 2, 14, 13); R("#ffffff", px + 1, oy + 2, 14, 1);
    R("#8fd0e0", px + 3, oy + 4, 10, 9); R("#c6eef5", px + 4, oy + 5, 4, 1); R("#8d949e", px + 12, oy + 3, 2, 2); R("#b8bec6", px + 1, oy + 15, 14, 2);
  } else if (st === 28) {
    R(INK, px, oy + 3, TILE, 14); R("#5a3e22", px + 1, oy + 9, 14, 7); R("#7a5636", px + 1, oy + 9, 14, 1);
    R(INK, px + 1, oy + 1, 14, 9); R("#1c2a44", px + 2, oy + 2, 12, 7); R("#5a84c0", px + 3, oy + 3, 5, 2); R("#3a5a8a", px + 3, oy + 6, 9, 1);
  } else if (st === 29) {
    R(INK, px + 4, oy + 8, 8, 9); R("#a85a2a", px + 5, oy + 9, 6, 7); R("#c87a44", px + 5, oy + 9, 6, 1);
    R(INK, px + 2, oy - 2, 12, 11); R("#3f8a3a", px + 3, oy - 1, 10, 9); R("#5fb04a", px + 4, oy, 4, 3); R("#5fb04a", px + 9, oy + 3, 3, 3); R("#2a6a2a", px + 6, oy + 5, 2, 3);
  } else if (st === 30) {
    // checkout: conveyor belt, till and a little screen
    R(INK, px, oy + 1, TILE, 17); R("#c9cdd9", px + 1, oy + 2, 14, 13); R("#eef2f6", px + 1, oy + 2, 14, 1); R("#8d949e", px + 1, oy + 15, 14, 2);
    R("#1c1c24", px + 2, oy + 8, 12, 5); for (let i = 0; i < 4; i++) R("#3a3a48", px + 3 + i * 3, oy + 9, 1, 3);
    R(INK, px + 9, oy + 2, 6, 6); R("#2c3a55", px + 10, oy + 3, 4, 3); R("#86f04e", px + 10, oy + 3, 2, 1); R("#c0392b", px + 2, oy + 3, 5, 3); R("#f5c542", px + 3, oy + 4, 1, 1);
  } else if (st === 31) {
    // shopping cart, seen from above
    R("rgba(0,0,6,0.35)", px + 3, oy + 14, 11, 3);
    R(INK, px + 2, oy + 2, 12, 12); R("#aab2bd", px + 3, oy + 3, 10, 10); R("#2a2c34", px + 4, oy + 4, 8, 8);
    for (let i = 0; i < 3; i++) { R("#8d949e", px + 4, oy + 5 + i * 3, 8, 1); R("#8d949e", px + 5 + i * 3, oy + 4, 1, 8); }
    R(GOODS[(px >> 4) % 6], px + 5, oy + 5, 3, 3); R(GOODS[((px >> 4) + 2) % 6], px + 8, oy + 8, 3, 2);
    R("#c0392b", px + 2, oy + 14, 12, 2); R(INK, px + 3, oy + 16, 2, 2); R(INK, px + 11, oy + 16, 2, 2);
  } else if (st === 32) {
    // produce crate
    const F = v > 0.5 ? ["#d8433b", "#f47c72"] : ["#f09a4a", "#ffc680"], F2 = ["#5fb04a", "#8fd062"];
    R(INK, px, oy + 2, TILE, 16); R("#8a6238", px + 1, oy + 3, 14, 12); R("#a87c4c", px + 1, oy + 3, 14, 1); R("#5a3e22", px + 1, oy + 15, 14, 2); R("#5a3e22", px + 7, oy + 3, 2, 12);
    for (let j = 0; j < 3; j++) for (let i = 0; i < 2; i++) { R(F[0], px + 2 + i * 3, oy + 5 + j * 3, 2, 2); R(F[1], px + 2 + i * 3, oy + 5 + j * 3, 1, 1); R(F2[0], px + 10 + i * 3, oy + 5 + j * 3, 2, 2); R(F2[1], px + 10 + i * 3, oy + 5 + j * 3, 1, 1); }
  } else if (st === 33) {
    // freezer chest with a sliding glass lid
    R(INK, px, oy + 1, TILE, 17); R("#dfe5ec", px + 1, oy + 2, 14, 13); R("#ffffff", px + 1, oy + 2, 14, 1); R("#9aa3b0", px + 1, oy + 15, 14, 2);
    R("#2a6a7a", px + 2, oy + 4, 12, 9); R("#5fd0e0", px + 3, oy + 5, 10, 7); R("#c6f4f8", px + 4, oy + 6, 4, 1); R("#2a6a7a", px + 8, oy + 4, 1, 9);
    R(GOODS[(px >> 4) % 6], px + 4, oy + 9, 3, 2); R(GOODS[((px >> 4) + 3) % 6], px + 10, oy + 8, 2, 3); R("#c0392b", px + 1, oy + 13, 14, 1);
  } else {
    R(INK, px + 1, oy + 4, 9, 13); R("#b8935c", px + 2, oy + 5, 7, 11); R("#d8b47a", px + 2, oy + 5, 7, 1); R("#e6dcc0", px + 5, oy + 5, 1, 11);
    R(INK, px + 8, oy + 1, 8, 16); R("#a8834c", px + 9, oy + 2, 6, 14); R("#c8a46a", px + 9, oy + 2, 6, 1); R("#e6dcc0", px + 9, oy + 8, 6, 1);
  }
}

function buildWallsCity(): Cv {
  NEON.length = 0;
  const [c, x] = mk(MW * TILE, MH * TILE + RAISE);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  const same = (tx: number, ty: number, st: number) => kindAt(tx, ty) === 1 && styleAt(tx, ty) === st;
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      const k = kindAt(tx, ty);
      if (!k) continue;
      const px = tx * TILE, py = ty * TILE, fy = py + TILE, st = styleAt(tx, ty);
      if (k === 1 && st === 9) continue; // void
      if (k === 1 && st === 1) {
        // military checkpoint wall
        const U = kindAt(tx, ty - 1) !== 1, L = kindAt(tx - 1, ty) !== 1, Rt = kindAt(tx + 1, ty) !== 1, Dn = kindAt(tx, ty + 1) !== 1;
        R("#5c6675", px, py, TILE, TILE);
        R("#6d7888", px + 1, py + 1, 14, 6); R("#525b69", px + 1, py + 9, 14, 6);
        R("#8a96a8", px + 2, py + 2, 1, 1); R("#8a96a8", px + 13, py + 2, 1, 1); R("#3a414d", px + 2, py + 13, 1, 1); R("#3a414d", px + 13, py + 13, 1, 1);
        const hz = (ax: number, ay: number, w: number, h: number, i: number) => R(i % 2 ? "#1a1a22" : "#f5c542", ax, ay, w, h);
        for (let i = 0; i < 4; i++) {
          if (U) hz(px + i * 4, py, 4, 2, i + tx);
          if (Dn) hz(px + i * 4, py + 14, 4, 2, i + tx);
          if (L) hz(px, py + i * 4, 2, 4, i + ty);
          if (Rt) hz(px + 14, py + i * 4, 2, 4, i + ty);
        }
        R("#39404b", px, fy, TILE, RAISE);
        R("#4a525f", px, fy + 1, TILE, 2); R("#2a2f38", px + 7, fy, 1, RAISE); R("#22262d", px, fy + RAISE - 1, TILE, 1); R("#22262d", px, fy, TILE, 1);
        R("#5ff0e0", px + 3, fy + 4, 2, 1); R("#5ff0e0", px + 11, fy + 4, 2, 1);
      } else if (k === 1 && st >= 5) {
        // house wall: plaster cap seen from above, wallpaper inside, siding outside
        const s = HS[(st - 5) % 4], v = h2(tx, ty, 30), shop = st === 8;
        R(s.cap, px, py, TILE, TILE);
        if (kindAt(tx, ty - 1) !== 1) { R(s.lo, px, py, TILE, 1); R(s.hi, px, py + 1, TILE, 1); }
        if (kindAt(tx - 1, ty) !== 1) { R(s.lo, px, py, 1, TILE); R(s.hi, px + 1, py + 1, 1, TILE - 1); }
        if (kindAt(tx + 1, ty) !== 1) R(s.lo, px + 15, py, 1, TILE);
        if (kindAt(tx, ty + 1) !== 1) R(s.lo, px, py + 15, TILE, 1);
        if (kindAt(tx, ty + 1) !== 1 && ty < MH - 1) {
          if (houseAt(tx, ty + 1) >= 0) {
            R(s.paper, px, fy, TILE, RAISE);
            if (shop) {
              // shop wall: red band, promo posters
              R("#c0392b", px, fy + 1, TILE, 1); R("#f5c542", px, fy + 2, TILE, 1);
              if (v < 0.22) { R(INK, px + 2, fy + 3, 12, 5); R("#c0392b", px + 3, fy + 3, 10, 4); x.fillStyle = "#fff3c0"; glyphs(x, "SALE", px + 1, fy + 3, 1); }
              else if (v < 0.4) { R(INK, px + 4, fy + 3, 8, 5); R("#f5c542", px + 5, fy + 3, 6, 4); R("#c0392b", px + 6, fy + 4, 4, 2); }
              else if (v < 0.5) { R(INK, px + 5, fy + 3, 6, 4); R("#eef2f6", px + 6, fy + 3, 4, 3); R(INK, px + 8, fy + 4, 1, 1); } // clock
            } else {
              for (let i = 1; i < TILE; i += 4) R(s.paperD, px + i, fy, 1, RAISE - 1);
              if (v < 0.16) { R(INK, px + 4, fy + 1, 8, 5); R("#8fb0d0", px + 5, fy + 2, 6, 3); R("#5f8a5a", px + 5, fy + 4, 6, 1); R("#f5c542", px + 9, fy + 2, 1, 1); }
              else if (v < 0.3) { R(INK, px + 3, fy + 1, 10, 5); R("#18243c", px + 4, fy + 2, 8, 3); R("#f3ead8", px + 4, fy + 2, 2, 3); R("#f3ead8", px + 10, fy + 2, 2, 3); }
              else if (v < 0.38) { R("#5a3e22", px + 3, fy + 3, 10, 1); R("#d8433b", px + 4, fy + 1, 2, 2); R("#3b6ea8", px + 8, fy + 1, 2, 2); }
              else if (v > 0.92) { R("rgba(120,18,30,0.7)", px + 5, fy + 2, 5, 2); R("rgba(120,18,30,0.7)", px + 7, fy + 4, 1, 3); }
            }
            R("rgba(0,0,0,0.3)", px, fy, TILE, 1); R("#3a2a1c", px, fy + RAISE - 1, TILE, 1);
          } else if (shop) {
            // storefront glass
            R("#2a3a50", px, fy, TILE, RAISE); R("#111a28", px + 1, fy + 1, 14, 6); R("#3fb6cc", px + 1, fy + 1, 14, 1); R(INK, px + 7, fy + 1, 1, 6);
            if (v < 0.5) { R("#d8433b", px + 2, fy + 3, 4, 3); R("#f5c542", px + 9, fy + 4, 4, 2); }
            else { R("#3a4658", px + 2, fy + 4, 4, 3); R("#3a4658", px + 9, fy + 3, 5, 4); }
            R(s.extD, px, fy + RAISE - 1, TILE, 1);
            if (v > 0.78) NEON.push({ x: px + 8, y: py + 20, r: 30, a: 0.4, col: "c", pad: false });
          } else {
            R(s.ext, px, fy, TILE, RAISE);
            R(s.extL, px, fy + 2, TILE, 1); R(s.extL, px, fy + 5, TILE, 1);
            R(s.extD, px, fy, TILE, 1); R(s.extD, px, fy + RAISE - 1, TILE, 1);
            if (v < 0.22) { R(s.extD, px + 4, fy + 1, 8, 6); R("#ffd86b", px + 5, fy + 2, 6, 4); R("#fff3c0", px + 5, fy + 2, 2, 1); R(s.extD, px + 8, fy + 2, 1, 4); NEON.push({ x: px + 8, y: py + 18, r: 22, a: 0.45, col: "w", pad: false }); }
            else if (v < 0.6) { R(s.extD, px + 4, fy + 1, 8, 6); R("#141c2a", px + 5, fy + 2, 6, 4); R("#2c3a55", px + 5, fy + 2, 2, 1); R(s.extD, px + 8, fy + 2, 1, 4); }
            else if (v < 0.72) { R("#141c2a", px + 4, fy + 1, 8, 6); R("#5a4028", px + 3, fy + 2, 10, 2); R("#6e5236", px + 3, fy + 5, 10, 1); }
          }
        }
      } else if (k === 1) {
        const s = CS[st] ?? CS[2];
        R(s.top, px, py, TILE, TILE);
        for (let i = 0; i < 4; i++) R(i % 2 ? s.a : s.b, px + 1 + ((h2(tx, ty, i) * 12) | 0), py + 1 + ((h2(tx, ty, i + 7) * 13) | 0), 2, 1);
        // parapet around the roof
        if (!same(tx, ty - 1, st)) { R(s.hi, px, py, TILE, 1); R(s.lo, px, py + 1, TILE, 2); }
        if (!same(tx - 1, ty, st)) { R(s.hi, px, py, 1, TILE); R(s.lo, px + 1, py, 2, TILE); }
        if (!same(tx + 1, ty, st)) { R(s.lo, px + 13, py, 2, TILE); R(s.b, px + 15, py, 1, TILE); }
        if (!same(tx, ty + 1, st)) { R(s.lo, px, py + 13, TILE, 2); R(s.hi, px, py + 15, TILE, 1); }
        // facade
        R(s.front, px, fy, TILE, RAISE);
        R(s.fline, px, fy + 3, TILE, 1); R(s.fline, px + (tx % 2 ? 5 : 11), fy + 1, 1, 2); R(s.fline, px + (tx % 2 ? 11 : 5), fy + 4, 1, 3);
        R(s.fdark, px, fy, TILE, 1); R(s.fdark, px, fy + RAISE - 1, TILE, 1);
        if (kindAt(tx, ty + 1) !== 1 && ty < MH - 1) {
          const v = h2(tx, ty, 30);
          if (v < 0.3) {
            R(s.fdark, px + 4, fy + 1, 8, 6); R("#ffd86b", px + 5, fy + 2, 6, 4); R("#fff3c0", px + 5, fy + 2, 2, 1); R(s.fdark, px + 8, fy + 2, 1, 4);
            if (v < 0.13) NEON.push({ x: px + 8, y: py + 18, r: 24, a: 0.5, col: "w", pad: false });
          } else if (v < 0.62) {
            R(s.fdark, px + 4, fy + 1, 8, 6); R("#141c2a", px + 5, fy + 2, 6, 4); R("#2c3a55", px + 5, fy + 2, 2, 1); R(s.fdark, px + 8, fy + 2, 1, 4);
            if (v > 0.55) R("#05070c", px + 9, fy + 3, 2, 2);
          } else if (v < 0.7) {
            R(s.fdark, px + 4, fy, 8, RAISE); R("#3a2a22", px + 5, fy + 1, 6, RAISE - 1); R("#f5c542", px + 9, fy + 4, 1, 1);
          } else if (v < 0.8) {
            const n = NEON_COL[((v * 1000) | 0) % 4];
            R("#0d0d12", px + 2, fy + 1, 12, 5); R(n[1], px + 3, fy + 2, 10, 3); R(n[2], px + 4, fy + 3, 3, 1); R(n[2], px + 9, fy + 3, 2, 1);
            NEON.push({ x: px + 8, y: py + 20, r: 38, a: 0.62, col: n[0], pad: false, fx: v > 0.77 ? 1 : undefined });
          } else if (v < 0.87) {
            R("#141c2a", px + 4, fy + 1, 8, 6); R("#5a4028", px + 3, fy + 2, 10, 2); R("#6e5236", px + 3, fy + 5, 10, 1);
          }
        }
      } else if (k === 2 && st >= 10) cupboard(R, px, py, st);
      else if (k === 2) {
        if (st === 1 || st === 5) carH(R, px, py, h2(tx, ty, 40), st === 5);
        else if (st === 3) carV(R, px, py, h2(tx, ty, 40));
        else if (st === 0) dumpster(R, px, py);
      } else if (k === 3 && st >= 20) lowFurniture(R, px, py, st, h2(houseAt(tx, ty), 3, 44));
      else if (k === 3) {
        // low police barricade
        const oy = py + RAISE - 3;
        R("#1a1a22", px, oy, TILE, TILE);
        R("#6d7684", px + 1, oy + 1, 14, 14);
        for (let i = -16; i < 16; i += 8) for (let j = 1; j < 15; j++) { const sx = px + i + j; if (sx > px && sx < px + 12) R("#f5c542", sx, oy + j, 4, 1); }
        R("#8a96a8", px + 1, oy + 1, 14, 1); R("#1a1a22", px, oy, TILE, 1); R("#1a1a22", px + 15, oy, 1, TILE);
        R("#3d444f", px, oy + TILE, TILE, 3); R("#22262d", px, oy + TILE + 2, TILE, 1);
      } else if (st === 1) {
        // tree: roots in a patch of soil (flat on the ground)
        const gy = py + RAISE;
        ell(R, px + 8, gy + 8, 7, 5, "#1a1410"); ell(R, px + 8, gy + 8, 5, 3, "#3a2c20");
        R("#2a1c14", px + 2, gy + 9, 4, 1); R("#2a1c14", px + 10, gy + 11, 4, 1); R("#2a1c14", px + 11, gy + 5, 3, 1);
      } else {
        // lamp post / traffic light footing
        R(INK, px + 2, py + 2, 12, 12 + RAISE);
        R("#5d5f69", px + 3, py + 3, 10, 10); R("#7d7f8a", px + 3, py + 3, 10, 1); R("#7d7f8a", px + 3, py + 3, 1, 10);
        R("#3c3e46", px + 3, py + 13, 10, RAISE - 1); R("#2a2b33", px + 7, py + 14, 2, RAISE - 3);
        if (st === 2) { R("#f5c542", px + 3, py + 14, 10, 1); R(INK, px + 5, py + 14, 2, 1); R(INK, px + 9, py + 14, 2, 1); }
      }
    }
  for (let i = 0; i < BUILDINGS.length; i++) roofProps(R, BUILDINGS[i], i + 3);
  return c;
}

/** roofs of the enterable houses; the engine fades a roof out while you are inside */
function buildRoofsCity(): Cv {
  const [c, x] = mk(MW * TILE, MH * TILE);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  HOUSES.forEach((hs, n) => {
    const s = ROOF[n % 4], X = hs.x * TILE, Y = hs.y * TILE, W = hs.w * TILE, H = hs.h * TILE;
    if (hs.shop) {
      // flat supermarket roof with a big sign
      R(INK, X, Y, W, H); R("#565c68", X + 1, Y + 1, W - 2, H - 2); R("#6a7180", X + 1, Y + 1, W - 2, 1); R("#6a7180", X + 1, Y + 1, 1, H - 2);
      R("#3c414b", X + 4, Y + 4, W - 8, H - 8); R("#454b57", X + 5, Y + 5, W - 10, H - 10);
      for (let i = 0; i < 4; i++) {
        const ax = Math.round(X + 16 + (i * (W - 54)) / 3), ay = Y + H - 36;
        R(INK, ax, ay, 22, 16); R("#aab2bd", ax + 1, ay + 1, 20, 14); R("#d9dee8", ax + 1, ay + 1, 20, 1); R("#4a505c", ax + 3, ay + 3, 9, 9); R("#7d8592", ax + 5, ay + 5, 5, 5);
      }
      for (let i = 0; i < 3; i++) { const sx = X + 30 + i * 100, sy = Y + 74; R(INK, sx, sy, 26, 14); R("#1c2c55", sx + 1, sy + 1, 24, 12); R("#5f84d4", sx + 1, sy + 6, 24, 1); R("#5f84d4", sx + 8, sy + 1, 1, 12); R("#5f84d4", sx + 17, sy + 1, 1, 12); }
      const sx = X + (W >> 1) - 42, sy = Y + 22;
      R(INK, sx - 5, sy - 5, 90, 35); R("#c0392b", sx - 4, sy - 4, 88, 33); R("#e8604c", sx - 4, sy - 4, 88, 2);
      x.fillStyle = "#fff3c0";
      glyphs(x, "MART", sx + 1, sy, 5);
    } else {
      R(s.lo, X, Y, W, H);
      R(s.a, X + 1, Y + 1, W - 2, H - 2);
      for (let j = 0; j < H - 2; j += 4) {
        R(s.b, X + 1, Y + 4 + j, W - 2, 1);
        for (let i = ((j >> 2) % 2) * 4; i < W - 2; i += 8) R(s.b, X + 1 + i, Y + 1 + j, 1, 3);
      }
      R("rgba(255,255,255,0.07)", X + 1, Y + 1, W - 2, (H >> 1) - 1);
      R(s.hi, X + 1, Y + (H >> 1) - 1, W - 2, 2); R(s.lo, X + 1, Y + (H >> 1) + 1, W - 2, 1);
      R(s.hi, X + 1, Y + 1, W - 2, 1); R(s.hi, X + 1, Y + 1, 1, H - 2); R(s.lo, X + 1, Y + H - 3, W - 2, 2);
      // chimney
      const cx = X + W - 30 + ((n * 7) % 9), cy = Y + 9;
      R("rgba(0,0,0,0.3)", cx + 2, cy + 3, 11, 10); R(INK, cx, cy, 11, 11); R("#7a5446", cx + 1, cy + 1, 9, 9); R("#9a7262", cx + 1, cy + 1, 9, 1); R("#14100e", cx + 3, cy + 3, 5, 5);
      // skylights
      if (hs.up !== undefined || hs.under !== undefined) {
        // two storeys: a raised second roof with lit dormer windows
        const ix = X + 12, iy = Y + 22, iw = W - 24, ih = H - 40;
        R("rgba(0,0,0,0.4)", ix + 3, iy + 5, iw, ih); R(s.lo, ix - 1, iy - 1, iw + 2, ih + 2); R(s.a, ix, iy, iw, ih);
        for (let j = 0; j < ih; j += 4) R(s.b, ix, iy + 3 + j, iw, 1);
        R(s.hi, ix, iy, iw, 2); R(s.hi, ix, iy, 2, ih); R(s.hi, ix, iy + (ih >> 1) - 1, iw, 2); R(s.lo, ix, iy + ih - 2, iw, 2);
        for (let i = 0; i < 3; i++) {
          const dx = (ix + 12 + (i * (iw - 40)) / 2) | 0, dy = iy + ih - 15;
          R(INK, dx, dy, 16, 13); R("#7a5446", dx + 1, dy + 1, 14, 11); R("#ffd86b", dx + 3, dy + 4, 10, 7); R("#fff3c0", dx + 3, dy + 4, 4, 2); R(INK, dx + 7, dy + 4, 1, 7);
        }
      } else
      for (let i = 0; i < 2; i++) { const sx = X + 12 + i * 40, sy = Y + H - 26; R(INK, sx, sy, 14, 10); R("#243a52", sx + 1, sy + 1, 12, 8); R("#5a84a8", sx + 2, sy + 2, 4, 1); R(INK, sx + 7, sy + 1, 1, 8); }
    }
    // striped awning above every door
    for (const d of hs.doors) {
      const dx = d.tx * TILE, dy = d.ty * TILE;
      const stripe = (ax: number, ay: number, w: number, h: number, horiz: boolean) => {
        R(INK, ax - 1, ay - 1, w + 2, h + 2);
        for (let i = 0; i < (horiz ? w : h); i += 3) R((i / 3) % 2 ? "#f3ead8" : hs.shop ? "#c0392b" : "#f5c542", horiz ? ax + i : ax, horiz ? ay : ay + i, horiz ? Math.min(3, w - i) : w, horiz ? h : Math.min(3, h - i));
      };
      if (d.oy === 1) stripe(dx, Y + H - 7, 16, 6, true);
      else if (d.oy === -1) stripe(dx, Y + 1, 16, 6, true);
      else if (d.ox === -1) stripe(X + 1, dy, 6, 16, false);
      else stripe(X + W - 7, dy, 6, 16, false);
    }
  });
  return c;
}

/* ───────────── standing props (same anchor as the palm sprite) ───────────── */
function buildLamp(): Cv {
  const [c, x] = mk(44, 44);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  R(INK, 20, 4, 4, 40); R("#5d6470", 21, 5, 2, 39); R("#9aa2ae", 21, 5, 1, 39);
  R(INK, 18, 38, 8, 6); R("#4a505c", 19, 39, 6, 5); R("#6a7280", 19, 39, 6, 1);
  R(INK, 22, 3, 14, 4); R("#5d6470", 23, 4, 12, 2);
  R(INK, 27, 2, 10, 8); R("#4a505c", 28, 3, 8, 3); R("#fff3c0", 28, 6, 8, 3); R("#ffffff", 29, 7, 5, 1);
  return c;
}
function buildTree(ph: number): Cv {
  const [c, x] = mk(44, 44);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  R(INK, 19, 22, 6, 22); R("#4a3424", 20, 23, 4, 21); R("#6a4c34", 20, 23, 1, 21); R("#2e2016", 23, 30, 1, 10);
  R(INK, 15, 26, 5, 2); R("#4a3424", 16, 26, 4, 1); R(INK, 24, 29, 5, 2); R("#4a3424", 24, 29, 4, 1);
  const sx = Math.round(Math.sin(ph) * 1.6);
  const blob = (bx: number, by: number, rx: number, ry: number) => { ell(R, bx + 1, by + 1, rx + 1, ry + 1, "#0c1a12"); };
  const fill = (bx: number, by: number, rx: number, ry: number, col: string) => ell(R, bx, by, rx, ry, col);
  const B: number[][] = [[22 + sx, 13, 12, 9], [13 + sx, 18, 7, 6], [31 + sx, 18, 7, 6], [22 + sx, 20, 9, 6], [17 + sx, 9, 6, 5], [28 + sx, 9, 6, 5]];
  for (const b of B) blob(b[0], b[1], b[2], b[3]);
  for (const b of B) fill(b[0], b[1], b[2], b[3], "#1c4028");
  for (const b of B) fill(b[0] - 2, b[1] - 2, Math.max(2, b[2] - 4), Math.max(2, b[3] - 3), "#2a5a36");
  for (let i = 0; i < 16; i++) R(i % 3 ? "#3f7a46" : "#5a9a5a", 12 + sx + ((h2(i, 3, 91) * 20) | 0), 6 + ((h2(i, 4, 92) * 14) | 0), 2, 1);
  return c;
}
function buildSignal(): Cv {
  const [c, x] = mk(44, 44);
  const R: Paint = (col, a, b, w, h) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  R(INK, 20, 14, 4, 30); R("#3c424c", 21, 15, 2, 29); R("#6a7280", 21, 15, 1, 29);
  R(INK, 18, 38, 8, 6); R("#4a505c", 19, 39, 6, 5);
  R(INK, 17, 0, 10, 20); R("#22252d", 18, 1, 8, 18); R("#3c424c", 18, 1, 8, 1);
  R("#3a1014", 20, 3, 4, 4); R("#f5c542", 20, 8, 4, 4); R("#fff3c0", 21, 9, 2, 1); R("#10301a", 20, 13, 4, 4);
  return c;
}

/** every static light source of the night city */
export function cityLamps(): Lamp[] {
  const out: Lamp[] = [];
  for (const p of PALMS) {
    if (p.k === 0) {
      const fx = h2(p.x | 0, p.y | 0, 90) > 0.8 ? 1 : undefined;
      out.push({ x: p.x + 9, y: p.y + 6, r: 72, a: 0.85, col: "w", pad: false, fx });
      out.push({ x: p.x + 10, y: p.y - 41, r: 13, a: 1, col: "w", pad: false, fx });
    } else if (p.k === 2) out.push({ x: p.x, y: p.y - 39, r: 16, a: 0, col: "y", pad: false, fx: 4 });
  }
  const PX = PAD.x * TILE, PY = PAD.y * TILE, PW = PAD.w * TILE, PH = PAD.h * TILE;
  for (const [lx, ly] of [[PX + 7, PY + 7], [PX + PW - 8, PY + 7], [PX + 7, PY + PH - 8], [PX + PW - 8, PY + PH - 8]]) out.push({ x: lx, y: ly, r: 52, a: 0.8, col: "c", pad: true });
  // lamps left burning inside the houses; strip lights and cold fridge glow in the mart
  HOUSES.forEach((hs, n) => {
    if (hs.stair) out.push({ x: hs.stair.tx * TILE + 8, y: hs.stair.ty * TILE + 14, r: 34, a: 0.6, col: "y", pad: false, house: n }); // a bulb over the stairs
    if (hs.shop) {
      const X0 = (hs.x + 1) * TILE, Y0 = (hs.y + 1) * TILE, W = (hs.w - 2) * TILE, H = (hs.h - 2) * TILE;
      for (let i = 0; i < 4; i++) out.push({ x: X0 + (W * (i + 0.5)) / 4, y: Y0 + H * 0.55, r: 54, a: i % 2 ? 0.5 : 0.36, col: "w", pad: false, house: n, fx: i !== 1 ? 1 : undefined });
      for (let i = 0; i < 5; i++) out.push({ x: X0 + (W * (i + 0.5)) / 5, y: Y0 + 16, r: 34, a: 0.5, col: "c", pad: false, house: n });
      return;
    }
    hs.rooms.forEach((rm, k) => {
      // only some rooms still have a bulb burning: the rest is up to your flashlight
      if (h2(n, k, 71) > 0.62) out.push({ x: (rm.x + rm.w / 2) * TILE, y: (rm.y + rm.h / 2) * TILE, r: 20 + Math.max(rm.w, rm.h) * 6, a: 0.5, col: "w", pad: false, house: n, fx: h2(n, k, 72) > 0.6 ? 1 : undefined });
    });
  });
  // wrecks with their headlights still on, and the police car's light bar
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      if (kindAt(tx, ty) !== 2) continue;
      const st = styleAt(tx, ty), px = tx * TILE, py = ty * TILE;
      if (st === 5) {
        out.push({ x: px + 13, y: py + 2, r: 64, a: 0.45, col: "r", pad: false, fx: 2 });
        out.push({ x: px + 19, y: py + 2, r: 64, a: 0.45, col: "b", pad: false, fx: 3 });
      } else if ((st === 1 || st === 3) && h2(tx, ty, 41) > 0.7) {
        if (st === 1) out.push({ x: px + 33, y: py + 4, r: 22, a: 0.6, col: "w", pad: false, beam: 0, fx: h2(tx, ty, 42) > 0.5 ? 1 : undefined });
        else out.push({ x: px + 8, y: py - 8, r: 22, a: 0.6, col: "w", pad: false, beam: -Math.PI / 2, fx: h2(tx, ty, 42) > 0.5 ? 1 : undefined });
      }
    }
  return out.concat(NEON);
}

export interface MapArt { floor: Cv; clean: Cv; walls: Cv; roofs: Cv | null; mini: Cv; props: Cv[][]; theme: number }
const artCache: (MapArt | undefined)[] = [];
/** loads the map and returns its (lazily built, cached) textures */
export function mapArt(id: number): MapArt {
  loadMap(id);
  if (!artCache[id]) {
    const floor = id === 0 ? buildFloor() : buildFloorCity();
    const [clean, cx] = mk(floor.width, floor.height);
    cx.drawImage(floor, 0, 0);
    if (id === 0) artCache[id] = { floor, clean, walls: buildWalls(), roofs: null, mini: buildMini(0), props: [[buildPalm(-0.6), buildPalm(0), buildPalm(0.6)]], theme: 0 };
    else {
      const lamp = buildLamp(), sig = buildSignal();
      artCache[id] = { floor, clean, walls: buildWallsCity(), roofs: buildRoofsCity(), mini: buildMini(1), props: [[lamp, lamp, lamp], [buildTree(-0.6), buildTree(0), buildTree(0.6)], [sig, sig, sig]], theme: 1 };
    }
  }
  return artCache[id]!;
}

/* ───────────── zombies: head + torso sprites, limbs are animated in code ───────────── */
const Z_HEADS: string[][] = [
  // bald, head wound
  [
    "....KKKKKK....", "..KKSSSSSSKK..", ".KSsSSSSSBBSK.", ".KSSSSSSSSBdK.", "KSSSSSSSSSSSdK",
    "KSDEDSSSDEDSdK", "KSSSSSSSSSSSdK", "KSSMTMTMTMSSdK", ".KdSSMMMMSSdK.", "..KKKKKKKKKK..",
  ],
  // messy hair
  [
    "...KKKKKKKK...", "..KHHhHHHHHK..", ".KHHHHHhHHHHK.", ".KHSSHSSSHSdK.", "KHSSSSSSSSSSdK",
    "KSDEDSSSDEDSdK", "KSSSSSSSSSBSdK", "KSSMTMTMTMSSdK", ".KdSSMMMMSSdK.", "..KKKKKKKKKK..",
  ],
  // long hair
  [
    "...KKKKKKKK...", "..KHHHHhHHHK..", ".KHHhHHHHHHHK.", "KHHSSSSSSSHHHK", "KHSSSSSSSSSHHK",
    "KHDEDSSSDEDHHK", "KHSSSSSSSSSHHK", "KHSMTMTMTMSHHK", "KHHdSMMMMSdHHK", ".KHKKKKKKKKHK.",
  ],
  // cap / helmet
  [
    "...KKKKKKKK...", "..KCCcCCCCCK..", ".KCCCCCCCCCCK.", "KKCCCCCCCCCCKK", "KSSSSSSSSSSSdK",
    "KSDEDSSSDEDSdK", "KSSBSSSSSSSSdK", "KSSMTMTMTMSSdK", ".KdSSMMMMSSdK.", "..KKKKKKKKKK..",
  ],
];
const Z_TORSO = ["..KRRRRRRRRK..", ".KRrRRRRRRrRK.", ".KRRRSRRBRRRK.", ".KRRRRRBBRRRK.", "..KKPPPPPPKK..", "...KPPKKPPK..."];
const Z_SKIN = [["#8fae7a", "#a9c692", "#6d8a5c"], ["#9aa8a0", "#b4c2ba", "#77857d"], ["#7fa08e", "#99baa8", "#5f7d6d"]];
const Z_SHIRT = [["#3b6ea8", "#5a8cc6"], ["#a83b3b", "#c65a5a"], ["#c9c9c0", "#e6e6de"], ["#c9a83b", "#e6c65a"], ["#6a4a8a", "#8868a8"], ["#3f8a5a", "#5aa878"], ["#d07a2a", "#f09a4a"]];
const Z_PANTS = ["#35415e", "#4a4a55", "#5a4632"];
const Z_HAIR = [["#2a1c14", "#4a3424"], ["#5a3a1c", "#7a5430"], ["#b8a070", "#d8c090"], ["#1c1c24", "#3a3a48"]];
/** zombie dog body, facing right (legs are drawn in code) */
const DOG = [
  "..............KK..",
  ".............KDDK.",
  "KK..........KDDDDK",
  "KDKKKKKKKKKKDDEDDK",
  ".KDdDRDRDdDDDDDDTK",
  ".KDDDRDRDDDDDKKKK.",
  ".KDDDDDDDDDDK.....",
  "..KKKKKKKKKK......",
];

export interface ZVar { img: Cv; white: Cv; skin: string; sleeve: string; pants: string; s: number }

function zvar(i: number, eye: string, scale: number, extra: Record<string, string> = {}): ZVar {
  const sk = Z_SKIN[i % 3], sh = Z_SHIRT[(i * 3 + 1) % Z_SHIRT.length], cap = Z_SHIRT[(i + 3) % Z_SHIRT.length], hr = Z_HAIR[(i + (i >> 2)) % 4];
  const pal: Record<string, string> = {
    K: "#0d0a0c", S: sk[0], s: sk[1], d: sk[2], D: "#241014", E: eye, M: "#4a0c14", T: "#e9e2c8", B: "#8a1420",
    H: hr[0], h: hr[1], C: cap[0], c: cap[1], R: sh[0], r: sh[1], P: Z_PANTS[i % 3], ...extra,
  };
  const base = fromMap([...Z_HEADS[i % 4], ...Z_TORSO], pal);
  let img = base;
  if (scale !== 1) {
    const [sc, sx] = mk(Math.round(14 * scale), Math.round(16 * scale));
    sx.drawImage(base, 0, 0, sc.width, sc.height);
    img = sc;
  }
  return { img, white: whiten(img), skin: pal.S, sleeve: pal.R, pants: pal.P, s: scale };
}
function dogVar(i: number): ZVar {
  const fur = [["#6a6a74", "#8e8e9a"], ["#6a5244", "#8f715e"], ["#55555f", "#7a7a86"]][i % 3];
  const img = fromMap(DOG, { K: "#0d0a0c", D: fur[0], d: fur[1], R: "#a8202c", E: "#ff4a4a", T: "#e9e2c8" });
  return { img, white: whiten(img), skin: fur[1], sleeve: fur[0], pants: fur[0], s: 1 };
}

let zCache: Record<BugKind, ZVar[]> | null = null;
export function zombieSprites(): Record<BugKind, ZVar[]> {
  if (zCache) return zCache;
  const walkers: ZVar[] = [], runners: ZVar[] = [];
  for (let i = 0; i < 12; i++) walkers.push(zvar(i, "#ffe9a0", 1));
  for (let i = 0; i < 4; i++) runners.push(zvar(i * 5 + 1, "#ff4a4a", 1, { S: "#b8a8a0", s: "#d2c4bc", d: "#8f7f78", P: "#3a3a48", B: "#a8202c" }));
  const bile = { S: "#7fbf4a", s: "#a6e070", d: "#5a9a34", R: "#56606e", r: "#6e7a8a", B: "#c8ff4a", M: "#2f7a20", T: "#c8ff4a" };
  zCache = {
    scav: walkers,
    warrior: runners,
    spitter: [zvar(0, "#c8ff4a", 1.25, bile), zvar(1, "#c8ff4a", 1.25, bile)],
    // riot-gear brute
    charger: [zvar(3, "#ff4a4a", 1.5, { S: "#8a9488", s: "#a4aea2", d: "#687266", C: "#1c2438", c: "#4a5a80", R: "#232c44", r: "#3d4a6c", P: "#2a3350", B: "#c9c9c0" })],
    // giant mutant
    titan: [zvar(0, "#c8ff4a", 3, { S: "#8a6a9a", s: "#a888b8", d: "#644a74", R: "#3a2a44", r: "#54405e", P: "#33263e", B: "#c8ff4a", M: "#2a0c1c" })],
    dog: [dogVar(0), dogVar(1), dogVar(2)],
  };
  return zCache;
}

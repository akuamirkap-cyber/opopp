export type SfxName =
  | "pistol" | "shotgun" | "sniper" | "bazooka" | "slash" | "whoosh" | "thunk" | "hit" | "hurt" | "ko" | "boom"
  | "squish" | "roar" | "beep" | "pod" | "groan" | "bark" | "crack" | "thunder" | "alarm" | "ping" | "heart" | "screech" | "rumble" | "reload" | "dash" | "deflect" | "start" | "win" | "lose" | "click" | "wall" | "pick" | "tick";

/** Tiny chiptune-style sound kit, everything is synthesized with WebAudio. */
class SoundKit {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private noiseBuf: AudioBuffer | null = null;
  private last: Partial<Record<SfxName, number>> = {};
  muted = false;

  unlock() {
    try {
      if (!this.ctx) {
        const AC: typeof AudioContext =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (!AC) return;
        this.ctx = new AC();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.32;
        this.master.connect(this.ctx.destination);
        const buf = this.ctx.createBuffer(1, this.ctx.sampleRate, this.ctx.sampleRate);
        const d = buf.getChannelData(0);
        for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
        this.noiseBuf = buf;
      }
      if (this.ctx.state === "suspended") void this.ctx.resume();
    } catch {
      this.ctx = null;
    }
  }

  private amb: { drone: GainNode; wind: GainNode; rain: GainNode } | null = null;
  private ambLevel = -1;

  /** continuous low drone + wind for the alien planet (level 0 turns it off) */
  ambience(level: number, wind = 0.5, rain = 0) {
    if (!this.ctx || !this.master) return;
    const key = Math.round(level * 20) + Math.round(wind * 20) * 100 + Math.round(rain * 10) * 10000;
    if (key === this.ambLevel) return;
    this.ambLevel = key;
    try {
      const c = this.ctx, t = c.currentTime;
      if (!this.amb) {
        if (level <= 0) return;
        const drone = c.createGain(), wnd = c.createGain(), lp = c.createBiquadFilter(), bp = c.createBiquadFilter();
        drone.gain.value = 0; wnd.gain.value = 0;
        lp.type = "lowpass"; lp.frequency.value = 210;
        bp.type = "bandpass"; bp.frequency.value = 520; bp.Q.value = 0.6;
        for (const [type, f] of [["sine", 46], ["sawtooth", 69.4], ["sine", 92.5]] as [OscillatorType, number][]) {
          const o = c.createOscillator();
          o.type = type; o.frequency.value = f;
          o.connect(lp);
          o.start();
        }
        const lfo = c.createOscillator(), lg = c.createGain();
        lfo.frequency.value = 0.13; lg.gain.value = 70;
        lfo.connect(lg).connect(lp.frequency);
        lfo.start();
        lp.connect(drone).connect(this.master);
        const n = c.createBufferSource();
        n.buffer = this.noiseBuf; n.loop = true;
        const l2 = c.createOscillator(), g2 = c.createGain();
        l2.frequency.value = 0.21; g2.gain.value = 260;
        l2.connect(g2).connect(bp.frequency);
        l2.start();
        n.connect(bp).connect(wnd).connect(this.master);
        n.start();
        // rain hiss
        const rn = c.createGain(), hp = c.createBiquadFilter(), n2 = c.createBufferSource();
        rn.gain.value = 0;
        hp.type = "highpass"; hp.frequency.value = 2600;
        n2.buffer = this.noiseBuf; n2.loop = true;
        n2.connect(hp).connect(rn).connect(this.master);
        n2.start(0, 0.37);
        this.amb = { drone, wind: wnd, rain: rn };
      }
      this.amb.drone.gain.setTargetAtTime(level * 0.55, t, 0.4);
      this.amb.wind.gain.setTargetAtTime(level * wind * 0.5, t, 0.5);
      this.amb.rain.gain.setTargetAtTime(level > 0 ? Math.min(2, rain) * 0.15 : 0, t, 0.6);
    } catch {
      /* optional */
    }
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master) this.master.gain.value = m ? 0 : 0.32;
  }

  private tone(type: OscillatorType, f0: number, f1: number, dur: number, vol: number, delay = 0) {
    const c = this.ctx!, t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master!);
    o.start(t);
    o.stop(t + dur + 0.02);
  }

  private noise(ftype: BiquadFilterType, f0: number, f1: number, dur: number, vol: number, delay = 0) {
    const c = this.ctx!, t = c.currentTime + delay;
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf;
    s.loop = true;
    f.type = ftype;
    f.frequency.setValueAtTime(f0, t);
    if (f1 !== f0) f.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(f).connect(g).connect(this.master!);
    s.start(t, Math.random() * 0.5);
    s.stop(t + dur + 0.02);
  }

  play(name: SfxName, v = 1) {
    if (!this.ctx || !this.master || this.muted || v < 0.03) return;
    const now = performance.now();
    if (now - (this.last[name] ?? 0) < 35) return;
    this.last[name] = now;
    try {
      switch (name) {
        case "pistol":
          this.noise("highpass", 1800, 900, 0.07, 0.5 * v);
          this.tone("square", 560, 170, 0.07, 0.3 * v);
          break;
        case "shotgun":
          this.noise("lowpass", 2600, 300, 0.24, 0.9 * v);
          this.tone("sawtooth", 170, 45, 0.16, 0.5 * v);
          break;
        case "sniper":
          this.noise("lowpass", 4500, 200, 0.4, 1.0 * v);
          this.tone("triangle", 260, 36, 0.32, 0.8 * v);
          this.tone("square", 1500, 300, 0.06, 0.2 * v);
          break;
        case "bazooka":
          this.noise("bandpass", 300, 2400, 0.35, 0.9 * v);
          this.tone("sawtooth", 120, 420, 0.3, 0.4 * v);
          this.tone("sine", 90, 40, 0.2, 0.7 * v);
          break;
        case "crack":
          this.noise("highpass", 2200, 900, 0.06, 0.6 * v);
          this.tone("square", 220, 70, 0.09, 0.5 * v);
          this.noise("lowpass", 700, 200, 0.14, 0.6 * v);
          break;
        case "bark":
          this.tone("sawtooth", 430, 170, 0.08, 0.4 * v);
          this.tone("square", 310, 130, 0.08, 0.25 * v, 0.1);
          this.noise("bandpass", 900, 500, 0.09, 0.3 * v);
          break;
        case "groan":
          this.tone("sawtooth", 92 + Math.random() * 44, 60, 0.5, 0.3 * v);
          this.tone("square", 138, 86, 0.42, 0.11 * v, 0.04);
          this.noise("bandpass", 420, 250, 0.45, 0.2 * v);
          break;
        case "thunder":
          this.noise("lowpass", 420, 60, 1.5, 1.1 * v);
          this.tone("sine", 58, 30, 1.1, 0.9 * v);
          this.noise("lowpass", 2400, 300, 0.25, 0.5 * v);
          break;
        case "alarm":
          for (let i = 0; i < 3; i++) {
            this.tone("square", 640, 640, 0.15, 0.2 * v, i * 0.36);
            this.tone("square", 470, 470, 0.15, 0.2 * v, i * 0.36 + 0.18);
          }
          break;
        case "ping":
          this.tone("sine", 1760, 1700, 0.07, 0.3 * v);
          this.tone("sine", 1760, 1700, 0.07, 0.11 * v, 0.1);
          break;
        case "heart":
          this.tone("sine", 74, 44, 0.1, 1.0 * v);
          this.tone("sine", 64, 40, 0.1, 0.8 * v, 0.17);
          break;
        case "screech":
          this.tone("sawtooth", 950, 2300, 0.2, 0.22 * v);
          this.tone("square", 1400, 700, 0.16, 0.12 * v, 0.05);
          this.noise("bandpass", 3200, 5200, 0.22, 0.3 * v);
          break;
        case "rumble":
          this.noise("lowpass", 190, 80, 0.6, 1.1 * v);
          this.tone("sine", 48, 34, 0.55, 0.8 * v);
          break;
        case "squish":
          this.noise("lowpass", 900, 200, 0.1, 0.5 * v);
          this.tone("sine", 320, 90, 0.09, 0.35 * v);
          break;
        case "roar":
          this.tone("sawtooth", 70, 150, 0.5, 0.6 * v);
          this.tone("square", 52, 96, 0.5, 0.35 * v);
          this.noise("bandpass", 300, 900, 0.5, 0.4 * v);
          break;
        case "beep":
          this.tone("square", 1250, 1250, 0.07, 0.25 * v);
          break;
        case "pod":
          this.noise("lowpass", 3000, 150, 0.35, 0.9 * v);
          this.tone("sine", 140, 40, 0.3, 0.9 * v);
          break;
        case "slash":
          this.noise("bandpass", 2500, 7000, 0.09, 0.45 * v);
          break;
        case "whoosh":
          this.noise("bandpass", 500, 1800, 0.16, 0.5 * v);
          break;
        case "thunk":
          this.noise("lowpass", 1100, 200, 0.12, 0.8 * v);
          this.tone("sine", 210, 70, 0.12, 0.8 * v);
          break;
        case "hit":
          this.tone("square", 340, 140, 0.05, 0.28 * v);
          break;
        case "hurt":
          this.tone("sawtooth", 200, 70, 0.14, 0.45 * v);
          break;
        case "ko":
          this.tone("triangle", 780, 780, 0.07, 0.5 * v);
          this.tone("triangle", 590, 590, 0.07, 0.5 * v, 0.07);
          this.tone("triangle", 390, 300, 0.14, 0.5 * v, 0.14);
          break;
        case "boom":
          this.noise("lowpass", 1400, 60, 0.6, 1.2 * v);
          this.tone("sine", 100, 28, 0.45, 1.0 * v);
          break;
        case "reload":
          this.tone("square", 950, 950, 0.025, 0.2 * v);
          this.tone("square", 1300, 1300, 0.025, 0.2 * v, 0.09);
          break;
        case "dash":
          this.noise("bandpass", 700, 2600, 0.13, 0.35 * v);
          break;
        case "deflect":
          this.tone("square", 1300, 2200, 0.09, 0.4 * v);
          this.tone("triangle", 2600, 2600, 0.12, 0.3 * v, 0.03);
          break;
        case "start":
          [440, 554, 659, 880].forEach((f, i) => this.tone("square", f, f, 0.09, 0.3 * v, i * 0.08));
          break;
        case "win":
          [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone("square", f, f, 0.12, 0.3 * v, i * 0.1));
          break;
        case "lose":
          [440, 370, 311, 233].forEach((f, i) => this.tone("triangle", f, f * 0.97, 0.16, 0.45 * v, i * 0.14));
          break;
        case "click":
          this.tone("square", 720, 900, 0.04, 0.22 * v);
          break;
        case "wall":
          this.noise("highpass", 3000, 3000, 0.03, 0.14 * v);
          break;
        case "pick":
          this.tone("square", 660, 660, 0.06, 0.3 * v);
          this.tone("square", 990, 990, 0.09, 0.3 * v, 0.06);
          break;
        case "tick":
          this.tone("square", 520, 520, 0.06, 0.3 * v);
          break;
      }
    } catch {
      /* audio is optional */
    }
  }
}

export const audio = new SoundKit();

import { RAISE, TILE, WEAPON_ORDER } from "./defs";
import type { WeaponId } from "./defs";
import { BUILDINGS, MH, MW, PALMS, houseAt, kindAt, styleAt } from "./map";
import type { Building } from "./map";

type Pal = Record<string, string>;
type Cv = HTMLCanvasElement;
type Ctx = CanvasRenderingContext2D;

export function mk(w: number, h: number): [Cv, Ctx] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  const x = c.getContext("2d")!;
  x.imageSmoothingEnabled = false;
  return [c, x];
}

export function fromMap(rows: string[], pal: Pal): Cv {
  const [c, x] = mk(rows[0].length, rows.length);
  rows.forEach((r, y) => {
    for (let i = 0; i < r.length; i++) {
      const col = pal[r[i]];
      if (col) {
        x.fillStyle = col;
        x.fillRect(i, y, 1, 1);
      }
    }
  });
  return c;
}

export function whiten(src: Cv): Cv {
  const [c, x] = mk(src.width, src.height);
  x.drawImage(src, 0, 0);
  x.globalCompositeOperation = "source-in";
  x.fillStyle = "#ffffff";
  x.fillRect(0, 0, c.width, c.height);
  return c;
}

/* ───────────── operators: 14x10 head + 14x6 torso, legs/scarf/hands animated in code ───────────── */
const HEADS: string[][] = [
  // VIPER – pointed ninja hood, eye slit, gold forehead plate
  [
    "....KKKKKK....", "..KKHHHHHHKK..", ".KHhhhHHHHHdK.", ".KhhHHHHHHHdK.", "KHHHHHAAHHHHdK",
    "KHMMMMMMMMMMdK", "KHMFFWKFFWKMdK", "KHMMMmmmmMMMdK", ".KdMMMMMMMMdK.", "..KKKKKKKKKK..",
  ],
  // BRICK – headset, short hair, grinning bandana
  [
    "....KKKKKK....", "..KKRRRRRRKK..", ".KRRrrrRRRRRK.", ".KRrRRRRRRRRK.", "KGRFFFFFFFFRGK",
    "KGFFWKFFFWKFGK", "KGFMMMMMMMMFGK", ".KMMAMMMMAMMK.", ".KMMMAAAAMMMK.", "..KKKKKKKKKK..",
  ],
  // ONI – horned helmet with glowing multi-eye visor
  [
    ".A..KKKKKK..A.", ".AKKHHHHHHKKA.", ".KHHhhhHHHHHK.", ".KHhHHHAAHHdK.", "KHHHHHHAAHHHdK",
    "KHDDDDDDDDDDdK", "KHDVVDVVVDVVdK", "KHDDDDDDDDDDdK", ".KdHHGGGGHHdK.", "..KKKKKKKKKK..",
  ],
  // GHOST – skull mask under a hood
  [
    "....KKKKKK....", "..KKHHHHHHKK..", ".KHhhhHHHHHdK.", ".KhHHHHHHHHdK.", "KHHSSSSSSSSHdK",
    "KHSSKKSSSKKSdK", "KHSSKKSsSKKSdK", "KHdSSSSSSSSddK", ".KddSKSKSKSdK.", "..KKKKKKKKKK..",
  ],
  // SHADE – ornate trimmed veil, glowing eyes
  [
    "....KKKKKK....", "..KKAAAAAAKK..", ".KAAHHHHHHAAK.", ".KAHHhhHHHHAK.", "KAHHHHHHHHHHAK",
    "KAHDDDDDDDDHAK", "KAHDVVDDVVDHAK", "KAHDDDDDDDDHAK", ".KAAHDDDDHAAK.", "..KKKKKKKKKK..",
  ],
];
const TORSO = ["..KAABBBBAAK..", ".KAaBbBBbBaAK.", ".KBKBGAAGBKBK.", ".KBKBGGGGBKBK.", "..KKaAAAAaKK..", "...KDBKKBDK..."];

export const TEAM_PAL: Pal[] = [
  {
    K: "#0a0a0f", H: "#2b2d3a", h: "#4c5070", d: "#1b1c27", M: "#16171f", m: "#2c2e3d", F: "#e8b88f", A: "#f5c542", a: "#b8862b",
    B: "#22232f", b: "#3c3f58", D: "#111219", S: "#ece8dc", s: "#b3ae9e", V: "#fff3b0", W: "#ffffff", R: "#6b4226", r: "#94623c",
    G: "#3c4052", g: "#5b6078",
  },
  {
    K: "#16060a", H: "#6a1826", h: "#9a3243", d: "#470e19", M: "#240a0f", m: "#40151c", F: "#d9a47e", A: "#ff4d5e", a: "#b3243a",
    B: "#4a111b", b: "#782836", D: "#1f080c", S: "#f0dcd6", s: "#b89f98", V: "#ffd9d9", W: "#ffffff", R: "#2b1a12", r: "#4d362b",
    G: "#3a2a30", g: "#5c4650",
  },
];

/* ───────────── weapons (pointing right) ───────────── */
const WEAPON_MAPS: Record<WeaponId, string[]> = {
  pistol: ["..KKKKKKKK.", ".KLLLLLLLAK", ".KGGGgGGGGK", ".KGAKKKKKK.", ".KGGK......", ".KGaK......", "..KK......."],
  shotgun: [
    "......KKKKKKKKKKKK.",
    "KKKKKKgLLLLLLLLLLLK",
    "KWWWWKGGGGGGGGGGGK.",
    "KWwwWKGAAGKWWWWKK..",
    "KWWKKKKGGKKKKKKK...",
    ".KK...KGK..........",
    ".......K...........",
  ],
  sniper: [
    "........KKKKKKK...........",
    ".......KLLAALLLK..........",
    "........KKgKKgK...........",
    "KKKKKKKKKgggggKKKKKKKKKKKK",
    "KGGGGGAGGGGGGGGLLLLLLLLLLK",
    "KGGGKKKGGAGKKKKKKKKKKKKKK.",
    "KGGK..KGKKGK..............",
    ".KK...KGK.KK..............",
    "......KKK.................",
  ],
  bazooka: [
    "KK...KKKKKKKKKKKKK....",
    "KoKKKOOOOOOOOOOOOOKKK.",
    "KoOOOOoooooooAAoooORRK",
    "KOOOOOOOOOOOOAAOOOORRK",
    "KOKKKOOOOOOOOOOOOOKKK.",
    "KK...KKKGKKKKGKKKK....",
    ".......KGK..KGK.......",
    ".......KGK..KKK.......",
    ".......KKK............",
  ],
  karambit: ["......KKK..", "....KKSSSK.", "...KSSSssSK", "..KSSsKKsSK", ".KASsK..KSK", "KAAaK...KsK", "KAKAK....K.", "KAAK.......", ".KK........"],
  bat: ["...........KKKKKK.", "KKKKKKKKKKKWWWWWWK", "KaAaAWWWWWWWWAWWWK", "KKKKKKKKKKKwwwwwwK", "...........KKKKKK."],
};
/** grip position inside each weapon sprite */
export const WPIVOT: Record<WeaponId, [number, number]> = {
  pistol: [3, 3], shotgun: [7, 3], sniper: [7, 5], bazooka: [8, 5], karambit: [2, 6], bat: [2, 2],
};
/** barrel line relative to the grip row (for muzzle flashes) */
export const WBARREL: Record<WeaponId, number> = { pistol: -2, shotgun: -2, sniper: -1, bazooka: -3, karambit: 0, bat: 0 };
const WEAPON_PAL = (team: number): Pal => ({
  K: "#0a0a0f", G: "#2c2f3d", g: "#474c62", L: "#737a96", S: "#e9f1f8", s: "#a9b6c8",
  W: team === 0 ? "#dba55c" : "#cf8f5e", w: team === 0 ? "#a8743a" : "#96603c",
  O: team === 0 ? "#566b3e" : "#5b4a52", o: team === 0 ? "#7f9658" : "#806b74", R: "#e0483e",
  A: team === 2 ? "#c9cdd9" : TEAM_PAL[team].A, a: team === 2 ? "#8a8f9c" : TEAM_PAL[team].a,
});

const BARREL = [
  "..KKKKKK..", ".KrrrrrrK.", "KRrrrrrrRK", "KRRRRRRRRK", "KRRRRRRRRK", "KYYKYYKYYK",
  "KRRRRRRRRK", "KRRRRRRRRK", "KDRRRRRRDK", ".KDDDDDDK.", "..KKKKKK..",
];
const HEART = [".KK.KK.", "KPPKPPK", "KPWPPPK", ".KPPPK.", "..KPK..", "...K..."];

/* ───────────── 3x5 pixel font for in-world text ───────────── */
const FONT: Record<string, string> = {
  A: "010101111101101", B: "110101110101110", C: "011100100100011", D: "110101101101110", E: "111100110100111",
  F: "111100110100100", G: "011100101101011", H: "101101111101101", I: "111010010010111", J: "001001001101010",
  K: "101101110101101", L: "100100100100111", M: "101111111101101", N: "110101101101101", O: "010101101101010",
  P: "110101110100100", Q: "010101101110011", R: "110101110101101", S: "011100010001110", T: "111010010010010",
  U: "101101101101111", V: "101101101101010", W: "101101111111101", X: "101101010101101", Y: "101101010010010",
  Z: "111001010100111", "0": "111101101101111", "1": "010110010010111", "2": "110001010100111",
  "3": "110001010001110", "4": "101101111001001", "5": "111100110001110", "6": "011100111101111",
  "7": "111001010010010", "8": "111101111101111", "9": "111101111001110", "!": "010010010000010",
  "+": "000010111010000", "-": "000000111000000", "?": "110001010000010", ".": "000000000000010", ",": "000000000010100",
  "'": "010010000000000", ":": "000010000010000",
};

export function glyphs(ctx: Ctx, text: string, x: number, y: number, s = 1) {
  for (let i = 0; i < text.length; i++) {
    const g = FONT[text[i]];
    if (g) for (let p = 0; p < 15; p++) if (g[p] === "1") ctx.fillRect(x + (i * 4 + (p % 3)) * s, y + ((p / 3) | 0) * s, s, s);
  }
}

/** draw centered pixel text with a dark outline */
export function drawText(ctx: Ctx, text: string, cx: number, y: number, color: string, outline = "#0a0a0f") {
  const x = Math.round(cx - (text.length * 4 - 1) / 2);
  y = Math.round(y);
  ctx.fillStyle = outline;
  glyphs(ctx, text, x - 1, y);
  glyphs(ctx, text, x + 1, y);
  glyphs(ctx, text, x, y - 1);
  glyphs(ctx, text, x, y + 1);
  ctx.fillStyle = color;
  glyphs(ctx, text, x, y);
}

/* ───────────── world textures ───────────── */
export function h2(x: number, y: number, s = 0): number {
  let n = Math.imul(x + 11, 374761393) ^ Math.imul(y + 7, 668265263) ^ Math.imul(s + 3, 982451653);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  return ((n ^ (n >>> 16)) >>> 0) / 4294967296;
}

function isPlaza(tx: number, ty: number) {
  return (Math.abs(tx - 29.5) < 7 && Math.abs(ty - 18.5) < 6) || (ty >= 17 && ty <= 20 && tx >= 9 && tx <= 50);
}
const tall = (tx: number, ty: number) => {
  const k = kindAt(tx, ty);
  return k !== 0 && k !== 3;
};

export function buildFloor(): Cv {
  const W = MW * TILE, H = MH * TILE;
  const [c, x] = mk(W, H);
  const R = (col: string, a: number, b: number, w: number, h: number) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  /** run a painter at a spot and at its 180deg mirrored twin */
  const twin = (fn: (a: number, b: number) => void, a: number, b: number, w: number, h: number) => {
    fn(a, b);
    fn(W - a - w, H - b - h);
  };

  // base sand
  R("#dcb983", 0, 0, W, H);
  // soft tonal blotches
  for (let i = 0; i < 90; i++) {
    const bx = h2(i, 1, 50) * W, by = h2(i, 2, 51) * H, col = i % 2 ? "rgba(236,208,158,0.35)" : "rgba(196,158,102,0.28)";
    for (let j = 0; j < 9; j++) {
      const a = h2(i, j, 52) * 6.283, r = h2(i, j, 53) * 22;
      R(col, (bx + Math.cos(a) * r) | 0, (by + Math.sin(a) * r * 0.7) | 0, 6 + ((h2(i, j, 54) * 12) | 0), 3 + ((h2(i, j, 55) * 6) | 0));
    }
  }
  // tyre tracks through the outer lanes
  for (let px = 20; px < W - 20; px += 3) {
    if (h2(px, 0, 60) < 0.2) continue;
    const y0 = 40 + Math.sin(px * 0.013) * 9;
    for (const yy of [y0, y0 + 8, H - y0 - 2, H - y0 - 10]) R("rgba(150,108,64,0.3)", px, yy | 0, 2, 2);
  }

  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      const px = tx * TILE, py = ty * TILE;
      if (isPlaza(tx, ty)) {
        R("#a39075", px, py, TILE, TILE);
        for (let r = 0; r < 2; r++)
          for (let q = 0; q < 2; q++) {
            const v = h2(tx * 2 + q, ty * 2 + r, 1);
            const sx = px + q * 8, sy = py + r * 8;
            R(v > 0.75 ? "#d3c3a8" : v > 0.45 ? "#c9b89b" : v > 0.15 ? "#c1ae90" : "#b7a384", sx, sy, 7, 7);
            R("rgba(255,250,235,0.3)", sx, sy, 7, 1);
            R("rgba(255,250,235,0.18)", sx, sy, 1, 7);
            if (v > 0.93) { R("#8fa06a", sx + 4, sy + 4, 2, 2); R("#a9bb80", sx + 3, sy + 5, 1, 1); }
            else if (v < 0.05) { R("#9a8669", sx + 1, sy + 3, 3, 1); R("#9a8669", sx + 3, sy + 4, 2, 1); }
          }
        // curb where plaza meets sand
        if (!isPlaza(tx, ty - 1)) R("#8d7b61", px, py, TILE, 2);
        if (!isPlaza(tx, ty + 1)) R("#8d7b61", px, py + 14, TILE, 2);
        if (!isPlaza(tx - 1, ty)) R("#8d7b61", px, py, 2, TILE);
        if (!isPlaza(tx + 1, ty)) R("#8d7b61", px + 14, py, 2, TILE);
      } else {
        for (let i = 0; i < 5; i++)
          R(i % 2 ? "#ebcf9c" : "#c9a56d", px + ((h2(tx, ty, i) * 14) | 0), py + ((h2(tx, ty, i + 9) * 15) | 0), i === 0 ? 3 : 2, 1);
        const v = h2(tx, ty, 20);
        if (v > 0.93) {
          const ox = 3 + ((h2(tx, ty, 21) * 9) | 0), oy = 3 + ((h2(tx, ty, 22) * 9) | 0);
          R("#a98758", px + ox, py + oy, 3, 2);
          R("#f3dcae", px + ox, py + oy, 2, 1);
        } else if (v > 0.86) {
          // dune ripple
          const oy = 4 + ((h2(tx, ty, 23) * 8) | 0);
          R("#c9a56d", px + 2, py + oy + 1, 3, 1); R("#c9a56d", px + 5, py + oy, 4, 1); R("#c9a56d", px + 9, py + oy + 1, 3, 1);
          R("#ebcf9c", px + 5, py + oy + 1, 4, 1);
        } else if (v > 0.81) {
          // grass tuft
          const ox = 4 + ((h2(tx, ty, 24) * 8) | 0), oy = 5 + ((h2(tx, ty, 25) * 7) | 0);
          R("#5d8a3c", px + ox, py + oy, 1, 3); R("#5d8a3c", px + ox + 2, py + oy + 1, 1, 2); R("#5d8a3c", px + ox - 2, py + oy + 1, 1, 2);
          R("#8fbf5a", px + ox, py + oy, 1, 1); R("#8fbf5a", px + ox + 2, py + oy + 1, 1, 1);
        } else if (v < 0.03) {
          // cracks
          R("#b8935c", px + 3, py + 5, 4, 1); R("#b8935c", px + 6, py + 6, 1, 3); R("#b8935c", px + 7, py + 8, 4, 1);
        }
      }
    }

  // mosaic ring around the centre
  for (let a = 0; a < 6.283; a += 0.02) {
    const seg = Math.floor(a / 0.26) % 3;
    R(seg === 0 ? "#c9973a" : seg === 1 ? "#a8323a" : "#e9e2d2", (W / 2 + Math.cos(a) * 66) | 0, (H / 2 + Math.sin(a) * 66) | 0, 2, 2);
    if (seg !== 2) R("rgba(60,40,30,0.35)", (W / 2 + Math.cos(a) * 62) | 0, (H / 2 + Math.sin(a) * 62) | 0, 1, 1);
  }
  // faded lane dashes on the mid road
  twin((a, b) => { for (let i = 0; i < 10; i++) if (h2(i, a, 70) > 0.15) R("rgba(255,250,235,0.5)", a + i * 16, b, 8, 2); }, 11 * TILE, 19 * TILE - 1, 160, 2);

  // rugs
  const rug = (w: number, h: number, base: string, dark: string) => (a: number, b: number) => {
    R("#3a1a14", a - 1, b - 1, w + 2, h + 2);
    R(base, a, b, w, h);
    R("#f0c75a", a + 1, b + 1, w - 2, 1); R("#f0c75a", a + 1, b + h - 2, w - 2, 1); R("#f0c75a", a + 1, b + 1, 1, h - 2); R("#f0c75a", a + w - 2, b + 1, 1, h - 2);
    R(dark, a + 3, b + 3, w - 6, h - 6);
    for (let i = 5; i < w - 6; i += 4) { R("#f0c75a", a + i, b + ((h / 2) | 0), 2, 1); R(base, a + i, b + ((h / 2) | 0) - 2, 2, 1); R(base, a + i, b + ((h / 2) | 0) + 2, 2, 1); }
    for (let j = 0; j < h; j += 2) { R("#f3ead8", a - 2, b + j, 1, 1); R("#f3ead8", a + w + 1, b + j, 1, 1); }
  };
  twin(rug(26, 13, "#a8323a", "#7a1f28"), 19 * TILE + 3, 14 * TILE + 1, 26, 13);
  twin(rug(22, 11, "#2f6f8a", "#1f4c61"), 10 * TILE + 2, 13 * TILE + 3, 22, 11);
  twin(rug(13, 24, "#a8323a", "#7a1f28"), 22 * TILE + 1, 7 * TILE - 2, 13, 24);

  // manholes
  twin((a, b) => {
    R("#5e564c", a + 2, b, 8, 12); R("#5e564c", a, b + 2, 12, 8); R("#5e564c", a + 1, b + 1, 10, 10);
    R("#8d8478", a + 2, b + 1, 8, 10); R("#8d8478", a + 1, b + 2, 10, 8);
    R("#6f675c", a + 3, b + 3, 6, 1); R("#6f675c", a + 3, b + 6, 6, 1); R("#6f675c", a + 3, b + 9, 6, 1); R("#a9a093", a + 2, b + 2, 3, 1);
  }, 25 * TILE + 2, 18 * TILE + 2, 12, 12);

  // bomb-site style markings
  const site = (letter: string) => (a: number, b: number) => {
    const cx = a + 24, cy = b + 24;
    for (let t = 0; t < 6.283; t += 0.035) if (Math.floor(t / 0.3) % 2 === 0) R("rgba(255,255,255,0.55)", (cx + Math.cos(t) * 23) | 0, (cy + Math.sin(t) * 23) | 0, 2, 2);
    for (let i = -18; i <= 18; i += 4) { R("rgba(245,197,66,0.5)", cx + i, cy + 17, 2, 2); R("rgba(245,197,66,0.5)", cx + i, cy - 19, 2, 2); }
    x.fillStyle = "rgba(255,255,255,0.6)";
    glyphs(x, letter, cx - 6, cy - 10, 4);
  };
  site("A")(26.5 * TILE, 2 * TILE + 2);
  site("B")(W - 26.5 * TILE - 48, H - 2 * TILE - 50);

  // spawn mats
  const zone = (x0: number, col: string, line: string, label: string) => {
    R(col, x0 * TILE, 14 * TILE, 6 * TILE, 10 * TILE);
    for (let i = 0; i < 6 * TILE; i += 8) { R(line, x0 * TILE + i, 14 * TILE, 4, 2); R(line, x0 * TILE + i, 24 * TILE - 2, 4, 2); }
    for (let i = 0; i < 10 * TILE; i += 8) { R(line, x0 * TILE, 14 * TILE + i, 2, 4); R(line, (x0 + 6) * TILE - 2, 14 * TILE + i, 2, 4); }
    x.fillStyle = line;
    glyphs(x, label, (x0 + 3) * TILE - label.length * 4 + 1, 14 * TILE + 6, 2);
    // chevrons pointing to the fight
    const dir = x0 < 10 ? 1 : -1, cx = (x0 + 3) * TILE;
    for (let k = 0; k < 3; k++) for (let i = 0; i < 6; i++) { R(line, cx + dir * (k * 8 - 8 - i) + (dir < 0 ? -2 : 0), 19 * TILE - 6 + i, 2, 1); R(line, cx + dir * (k * 8 - 8 - i) + (dir < 0 ? -2 : 0), 19 * TILE + 5 - i, 2, 1); }
  };
  zone(2, "rgba(245,197,66,0.14)", "rgba(245,197,66,0.7)", "GOLD");
  zone(MW - 8, "rgba(255,77,94,0.14)", "rgba(255,77,94,0.7)", "CRIMSON");

  // palm canopy shadows
  for (const p of PALMS) {
    for (let j = -9; j <= 9; j++) {
      const w = Math.round(Math.sqrt(1 - (j * j) / 90) * 17);
      R("rgba(70,40,25,0.18)", p.x + 9 - w, p.y + 12 + j, w * 2, 1);
    }
  }
  // directional contact shadows (sun from top-left)
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      if (kindAt(tx, ty)) continue;
      const px = tx * TILE, py = ty * TILE;
      const up = tall(tx, ty - 1), left = tall(tx - 1, ty);
      if (up) { R("rgba(70,38,22,0.34)", px, py, TILE, 4); R("rgba(70,38,22,0.16)", px, py + 4, TILE, 3); }
      else if (kindAt(tx, ty - 1) === 3) R("rgba(70,38,22,0.28)", px, py, TILE, 2);
      if (left) { R("rgba(70,38,22,0.24)", px, py + (up ? 7 : 0), 3, TILE - (up ? 7 : 0)); R("rgba(70,38,22,0.12)", px + 3, py + (up ? 7 : 0), 2, TILE - (up ? 7 : 0)); }
      if (!up && !left && tall(tx - 1, ty - 1)) { R("rgba(70,38,22,0.24)", px, py, 3, 4); R("rgba(70,38,22,0.12)", px, py + 4, 3, 3); R("rgba(70,38,22,0.12)", px + 3, py, 2, 4); }
    }
  return c;
}

const STY = [
  { top: "#b9583d", hi: "#e08462", lo: "#873827", a: "#cc6a4c", b: "#a04630", front: "#d6b47e", fdark: "#9c7b4e", fline: "#bf9c66" }, // terracotta roof
  { top: "#73839b", hi: "#a3b4ca", lo: "#4f5d77", a: "#8191a9", b: "#66758d", front: "#8f8a7c", fdark: "#5f5a4e", fline: "#7b766b" }, // slate concrete
  { top: "#8b6b58", hi: "#b8967e", lo: "#644a3d", a: "#9a7965", b: "#7d5f4e", front: "#4f3b33", fdark: "#2b1f1c", fline: "#3c2c27" }, // dark brick rampart
  { top: "#ddd5c1", hi: "#f8f3e4", lo: "#a59d88", a: "#e8e1cf", b: "#cbc3ad", front: "#c4b290", fdark: "#8d7d5a", fline: "#ad9c79" }, // whitewash
];

export function buildWalls(): Cv {
  const [c, x] = mk(MW * TILE, MH * TILE + RAISE);
  const R = (col: string, a: number, b: number, w: number, h: number) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      const k = kindAt(tx, ty);
      if (!k) continue;
      const px = tx * TILE, py = ty * TILE, fy = py + TILE;
      if (k === 1) {
        const st = styleAt(tx, ty), s = STY[st];
        R(s.top, px, py, TILE, TILE);
        if (st === 0) {
          for (let j = 0; j < 4; j++) {
            R(s.b, px, py + j * 4 + 3, TILE, 1);
            for (let i = 0; i < 4; i++) R(s.b, px + i * 4 + (j % 2 ? 2 : 0), py + j * 4, 1, 3);
            R(s.a, px + ((h2(tx, ty, j) * 13) | 0), py + j * 4 + 1, 2, 1);
          }
        } else {
          for (let i = 0; i < 4; i++) R(i % 2 ? s.a : s.b, px + 2 + ((h2(tx, ty, i) * 11) | 0), py + 2 + ((h2(tx, ty, i + 7) * 11) | 0), 2, 1);
          if (st === 1) { R(s.b, px + 15, py, 1, TILE); R(s.b, px, py + 15, TILE, 1); R(s.lo, px + 2, py + 2, 1, 1); R(s.lo, px + 12, py + 12, 1, 1); }
        }
        const U = kindAt(tx, ty - 1) !== 1, L = kindAt(tx - 1, ty) !== 1, Rt = kindAt(tx + 1, ty) !== 1, Dn = kindAt(tx, ty + 1) !== 1;
        if (U) { R(s.hi, px, py, TILE, 1); R(s.b, px, py + 1, TILE, 1); }
        if (L) { R(s.hi, px, py, 1, TILE); R(s.b, px + 1, py, 1, TILE); }
        if (Rt) { R(s.b, px + 14, py, 1, TILE); R(s.lo, px + 15, py, 1, TILE); }
        if (Dn) { R(s.b, px, py + 14, TILE, 1); R(s.lo, px, py + 15, TILE, 1); }
        // front face
        R(s.front, px, fy, TILE, RAISE);
        R(s.fline, px, fy + 3, TILE, 1);
        R(s.fline, px + (tx % 2 ? 5 : 11), fy + 1, 1, 2);
        R(s.fline, px + (tx % 2 ? 11 : 5), fy + 4, 1, RAISE - 5);
        R(s.fdark, px, fy, TILE, 1);
        R(s.fdark, px, fy + RAISE - 1, TILE, 1);
        if (st !== 2 && kindAt(tx, ty + 1) === 0) {
          const v = h2(tx, ty, 30);
          if (v < 0.3) {
            R(s.fdark, px + 4, fy + 1, 8, 6);
            R("#5fb6cc", px + 5, fy + 2, 6, 4);
            R("#cdf1f6", px + 5, fy + 2, 2, 1); R("#9bdbe8", px + 6, fy + 3, 1, 1);
            R(s.fdark, px + 8, fy + 2, 1, 4);
          } else if (v < 0.4) {
            R(s.fdark, px + 4, fy, 8, RAISE);
            R("#7a4c2a", px + 5, fy + 1, 6, RAISE - 1);
            R("#95633a", px + 5, fy + 1, 2, RAISE - 1);
            R("#f5c542", px + 9, fy + 4, 1, 1);
          } else if (v < 0.56) {
            for (let i = 0; i < TILE; i += 2) {
              R((i >> 1) % 2 ? "#f3ead8" : v < 0.48 ? "#d8433b" : "#3f8fb0", px + i, fy, 2, 3);
              if ((i >> 1) % 2 === 0) R(v < 0.48 ? "#a82e2a" : "#2c6a86", px + i, fy + 3, 2, 1);
            }
          }
        }
      } else if (k === 2) {
        const v = h2(tx, ty, 3);
        const P = v > 0.66
          ? { top: "#6f8a4c", edge: "#40552b", hi: "#93b06b", pl: "#627c42", front: "#536b39", dark: "#2f401d" }
          : v > 0.52
            ? { top: "#4d7ea8", edge: "#2d5273", hi: "#7fb0d6", pl: "#44729a", front: "#3b6387", dark: "#1f3a54" }
            : { top: "#c8924f", edge: "#8c5c2c", hi: "#e6b877", pl: "#b07c3f", front: "#9a6630", dark: "#5a3817" };
        R(P.top, px, py, TILE, TILE);
        for (let j = 4; j < 16; j += 4) R(P.pl, px + 2, py + j, 12, 1);
        R(P.edge, px, py, TILE, 2); R(P.edge, px, py + 14, TILE, 2); R(P.edge, px, py, 2, TILE); R(P.edge, px + 14, py, 2, TILE);
        R(P.hi, px + 1, py + 1, 14, 1); R(P.hi, px + 1, py + 1, 1, 14);
        if (v <= 0.52) {
          for (let i = 3; i < 13; i++) { R(P.edge, px + i, py + i, 2, 1); R(P.edge, px + 14 - i, py + i, 2, 1); }
        } else if (v > 0.66) {
          R("#e8d36a", px + 7, py + 5, 2, 6); R("#e8d36a", px + 5, py + 7, 6, 2);
        } else {
          R(P.hi, px + 4, py + 4, 8, 8); R(P.top, px + 5, py + 5, 6, 6);
        }
        // metal corners
        for (const [cx, cy] of [[0, 0], [13, 0], [0, 13], [13, 13]]) { R("#5b6170", px + cx, py + cy, 3, 3); R("#aab2c2", px + cx + 1, py + cy + 1, 1, 1); }
        R(P.front, px, fy, TILE, RAISE);
        R(P.dark, px, fy, 2, RAISE); R(P.dark, px + 14, fy, 2, RAISE); R(P.dark, px, fy + RAISE - 1, TILE, 1); R(P.dark, px, fy, TILE, 1);
        R(P.dark, px + 7, fy + 1, 1, RAISE - 2);
        if (v > 0.52) { R("#c9c2b4", px + 4, fy + 2, 2, 2); R("#c9c2b4", px + 10, fy + 2, 2, 2); }
      } else if (k === 3) {
        // sandbags – low cover, only lifted 3px
        const oy = py + RAISE - 3;
        R("#6b5a3a", px, oy, TILE, TILE);
        for (let r = 0; r < 2; r++)
          for (let q = -1; q < 2; q++) {
            const sx = Math.max(px, px + q * 8 + (r ? 4 : 0)), ex = Math.min(px + TILE, px + q * 8 + (r ? 4 : 0) + 8);
            if (ex - sx < 2) continue;
            const sy = oy + r * 8;
            R("#cbb684", sx + 1, sy + 1, ex - sx - 1, 6);
            R("#e6d6a8", sx + 1, sy + 1, ex - sx - 2, 2);
            R("#a8945f", sx + 1, sy + 6, ex - sx - 1, 1);
            R("#8a7648", sx + ((ex - sx) >> 1), sy + 3, 1, 2);
          }
        R("#93804f", px, oy + TILE, TILE, 3);
        R("#5a4a2d", px, oy + TILE + 2, TILE, 1);
        R("#5a4a2d", px + 7, oy + TILE, 1, 2);
      } else {
        // stone planter with soil
        R("#b9b3a4", px, py, TILE, TILE);
        R("#dedacd", px, py, TILE, 1); R("#dedacd", px, py, 1, TILE); R("#8a8477", px + 15, py, 1, TILE); R("#8a8477", px, py + 15, TILE, 1);
        R("#8a8477", px + 2, py + 2, 12, 12);
        R("#5c4030", px + 3, py + 3, 10, 10);
        R("#70503c", px + 4, py + 4, 3, 2); R("#70503c", px + 9, py + 9, 3, 2); R("#4f8a3a", px + 4, py + 10, 2, 1); R("#4f8a3a", px + 11, py + 4, 1, 2);
        R("#9a9486", px, fy, TILE, RAISE);
        R("#7b7568", px, fy + 3, TILE, 1); R("#7b7568", px + 8, fy, 1, 3); R("#6a6458", px, fy, TILE, 1); R("#57524a", px, fy + RAISE - 1, TILE, 1);
      }
    }
  for (let i = 0; i < BUILDINGS.length; i++) roofProps(R, BUILDINGS[i], i);
  return c;
}

/** AC units, skylights, vents... scattered over big roofs */
export function roofProps(R: (col: string, a: number, b: number, w: number, h: number) => void, b: Building, seed: number) {
  if (b.w < 2 || b.h < 2) return;
  const X = b.x * TILE, Y = b.y * TILE, W = b.w * TILE, H = b.h * TILE;
  const n = Math.max(1, Math.min(4, Math.round((b.w * b.h) / 5)));
  const slot = (W - 10) / n;
  for (let i = 0; i < n; i++) {
    const ox = Math.round(X + 5 + i * slot + h2(seed, i, 80) * Math.max(0, slot - 14));
    const oy = Math.round(Y + 5 + h2(seed, i, 81) * Math.max(0, H - 22));
    const t = (h2(seed, i, 82) * 5) | 0;
    R("rgba(0,0,0,0.22)", ox + 1, oy + 2, 12, 10);
    if (t === 0) {
      // AC unit
      R("#5d6470", ox, oy, 12, 10); R("#c3cad3", ox + 1, oy + 1, 10, 8); R("#e9eef3", ox + 1, oy + 1, 10, 1);
      R("#4a505c", ox + 2, oy + 3, 5, 5); R("#7d8592", ox + 3, oy + 4, 3, 3); R("#4a505c", ox + 4, oy + 5, 1, 1);
      R("#8d949e", ox + 8, oy + 3, 2, 1); R("#8d949e", ox + 8, oy + 5, 2, 1); R("#8d949e", ox + 8, oy + 7, 2, 1);
    } else if (t === 1) {
      // skylight
      R("#3f4651", ox, oy, 12, 10); R("#6cc4d8", ox + 1, oy + 1, 10, 8); R("#3f4651", ox + 6, oy + 1, 1, 8);
      R("#d9f5f9", ox + 2, oy + 2, 3, 1); R("#d9f5f9", ox + 2, oy + 3, 1, 2); R("#a5e2ee", ox + 8, oy + 5, 2, 1);
    } else if (t === 2) {
      // solar panel
      R("#1c2c55", ox, oy, 12, 10); R("#2f4d99", ox + 1, oy + 1, 10, 8);
      R("#5f84d4", ox + 1, oy + 4, 10, 1); R("#5f84d4", ox + 4, oy + 1, 1, 8); R("#5f84d4", ox + 8, oy + 1, 1, 8); R("#9cb8ef", ox + 1, oy + 1, 3, 1);
    } else if (t === 3) {
      // water tank
      R("#3b536e", ox + 2, oy, 8, 10); R("#3b536e", ox, oy + 2, 12, 6); R("#3b536e", ox + 1, oy + 1, 10, 8);
      R("#6c93b8", ox + 2, oy + 1, 8, 8); R("#6c93b8", ox + 1, oy + 2, 10, 6); R("#a5c6e2", ox + 3, oy + 2, 3, 2); R("#4d7193", ox + 5, oy + 5, 3, 3);
    } else {
      // vents
      R("#5d6470", ox, oy + 1, 5, 5); R("#aab2bd", ox + 1, oy + 2, 3, 3); R("#2c3038", ox + 2, oy + 3, 1, 1);
      R("#5d6470", ox + 7, oy + 4, 5, 5); R("#aab2bd", ox + 8, oy + 5, 3, 3); R("#2c3038", ox + 9, oy + 6, 1, 1);
    }
  }
}

export function buildPalm(ph: number): Cv {
  const [c, x] = mk(44, 44);
  const R = (col: string, a: number, b: number, w: number, h: number) => {
    x.fillStyle = col;
    x.fillRect(a, b, w, h);
  };
  let tx = 22;
  for (let i = 0; i <= 22; i++) {
    const t = i / 22;
    tx = 22 + Math.round(Math.sin(t * 1.5) * 3 + Math.sin(ph) * t * 1.3);
    R("#2e1f16", tx - 2, 42 - i, 5, 1);
    R(i % 3 === 0 ? "#6a4d33" : "#93714c", tx - 1, 42 - i, 3, 1);
    R("#b8946a", tx - 1, 42 - i, 1, 1);
  }
  const cx = tx, cy = 19;
  const fr = [-2.85, -2.2, -1.57, -0.95, -0.3, 0.35, 2.8];
  const pts: number[][][] = fr.map((a, n) => {
    const len = 15 + (n % 2) * 3, out: number[][] = [];
    for (let i = 2; i <= len; i++) out.push([Math.round(cx + Math.cos(a) * i + Math.sin(ph + n) * i * 0.07), Math.round(cy + Math.sin(a) * i * 0.55 + i * i * 0.028), i / len]);
    return out;
  });
  for (const f of pts) for (const p of f) R("#1f4220", p[0] - 1, p[1] - 1, 4, 3);
  for (const f of pts) for (const p of f) {
    R(p[2] > 0.8 ? "#8fd062" : "#479436", p[0], p[1] - 1, 2, 2);
    R(p[2] > 0.5 ? "#a8e07a" : "#63b548", p[0], p[1] - 1, 1, 1);
  }
  R("#3d2718", cx - 3, cy, 3, 3); R("#6b4a2e", cx - 2, cy, 1, 1);
  R("#3d2718", cx + 1, cy + 1, 3, 3); R("#6b4a2e", cx + 2, cy + 1, 1, 1);
  return c;
}

export function buildMini(theme = 0): Cv {
  const [c, x] = mk(MW, MH);
  const COL = theme === 0
    ? ["rgba(52,44,48,0.9)", "#9a7965", "#c8924f", "#cbb684", "#5d9a3c"]
    : ["rgba(34,36,44,0.9)", "#7d8494", "#c8643a", "#f5c542", "#ffe9a0"];
  for (let ty = 0; ty < MH; ty++)
    for (let tx = 0; tx < MW; tx++) {
      // house interiors show as warm floor: furniture stays a surprise
      const k = kindAt(tx, ty), home = houseAt(tx, ty) >= 0;
      x.fillStyle = home && k !== 1 ? "rgba(86,66,44,0.95)" : home ? "#a39a8a" : k === 1 && styleAt(tx, ty) === 9 ? "#07050c" : COL[k];
      x.fillRect(tx, ty, 1, 1);
    }
  return c;
}

export interface Sprites {
  head: Cv[][];
  headW: Cv[][];
  torso: Cv[][];
  torsoW: Cv[][];
  weapon: Record<WeaponId, Cv>[];
  barrel: Cv;
  barrelWhite: Cv;
  heart: Cv;
}

/* ───────────── survivors (zombie mode): civilians with caps, hoodies and backpacks ───────────── */
const S_HEADS: string[][] = [
  // JAKA – red baseball cap, stubble
  [
    "....KKKKKK....", "..KKCCCCCCKK..", ".KCCcCCCCCCCK.", ".KCCCCCCCCCCK.", "KKCCCCCCCCCCKK",
    "KHFFFFFFFFFFHK", "KFFWEFFFWEFFfK", "KFFFFFFFFFFFfK", ".KfMMMMMMMMfK.", "..KKKKKKKKKK..",
  ],
  // SARI – long brown hair, yellow headband
  [
    "....KKKKKK....", "..KKHHHHHHKK..", ".KHHhhHHHHHHK.", ".KHHHHHHHHHHK.", "KHHCCCCCCCCHHK",
    "KHFFFFFFFFFFHK", "KHFWEFFFWEFFHK", "KHFFFFFFFFFFHK", "KHKfFFMMFFfKHK", ".KKKKKKKKKKKK.",
  ],
  // BIMO – green beanie, big beard
  [
    "....KKKKKK....", "..KKCCCCCCKK..", ".KCCcCcCcCCCK.", ".KCCCCCCCCCCK.", "KccccccccccccK",
    "KFFFFFFFFFFFfK", "KFFWEFFFWEFFfK", "KMMFFFFFFFFMMK", ".KMMMMMMMMMMK.", "..KKKKKKKKKK..",
  ],
  // NADIA – yellow raincoat hood, face mask
  [
    "....KKKKKK....", "..KKCCCCCCKK..", ".KCCcCCCCCCCK.", ".KCHHHHHHHHCK.", "KCHHFFFFFFHHCK",
    "KCFFFFFFFFFFCK", "KCFWEFFFWEFFCK", "KCMMMMMMMMMMCK", ".KCMMMMMMMMCK.", "..KKKKKKKKKK..",
  ],
  // BARA – red bandana, sunglasses, moustache
  [
    "....KKKKKK....", "..KKCCCCCCKK..", ".KCCcCCCcCCCK.", ".KCCCCCCCCCCK.", "KFFFFFFFFFFFfK",
    "KFEEEEFFEEEEfK", "KFEWEEFFEWEEfK", "KFFFFFFFFFFFfK", ".KfFMMMMMMFfK.", "..KKKKKKKKKK..",
  ],
];
const S_TORSO: string[][] = [
  ["..KJJTTTTJJK..", ".KJjJTTTTJjJK.", ".KJKJTTTTJKJK.", ".KJKJJTTJJKJK.", "..KKPPPPPPKK..", "...KDPKKPDK..."], // open denim jacket
  ["..KJjJjJjJjK..", ".KjJjJjJjJjJK.", ".KJKJjJjJjKJK.", ".KjKjJjJjJKjK.", "..KKPPPPPPKK..", "...KDPKKPDK..."], // flannel shirt
  ["..KJJJTTJJJK..", ".KJjJJWJWJjJK.", ".KJKJJJJJJKJK.", ".KJKJjjjjJKJK.", "..KKPPPPPPKK..", "...KDPKKPDK..."], // hoodie
  ["..KJJJJWJJJK..", ".KJjJJJWJJjJK.", ".KJKJJJWJJKJK.", ".KJKJJJWJJKJK.", "..KKPPPPPPKK..", "...KDPKKPDK..."], // raincoat
  ["..KTJJTTJJTK..", ".KTTJJTTJJTTK.", ".KTKJjTTjJKTK.", ".KTKJJTTJJKTK.", "..KKPPPPPPKK..", "...KDPKKPDK..."], // hunting vest
];
const S_PAL: Pal[] = [
  { K: "#0d0a0c", F: "#e0ac7e", f: "#b98458", E: "#1a1014", W: "#ffffff", H: "#3a2618", h: "#5a3e28", C: "#c0392b", c: "#e8604c", M: "#9a7458", J: "#3f6ea8", j: "#6a98cf", T: "#e6e0d0", P: "#4a3424", D: "#2f3f5e" },
  { K: "#0d0a0c", F: "#f0c8a0", f: "#c89a70", E: "#1a1014", W: "#ffffff", H: "#6a3a1c", h: "#96592e", C: "#f5c542", c: "#ffe58a", M: "#b8604a", J: "#b03a3a", j: "#7a1f24", T: "#e6e0d0", P: "#3a3a48", D: "#3a4a66" },
  { K: "#0d0a0c", F: "#c98e62", f: "#9a6a44", E: "#1a1014", W: "#ffffff", H: "#2a1c14", h: "#4a3424", C: "#3f7a4a", c: "#5a9a66", M: "#4a3020", J: "#56606e", j: "#6e7a8a", T: "#2a2c34", P: "#3a3a3a", D: "#3b3b44" },
  { K: "#0d0a0c", F: "#e8b88f", f: "#c08a60", E: "#1a1014", W: "#ffffff", H: "#1c1c24", h: "#3a3a48", C: "#d8b02a", c: "#f5d85a", M: "#8fd0e0", J: "#d8b02a", j: "#f5d85a", T: "#e6e0d0", P: "#4a4a55", D: "#2c3350" },
  { K: "#0d0a0c", F: "#b9805a", f: "#8f5c3c", E: "#15151c", W: "#8fa8c8", H: "#2a1c14", h: "#4a3424", C: "#a8202c", c: "#d04a4a", M: "#2a1c14", J: "#5a4a2a", j: "#7a6a40", T: "#8a8a80", P: "#2a2a2a", D: "#4a4a3a" },
];
/** [backpack colour, scarf colour, scarf shade] per survivor */
const S_GEAR = [["#7a5a34", "", ""], ["#3f8a5a", "", ""], ["#a85a2a", "", ""], ["#3b6ea8", "", ""], ["", "#a8202c", "#6e1420"]];

/** per look (0 gold squad, 1 crimson squad, 2 survivors) and skin: K outline, D legs, B sleeves, A/a scarf, F hands, P backpack */
export const LOOK_PAL: Pal[][] = [];

let cache: Sprites | null = null;
export function initSprites(): Sprites {
  if (cache) return cache;
  const head: Cv[][] = [], headW: Cv[][] = [], torso: Cv[][] = [], torsoW: Cv[][] = [], weapon: Record<WeaponId, Cv>[] = [];
  for (let t = 0; t < 3; t++) {
    if (t < 2) {
      const tp = TEAM_PAL[t], body = fromMap(TORSO, tp);
      head.push(HEADS.map((h) => fromMap(h, tp)));
      torso.push(HEADS.map(() => body));
      LOOK_PAL.push(HEADS.map(() => ({ K: tp.K, D: tp.D, B: tp.B, A: tp.A, a: tp.a, F: t === 0 ? "#e2cfa6" : "#f0c9b4", P: "" })));
    } else {
      head.push(S_HEADS.map((h, i) => fromMap(h, S_PAL[i])));
      torso.push(S_TORSO.map((b, i) => fromMap(b, S_PAL[i])));
      LOOK_PAL.push(S_PAL.map((sp, i) => ({ K: sp.K, D: sp.D, B: sp.J, A: S_GEAR[i][1], a: S_GEAR[i][2], F: sp.F, P: S_GEAR[i][0] })));
    }
    headW.push(head[t].map(whiten));
    torsoW.push(torso[t].map(whiten));
    const w = {} as Record<WeaponId, Cv>;
    for (const id of WEAPON_ORDER) w[id] = fromMap(WEAPON_MAPS[id], WEAPON_PAL(t));
    weapon.push(w);
  }
  const barrel = fromMap(BARREL, { K: "#1a0a0c", R: "#d8433b", r: "#f47c72", D: "#9c2a2a", Y: "#f5c542" });
  cache = {
    head, headW, torso, torsoW, weapon, barrel,
    barrelWhite: whiten(barrel),
    heart: fromMap(HEART, { K: "#3a0a1c", P: "#ff5d8f", W: "#ffffff" }),
  };
  return cache;
}

const urlCache: Record<string, string> = {};
/** data-URL of a weapon sprite (26x10), for DOM HUD */
export function weaponIcon(id: WeaponId, team = 0): string {
  const key = `w${id}${team}`;
  if (!urlCache[key]) {
    const src = initSprites().weapon[team][id];
    const [c, x] = mk(26, 10);
    x.drawImage(src, Math.floor((26 - src.width) / 2), Math.floor((10 - src.height) / 2));
    urlCache[key] = c.toDataURL();
  }
  return urlCache[key];
}

/** data-URL of a full character (16x22), for menus. look: 0 gold squad, 1 crimson squad, 2 survivors */
export function portrait(skin: number, look = 0): string {
  const key = `p${skin}${look}`;
  if (!urlCache[key]) {
    const sp = initSprites(), pal = LOOK_PAL[look][skin];
    const [c, x] = mk(16, 22);
    x.fillStyle = "rgba(0,0,0,0.35)";
    x.fillRect(3, 19, 10, 2);
    if (pal.P) {
      x.fillStyle = pal.K;
      x.fillRect(0, 10, 4, 8);
      x.fillStyle = pal.P;
      x.fillRect(0, 11, 3, 6);
    }
    if (pal.A) {
      x.fillStyle = pal.A;
      x.fillRect(1, 11, 2, 2);
      x.fillStyle = pal.a;
      x.fillRect(0, 13, 2, 3);
    }
    x.fillStyle = pal.D;
    x.fillRect(5, 17, 2, 3);
    x.fillRect(9, 17, 2, 3);
    x.drawImage(sp.torso[look][skin], 1, 11);
    x.drawImage(sp.head[look][skin], 1, 1);
    urlCache[key] = c.toDataURL();
  }
  return urlCache[key];
}

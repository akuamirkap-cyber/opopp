import { useEffect, useMemo, useRef, useState } from "react";
import "@fontsource/press-start-2p/400.css";
import { Hud } from "./components/Hud";
import { Menu } from "./components/Menu";
import { Pause, Results, TouchControls } from "./components/Overlays";
import { audio } from "./game/audio";
import type { DiffId, GameMode, WeatherId } from "./game/defs";
import { Game } from "./game/engine";
import { HOUSES } from "./game/map";
import type { HudState, MatchResult } from "./game/engine";

type Screen = "menu" | "game" | "result";

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [screen, setScreen] = useState<Screen>("menu");
  const [hud, setHud] = useState<HudState | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [skin, setSkin] = useState(2);
  const [diff, setDiff] = useState<DiffId>("normal");
  const [mode, setMode] = useState<GameMode>("pvp");
  const [weather, setWeather] = useState<WeatherId>("auto");
  const coarse = useMemo(() => typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches, []);

  useEffect(() => {
    const g = new Game(canvasRef.current!, {
      onHud: setHud,
      onMatchEnd: (r) => {
        setResult(r);
        setScreen("result");
      },
    });
    g.startDemo();
    setGame(g);
    // debug handle for testing from the console
    (window as unknown as { __chibi?: Game; __chibiHouses?: () => unknown }).__chibi = g;
    (window as unknown as { __chibiHouses?: () => unknown }).__chibiHouses = () => HOUSES;
    return () => g.destroy();
  }, []);

  const click = () => {
    audio.unlock();
    audio.play("click");
  };
  const play = () => {
    click();
    setResult(null);
    setScreen("game");
    game?.startMatch(skin, diff, mode, weather);
  };
  const toMenu = () => {
    click();
    setResult(null);
    setScreen("menu");
    game?.startDemo();
  };

  const inPlay = screen === "game" && hud?.mode === "play";
  const showTouch = inPlay && (coarse || hud.touch) && !hud.paused;

  return (
    <div className={`fixed inset-0 select-none overflow-hidden bg-[#0b0910] ${inPlay && !hud.paused && !showTouch ? "cursor-none" : ""}`}>
      <div className="absolute inset-0 flex items-center justify-center overflow-hidden">
        <canvas ref={canvasRef} className="game" />
      </div>

      {inPlay && game && showTouch && <TouchControls game={game} />}
      {inPlay && game && (
        <Hud hud={hud} onSelect={(i) => game.selectWeapon(i)} onPause={() => game.togglePause()} onMute={() => game.toggleMute()} onStrat={(n) => game.action(n === 0 ? "strat1" : "strat2")} />
      )}
      {inPlay && game && hud.paused && (
        <Pause muted={hud.muted} onResume={() => { click(); game.togglePause(false); }} onMute={() => game.toggleMute()} onQuit={toMenu} />
      )}

      {screen === "menu" && (
        <Menu
          skin={skin}
          setSkin={(s) => { click(); setSkin(s); }}
          diff={diff}
          setDiff={(d) => { click(); setDiff(d); }}
          mode={mode}
          setMode={(m) => { click(); setMode(m); }}
          weather={weather}
          setWeather={(w) => { click(); setWeather(w); }}
          onPlay={play}
        />
      )}
      {screen === "result" && result && <Results result={result} onAgain={play} onMenu={toMenu} />}
    </div>
  );
}

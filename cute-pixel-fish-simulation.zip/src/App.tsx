import { useCallback, useEffect, useRef, useState } from 'react';
import { Aquarium, MAX_FISH } from './sim/engine';
import { VARIETIES, drawFish } from './sim/fish';
import { THEMES } from './sim/scene';
import { pack } from './sim/palette';

/** Ikon ikan mungil yang dirender langsung dari sprite aslinya */
function FishIcon({ vi }: { vi: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current;
    const ctx = c?.getContext('2d');
    if (!c || !ctx) return;
    const S = 24;
    const buf = new Uint32Array(S * S).fill(pack(98, 204, 224));
    for (let y = 0; y < S; y++) {
      for (let x = 0; x < S; x++) if (y > 13 + ((x + y) & 1)) buf[y * S + x] = pack(74, 168, 220);
    }
    drawFish(buf, S, S, {
      x: 14,
      y: 12,
      unit: 6.2,
      facing: 1,
      pitch: 0,
      wave: 1.2,
      swim: 0.5,
      seed: 11,
      variety: VARIETIES[vi],
      eye: 'open',
      mouthOpen: false,
      tint: [0, 0, 0],
      tintAmt: 0,
    });
    ctx.putImageData(new ImageData(new Uint8ClampedArray(buf.buffer as ArrayBuffer), S, S), 0, 0);
  }, [vi]);
  return <canvas ref={ref} width={24} height={24} className="pixelated block h-10 w-10 sm:h-12 sm:w-12" aria-hidden="true" />;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tagRef = useRef<HTMLDivElement>(null);
  const tagNameRef = useRef<HTMLSpanElement>(null);
  const tagKindRef = useRef<HTMLSpanElement>(null);
  const engineRef = useRef<Aquarium | null>(null);
  const scaleRef = useRef(4);
  const pausedRef = useRef(false);

  const [count, setCount] = useState(0);
  const [theme, setTheme] = useState(0);
  const [paused, setPaused] = useState(false);
  const [hint, setHint] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const aq = new Aquarium();
    engineRef.current = aq;
    let img: ImageData | null = null;

    const fit = () => {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const scale = Math.max(2, Math.min(8, Math.round(Math.min(vw, vh) / 210)));
      const W = Math.ceil(vw / scale);
      const H = Math.ceil(vh / scale);
      scaleRef.current = scale;
      canvas.width = W;
      canvas.height = H;
      canvas.style.width = `${W * scale}px`;
      canvas.style.height = `${H * scale}px`;
      aq.resize(W, H);
      img = new ImageData(new Uint8ClampedArray(aq.buf.buffer as ArrayBuffer), W, H);
      setCount(aq.fish.length);
    };
    fit();

    let resizeT = 0;
    const onResize = () => {
      window.clearTimeout(resizeT);
      resizeT = window.setTimeout(fit, 120);
    };
    window.addEventListener('resize', onResize);

    let raf = 0;
    let last = performance.now();
    let tagKey = '';
    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!pausedRef.current) aq.step(dt);
      aq.render();
      if (img) ctx.putImageData(img, 0, 0);

      const tag = tagRef.current;
      if (tag) {
        const lb = aq.label();
        if (lb) {
          const s = scaleRef.current;
          const x = Math.max(60, Math.min(window.innerWidth - 60, lb.x * s));
          const y = Math.max(96, lb.y * s);
          tag.style.opacity = '1';
          tag.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px) translate(-50%, -100%)`;
          const key = `${lb.name}|${lb.variety}`;
          if (key !== tagKey) {
            tagKey = key;
            if (tagNameRef.current) tagNameRef.current.textContent = lb.name;
            if (tagKindRef.current) tagKindRef.current.textContent = lb.variety;
          }
        } else tag.style.opacity = '0';
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(resizeT);
      window.removeEventListener('resize', onResize);
    };
  }, []);

  const onTap = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const aq = engineRef.current;
    if (!aq) return;
    const r = e.currentTarget.getBoundingClientRect();
    aq.tap((e.clientX - r.left) / scaleRef.current, (e.clientY - r.top) / scaleRef.current);
    setHint(false);
  }, []);

  const addFish = (vi: number) => {
    const aq = engineRef.current;
    if (aq?.addFish(vi)) setCount(aq.fish.length);
  };
  const removeFish = () => {
    const aq = engineRef.current;
    if (aq?.removeFish()) setCount(aq.fish.length);
  };
  const feed = () => {
    engineRef.current?.feed();
    setHint(false);
  };
  const nextTheme = () => {
    const n = (theme + 1) % THEMES.length;
    engineRef.current?.setTheme(n);
    setTheme(n);
  };
  const togglePause = () => {
    pausedRef.current = !pausedRef.current;
    setPaused(pausedRef.current);
  };

  const th = THEMES[theme];
  const full = count >= MAX_FISH;

  return (
    <main className="fixed inset-0 overflow-hidden bg-[#3b4592] font-pixel text-ink select-none">
      <h1 className="sr-only">Akuarium piksel ikan demekin</h1>
      <canvas
        ref={canvasRef}
        onPointerDown={onTap}
        role="img"
        aria-label="Akuarium piksel berisi ikan mas koki demekin yang berenang. Ketuk air untuk memberi makan, ketuk ikan untuk mengelus."
        className="pixelated absolute left-0 top-0 block cursor-pointer touch-none"
      />

      {/* label nama ikan */}
      <div ref={tagRef} className="px-panel pointer-events-none absolute left-0 top-0 px-2 py-1 text-center opacity-0 transition-opacity duration-200" aria-hidden="true">
        <span ref={tagNameRef} className="block text-base font-bold leading-none" />
        <span ref={tagKindRef} className="mt-0.5 block text-xs leading-none text-rose" />
      </div>

      {/* kiri atas: judul */}
      <div className="px-panel pointer-events-none absolute left-3 top-3 px-3 py-2 sm:left-4 sm:top-4">
        <p className="font-arcade text-[11px] leading-none tracking-tight sm:text-sm">
          DEMEKIN<span className="text-coral"> ♥</span>
        </p>
        <p className="mt-1.5 text-xs leading-none text-plum sm:text-sm">akuarium piksel mungil</p>
      </div>

      {/* kanan atas: tema + jeda */}
      <div className="absolute right-3 top-3 flex gap-2.5 sm:right-4 sm:top-4">
        <button type="button" onClick={nextTheme} className="px-btn flex items-center gap-2 px-2.5 py-2 text-sm font-semibold" aria-label={`Ganti suasana. Sekarang: ${th.name}`}>
          <span className="flex h-4 w-4 flex-col overflow-hidden outline outline-2 outline-ink" aria-hidden="true">
            {th.swatch.map((c) => (
              <span key={c} className="flex-1" style={{ background: c }} />
            ))}
          </span>
          {th.name}
        </button>
        <button type="button" onClick={togglePause} className="px-btn w-10 py-2 font-arcade text-[10px]" aria-label={paused ? 'Lanjutkan simulasi' : 'Jeda simulasi'} aria-pressed={paused}>
          {paused ? '▶' : 'II'}
        </button>
      </div>

      {/* petunjuk */}
      {hint && (
        <p className="hint-float px-panel pointer-events-none absolute left-1/2 top-[76px] w-max max-w-[88vw] px-3 py-1.5 text-center text-sm sm:top-20 sm:text-base">
          Ketuk air untuk kasih makan · ketuk ikan untuk mengelus <span className="text-coral">♥</span>
        </p>
      )}

      {/* dok bawah */}
      <div className="absolute inset-x-0 bottom-3 flex justify-center px-3 sm:bottom-4">
        <div className="px-panel flex max-w-full flex-wrap items-center justify-center gap-x-4 gap-y-2.5 px-3 py-2.5">
          <div>
            <p className="mb-1.5 text-xs font-semibold leading-none text-plum">Tambah ikan</p>
            <div className="flex gap-2">
              {VARIETIES.map((v, i) => (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => addFish(i)}
                  disabled={full}
                  title={v.name}
                  aria-label={`Tambah ikan ${v.name}`}
                  className="px-swatch"
                >
                  <FishIcon vi={i} />
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button type="button" onClick={feed} className="px-btn px-btn-pink px-3 py-2.5 text-base font-bold leading-none">
              Beri makan
            </button>
            <div className="flex items-center gap-2.5">
              <button type="button" onClick={removeFish} disabled={count === 0} className="px-btn h-9 w-9 text-xl font-bold leading-none" aria-label="Lepas satu ikan">
                −
              </button>
              <p className="min-w-[3.2rem] text-center leading-none" aria-live="polite">
                <span className="block text-lg font-bold leading-none tabular-nums">
                  {count}
                  <span className="text-plum">/{MAX_FISH}</span>
                </span>
                <span className="mt-0.5 block text-xs leading-none text-plum">ikan</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

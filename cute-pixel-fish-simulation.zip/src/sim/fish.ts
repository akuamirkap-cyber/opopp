// Renderer ikan mas koki (demekin/ryukin) prosedural bergaya pixel-art.
// Bentuk didefinisikan dalam koordinat lokal (u, v): ikan menghadap kanan (+u),
// v ke bawah, 1 unit ≈ setengah tinggi badan. Tiap piksel di-sample lalu
// diwarnai dengan ramp warna + ordered dithering supaya gradasinya khas piksel.

import { RGB, TAU, blend, clamp, dither, hash, hex, ramp, sstep, vnoise } from './palette';

export type Pattern = 'sarasa' | 'full' | 'calico' | 'patch' | 'cap';

export interface Variety {
  id: string;
  name: string;
  pattern: Pattern;
  base: RGB[]; // 5 tone terang→gelap (perut)
  patch: RGB[]; // 5 tone (corak)
  head: RGB[]; // 5 tone
  fin: RGB[]; // 4 tone: pangkal → tepi
  finShade: RGB;
  finLine: RGB;
  ring: RGB;
  pupil: RGB;
  blush: RGB;
  mouth: RGB;
  speck?: RGB;
  swatch: [string, string];
}

const WHITE_BODY = ['#ffffff', '#fff0e8', '#f9d3cf', '#dba9bb', '#a7859f'] as const;
const RED_PATCH = ['#ffa068', '#ff623f', '#ee3530', '#c41f3c', '#861641'] as const;

export const VARIETIES: Variety[] = [
  {
    id: 'sarasa',
    name: 'Sarasa',
    pattern: 'sarasa',
    base: ramp(...WHITE_BODY),
    patch: ramp(...RED_PATCH),
    head: ramp('#fffbe2', '#ffeab8', '#fbc894', '#e79c80', '#b3716f'),
    fin: ramp('#ffc4be', '#ffe2da', '#fff4ee', '#ffffff'),
    finShade: hex('#c7a6d6'),
    finLine: hex('#b582b4'),
    ring: hex('#fff3d6'),
    pupil: hex('#1d1230'),
    blush: hex('#ff8098'),
    mouth: hex('#c9485a'),
    swatch: ['#ff5d3d', '#fff0e8'],
  },
  {
    id: 'sakura',
    name: 'Sakura',
    pattern: 'patch',
    base: ramp('#ffffff', '#fff1f1', '#fbd5dc', '#e0aac6', '#aa86a8'),
    patch: ramp('#ffd3de', '#ffa5bf', '#f7789f', '#d2568c', '#963c7a'),
    head: ramp('#fff8f0', '#ffe3d8', '#f9c2c2', '#de97ad', '#a86c92'),
    fin: ramp('#ffbdd2', '#ffdae6', '#fff0f5', '#ffffff'),
    finShade: hex('#cfa2d4'),
    finLine: hex('#c07ab0'),
    ring: hex('#fff6ee'),
    pupil: hex('#2a1436'),
    blush: hex('#ff7aa2'),
    mouth: hex('#d0507c'),
    swatch: ['#ff8fb3', '#fff1f1'],
  },
  {
    id: 'emas',
    name: 'Emas',
    pattern: 'full',
    base: ramp('#fff8cc', '#ffe38e', '#ffc463', '#f09c4e', '#b8684a'),
    patch: ramp('#ffdc72', '#ffae40', '#ff8232', '#e3562f', '#a0343f'),
    head: ramp('#ffe890', '#ffc256', '#ff9642', '#e56b38', '#a34340'),
    fin: ramp('#ff9a52', '#ffc27c', '#ffe4b0', '#fff8e0'),
    finShade: hex('#e0806a'),
    finLine: hex('#c05a4a'),
    ring: hex('#fff6d0'),
    pupil: hex('#24122a'),
    blush: hex('#ff6a70'),
    mouth: hex('#b8403c'),
    swatch: ['#ffd76a', '#ff7a30'],
  },
  {
    id: 'calico',
    name: 'Calico',
    pattern: 'calico',
    base: ramp('#ffffff', '#e6f3ff', '#bfd6f7', '#96abde', '#6d7bb5'),
    patch: ramp('#ffc47c', '#ff9852', '#f2703e', '#c94c44', '#8c3350'),
    head: ramp('#fff9ea', '#ffe5c2', '#f7c29e', '#dc9792', '#a56c84'),
    fin: ramp('#c4d8ff', '#e0ebff', '#f4f9ff', '#ffffff'),
    finShade: hex('#8f9ed6'),
    finLine: hex('#7a82c0'),
    ring: hex('#f4fbff'),
    pupil: hex('#1a1634'),
    blush: hex('#ff8fa3'),
    mouth: hex('#b85a6a'),
    speck: hex('#2c2440'),
    swatch: ['#bfd6f7', '#ff9852'],
  },
  {
    id: 'kuro',
    name: 'Kuro',
    pattern: 'full',
    base: ramp('#c9a890', '#94788a', '#625072', '#3f3558', '#251e3c'),
    patch: ramp('#8884b8', '#5a5688', '#3c3862', '#282546', '#18162e'),
    head: ramp('#9690c2', '#646092', '#44406a', '#2c294c', '#1b1932'),
    fin: ramp('#36315c', '#4a4578', '#6964a0', '#a09cd6'),
    finShade: hex('#1f1c3a'),
    finLine: hex('#17142c'),
    ring: hex('#ffd76a'),
    pupil: hex('#0d0a18'),
    blush: hex('#ff7a9a'),
    mouth: hex('#c0789a'),
    swatch: ['#5a5688', '#c9a890'],
  },
  {
    id: 'tancho',
    name: 'Tancho',
    pattern: 'cap',
    base: ramp(...WHITE_BODY),
    patch: ramp(...RED_PATCH),
    head: ramp('#ffffff', '#fff3e8', '#f8d8ce', '#dcacb8', '#a8869c'),
    fin: ramp('#ffd2cc', '#ffe8e2', '#fff6f2', '#ffffff'),
    finShade: hex('#c7a6d6'),
    finLine: hex('#b582b4'),
    ring: hex('#fff3d6'),
    pupil: hex('#1d1230'),
    blush: hex('#ff8098'),
    mouth: hex('#c9485a'),
    swatch: ['#ffffff', '#ee3530'],
  },
  {
    id: 'lila',
    name: 'Lila',
    pattern: 'sarasa',
    base: ramp('#ffffff', '#f4efff', '#dbd1f8', '#b5a5e2', '#8676ba'),
    patch: ramp('#dcc0ff', '#b890ff', '#9069ee', '#6a4cc8', '#46348f'),
    head: ramp('#fff8fc', '#fbe2f3', '#e9c1e7', '#c49ad3', '#8f6fae'),
    fin: ramp('#d4bcff', '#e8daff', '#f6efff', '#ffffff'),
    finShade: hex('#9d8fdc'),
    finLine: hex('#8672c8'),
    ring: hex('#fff6ff'),
    pupil: hex('#1c1238'),
    blush: hex('#ff94c6'),
    mouth: hex('#a8589c'),
    swatch: ['#b890ff', '#f4efff'],
  },
];

export type EyeState = 'open' | 'blink' | 'happy';

export interface FishPose {
  x: number; // pusat ikan di layar (bilangan bulat)
  y: number;
  unit: number; // piksel per unit lokal
  facing: number; // -1..1 (tanda = arah, besaran = fase berbalik)
  pitch: number; // + = moncong turun
  wave: number; // fase kibasan sirip
  swim: number; // 0..1.3 kekuatan kibasan
  seed: number;
  variety: Variety;
  eye: EyeState;
  mouthOpen: boolean;
  tint: RGB;
  tintAmt: number;
}

// ---------- buffer sprite sementara ----------
const SPR = 151;
const sR = new Uint8ClampedArray(SPR * SPR);
const sG = new Uint8ClampedArray(SPR * SPR);
const sB = new Uint8ClampedArray(SPR * SPR);
const sA = new Float32Array(SPR * SPR);
const sK = new Uint8Array(SPR * SPR); // 0 kosong, 1 sirip (tembus), 2 badan (solid)

// keluaran sample()
let oR = 0;
let oG = 0;
let oB = 0;
let oA = 0;
let oK = 0;

// parameter pose aktif
let qV: Variety = VARIETIES[0];
let qSeed = 0;
let qLx = 1;
let qWave = 0;
let qTail = 0.16;
let qDors = 0.05;
let qFlap = 0;
let qPx = 0.07;

const win = (x: number, lo: number, hi: number, s: number) => sstep(lo, lo + s, x) * (1 - sstep(hi - s, hi, x));
const gauss = (x: number, s: number) => Math.exp(-(x * x) / (s * s));

/** Ekor bercagak dua cuping lebar (0 = lurus ke belakang, + = ke bawah) */
function tailR(th: number): number {
  const w = win(th, -1.34, 1.3, 0.2);
  if (w <= 0) return 0;
  return (
    (0.56 + 0.44 * gauss(th + 0.9, 0.42) + 0.38 * gauss(th - 0.84, 0.42) - 0.07 * gauss(th - 0.12, 0.22) + 0.012 * Math.sin(th * 30)) *
    Math.sqrt(w)
  );
}

// Sirip punggung "layar": tabel (sudut, jarak dari pusat badan). 0 = ke atas, + = ke belakang.
// Tinggi di depan (di atas puncak punuk), lalu menurun mengikuti punggung sampai pangkal ekor.
const DT = [-0.85, 1.22, -0.42, 1.37, -0.24, 1.37, -0.02, 1.31, 0.2, 1.21, 0.55, 1.1, 1.0, 1.0, 1.25, 0.95];
function dorsalR(ph: number): number {
  if (ph < DT[0] || ph > 1.22) return 0;
  let r = DT[DT.length - 1];
  for (let k = 0; k < DT.length - 2; k += 2) {
    if (ph < DT[k + 2]) {
      const t = (ph - DT[k]) / (DT[k + 2] - DT[k]);
      r = DT[k + 1] + (DT[k + 3] - DT[k + 1]) * t;
      break;
    }
  }
  return (r + 0.012 * Math.sin(ph * 38)) * Math.sqrt(1 - sstep(1.02, 1.22, ph));
}

/** Bayangan bola semu: 0 = paling terang, 1 = paling gelap */
function shade(nx: number, ny: number): number {
  const d2 = nx * nx + ny * ny;
  const nz = Math.sqrt(Math.max(0, 1 - d2));
  const l = nx * (-0.42 * qLx) + ny * -0.62 + nz * 0.66;
  let t = 0.54 - 0.5 * l;
  if (d2 > 0.78) t += (d2 - 0.78) * 0.5;
  return t < 0 ? 0 : t > 1 ? 1 : t;
}

/** 0 = warna dasar, 1 = corak, 2 = bintik */
function mask(u: number, v: number): number {
  const seed = qSeed;
  const s = seed % 89;
  switch (qV.pattern) {
    case 'sarasa': {
      const k = (hash(1, 2, seed) - 0.5) * 0.16;
      const edge = -0.36 + k + 0.98 * sstep(-0.16, -0.52, u);
      const wob = (vnoise(u * 3.1 + s, v * 3.1, seed) - 0.5) * 0.26;
      if (v < edge + wob) return 1;
      let dx = u + 0.06;
      let dy = v - 0.36;
      if (dx * dx + dy * dy < 0.0075) return 1; // titik merah kecil di badan
      dx = (u - 0.55) / 0.08;
      dy = (v - 0.22) / 0.12;
      if (dx * dx + dy * dy < 1) return 1; // tanda merah di tutup insang
      return 0;
    }
    case 'full': {
      const wob = (vnoise(u * 2.6 + s, v * 2.6, seed) - 0.5) * 0.2;
      return v < 0.4 + wob - 0.25 * u ? 1 : 0;
    }
    case 'cap': {
      const dx = (u - 0.3) / 0.5;
      const dy = (v + 0.72) / 0.36;
      const wob = (vnoise(u * 4 + s, v * 4, seed) - 0.5) * 0.35;
      return dx * dx + dy * dy < 1 + wob ? 1 : 0;
    }
    case 'calico': {
      const cs = 0.17;
      const gx = Math.floor(u / cs);
      const gy = Math.floor(v / cs);
      if (hash(gx, gy, seed + 7) > 0.84) {
        const fx = u / cs - gx - 0.5;
        const fy = v / cs - gy - 0.5;
        if (fx * fx + fy * fy < 0.11) return 2;
      }
      return vnoise(u * 2.1 + s, v * 2.1 + 3, seed) > 0.55 ? 1 : 0;
    }
    case 'patch':
      return vnoise(u * 1.9 + s, v * 1.9 + 5, seed) + 0.1 * Math.max(0, -v) > 0.57 ? 1 : 0;
  }
}

function finOut(rn: number, ang: number, freq: number, rim: boolean, far: boolean, px: number, py: number) {
  const V = qV;
  const ray = Math.sin(ang * freq);
  const hi = ray > 0.45;
  const idx = dither(4, rn * 0.9 + (hi ? 0.14 : 0), px, py, 0.7);
  let c = V.fin[idx];
  let al = Math.min(1, 0.99 - 0.22 * rn + (hi ? 0.06 : 0));
  let m = 0;
  if (ray < -0.5 && rn > 0.22) m = 0.4;
  if (rim) {
    c = V.fin[3];
    al = 0.92;
    m = 0;
  }
  if (far) {
    m = m + (1 - m) * 0.4;
    al *= 0.94;
  }
  const sh = V.finShade;
  oR = c[0] + (sh[0] - c[0]) * m;
  oG = c[1] + (sh[1] - c[1]) * m;
  oB = c[2] + (sh[2] - c[2]) * m;
  oA = al;
  oK = 1;
}

function sample(u: number, v: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  if (u < -2.0 || u > 1.34 || v < -1.7 || v > 1.8) return;
  const V = qV;

  // --- sirip dada (di depan badan, mengepak; pangkalnya merona) ---
  let dx = u - 0.62;
  let dy = v - 0.4;
  let r2 = dx * dx + dy * dy;
  if (r2 < 0.2) {
    let a = Math.atan2(dy, dx) - (2.2 + qFlap);
    if (a < -Math.PI) a += TAU;
    const w = win(a, -0.6, 0.6, 0.3);
    if (w > 0) {
      const R = 0.44 * Math.sqrt(w);
      const r = Math.sqrt(r2);
      if (r < R) {
        const edge = R - r < qPx * 0.9;
        const c = edge ? V.finLine : V.fin[r < R * 0.5 ? 0 : Math.sin(a * 11) > 0.3 ? 3 : 2];
        oR = c[0];
        oG = c[1];
        oB = c[2];
        oA = 1;
        oK = 2;
        return;
      }
    }
  }

  // --- kepala: kerucut membulat kecil yang menyembul dari badan + bibir monyong ---
  const ht = u <= 0.85 ? 0 : u >= 1.03 ? 1 : (u - 0.85) / 0.18;
  const hr = 0.34 - 0.115 * ht;
  const hdx = u - (0.85 + 0.18 * ht);
  const hdy = v - (0.06 + 0.035 * ht);
  const hd2 = hdx * hdx + hdy * hdy;
  const lx = u - 1.2;
  const ly = v - 0.16;
  const inHead = hd2 < hr * hr || lx * lx + ly * ly < 0.0049;

  // --- badan: perut bola kembung + punuk tinggi (depan curam, belakang melandai) + pangkal ekor ---
  const ax = (u - 0.05) / 0.8;
  const ay = (v - 0.2) / 0.87;
  let inBody = ax * ax + ay * ay < 1;
  if (!inBody) {
    const by = (v + 0.3) / 0.7;
    const bu = u - 0.3;
    if (by > -1 && by < 1 && bu > -0.92 && bu < 0.54) {
      if (bu >= 0) inBody = Math.pow(bu / 0.54, 2.25) + Math.pow(by < 0 ? -by : by, 2.25) < 1;
      else {
        const bx = bu / 0.92;
        inBody = bx * bx + by * by < 1;
      }
    }
    if (!inBody) {
      const cx = (u + 0.7) / 0.2;
      const cy = (v + 0.16) / 0.2;
      inBody = cx * cx + cy * cy < 1;
    }
  }

  if (inHead) {
    let t = shade((u - 0.9) / 0.5, (v - 0.06) / 0.48) - 0.05;
    const gl = 0.34 - qPx * 1.1;
    if (inBody && ht === 0 && u < 0.8 && hd2 > gl * gl) t += 0.3; // garis tutup insang
    const m = V.pattern === 'full' ? 0 : mask(u, v);
    let c: RGB;
    if (m === 2 && V.speck) c = V.speck;
    else c = (m === 1 ? V.patch : V.head)[dither(5, t, px, py, 0.55)];
    oR = c[0];
    oG = c[1];
    oB = c[2];
    oA = 1;
    oK = 2;
    return;
  }
  if (inBody) {
    const t = shade((u - 0.03) / 0.9, (v - 0.03) / 1.12);
    const m = mask(u, v);
    let c: RGB;
    if (m === 2 && V.speck) c = V.speck;
    else c = (m === 1 ? V.patch : V.base)[dither(5, t, px, py, 0.55)];
    oR = c[0];
    oG = c[1];
    oB = c[2];
    oA = 1;
    oK = 2;
    return;
  }

  // --- sirip perut: dua kipas pendek lebar di bawah perut (dekat & jauh) ---
  if (v > 0.8) {
    const sway = Math.sin(qWave * 0.5) * 0.08;
    dx = u - 0.14;
    dy = v - 0.98;
    r2 = dx * dx + dy * dy;
    if (r2 < 0.5) {
      const a = Math.atan2(dy, dx) - 1.84 - sway;
      const w = win(a, -0.54, 0.54, 0.16);
      if (w > 0) {
        const R = (0.67 + 0.012 * Math.sin(a * 26)) * Math.sqrt(w);
        const r = Math.sqrt(r2);
        if (r < R) {
          finOut(r / R, a, 19, R - r < qPx * 1.05, false, px, py);
          return;
        }
      }
    }
    dx = u - 0.32;
    dy = v - 0.98;
    r2 = dx * dx + dy * dy;
    if (r2 < 0.42) {
      const a = Math.atan2(dy, dx) - 1.42 + sway;
      const w = win(a, -0.44, 0.44, 0.16);
      if (w > 0) {
        const R = 0.61 * Math.sqrt(w);
        const r = Math.sqrt(r2);
        if (r < R) {
          finOut(r / R, a, 19, false, true, px, py);
          return;
        }
      }
    }
  }

  // --- ekor bercagak; lapis jauh mengintip di bawah seperti sirip anal ---
  dx = u + 0.76;
  dy = v + 0.18;
  if (dx < 0.3) {
    r2 = dx * dx + dy * dy;
    if (r2 < 1.3) {
      const r = Math.sqrt(r2);
      const th = Math.atan2(dy, -dx);
      const thw = th + qTail * Math.sin(qWave - r * 3) * (0.2 + r);
      let R = tailR(thw);
      if (r < R) {
        finOut(r / R, thw, 27, R - r < qPx * 1.05, false, px, py);
        return;
      }
      const thf = th - 0.36 + qTail * Math.sin(qWave - r * 3 - 0.9) * (0.2 + r);
      R = 0.9 * tailR(thf);
      if (r < R) {
        finOut(r / R, thf, 27, false, true, px, py);
        return;
      }
    }
  }

  // --- sirip punggung: layar panjang dari puncak punuk sampai pangkal ekor ---
  const fe = 0.6 + 0.32 * Math.min(0, v + 1);
  if (v < -0.25 && u < fe) {
    dx = u;
    dy = v + 0.2;
    r2 = dx * dx + dy * dy;
    if (r2 < 2.1) {
      const r = Math.sqrt(r2);
      const ph = Math.atan2(-dx, -dy);
      const wob = qDors * Math.sin(qWave * 0.6 - ph * 3) * Math.max(0, r - 0.8) * 2.2;
      const R = dorsalR(ph + wob);
      if (r < R) {
        // jari-jari sirip memancar dari dalam badan: tegak di depan, rebah ke belakang
        const ra = Math.atan2(0.45 - u, 0.1 - v) + wob;
        const rn = clamp((r - 0.8) / (R - 0.8), 0, 1);
        finOut(0.2 + 0.8 * rn, ra, 52, R - r < qPx * 1.05 || u > fe - qPx * 1.05, false, px, py);
        return;
      }
    }
  }
}

// ---------- stempel mata (biar imut & tajam di piksel) ----------
const EYE_L = [' RRR ', 'RWKKR', 'RKKKR', 'RKKSR', ' RRR '];
const EYE_M = [' RR ', 'RWKR', 'RKKR', ' RR '];
const EYE_S = ['RR ', 'WKR', 'KKR'];
const HAPPY_L = ['     ', '  K  ', ' K K ', 'K   K', '     '];
const HAPPY_M = ['    ', ' KK ', 'K  K', '    '];
const BLINK_L = ['     ', '     ', 'KKKKK', '     ', '     '];
const BLINK_M = ['    ', '    ', 'KKKK', '    '];

function setPx(idx: number, c: RGB) {
  sR[idx] = c[0];
  sG[idx] = c[1];
  sB[idx] = c[2];
  sA[idx] = 1;
}

const WHITE: RGB = [255, 255, 255];

export function drawFish(buf: Uint32Array, W: number, H: number, p: FishPose) {
  const unit = p.unit;
  const inv = 1 / unit;
  const sgn = p.facing >= 0 ? 1 : -1;
  const fm = Math.max(0.3, Math.abs(p.facing));
  const f = sgn * fm;
  const a = p.pitch * sgn;
  const ca = Math.cos(a);
  const sa = Math.sin(a);
  const hw = Math.min((SPR - 1) >> 1, Math.ceil(2.25 * unit) + 2);
  const sw = hw * 2 + 1;
  const V = p.variety;

  qV = V;
  qSeed = p.seed;
  qLx = sgn;
  qWave = p.wave;
  qTail = 0.09 + 0.1 * p.swim;
  qDors = 0.035 + 0.035 * p.swim;
  qFlap = Math.sin(p.wave * 0.9) * 0.3;
  qPx = inv;

  for (let j = 0; j < sw; j++) {
    const Y = (j - hw) * inv;
    for (let i = 0; i < sw; i++) {
      const X = (i - hw) * inv;
      sample((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      const idx = j * sw + i;
      sK[idx] = oK;
      if (oK) {
        sR[idx] = oR;
        sG[idx] = oG;
        sB[idx] = oB;
        sA[idx] = oA;
      }
    }
  }

  // lokal → koordinat sprite
  const toX = (u: number, v: number) => Math.round((u * f * ca - v * sa) * unit) + hw;
  const toY = (u: number, v: number) => Math.round((u * f * sa + v * ca) * unit) + hw;

  if (fm > 0.55) {
    // pipi merona
    const bxp = toX(0.8, 0.25);
    const byp = toY(0.8, 0.25);
    const bw = unit >= 14 ? 3 : 2;
    const bh = p.eye === 'happy' && unit >= 12 ? 2 : 1;
    for (let j = 0; j < bh; j++) {
      for (let i = 0; i < bw; i++) {
        const xx = bxp + (sgn > 0 ? i - bw + 1 : -i + bw - 1);
        const idx = (byp + j) * sw + xx;
        if (xx < 0 || xx >= sw || byp + j < 0 || byp + j >= sw || sK[idx] !== 2) continue;
        sR[idx] += (V.blush[0] - sR[idx]) * 0.62;
        sG[idx] += (V.blush[1] - sG[idx]) * 0.62;
        sB[idx] += (V.blush[2] - sB[idx]) * 0.62;
      }
    }
    // mulut mungil
    const mx = toX(1.2, 0.16);
    const my = toY(1.2, 0.16);
    for (let j = 0; j < (p.mouthOpen ? 2 : 1); j++) {
      const idx = (my + j) * sw + mx;
      if (mx >= 0 && mx < sw && my + j >= 0 && my + j < sw && sK[idx] === 2) setPx(idx, V.mouth);
    }
    // mata
    const big = unit >= 14.5;
    const small = unit < 9.5;
    let tpl: string[];
    if (p.eye === 'happy') tpl = big ? HAPPY_L : HAPPY_M;
    else if (p.eye === 'blink') tpl = big ? BLINK_L : BLINK_M;
    else tpl = big ? EYE_L : small ? EYE_S : EYE_M;
    const n = tpl.length;
    const ex = toX(0.93, -0.03) - (n >> 1);
    const ey = toY(0.93, -0.03) - (n >> 1);
    for (let j = 0; j < n; j++) {
      const row = tpl[j];
      for (let i = 0; i < row.length; i++) {
        const ch = row[i];
        if (ch === ' ') continue;
        const xx = ex + i;
        const yy = ey + j;
        if (xx < 0 || xx >= sw || yy < 0 || yy >= sw) continue;
        const idx = yy * sw + xx;
        if (sK[idx] !== 2) continue;
        if (ch === 'R') setPx(idx, V.ring);
        else if (ch === 'W') setPx(idx, WHITE);
        else if (ch === 'S') setPx(idx, [V.pupil[0] + 60, V.pupil[1] + 50, V.pupil[2] + 90]);
        else setPx(idx, V.pupil);
      }
    }
  }

  // komposit + outline halus (selout)
  const x0 = p.x - hw;
  const y0 = p.y - hw;
  const tr = p.tint[0];
  const tg = p.tint[1];
  const tb = p.tint[2];
  const ta = p.tintAmt;
  const fl = V.finLine;
  for (let j = 0; j < sw; j++) {
    const Y = y0 + j;
    if (Y < 0 || Y >= H) continue;
    for (let i = 0; i < sw; i++) {
      const X = x0 + i;
      if (X < 0 || X >= W) continue;
      const idx = j * sw + i;
      const k = sK[idx];
      let r = 0;
      let g = 0;
      let b = 0;
      let al = 0;
      const kl = i > 0 ? sK[idx - 1] : 0;
      const kr = i < sw - 1 ? sK[idx + 1] : 0;
      const ku = j > 0 ? sK[idx - sw] : 0;
      const kd = j < sw - 1 ? sK[idx + sw] : 0;
      if (k) {
        r = sR[idx];
        g = sG[idx];
        b = sB[idx];
        al = sA[idx];
        if (k === 1 && (kl === 2 || kr === 2 || ku === 2 || kd === 2)) {
          r += (fl[0] - r) * 0.55;
          g += (fl[1] - g) * 0.55;
          b += (fl[2] - b) * 0.55;
          if (al < 0.9) al = 0.9;
        }
      } else {
        let n = -1;
        if (kl === 2) n = idx - 1;
        else if (kr === 2) n = idx + 1;
        else if (ku === 2) n = idx - sw;
        else if (kd === 2) n = idx + sw;
        if (n >= 0) {
          r = sR[n] * 0.42 + 8;
          g = sG[n] * 0.28 + 4;
          b = sB[n] * 0.38 + 22;
          al = 0.92;
        } else if (kl || kr || ku || kd) {
          r = fl[0];
          g = fl[1];
          b = fl[2];
          al = 0.6;
        } else continue;
      }
      if (ta > 0) {
        r += (tr - r) * ta;
        g += (tg - g) * ta;
        b += (tb - b) * ta;
      }
      blend(buf, Y * W + X, r, g, b, al);
    }
  }
}

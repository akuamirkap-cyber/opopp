type Cv = HTMLCanvasElement;
type Ctx = CanvasRenderingContext2D;

export interface Weather { dark: number; fog: number; rain: number; bolt: number; name: string; snow?: number; /** 0 night .. 1 daylight */ day?: number }

const rand = Math.random;
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);

function canvas(w: number, h: number): [Cv, Ctx] {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return [c, c.getContext("2d")!];
}

function radial(r: number, g: number, b: number, a0: number): Cv {
  const [c, x] = canvas(64, 64);
  const gr = x.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, `rgba(${r},${g},${b},${a0})`);
  gr.addColorStop(0.45, `rgba(${r},${g},${b},${a0 * 0.7})`);
  gr.addColorStop(1, `rgba(${r},${g},${b},0)`);
  x.fillStyle = gr;
  x.fillRect(0, 0, 64, 64);
  return c;
}

/**
 * Night, flashlights, drifting fog, acid rain and lightning for the alien planet.
 * Darkness lives on its own canvas; lights punch holes into it.
 */
export class Atmosphere {
  cur: Weather = { dark: 0.6, fog: 0.25, rain: 0, bolt: 0.02, name: "MALAM" };
  flash = 0;
  /** 0..1: how far indoors the view is (rooms are lit by their own bulbs, so the night is less heavy) */
  indoor = 0;
  /** 0..1: barred into somewhere safe - the lights are up and the whole place can be seen */
  cozy = 0;
  private dawn: Cv | null = null;
  /** 0..1: the floor you are on has nothing dead left on it - every room can be seen */
  clear = 0;
  /** set when thunder should be heard; the engine consumes it */
  thunder = false;
  private W = 480;
  private H = 270;
  private lc: Cv;
  private lx: Ctx;
  private fc: Cv;
  private fx: Ctx;
  private rip: number[] = [];
  private glow = radial(255, 255, 255, 1);
  private cone: Cv;
  private fogTex: Cv;
  private tints: Record<string, Cv> = {
    b: radial(70, 120, 255, 0.6), y: radial(255, 190, 60, 0.6), m: radial(255, 95, 210, 0.55), c: radial(95, 240, 224, 0.5), o: radial(255, 122, 60, 0.6), r: radial(255, 48, 48, 0.6), g: radial(140, 255, 90, 0.55), w: radial(255, 240, 200, 0.5),
  };
  private flick = 0;
  private thunderT = -1;
  private bolt: number[] = [];
  private boltLife = 0;
  private drops: number[] = [];

  constructor() {
    [this.lc, this.lx] = canvas(this.W, this.H);
    [this.fc, this.fx] = canvas(this.W, this.H);
    // flashlight cone: stacked wedges give a soft edge without ctx.filter
    const [cc, cx] = canvas(160, 160);
    for (let k = 0; k < 8; k++) {
      const half = 0.52 - k * 0.036;
      const gr = cx.createRadialGradient(0, 80, 0, 0, 80, 160);
      gr.addColorStop(0, "rgba(255,255,255,0.24)");
      gr.addColorStop(0.6, "rgba(255,255,255,0.16)");
      gr.addColorStop(1, "rgba(255,255,255,0)");
      cx.fillStyle = gr;
      cx.beginPath();
      cx.moveTo(0, 80);
      cx.arc(0, 80, 160, -half, half);
      cx.closePath();
      cx.fill();
    }
    // ...and a hot core down the middle, the way a real torch throws its light
    for (const half of [0.17, 0.11, 0.06]) {
      const gr = cx.createRadialGradient(0, 80, 0, 0, 80, 150);
      gr.addColorStop(0, "rgba(255,255,255,0.3)");
      gr.addColorStop(0.7, "rgba(255,255,255,0.14)");
      gr.addColorStop(1, "rgba(255,255,255,0)");
      cx.fillStyle = gr;
      cx.beginPath();
      cx.moveTo(0, 80);
      cx.arc(0, 80, 150, -half, half);
      cx.closePath();
      cx.fill();
    }
    this.cone = cc;
    // tileable chunky fog texture
    const [fc, fx] = canvas(128, 128);
    const img = fx.createImageData(128, 128), d = img.data;
    const W8 = [[1, 0, 0.5, 0.3], [0, 1, 0.5, 1.9], [1, 1, 0.4, 4.1], [2, -1, 0.3, 2.2], [-1, 2, 0.3, 5.3], [3, 1, 0.2, 0.7], [1, 3, 0.2, 3.3], [2, 2, 0.15, 1.1]];
    for (let y = 0; y < 128; y += 2)
      for (let x = 0; x < 128; x += 2) {
        let v = 0;
        for (const w of W8) v += w[2] * Math.sin((Math.PI * 2 * (w[0] * x + w[1] * y)) / 128 + w[3]);
        const a = Math.round(clamp((v / 2.55 + 0.18) * 0.95, 0, 1) * 4) / 4;
        for (let j = 0; j < 2; j++)
          for (let i = 0; i < 2; i++) {
            const o = ((y + j) * 128 + x + i) * 4;
            d[o] = 172; d[o + 1] = 196; d[o + 2] = 228; d[o + 3] = a * 190;
          }
      }
    fx.putImageData(img, 0, 0);
    this.fogTex = fc;
  }

  resize(W: number, H: number) {
    this.W = W;
    this.H = H;
    this.lc.width = W;
    this.lc.height = H;
    this.fc.width = W;
    this.fc.height = H;
    this.drops = [];
    for (let i = 0; i < 260; i++) this.drops.push(rand() * (W + 80), rand() * H);
  }

  update(dt: number, target: Weather) {
    const c = this.cur, k = 1 - Math.exp(-dt * 0.9);
    c.dark += (target.dark - c.dark) * k;
    c.fog += (target.fog - c.fog) * k;
    c.rain += (target.rain - c.rain) * k;
    c.bolt = target.bolt;
    c.name = target.name;
    c.snow = (c.snow ?? 0) + ((target.snow ?? 0) - (c.snow ?? 0)) * k;
    c.day = (c.day ?? 0) + ((target.day ?? 0) - (c.day ?? 0)) * k; // dawn breaks slowly
    const d = this.drops, sn = (c.snow ?? 0) > 0.3;
    for (let i = 0; i < d.length; i += 2) {
      // snow drifts down slowly, each flake at its own pace; rain hammers down
      d[i] -= (sn ? 10 + (i % 7) * 2 : 120 + 70 * c.rain) * dt;
      d[i + 1] += (sn ? 26 + (i % 5) * 6 : 430 + 110 * c.rain) * dt;
      if (d[i + 1] > this.H) { d[i + 1] -= this.H + 8; d[i] = rand() * (this.W + 80); }
      if (sn && d[i] < -6) d[i] += this.W + 12;
    }
    this.flash *= Math.exp(-dt * 7);
    if (this.flick > 0 && (this.flick -= dt) <= 0) this.flash = Math.max(this.flash, 0.85);
    if (this.boltLife > 0) this.boltLife -= dt;
    if (this.thunderT > 0 && (this.thunderT -= dt) <= 0) this.thunder = true;
    if (rand() < c.bolt * dt) this.strike();
  }

  strike() {
    this.flash = 1;
    this.flick = 0.11;
    this.thunderT = 0.2 + rand() * 0.5;
    this.boltLife = 0.13;
    let x = this.W * (0.1 + rand() * 0.8), y = 0;
    const end = this.H * (0.35 + rand() * 0.5);
    this.bolt = [x, y];
    while (y < end) {
      x += (rand() - 0.5) * 26;
      y += 8 + rand() * 16;
      this.bolt.push(x, y);
    }
  }

  /** fog banks and rain, drawn over the world but under the darkness */
  weather(ctx: Ctx, cl: number, ct: number, t: number) {
    const f = this.cur.fog, W = this.W, H = this.H;
    if (f > 0.02) {
      const mod = (v: number, m: number) => ((v % m) + m) % m;
      ctx.globalAlpha = Math.min(0.62, f * 0.5);
      let ox = -mod(cl + t * 15, 128), oy = -mod(ct + t * 5, 128);
      for (let x = ox; x < W; x += 128) for (let y = oy; y < H; y += 128) ctx.drawImage(this.fogTex, x, y);
      ctx.globalAlpha = Math.min(0.5, f * 0.38);
      ox = -mod(cl * 0.8 - t * 10, 256); oy = -mod(ct * 0.8 + t * 8, 256);
      for (let x = ox; x < W; x += 256) for (let y = oy; y < H; y += 256) ctx.drawImage(this.fogTex, x, y, 256, 256);
      ctx.globalAlpha = 1;
    }
    const s = this.cur.snow ?? 0;
    if (s > 0.03) {
      // snowfall: big soft flakes in front, small ones behind, all swaying a little
      const d = this.drops;
      for (let i = 0; i < d.length; i += 2) {
        const big = (i >> 1) % 4 === 0, x = (d[i] + Math.sin(t * (0.8 + (i % 5) * 0.2) + i) * 5) | 0, y = d[i + 1] | 0;
        ctx.fillStyle = big ? `rgba(255,255,255,${(0.85 * s).toFixed(2)})` : `rgba(215,228,250,${(0.6 * s).toFixed(2)})`;
        ctx.fillRect(x, y, big ? 2 : 1, big ? 2 : 1);
      }
      ctx.fillStyle = `rgba(190,210,245,${(0.05 * s).toFixed(3)})`;
      ctx.fillRect(0, 0, W, H);
    }
    const r = this.cur.rain;
    if (r > 0.03) {
      const d = this.drops, n = (((d.length / 2) * Math.min(1, Math.pow(r / 2, 1.4))) | 0) * 2, heavy = r > 1.3;
      const vx = 120 + 70 * r, vy = 430 + 110 * r, sl = vx / vy + Math.sin(t * 0.35) * 0.08;
      const len = heavy ? 12 : 7;
      // far drops: thin and faint; near drops: long, bright streaks blown sideways by the wind
      for (let layer = 0; layer < 2; layer++) {
        ctx.strokeStyle = layer ? (heavy ? "rgba(215,230,255,0.62)" : "rgba(200,220,255,0.5)") : "rgba(150,175,230,0.28)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        for (let i = 0; i < n; i += 2) {
          if (((i >> 1) & 1) !== layer) continue;
          const x = d[i] | 0, y = d[i + 1] | 0, L = layer ? len : len * 0.6;
          ctx.moveTo(x + sl * L, y - L);
          ctx.lineTo(x, y);
        }
        ctx.stroke();
      }
      // splashes and expanding ripples where the drops hit the ground
      ctx.fillStyle = "rgba(215,230,255,0.6)";
      const sp = heavy ? n / 3 : n / 6;
      for (let i = 0; i < sp; i++) {
        const x = (rand() * W) | 0, y = (rand() * H) | 0;
        ctx.fillRect(x, y, 2, 1);
        if (heavy && i % 2) { ctx.fillRect(x - 1, y - 1, 1, 1); ctx.fillRect(x + 2, y - 1, 1, 1); }
      }
      if (heavy && this.rip.length < 90 && rand() < 0.9) this.rip.push(rand() * W, rand() * H, 0);
      ctx.strokeStyle = "rgba(200,220,255,0.35)";
      for (let i = this.rip.length - 3; i >= 0; i -= 3) {
        const k = (this.rip[i + 2] += 0.045);
        if (k >= 1) { this.rip.splice(i, 3); continue; }
        ctx.globalAlpha = 1 - k;
        ctx.beginPath();
        ctx.ellipse(this.rip[i], this.rip[i + 1], 1 + k * 7, 0.5 + k * 3, 0, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
      if (heavy) {
        // a sheet of water in the air, and a cold blue cast
        ctx.fillStyle = "rgba(150,175,225,0.09)";
        ctx.fillRect(0, 0, W, H);
      }
    }
  }

  /** start a darkness pass */
  begin() {
    const x = this.lx;
    x.globalCompositeOperation = "source-over";
    x.globalAlpha = 1;
    x.clearRect(0, 0, this.W, this.H);
    x.fillStyle = `rgba(7,4,20,${(this.cur.dark * Math.max(0.12, 1 - 0.42 * this.indoor - 0.45 * this.cozy - 0.24 * this.clear) * (1 - 0.85 * this.flash)).toFixed(3)})`;
    x.fillRect(0, 0, this.W, this.H);
    x.globalCompositeOperation = "destination-out";
  }

  /** round light at screen position */
  light(x: number, y: number, r: number, a = 1) {
    if (a <= 0.01 || x < -r || y < -r || x > this.W + r || y > this.H + r) return;
    this.lx.globalAlpha = a > 1 ? 1 : a;
    this.lx.drawImage(this.glow, x - r, y - r, r * 2, r * 2);
  }

  /** flashlight cone */
  beam(x: number, y: number, ang: number, len: number, a = 1) {
    const c = this.lx;
    c.save();
    c.translate(x, y);
    c.rotate(ang);
    c.globalAlpha = a > 1 ? 1 : a;
    c.drawImage(this.cone, 0, -len / 2, len, len);
    c.restore();
  }

  /** run light draws clipped to a screen-space polygon, so walls cast shadows */
  clip(poly: number[], fn: () => void) {
    const c = this.lx;
    c.save();
    c.beginPath();
    c.moveTo(poly[0], poly[1]);
    for (let i = 2; i < poly.length; i += 2) c.lineTo(poly[i], poly[i + 1]);
    c.closePath();
    c.clip();
    fn();
    c.restore();
  }

  /** black out everything outside a screen rectangle (you are indoors: the street is out of sight) */
  shade(x0: number, y0: number, x1: number, y1: number, a: number) {
    const c = this.lx, W = this.W, H = this.H;
    c.globalCompositeOperation = "source-over";
    c.globalAlpha = 1;
    c.fillStyle = `rgba(5,3,12,${a.toFixed(3)})`;
    if (y0 > 0) c.fillRect(0, 0, W, y0);
    if (y1 < H) c.fillRect(0, y1, W, H - y1);
    if (x0 > 0) c.fillRect(0, y0, x0, y1 - y0);
    if (x1 < W) c.fillRect(x1, y0, W - x1, y1 - y0);
    c.globalCompositeOperation = "destination-out";
  }

  /**
   * line of sight + focus: everything you cannot see is dark (almost black when indoors), what you can see
   * is dimmed with distance, and the area around the mouse stays sharp.
   * poly = screen-space visibility polygon of the player.
   */
  focus(
    poly: number[], px: number, py: number, mx: number, my: number, indoor: number, reach: number, aimed: boolean,
    mates: { poly: number[]; x: number; y: number; ang: number; len: number }[] = [], room: number[] | null = null, roomA = 0, outA = 0, shells: number[][] = [], shellA = 0,
  ) {
    const f = this.fx, W = this.W, H = this.H;
    f.globalCompositeOperation = "source-over";
    f.globalAlpha = 1;
    f.clearRect(0, 0, W, H);
    f.fillStyle = `rgba(4,3,9,${((0.58 + 0.41 * indoor) * (1 - 0.92 * this.cozy) * (1 - 0.9 * (this.cur.day ?? 0) * (1 - indoor))).toFixed(3)})`;
    f.fillRect(0, 0, W, H);
    f.globalCompositeOperation = "destination-out";
    f.save();
    f.beginPath();
    f.moveTo(poly[0], poly[1]);
    for (let i = 2; i < poly.length; i += 2) f.lineTo(poly[i], poly[i + 1]);
    f.closePath();
    f.clip();
    f.globalAlpha = 0.7 + 0.24 * indoor;
    f.fillRect(0, 0, W, H); // visible but far: dim
    f.globalAlpha = 1;
    f.drawImage(this.glow, px - reach, py - reach, reach * 2, reach * 2);       // around you
    if (aimed) f.drawImage(this.glow, mx - reach * 0.75, my - reach * 0.75, reach * 1.5, reach * 1.5); // where you are looking
    f.restore();
    // what your friends' torches sweep, you see too
    for (const m of mates) {
      f.save();
      f.beginPath();
      f.moveTo(m.poly[0], m.poly[1]);
      for (let i = 2; i < m.poly.length; i += 2) f.lineTo(m.poly[i], m.poly[i + 1]);
      f.closePath();
      f.clip();
      f.globalAlpha = 1;
      f.drawImage(this.glow, m.x - 42, m.y - 42, 84, 84);
      f.translate(m.x, m.y);
      f.rotate(m.ang);
      f.drawImage(this.cone, 0, -m.len / 2, m.len, m.len);
      f.drawImage(this.cone, 0, -m.len / 2, m.len, m.len);
      f.restore();
    }
    if (room) {
      f.fillStyle = "#000";
      // a floor with nothing dead left on it lies open: every room
      if (roomA > 0.01) { f.globalAlpha = roomA; f.fillRect(room[0], room[1], room[2] - room[0], room[3] - room[1]); }
      // upstairs, what is outside the walls is in view all round: the street far below, the front of the building
      if (outA > 0.01) {
        f.globalAlpha = outA;
        f.fillRect(0, 0, W, room[1]); f.fillRect(0, room[3], W, H - room[3]);
        f.fillRect(0, room[1], room[0], room[3] - room[1]); f.fillRect(room[2], room[1], W - room[2], room[3] - room[1]);
      }
      f.globalAlpha = 1;
    }
    const c = this.lx;
    c.globalCompositeOperation = "source-over";
    c.globalAlpha = 1;
    if (shellA > 0.01) {
      // buildings stand above the street: their walls and roofs are in view even where the ground behind them is not
      f.globalAlpha = shellA;
      f.fillStyle = "#000";
      for (const q of shells) {
        f.beginPath();
        f.moveTo(q[0], q[1]);
        for (let i = 2; i < q.length; i += 2) f.lineTo(q[i], q[i + 1]);
        f.closePath();
        f.fill();
      }
      f.globalAlpha = 1;
    }
    c.drawImage(this.fc, 0, 0);
    c.globalCompositeOperation = "destination-out";
  }

  /** light falling on a wall: the darkness comes off that stretch of it */
  lit(q: number[], a: number) {
    const c = this.lx;
    c.globalAlpha = a > 1 ? 1 : a;
    c.fillStyle = "#000";
    c.beginPath();
    c.moveTo(q[0], q[1]); c.lineTo(q[2], q[3]); c.lineTo(q[4], q[5]); c.lineTo(q[6], q[7]);
    c.closePath();
    c.fill();
    c.globalAlpha = 1;
  }

  /** the beam of a torch hanging in the air - dust, rain, fog and snow catch it. Added light, clipped to what the torch can reach */
  shaft(ctx: Ctx, poly: number[], x: number, y: number, ang: number, len: number, a: number) {
    a *= 1 - (this.cur.day ?? 0); // no beam to see in daylight
    if (a <= 0.01) return;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(poly[0], poly[1]);
    for (let i = 2; i < poly.length; i += 2) ctx.lineTo(poly[i], poly[i + 1]);
    ctx.closePath();
    ctx.clip();
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = a > 1 ? 1 : a;
    ctx.translate(x, y);
    ctx.rotate(ang);
    ctx.drawImage(this.cone, 0, -len / 2, len, len);
    ctx.restore();
  }

  /** a light mirrored in wet ground: a long, thin smear below it */
  streak(ctx: Ctx, x: number, y: number, w: number, h: number, key: string, a: number) {
    if (a <= 0.01 || x < -w || y < -h || x > this.W + w || y > this.H + h) return;
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = a > 1 ? 1 : a;
    ctx.drawImage(this.tints[key] ?? this.tints.w, x - w / 2, y, w, h);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }

  /** composite the darkness (and lightning) onto the frame */
  end(ctx: Ctx) {
    // the darkness layer is softened a little so light and shadow edges melt instead of cutting
    const soft = "filter" in ctx;
    if (soft) ctx.filter = "blur(1.3px)";
    ctx.drawImage(this.lc, 0, 0);
    if (soft) ctx.filter = "none";
    // colour grade: cold blue shadows, so warm lamps and fire pop
    ctx.globalCompositeOperation = "soft-light";
    const day = this.cur.day ?? 0;
    if (day < 0.97) {
      ctx.fillStyle = `rgba(70,110,230,${((0.06 + this.cur.dark * 0.2) * (1 - day)).toFixed(3)})`;
      ctx.fillRect(0, 0, this.W, this.H);
    }
    if (day > 0.02) {
      // morning: everything warms up, most of all in the east, where the sun is low
      if (!this.dawn || this.dawn.width !== this.W || this.dawn.height !== this.H) {
        const [dc, dx] = canvas(this.W, this.H);
        const gr = dx.createLinearGradient(0, 0, this.W, this.H * 0.4);
        gr.addColorStop(0, "rgba(255,255,250,0.3)"); // (a bright, lightly clouded day - not a gloomy dawn)
        gr.addColorStop(1, "rgba(255,246,226,0.36)");
        dx.fillStyle = gr;
        dx.fillRect(0, 0, this.W, this.H);
        this.dawn = dc;
      }
      ctx.globalAlpha = day;
      ctx.drawImage(this.dawn, 0, 0);
      ctx.globalAlpha = 1;
    }
    ctx.globalCompositeOperation = "source-over";
    if (this.flash > 0.02) {
      ctx.fillStyle = `rgba(205,225,255,${(0.16 * this.flash).toFixed(3)})`;
      ctx.fillRect(0, 0, this.W, this.H);
    }
    if (this.boltLife > 0) {
      const b = this.bolt;
      for (let pass = 0; pass < 2; pass++) {
        ctx.strokeStyle = pass ? "#ffffff" : "rgba(170,200,255,0.6)";
        ctx.lineWidth = pass ? 1.5 : 4;
        ctx.beginPath();
        ctx.moveTo(b[0], b[1]);
        for (let i = 2; i < b.length; i += 2) ctx.lineTo(b[i], b[i + 1]);
        ctx.stroke();
      }
    }
  }

  /** coloured additive glow (bioluminescence, alarms, eyes) */
  tint(ctx: Ctx, x: number, y: number, r: number, key: string, a: number) {
    a *= 1 - 0.75 * (this.cur.day ?? 0); // lamps, eyes and muzzle flashes pale in daylight
    if (a <= 0.01 || x < -r || y < -r || x > this.W + r || y > this.H + r) return;
    ctx.globalCompositeOperation = "lighter";
    ctx.globalAlpha = a > 1 ? 1 : a;
    ctx.drawImage(this.tints[key], x - r, y - r, r * 2, r * 2);
    ctx.globalAlpha = 1;
    ctx.globalCompositeOperation = "source-over";
  }
}

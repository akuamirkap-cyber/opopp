import { glyphs } from "./sprites";

type Ctx = CanvasRenderingContext2D;

/** left edge of every side window, in bus pixels from the middle of the bus (the glass is 7 x 10, its top at -27). The last one is the driver's. */
export const BUS_WIN = [-36, -27, -18, -9, 0, 19];

export interface BusOpt {
  /** clock: wheels, bounce, lamps */
  t: number;
  moving: boolean;
  /** no rattle (the road trip moves the whole bus itself) */
  smooth?: boolean;
  /** fresh blood on the ram */
  ram?: boolean;
  /** how many simple heads show in the windows (the road trip draws real faces itself) */
  riders?: number;
  /** parked: the stop arm is swung out */
  stop?: boolean;
  /** the roof lamps flash: time to get in */
  flash?: boolean;
}

const HAT = ["#c0392b", "#f5c542", "#3f7a4a", "#ff7ab0", "#4a8fd8", "#8a6844"];

/**
 * The squad's ride: a yellow school bus dressed for the end of the world - a toothed ram on the nose, a plate over the rear wheel,
 * supplies lashed to the roof. Side view, nose to the right; (ox, oy) = the road under the middle of it.
 */
export function drawBus(ctx: Ctx, ox: number, oy: number, o: BusOpt) {
  const R = (c: string, a: number, b: number, w: number, h: number) => { ctx.fillStyle = c; ctx.fillRect(ox + a, oy + b, w, h); };
  const yb = o.moving && !o.smooth ? Math.round(Math.sin(o.t * 42)) : 0;
  const INK = "#0b0b10", Y = "#f6b91c", YH = "#ffdc66", YD = "#cf920e", GL = "#132238", GH = "#3d6490", RAIL = "#15151c";
  R("rgba(0,0,0,0.34)", -42, 5, 98, 4);
  // the long yellow body
  R(INK, -40, -31 + yb, 73, 30);
  R(Y, -39, -30 + yb, 71, 28); R(YH, -39, -30 + yb, 71, 1); R(YD, -39, -5 + yb, 71, 3);
  R(INK, -40, -31 + yb, 1, 1); R(INK, 32, -31 + yb, 1, 1);
  // the nose: hood, grille, headlamp
  R(INK, 32, -19 + yb, 14, 18); R(Y, 32, -18 + yb, 13, 16); R(YH, 32, -18 + yb, 13, 1); R(YD, 32, -5 + yb, 13, 3);
  R(RAIL, 42, -15 + yb, 3, 8); R("#5d6470", 42, -14 + yb, 1, 6); R("#fff3c0", 43, -17 + yb, 2, 2);
  // windscreen
  R(INK, 28, -29 + yb, 5, 12); R(GL, 29, -28 + yb, 3, 10); R(GH, 29, -28 + yb, 3, 2);
  // the two black rub rails, and the name between them
  R(RAIL, -39, -15 + yb, 71, 1); R(RAIL, -39, -7 + yb, 71, 1);
  ctx.fillStyle = RAIL;
  glyphs(ctx, "SCHOOL BUS", ox - 37, oy - 13 + yb, 1);
  // windows - with somebody looking out of each when everybody is aboard
  for (let i = 0; i < 6; i++) {
    const wx = BUS_WIN[i];
    R(INK, wx, -28 + yb, 9, 12); R(GL, wx + 1, -27 + yb, 7, 10); R(GH, wx + 1, -27 + yb, 7, 2);
    if (i < (o.riders ?? 0)) {
      R(HAT[i % HAT.length], wx + 2, -25 + yb, 5, 2); R("#e0ac7e", wx + 2, -23 + yb, 5, 3);
      R(INK, wx + 3, -22 + yb, 1, 1); R(INK, wx + 5, -22 + yb, 1, 1);
      R("#2c3a4c", wx + 1, -20 + yb, 7, 3);
    }
    R("#8d949e", wx + 1, -20 + yb, 7, 1);
  }
  // the folding door
  R(INK, 10, -28 + yb, 8, 27); R(GL, 11, -27 + yb, 6, 10); R(GH, 11, -27 + yb, 6, 2); R(YD, 11, -16 + yb, 6, 14); R(RAIL, 13, -27 + yb, 1, 25);
  // the stop arm
  if (o.stop) { R(INK, 3, -15 + yb, 7, 7); R("#d8433b", 4, -14 + yb, 5, 5); R("#ffffff", 5, -12 + yb, 3, 1); }
  else { R(INK, 5, -15 + yb, 3, 7); R("#d8433b", 6, -14 + yb, 1, 5); }
  // red and amber lamps on both ends of the roof
  const fl = !!o.flash && Math.sin(o.t * 10) > 0, fr = !!o.flash && !fl;
  R(fl ? "#ff5a4a" : "#a8322c", -38, -30 + yb, 3, 2); R(fr ? "#ffd75e" : "#b9831a", -34, -30 + yb, 3, 2);
  R(fr ? "#ffd75e" : "#b9831a", 23, -30 + yb, 3, 2); R(fl ? "#ff5a4a" : "#a8322c", 27, -30 + yb, 3, 2);
  // lashed to the roof: an ammunition box, a jerrycan, a crate
  R(INK, -34, -36 + yb, 32, 5);
  R("#4a5a34", -33, -35 + yb, 9, 4); R("#6a7a4a", -33, -35 + yb, 9, 1); R("#f5c542", -30, -34 + yb, 3, 1);
  R("#c0392b", -23, -35 + yb, 5, 4); R("#e8604c", -23, -35 + yb, 5, 1);
  R("#7a4a30", -17, -35 + yb, 14, 4); R("#9a6a48", -17, -35 + yb, 14, 1); R(INK, -10, -35 + yb, 1, 4);
  // a steel plate bolted over the rear wheel
  R("#5d6470", -38, -6 + yb, 22, 4); R("#858c98", -38, -6 + yb, 22, 1);
  for (const rx of [-37, -31, -25, -19]) R("#c9cdd9", rx, -4 + yb, 1, 1);
  // wheel arches, fat tyres, yellow hubs
  const ph = o.moving ? Math.floor(o.t * 34) % 4 : 0;
  for (const wx of [-32, 24]) {
    R(INK, wx - 1, -7 + yb, 15, 7);
    R(INK, wx, -5, 13, 12); R("#26272e", wx + 1, -4, 11, 10);
    for (let i = 0; i < 3; i++) { R("#3a3c46", wx + 1 + ((i * 4 + ph) % 10), -4, 2, 1); R("#3a3c46", wx + 1 + ((i * 4 + 4 - ph) % 10), 5, 2, 1); }
    R(Y, wx + 4, -1, 5, 4); R("#8d949e", wx + 5, 0, 3, 2); R("#ffffff", wx + 6, 0, 1, 1);
  }
  // rear bumper and tail lamp
  R(RAIL, -42, -5 + yb, 3, 4); R("#d8433b", -40, -12 + yb, 1, 4);
  // the ram: a steel wedge with teeth, welded to the frame
  R(INK, 46, -12 + yb, 6, 15); R("#8d949e", 47, -11 + yb, 4, 13); R("#c9cdd9", 47, -11 + yb, 1, 13); R("#5d6470", 50, -11 + yb, 1, 13);
  for (let i = 0; i < 4; i++) {
    const ty = -10 + yb + i * 3;
    R(INK, 51, ty - 1, 6 - (i % 2), 3); R("#d9dee8", 51, ty, 4 - (i % 2), 1); R("#ffffff", 54 - (i % 2), ty, 1, 1);
  }
  if (o.ram) { R("#a8202c", 48, -5 + yb, 3, 4); R("#d04a4a", 52, -4 + yb, 3, 1); R("#a8202c", 51, -1 + yb, 4, 1); }
}

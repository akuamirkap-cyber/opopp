import { TILE } from "./defs";
import type { WeaponDef } from "./defs";
import type { Fighter, Game } from "./engine";
import type { Bug } from "./bugs";
import { BUG } from "./bugs";
import { kindAt } from "./map";
import { nyClimb } from "./nyc";
import { escapeOf, leanX, leanY, persp } from "../ny/b3d";
import type { Obj } from "../ny/world";

/**
 * New York: up the fire escape. Hold "up" against the front of a building and you climb onto the landing at the first floor;
 * keep holding and you go on to floors 2, 3 and 4 and finally over the edge of the roof. From up there you shoot down into the
 * street - the dead cannot reach you, only spit at you - and your friends climb up after you.
 *
 * Where somebody "is" stays on the pavement under the fire escape (that is where the dead gather, what the camera and the radar use);
 * only for looking, aiming, firing and drawing they are lifted to where they stand on the building.
 */
export interface Perch {
  /** the building */
  o: Obj;
  /** how high each landing is; lvl 1..n = a landing, n + 1 = the roof */
  zs: number[]; lvl: number;
  /** height right now (it follows the ladder), how far back from the edge of the roof */
  z: number; d: number;
  holdT: number; busy: number;
  /** lifted at the moment - and where they were standing before that */
  on: boolean; bx: number; by: number; aim0: number;
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const zOf = (p: Perch) => (p.lvl <= p.zs.length ? p.zs[p.lvl - 1] : p.o.fh ?? 0);
export const perchName = (p: Perch) => (p.lvl > p.zs.length ? "ATAP GEDUNG" : `BALKON LANTAI ${p.lvl}`);

/** lift somebody to where they stand on the building (until perchDown). Returns the perch when it did. */
export function perchUp(g: Game, f: Fighter): Perch | null {
  const p = f.perch;
  if (!p || p.on) return null;
  const vx = g.cl + g.W / 2, vy = g.ct + g.H / 2;
  p.bx = f.x; p.by = f.y; p.aim0 = f.aim; p.on = true;
  f.x = leanX(p.bx, p.z, vx);
  f.y = leanY(p.o.sy, p.z, vy) - p.d * (1 + persp(p.z) * 0.34) - 5;
  if (!f.isPlayer) {
    // friends look down the barrel at whatever they have picked
    const t = f.ai?.target;
    if (t && t.alive) f.aim = Math.atan2(t.y - 5 - f.y, t.x - f.x);
  }
  return p;
}
export function perchDown(f: Fighter, p: Perch) {
  if (!p.on) return;
  p.on = false;
  f.x = p.bx; f.y = p.by;
  if (!f.isPlayer) f.aim = p.aim0;
}

function mount(g: Game, f: Fighter, o: Obj, lvl: number) {
  const zs = escapeOf(o.fh ?? 0);
  f.perch = { o, zs, lvl: clamp(lvl, 1, zs.length + 1), z: 0, d: 0, holdT: 0, busy: 0.3, on: false, bx: f.x, by: f.y, aim0: f.aim };
  f.vx = f.vy = f.kx = f.ky = 0; f.dashT = 0;
  g.setRest(f, false);
  if (f.ai) f.ai.path = [];
  g.dust(f.x, f.y + 4, 2);
  if (f === g.focus()) { g.snd("click", f.x, f.y, 0.7); g.say(f.x, f.y - 30, "MEMANJAT!", "#8af0ff"); }
  g.hudDirty = true;
}

/** back down to the pavement (jump = straight over the railing) */
export function dismount(g: Game, f: Fighter, jump = false) {
  const p = f.perch;
  if (!p) return;
  perchDown(f, p);
  f.perch = null;
  f.vx = f.vy = f.kx = f.ky = 0;
  for (let k = 0; k < 6; k += 2) { f.scarf[k] = f.x; f.scarf[k + 1] = f.y; }
  g.dust(f.x, f.y + 4, jump ? 6 : 2);
  if (jump) { g.snd("thunk", f.x, f.y, 0.5); if (f === g.focus()) g.cam.shake = Math.min(10, g.cam.shake + 2.5); }
  g.hudDirty = true;
}

/** the player, on the pavement: pushing up against a front with a fire escape starts the climb */
export function perchTry(g: Game, f: Fighter, dt: number) {
  if (g.phase !== "live" || f.resting || f.dashT > 0) { g.perchT = 0; return; }
  const o = nyClimb(f.x, f.y);
  if (!o || kindAt(Math.floor(f.x / TILE), Math.floor((f.y - 10) / TILE)) !== 1) { g.perchT = 0; return; }
  if (!(g.iy < -0.5 && Math.abs(g.ix) < 0.6)) {
    g.perchT = 0;
    if (g.t - g.perchHintAt > 9) { g.perchHintAt = g.t; g.say(f.x, f.y - 28, "TAHAN [W]/ATAS: PANJAT BALKON", "#8af0ff"); }
    return;
  }
  g.perchT += dt;
  if (g.perchT < 0.26) return;
  g.perchT = 0;
  g.perchHintAt = g.t + 30;
  mount(g, f, o, 1);
}

function rung(g: Game, f: Fighter, p: Perch) {
  p.holdT = 0; p.busy = 0.3;
  g.snd("click", f.x, f.y, 0.5);
  g.hudDirty = true;
}

/** one frame of somebody on a building: you walk along the landing, climb and come down; friends hold their window and shoot */
export function perchTick(g: Game, f: Fighter, dt: number) {
  const p = f.perch;
  if (!p) return;
  const o = p.o, top = p.zs.length + 1;
  if (g.phase === "end" || g.phase === "over" || f.gone) { dismount(g, f); return; }
  let moved = false;
  if (f.isPlayer) {
    if (g.wantDash) { g.wantDash = false; dismount(g, f, true); return; } // over the railing
    const up = perchUp(g, f);
    g.controlPlayer(f);
    if (up) perchDown(f, up);
    if (g.phase === "live") {
      const ix = g.ix, iy = g.iy;
      p.busy -= dt;
      if (Math.abs(ix) > 0.3) {
        const nx = clamp(f.x + Math.sign(ix) * 46 * dt, o.x + 5, o.x + o.w - 5);
        moved = nx !== f.x;
        f.x = nx;
      }
      const roofMax = Math.max(0, o.h - (o.fh ?? 0) - 12);
      if (iy < -0.5) {
        if (p.lvl === top) { if (p.d < roofMax) { p.d = Math.min(roofMax, p.d + 38 * dt); moved = true; } }
        else if (p.busy <= 0 && (p.holdT += dt) > 0.2) { p.lvl++; rung(g, f, p); }
      } else if (iy > 0.5) {
        if (p.lvl === top && p.d > 0) { p.d = Math.max(0, p.d - 38 * dt); moved = true; }
        else if (p.busy <= 0 && (p.holdT += dt) > 0.2) {
          if (p.lvl > 1) { p.lvl--; rung(g, f, p); }
          else { dismount(g, f); return; }
        }
      } else p.holdT = 0;
    }
  } else if (g.phase === "live") g.controlBot(f, dt);
  const zt = zOf(p), dz = zt - p.z;
  p.z = Math.abs(dz) < 0.4 ? zt : p.z + dz * Math.min(1, dt * 7);
  const up = perchUp(g, f);
  g.tickFighter(f, 0, 0, dt);
  if (up) perchDown(f, up);
  f.vx = f.vy = f.kx = f.ky = 0;
  if (moved || Math.abs(dz) > 1.5) { f.moving = true; f.walkT += dt * 0.6; }
}

/** your friends - and the people you found - follow you up, and come down when you do */
export function perchSquad(g: Game) {
  const pl = g.player, pp = pl && pl.alive ? pl.perch : null;
  if (!pl || !pp) {
    for (const f of g.fighters) if (!f.isPlayer && f.perch && f.alive) dismount(g, f);
    return;
  }
  let n = 0;
  for (const f of g.fighters) if (!f.isPlayer && f.perch) { if (f.perch.o !== pp.o && f.alive) dismount(g, f); else n++; }
  const o = pp.o, top = pp.zs.length + 1;
  for (const f of g.fighters) {
    if (f.isPlayer || !f.alive || f.gone || f.team !== pl.team || f.perch || (f.civ && f.hid)) continue;
    if (Math.hypot(f.x - pl.x, f.y - pl.y) > 64) continue;
    let x = clamp(pl.x + [16, -16, 30, -30, 44, -44, 58, -58][n % 8], o.x + 6, o.x + o.w - 6);
    if (kindAt(Math.floor(x / TILE), Math.floor(pl.y / TILE)) !== 0) x = pl.x;
    f.x = x; f.y = pl.y;
    mount(g, f, o, 1 + ((pp.lvl + n) % top));
    n++;
  }
}

/** drawn over the legs of somebody standing on a landing (the railing) or at the edge of a roof (the coping) */
export function perchRail(g: Game, f: Fighter, p: Perch) {
  const ctx = g.ctx, x = Math.round(f.x) - g.cl, y = Math.round(f.y) - g.ct + 6;
  if (p.lvl > p.zs.length) {
    if (p.d < 3 && Math.abs(zOf(p) - p.z) < 2) {
      ctx.fillStyle = "rgba(226,224,212,0.6)"; ctx.fillRect(x - 8, y - 1, 16, 1);
      ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.fillRect(x - 8, y, 16, 1);
    }
    return;
  }
  if (Math.abs(zOf(p) - p.z) > 2) return; // still on the ladder
  ctx.fillStyle = "#1b1d25";
  ctx.fillRect(x - 9, y - 7, 18, 1);
  for (let i = -8; i <= 8; i += 4) ctx.fillRect(x + i, y - 6, 1, 6);
  ctx.fillRect(x - 9, y, 18, 1);
}

/** where a line from (sx, sy) along (dx, dy) enters a box: 0..1 along the line, -1 = it misses */
function segBox(sx: number, sy: number, dx: number, dy: number, x0: number, y0: number, x1: number, y1: number): number {
  let k0 = 0, k1 = 1;
  for (const [s, d, lo, hi] of [[sx, dx, x0, x1], [sy, dy, y0, y1]]) {
    if (Math.abs(d) < 1e-6) { if (s < lo || s > hi) return -1; continue; }
    let a = (lo - s) / d, b = (hi - s) / d;
    if (a > b) [a, b] = [b, a];
    k0 = Math.max(k0, a); k1 = Math.min(k1, b);
    if (k0 > k1) return -1;
  }
  return k0;
}

/**
 * A shot fired from up on a building (f is lifted; (sx, sy) = the muzzle; da = how far this round strays).
 * It goes down to where the crosshair lies in the street, and through whoever stands in its way there.
 * Seen from above a body is a box standing on its feet, so the line comes in through the top of it: heads are easy from up here.
 */
export function perchShot(g: Game, f: Fighter, w: WeaponDef, sx: number, sy: number, da: number) {
  const p = f.perch;
  if (!p) return;
  let tx: number, ty: number;
  const t = f.ai?.target;
  if (f.isPlayer && !g.useTouch) { tx = g.mx + g.cl; ty = g.my + g.ct; }
  else if (!f.isPlayer && t && t.alive) { tx = t.x; ty = t.y - 5; }
  else {
    // no crosshair: whatever stands closest to the line of fire
    let best: Bug | null = null, bd = 1e9;
    for (const z of g.bug.bugs) {
      const ax = z.x - sx, ay = z.y - 5 - sy, d = Math.hypot(ax, ay);
      if (d > 300 || d >= bd) continue;
      const a = Math.atan2(ay, ax) - f.aim;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.4) { bd = d; best = z; }
    }
    if (best) { tx = best.x; ty = best.y - 5; }
    else { const far = 110 + p.z; tx = sx + Math.cos(f.aim) * far; ty = sy + Math.sin(f.aim) * far; }
  }
  let dx = tx - sx, dy = ty - sy;
  const ca = Math.cos(da), sa = Math.sin(da);
  [dx, dy] = [dx * ca - dy * sa, dx * sa + dy * ca];
  let L = Math.hypot(dx, dy) || 1;
  const range = w.speed * w.life * 1.1 + p.z * 0.6;
  if (L > range) { dx *= range / L; dy *= range / L; L = range; }
  const ux = dx / L, uy = dy / L, ang = Math.atan2(uy, ux), rocket = w.id === "bazooka";
  const hits: { z: Bug; k: number; head: boolean }[] = [];
  if (!rocket)
    for (const z of g.bug.bugs) {
      const info = BUG[z.kind], low = z.state === "down" || (z.limp ?? 0) >= 2 || z.kind === "dog";
      const R = info.r + 3, hh = low ? 8 : info.r * 3 + 2;
      const k = segBox(sx, sy, dx, dy, z.x - R, z.y - hh, z.x + R, z.y + 2);
      if (k >= 0) hits.push({ z, k, head: !low && sy + dy * k < z.y - hh * 0.5 });
    }
  hits.sort((a, b) => a.k - b.k);
  let end = 1, n = 0;
  for (const h of hits) {
    const kind = h.z.kind;
    const head = kind !== "charger" && kind !== "dog" && (h.head || (w.id === "pistol" && Math.random() < 0.45));
    const mul = head ? (kind === "titan" ? 1.8 : kind === "tank" ? 1.6 : w.id === "shotgun" ? 2 : 3) : 1.1;
    g.bug.hurt(h.z, w.dmg * mul, f, w.id, ang, w.knock * 0.6, false, head, head ? 0 : 1);
    n++;
    if (!w.pierce || n >= 3) { end = h.k; break; }
  }
  const ex = sx + dx * end, ey = sy + dy * end;
  g.tracers.push({ x0: sx + ux * 5, y0: sy + uy * 5, x1: ex, y1: ey, life: w.id === "sniper" ? 0.22 : 0.1, color: w.id === "goldgun" ? "#ffd700" : w.id === "pistol" ? "#ffe9a0" : "#ffd27a" });
  if (rocket) {
    // the rocket leaves a thread of smoke and goes off down there
    for (let d = 12; d < L; d += 14) g.puff(sx + ux * d, sy + uy * d, 1, ["#ffffff", "#e3ddd0", "#b9b3a8"], 8, { z: 4, vz: 8, max: 0.5, size: 2, grav: -18, drag: 2 });
    g.blast(ex, ey, f, 46, w.dmg, w.knock, "bazooka", false);
    return;
  }
  if (!n || end === 1) {
    // it ends in the street
    g.hitFx(ex, ey, ang, 4, 0);
    g.puff(ex, ey, 3, ["#d9d2c2", "#8a8478", "#5a5c68"], 34, { z: 1, vz: 40, max: 0.32, size: 1, grav: 160 });
  }
}

import { MAX_HP } from "./defs";
import type { Fighter, Game } from "./engine";
import { LOOK_PAL, drawText } from "./sprites";

/**
 * More to read in a face than pain and rage: dozing, dizzy, out of breath, startled, laughing, a wink after a good shot,
 * the hard little grin of somebody in a firefight, running flat out, whistling when nothing is wrong.
 * 0 = nothing special (the plain faces take over).
 */
export function moodX(g: Game, f: Fighter): number {
  if (f.ouch > 0 || f.mad > 0 || f.sad > 0 || f.swingT > 0 || f.recoil > 0.25) return 0;
  if (f.restK > 0.6) return 1;
  if (f.hp < 22) return 2;
  if (f.exh || (f.isPlayer && f.stam < 24)) return 3;
  if (f.fear > 1.2) return 4;
  if (f.joy > 0.9) return 5;
  if (f.joy > 0.12) return (f.id + Math.floor(g.t * 0.5)) % 2 ? 6 : 0;
  if (f.loud > 0.25) return 7;
  if (f.runK > 0.6 && f.moving) return 8;
  if (f.fear <= 0 && f.hp > 50 && (g.t * 0.11 + f.id * 0.618) % 1 < 0.14) return 9;
  return 0;
}

/** draw one of those faces onto a head whose top-left corner is at (ox, oy). Returns false when the plain face should be drawn instead. */
export function faceX(g: Game, f: Fighter, ox: number, oy: number): boolean {
  const m = moodX(g, f);
  if (!m) return false;
  const ctx = g.ctx, t = g.t, skin = LOOK_PAL[f.look][f.skin].F, dark = "#1a1014", red = "#4a0c14";
  const shades = f.look === 2 && f.skin === 4, mask = f.look === 2 && f.skin === 3;
  const e0 = ox + 3, e1 = ox + 8, ey = oy + 6, mx = ox + 5, my = oy + 8;
  const P = (c: string, x: number, y: number, w = 1, h = 1) => { ctx.fillStyle = c; ctx.fillRect(x, y, w, h); };
  if (!shades) {
    if (m === 1 || m === 3) {
      // shut (dozing) or half shut (worn out), the inner brows up
      for (const x of [e0, e1]) { P(skin, x, ey - 1, 2, 2); P(dark, x, ey, 2, 1); }
      if (m === 3) { P(dark, e0 + 1, ey - 2); P(dark, e1, ey - 2); }
    } else if (m === 2) {
      // the eyes roll
      for (const x of [e0, e1]) { const k = Math.floor(t * 9 + x) % 4; P("#ffffff", x, ey - 1, 2, 2); P(dark, x + (k === 1 || k === 2 ? 1 : 0), ey - (k < 2 ? 1 : 0)); }
    } else if (m === 4) {
      // wide open, brows shot up
      for (const x of [e0, e1]) { P("#ffffff", x, ey - 2, 2, 3); P(dark, x + (x === e0 ? 1 : 0), ey - 1); P(dark, x, ey - 4, 2, 1); }
    } else if (m === 5) {
      // squeezed shut with laughing
      for (const x of [e0, e1]) P(skin, x, ey - 1, 2, 2);
      P(dark, e0, ey); P(dark, e0 + 1, ey - 1); P(dark, e1, ey - 1); P(dark, e1 + 1, ey);
    } else if (m === 6) {
      // a wink
      P(skin, e0, ey - 1, 2, 2); P(dark, e0, ey, 2, 1);
    } else if (m === 7) {
      // narrowed, the brows drawn together
      for (const x of [e0, e1]) P(skin, x, ey - 1, 2, 1);
      P(dark, e0, ey - 2); P(dark, e0 + 1, ey - 1); P(dark, e1 + 1, ey - 2); P(dark, e1, ey - 1);
    }
  }
  if (!mask) {
    if (m === 1) P(red, mx + 1, my, 2, Math.sin(t * 2 + f.id) > 0 ? 2 : 1);
    else if (m === 2) { for (let i = 0; i < 4; i++) P(dark, mx + i, my + ((i + Math.floor(t * 6)) % 2)); }
    else if (m === 3) { const open = Math.sin(t * 11 + f.id) > 0; P(red, mx + 1, my, 2, open ? 2 : 1); if (open) P("#e88aa0", mx + 1, my + 1, 2, 1); }
    else if (m === 4) P(red, mx + 1, my, 2, 2);
    else if (m === 5) { const big = Math.sin(t * 16 + f.id) > 0; P(red, mx, my, 4, big ? 3 : 2); P("#ffffff", mx, my, 4, 1); }
    else if (m === 6) { P(dark, mx + 1, my, 3, 1); P(dark, mx + 4, my - 1); P("#ffffff", mx + 2, my); }
    else if (m === 7) { P(dark, mx, my, 4, 1); P("#ffffff", mx + 1, my, 2, 1); P(dark, mx + 4, my - 1); }
    else if (m === 8) { const open = Math.sin(f.walkT * 24) > 0; P(red, mx + 1, my, 2, open ? 2 : 1); }
    else if (m === 9) { P(red, mx + 3, my, 1, 2); P(skin, mx + 4, my, 1, 1); }
  }
  if (m === 3) {
    // sweat down both temples, a flushed face
    const k = (t * 1.8 + f.id * 0.3) % 1, k2 = (k + 0.5) % 1;
    P("#8fd0ff", ox + 12, oy + 2 + Math.round(k * 5), 1, 2); P("#8fd0ff", ox + 1, oy + 3 + Math.round(k2 * 5), 1, 2);
    P("#ff8a8a", ox + 2, ey + 1); P("#ff8a8a", ox + 11, ey + 1);
  } else if (m === 5 || m === 6 || m === 9) { P("#ff9aa5", ox + 2, ey + 1); P("#ff9aa5", ox + 11, ey + 1); }
  return true;
}

/** what floats over a head: Zs, circling stars, a puff of breath, a "!", sparks of laughter, a whistled note - and speed lines behind a runner */
export function emote(g: Game, f: Fighter, x: number, y: number) {
  if (f.look < 2 || !f.alive) return;
  const m = moodX(g, f), ctx = g.ctx, t = g.t;
  const P = (c: string, px: number, py: number, w = 1, h = 1) => { ctx.fillStyle = c; ctx.fillRect(px, py, w, h); };
  const top = y - 27 - (f.isPlayer ? 6 : 0) - (f.hp < MAX_HP ? 4 : 0);
  if (m === 1) {
    for (let i = 0; i < 3; i++) {
      const k = (t * 0.6 + i / 3) % 1;
      ctx.globalAlpha = 1 - k;
      drawText(ctx, "Z", x + 7 + Math.round(k * 8 + Math.sin(k * 9) * 2), top + 8 - Math.round(k * 14), "#bfe2ff");
    }
  } else if (m === 2) {
    for (let i = 0; i < 3; i++) { const a = t * 6 + i * 2.094; P(i ? "#ffe45c" : "#ffffff", x + Math.round(Math.cos(a) * 7), y - 17 + Math.round(Math.sin(a) * 2.5), 2, 2); }
  } else if (m === 3) {
    const k = (t * 1.5 + f.id * 0.37) % 1, dir = Math.cos(f.aim) < 0 ? -1 : 1;
    ctx.globalAlpha = (1 - k) * 0.8;
    P("#ffffff", x + dir * (7 + Math.round(k * 6)), y - 6 - Math.round(k * 3), 2 + Math.round(k * 2), 2);
  } else if (m === 4) {
    const b = Math.round(Math.abs(Math.sin(t * 14)) * 2);
    P("#0a0a0f", x - 2, top - 3 - b, 4, 9); P("#ffe45c", x - 1, top - 2 - b, 2, 4); P("#ffe45c", x - 1, top + 3 - b, 2, 2);
  } else if (m === 5) {
    for (let i = 0; i < 2; i++) {
      const k = (t * 2.2 + i * 0.5) % 1, s = i ? 1 : -1;
      ctx.globalAlpha = 1 - k;
      P("#ffe45c", x + s * (9 + Math.round(k * 4)), y - 14 - Math.round(k * 6), 2, 1); P("#ffe45c", x + s * (10 + Math.round(k * 4)) - (s > 0 ? 1 : 0), y - 15 - Math.round(k * 6), 1, 3);
    }
  } else if (m === 9) {
    const k = (t * 0.9 + f.id * 0.21) % 1, nx = x + 8 + Math.round(k * 7), ny = y - 16 - Math.round(k * 10 + Math.sin(k * 12) * 2);
    ctx.globalAlpha = 1 - k * 0.8;
    P("#0a0a0f", nx - 1, ny - 1, 5, 7); P("#8af0ff", nx + 2, ny, 1, 4); P("#8af0ff", nx, ny + 3, 3, 2); P("#8af0ff", nx + 2, ny, 2, 1);
  }
  ctx.globalAlpha = 1;
  if (f.runK > 0.7 && f.moving && !f.perch) {
    const dir = f.vx >= 0 ? -1 : 1;
    ctx.globalAlpha = 0.5;
    for (let i = 0; i < 2; i++) { const k = (t * 5 + i * 0.5) % 1; P("#ffffff", x + dir * (8 + Math.round(k * 8)), y - 8 + i * 6, 4 - Math.round(k * 3), 1); }
    ctx.globalAlpha = 1;
  }
}

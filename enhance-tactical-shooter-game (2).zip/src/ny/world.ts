import { MH, MW, Spr, T, hash2, mkCanvas, mulberry32, outline, pick, pix, ri, textW } from './util';
import {
  COBBLE, CROSS_H, CROSS_V, DIRT, GRASS, ICE, LAKE, MINI_COL, PATH, PLAZA, REDPAVE, RH_B, RH_T, ROAD, RV_L, RV_R, SIDEWALK, WATER, WOOD, isRoad,
} from './tiles';
import { CarType, Props } from './sprites';
import * as B from './buildings';
import { classify } from './interior';

export interface Obj {
  k: 0;
  x: number;
  y: number;
  w: number;
  h: number;
  sy: number;
  spr?: Spr;
  make?: () => Spr;
  fade?: boolean;
  /** a building standing on its lot: the height of its front, and how deep the lot is (px) */
  fh?: number;
  dp?: number;
  /** parked 3D car metadata */
  car?: { kind: number; body: string; len: number; sign?: string; dir: number };
  dyn?: number; // 1 traffic light, 2 steam
  a?: number;
  stamp?: number;
}
export interface Inter { x: number; y: number; n: boolean; e: boolean; s: boolean; w: boolean }
export interface Landmark { name: string; x: number; y: number; r: number; info: string }
export interface Station { name: string; x: number; y: number }
export interface Trigger { x: number; y: number; w: number; h: number; label: string; tx: number; ty: number }
export interface Spot { kind: string; x: number; y: number; n?: number; v?: number; w?: number; h?: number }
export interface Door { x: number; y: number; kind: string; name: string; seed: number }
export interface BoatDef { c: HTMLCanvasElement; x: number; y: number; vx: number; vy: number; a: number; b: number }

export interface World {
  tiles: Uint8Array;
  gfx: Uint16Array;
  solid: Uint8Array;
  npcOk: Uint8Array;
  zone: Int16Array;
  core: Int16Array;
  inters: Inter[];
  objs: Obj[];
  buckets: Obj[][];
  bw: number;
  bh: number;
  landmarks: Landmark[];
  stations: Station[];
  triggers: Trigger[];
  spots: Spot[];
  lanes: number[];
  boats: BoatDef[];
  doors: Door[];
  mini: HTMLCanvasElement;
  start: { x: number; y: number };
  district: (tx: number, ty: number) => string;
}

export const BUCKET = 128;

const DN: string[][] = [
  ['Harlem', 'Harlem', 'Harlem', 'East Harlem', 'East Harlem'],
  ['Upper West Side', 'Central Park', 'Central Park', 'Central Park', 'Upper East Side'],
  ['Upper West Side', 'Central Park', 'Central Park', 'Central Park', 'Upper East Side'],
  ['Upper West Side', 'Central Park', 'Central Park', 'Central Park', 'Upper East Side'],
  ["Hell's Kitchen", 'Theater District', 'Rockefeller Center', 'Fifth Avenue', 'Midtown East'],
  ["Hell's Kitchen", 'Times Square', 'Bryant Park', 'Grand Central', 'Turtle Bay'],
  ['Hudson Yards', 'Penn Station', 'Midtown South', 'Koreatown', 'Kips Bay'],
  ['Chelsea', 'Chelsea', 'Flatiron District', 'Gramercy', 'Stuyvesant Town'],
  ['West Village', 'Greenwich Village', 'Washington Square', 'East Village', 'Alphabet City'],
  ['Tribeca', 'SoHo', 'Little Italy', 'Chinatown', 'Lower East Side'],
  ['World Trade Center', 'Financial District', 'Wall Street', 'Financial District', 'South Street Seaport'],
];

function district(tx: number, ty: number): string {
  if (tx >= 152) return 'DUMBO, Brooklyn';
  if (ty >= 201 && tx < 34) return 'Liberty Island';
  if (tx >= 126 && ty >= 164 && ty < 176) return 'Brooklyn Bridge';
  if (tx < 18 || tx > 125) return tx < 18 ? 'Hudson River' : 'East River';
  if (ty >= 188) return 'Battery Park';
  if (tx >= 44 && tx < 100 && ty >= 28 && ty < 72) return 'Central Park';
  const k = Math.max(0, Math.min(4, Math.floor((tx - 20) / 20)));
  const j = Math.max(0, Math.min(10, Math.floor((ty - 8) / 16)));
  return DN[j][k];
}

interface Cfg {
  st: number[];
  h: [number, number];
  ov: [number, number];
  names?: string[];
  awn?: string[];
  marq?: number;
  boards?: number;
  vs?: string[];
}

const C: Record<string, Cfg> = {
  harlem: { st: [1, 1, 0, 0, 5], h: [88, 132], ov: [0, 10] },
  uws: { st: [0, 1, 3, 5, 3], h: [112, 166], ov: [0, 24] },
  ues: { st: [3, 1, 3, 5], h: [112, 170], ov: [0, 28] },
  hk: { st: [0, 0, 5, 2, 6], h: [96, 164], ov: [0, 24] },
  theater: { st: [0, 3, 2, 3], h: [130, 188], ov: [10, 40], marq: 0.55, boards: 0.45 },
  midtown: { st: [2, 2, 3, 3, 5], h: [160, 228], ov: [20, 56] },
  ktown: { st: [0, 5, 2, 3], h: [120, 178], ov: [6, 30], names: ['K-BBQ', 'KARAOKE', 'K-POP', 'BIBIMBAP', 'TOFU', 'SOJU', 'BOBA', 'K-BEAUTY'], vs: ['BBQ', 'KTV', 'SPA'] },
  chelsea: { st: [0, 6, 4, 5, 2], h: [96, 154], ov: [0, 20], names: ['GALLERY', 'ART', 'VINYL', 'MARKET', 'COFFEE', 'BAGELS', 'BOOKS', 'LOFT'] },
  village: { st: [1, 0, 0, 1, 4], h: [86, 122], ov: [0, 8], names: ['JAZZ', 'COMEDY', 'RECORDS', 'CAFE', 'BOOKS', 'PIZZA', 'TATTOO', 'BAR', 'VINTAGE'] },
  evill: { st: [0, 0, 0, 4, 1], h: [88, 130], ov: [0, 8], names: ['TATTOO', 'VINYL', 'RAMEN', 'DIVE BAR', 'THRIFT', 'PIEROGI', 'PIZZA', 'BODEGA', 'PUNK'] },
  soho: { st: [4, 4, 4, 0, 6], h: [106, 144], ov: [0, 12], names: ['BOUTIQUE', 'DENIM', 'SHOES', 'GALLERY', 'COFFEE', 'SNEAKERS', 'ATELIER', 'STUDIO'] },
  tribeca: { st: [6, 4, 6, 0], h: [102, 144], ov: [0, 12] },
  italy: { st: [0, 0, 1, 0], h: [88, 126], ov: [0, 8], names: ['PIZZA', 'PASTA', 'CAFFE', 'GELATO', 'CANNOLI', 'TRATTORIA', 'ESPRESSO', 'VINO'], awn: ['#2f8a4a', '#f2f2f2', '#c0392b'] },
  china: { st: [7], h: [92, 132], ov: [0, 8], names: ['DIM SUM', 'NOODLES', 'TEA', 'DUMPLING', 'BAKERY', 'HERBS', 'GIFTS', 'BBQ DUCK'] },
  les: { st: [0, 0, 6, 4], h: [88, 130], ov: [0, 8] },
  fidi: { st: [2, 3, 3, 2], h: [170, 236], ov: [26, 60] },
  seaport: { st: [6, 0, 6], h: [88, 112], ov: [0, 6], names: ['SEAPORT', 'FISH MKT', 'OYSTERS', 'PIER 17', 'CHOWDER', 'ROPES', 'MAPS'] },
  bk: { st: [6, 6, 0], h: [96, 144], ov: [0, 10], names: ['PIZZA', 'COFFEE', 'DUMBO', 'BOOKS', 'BAGELS', 'ICE CREAM', 'LOFTS', 'VINYL'] },
};
const SHOWS = ['WICKED', 'HAMILTON', 'LION KING', 'CHICAGO', 'ALADDIN', 'SIX', 'CATS', 'PHANTOM', 'HADESTOWN', 'MJ'];

function bullSprite(): Spr {
  const { c, g } = mkCanvas(24, 20);
  pix(g, 1, 1, [
    '.................d....',
    '.h..h......ll....d....',
    '.hbbh...llllbbb..d....',
    '.bbbbblllbbbbbbbd.....',
    'bbdbbbbbbbbbbbbbb.....',
    'bbbbbbbbbbbbbbbbb.....',
    '.bbb.bbbbbbbbbbbb.....',
    '..d..bbddddddbbb......',
    '.....bb......bb.......',
    '....bb.......bb.......',
    '....dd.......dd.......',
  ], { b: '#8a5a2b', l: '#c98b3f', d: '#5a3a1b', h: '#e8dcc0' });
  const g2 = c.getContext('2d')!;
  g2.fillStyle = '#a9a294';
  g2.fillRect(3, 13, 18, 5);
  g2.fillStyle = '#8f887b';
  g2.fillRect(3, 17, 18, 1);
  outline(c);
  return { c };
}

export function generateWorld(P: Props, cars: CarType[]): World {
  const r = mulberry32(20240625);
  const N = MW * MH;
  const tiles = new Uint8Array(N);
  const solid = new Uint8Array(N);
  const reserved = new Uint8Array(N);
  const zone = new Int16Array(N);
  const core = new Int16Array(N);
  const objs: Obj[] = [];
  const inters: Inter[] = [];
  const landmarks: Landmark[] = [];
  const stations: Station[] = [];
  const triggers: Trigger[] = [];
  const spots: Spot[] = [];
  const doors: Door[] = [];
  const door = (x: number, y: number, kind: string, name: string) => doors.push({ x, y, kind, name, seed: ri(r, 1, 1e9) });

  const I = (x: number, y: number) => y * MW + x;
  const inb = (x: number, y: number) => x >= 0 && y >= 0 && x < MW && y < MH;
  const setT = (x: number, y: number, t: number) => {
    if (inb(x, y)) tiles[I(x, y)] = t;
  };
  const getT = (x: number, y: number) => (inb(x, y) ? tiles[I(x, y)] : WATER);
  const fill = (x: number, y: number, w: number, h: number, t: number, only = -1) => {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (only < 0 || getT(xx, yy) === only) setT(xx, yy, t);
  };
  const block = (x: number, y: number, w: number, h: number) => {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (inb(xx, yy)) solid[I(xx, yy)] |= 1;
  };
  const reserve = (x: number, y: number, w: number, h: number) => {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (inb(xx, yy)) reserved[I(xx, yy)] = 1;
  };
  const ellT = (cx: number, cy: number, rx: number, ry: number, t: number, only = -1) => {
    for (let y = Math.floor(cy - ry); y <= cy + ry; y++)
      for (let x = Math.floor(cx - rx); x <= cx + rx; x++) {
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1 && (only < 0 || getT(x, y) === only)) setT(x, y, t);
      }
  };
  const promenade = () => {
    const ch: number[] = [];
    for (let y = 2; y < MH - 2; y++)
      for (let x = 2; x < MW - 2; x++) {
        if (tiles[I(x, y)] !== GRASS) continue;
        let near = false;
        for (let dy = -2; dy <= 2 && !near; dy++) for (let dx = -2; dx <= 2; dx++) if (tiles[I(x + dx, y + dy)] === WATER) {
          near = true;
          break;
        }
        if (near) ch.push(I(x, y));
      }
    for (const i of ch) tiles[i] = PLAZA;
  };

  // ------------------------------------------------------------ land
  fill(18, 6, 108, 182, SIDEWALK);
  for (let y = 188; y < 200; y++) {
    const xl = 18 + Math.floor((y - 188) * 1.2);
    const xr = 125 - Math.floor((y - 188) * 2.2);
    fill(xl, y, xr - xl + 1, 1, y < 190 ? SIDEWALK : GRASS);
  }
  fill(152, 140, 24, 66, SIDEWALK);
  ellT(15, 211, 11, 7, GRASS);
  fill(126, 166, 26, 2, WOOD);
  fill(126, 172, 26, 2, WOOD);

  // ------------------------------------------------------------ roads
  interface VS { x: number; y0: number; y1: number }
  interface HS { y: number; x0: number; x1: number }
  const vs: VS[] = [];
  const hs: HS[] = [];
  for (let k = 0; k <= 5; k++) {
    const x = 20 + 20 * k;
    if (k === 2 || k === 3) vs.push({ x, y0: 8, y1: 27 }, { x, y0: 72, y1: 187 });
    else vs.push({ x, y0: 8, y1: 187 });
  }
  for (let j = 0; j <= 11; j++) {
    const y = 8 + 16 * j;
    if (j === 2 || j === 3) hs.push({ y, x0: 20, x1: 43 }, { y, x0: 100, x1: 123 });
    else if (j === 10) hs.push({ y, x0: 20, x1: 163 });
    else hs.push({ y, x0: 20, x1: 123 });
  }
  vs.push({ x: 160, y0: 146, y1: 199 });
  const vr = new Uint8Array(N);
  const hr = new Uint8Array(N);
  for (const s of vs) for (let y = s.y0; y <= s.y1; y++) for (let c = 0; c < 4; c++) vr[I(s.x + c, y)] = c + 1;
  for (const s of hs) for (let x = s.x0; x <= s.x1; x++) for (let c = 0; c < 4; c++) hr[I(x, s.y + c)] = c + 1;
  for (let i = 0; i < N; i++) {
    if (vr[i] && hr[i]) tiles[i] = ROAD;
    else if (vr[i]) tiles[i] = vr[i] === 2 ? RV_L : vr[i] === 3 ? RV_R : ROAD;
    else if (hr[i]) tiles[i] = hr[i] === 2 ? RH_T : hr[i] === 3 ? RH_B : ROAD;
  }
  for (const v of vs)
    for (const h of hs) {
      if (!(v.x >= h.x0 && v.x + 3 <= h.x1 && h.y >= v.y0 && h.y + 3 <= v.y1)) continue;
      const it: Inter = { x: v.x, y: h.y, n: v.y0 < h.y, s: v.y1 > h.y + 3, w: h.x0 < v.x, e: h.x1 > v.x + 3 };
      inters.push(it);
      const id = inters.length;
      for (let yy = 0; yy < 4; yy++) for (let xx = 0; xx < 4; xx++) core[I(v.x + xx, h.y + yy)] = id;
      for (let yy = -2; yy < 6; yy++) for (let xx = -2; xx < 6; xx++) if (inb(v.x + xx, h.y + yy)) zone[I(v.x + xx, h.y + yy)] = id;
      if (it.n) fill(v.x, h.y - 2, 4, 2, CROSS_V);
      if (it.s) fill(v.x, h.y + 4, 4, 2, CROSS_V);
      if (it.w) fill(v.x - 2, h.y, 2, 4, CROSS_H);
      if (it.e) fill(v.x + 4, h.y, 2, 4, CROSS_H);
    }

  // ------------------------------------------------------------ helpers
  const lot = (tx: number, ty: number, wt: number, dt: number, o: Partial<B.BOpt> & { h: number; style: number }, ov = 0) => {
    ov = Math.max(ov, o.h - dt * T + 36); // every front keeps a proper roof on top of it
    const hpx = dt * T + ov;
    const W = wt * T;
    const by = (ty + dt) * T;
    if (!o.garage) {
      if (o.style === 1) {
        o.doorOff = ri(r, -(W >> 3), W >> 3);
        door(tx * T + (W >> 1) + o.doorOff, by, 'home', 'APARTMENT');
      } else if (o.style === 2 || o.style === 3) {
        door(tx * T + (W >> 1), by, o.marquee ? 'theater' : 'lobby', o.marquee ?? pick(r, ['HOTEL', 'OFFICE TOWER', 'BANK', 'GRAND HOTEL', 'TOWER LOBBY', 'OFFICES']));
      } else {
        o.doorL = r() < 0.5;
        if (o.shop === undefined) {
          o.shop = '';
          const list = o.names ?? B.SHOPS;
          for (let i = 0; i < 8; i++) {
            const n = pick(r, list);
            if (textW(n) <= W - 6) {
              o.shop = n;
              break;
            }
          }
        }
        const nm = o.marquee ?? (o.shop || 'SHOP');
        door(tx * T + (o.doorL ? 6 : W - 7), by, o.marquee ? 'theater' : classify(nm), nm);
      }
    }
    const opt = { ...o, wt, hpx, seed: ri(r, 1, 1e9) } as B.BOpt;
    objs.push({ k: 0, x: tx * T, y: (ty + dt) * T - hpx, w: wt * T, h: hpx, sy: (ty + dt) * T, make: () => B.building(opt), fade: true, fh: Math.min(o.h, hpx), dp: dt * T });
    block(tx, ty, wt, dt);
  };
  const put = (spr: Spr, tx: number, ty: number, wt: number, dt: number, o: { solid?: boolean; fade?: boolean; dx?: number; dy?: number; sy?: number; fh?: number; dp?: number } = {}) => {
    const x = Math.round(tx * T + (wt * T - spr.c.width) / 2 + (o.dx ?? 0));
    const y = (ty + dt) * T - spr.c.height + (o.dy ?? 0);
    objs.push({ k: 0, x, y, w: spr.c.width, h: spr.c.height, sy: o.sy ?? (ty + dt) * T, spr, fade: o.fade ?? spr.c.height > dt * T + 8, fh: o.fh, dp: o.dp ?? dt * T });
    if (o.solid !== false) block(tx, ty, wt, dt);
    reserve(tx, ty, wt, dt);
  };
  const prop = (spr: Spr, px: number, py: number, solidTile = false, dyn = 0, a = 0) => {
    objs.push({ k: 0, x: Math.round(px - spr.c.width / 2), y: Math.round(py - spr.c.height), w: spr.c.width, h: spr.c.height, sy: py, spr, dyn, a });
    if (solidTile && inb(px >> 4, (py - 1) >> 4)) solid[I(px >> 4, (py - 1) >> 4)] |= 1;
  };
  const propT = (spr: Spr, tx: number, ty: number, solidTile = false) => prop(spr, tx * T + 8, ty * T + 14, solidTile);
  const flat = (spr: Spr, tx: number, ty: number) => objs.push({ k: 0, x: tx * T, y: ty * T, w: spr.c.width, h: spr.c.height, sy: ty * T - 4, spr });
  const treeAt = (tx: number, ty: number, set: Spr[]) => {
    if (!inb(tx, ty) || solid[I(tx, ty)] || reserved[I(tx, ty)]) return;
    prop(pick(r, set), tx * T + 8, ty * T + 15, true);
  };
  const parkTree = (tx: number, ty: number) => {
    const q = r();
    treeAt(tx, ty, q < 0.7 ? P.trees : q < 0.9 ? P.autumn : q < 0.96 ? P.cherry : [P.pine]);
  };
  const scatter = (x: number, y: number, w: number, h: number, p: number) => {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (getT(xx, yy) === GRASS && r() < p) parkTree(xx, yy);
  };
  const lm = (name: string, x: number, y: number, rad: number, info: string) => landmarks.push({ name, x, y, r: rad, info });
  const spot = (kind: string, tx: number, ty: number, o: Partial<Spot> = {}) => spots.push({ kind, x: tx * T + 8, y: ty * T + 10, ...o });
  const vendor = (tx: number, ty: number, v: number) => {
    put(P.carts[v], tx, ty, 2, 1, { fade: false });
    spots.push({ kind: 'vendor', x: (tx + 2) * T + 8, y: ty * T + 12, v });
  };
  const station = (name: string, tx: number, ty: number) => {
    put(P.subway, tx, ty, 2, 1, { fade: false });
    reserve(tx - 1, ty - 1, 5, 3);
    stations.push({ name, x: (tx + 2) * T + 8, y: ty * T + 10 });
  };
  const rowLots = (x0: number, x1: number, by: number, cfg: Cfg) => {
    let x = x0;
    while (x < x1) {
      let w = ri(r, 3, 5);
      if (x1 - x - w < 3) w = x1 - x;
      const h = ri(r, cfg.h[0], cfg.h[1]);
      const ov = Math.max(ri(r, cfg.ov[0], cfg.ov[1]), h - 128 + ri(r, 36, 70)); // a roof of 36-70 px above the taller front
      const o: Partial<B.BOpt> & { h: number; style: number } = { h, style: pick(r, cfg.st), names: cfg.names, awn: cfg.awn };
      if (cfg.marq && w >= 4 && r() < cfg.marq) {
        o.marquee = pick(r, SHOWS);
        o.style = pick(r, [0, 3, 0]);
      }
      if (cfg.boards && r() < cfg.boards) o.boards = true;
      if (cfg.vs && r() < 0.5) o.vsign = pick(r, cfg.vs);
      lot(x, by, w, 8, o, ov);
      x += w;
    }
  };

  // ------------------------------------------------------------ Central Park
  fill(46, 30, 52, 40, GRASS);
  ellT(73, 37, 12, 4.2, LAKE);
  ellT(58.5, 50, 6, 3.6, LAKE);
  ellT(63.5, 52, 4, 2.4, LAKE);
  ellT(90, 63, 3.2, 1.8, LAKE);
  const pth = (x: number, y: number, w: number, h: number) => {
    for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) setT(xx, yy, getT(xx, yy) === LAKE || getT(xx, yy) === WOOD ? WOOD : PATH);
  };
  pth(48, 31, 48, 2);
  pth(48, 66, 48, 2);
  pth(48, 31, 2, 37);
  pth(94, 31, 2, 37);
  pth(48, 43, 48, 2);
  pth(48, 56, 48, 2);
  pth(71, 43, 2, 25);
  pth(59, 43, 2, 15);
  pth(83, 43, 2, 25);
  for (const x of [55, 71, 87]) {
    pth(x, 30, 2, 1);
    pth(x, 68, 2, 2);
  }
  for (const y of [43, 56]) {
    pth(46, y, 2, 2);
    pth(96, y, 2, 2);
  }
  fill(67, 46, 10, 5, PLAZA);
  put(B.fountain(true), 70, 47, 3, 2);
  lm('Bethesda Fountain', 71, 49, 5, 'Air mancur "Angel of the Waters" — jantungnya Central Park sejak 1873.');
  lm('Bow Bridge', 60, 50, 3, 'Jembatan paling romantis di Central Park, langganan muncul di film.');
  lm('The Reservoir', 73, 43, 3, 'Waduk Jacqueline Kennedy Onassis, dikelilingi jalur jogging 2,5 km.');
  put(B.castle('#8f8a80'), 77, 45, 4, 3);
  lm('Belvedere Castle', 79, 49, 4, 'Kastil mini 1869 di atas batu Vista Rock. Stasiun cuaca resmi NYC!');
  fill(50, 36, 4, 4, PLAZA);
  flat(B.imagine(), 51, 37);
  lm('Strawberry Fields', 52, 38, 3, 'Mozaik "IMAGINE" untuk mengenang John Lennon.');
  ellT(87, 53, 2, 1.5, DIRT, GRASS);
  put(B.carriage(), 74, 70, 3, 1);
  vendor(68, 68, 0);
  vendor(46, 45, 1);
  vendor(96, 58, 3);
  vendor(74, 29, 2);
  reserve(46, 28, 52, 2);
  for (const [x, y] of [[66, 60], [80, 60], [52, 34], [90, 36]]) propT(P.rock, x, y, true);
  for (const y of [42, 55]) for (let x = 51; x < 94; x += 7) if (getT(x, y) === GRASS && !solid[I(x, y)]) {
    prop(P.bench, x * T + 8, y * T + 15, true);
    reserve(x, y, 1, 1);
  }
  for (const y of [45, 58, 33, 65]) for (let x = 53; x < 94; x += 6) if (getT(x, y) === GRASS) prop(P.lamp, x * T + 8, y * T + 6);
  for (let y = 30; y < 70; y++)
    for (let x = 46; x < 98; x++) {
      if (getT(x, y) !== GRASS) continue;
      const l1 = Math.pow((x - 89) / 5, 2) + Math.pow((y - 50) / 5.5, 2) <= 1;
      const l2 = Math.pow((x - 54) / 5, 2) + Math.pow((y - 61) / 4.2, 2) <= 1;
      if (l1 || l2) continue;
      const edge = x === 46 || x === 97 || y === 30 || y === 69;
      if (edge ? (x + y) % 2 === 0 : r() < 0.2) parkTree(x, y);
    }
  spot('crowd', 54, 61, { n: 12, w: 52 });
  spot('crowd', 89, 50, { n: 8, w: 56 });
  spot('crowd', 72, 49, { n: 8, w: 36 });
  spot('perf', 75, 49);
  spot('pigeons', 69, 49, { n: 6 });
  spot('pigeons', 72, 44, { n: 5 });
  spot('pigeons', 60, 57, { n: 5 });
  station('59 St · Central Park South', 66, 70);

  // ------------------------------------------------------------ blocks
  const blockFn = (j: number, k: number, bx: number, by: number) => {
    const all = (cfg: Cfg) => rowLots(bx, bx + 12, by, cfg);
    switch (j * 10 + k) {
      case 2:
        rowLots(bx, bx + 3, by, C.harlem);
        lot(bx + 3, by, 6, 8, { h: 140, style: 0, vsign: 'APOLLO', marquee: 'APOLLO', shop: '' }, 4);
        rowLots(bx + 9, bx + 12, by, C.harlem);
        lm('Apollo Theater', bx + 6, by + 9, 5, 'Panggung legendaris Harlem sejak 1934 — tempat lahirnya bintang soul & jazz.');
        station('125 St · Harlem', bx + 1, by + 9);
        break;
      case 20:
        put(B.museum({ wt: 12, hpx: 186, h: 112, wall: '#b08a7a', cols: 6, name: 'NATURAL HISTORY', banners: ['#2b5fb0', '#c0392b', '#2f8a4a', '#e8742b', '#8a3fb0'], steps: 10, seed: 5 }), bx, by, 12, 8, { fh: 112 });
        door((bx + 6) * T, (by + 8) * T, 'museum', 'MUSEUM OF NATURAL HISTORY');
        lm('Museum of Natural History', bx + 6, by + 9, 6, 'Museum raksasa dengan kerangka dinosaurus. Ingat film Night at the Museum?');
        station('81 St · Museum of Natural History', bx + 1, by + 9);
        spot('crowd', bx + 6, by + 8, { n: 6, w: 40 });
        break;
      case 14:
        put(B.guggenheim(), bx, by, 8, 8);
        rowLots(bx + 8, bx + 12, by, C.ues);
        door(bx * T + 88, (by + 8) * T, 'museum', 'GUGGENHEIM');
        lm('Guggenheim Museum', bx + 4, by + 9, 5, 'Museum spiral putih karya Frank Lloyd Wright (1959).');
        break;
      case 24:
        put(B.museum({ wt: 12, hpx: 182, h: 106, wall: '#d6ccb8', cols: 8, name: 'THE MET', banners: ['#c0392b', '#2b5fb0', '#c9a13b', '#c0392b', '#2b5fb0', '#c9a13b', '#c0392b'], steps: 12, ped: true, seed: 6 }), bx, by, 12, 8, { fh: 106 });
        door((bx + 6) * T, (by + 8) * T, 'museum', 'THE MET');
        lm('The Met', bx + 6, by + 9, 6, 'Metropolitan Museum of Art — salah satu museum seni terbesar di dunia.');
        station('86 St · Museum Mile', bx + 1, by + 9);
        spot('crowd', bx + 6, by + 8, { n: 8, w: 44 });
        spot('pigeons', bx + 8, by + 8, { n: 5 });
        break;
      case 42: {
        lot(bx, by, 4, 8, { h: 176, style: 3 }, 30);
        lot(bx + 8, by, 4, 8, { h: 176, style: 3 }, 30);
        put(B.tower({ wt: 4, tiers: [[0, 85], [6, 68], [12, 51]], wall: '#bfb5a5', seed: 30, rd: 14 }), bx + 4, by, 4, 4, { fh: 204 });
        fill(bx + 4, by + 4, 4, 4, PLAZA);
        fill(bx + 4, by + 5, 4, 2, ICE);
        put(B.xmasTree(), bx + 5, by + 4, 2, 1, { fade: false });
        prop(P.statueG, (bx + 4) * T + 8, (by + 5) * T - 2);
        prop(P.flagUS, (bx + 7) * T + 9, (by + 5) * T - 2);
        block(bx + 4, by + 4, 4, 1);
        put(B.rinkRail(64), bx + 4, by + 7, 4, 1, { fade: false });
        spots.push({ kind: 'skate', x: bx + 4, y: by + 5, w: 4, h: 2, n: 7 });
        for (let i = 0; i < 4; i++) prop(P.flags[i * 3], (bx + 3) * T + 20 + i * 16, (by + 8) * T + 3);
        lm('Rockefeller Center', bx + 6, by + 9, 5, 'Rumah bagi 30 Rock, arena ice skating & pohon Natal paling terkenal di dunia.');
        station('47-50 Sts · Rockefeller Ctr', bx + 1, by + 9);
        spot('crowd', bx + 6, by + 8, { n: 9, w: 36 });
        break;
      }
      case 43:
        rowLots(bx, bx + 3, by, C.midtown);
        put(B.cathedral({ wt: 6, hpx: 240, h: 140, wall: '#d9d4c8', spires: 2, seed: 3 }), bx + 3, by, 6, 8, { fh: 140 });
        rowLots(bx + 9, bx + 12, by, C.midtown);
        door((bx + 6) * T, (by + 8) * T, 'church', "ST. PATRICK'S");
        lm("St. Patrick's Cathedral", bx + 6, by + 9, 5, 'Katedral neo-gotik megah di Fifth Avenue, selesai 1878.');
        break;
      case 50:
        all(C.hk);
        fill(6, 100, 12, 2, WOOD);
        prop(B.boat(6), 3 * T + 106, 100 * T, false);
        lm('Intrepid Museum', 12, 101, 4, 'Kapal induk USS Intrepid yang disulap jadi museum laut, udara & antariksa.');
        break;
      case 51: {
        for (let i = 0; i < 3; i++) {
          const h = ri(r, 176, 212);
          lot(bx + i * 4, by, 4, 4, { h, style: pick(r, [2, 3, 2]), boards: true }, h - 40);
        }
        fill(bx, by + 4, 12, 4, PLAZA);
        fill(bx + 2, by + 6, 8, 2, REDPAVE);
        put(B.tkts(), bx + 5, by + 4, 3, 2, { fade: false });
        vendor(bx, by + 5, 0);
        vendor(bx + 10, by + 5, 1);
        spot('mascot', bx + 3, by + 7, { v: 0 });
        spot('mascot', bx + 8, by + 7, { v: 1 });
        spot('mascot', bx + 6, by + 8, { v: 2 });
        spot('cop', bx + 1, by + 8);
        spot('cop', bx + 11, by + 7);
        spot('perf', bx + 9, by + 7);
        spot('crowd', bx + 6, by + 7, { n: 22, w: 84 });
        spot('pigeons', bx + 4, by + 7, { n: 6 });
        lm('Times Square', bx + 6, by + 7, 7, 'Persimpangan dunia! Billboard raksasa menyala 24 jam nonstop.');
        station('Times Sq · 42 St', bx + 1, by + 9);
        break;
      }
      case 52: {
        fill(bx, by, 6, 8, PATH);
        fill(bx + 1, by + 1, 4, 6, GRASS);
        for (const [x, y] of [[0, 0], [5, 0], [0, 7], [5, 7], [0, 3], [5, 4]]) treeAt(bx + x, by + y, P.trees);
        propT(P.tables[0], bx + 2, by + 7, true);
        propT(P.tables[1], bx + 3, by, true);
        propT(P.tables[2], bx + 4, by + 7, true);
        spot('crowd', bx + 3, by + 4, { n: 8, w: 30 });
        put(B.museum({ wt: 6, hpx: 180, h: 108, wall: '#e2dccf', cols: 4, name: 'LIBRARY', steps: 10, ped: true, lions: true, seed: 8 }), bx + 6, by, 6, 8, { fh: 108 });
        door((bx + 9) * T, (by + 8) * T, 'library', 'PUBLIC LIBRARY');
        lm('NY Public Library & Bryant Park', bx + 8, by + 9, 5, 'Perpustakaan megah yang dijaga dua singa marmer: Patience & Fortitude.');
        break;
      }
      case 53:
        put(B.museum({ wt: 8, hpx: 180, h: 108, wall: '#cfc4ae', cols: 4, name: 'GRAND CENTRAL', arches: true, steps: 4, seed: 9 }), bx, by, 8, 8, { fh: 108 });
        put(B.tower({ wt: 4, tiers: [[0, 85], [5, 119], [12, 44]], wall: '#b9b4ac', spire: 100, crown: true, rd: 10, seed: 31 }), bx + 8, by, 4, 8, { fh: 248 });
        door((bx + 4) * T, (by + 8) * T, 'terminal', 'GRAND CENTRAL');
        door((bx + 10) * T, (by + 8) * T, 'lobby', 'CHRYSLER BUILDING');
        lm('Grand Central Terminal', bx + 4, by + 9, 4, 'Stasiun megah 1913 dengan 44 peron — terbanyak di dunia.');
        lm('Chrysler Building', bx + 10, by + 9, 3, 'Mahkota Art Deco berkilau setinggi 319 m (1930). Favorit banyak orang!');
        station('Grand Central · 42 St', bx + 1, by + 9);
        spot('crowd', bx + 4, by + 8, { n: 8, w: 44 });
        break;
      case 54: {
        fill(bx, by, 12, 8, PLAZA);
        put(B.tower({ wt: 4, tiers: [[0, 200]], wall: '#5a9a9a', glass: true, rd: 14, seed: 32 }), bx + 7, by, 4, 5, { fh: 200 });
        put(B.museum({ wt: 6, hpx: 94, h: 60, wall: '#e6e2d8', cols: 5, name: 'UN', steps: 4, seed: 10 }), bx, by + 1, 6, 4, { fh: 60 });
        for (let i = 0; i < 12; i++) prop(P.flags[i], (bx + i) * T + 8, (by + 7) * T - 3);
        prop(P.statueB, (bx + 6) * T + 8, (by + 5) * T - 2, true);
        fill(bx + 1, by + 7, 10, 1, GRASS);
        door((bx + 9) * T, (by + 5) * T, 'lobby', 'UNITED NATIONS');
        lm('United Nations HQ', bx + 6, by + 8, 6, 'Markas besar PBB. Secara teknis ini wilayah internasional, bukan AS!');
        break;
      }
      case 60:
        // Hudson Mega Mall: seven lots of glass under one sign - three floors of shops, food and a lift inside
        put(B.building({ wt: 7, hpx: 248, h: 196, style: 2, seed: 360, marquee: 'HUDSON MEGA MALL' } as B.BOpt), bx, by, 7, 8, { fh: 196 });
        door((bx + 3) * T + 8, (by + 8) * T, 'mall', 'HUDSON MEGA MALL');
        lm('Hudson Mega Mall', bx + 3, by + 9, 5, 'Tiga lantai untuk dijelajahi: atrium, butik & teknologi, lalu food hall. Naik lift dan kumpulkan suvenir.');
        fill(bx + 7, by, 5, 8, PLAZA);
        put(B.vessel(), bx + 8, by + 2, 4, 3);
        propT(P.planter, bx + 7, by + 6, true);
        propT(P.planter, bx + 11, by + 6, true);
        treeAt(bx + 7, by, P.cherry);
        treeAt(bx + 11, by, P.cherry);
        lm('Vessel · Hudson Yards', bx + 10, by + 7, 4, 'Struktur sarang lebah dengan 154 tangga yang saling terhubung.');
        station('34 St · Hudson Yards', bx + 1, by + 9);
        break;
      case 61:
        lot(bx, by, 3, 8, { h: 186, style: 2 }, 40);
        fill(bx + 3, by, 9, 8, PLAZA);
        put(B.arena(), bx + 4, by + 1, 7, 6, { fade: false, fh: 44 });
        prop(B.signBoard('PENN STATION', '#1f2a3a', '#ffffff'), (bx + 4) * T, (by + 8) * T - 1);
        lm('Madison Square Garden', bx + 7, by + 8, 5, 'Arena paling terkenal di dunia — kandang Knicks & Rangers, di atas Penn Station.');
        station('34 St · Penn Station', bx + 1, by + 9);
        spot('crowd', bx + 8, by + 8, { n: 7, w: 40 });
        break;
      case 62:
        rowLots(bx, bx + 4, by, C.midtown);
        put(B.tower({ wt: 5, tiers: [[0, 58], [7, 143], [15, 37], [23, 20], [31, 14]], wall: '#b9ad98', spire: 50, rd: 10, seed: 33 }), bx + 4, by, 5, 8, { fh: 272 });
        rowLots(bx + 9, bx + 12, by, C.midtown);
        door((bx + 6) * T + 8, (by + 8) * T, 'lobby', 'EMPIRE STATE');
        lm('Empire State Building', bx + 6, by + 9, 5, '381 m, dibangun hanya dalam 410 hari (1931). King Kong pernah manjat di sini!');
        spot('crowd', bx + 6, by + 8, { n: 10, w: 40 });
        break;
      case 63:
        all(C.ktown);
        break;
      case 70:
        rowLots(bx, bx + 5, by, C.chelsea);
        fill(bx + 5, by, 3, 8, GRASS);
        fill(bx + 6, by, 1, 8, WOOD);
        for (let y = by; y < by + 8; y++) propT(y % 3 === 0 ? P.planter : P.bush, y % 2 ? bx + 5 : bx + 7, y);
        rowLots(bx + 8, bx + 12, by, C.chelsea);
        lm('The High Line', bx + 6, by + 5, 3, 'Bekas rel kereta layang yang disulap jadi taman memanjang.');
        break;
      case 72: {
        put(B.flatiron(250, 200, 21), bx, by, 3, 8);
        fill(bx + 3, by, 9, 8, GRASS);
        fill(bx + 3, by + 3, 9, 2, PATH);
        fill(bx + 7, by, 2, 8, PATH);
        put(B.kiosk(), bx + 9, by, 3, 3, { fade: false });
        spots.push({ kind: 'queue', x: (bx + 10) * T, y: (by + 3) * T + 8, n: 7 });
        put(B.fountain(false), bx + 4, by + 5, 3, 2, { fade: false });
        scatter(bx + 3, by, 9, 8, 0.3);
        propT(P.bench, bx + 10, by + 5, true);
        spot('pigeons', bx + 8, by + 4, { n: 5 });
        door((bx + 1) * T + 8, (by + 8) * T, 'lobby', 'FLATIRON');
        lm('Flatiron Building', bx + 1, by + 9, 4, 'Gedung segitiga ikonik berbentuk setrika (1902).');
        lm('Madison Square Park', bx + 9, by + 4, 3, 'Shake Shack pertama lahir dari kios hot dog di taman ini. Antreannya... ya begitu.');
        station('23 St · Flatiron', bx + 4, by + 9);
        break;
      }
      case 73:
        rowLots(bx, bx + 4, by, C.village);
        lot(bx + 4, by, 4, 4, { h: 86, style: 1 }, 6);
        fill(bx + 4, by + 4, 4, 4, GRASS);
        scatter(bx + 4, by + 4, 4, 3, 0.4);
        prop(P.statueB, (bx + 6) * T, (by + 8) * T - 4, true);
        rowLots(bx + 8, bx + 12, by, C.village);
        break;
      case 82: {
        fill(bx, by, 12, 8, GRASS);
        fill(bx, by + 3, 12, 2, PATH);
        fill(bx + 5, by, 3, 8, PATH);
        fill(bx + 3, by + 2, 7, 4, PLAZA);
        put(B.fountain(false), bx + 5, by + 3, 3, 2, { fade: false });
        put(B.arch(), bx + 5, by, 3, 1, { solid: false, fade: false });
        block(bx + 5, by, 1, 1);
        block(bx + 7, by, 1, 1);
        propT(P.bench, bx + 1, by + 2, true);
        propT(P.bench, bx + 10, by + 2, true);
        propT(P.bench, bx + 1, by + 6, true);
        propT(P.bench, bx + 10, by + 6, true);
        scatter(bx, by, 12, 8, 0.3);
        spot('perf', bx + 3, by + 6);
        spot('perf', bx + 9, by + 2);
        spot('crowd', bx + 6, by + 5, { n: 14, w: 60 });
        spot('pigeons', bx + 4, by + 3, { n: 6 });
        spot('pigeons', bx + 8, by + 5, { n: 6 });
        lm('Washington Square Arch', bx + 6, by + 2, 4, 'Gapura marmer 1892 — tempat nongkrong musisi jalanan, mahasiswa NYU & pecatur.');
        station('W 4 St · Washington Sq', bx + 1, by + 9);
        break;
      }
      case 84:
        fill(bx, by, 6, 8, GRASS);
        fill(bx, by + 3, 6, 2, PATH);
        fill(bx + 2, by, 2, 8, PATH);
        scatter(bx, by, 6, 8, 0.4);
        rowLots(bx + 6, bx + 12, by, C.evill);
        spot('pigeons', bx + 3, by + 4, { n: 5 });
        break;
      case 90:
        rowLots(bx, bx + 4, by, C.tribeca);
        lot(bx + 4, by, 3, 8, { h: 104, style: 0, garage: true, shop: 'FDNY' }, 0);
        rowLots(bx + 7, bx + 12, by, C.tribeca);
        lm('Hook & Ladder 8', bx + 5, by + 9, 3, 'Pemadam kebakaran yang jadi markas Ghostbusters di film. Who you gonna call?');
        break;
      case 93:
        all(C.china);
        lm('Chinatown', bx + 6, by + 9, 5, 'Salah satu Chinatown terbesar di luar Asia. Dim sum dulu, yuk!');
        station('Canal St · Chinatown', bx + 1, by + 9);
        spot('crowd', bx + 7, by + 8, { n: 8, w: 60 });
        break;
      case 94:
        rowLots(bx, bx + 4, by, C.les);
        lot(bx + 4, by, 4, 8, { h: 104, style: 0, shop: "KATZ'S", vsign: 'KATZ' }, 0);
        rowLots(bx + 8, bx + 12, by, C.les);
        lm("Katz's Delicatessen", bx + 6, by + 9, 3, 'Deli legendaris sejak 1888. Sandwich pastrami-nya juara dunia.');
        break;
      case 100: {
        fill(bx, by, 12, 8, PLAZA);
        put(B.tower({ wt: 5, tiers: [[0, 41], [2, 58], [4, 58], [6, 58], [8, 41]], wall: '#5a8fb8', glass: true, spire: 50, rd: 12, seed: 34 }), bx, by, 5, 5, { fh: 256 });
        put(B.oculus(), bx + 6, by + 1, 6, 3, { fade: false });
        for (const px of [bx + 1, bx + 7]) {
          flat(B.pool911(), px, by + 5);
          block(px, by + 5, 3, 3);
        }
        for (const [x, y] of [[5, 6], [10, 5], [11, 7], [10, 7], [4, 7]]) treeAt(bx + x, by + y, P.trees);
        door((bx + 2) * T + 8, (by + 5) * T, 'lobby', 'ONE WORLD TRADE');
        lm('One World Trade Center', bx + 2, by + 9, 4, '541 m (1.776 kaki) — gedung tertinggi di belahan bumi barat.');
        lm('9/11 Memorial', bx + 5, by + 5, 2, 'Dua kolam refleksi di tapak Menara Kembar, mengenang para korban.');
        lm('The Oculus', bx + 9, by + 4, 2, 'Stasiun bersayap putih karya Santiago Calatrava — seperti burung yang dilepas.');
        station('World Trade Center', bx + 6, by + 9);
        break;
      }
      case 101:
        rowLots(bx, bx + 4, by, C.fidi);
        put(B.cathedral({ wt: 4, hpx: 230, h: 132, wall: '#7a5a48', spires: 1, seed: 4 }), bx + 4, by, 4, 8, { fh: 132 });
        rowLots(bx + 8, bx + 12, by, C.fidi);
        door((bx + 6) * T, (by + 8) * T, 'church', 'TRINITY CHURCH');
        lm('Trinity Church', bx + 6, by + 9, 3, 'Gereja gotik 1846 — dulu bangunan tertinggi di New York.');
        break;
      case 102: {
        put(B.museum({ wt: 6, hpx: 186, h: 116, wall: '#d9d2c2', cols: 6, name: 'NYSE', flag: true, ped: true, steps: 6, seed: 11 }), bx, by, 6, 8, { fh: 116 });
        lot(bx + 6, by, 3, 4, { h: 162, style: 3 }, 56);
        fill(bx + 6, by + 4, 3, 4, PLAZA);
        prop(bullSprite(), (bx + 7) * T + 8, (by + 6) * T + 12, true);
        lot(bx + 9, by, 3, 8, { h: 200, style: 2 }, 50);
        spot('crowd', bx + 7, by + 7, { n: 8, w: 22 });
        spot('cop', bx + 4, by + 8);
        door((bx + 3) * T, (by + 8) * T, 'lobby', 'STOCK EXCHANGE');
        lm('New York Stock Exchange', bx + 3, by + 9, 3, 'Bursa saham terbesar di dunia, di jantung Wall Street.');
        lm('Charging Bull', bx + 7, by + 7, 2, 'Banteng perunggu 3,2 ton — simbol optimisme Wall Street.');
        station('Wall St', bx + 10, by + 9);
        break;
      }
      case 104:
        all(C.seaport);
        fill(126, 176, 7, 5, WOOD);
        prop(B.boat(5), 126 * T + 52, 186 * T + 4);
        propT(P.bench, 128, 176, true);
        propT(P.bench, 130, 176, true);
        lm('South Street Seaport', 127, 178, 4, 'Pelabuhan tua abad ke-19 dengan kapal layar bersejarah.');
        station('Fulton St · Seaport', bx + 1, by + 9);
        break;
      default: {
        const key = j === 0 ? 'harlem' : j <= 3 ? (k === 0 ? 'uws' : 'ues') : j === 4 ? (k === 0 ? 'hk' : k === 1 ? 'theater' : 'midtown') : j === 5 ? 'hk'
          : j === 6 ? 'hk' : j === 7 ? (k <= 1 ? 'chelsea' : 'hk') : j === 8 ? (k <= 1 ? 'village' : 'evill') : j === 9 ? (k === 1 ? 'soho' : k === 2 ? 'italy' : 'les') : 'fidi';
        all(C[key]);
        if (j === 9 && k === 1) station('Spring St · SoHo', bx + 1, by + 9);
      }
    }
  };
  for (let j = 0; j <= 10; j++)
    for (let k = 0; k <= 4; k++) {
      if (j >= 1 && j <= 3 && k >= 1 && k <= 3) continue;
      blockFn(j, k, 26 + 20 * k, 14 + 16 * j);
    }

  // ------------------------------------------------------------ Battery Park
  promenade();
  fill(20, 193, 100, 2, PATH, GRASS);
  fill(58, 190, 2, 10, PATH, GRASS);
  fill(44, 190, 2, 10, PATH, GRASS);
  fill(44, 198, 2, 2, PATH);
  fill(44, 200, 2, 5, WOOD);
  put(B.castle('#b08a68'), 70, 195, 4, 3);
  prop(B.boat(0), 46 * T + 44, 204 * T + 6);
  prop(B.signBoard('STATUE FERRY', '#2b4f8a', '#ffffff'), 42 * T, 199 * T + 6);
  triggers.push({ x: 44, y: 202, w: 2, h: 3, label: 'Naik ferry ke Liberty Island', tx: 28 * T + 8, ty: 210 * T + 12 });
  scatter(18, 190, 108, 10, 0.12);
  for (let x = 26; x < 100; x += 9) if (getT(x, 192) === GRASS && !solid[I(x, 192)]) prop(P.bench, x * T + 8, 192 * T + 15, true);
  vendor(50, 191, 3);
  vendor(62, 191, 0);
  spot('crowd', 46, 196, { n: 10, w: 40 });
  spot('pigeons', 56, 194, { n: 6 });
  spot('perf', 60, 196);
  lm('Battery Park', 56, 194, 5, 'Taman di ujung selatan Manhattan. Dari dermaga sini ferry berangkat ke Patung Liberty!');
  station('South Ferry', 54, 189);

  // ------------------------------------------------------------ Liberty Island
  fill(10, 212, 11, 3, PLAZA);
  fill(20, 210, 6, 2, PATH);
  fill(26, 210, 5, 2, WOOD);
  put(B.liberty(), 13, 209, 5, 3, { fade: true });
  prop(B.boat(0), 30 * T, 210 * T - 2);
  triggers.push({ x: 29, y: 210, w: 2, h: 2, label: 'Naik ferry ke Battery Park', tx: 44 * T + 16, ty: 201 * T });
  prop(P.flagUS, 9 * T, 213 * T);
  for (const [x, y] of [[7, 209], [8, 215], [22, 207], [23, 214], [11, 206], [19, 206], [6, 212]]) treeAt(x, y, P.trees);
  vendor(19, 215, 3);
  spot('crowd', 15, 213, { n: 16, w: 52 });
  spot('pigeons', 17, 214, { n: 6 });
  lm('Statue of Liberty', 15, 213, 6, 'Lady Liberty! Hadiah dari Prancis (1886), 93 m sampai ujung obornya.');

  // ------------------------------------------------------------ Brooklyn
  fill(152, 140, 6, 26, GRASS);
  fill(152, 174, 6, 32, GRASS);
  promenade();
  fill(152, 160, 6, 6, PLAZA);
  put(B.carousel(), 154, 150, 3, 3, { fade: false });
  fill(146, 186, 6, 3, WOOD);
  scatter(152, 140, 6, 66, 0.22);
  for (const by of [142, 152, 162, 172, 182, 192]) {
    rowLots(166, 176, by, C.bk);
    fill(164, by + 8, 12, 2, COBBLE);
  }
  fill(164, 140, 12, 2, COBBLE);
  for (const y of [144, 156, 178, 188, 196]) propT(P.bench, 155, y, true);
  vendor(153, 161, 3);
  station('High St · Brooklyn Bridge', 154, 164);
  spot('crowd', 155, 156, { n: 8, w: 40 });
  spot('crowd', 149, 187, { n: 5, w: 30 });
  spot('pigeons', 155, 162, { n: 6 });
  lm('DUMBO', 162, 158, 5, 'Down Under the Manhattan Bridge Overpass — gudang bata, jalan batu & kopi enak.');
  lm("Jane's Carousel", 155, 154, 3, 'Komidi putar antik 1922 di dalam paviliun kaca tepi sungai.');

  // bridge
  const tw = B.bridgeTower();
  for (const tx of [133, 143]) put(tw, tx, 166, 2, 8, { solid: false, dy: 8, sy: 174 * T + 1, fade: true });
  const cable = B.bridgeCable(26 * T, 90, 8 * T, 18 * T);
  objs.push({ k: 0, x: 126 * T, y: 166 * T - 90, w: 26 * T, h: 90, sy: 166 * T + 1, spr: cable });
  objs.push({ k: 0, x: 126 * T, y: 174 * T - 90, w: 26 * T, h: 90, sy: 174 * T + 2, spr: cable });
  lm('Brooklyn Bridge', 139, 170, 5, 'Dibuka 1883 — jembatan gantung kabel baja pertama di dunia. Jalan kaki nyebrangnya wajib!');

  // ------------------------------------------------------------ street furniture
  for (let n = 0; n < inters.length; n++) {
    const it = inters[n];
    const cs: [number, number, number][] = [[it.x - 1, it.y - 1, 0], [it.x + 4, it.y - 1, 1], [it.x - 1, it.y + 4, 1], [it.x + 4, it.y + 4, 0]];
    for (const [cx, cy, ax] of cs) if (getT(cx, cy) === SIDEWALK && !solid[I(cx, cy)]) prop(P.tlight, cx * T + 8, cy * T + 12, false, 1, (n + 1) * 2 + ax);
  }
  for (let y = 1; y < MH - 1; y++)
    for (let x = 1; x < MW - 1; x++) {
      const i = I(x, y);
      if (tiles[i] !== SIDEWALK || solid[i] || reserved[i] || zone[i]) continue;
      const n = isRoad(tiles[i - MW]);
      const s = isRoad(tiles[i + MW]);
      const e = isRoad(tiles[i + 1]);
      const w = isRoad(tiles[i - 1]);
      if (!(n || s || e || w)) {
        if ((x === 18 || x === 125) && y % 11 === 5) prop(P.bench, x * T + 8, y * T + 14, true);
        continue;
      }
      const q = n || s ? x % 6 : y % 6;
      const h = hash2(x, y) % 100;
      const px = x * T + 8 + (e ? 3 : w ? -3 : 0);
      const py = y * T + (s ? 12 : n ? 7 : 10);
      const jj = Math.floor((y - 8) / 16);
      const tp = x >= 152 ? 40 : jj <= 3 || (jj >= 7 && jj <= 9) ? 80 : 30;
      if (q === 1) prop(P.lamp, px, py);
      else if (q === 4) {
        if (h < tp) prop(P.street[hash2(y, x) % (jj === 8 ? 5 : 4)], px, py);
      } else if (h < 3) prop(P.hydrant, px, py);
      else if (h < 6) prop(P.trash, px, py);
      else if (h < 8) prop(P.mailbox, px, py);
      else if (h < 10) prop(P.news[h % 3], px, py);
      else if (h < 11) prop(P.link, px, py);
      else if (h < 12) prop(P.steam, px, py, false, 2);
      else if (h < 13) prop(P.cone, px, py);
    }
  // random cops & performers on corners
  for (let n = 0; n < inters.length; n += 5) spots.push({ kind: 'cop', x: (inters[n].x - 1) * T + 4, y: (inters[n].y + 5) * T });

  // ------------------------------------------------------------ boats
  const boats: BoatDef[] = [
    { c: B.boat(1).c, x: 90 * T, y: 213 * T, vx: 13, vy: 0, a: 44 * T, b: 172 * T },
    { c: B.boat(4).c, x: 120 * T, y: 207 * T, vx: -20, vy: 0, a: 64 * T, b: 150 * T },
    { c: B.boat(2).c, x: 14, y: 60 * T, vx: 0, vy: 9, a: 6 * T, b: 188 * T },
    { c: B.boat(3).c, x: 136 * T, y: 100 * T, vx: 0, vy: -7, a: 8 * T, b: 150 * T },
    { c: B.boat(2).c, x: 144 * T, y: 30 * T, vx: 0, vy: 11, a: 6 * T, b: 136 * T },
    { c: B.boat(3).c, x: 70 * T, y: 219 * T, vx: 9, vy: 0, a: 40 * T, b: 172 * T },
  ];

  // ------------------------------------------------------------ lanes (car spawn points)
  const lanes: number[] = [];
  for (const s of vs) for (let y = s.y0 + 4; y < s.y1 - 3; y += 5) if (!zone[I(s.x, y)]) lanes.push(s.x * T + 16, y * T + 8, 2, s.x * T + 48, y * T + 8, 0);
  for (const s of hs) for (let x = s.x0 + 4; x < s.x1 - 3; x += 5) if (!zone[I(x, s.y)]) lanes.push(x * T + 8, s.y * T + 16, 3, x * T + 8, s.y * T + 48, 1);
  // parked cars in Brooklyn cobble alley (rendered in 3D)
  for (const [x, y, ci] of [[168, 150, 6], [172, 160, 9], [169, 170, 14], [173, 180, 7]]) {
    const ct = cars[ci], cc = ct.c[1];
    objs.push({ k: 0, x: x * T, y: y * T + 2, w: cc.width, h: cc.height, sy: y * T + 22, spr: { c: cc }, car: { kind: ct.kind, body: ct.body, len: ct.len, sign: ct.sign, dir: 1 } });
    block(x, y, 2, 2);
  }

  // drop doors whose doorstep is blocked or not on walkable ground
  for (let i = doors.length - 1; i >= 0; i--) {
    const d = doors[i];
    const di = I(d.x >> 4, (d.y + 4) >> 4);
    if (solid[di] || tiles[di] === WATER || isRoad(tiles[di])) doors.splice(i, 1);
  }

  // ------------------------------------------------------------ gfx, npcOk, minimap
  const gfx = new Uint16Array(N);
  const npcOk = new Uint8Array(N);
  const { c: mini, g: mg } = mkCanvas(MW, MH);
  const img = mg.createImageData(MW, MH);
  for (let y = 0; y < MH; y++)
    for (let x = 0; x < MW; x++) {
      const i = I(x, y);
      const t = tiles[i];
      let m = 0;
      const test = (f: (n: number) => boolean) => (f(getT(x, y - 1)) ? 1 : 0) | (f(getT(x + 1, y)) ? 2 : 0) | (f(getT(x, y + 1)) ? 4 : 0) | (f(getT(x - 1, y)) ? 8 : 0);
      if (t === SIDEWALK) m = test(isRoad);
      else if (t === GRASS) m = test((n) => n !== GRASS);
      else if (t === WATER) m = test((n) => n !== WATER);
      else if (t === LAKE) m = test((n) => n !== LAKE);
      const h = hash2(x, y) % 16;
      const v = h < 9 ? 0 : h < 13 ? 1 : h < 15 ? 2 : 3;
      gfx[i] = t * 64 + m * 4 + v;
      const walk = t === SIDEWALK || t === CROSS_V || t === CROSS_H || t === GRASS || t === PATH || t === PLAZA || t === WOOD || t === COBBLE || t === REDPAVE || t === DIRT || t === ICE;
      npcOk[i] = walk && !solid[i] ? 1 : 0;
      const col = parseInt((solid[i] && t !== WATER && t !== LAKE && t !== ICE ? (t === GRASS ? '#2f7a38' : '#7d7468') : MINI_COL[t]).slice(1), 16);
      img.data[i * 4] = col >> 16;
      img.data[i * 4 + 1] = (col >> 8) & 255;
      img.data[i * 4 + 2] = col & 255;
      img.data[i * 4 + 3] = 255;
    }
  mg.putImageData(img, 0, 0);

  // ------------------------------------------------------------ buckets
  const bw = Math.ceil((MW * T) / BUCKET);
  const bh = Math.ceil((MH * T) / BUCKET);
  const buckets: Obj[][] = [];
  for (let i = 0; i < bw * bh; i++) buckets.push([]);
  for (const o of objs) {
    const x0 = Math.max(0, Math.floor(o.x / BUCKET));
    const x1 = Math.min(bw - 1, Math.floor((o.x + o.w) / BUCKET));
    const y0 = Math.max(0, Math.floor(o.y / BUCKET));
    const y1 = Math.min(bh - 1, Math.floor((o.y + o.h) / BUCKET));
    for (let by = y0; by <= y1; by++) for (let bx = x0; bx <= x1; bx++) buckets[by * bw + bx].push(o);
  }

  return {
    tiles, gfx, solid, npcOk, zone, core, inters, objs, buckets, bw, bh, landmarks, stations, triggers, spots, lanes, boats, doors, mini,
    start: { x: 52 * T, y: 102 * T + 8 },
    district,
  };
}

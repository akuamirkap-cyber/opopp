import { G, T, mkCanvas, mulberry32, pick, ri } from './util';

export const WATER = 0;
export const SIDEWALK = 1;
export const ROAD = 2;
export const RV_L = 3;
export const RV_R = 4;
export const RH_T = 5;
export const RH_B = 6;
export const CROSS_V = 7;
export const CROSS_H = 8;
export const GRASS = 9;
export const PATH = 10;
export const PLAZA = 11;
export const WOOD = 12;
export const LAKE = 13;
export const COBBLE = 14;
export const REDPAVE = 15;
export const DIRT = 16;
export const ICE = 17;
export const NTYPES = 18;

export const ATLAS_COLS = 32;

export const isRoad = (t: number) => t >= 2 && t <= 8;
export const isWater = (t: number) => t === WATER || t === LAKE;

export const MINI_COL: string[] = [
  '#2f6fb5', '#b9b5ab', '#474a56', '#474a56', '#474a56', '#474a56', '#474a56', '#d9d9d2', '#d9d9d2',
  '#4f9d40', '#d8c495', '#cbc4b5', '#a87442', '#4a9cc0', '#8b8379', '#b4443a', '#b98a57', '#d3ecf5',
];

function paint(g: G, t: number, m: number, v: number, f: number, ox: number, oy: number) {
  const r = mulberry32(t * 7919 + v * 104729 + 17);
  const P = (c: string, x: number, y: number, w = 1, h = 1) => {
    if (x < 0) {
      w += x;
      x = 0;
    }
    if (y < 0) {
      h += y;
      y = 0;
    }
    if (x + w > T) w = T - x;
    if (y + h > T) h = T - y;
    if (w <= 0 || h <= 0) return;
    g.fillStyle = c;
    g.fillRect(ox + x, oy + y, w, h);
  };
  const speck = (cols: string[], n: number) => {
    for (let i = 0; i < n; i++) P(pick(r, cols), ri(r, 0, 15), ri(r, 0, 15));
  };
  switch (t) {
    case WATER: {
      P('#2a66ad', 0, 0, 16, 16);
      for (let i = 0; i < 2; i++) P('#245c9f', ri(r, 0, 10), ri(r, 0, 15), ri(r, 3, 6), 1);
      for (let i = 0; i < 2 + (v % 2); i++) {
        const x = (ri(r, 0, 12) + f * 2) % 13;
        const y = ri(r, 1, 14);
        P('#4d8fd4', x, y, 3, 1);
        if (i === 0) P('#8cc0ee', x + 1, y, 1, 1);
      }
      if (m & 1) {
        P('#7b8290', 0, 0, 16, 5);
        P('#9ea5b2', 0, 0, 16, 1);
        P('#5b616e', 0, 4, 16, 1);
        P('#666c79', 3, 1, 1, 3);
        P('#666c79', 11, 1, 1, 3);
        P('#1c4a86', 0, 5, 16, 2);
        P('#b9dcf5', (3 + f * 4) % 12, 7, 3, 1);
      }
      if (m & 4) P('#5b9bd8', 0, 15, 16, 1);
      if (m & 2) P('#5b9bd8', 15, 0, 1, 16);
      if (m & 8) P('#5b9bd8', 0, 0, 1, 16);
      break;
    }
    case SIDEWALK: {
      P('#b8b4aa', 0, 0, 16, 16);
      P('#c3bfb5', 0, 0, 15, 1);
      P('#a7a399', 0, 15, 16, 1);
      P('#a7a399', 15, 0, 1, 16);
      speck(['#aeaaa0', '#c1bdb3'], 6);
      if (v === 1) {
        P('#8f8b82', 4, 5, 1, 3);
        P('#8f8b82', 5, 8, 1, 2);
        P('#8f8b82', 6, 10, 1, 3);
      } else if (v === 2) {
        P('#7d7a73', 5, 9);
        P('#7d7a73', 11, 4);
        P('#85827a', 9, 12);
      } else if (v === 3) {
        P('#77746e', 4, 4, 8, 8);
        for (let i = 0; i < 4; i++) P('#4c4a46', 5, 5 + i * 2, 6, 1);
      }
      if (m & 1) P('#d9d6cd', 0, 0, 16, 2);
      if (m & 4) {
        P('#d9d6cd', 0, 13, 16, 2);
        P('#7f7b74', 0, 15, 16, 1);
      }
      if (m & 2) P('#d9d6cd', 14, 0, 2, 16);
      if (m & 8) P('#d9d6cd', 0, 0, 2, 16);
      break;
    }
    case ROAD:
    case RV_L:
    case RV_R:
    case RH_T:
    case RH_B:
    case CROSS_V:
    case CROSS_H: {
      P('#3f414c', 0, 0, 16, 16);
      speck(['#393b45', '#474955', '#454752'], 10);
      if (t === ROAD && v === 3) {
        P('#2c2d35', 6, 5, 4, 6);
        P('#2c2d35', 5, 6, 6, 4);
        P('#565861', 6, 6, 4, 4);
        P('#2c2d35', 7, 7, 2, 2);
      }
      if (t === ROAD && v === 2) P('#3a3c46', 3, 6, 9, 6);
      const yl = '#e0b43a';
      if (t === RV_L) P(yl, 14, 0, 1, 16);
      if (t === RV_R) P(yl, 1, 0, 1, 16);
      if (t === RH_T) P(yl, 0, 14, 16, 1);
      if (t === RH_B) P(yl, 0, 1, 16, 1);
      if (t === CROSS_V) {
        P('#e4e4de', 1, 0, 5, 16);
        P('#e4e4de', 9, 0, 5, 16);
        speck(['#c9c9c4', '#babab6'], 5);
      }
      if (t === CROSS_H) {
        P('#e4e4de', 0, 1, 16, 5);
        P('#e4e4de', 0, 9, 16, 5);
        speck(['#c9c9c4', '#babab6'], 5);
      }
      break;
    }
    case GRASS: {
      P('#4c9a3e', 0, 0, 16, 16);
      speck(['#57a847', '#448c38'], 8);
      for (let i = 0; i < 2 + v; i++) {
        const x = ri(r, 1, 13);
        const y = ri(r, 2, 12);
        P('#6cbd55', x, y, 1, 2);
        P('#6cbd55', x + 1, y + 1);
      }
      if (v === 2) for (let i = 0; i < 3; i++) P(pick(r, ['#ffffff', '#ffe14a', '#ff8fb4', '#c9a6ff']), ri(r, 2, 13), ri(r, 2, 13));
      if (v === 3) P('#408636', ri(r, 2, 8), ri(r, 2, 8), 5, 4);
      if (m & 1) P('#3a7a33', 0, 0, 16, 1);
      if (m & 4) P('#3a7a33', 0, 15, 16, 1);
      if (m & 2) P('#3a7a33', 15, 0, 1, 16);
      if (m & 8) P('#3a7a33', 0, 0, 1, 16);
      break;
    }
    case PATH: {
      P('#d6c193', 0, 0, 16, 16);
      speck(['#c7b183', '#e2d0a6', '#bda777'], 12);
      if (v >= 2) P('#b9a374', ri(r, 2, 12), ri(r, 2, 12), 2, 1);
      break;
    }
    case PLAZA: {
      P('#c8c1b2', 0, 0, 16, 16);
      P('#bcb4a5', 0, 0, 8, 8);
      P('#bcb4a5', 8, 8, 8, 8);
      P('#a9a193', 0, 15, 16, 1);
      P('#a9a193', 15, 0, 1, 16);
      P('#b0a899', 0, 7, 16, 1);
      P('#b0a899', 7, 0, 1, 16);
      speck(['#d1cabc', '#b5ad9e'], 4);
      break;
    }
    case WOOD: {
      P('#a87442', 0, 0, 16, 16);
      for (const y of [3, 7, 11, 15]) P('#7e5330', 0, y, 16, 1);
      P('#7e5330', 2 + v * 3, 0, 1, 3);
      P('#7e5330', 9 - v, 8, 1, 3);
      P('#7e5330', 13 - v * 2, 4, 1, 3);
      P('#bd8a55', 3, 5, 4, 1);
      P('#bd8a55', 9, 13, 3, 1);
      P('#bd8a55', 6 + v, 1, 3, 1);
      break;
    }
    case LAKE: {
      P('#3f93b8', 0, 0, 16, 16);
      for (let i = 0; i < 2; i++) {
        const x = (ri(r, 0, 12) + f * 2) % 13;
        const y = ri(r, 2, 14);
        P('#66b6d4', x, y, 3, 1);
      }
      P('#3888ab', ri(r, 0, 10), ri(r, 0, 15), 4, 1);
      if (m & 1) {
        P('#2c6f8f', 0, 0, 16, 3);
        P('#6b5a3c', 0, 0, 16, 1);
      }
      if (m & 4) P('#7cc4dc', 0, 15, 16, 1);
      if (m & 2) P('#7cc4dc', 15, 0, 1, 16);
      if (m & 8) P('#7cc4dc', 0, 0, 1, 16);
      break;
    }
    case COBBLE: {
      P('#8a8279', 0, 0, 16, 16);
      for (let y = 0; y < 16; y += 4) {
        const off = ((y / 4) % 2) * 4;
        P('#6f675f', 0, y + 3, 16, 1);
        for (let x = 0; x < 16; x += 8) P('#6f675f', (x + off) % 16, y, 1, 3);
      }
      for (let i = 0; i < 3; i++) P('#9c948a', ri(r, 0, 3) * 4 + 1, ri(r, 0, 3) * 4, 2, 2);
      break;
    }
    case REDPAVE: {
      P('#b4443a', 0, 0, 16, 16);
      P('#a23b32', 0, 15, 16, 1);
      P('#a23b32', 15, 0, 1, 16);
      speck(['#c0544a', '#a84037'], 6);
      break;
    }
    case DIRT: {
      P('#b98a57', 0, 0, 16, 16);
      speck(['#a97b4a', '#c79a66'], 10);
      break;
    }
    case ICE: {
      P('#d3ecf5', 0, 0, 16, 16);
      P('#b9dcea', ri(r, 0, 8), ri(r, 0, 15), 6, 1);
      P('#b9dcea', ri(r, 0, 12), ri(r, 0, 10), 1, 5);
      P('#ffffff', (ri(r, 0, 12) + f * 3) % 14, ri(r, 1, 14), 2, 1);
      break;
    }
  }
}

export function buildAtlas(): HTMLCanvasElement[] {
  const out: HTMLCanvasElement[] = [];
  const rows = Math.ceil((NTYPES * 64) / ATLAS_COLS);
  for (let f = 0; f < 3; f++) {
    const { c, g } = mkCanvas(ATLAS_COLS * T, rows * T);
    for (let t = 0; t < NTYPES; t++)
      for (let m = 0; m < 16; m++)
        for (let v = 0; v < 4; v++) {
          const i = t * 64 + m * 4 + v;
          paint(g, t, m, v, f, (i % ATLAS_COLS) * T, Math.floor(i / ATLAS_COLS) * T);
        }
    out.push(c);
  }
  return out;
}

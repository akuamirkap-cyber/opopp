import type { Board, Spr, Tier3D } from './util';
import { shade } from './util';

/**
 * New York in three dimensions. Every building is a solid prism standing on its lot, seen from above the centre of the view:
 * the higher a storey, the further its corners project away from that centre in BOTH X and Y (bounded cleanly so tall
 * skyscrapers stay upright and architectural rather than tilting like wedges).
 * Landmarks (setback Art Deco towers, Madison Square Garden, museums, cathedrals) also project in 3D so the skyline coheres.
 */
type G = CanvasRenderingContext2D;

/** bounded perspective expansion factor for a height z above pavement (max ~10.5% so tall towers stay crisp & upright) */
export const persp = (z: number) => (z <= 0 ? 0 : 0.105 * (1 - Math.exp(-z / 90)));

/** screen X of a world X at height z above pavement, relative to viewport centre vx */
export const leanX = (x: number, z: number, vx: number) => vx + (x - vx) * (1 + persp(z));

/** screen Y of a building's front-edge Y (by) at height z above pavement, relative to viewport centre vy */
export const leanY = (by: number, z: number, vy: number) => by - z + (by - vy) * persp(z) * 0.34;

const cols = new WeakMap<HTMLCanvasElement, string[]>();
/** [west wall, east wall, west dark, east dark, west lit, east lit, west trim, east trim] */
function sideCols(s: Spr, fh: number): string[] {
  let c = cols.get(s.c);
  if (c) return c;
  let wall = s.wall;
  if (!wall || !/^#[0-9a-f]{6}$/i.test(wall)) {
    wall = '#737682';
    try {
      const d = s.c.getContext('2d')!.getImageData(Math.min(3, s.c.width - 1), Math.max(0, s.c.height - Math.max(24, fh >> 1)), 1, 1).data;
      if (d[3] > 0) wall = '#' + ((1 << 24) | (d[0] << 16) | (d[1] << 8) | d[2]).toString(16).slice(1);
    } catch { /* keep default grey */ }
  }
  c = [
    shade(wall, 0.56), // west shaded wall
    shade(wall, 0.88), // east sunlit wall
    shade(wall, 0.25), // west window glass
    shade(wall, 0.36), // east window glass
    shade(wall, 0.42), // west floor trim / cornice
    shade(wall, 0.68), // east floor trim / cornice
    shade(wall, 0.72), // west window sill highlight
    shade(wall, 1.08), // east window sill highlight
  ];
  cols.set(s.c, c);
  return c;
}

/**
 * Draw a true 3D perspective side wall quad:
 * bottom-front (x0, yb0) -> bottom-back (x0, yt0) -> top-back (x1, yt1) -> top-front (x1, yb1).
 * Floor ledges and recessed windows use bilinear coordinates (u, t) on the quad so they follow exact perspective lines.
 */
function drawSideQuad(
  g: G,
  x0: number, yb0: number, yt0: number,
  x1: number, yb1: number, yt1: number,
  fh: number, depth: number,
  wallCol: string, glassCol: string, trimCol: string, sillCol: string,
  lit = false,
) {
  const q = [0, 0];
  const P = (u: number, t: number) => {
    // u: 0 = front street corner, 1 = back roof corner; t: 0 = ground, 1 = roofline
    const xf = x0 + (x1 - x0) * t;
    const yf = yb0 + (yb1 - yb0) * t;
    const yb = yt0 + (yt1 - yt0) * t;
    q[0] = xf;
    q[1] = yf + (yb - yf) * u;
  };
  const quad = (u0: number, t0: number, u1: number, t1: number) => {
    P(u0, t0); g.moveTo(q[0], q[1]);
    P(u1, t0); g.lineTo(q[0], q[1]);
    P(u1, t1); g.lineTo(q[0], q[1]);
    P(u0, t1); g.lineTo(q[0], q[1]);
    g.closePath();
  };

  // main wall fill
  g.fillStyle = wallCol;
  g.beginPath();
  quad(0, 0, 1, 1);
  g.fill();

  // ground plinth / street shadow
  g.fillStyle = 'rgba(8,10,20,0.22)';
  g.beginPath();
  quad(0, 0, 1, Math.min(0.16, 10 / Math.max(12, fh)));
  g.fill();

  const w = Math.abs(x1 - x0);
  if (w >= 2.5 && fh >= 18) {
    const nf = Math.max(2, Math.round(fh / 13));
    const nd = Math.max(1, Math.min(8, Math.round(depth / 11)));

    // perspective floor bands
    g.strokeStyle = trimCol;
    g.lineWidth = 1;
    g.beginPath();
    for (let f = 1; f < nf; f++) {
      const t = f / nf;
      P(0, t); g.moveTo(q[0], q[1]);
      P(1, t); g.lineTo(q[0], q[1]);
    }
    g.stroke();

    // perspective recessed windows (aligned with roof/ground edges, never staircased)
    if (w >= 4) {
      g.fillStyle = glassCol;
      g.beginPath();
      for (let f = 0; f < nf; f++) {
        const t0 = (f + 0.28) / nf, t1 = (f + 0.78) / nf;
        for (let j = 0; j < nd; j++) {
          const u0 = (j + 0.22) / nd, u1 = (j + 0.78) / nd;
          quad(u0, t0, u1, t1);
        }
      }
      g.fill();

      // subtle window sill / sunlit highlight along bottom of each window
      g.strokeStyle = sillCol;
      g.beginPath();
      for (let f = 0; f < nf; f++) {
        const t = (f + 0.26) / nf;
        for (let j = 0; j < nd; j++) {
          P((j + 0.22) / nd, t); g.moveTo(q[0], q[1]);
          P((j + 0.78) / nd, t); g.lineTo(q[0], q[1]);
        }
      }
      g.stroke();

      // occasional warm lit windows when night falls (or reflections)
      if (lit) {
        g.fillStyle = '#ffd86b';
        g.beginPath();
        for (let f = 0; f < nf; f++) {
          for (let j = 0; j < nd; j++) {
            if (((f * 7 + j * 13) % 5) !== 0) continue;
            quad((j + 0.26) / nd, (f + 0.32) / nf, (j + 0.74) / nd, (f + 0.74) / nf);
          }
        }
        g.fill();
      }
    }

    // top parapet band
    g.fillStyle = trimCol;
    g.beginPath();
    quad(0, 0.96, 1, 1);
    g.fill();
  }

  // crisp architectural ink edges (front corner, roof side edge, back outer corner)
  g.strokeStyle = '#0b0b10';
  g.lineWidth = 1;
  g.beginPath();
  P(0, 0); g.moveTo(q[0], q[1]);
  P(0, 1); g.lineTo(q[0], q[1]);
  P(1, 1); g.lineTo(q[0], q[1]);
  P(1, 0); g.lineTo(q[0], q[1]);
  g.stroke();
}

/** draw sliced front facade from sprite region [sx0..sx0+W, srcTop..srcTop+fh] rising from ground by to roof ryFront */
function drawFrontSlices(
  g: G, c: HTMLCanvasElement,
  srcX: number, srcTop: number, W: number, fh: number,
  gx: number, by: number, zBase: number,
  vx: number, vy: number,
) {
  const xl = leanX(gx, zBase + fh, vx);
  const xr = leanX(gx + W, zBase + fh, vx);
  const x0 = leanX(gx, zBase, vx);
  const x1 = leanX(gx + W, zBase, vx);
  const lean = Math.max(Math.abs(xl - x0), Math.abs(xr - x1));
  const ySkew = Math.abs(leanY(by, zBase + fh, vy) - (by - zBase - fh));

  if (lean < 0.75 && ySkew < 0.75) {
    const dy = Math.round(leanY(by, zBase + fh, vy));
    g.drawImage(c, srcX, srcTop, W, fh, Math.round(x0), dy, W, fh);
    return;
  }
  const n = Math.max(4, Math.min(fh, Math.ceil(Math.max(lean, ySkew) * 1.4) + 2));
  let zb = 0;
  for (let i = 0; i < n; i++) {
    const zt = i === n - 1 ? fh : Math.round(((i + 1) * fh) / n);
    const sh = zt - zb;
    if (sh > 0) {
      const zm = zBase + (zb + zt) * 0.5;
      const dx0 = Math.round(leanX(gx, zm, vx));
      const dx1 = Math.round(leanX(gx + W, zm, vx));
      const dyTop = Math.round(leanY(by, zBase + zt, vy));
      const dyBot = Math.round(leanY(by, zBase + zb, vy));
      g.drawImage(c, srcX, srcTop + (fh - zt), W, sh, dx0, dyTop, Math.max(1, dx1 - dx0), Math.max(1, dyBot - dyTop));
    }
    zb = zt;
  }
}

/**
 * Draw a standard rectangular building (or museum/flat facade) in coherent 3D.
 * `sx, sy` = sprite top-left corner at ground plane; `fh` = front facade height; `dp` = lot depth; `vx, vy` = view centre.
 */
export function draw3D(g: G, s: Spr, sx: number, sy: number, fh: number, dp: number, vx: number, vy?: number, night = false) {
  if (s.tiers) {
    drawTower3D(g, s, sx, sy, dp, vx, vy ?? g.canvas.height / 2, night);
    return;
  }
  if (s.kind3d === 'arena') {
    drawArena3D(g, s, sx, sy, vx, vy ?? g.canvas.height / 2);
    return;
  }
  const c = s.c, W = c.width, hpx = c.height, D = Math.max(0, hpx - fh), by = sy + hpx;
  const cy = vy ?? g.canvas.height / 2;

  const e = persp(fh);
  const xl = leanX(sx, fh, vx), xr = leanX(sx + W, fh, vx);
  const ryFront = leanY(by, fh, cy);
  const dRoof = D * (1 + e * 0.34);
  const ryBack = ryFront - dRoof;
  // matching ground-depth so the side wall top & bottom edges stay parallel in 3D (never a skewed wedge!)
  const dGround = Math.min(dp, Math.max(10, D));
  const gyBack = by - dGround;

  const sc = sideCols(s, fh);
  if (xl - sx > 0.5) {
    drawSideQuad(g, sx, by, gyBack, xl, ryFront, ryBack, fh, dRoof, sc[0], sc[2], sc[4], sc[6], night);
  } else if (sx + W - xr > 0.5) {
    drawSideQuad(g, sx + W, by, gyBack, xr, ryFront, ryBack, fh, dRoof, sc[1], sc[3], sc[5], sc[7], night);
  }

  // front wall
  if (s.kind3d === 'cathedral') {
    // cathedral spires stick above D; draw entire cathedral cleanly shifted at top
    drawFrontSlices(g, c, 0, D, W, fh, sx, by, 0, vx, cy);
    if (D > 0) {
      const dx = Math.round(xl), dw = Math.max(1, Math.round(xr) - dx);
      g.drawImage(c, 0, 0, W, D, dx, Math.round(ryBack), dw, Math.max(1, Math.round(ryFront - ryBack)));
    }
    return;
  }

  drawFrontSlices(g, c, 0, D, W, fh, sx, by, 0, vx, cy);

  // roof + crisp 3D parapet rim
  if (D > 0) {
    const rx = Math.round(xl), rw = Math.max(1, Math.round(xr) - rx);
    const ry = Math.round(ryBack), rh = Math.max(1, Math.round(ryFront - ryBack));
    g.drawImage(c, 0, 0, W, D, rx, ry, rw, rh);
    g.fillStyle = 'rgba(255,248,225,0.16)';
    g.fillRect(rx, ry + rh - 1, rw, 1);
    g.fillRect(rx + rw - 1, ry, 1, rh);
    g.strokeStyle = '#0b0b10';
    g.lineWidth = 1;
    g.strokeRect(rx + 0.5, ry + 0.5, Math.max(1, rw - 1), Math.max(1, rh - 1));
  }
}

/** Setback Art Deco / glass skyscrapers: each tier projects from the roof of the tier below it */
function drawTower3D(g: G, s: Spr, sx: number, sy: number, dp: number, vx: number, vy: number, night: boolean) {
  const tiers: Tier3D[] = s.tiers!, c = s.c, hpx = c.height, by = sy + hpx;
  const sc = sideCols(s, tiers[0]?.h ?? 60);

  const baseX = tiers[0]?.x ?? 0;
  for (let i = 0; i < tiers.length; i++) {
    const ti = tiers[i];
    const z0 = ti.z0, z1 = z0 + ti.h;
    const setY = (ti.x - baseX) * 0.55; // setback tiers step inward from the roof edge as well as from the sides
    const tierBy = by - setY;
    const gx0 = sx + ti.x, gx1 = gx0 + ti.w;
    const bx0 = leanX(gx0, z0, vx), bx1 = leanX(gx1, z0, vx);
    const tx0 = leanX(gx0, z1, vx), tx1 = leanX(gx1, z1, vx);
    const by0 = leanY(tierBy, z0, vy), by1 = leanY(tierBy, z1, vy);

    const e0 = persp(z0), e1 = persp(z1);
    const d0 = ti.d * (1 + e0 * 0.34), d1 = ti.d * (1 + e1 * 0.34);
    const ty0 = by0 - Math.min(dp, d0), ty1 = by1 - d1;

    if (tx0 - bx0 > 0.5) {
      drawSideQuad(g, bx0, by0, ty0, tx0, by1, ty1, ti.h, d1, sc[0], sc[2], sc[4], sc[6], night);
    } else if (bx1 - tx1 > 0.5) {
      drawSideQuad(g, bx1, by0, ty0, tx1, by1, ty1, ti.h, d1, sc[1], sc[3], sc[5], sc[7], night);
    }

    drawFrontSlices(g, c, ti.x, ti.top, ti.w, ti.h, gx0, tierBy, z0, vx, vy);

    // setback roof terrace
    if (ti.d > 0) {
      const rx = Math.round(tx0), rw = Math.max(1, Math.round(tx1) - rx);
      const ry = Math.round(ty1), rh = Math.max(1, Math.round(by1 - ty1));
      g.drawImage(c, ti.x, ti.top - ti.d, ti.w, ti.d, rx, ry, rw, rh);
      g.fillStyle = 'rgba(255,248,225,0.16)';
      g.fillRect(rx, ry + rh - 1, rw, 1);
      g.strokeStyle = '#0b0b10';
      g.lineWidth = 1;
      g.strokeRect(rx + 0.5, ry + 0.5, Math.max(1, rw - 1), Math.max(1, rh - 1));
    }
  }

  // crown / spire above the top tier
  const spireY = s.spireY ?? 0;
  if (spireY > 0) {
    const topT = tiers[tiers.length - 1];
    const zTop = topT.z0 + topT.h;
    const setY = (topT.x - baseX) * 0.55;
    const gx0 = sx + topT.x, tx0 = Math.round(leanX(gx0, zTop, vx)), tx1 = Math.round(leanX(gx0 + topT.w, zTop, vx));
    const off = spireY < topT.top ? (topT.d >> 1) : 0;
    const yBase = Math.round(leanY(by - setY, zTop, vy) - off);
    g.drawImage(c, topT.x, 0, topT.w, spireY, tx0, yBase - spireY, Math.max(1, tx1 - tx0), spireY);
  }
}

/** Madison Square Garden ("THE GARDEN"): true 3D cylindrical drum + ribbed concrete columns + shifted circular roof */
function drawArena3D(g: G, s: Spr, sx: number, sy: number, vx: number, vy: number) {
  const c = s.c, W = c.width;
  const cx0 = sx + 56, cy0 = sy + 70, fh = 44;
  const e = persp(fh);
  const cx1 = leanX(cx0, fh, vx), cy1 = leanY(cy0, fh, vy);
  const dx = cx1 - cx0;
  if (Math.abs(dx) < 0.7) { g.drawImage(c, sx, sy); return; }

  const rx0 = 54, ry0 = 24, rx1 = rx0 * (1 + e * 0.6), ry1 = ry0 * (1 + e * 0.4);

  // cylindrical drum slices rising from base (cy0) to roof (cy1)
  const n = 16;
  for (let i = 0; i <= n; i++) {
    const t = i / n;
    const cx = cx0 + (cx1 - cx0) * t;
    const cy = cy0 + (cy1 - cy0) * t;
    const rx = rx0 + (rx1 - rx0) * t;
    const ry = ry0 + (ry1 - ry0) * t;
    const col = i === 0 ? '#4a4234' : i <= 2 ? '#8a7a64' : i === 4 || i === 5 ? '#2e4464' : i % 2 ? '#bda98e' : '#aa977d';
    g.fillStyle = col;
    g.beginPath();
    g.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    g.fill();
  }
  // vertical concrete ribs along the curved front drum
  g.strokeStyle = 'rgba(58,48,36,0.45)';
  g.lineWidth = 1;
  g.beginPath();
  for (let a = 0.18; a < Math.PI - 0.16; a += 0.2) {
    const x0 = cx0 + Math.cos(a) * rx0, y0 = cy0 + Math.sin(a) * ry0;
    const x1 = cx1 + Math.cos(a) * rx1, y1 = cy1 + Math.sin(a) * ry1;
    g.moveTo(x0, y0); g.lineTo(x1, y1);
  }
  g.stroke();

  // roof disc from original sprite top [0..112, 0..52] scaled cleanly to top ellipse
  const rW = Math.round(rx1 * 2 + 4), rH = Math.round(ry1 * 2 + 4);
  g.save();
  g.beginPath();
  g.ellipse(cx1, cy1, rx1, ry1, 0, 0, Math.PI * 2);
  g.clip();
  g.drawImage(c, 0, 0, W, 52, Math.round(cx1 - rx1 - 2), Math.round(cy1 - ry1 - 2), rW, rH);
  g.restore();

  // crisp roof rim highlight + outline
  g.strokeStyle = 'rgba(255,248,225,0.24)';
  g.lineWidth = 1;
  g.beginPath();
  g.ellipse(cx1, cy1, rx1 - 0.5, ry1 - 0.5, 0, 0.1, Math.PI - 0.1);
  g.stroke();
  g.strokeStyle = '#4a4234';
  g.beginPath();
  g.ellipse(cx1, cy1, rx1, ry1, 0, 0, Math.PI * 2);
  g.stroke();

  // front marquee "THE GARDEN" seated cleanly on the front wall
  const mx = Math.round(cx0 + dx * 0.28 - 23), my = Math.round(cy0 + ry0 - 14);
  g.drawImage(c, 56 - 23, 62, 46, 11, mx, my, 46, 11);
}

/** how far a billboard on the front has moved with the storey it hangs on */
export function boardShift(sx: number, b: Board, hpx: number, fh: number, vx: number) {
  const cx = sx + b.x + b.w / 2, z = Math.max(0, Math.min(fh, hpx - (b.y + b.h / 2)));
  return Math.round(leanX(cx, z, vx) - cx);
}

/** vertical shift of a billboard / light on the front wall */
export function boardShiftY(by: number, bY: number, bH: number, hpx: number, fh: number, vy: number) {
  const z = Math.max(0, Math.min(fh, hpx - (bY + bH / 2)));
  return Math.round(leanY(by, z, vy) - (by - z));
}

/** the fire escape: how high above the pavement each of its landings is (floors 1 to 4, fewer on a low building) */
export function escapeOf(fh: number): number[] {
  // the first landing just above the street floor, then one per 20 px storey
  const n = Math.max(0, Math.min(4, Math.floor((fh - 36) / 20))), zs: number[] = [];
  for (let i = 0; i < n; i++) zs.push(36 + i * 20);
  return zs;
}
/** can somebody climb this front? */
export const canClimb = (w: number, fh: number | undefined): fh is number => fh !== undefined && fh >= 30 && w >= 30;

/** paint the fire escape onto the front of a building: 3D iron balconies with drop shadow, alternating diagonal stairs, roof hatch */
export function fireEscape(c: HTMLCanvasElement, fh: number) {
  const W = c.width, hpx = c.height;
  if (!canClimb(W, fh)) return;
  const g = c.getContext('2d')!, zs = escapeOf(fh);
  const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  const IRON = '#181a22', BAR = 'rgba(24,26,34,0.85)', HI = '#62697a', SHADOW = 'rgba(0,0,0,0.36)';
  const x0 = 3, x1 = W - 3, top = hpx - fh;

  // diagonal iron stair stringers connecting landings (alternating sides) + vertical access ladder
  const lxL = W >= 46 ? Math.round(W * 0.28) : (W >> 1);
  const lxR = W >= 46 ? Math.round(W * 0.72) : (W >> 1);
  for (let i = 0; i < zs.length; i++) {
    const yBot = hpx - zs[i];
    const yTop = i + 1 < zs.length ? hpx - zs[i + 1] : top;
    const ax = i % 2 === 0 ? lxL : lxR;
    const bx = i + 1 < zs.length ? ((i + 1) % 2 === 0 ? lxL : lxR) : ax;
    const steps = Math.max(3, Math.round((yBot - yTop) / 3));
    for (let s = 0; s <= steps; s++) {
      const t = s / steps;
      const sx = Math.round(ax + (bx - ax) * t);
      const sy = Math.round(yBot + (yTop - yBot) * t);
      R(IRON, sx - 2, sy, 5, 1);
      R(HI, sx - 1, sy, 3, 1);
    }
  }
  // drop-down ground ladder on floor 1
  const y1 = hpx - (zs[0] ?? 21);
  R(IRON, lxL - 2, y1, 1, hpx - 10 - y1);
  R(IRON, lxL + 2, y1, 1, hpx - 10 - y1);
  for (let y = hpx - 11; y > y1; y -= 3) R(HI, lxL - 1, y, 3, 1);

  // balconies at floors 1..4 with 3D underside slab & shadow
  for (const z of zs) {
    const y = hpx - z;
    R(SHADOW, x0, y + 2, x1 - x0, 2);
    R(IRON, x0, y, x1 - x0, 2);
    R(HI, x0, y - 1, x1 - x0, 1);
    R(IRON, x0, y - 7, x1 - x0, 1);
    for (let x = x0; x < x1; x += 4) R(BAR, x, y - 6, 1, 5);
    R(IRON, x0, y - 7, 1, 7);
    R(IRON, x1 - 1, y - 7, 1, 7);
  }
  // rooftop coping + roof access lip
  R('rgba(255,255,255,0.22)', 1, top, W - 2, 1);
  R('rgba(0,0,0,0.28)', 1, top + 1, W - 2, 1);
  R(IRON, lxR - 4, top - 2, 9, 3);
  R(HI, lxR - 3, top - 1, 7, 1);
}

import { Board, G, R, Rng, Spr, T, drawText, ell, hash2, line, mkCanvas, mulberry32, outline, pick, pix, ri, shade, textW, tri } from './util';

const PAL: string[][] = [
  ['#a4503c', '#8f4636', '#b0603f', '#7e4a3a', '#9a5a44', '#b86f52', '#6f4038', '#c08a6a'],
  ['#7b4b3a', '#6a4334', '#8a5a45', '#5f4a40', '#946651', '#a0705a'],
  ['#4f8fb8', '#3f7f9f', '#5a9ac0', '#2f6f8f', '#3b5f7f', '#57a0a0', '#6aa7c9', '#2e4f6e', '#4a6a8a'],
  ['#c9b99a', '#b8a98c', '#d6c8ac', '#a89c88', '#bfb5a5', '#d9d2c2', '#9a8f80'],
  ['#e6dfcf', '#d9cdb6', '#c9d4d6', '#e8c9b0', '#cfd8c0', '#b9c4d0', '#e8dca0'],
  ['#cfcac0', '#b7b2a8', '#d8d0c4', '#aeb4b8', '#c4b8a8'],
  ['#8a4a38', '#9a5540', '#7a4434', '#a05a3c', '#6a3c30'],
  ['#a4503c', '#8f4636', '#b0603f', '#9a5a44', '#c9b99a'],
];
const ROOFS = ['#5b5e66', '#6b6258', '#4e525c', '#7a7468', '#5a5450', '#686c74'];
const SIGNS = ['#1f2a3a', '#b3262a', '#1f5a3a', '#f2ead8', '#2a2a33', '#e8c14a', '#2b5fb0', '#5a2a6a', '#e8742b'];
const AWN = ['#b3262a', '#2f6b45', '#2b5fb0', '#e8c14a', '#2a2a33', '#8a3fb0', '#e8742b'];
const DOORS = ['#5a2a22', '#2a4a3a', '#22303f', '#7a2a2a', '#3a3a44', '#1f3a6a'];
export const SHOPS = [
  'DELI', 'PIZZA', 'BAGELS', 'COFFEE', 'BOOKS', 'BODEGA', 'BAR', 'NAILS', 'HALAL', 'TACOS', 'RAMEN', 'VINYL', 'PHARMACY', 'BANK',
  'HOTEL', 'GYM', 'LAUNDRY', 'DINER', 'BAKERY', 'SUSHI', 'BURGERS', 'FLOWERS', 'BARBER', 'PAWN', '99C', 'WINE', 'THAI', 'NEWS', 'CAFE', 'DONUTS',
];
const FE = '#1d1e25';

const lum = (hex: string) => {
  const n = parseInt(hex.slice(1), 16);
  return (n >> 16) * 0.3 + ((n >> 8) & 255) * 0.59 + (n & 255) * 0.11;
};

export interface BOpt {
  wt: number;
  hpx: number;
  h: number;
  style: number;
  seed: number;
  names?: string[];
  shop?: string;
  vsign?: string;
  marquee?: string;
  boards?: boolean;
  garage?: boolean;
  awn?: string[];
  doorL?: boolean;
  doorOff?: number;
}

// ---------------------------------------------------------------- pieces
function waterTower(g: G, x: number, y: number) {
  R(g, '#2a2a30', x + 2, y + 11, 1, 8);
  R(g, '#2a2a30', x + 9, y + 11, 1, 8);
  R(g, '#2a2a30', x + 2, y + 15, 8, 1);
  R(g, '#8a5a3a', x + 1, y + 4, 10, 8);
  R(g, '#a87450', x + 1, y + 4, 2, 8);
  R(g, '#6e452c', x + 4, y + 4, 1, 8);
  R(g, '#6e452c', x + 7, y + 4, 1, 8);
  R(g, '#5c3a24', x + 9, y + 4, 2, 8);
  R(g, '#3a3a40', x + 1, y + 6, 10, 1);
  R(g, '#3a3a40', x + 1, y + 10, 10, 1);
  R(g, '#4a4640', x + 1, y + 3, 10, 1);
  R(g, '#5a5650', x + 2, y + 2, 8, 1);
  R(g, '#5a5650', x + 4, y + 1, 4, 1);
  R(g, '#6a6660', x + 5, y, 2, 1);
}

function acUnit(g: G, x: number, y: number) {
  R(g, '#b9bcc4', x, y, 9, 6);
  R(g, '#8e9299', x, y + 5, 9, 2);
  R(g, '#6a6d76', x + 2, y + 1, 5, 3);
  R(g, '#9a9da6', x + 3, y + 2, 3, 1);
}

function roof(g: G, r: Rng, x: number, y: number, W: number, D: number, col: string, stuff: boolean) {
  if (D <= 0) return;
  R(g, shade(col, 1.3), x, y, W, D);
  R(g, col, x + 2, y + 2, W - 4, D - 3);
  R(g, shade(col, 0.78), x + 2, y + 2, W - 4, 1);
  R(g, shade(col, 0.78), x + 2, y + 2, 1, D - 3);
  for (let i = 0; i < (W * D) / 50; i++) R(g, shade(col, r() < 0.5 ? 0.9 : 1.1), x + 3 + ri(r, 0, Math.max(0, W - 7)), y + 3 + ri(r, 0, Math.max(0, D - 6)), 1, 1);
  if (!stuff || D < 16) return;
  if (D >= 40 && W >= 44 && r() < 0.6) {
    const pw = ri(r, 16, Math.min(40, W - 16));
    const pd = ri(r, 10, Math.min(22, D - 26));
    const px = x + ri(r, 5, W - pw - 5);
    const py = y + ri(r, 4, D - pd - 16);
    const pc = shade(col, 1.15);
    R(g, 'rgba(0,0,0,.25)', px + 2, py + pd + 8, pw, 2);
    R(g, shade(pc, 1.2), px, py, pw, pd);
    R(g, pc, px + 1, py + 1, pw - 2, pd - 2);
    R(g, shade(pc, 0.62), px, py + pd, pw, 8);
    R(g, shade(pc, 0.4), px + 2, py + pd + 2, 3, 6);
    for (let k = 0; k * 6 + 10 < pw; k++) R(g, shade(pc, 0.45), px + 8 + k * 6, py + pd + 2, 3, 2);
  }
  const n = 1 + Math.floor((W * D) / 1400) + ri(r, 0, 1);
  for (let i = 0; i < n; i++) {
    const k = ri(r, 0, 6);
    const ix = x + 4 + ri(r, 0, Math.max(0, W - 20));
    const iy = y + 3 + ri(r, 0, Math.max(0, D - 26));
    if (k <= 1 && D >= 28) waterTower(g, ix, iy);
    else if (k === 2 || k <= 1) acUnit(g, ix, iy + 3);
    else if (k === 3) {
      R(g, shade(col, 1.4), ix - 1, iy + 2, 12, 9);
      R(g, '#8fb8cc', ix, iy + 3, 10, 7);
      R(g, '#b9d8e6', ix, iy + 3, 10, 1);
      R(g, '#5a7a8a', ix + 5, iy + 3, 1, 7);
    } else if (k === 4) {
      R(g, '#6b4a2e', ix - 1, iy + 1, 14, 10);
      R(g, '#3f8a3f', ix, iy + 2, 12, 8);
      R(g, '#58a84c', ix + 1, iy + 3, 4, 3);
      R(g, '#ff8fb4', ix + 7, iy + 4, 1, 1);
      R(g, '#ffe14a', ix + 9, iy + 7, 1, 1);
    } else if (k === 5) {
      R(g, '#3a3d46', ix + 2, iy, 1, 10);
      R(g, '#3a3d46', ix, iy + 2, 5, 1);
      R(g, '#3a3d46', ix + 1, iy + 5, 3, 1);
    } else {
      R(g, '#9a9da6', ix, iy + 4, 3, 5);
      R(g, '#6a6d76', ix, iy + 4, 3, 1);
      R(g, '#9a9da6', ix + 6, iy + 6, 3, 3);
    }
  }
}

function win(g: G, r: Rng, L: number[], x: number, y: number, w: number, h: number, glass: string, p: number) {
  R(g, glass, x, y, w, h);
  R(g, shade(glass, 1.6), x, y, Math.max(1, w >> 1), 1);
  R(g, shade(glass, 1.3), x, y + 1, 1, 1);
  if (r() < p) L.push(x, y, w, h, r() < 0.75 ? 0 : r() < 0.6 ? 1 : 2);
}

function fGrid(g: G, r: Rng, L: number[], x0: number, y0: number, W: number, H: number, wall: string, st: number) {
  const big = st === 4;
  const fh = big ? 24 : 20; // one storey: a person (24 px) stands a little under one
  const ww = big ? 11 : 9;
  const wh = big ? 15 : 13;
  const cols = Math.max(1, Math.floor((W - 4) / (ww + 7)));
  const gap = (W - cols * ww) / (cols + 1);
  const glass = pick(r, ['#2b3a55', '#33415f', '#27344d', '#3a4a66']);
  const frame = st === 1 ? shade(wall, 1.35) : st === 4 ? shade(wall, 0.78) : pick(r, ['#e9e2d0', '#d8cdb8', shade(wall, 1.3)]);
  const rows = Math.floor((H - 3) / fh);
  const fe = (st === 0 || st === 7 || st === 4) && cols >= 2 && r() < 0.75;
  const fc = fe ? ri(r, 0, cols - 2) : -1;
  for (let f = 0; f < rows; f++) {
    const y = y0 + 3 + f * fh;
    for (let c = 0; c < cols; c++) {
      const x = Math.round(x0 + gap + c * (ww + gap));
      R(g, frame, x - 1, y - 1, ww + 2, wh + 2);
      win(g, r, L, x, y, ww, wh, glass, 0.38);
      if (st === 1 || st === 4 || st === 6) {
        R(g, frame, x, y, 1, 1);
        R(g, frame, x + ww - 1, y, 1, 1);
      }
      R(g, frame, x, y + (wh >> 1), ww, 1);
      if (big) R(g, frame, x + (ww >> 1), y, 1, wh);
      R(g, shade(wall, 0.7), x - 1, y + wh + 1, ww + 2, 1);
      const q = r();
      if (q < 0.1 && !big) {
        R(g, '#c8cbd0', x + 1, y + wh - 3, ww - 2, 3);
        R(g, '#8e9299', x + 1, y + wh - 1, ww - 2, 1);
      } else if (q < 0.18) {
        R(g, '#4f9a3e', x - 1, y + wh, ww + 2, 2);
        R(g, pick(r, ['#ff6b8a', '#ffd84a', '#ffffff']), x + ri(r, 0, ww - 1), y + wh, 1, 1);
      } else if (q < 0.32) R(g, pick(r, ['#c9b28a', '#a85a5a', '#6a8ab0', '#e8e0c8']), x, y, ww, 2);
    }
    if (fe) {
      const bx = Math.round(x0 + gap + fc * (ww + gap));
      const bw = Math.round(2 * ww + gap);
      const yb = y + wh + 1;
      R(g, FE, bx - 2, yb, bw + 4, 1);
      R(g, FE, bx - 2, yb - 4, bw + 4, 1);
      for (let xx = bx - 2; xx <= bx + bw + 1; xx += 2) R(g, FE, xx, yb - 4, 1, 4);
      if (f < rows - 1) for (let i = 0; i < fh - 5; i++) R(g, FE, bx + Math.round((i * (bw - 3)) / (fh - 5)), yb + 1 + i, 2, 1);
      else {
        R(g, FE, bx + 2, yb + 1, 1, 7);
        R(g, FE, bx + 5, yb + 1, 1, 7);
        R(g, FE, bx + 2, yb + 3, 4, 1);
        R(g, FE, bx + 2, yb + 6, 4, 1);
      }
    }
  }
}

function fDeco(g: G, r: Rng, L: number[], x0: number, y0: number, W: number, H: number, wall: string) {
  const pier = 4;
  const ww = 6;
  const n = Math.max(1, Math.floor((W - pier) / (ww + pier)));
  const off = Math.floor((W - (n * (ww + pier) + pier)) / 2);
  const glass = '#2a3550';
  const sp = shade(wall, 0.86);
  for (let c = 0; c < n; c++) {
    const x = x0 + off + pier + c * (ww + pier);
    for (let y = y0 + 5; y + 12 <= y0 + H; y += 15) {
      win(g, r, L, x, y, ww, 10, glass, 0.35);
      R(g, sp, x, y + 10, ww, 5);
    }
  }
  for (let c = 0; c <= n; c++) R(g, shade(wall, 1.12), x0 + off + c * (ww + pier), y0, 1, H);
  R(g, shade(wall, 1.2), x0, y0, W, 2);
  R(g, shade(wall, 0.7), x0, y0 + 2, W, 1);
}

function fGlass(g: G, r: Rng, L: number[], x0: number, y0: number, W: number, H: number, col: string) {
  const cw = pick(r, [6, 7, 8]);
  const ch = pick(r, [10, 10, 12]);
  for (let y = 0; y < H; y += ch)
    for (let x = 0; x < W; x += cw) {
      const band = ((x - y * 0.6 + 600) % 56) / 56;
      let f = band < 0.18 ? 1.32 : band < 0.3 ? 1.15 : band > 0.8 ? 0.86 : 1;
      f *= 0.94 + r() * 0.12;
      const w = Math.min(cw, W - x);
      const h = Math.min(ch, H - y);
      R(g, shade(col, f), x0 + x, y0 + y, w, h);
      if (r() < 0.16 && w > 2 && h > 2) L.push(x0 + x, y0 + y, w - 1, h - 1, r() < 0.7 ? 0 : 1);
    }
  for (let y = ch - 1; y < H; y += ch) R(g, shade(col, 0.62), x0, y0 + y, W, 1);
  for (let x = cw - 1; x < W; x += cw) R(g, shade(col, 0.72), x0 + x, y0, 1, H);
  R(g, shade(col, 1.5), x0, y0, W, 1);
}

function shop(g: G, r: Rng, L: number[], GL: number[], x0: number, y: number, W: number, gh: number, wall: string, o: BOpt) {
  let name = o.shop ?? '';
  if (o.shop === undefined) {
    const list = o.names ?? SHOPS;
    for (let i = 0; i < 8; i++) {
      const n = pick(r, list);
      if (textW(n) <= W - 6) {
        name = n;
        break;
      }
    }
  }
  const sb = pick(r, SIGNS);
  const sf = lum(sb) > 140 ? '#22222a' : '#fff6d8';
  R(g, shade(wall, 0.6), x0, y, W, gh);
  R(g, sb, x0 + 1, y, W - 2, 9);
  R(g, shade(sb, 0.7), x0 + 1, y + 8, W - 2, 1);
  if (name) drawText(g, name, x0 + ((W - textW(name)) >> 1), y + 2, sf);
  GL.push(x0 + 1, y, W - 2, 9);
  const aw = r() < 0.6 || !!o.awn;
  if (aw) {
    const ac = pick(r, AWN);
    const stripes = o.awn ?? [ac, shade(ac, 1.35)];
    for (let x = x0 + 2; x < x0 + W - 2; x++) R(g, stripes[Math.floor((x - x0) / 4) % stripes.length], x, y + 9, 1, 5 + ((x - x0) % 2));
  }
  const wy = y + (aw ? 15 : 11);
  const wh = y + gh - 2 - wy;
  const dw = 11;
  const left = o.doorL ?? r() < 0.5;
  const dx = left ? x0 + 3 : x0 + W - 3 - dw;
  const wx0 = left ? x0 + 3 + dw + 2 : x0 + 3;
  const wx1 = left ? x0 + W - 3 : dx - 2;
  R(g, '#1c2636', wx0, wy, wx1 - wx0, wh);
  R(g, '#3d5878', wx0, wy, 4, 1);
  R(g, '#3d5878', wx0, wy + 1, 2, 1);
  for (let i = wx0 + 2; i < wx1 - 3; i += 4) R(g, pick(r, ['#e8c14a', '#d94a4a', '#4ab06a', '#f2f2f2', '#e87ab0', '#4a7fd9']), i, wy + wh - 3, 2, 2);
  L.push(wx0, wy, wx1 - wx0, wh, 3);
  const dc = pick(r, DOORS);
  R(g, dc, dx, wy - 1, dw, wh + 2);
  R(g, '#22303f', dx + 1, wy, dw - 2, wh - 3);
  R(g, '#e0c060', dx + dw - 2, wy + (wh >> 1) + 1, 1, 1);
  R(g, shade(wall, 0.42), x0, y + gh - 1, W, 1);
}

function stoop(g: G, r: Rng, L: number[], x0: number, y: number, W: number, gh: number, wall: string, off?: number) {
  R(g, shade(wall, 0.85), x0, y, W, gh);
  R(g, shade(wall, 0.6), x0, y, W, 1);
  const dx = x0 + (W >> 1) - 6 + (off ?? ri(r, -(W >> 3), W >> 3));
  const dc = pick(r, DOORS);
  R(g, shade(wall, 1.35), dx - 1, y + 1, 14, 19);
  R(g, dc, dx, y + 2, 12, 17);
  R(g, shade(dc, 0.7), dx + 6, y + 2, 1, 17);
  R(g, '#ffd77a', dx + 1, y + 2, 10, 3);
  L.push(dx + 1, y + 2, 10, 3, 0);
  for (let i = 0; i < gh - 19; i++) R(g, i % 2 ? '#8a8076' : '#a89f93', dx - 2 - (i >> 1), y + 19 + i, 16 + (i >> 1) * 2, 1);
  R(g, FE, dx - 3, y + 13, 1, gh - 14);
  R(g, FE, dx + 14, y + 13, 1, gh - 14);
  for (const bx of [x0 + 3, x0 + W - 12]) {
    if (Math.abs(bx - dx) < 18) continue;
    R(g, '#1c2636', bx, y + gh - 10, 9, 7);
    for (let k = 0; k < 5; k++) R(g, FE, bx + k * 2, y + gh - 10, 1, 7);
    win(g, r, L, bx, y + 3, 8, 12, '#2b3a55', 0.4);
  }
  R(g, shade(wall, 0.45), x0, y + gh - 1, W, 1);
}

function lobby(g: G, r: Rng, L: number[], x0: number, y: number, W: number, gh: number, wall: string, deco: boolean) {
  R(g, shade(wall, 0.5), x0, y, W, gh);
  const n = Math.max(1, Math.floor(W / 18));
  const bw = W / n;
  for (let i = 0; i < n; i++) {
    const bx = Math.round(x0 + i * bw);
    R(g, '#1b2738', bx + 2, y + 3, Math.round(bw) - 2, gh - 4);
    R(g, '#3d5878', bx + 2, y + 3, 4, 1);
    if (r() < 0.8) L.push(bx + 2, y + 3, Math.round(bw) - 2, gh - 4, 3);
    R(g, deco ? shade(wall, 1.1) : '#30343c', bx, y, 2, gh);
  }
  R(g, deco ? shade(wall, 1.1) : '#30343c', x0 + W - 2, y, 2, gh);
  const cx = x0 + (W >> 1);
  R(g, deco ? '#c9a13b' : '#2a2d34', cx - 13, y + 2, 26, 3);
  R(g, '#3e5a7a', cx - 6, y + 7, 12, gh - 8);
  R(g, '#111111', cx, y + 7, 1, gh - 8);
  R(g, shade(wall, 0.4), x0, y + gh - 1, W, 1);
}

// ---------------------------------------------------------------- generic building
export function building(o: BOpt): Spr {
  const r = mulberry32(o.seed);
  const W = o.wt * T;
  const H = o.h;
  const D = o.hpx - o.h;
  const { c, g } = mkCanvas(W, o.hpx);
  const L: number[] = [];
  const GL: number[] = [];
  const boards: Board[] = [];
  const st = o.style;
  const wall = pick(r, PAL[st]);
  roof(g, r, 0, 0, W, D, pick(r, ROOFS), true);
  const y0 = D;
  R(g, wall, 0, y0, W, H);
  if (st === 0 || st === 1 || st === 6 || st === 7) {
    for (let y = y0 + 3; y < y0 + H; y += 4) R(g, shade(wall, 0.9), 0, y, W, 1);
    for (let i = 0; i < (W * H) / 40; i++) R(g, shade(wall, r() < 0.5 ? 0.82 : 1.1), ri(r, 0, W - 3), y0 + ri(r, 0, H - 2), 2, 1);
  }
  const gh = st === 1 ? 30 : 34; // the street floor: doors a little taller than the people walking past
  const bodyH = H - gh;
  if (st === 2) fGlass(g, r, L, 0, y0, W, bodyH, wall);
  else if (st === 3) fDeco(g, r, L, 0, y0, W, bodyH, wall);
  else {
    R(g, shade(wall, 1.3), 0, y0, W, 2);
    R(g, shade(wall, 0.6), 0, y0 + 2, W, 1);
    for (let x = 1; x < W; x += 4) R(g, shade(wall, 0.7), x, y0 + 3, 2, 1);
    fGrid(g, r, L, 0, y0 + 4, W, bodyH - 4, wall, st);
  }
  const gy = y0 + bodyH;
  if (o.garage) {
    R(g, shade(wall, 0.7), 0, gy, W, gh);
    R(g, '#f2ead8', 4, gy, W - 8, 6);
    drawText(g, o.shop ?? 'FDNY', (W - textW(o.shop ?? 'FDNY')) >> 1, gy + 1, '#b3262a');
    R(g, '#b3262a', 5, gy + 7, W - 10, gh - 8);
    for (let x = 7; x < W - 8; x += 6) R(g, '#22303f', x, gy + 9, 4, 3);
    for (let y = gy + 13; y < gy + gh - 1; y += 3) R(g, '#8a1c20', 5, y, W - 10, 1);
    GL.push(4, gy, W - 8, 6);
  } else if (st === 1) stoop(g, r, L, 0, gy, W, gh, wall, o.doorOff);
  else if (st === 2 || st === 3) lobby(g, r, L, 0, gy, W, gh, wall, st === 3);
  else shop(g, r, L, GL, 0, gy, W, gh, wall, o);

  if (o.boards) {
    let y = y0 + 5;
    while (y < gy - 16) {
      const bh = Math.min(ri(r, 14, 28), gy - 6 - y);
      R(g, '#15151c', 2, y - 1, W - 4, bh + 2);
      boards.push({ x: 3, y, w: W - 6, h: bh, kind: ri(r, 0, 4), seed: ri(r, 0, 9999) });
      y += bh + 4;
    }
  }
  if (o.marquee) {
    const my = gy - 10;
    R(g, '#f4ecd0', 2, my, W - 4, 11);
    R(g, '#2a2a33', 2, my + 10, W - 4, 1);
    for (let x = 2; x < W - 2; x += 3) {
      R(g, '#ffd23a', x, my, 1, 1);
      R(g, '#ffd23a', x + 1, my + 9, 1, 1);
    }
    if (textW(o.marquee) <= W - 8) drawText(g, o.marquee, (W - textW(o.marquee)) >> 1, my + 3, '#b0201c');
    GL.push(2, my, W - 4, 11);
  }
  if (o.vsign) {
    const s = o.vsign;
    const hgt = s.length * 6 + 3;
    const x = W - 10;
    const y = y0 + 8;
    const sc = st === 7 ? '#c0221c' : pick(r, ['#c0221c', '#1f2a3a', '#1f5a3a', '#e8742b']);
    R(g, FE, x - 1, y + 2, 1, hgt - 4);
    R(g, sc, x, y, 7, hgt);
    R(g, '#ffd23a', x, y, 7, 1);
    R(g, '#ffd23a', x, y + hgt - 1, 7, 1);
    for (let i = 0; i < s.length; i++) drawText(g, s[i], x + 2, y + 2 + i * 6, '#fff6d8');
    GL.push(x, y, 7, hgt);
  }
  if (st === 7) {
    for (let k = 0; k < 2; k++) {
      const x = 3 + k * (W - 13);
      const y = y0 + 10 + k * 6;
      const n = ri(r, 2, 4);
      R(g, k ? '#e8c14a' : '#c0221c', x, y, 7, n * 7 + 1);
      for (let i = 0; i < n; i++) for (let j = 0; j < 9; j++) if (r() < 0.6) R(g, k ? '#c0221c' : '#ffe14a', x + 1 + (j % 3) * 2, y + 1 + i * 7 + ((j / 3) | 0) * 2, 1, 1);
      GL.push(x, y, 7, n * 7 + 1);
    }
    R(g, '#3a2a22', 0, gy - 3, W, 1);
    for (let x = 3; x < W - 2; x += 6) {
      R(g, '#e03a2a', x, gy - 2, 3, 3);
      R(g, '#ffd23a', x + 1, gy - 1, 1, 1);
      GL.push(x, gy - 2, 3, 3);
    }
  }
  R(g, 'rgba(0,0,0,0.35)', 0, 0, 1, o.hpx);
  R(g, 'rgba(0,0,0,0.35)', W - 1, 0, 1, o.hpx);
  R(g, 'rgba(0,0,0,0.3)', 0, 0, W, 1);
  R(g, shade(wall, 1.15), 1, y0, 1, H);
  return { c, lights: L, glows: GL, boards, wall };
}

// ---------------------------------------------------------------- billboards
const BCOL = ['#ff3b5c', '#ffd23a', '#3ad0ff', '#7aff5a', '#ff7a1e', '#c95aff', '#ffffff', '#2a6aff'];
const BTXT = ['BROADWAY', 'NYC', 'I { NY', 'TKTS', 'SALE', 'NEWS', 'COLA', 'MUSICAL', 'LIVE', 'PIZZA', 'WOW', '2 FOR 1'];

export function drawBoard(g: G, b: Board, ox: number, oy: number, t: number) {
  const x = ox + b.x;
  const y = oy + b.y;
  const s = b.seed;
  const txt = BTXT[s % 12];
  const tx = x + ((b.w - textW(txt)) >> 1);
  const ty = y + ((b.h - 5) >> 1);
  g.save();
  g.beginPath();
  g.rect(x, y, b.w, b.h);
  g.clip();
  switch (b.kind) {
    case 0: {
      R(g, BCOL[s % 8], x, y, b.w, b.h);
      g.fillStyle = BCOL[((s >> 3) + 1 + (s % 8)) % 8];
      const off = Math.floor(t * 10) % 12;
      for (let i = -b.h - 12; i < b.w + 12; i += 12) for (let j = 0; j < b.h; j++) g.fillRect(x + i + off + j, y + j, 5, 1);
      R(g, '#15151c', tx - 2, ty - 2, textW(txt) + 4, 9);
      drawText(g, txt, tx, ty, '#ffffff');
      break;
    }
    case 1: {
      R(g, '#101018', x, y, b.w, b.h);
      const full = txt + ' * ' + BTXT[(s >> 2) % 12] + ' * ';
      const off = Math.floor(t * 14) % (full.length * 4);
      drawText(g, full + full + full, x - off, ty, BCOL[s % 8]);
      break;
    }
    case 2: {
      const c1 = BCOL[(s >> 1) % 8];
      R(g, c1, x, y, b.w, b.h);
      const on = Math.floor(t * 2 + s) % 2 === 0;
      const bc = on ? '#ffffff' : '#15151c';
      R(g, bc, x, y, b.w, 1);
      R(g, bc, x, y + b.h - 1, b.w, 1);
      R(g, bc, x, y, 1, b.h);
      R(g, bc, x + b.w - 1, y, 1, b.h);
      drawText(g, txt, tx, ty, '#15151c');
      break;
    }
    case 3: {
      const k = Math.floor(t * 3);
      for (let j = 0; j < b.h; j += 4)
        for (let i = 0; i < b.w; i += 4) {
          g.fillStyle = BCOL[hash2(i + s * 7 + k * 13, j + k * 5) % 8];
          g.fillRect(x + i, y + j, 4, 4);
        }
      break;
    }
    default: {
      const p = Math.sin(t * 3 + s) > 0;
      R(g, p ? '#ff3b5c' : '#c92a48', x, y, b.w, b.h);
      drawText(g, 'I { NY', x + ((b.w - 23) >> 1), ty, '#ffffff');
    }
  }
  g.restore();
}

// ---------------------------------------------------------------- towers
export interface TowerOpt {
  wt: number;
  tiers: [number, number][];
  wall: string;
  glass?: boolean;
  spire?: number;
  crown?: boolean;
  rd?: number;
  seed: number;
}

export function tower(o: TowerOpt): Spr {
  const r = mulberry32(o.seed);
  const W = o.wt * T;
  const n = o.tiers.length;
  const last = o.tiers[n - 1][0];
  const rd = o.rd ?? 12;
  const sp = o.spire ?? 0;
  let H = rd + last + sp;
  for (const t of o.tiers) H += t[1];
  const { c, g } = mkCanvas(W, H);
  const L: number[] = [];
  const GL: number[] = [];
  const lamps: number[] = [];
  let yb = H;
  let topY = 0;
  let z0 = 0;
  const tiers: { x: number; w: number; top: number; h: number; d: number; z0: number }[] = [];
  for (let i = 0; i < n; i++) {
    const [ins, h] = o.tiers[i];
    const x = ins;
    const w = W - 2 * ins;
    const top = yb - h;
    const d = rd + 2 * (last - ins);
    R(g, shade(o.wall, 1.25), x, top - d, w, d);
    R(g, shade(o.wall, 0.92), x + 1, top - d + 1, w - 2, d - 1);
    R(g, o.wall, x, top, w, h);
    const gh = i === 0 ? 20 : 0;
    if (o.glass) fGlass(g, r, L, x, top, w, h - gh, o.wall);
    else fDeco(g, r, L, x, top, w, h - gh, o.wall);
    if (i === 0) lobby(g, r, L, x, top + h - gh, w, gh, o.wall, !o.glass);
    R(g, 'rgba(0,0,0,.3)', x, top, 1, h);
    R(g, 'rgba(0,0,0,.3)', x + w - 1, top, 1, h);
    tiers.push({ x, w, top, h, d, z0 });
    z0 += h;
    topY = top;
    yb = top - (i < n - 1 ? o.tiers[i + 1][0] - ins : 0);
  }
  const cx = W >> 1;
  let ry = topY - (rd >> 1);
  let needle = sp;
  if (o.crown) {
    const wl = W - 2 * last;
    for (let i = 0; i < 5; i++) {
      const wi = wl - i * 5;
      const yy = topY - i * 6;
      R(g, i % 2 ? '#d5dde3' : '#b4bec8', cx - wi / 2, yy - 6, wi, 6);
      R(g, '#eef3f6', cx - wi / 2, yy - 6, wi, 1);
      for (let k = 0; k * 5 + 4 < wi; k++) tri(g, '#2a3550', cx - wi / 2 + 3 + k * 5, yy - 5, 2, 4);
    }
    GL.push(cx - wl / 2, topY - 31, wl, 31);
    ry = topY - 30;
    needle = sp - 30;
  }
  if (needle > 0) {
    R(g, '#aab2ba', cx - 2, ry - needle * 0.4, 4, needle * 0.4);
    R(g, '#c8d0d8', cx - 1, ry - needle, 2, needle);
    R(g, '#e03a3a', cx - 1, ry - needle, 2, 2);
    lamps.push(cx, ry - needle + 1, 18);
  }
  const spireY = o.crown ? topY : needle > 0 ? topY - (rd >> 1) : 0;
  return { c, wall: o.wall, tiers, spireY, lights: L, glows: GL, lamps };
}

// ---------------------------------------------------------------- museum-like
export interface MuseumOpt {
  wt: number;
  hpx: number;
  h: number;
  wall: string;
  cols: number;
  name: string;
  banners?: string[];
  ped?: boolean;
  steps?: number;
  arches?: boolean;
  flag?: boolean;
  lions?: boolean;
  seed: number;
}

export function museum(o: MuseumOpt): Spr {
  const W = o.wt * T;
  const D = o.hpx - o.h;
  const { c, g } = mkCanvas(W, o.hpx);
  const r = mulberry32(o.seed);
  const L: number[] = [];
  const GL: number[] = [];
  const wall = o.wall;
  roof(g, r, 0, 0, W, D, shade(wall, 0.72), false);
  for (let x = 10; x + 14 < W; x += 26) {
    R(g, shade(wall, 1.2), x - 1, 7, 16, Math.max(4, D - 22));
    R(g, '#9fc3d6', x, 8, 14, Math.max(2, D - 24));
    R(g, '#c4dce8', x, 8, 14, 1);
    R(g, '#6a8a9a', x + 7, 8, 1, Math.max(2, D - 24));
  }
  const y0 = D;
  const H = o.h;
  const st = o.steps ?? 10;
  R(g, wall, 0, y0, W, H);
  const cw = Math.round(W * 0.56);
  const cx0 = (W - cw) >> 1;
  for (let x = 6; x + 6 < cx0 - 4; x += 12)
    for (const xx of [x, W - x - 6]) {
      R(g, shade(wall, 1.2), xx - 1, y0 + 15, 8, H - st - 27);
      win(g, r, L, xx, y0 + 16, 6, H - st - 29, '#2b3a55', 0.5);
      R(g, shade(wall, 1.2), xx, y0 + 16 + ((H - st - 29) >> 1), 6, 1);
    }
  R(g, shade(wall, 1.15), 0, y0, W, 3);
  R(g, shade(wall, 0.75), 0, y0 + 3, W, 1);
  R(g, shade(wall, 1.08), cx0 - 2, y0 + 4, cw + 4, 9);
  R(g, shade(wall, 0.7), cx0 - 2, y0 + 13, cw + 4, 1);
  if (textW(o.name) <= cw) drawText(g, o.name, (W - textW(o.name)) >> 1, y0 + 6, shade(wall, 0.42));
  if (o.ped) {
    tri(g, shade(wall, 1.12), W >> 1, y0 - 13, cw / 2 + 2, 13);
    tri(g, shade(wall, 0.85), W >> 1, y0 - 8, cw / 2 - 8, 8);
  }
  const py = y0 + 14;
  const ph = H - 14 - st;
  R(g, shade(wall, 0.5), cx0, py, cw, ph);
  if (o.arches) {
    const aw = Math.floor((cw - 12) / 3);
    for (let i = 0; i < 3; i++) {
      const ax = cx0 + 4 + i * (aw + 2);
      R(g, '#243247', ax, py + 3, aw, ph - 3);
      R(g, shade(wall, 0.5), ax, py + 3, 2, 2);
      R(g, shade(wall, 0.5), ax + aw - 2, py + 3, 2, 2);
      for (let x = ax + 3; x < ax + aw; x += 4) R(g, '#3d5878', x, py + 3, 1, ph - 3);
      R(g, '#3d5878', ax, py + (ph >> 1), aw, 1);
      L.push(ax, py + 3, aw, ph - 3, 3);
    }
  } else {
    for (let i = 0; i < 3; i++) {
      const ddx = cx0 + Math.round((cw * (i + 1)) / 4) - 4;
      R(g, '#3a2a1e', ddx, py + ph - 13, 8, 13);
      R(g, '#ffd77a', ddx + 1, py + ph - 12, 6, 3);
      L.push(ddx, py + ph - 13, 8, 13, 3);
      win(g, r, L, ddx + 1, py + 4, 6, Math.max(3, ph - 22), '#2b3a55', 0.5);
    }
  }
  const n = o.cols;
  for (let i = 0; i < n; i++) {
    const x = cx0 + Math.round((i * (cw - 5)) / (n - 1));
    R(g, shade(wall, 1.2), x, py, 5, ph);
    R(g, shade(wall, 1.4), x + 1, py, 1, ph);
    R(g, shade(wall, 0.82), x + 4, py, 1, ph);
    R(g, shade(wall, 1.28), x - 1, py, 7, 2);
    R(g, shade(wall, 1.1), x - 1, py + ph - 2, 7, 2);
  }
  if (o.banners)
    o.banners.forEach((bc, i) => {
      const x = cx0 + Math.round(((i * 2 + 1) * (cw - 5)) / ((n - 1) * 2)) + 1;
      if (x > cx0 + cw - 6) return;
      R(g, bc, x - 1, py + 3, 5, Math.round(ph * 0.55));
      R(g, shade(bc, 1.45), x, py + 5, 3, 3);
      R(g, shade(bc, 0.7), x, py + 10, 3, 1);
    });
  if (o.flag) {
    const fx = (W >> 1) - 12;
    const fy = py + 2;
    for (let i = 0; i < 13; i++) R(g, i % 2 ? '#f2f2f2' : '#c0392b', fx, fy + i, 24, 1);
    R(g, '#2b3f8a', fx, fy, 10, 7);
    for (let i = 0; i < 6; i++) R(g, '#ffffff', fx + 1 + (i % 3) * 3, fy + 1 + ((i / 3) | 0) * 3, 1, 1);
  }
  for (let i = 0; i < st; i++) {
    const sx = Math.max(0, cx0 - 6 - i);
    R(g, i % 2 ? shade(wall, 0.76) : shade(wall, 1.04), sx, y0 + H - st + i, W - 2 * sx, 1);
  }
  if (o.lions)
    for (const lx of [cx0 - 12, cx0 + cw + 2]) {
      R(g, shade(wall, 0.9), lx, y0 + H - 9, 10, 9);
      R(g, shade(wall, 1.3), lx, y0 + H - 9, 10, 1);
      R(g, '#efe9dc', lx + 1, y0 + H - 14, 8, 5);
      R(g, '#efe9dc', lx + 1, y0 + H - 17, 4, 4);
      R(g, '#bfb8a8', lx + 2, y0 + H - 16, 1, 1);
    }
  R(g, 'rgba(0,0,0,0.35)', 0, 0, 1, o.hpx);
  R(g, 'rgba(0,0,0,0.35)', W - 1, 0, 1, o.hpx);
  return { c, wall: o.wall, lights: L, glows: GL };
}

// ---------------------------------------------------------------- cathedral
export function cathedral(o: { wt: number; hpx: number; h: number; wall: string; spires: number; seed: number }): Spr {
  const W = o.wt * T;
  const D = o.hpx - o.h;
  const H = o.h;
  const { c, g } = mkCanvas(W, o.hpx);
  const wall = o.wall;
  const cx = W >> 1;
  const L: number[] = [];
  const GL: number[] = [];
  const rt = Math.max(0, D - 62);
  // slate roof
  R(g, '#5f6d7c', 6, rt, W - 12, D - rt);
  R(g, '#7a8898', 6, rt, (W - 12) >> 1, D - rt);
  R(g, '#96a4b2', cx - 1, rt, 2, D - rt);
  for (let y = rt + 4; y < D; y += 5) R(g, 'rgba(0,0,0,.14)', 6, y, W - 12, 1);
  R(g, shade(wall, 0.9), 0, rt + 8, 6, D - rt - 8);
  R(g, shade(wall, 0.9), W - 6, rt + 8, 6, D - rt - 8);
  // facade
  R(g, wall, 0, D, W, H);
  for (let y = D + 6; y < D + H; y += 7) R(g, shade(wall, 0.93), 0, y, W, 1);
  tri(g, wall, cx, D - 16, W * 0.22, 16);
  tri(g, shade(wall, 1.12), cx, D - 16, W * 0.1, 8);
  R(g, shade(wall, 1.3), cx, D - 22, 1, 6);
  R(g, shade(wall, 1.3), cx - 2, D - 20, 5, 1);
  // rose window
  ell(g, shade(wall, 1.25), cx, D + 16, 8, 8);
  ell(g, '#22304a', cx, D + 16, 6, 6);
  for (const [dx, dy, col] of [[-3, -2, '#d94a6a'], [2, -3, '#4aa3d9'], [3, 2, '#e8c14a'], [-2, 3, '#4ab06a'], [0, 0, '#f2f2f2'], [-4, 1, '#c95aff'], [4, -1, '#ff7a1e']] as [number, number, string][]) R(g, col, cx + dx, D + 16 + dy, 2, 2);
  GL.push(cx - 7, D + 9, 15, 15);
  // doors
  const door = (dx: number, w: number, h: number) => {
    R(g, shade(wall, 1.25), dx - w / 2 - 1, D + H - h - 1, w + 2, h + 1);
    tri(g, shade(wall, 1.25), dx, D + H - h - w / 2 - 2, w / 2 + 1, w / 2 + 1);
    R(g, '#3a2618', dx - w / 2, D + H - h, w, h);
    tri(g, '#3a2618', dx, D + H - h - w / 2, w / 2, w / 2);
    R(g, '#22140c', dx, D + H - h, 1, h);
    L.push(dx - w / 2, D + H - h, w, h, 3);
  };
  door(cx, 12, 20);
  if (o.spires === 2) {
    door(cx - W * 0.36, 8, 13);
    door(cx + W * 0.36, 8, 13);
  }
  const lancet = (x: number, y: number, h: number) => {
    R(g, '#2a2f3f', x, y, 3, h);
    R(g, shade(wall, 1.25), x - 1, y - 1, 1, h + 1);
    R(g, shade(wall, 1.25), x + 3, y - 1, 1, h + 1);
    R(g, '#2a2f3f', x + 1, y - 1, 1, 1);
    if (hash2(x, y) % 3 === 0) L.push(x, y, 3, h, 1);
  };
  const spire = (tx: number, tw: number, rise: number, sh: number) => {
    R(g, shade(wall, 1.05), tx, D - rise, tw, H + rise);
    R(g, shade(wall, 1.2), tx, D - rise, 1, H + rise);
    R(g, shade(wall, 0.82), tx + tw - 1, D - rise, 1, H + rise);
    for (let y = D - rise + 8; y < D + H - 30; y += 20) {
      R(g, shade(wall, 0.8), tx, y - 3, tw, 1);
      lancet(tx + (tw >> 1) - 4, y, 10);
      lancet(tx + (tw >> 1) + 1, y, 10);
    }
    R(g, shade(wall, 1.25), tx - 1, D - rise - 2, tw + 2, 3);
    tri(g, shade(wall, 0.88), tx + tw / 2, D - rise - 2 - sh, tw / 2, sh);
    tri(g, shade(wall, 1.1), tx + tw / 2 - tw / 6, D - rise - 2 - sh + 4, tw / 5, sh - 4);
    R(g, shade(wall, 1.3), tx + (tw >> 1), D - rise - sh - 6, 1, 5);
    R(g, shade(wall, 1.3), tx + (tw >> 1) - 1, D - rise - sh - 4, 3, 1);
    R(g, shade(wall, 1.2), tx - 1, D - rise - 8, 2, 7);
    R(g, shade(wall, 1.2), tx + tw - 1, D - rise - 8, 2, 7);
  };
  if (o.spires === 2) {
    const tw = Math.round(W * 0.27);
    spire(0, tw, 22, 34);
    spire(W - tw, tw, 22, 34);
  } else {
    const tw = Math.round(W * 0.42);
    spire(cx - (tw >> 1), tw, 26, 40);
    door(cx, 10, 18);
    lancet(6, D + 20, 14);
    lancet(W - 9, D + 20, 14);
  }
  R(g, shade(wall, 0.6), 0, D + H - 1, W, 1);
  outline(c, shade(wall, 0.4));
  return { c, wall, kind3d: 'cathedral', lights: L, glows: GL };
}

// ---------------------------------------------------------------- unique landmarks
export function guggenheim(): Spr {
  const { c, g } = mkCanvas(128, 128);
  R(g, '#bdb9ae', 0, 24, 128, 104);
  R(g, '#aaa69c', 0, 24, 128, 2);
  // annex
  R(g, '#dedbd2', 6, 14, 44, 46);
  R(g, '#c9c6bd', 8, 16, 40, 42);
  R(g, '#f1efe8', 6, 60, 44, 68);
  for (let y = 68; y < 112; y += 10) R(g, '#3a4658', 10, y, 36, 3);
  R(g, '#d6d3ca', 46, 60, 4, 68);
  // rotunda
  const cx = 88;
  for (let i = 0; i < 5; i++) {
    const rx = 24 + i * 3.5;
    const yb = 114 - i * 15;
    R(g, '#f4f2ec', cx - rx, yb - 13, rx * 2, 13);
    R(g, '#ffffff', cx - rx * 0.75, yb - 13, rx * 0.35, 13);
    R(g, '#dcd9d0', cx + rx * 0.45, yb - 13, rx * 0.35, 13);
    R(g, '#c4c1b8', cx + rx * 0.8, yb - 13, rx * 0.2, 13);
    R(g, '#5a626c', cx - rx + 3, yb, rx * 2 - 6, 2);
  }
  ell(g, '#e6e3da', cx, 40, 38, 11);
  ell(g, '#cfccc3', cx, 40, 30, 8);
  ell(g, '#9fc3d6', cx, 40, 20, 5);
  ell(g, '#c9e0ec', cx - 4, 38, 8, 2);
  R(g, '#f1efe8', 50, 114, 78, 14);
  R(g, '#2a3344', 70, 117, 36, 11);
  R(g, '#4a6a8a', 70, 117, 36, 1);
  drawText(g, 'GUGGENHEIM', cx - 19, 105, '#6a6e78');
  R(g, 'rgba(0,0,0,.3)', 0, 127, 128, 1);
  return { c, lights: [70, 117, 36, 11, 3], glows: [] };
}

export function arena(): Spr {
  const W = 112;
  const { c, g } = mkCanvas(W, 100);
  const cx = 56;
  for (let x = 2; x < 110; x++) {
    const e = 24 * Math.sqrt(Math.max(0, 1 - Math.pow((x - cx) / 54, 2)));
    const f = 1.1 - (Math.abs(x - cx) / 54) * 0.42;
    const col = shade('#b8a68c', x % 6 === 0 ? f * 0.82 : f);
    R(g, col, x, 26 + e, 1, 44);
    R(g, shade('#2a3a52', f + 0.2), x, 26 + e + 31, 1, 8);
    R(g, shade('#8a7a64', f), x, 26 + e + 42, 1, 2);
  }
  ell(g, '#d6ccb8', cx, 26, 54, 24);
  ell(g, '#c4b9a2', cx, 26, 45, 19);
  ell(g, '#d6ccb8', cx, 26, 32, 13);
  ell(g, '#b8ad96', cx, 26, 18, 7);
  ell(g, '#8f8672', cx, 26, 6, 2);
  R(g, '#15151c', cx - 23, 62, 46, 11);
  R(g, '#e8742b', cx - 23, 62, 46, 1);
  drawText(g, 'THE GARDEN', cx - 19, 65, '#ffd23a');
  R(g, '#2a2d34', cx - 14, 84, 28, 3);
  outline(c, '#4a4234');
  return { c, wall: '#b8a68c', kind3d: 'arena', glows: [cx - 22, 63, 46, 11], lights: [] };
}

export function liberty(): Spr {
  const W = 80;
  const H = 158;
  const { c, g } = mkCanvas(W, H);
  // star fort
  R(g, '#a89c88', 2, H - 22, 76, 21);
  for (let i = 0; i < 10; i++) tri(g, '#bdb19c', 6 + i * 7.6, H - 29, 4, 7);
  R(g, '#c9bea8', 6, H - 25, 68, 6);
  R(g, '#8f8474', 2, H - 4, 76, 3);
  for (let x = 8; x < 74; x += 9) R(g, '#9a8e7a', x, H - 18, 1, 13);
  R(g, '#4a4238', 37, H - 13, 6, 10);
  // pedestal
  R(g, '#c4b79f', 24, H - 42, 32, 18);
  R(g, '#d6c9b0', 24, H - 42, 32, 2);
  R(g, '#cdbfa6', 28, H - 68, 24, 26);
  for (let k = 0; k < 4; k++) R(g, '#6a6052', 31 + k * 5, H - 62, 3, 13);
  R(g, '#ddd0b8', 26, H - 72, 28, 4);
  R(g, '#c4b79f', 30, H - 78, 20, 6);
  R(g, 'rgba(0,0,0,.14)', 46, H - 78, 10, 54);
  // statue
  const C = '#5fb59a';
  const D2 = '#3e8f7a';
  const Lc = '#8fd6bd';
  const sb = H - 78;
  for (let i = 0; i < 36; i++) {
    const hw = Math.round(5 + i * 0.12);
    R(g, C, 40 - hw, sb - 36 + i, hw * 2, 1);
    R(g, D2, 40 + hw - 3, sb - 36 + i, 3, 1);
    R(g, Lc, 40 - hw, sb - 36 + i, 2, 1);
  }
  line(g, D2, 38, sb - 30, 35, sb - 2);
  line(g, D2, 42, sb - 26, 44, sb - 2);
  line(g, D2, 40, sb - 16, 39, sb - 2);
  R(g, C, 37, sb - 44, 6, 8);
  R(g, Lc, 37, sb - 44, 2, 3);
  R(g, D2, 38, sb - 40, 4, 1);
  R(g, D2, 41, sb - 44, 2, 8);
  for (let a = -3; a <= 3; a++) line(g, C, 40, sb - 45, 40 + a * 3, sb - 51 + Math.abs(a));
  for (let i = 0; i < 20; i++) R(g, i % 5 === 4 ? D2 : C, 34 - Math.round(i * 0.12), sb - 35 - i, 3, 1);
  R(g, '#c9a13b', 30, sb - 59, 5, 4);
  tri(g, '#f5c542', 32.5, sb - 67, 3, 8);
  R(g, '#fff1a8', 32, sb - 63, 2, 3);
  R(g, Lc, 44, sb - 28, 5, 9);
  R(g, D2, 44, sb - 28, 1, 9);
  outline(c, '#2a3a36');
  return { c, lamps: [33, sb - 63, 34] };
}

export function arch(): Spr {
  const { c, g } = mkCanvas(50, 58);
  g.translate(1, 1);
  R(g, '#f6f2e8', 0, 2, 48, 9);
  R(g, '#e9e4d8', 0, 10, 48, 46);
  R(g, '#d6d0c2', 0, 11, 48, 2);
  R(g, '#bfb8a8', 8, 16, 32, 1);
  R(g, '#bfb8a8', 12, 19, 24, 1);
  R(g, '#d6d0c2', 0, 23, 48, 2);
  R(g, '#d0c9ba', 3, 30, 9, 20);
  R(g, '#f6f2e8', 5, 33, 5, 12);
  R(g, '#d0c9ba', 36, 30, 9, 20);
  R(g, '#f6f2e8', 38, 33, 5, 12);
  R(g, '#cfc8b8', 0, 52, 15, 4);
  R(g, '#cfc8b8', 33, 52, 15, 4);
  R(g, '#bfb8a8', 13, 26, 2, 30);
  R(g, '#bfb8a8', 33, 26, 2, 30);
  g.setTransform(1, 0, 0, 1, 0, 0);
  g.clearRect(16, 35, 18, 23);
  for (let dy = 0; dy <= 9; dy++) {
    const hw = Math.round(9 * Math.sqrt(1 - (dy * dy) / 81));
    g.clearRect(25 - hw, 35 - dy, hw * 2, 1);
  }
  outline(c, '#6a6458');
  return { c };
}

export function vessel(): Spr {
  const { c, g } = mkCanvas(66, 62);
  for (let y = 0; y < 52; y++) {
    const t = y / 51;
    const hw = Math.round(30 - t * 13);
    for (let x = -hw; x <= hw; x++) {
      const band = Math.floor(y / 5);
      const v = (x + 60 + (band % 2) * 3) % 6;
      const col = y % 5 === 4 || v === 0 ? '#6a3520' : x < -hw * 0.3 ? '#e09a5c' : x > hw * 0.5 ? '#9a5028' : '#c0703c';
      g.fillStyle = col;
      g.fillRect(33 + x, 8 + y, 1, 1);
    }
  }
  ell(g, '#8a4a28', 33, 8, 30, 6);
  ell(g, '#3a1e10', 33, 8, 24, 4);
  outline(c, '#3a1e10');
  return { c };
}

export function bridgeTower(): Spr {
  const W = 40;
  const FH = 84;
  const TD = 128;
  const { c, g } = mkCanvas(W, FH + TD + 10);
  const st = '#a39280';
  R(g, shade(st, 1.18), 4, 0, 32, TD);
  R(g, shade(st, 1.02), 6, 2, 28, TD - 2);
  for (let y = 10; y < TD; y += 12) R(g, shade(st, 0.92), 6, y, 28, 1);
  R(g, st, 4, TD, 32, FH);
  for (let y = TD + 5; y < TD + FH; y += 6) R(g, shade(st, 0.88), 4, y, 32, 1);
  for (let y = TD; y < TD + FH; y += 12) for (let x = 8; x < 36; x += 8) R(g, shade(st, 0.88), x + ((y / 12) % 2 ? 4 : 0), y, 1, 6);
  R(g, shade(st, 1.25), 2, TD, 36, 4);
  R(g, shade(st, 0.7), 2, TD + 4, 36, 1);
  for (const ax of [9, 22]) {
    R(g, '#3d3a44', ax, TD + 22, 9, 46);
    tri(g, '#3d3a44', ax + 4.5, TD + 12, 4.5, 10);
    R(g, '#5a5866', ax, TD + 22, 2, 46);
  }
  R(g, shade(st, 1.1), 4, TD + 68, 32, 3);
  R(g, shade(st, 0.8), 0, TD + FH - 2, W, 12);
  R(g, shade(st, 1.05), 0, TD + FH - 2, W, 2);
  R(g, 'rgba(0,0,0,.25)', 35, TD, 1, FH);
  return { c };
}

export function bridgeCable(W: number, H: number, p1: number, p2: number): Spr {
  const { c, g } = mkCanvas(W, H);
  const mid = (p1 + p2) / 2;
  const half = (p2 - p1) / 2;
  const yAt = (x: number) => {
    if (x <= p1) return H - 6 + (4 - (H - 6)) * Math.pow(x / p1, 1.4);
    if (x >= p2) return H - 6 + (4 - (H - 6)) * Math.pow((W - x) / (W - p2), 1.4);
    const u = (x - mid) / half;
    return H - 24 - (H - 28) * u * u;
  };
  for (const p of [p1, p2]) for (let k = 1; k <= 6; k++) for (const s of [-1, 1]) line(g, 'rgba(70,64,58,.55)', p, 6, p + s * k * 12, H - 4);
  for (let x = 0; x < W; x++) {
    const y = Math.round(yAt(x));
    if (x % 5 === 0) R(g, 'rgba(50,45,40,.6)', x, y + 2, 1, H - 6 - y);
    R(g, '#3a3531', x, y, 1, 2);
  }
  R(g, '#4a443e', 0, H - 5, W, 1);
  for (let x = 0; x < W; x += 8) R(g, '#4a443e', x, H - 5, 1, 5);
  return { c };
}

export function carousel(): Spr {
  const { c, g } = mkCanvas(48, 50);
  R(g, '#e8eef2', 0, 0, 48, 24);
  for (let x = 0; x < 48; x += 8) R(g, '#c4ced6', x, 0, 1, 24);
  R(g, '#c4ced6', 0, 12, 48, 1);
  R(g, '#9fc9de', 0, 24, 48, 26);
  R(g, '#5a2a22', 8, 45, 32, 3);
  R(g, '#d8382e', 8, 27, 32, 5);
  for (let k = 0; k < 6; k++) R(g, '#f5e9c8', 10 + k * 5, 27, 2, 5);
  R(g, '#e8c14a', 8, 32, 32, 1);
  for (const [hx, hy] of [[12, 37], [22, 35], [32, 37]]) {
    R(g, '#e8c14a', hx + 2, 32, 1, 13);
    R(g, '#f2f2f2', hx, hy, 6, 4);
    R(g, '#f2f2f2', hx - 1, hy - 2, 2, 3);
    R(g, '#c0392b', hx + 2, hy, 2, 2);
  }
  for (let x = 0; x < 48; x += 12) R(g, '#f4f6f8', x, 24, 2, 26);
  R(g, '#f4f6f8', 46, 24, 2, 26);
  R(g, '#f4f6f8', 0, 24, 48, 2);
  R(g, '#f4f6f8', 0, 48, 48, 2);
  return { c, lights: [2, 26, 44, 22, 3] };
}

export function fountain(angel: boolean): Spr {
  const { c, g } = mkCanvas(50, 46);
  ell(g, '#8f887b', 25, 33, 23, 11);
  ell(g, '#b9b2a4', 25, 31, 23, 11);
  ell(g, '#4aa8d4', 25, 30, 20, 8);
  ell(g, '#7cc8e8', 20, 28, 9, 2);
  R(g, '#b9b2a4', 22, 18, 6, 12);
  R(g, '#8f887b', 26, 18, 2, 12);
  ell(g, '#c9c2b4', 25, 18, 8, 2);
  if (angel) {
    R(g, '#5a9a86', 23, 5, 4, 12);
    R(g, '#5a9a86', 24, 2, 2, 3);
    R(g, '#5a9a86', 17, 6, 6, 3);
    R(g, '#5a9a86', 27, 6, 6, 3);
    R(g, '#5a9a86', 18, 9, 3, 2);
    R(g, '#5a9a86', 29, 9, 3, 2);
    R(g, '#3e7a68', 26, 6, 1, 11);
  } else {
    R(g, '#e8f6ff', 24, 3, 2, 15);
    R(g, '#e8f6ff', 21, 7, 1, 4);
    R(g, '#e8f6ff', 28, 7, 1, 4);
    R(g, '#e8f6ff', 19, 11, 1, 3);
    R(g, '#e8f6ff', 30, 11, 1, 3);
  }
  R(g, '#bfe6f8', 19, 20, 1, 7);
  R(g, '#bfe6f8', 30, 20, 1, 7);
  outline(c, '#4a463e');
  return { c };
}

export function boat(kind: number): Spr {
  if (kind <= 1 || kind === 4) {
    const hull = kind === 0 ? '#2b4f8a' : kind === 1 ? '#e8742b' : '#f2c230';
    const deck = kind === 1 ? '#f08a3c' : '#f2f2f2';
    const w = kind === 4 ? 44 : 78;
    const { c, g } = mkCanvas(w, 38);
    R(g, hull, 3, 23, w - 6, 10);
    R(g, hull, 1, 25, 2, 6);
    R(g, hull, w - 3, 25, 2, 6);
    R(g, shade(hull, 0.65), 3, 31, w - 6, 2);
    R(g, '#f2f2f2', 3, 23, w - 6, 1);
    R(g, deck, 8, 13, w - 16, 10);
    for (let x = 10; x < w - 12; x += 5) R(g, '#2a3a52', x, 16, 3, 4);
    if (kind !== 4) {
      R(g, shade(deck, 0.94), 16, 6, w - 32, 7);
      for (let x = 18; x < w - 20; x += 5) R(g, '#2a3a52', x, 8, 3, 3);
      R(g, kind === 1 ? '#2a2a33' : '#c0392b', (w >> 1) - 3, 1, 6, 5);
    } else drawText(g, 'TAXI', 14, 26, '#22222a');
    R(g, '#d8ecf8', 0, 34, w, 1);
    outline(c);
    return { c };
  }
  if (kind === 2) {
    const { c, g } = mkCanvas(26, 36);
    R(g, '#f2f2f2', 5, 27, 16, 5);
    R(g, '#f2f2f2', 3, 27, 2, 3);
    R(g, '#2b5fb0', 5, 30, 16, 2);
    R(g, '#5a4a3a', 13, 2, 1, 25);
    for (let i = 0; i < 22; i++) R(g, '#fafafa', 14, 3 + i, 1 + i * 0.42, 1);
    for (let i = 0; i < 18; i++) R(g, '#e4e4ee', 13 - i * 0.4, 7 + i, i * 0.4, 1);
    outline(c);
    return { c };
  }
  if (kind === 3) {
    const { c, g } = mkCanvas(32, 26);
    R(g, '#a8342a', 2, 15, 28, 7);
    R(g, '#22222a', 2, 20, 28, 2);
    R(g, '#f2f2f2', 8, 8, 14, 7);
    R(g, '#2a3a52', 10, 10, 10, 3);
    R(g, '#22222a', 13, 2, 5, 6);
    R(g, '#e8c14a', 13, 3, 5, 1);
    outline(c);
    return { c };
  }
  if (kind === 5) {
    const { c, g } = mkCanvas(100, 82);
    R(g, '#2a2420', 8, 62, 84, 12);
    R(g, '#2a2420', 4, 62, 4, 6);
    R(g, '#2a2420', 92, 60, 4, 8);
    R(g, '#e8e2d0', 6, 65, 88, 2);
    R(g, '#6a4a2e', 8, 60, 84, 2);
    line(g, '#5a4636', 92, 60, 99, 54);
    for (const x of [26, 50, 74]) {
      line(g, 'rgba(60,45,30,.7)', x, 8, x - 15, 60);
      line(g, 'rgba(60,45,30,.7)', x, 8, x + 15, 60);
      R(g, '#5a4636', x, 6, 2, 55);
      for (const [yy, hw] of [[14, 10], [28, 12], [42, 12]]) {
        R(g, '#5a4636', x - hw, yy, hw * 2 + 2, 1);
        R(g, '#efe9d8', x - hw + 1, yy + 1, hw * 2, 3);
        R(g, '#cfc8b4', x - hw + 1, yy + 3, hw * 2, 1);
      }
      R(g, '#c0392b', x + 2, 4, 5, 3);
    }
    outline(c);
    return { c };
  }
  // aircraft carrier
  const { c, g } = mkCanvas(212, 62);
  R(g, '#6a7078', 4, 34, 204, 22);
  R(g, '#6a7078', 0, 34, 4, 12);
  R(g, '#5a6068', 4, 44, 204, 12);
  R(g, '#3a3f46', 4, 54, 204, 2);
  R(g, '#8a9098', 0, 10, 212, 26);
  R(g, '#9aa0a8', 0, 10, 212, 2);
  R(g, '#e8c14a', 10, 24, 186, 1);
  R(g, '#f2f2f2', 10, 17, 120, 1);
  for (let x = 14; x < 190; x += 12) R(g, '#f2f2f2', x, 30, 6, 1);
  R(g, '#7a8088', 134, 0, 28, 14);
  R(g, '#5a6068', 134, 14, 28, 7);
  R(g, '#2a3a52', 137, 16, 22, 2);
  R(g, '#4a4f56', 146, 0, 2, 4);
  drawText(g, '11', 140, 5, '#f2f2f2');
  drawText(g, '11', 12, 40, '#c9ced6');
  const plane = ['....p....', '...ppp...', 'ppppppppp', '...ppp...', '..ppppp..'];
  const pc = ['#3a4a6a', '#c9ced6', '#5a6a5a', '#2a2a33', '#c9ced6', '#3a4a6a'];
  [[20, 13], [44, 26], [70, 13], [96, 27], [172, 14], [186, 26]].forEach(([px, py], i) => pix(g, px, py, plane, { p: pc[i] }));
  outline(c);
  return { c };
}

export function tkts(): Spr {
  const { c, g } = mkCanvas(50, 40);
  g.translate(1, 1);
  for (let i = 0; i < 10; i++) {
    R(g, '#e8463c', 2 + i, 34 - i * 3, 44 - 2 * i, 2);
    R(g, '#a8241e', 2 + i, 36 - i * 3, 44 - 2 * i, 1);
  }
  R(g, '#c0302a', 12, 0, 24, 8);
  drawText(g, 'TKTS', 17, 1, '#ffffff');
  g.setTransform(1, 0, 0, 1, 0, 0);
  outline(c, '#5a1410');
  return { c, glows: [1, 1, 48, 38] };
}

export function castle(col: string): Spr {
  const { c, g } = mkCanvas(66, 62);
  const r = mulberry32(77);
  R(g, shade(col, 1.25), 6, 26, 36, 6);
  R(g, col, 6, 32, 36, 28);
  R(g, shade(col, 1.25), 40, 10, 20, 6);
  R(g, shade(col, 1.05), 40, 16, 20, 44);
  for (let k = 0; k < 6; k++) R(g, col, 6 + k * 6, 23, 3, 4);
  for (let k = 0; k < 4; k++) R(g, shade(col, 1.05), 40 + k * 5.6, 7, 3, 4);
  for (let i = 0; i < 40; i++) R(g, shade(col, r() < 0.5 ? 0.88 : 1.1), ri(r, 7, 56), ri(r, 33, 57), 3, 2);
  for (let k = 0; k < 3; k++) {
    R(g, '#2a2f3f', 12 + k * 10, 38, 4, 8);
    R(g, col, 12 + k * 10, 38, 1, 1);
    R(g, col, 15 + k * 10, 38, 1, 1);
  }
  R(g, '#2a2f3f', 48, 24, 4, 8);
  R(g, '#2a2f3f', 48, 40, 4, 8);
  R(g, '#4a3626', 21, 48, 8, 12);
  R(g, col, 21, 48, 1, 1);
  R(g, col, 28, 48, 1, 1);
  R(g, '#8a8d96', 50, 0, 1, 8);
  R(g, '#c0392b', 51, 0, 6, 4);
  outline(c, shade(col, 0.4));
  return { c };
}

export function flatiron(hpx: number, h: number, seed: number): Spr {
  const W = 48;
  const D = hpx - h;
  const { c, g } = mkCanvas(W, hpx);
  const r = mulberry32(seed);
  const wall = '#cdbf9f';
  const L: number[] = [];
  tri(g, '#8a8474', 24, 0, 24, D);
  tri(g, '#a39c8a', 24, 4, 20, D - 4);
  tri(g, '#b8b09c', 20, 8, 12, D - 12);
  acUnit(g, 20, D - 14);
  R(g, wall, 0, D, W, h);
  fGrid(g, r, L, 0, D + 5, W, h - 26, wall, 5);
  R(g, shade(wall, 1.25), 0, D, W, 4);
  R(g, shade(wall, 0.65), 0, D + 4, W, 1);
  for (let x = 1; x < W; x += 3) R(g, shade(wall, 0.75), x, D + 5, 1, 2);
  for (let y = D + 34; y < D + h - 24; y += 39) R(g, shade(wall, 1.2), 0, y, W, 2);
  lobby(g, r, L, 0, D + h - 20, W, 20, wall, true);
  R(g, 'rgba(0,0,0,.12)', 0, D, 5, h);
  R(g, 'rgba(0,0,0,.12)', W - 5, D, 5, h);
  R(g, 'rgba(0,0,0,.2)', 0, D, 2, h);
  R(g, 'rgba(0,0,0,.25)', W - 2, D, 2, h);
  return { c, lights: L };
}

export function oculus(): Spr {
  const { c, g } = mkCanvas(98, 58);
  const cx = 49;
  const by = 54;
  for (let i = -12; i <= 12; i++) {
    const x0 = cx + i * 3.4;
    const x1 = cx + i * 4 + Math.sign(i) * 2;
    const y1 = by - 48 + Math.abs(i) * 3.3;
    line(g, '#f6f8fa', x0, by - 8, x1, y1);
    line(g, '#c8d0d6', x0 + 1, by - 8, x1 + 1, y1);
  }
  R(g, '#7fa8c0', cx - 2, by - 44, 4, 38);
  R(g, '#b9d8e8', cx - 2, by - 44, 1, 38);
  R(g, '#e9eef1', 6, by - 8, 86, 8);
  R(g, '#ffffff', 6, by - 8, 86, 1);
  R(g, '#2a3344', 38, by - 6, 22, 6);
  outline(c, '#5a6470');
  return { c, lights: [38, by - 6, 22, 6, 3] };
}

export function kiosk(): Spr {
  const { c, g } = mkCanvas(40, 42);
  R(g, '#5a5d66', 0, 0, 40, 18);
  R(g, '#6a6d76', 2, 2, 36, 14);
  R(g, '#3f8a3f', 4, 4, 32, 6);
  R(g, '#58a84c', 6, 5, 10, 3);
  R(g, '#58a84c', 22, 6, 9, 3);
  R(g, '#3a3d46', 0, 18, 40, 24);
  drawText(g, 'SHACK', 10, 20, '#7ad84a');
  R(g, '#ffe6a8', 5, 27, 30, 8);
  R(g, '#3a3d46', 14, 27, 1, 8);
  R(g, '#3a3d46', 25, 27, 1, 8);
  R(g, '#8a8d96', 3, 35, 34, 2);
  R(g, '#22242a', 0, 41, 40, 1);
  return { c, glows: [4, 19, 32, 17] };
}

export function carriage(): Spr {
  const { c, g } = mkCanvas(46, 28);
  g.translate(1, 1);
  ell(g, '#f0ece0', 10, 13, 7, 4);
  R(g, '#f0ece0', 3, 6, 4, 8);
  R(g, '#f0ece0', 0, 5, 6, 4);
  R(g, '#222222', 1, 6, 1, 1);
  for (const lx of [5, 8, 12, 15]) R(g, '#f0ece0', lx, 16, 2, 9);
  R(g, '#8a8478', 6, 4, 2, 7);
  R(g, '#8a8478', 17, 11, 2, 7);
  R(g, '#c0392b', 8, 9, 2, 8);
  R(g, '#3a2a1e', 16, 14, 10, 1);
  R(g, '#1f1f28', 24, 8, 16, 9);
  R(g, '#c0392b', 26, 6, 12, 4);
  R(g, '#f2f2f2', 23, 0, 18, 3);
  R(g, '#1f1f28', 24, 3, 1, 5);
  R(g, '#1f1f28', 39, 3, 1, 5);
  ell(g, '#2a2a30', 28, 20, 4, 4);
  ell(g, '#8a8d96', 28, 20, 1, 1);
  ell(g, '#2a2a30', 38, 19, 5, 5);
  ell(g, '#8a8d96', 38, 19, 1, 1);
  g.setTransform(1, 0, 0, 1, 0, 0);
  outline(c);
  return { c };
}

export function xmasTree(): Spr {
  const { c, g } = mkCanvas(42, 76);
  const r = mulberry32(12);
  R(g, '#5a3d24', 18, 66, 6, 9);
  for (let t = 0; t < 6; t++) {
    const top = 6 + t * 10;
    for (let i = 0; i < 16; i++) {
      const hw = Math.round(2 + (i * (5 + t * 2.4)) / 15);
      R(g, i > 12 ? '#1f5a3a' : i < 4 ? '#3f9a5a' : '#2c7a48', 21 - hw, top + i, hw * 2, 1);
    }
  }
  for (let i = 0; i < 70; i++) {
    const y = ri(r, 10, 68);
    const hw = Math.round(((y - 6) / 62) * 16);
    R(g, pick(r, ['#ff4a4a', '#ffd84a', '#4ab0ff', '#ffffff', '#ff8ad0']), 21 + ri(r, -hw, hw), y, 1, 1);
  }
  R(g, '#ffe14a', 20, 1, 3, 5);
  R(g, '#ffe14a', 18, 3, 7, 1);
  outline(c, '#123322');
  return { c, glows: [1, 1, 40, 70], lamps: [21, 3, 24] };
}

export function pool911(): Spr {
  const { c, g } = mkCanvas(48, 48);
  R(g, '#3a3d46', 0, 0, 48, 48);
  R(g, '#55585f', 1, 1, 46, 1);
  R(g, '#22384e', 3, 3, 42, 42);
  for (let i = 0; i < 14; i++) {
    R(g, '#4a6a8a', 4 + i * 3, 3, 1, 7);
    R(g, '#4a6a8a', 4 + i * 3, 38, 1, 7);
    R(g, '#4a6a8a', 3, 4 + i * 3, 7, 1);
    R(g, '#4a6a8a', 38, 4 + i * 3, 7, 1);
  }
  R(g, '#16283a', 10, 10, 28, 28);
  R(g, '#0c1620', 17, 17, 14, 14);
  return { c };
}

export function imagine(): Spr {
  const { c, g } = mkCanvas(32, 32);
  ell(g, '#e4dfd2', 16, 16, 15, 15);
  ell(g, '#8a857a', 16, 16, 13, 13);
  ell(g, '#e4dfd2', 16, 16, 11, 11);
  for (let a = 0; a < 12; a++) line(g, '#a8a296', 16, 16, 16 + Math.cos((a * Math.PI) / 6) * 11, 16 + Math.sin((a * Math.PI) / 6) * 11);
  R(g, '#e4dfd2', 1, 12, 30, 8);
  drawText(g, 'IMAGINE', 3, 14, '#3a3a44');
  return { c };
}

export function rinkRail(w: number): Spr {
  const { c, g } = mkCanvas(w, 14);
  R(g, 'rgba(190,225,245,.55)', 0, 3, w, 10);
  R(g, '#c9a13b', 0, 1, w, 2);
  R(g, '#8a6a1e', 0, 13, w, 1);
  for (let x = 0; x < w; x += 16) R(g, '#c9a13b', x, 1, 1, 13);
  R(g, '#c9a13b', w - 1, 1, 1, 13);
  return { c };
}

export function signBoard(text: string, bg: string, fg: string): Spr {
  const w = textW(text) + 8;
  const { c, g } = mkCanvas(w + 2, 24);
  R(g, '#3a3d46', 3, 10, 2, 13);
  R(g, '#3a3d46', w - 3, 10, 2, 13);
  R(g, bg, 1, 1, w, 11);
  R(g, shade(bg, 1.3), 1, 1, w, 1);
  drawText(g, text, 5, 4, fg);
  outline(c);
  return { c, glows: [1, 1, w, 11] };
}

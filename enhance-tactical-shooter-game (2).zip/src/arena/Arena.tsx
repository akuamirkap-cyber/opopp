import { useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent as RPointerEvent, ReactNode } from "react";
import { DIFFS, TEAMS } from "../game/defs";
import type { DiffId } from "../game/defs";
import { audio } from "../game/audio";
import { ArenaGame } from "./engine";
import type { ArenaConfig, ArenaHud, ArenaResult, ArenaRow, FeedItem } from "./engine";
import { MAP_INFO, mapPreview } from "./maps";
import { AWEP, AW_KEYS, AW_ORDER, awIcon, isBlade } from "./weapons";
import { ARENA_SKINS, SKIN_TAGS, opPortrait } from "./skins";
import type { AW } from "./weapons";

const SIZES = [1, 2, 3, 4, 5];
const KILLS = [10, 20, 30, 50];
const TIMES = [3, 5, 8, 10];
const KEYS: [string, string][] = [
  ["A / D", "Jalan"], ["W / SPASI", "Jetpack (tahan)"], ["SHIFT", "Sprint + NOS (tahan)"], ["S", "Merunduk / turun platform & pintu jalan tikus"], ["MOUSE", "Bidik 360°"], ["KLIK KIRI", "Tembak / kombo tebasan"],
  ["KLIK KANAN / C", "Perisai hologram (tahan)"], ["G", "Lempar granat"], ["F", "Tebasan SAMPING / pukul"], ["1-9, 0, -, =, K, T, P / SCROLL", "Pilih semua 15 senjata"], ["Q", "Senjata sebelumnya"], ["E", "SEMBUNYI di tempat sembunyi / ambil senjata"], ["R", "Reload"], ["TAB", "Papan skor"], ["ESC", "Pause"], ["N", "Musik"],
];
const TCOL = (t: number) => TEAMS[t]?.color ?? "#ffffff";
const isAW = (w: string): w is AW => w in AWEP;

function Section({ title, children, className = "" }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={`panel p-3 sm:p-4 ${className}`}>
      <h2 className="mb-3 text-[9px] text-[#f5c542] sm:text-[10px]"><span className="text-[#ff4d5e]">//</span> {title}</h2>
      {children}
    </section>
  );
}
function Opt<T extends string | number>({ v, cur, set, label }: { v: T; cur: T; set: (v: T) => void; label: string }) {
  return <button onClick={() => { audio.play("click", 0.6); set(v); }} className={`btn px-1 py-2 text-[7px] sm:text-[9px] ${v === cur ? "btn-on" : "btn-dark"}`}>{label}</button>;
}

/** a touch joystick: the left one walks and flies, the right one aims and shoots */
function Stick({ side, game }: { side: "L" | "R"; game: ArenaGame | null }) {
  const base = useRef<HTMLDivElement>(null);
  const [k, setK] = useState({ x: 0, y: 0, on: false });
  const set = (x: number, y: number, on: boolean) => {
    setK({ x, y, on });
    if (game) { const j = side === "L" ? game.joyL : game.joyR; j.x = x; j.y = y; j.on = on; }
  };
  const move = (e: RPointerEvent) => {
    const r = base.current!.getBoundingClientRect();
    let dx = (e.clientX - (r.left + r.width / 2)) / (r.width / 2), dy = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    const l = Math.hypot(dx, dy);
    if (l > 1) { dx /= l; dy /= l; }
    set(dx, dy, true);
  };
  return (
    <div
      ref={base}
      aria-label={side === "L" ? "Stik gerak dan jetpack" : "Stik bidik dan tembak"}
      className="relative h-32 w-32 rounded-full bg-[#14121c]/55"
      style={{ touchAction: "none", boxShadow: `0 0 0 2px #0a0a0f, 0 0 0 4px ${side === "L" ? "#5ff0e0" : "#ff4d5e"}` }}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); move(e); }}
      onPointerMove={(e) => k.on && move(e)}
      onPointerUp={() => set(0, 0, false)}
      onPointerCancel={() => set(0, 0, false)}
    >
      <span className="pointer-events-none absolute left-1/2 top-2 -translate-x-1/2 text-[6px] text-white/50">{side === "L" ? "JET ▲" : "TEMBAK"}</span>
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 h-12 w-12 rounded-full"
        style={{ background: side === "L" ? "#5ff0e0" : "#ff4d5e", boxShadow: "0 0 0 2px #0a0a0f", transform: `translate(calc(-50% + ${k.x * 38}px), calc(-50% + ${k.y * 38}px))` }}
      />
    </div>
  );
}

function Feed({ f }: { f: FeedItem }) {
  const icon = isAW(f.w) ? <img src={awIcon(f.w)} alt="" className="px h-[10px] w-auto" /> : <span className="text-[6px] text-white/70">{f.w === "nade" ? "GRANAT" : f.w === "melee" ? "PUKUL" : f.w === "flame" ? "API" : f.w === "rock" ? "BATU JATUH" : f.w === "wall" ? "BANTING" : "☠"}</span>;
  return (
    <div className={`flex items-center gap-1.5 px-1.5 py-1 text-[6px] sm:text-[7px] ${f.me ? "bg-[#f5c542]/25" : "bg-[#0c0a10]/75"}`} style={{ boxShadow: "0 0 0 1px #0a0a0f" }}>
      {f.k && <span style={{ color: TCOL(f.kt) }}>{f.k}</span>}
      {icon}
      {f.head && <span className="text-[#ff5a6a]">HS</span>}
      <span style={{ color: TCOL(f.vt) }}>{f.v}</span>
    </div>
  );
}

function Board({ rows, score }: { rows: ArenaRow[]; score: [number, number] }) {
  return (
    <div className="grid w-full gap-3 sm:grid-cols-2">
      {[0, 1].map((t) => (
        <div key={t} className="bg-[#0c0a10]/90 p-2" style={{ boxShadow: `0 0 0 2px #0a0a0f, 0 0 0 3px ${TCOL(t)}` }}>
          <div className="mb-2 flex justify-between text-[8px] sm:text-[10px]" style={{ color: TCOL(t) }}><span>TIM {TEAMS[t].name}</span><span>{score[t]}</span></div>
          <div className="grid grid-cols-[1fr_28px_28px_40px] gap-y-1 text-[6px] sm:text-[8px]">
            <span className="text-white/40">NAMA</span><span className="text-right text-white/40">K</span><span className="text-right text-white/40">D</span><span className="text-right text-white/40">DMG</span>
            {rows.filter((r) => r.team === t).map((r) => (
              <div key={r.name} className={`contents ${r.me ? "text-[#f5c542]" : "text-white"}`}>
                <span className="truncate">{r.me ? "▶ " : ""}{r.name}</span><span className="text-right">{r.k}</span><span className="text-right">{r.d}</span><span className="text-right">{r.dmg}</span>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

/** the side-view team deathmatch: lobby, the match, the results */
export function Arena({ skin, diff, onExit }: { skin: number; diff: DiffId; onExit: () => void }) {
  const [stage, setStage] = useState<"lobby" | "play">("lobby");
  const [cfg, setCfg] = useState<ArenaConfig>({ map: 2, size: 4, kills: 20, time: 5, diff, skin: skin <= 5 ? skin : 0, startWep: "katana" });
  const [run, setRun] = useState(0);
  const cvRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<ArenaGame | null>(null);
  const [game, setGame] = useState<ArenaGame | null>(null);
  const [hud, setHud] = useState<ArenaHud | null>(null);
  const [result, setResult] = useState<ArenaResult | null>(null);
  const [paused, setPaused] = useState(false);
  const [board, setBoard] = useState(false);
  const [hint, setHint] = useState(true);
  const touch = useMemo(() => typeof window !== "undefined" && !!window.matchMedia?.("(pointer: coarse)").matches, []);
  const previews = useMemo(() => MAP_INFO.map((_, i) => mapPreview(i)), []);
  const upd = (p: Partial<ArenaConfig>) => setCfg((c) => ({ ...c, ...p }));

  useEffect(() => {
    if (stage !== "play" || !cvRef.current) return;
    const g = new ArenaGame(cvRef.current, { hud: setHud, end: setResult });
    g.touch = touch;
    g.start(cfg);
    gameRef.current = g;
    setGame(g);
    setResult(null);
    setPaused(false);
    setHint(true);
    const id = setTimeout(() => setHint(false), 12000);
    return () => { clearTimeout(id); g.destroy(); gameRef.current = null; setGame(null); setHud(null); };
    // (the settings are read when the match starts)
  }, [stage, run]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { if (gameRef.current) gameRef.current.paused = paused; }, [paused, game]);

  useEffect(() => {
    if (stage !== "play") return;
    const kd = (e: KeyboardEvent) => {
      if (e.code === "Tab") { e.preventDefault(); setBoard(true); }
      if (e.code === "Escape" && !result) setPaused((p) => !p);
    };
    const ku = (e: KeyboardEvent) => { if (e.code === "Tab") setBoard(false); };
    window.addEventListener("keydown", kd);
    window.addEventListener("keyup", ku);
    return () => { window.removeEventListener("keydown", kd); window.removeEventListener("keyup", ku); };
  }, [stage, result]);

  const click = () => { audio.unlock(); audio.play("click", 0.6); };
  const go = () => { click(); setStage("play"); setRun((n) => n + 1); };
  const again = () => { click(); setResult(null); setPaused(false); setRun((n) => n + 1); };
  const lobby = () => { click(); setResult(null); setPaused(false); setStage("lobby"); };
  const exit = () => { click(); audio.hush(); onExit(); };

  if (stage === "lobby")
    return (
      <div className="scroll-thin fixed inset-0 z-50 overflow-y-auto font-pixel text-white" style={{ background: "radial-gradient(ellipse at top, #241a34 0%, #0b0910 70%)" }}>
        <div className="mx-auto flex min-h-full w-full max-w-5xl flex-col gap-4 px-4 py-4">
          <header className="flex items-start justify-between gap-3">
            <button onClick={exit} className="btn btn-dark px-3 py-2 text-[8px]">← MENU</button>
            <div className="flex flex-col items-center text-center">
              <div className="mb-2 bg-[#5ff0e0] px-2 py-1 text-[7px] text-[#0a0a0f] sm:text-[8px]">SIDE-VIEW · JETPACK · TEAM DEATHMATCH</div>
              <h1 className="ts-big text-2xl text-[#f5c542] sm:text-4xl">ARENA <span className="text-white">MILISI</span></h1>
              <p className="ts mt-3 text-[7px] text-[#e9e2d2] sm:text-[9px]">Terbang, bidik 360°, rebut senjata di arena - tim pertama capai target kill menang!</p>
            </div>
            <div className="w-[64px]" />
          </header>

          <Section title="PILIH ARENA">
            <div className="grid gap-3 sm:grid-cols-3">
              {MAP_INFO.map((m, i) => (
                <button key={m.name} onClick={() => { audio.play("click", 0.6); upd({ map: i }); }} className={`relative flex flex-col gap-2 p-2 text-left ${cfg.map === i ? "bg-[#f5c542]/15" : "bg-[#1a1822] hover:bg-[#262330]"}`} style={{ boxShadow: cfg.map === i ? "0 0 0 2px #f5c542" : "0 0 0 2px #0a0a0f" }}>
                  {i === 2 && <span className="absolute right-3 top-3 bg-[#5ff0e0] px-1.5 py-0.5 text-[5px] text-[#0a0a0f] sm:text-[6px]">★ DIPERINDAH</span>}
                  <img src={previews[i]} alt={`Peta ${m.name}`} className="px aspect-[20/9] w-full" style={{ imageRendering: "pixelated" }} />
                  <span className={`text-[8px] sm:text-[9px] ${cfg.map === i ? "text-[#f5c542]" : "text-white"}`}>{m.name}</span>
                  <span className="text-[6px] leading-[1.8] text-white/55 sm:text-[7px]">{m.sub}</span>
                </button>
              ))}
            </div>
          </Section>

          <div className="grid gap-4 md:grid-cols-2">
            <Section title="OPERATOR KAMU">
              <div className="grid grid-cols-6 gap-2">
                {ARENA_SKINS.map((name, i) => (
                  <button key={name} onClick={() => { audio.play("click", 0.6); upd({ skin: i }); }} className={`flex flex-col items-center gap-1.5 px-1 py-2 ${cfg.skin === i ? "bg-[#f5c542]/20" : "bg-[#1a1822] hover:bg-[#262330]"}`} style={{ boxShadow: cfg.skin === i ? "0 0 0 2px #f5c542" : "0 0 0 2px #0a0a0f" }}>
                    <img src={opPortrait(i)} alt={name} className={`px h-[48px] w-8 ${cfg.skin === i ? "hop" : "opacity-70"}`} />
                    <span className={`text-[6px] sm:text-[7px] ${cfg.skin === i ? "text-[#f5c542]" : "text-white/70"}`}>{name}</span>
                    <span className="hidden text-[5px] text-white/40 sm:block">{SKIN_TAGS[i]}</span>
                  </button>
                ))}
              </div>
            </Section>
            <Section title="ATURAN MATCH">
              <div className="flex flex-col gap-3 text-[7px] text-white/60 sm:text-[8px]">
                <div>UKURAN TIM<div className="mt-1.5 grid grid-cols-5 gap-1.5">{SIZES.map((n) => <Opt key={n} v={n} cur={cfg.size} set={(v) => upd({ size: v })} label={`${n}V${n}`} />)}</div></div>
                <div>TARGET KILL<div className="mt-1.5 grid grid-cols-4 gap-1.5">{KILLS.map((n) => <Opt key={n} v={n} cur={cfg.kills} set={(v) => upd({ kills: v })} label={String(n)} />)}</div></div>
                <div>WAKTU<div className="mt-1.5 grid grid-cols-4 gap-1.5">{TIMES.map((n) => <Opt key={n} v={n} cur={cfg.time} set={(v) => upd({ time: v })} label={`${n} MNT`} />)}</div></div>
                <div>KESULITAN BOT MUSUH<div className="mt-1.5 grid grid-cols-3 gap-1.5">{(Object.keys(DIFFS) as DiffId[]).map((d) => <Opt key={d} v={d} cur={cfg.diff} set={(v) => upd({ diff: v })} label={DIFFS[d].label} />)}</div></div>
                <div>PEMBAWA PISTOL PORTAL TIMMU (HANYA 1 ORANG PER TIM)<div className="mt-1.5 grid grid-cols-2 gap-1.5"><Opt v={1} cur={cfg.portalMe === false ? 0 : 1} set={(v) => upd({ portalMe: v === 1 })} label="KAMU" /><Opt v={0} cur={cfg.portalMe === false ? 0 : 1} set={(v) => upd({ portalMe: v === 1 })} label="BOT TEMAN" /></div></div>
              </div>
            </Section>
          </div>

          <button onClick={go} className="btn mx-1 px-4 py-4 text-sm sm:text-lg"><span className="blink">&gt;</span> MASUK ARENA</button>

          <div className="grid gap-4 md:grid-cols-2">
            <Section title="ARSENAL LENGKAP (15 SENJATA!)">
              <p className="mb-2.5 text-[6px] leading-[1.8] text-[#5ff0e0] sm:text-[7px]">Tiap pemain langsung membawa semua senjata di Duel - termasuk yang BARU: KAPAK ARGENT [K] & SENAPAN TESLA [T]. PISTOL PORTAL [P] hanya dibawa 1 orang per tim. Klik salah satu untuk memilih senjata awalmu:</p>
              <div className="grid grid-cols-1 gap-1.5 sm:grid-cols-2">
                {AW_ORDER.map((id, idx) => {
                  const active = (cfg.startWep ?? "katana") === id;
                  return (
                    <button
                      key={id}
                      onClick={() => { audio.play("click", 0.6); upd({ startWep: id }); }}
                      className={`flex items-center gap-2 p-1.5 text-left ${active ? "bg-[#f5c542]/20" : "bg-[#1a1822] hover:bg-[#262330]"}`}
                      style={{ boxShadow: active ? "0 0 0 2px #f5c542" : "0 0 0 1px #0a0a0f" }}
                    >
                      <span className="flex h-5 w-5 flex-none items-center justify-center bg-[#0c0a10] text-[6px] text-[#f5c542]">{AW_KEYS[idx]}</span>
                      <span className="flex w-[44px] flex-none justify-center"><img src={awIcon(id)} alt="" className="px h-[14px] w-auto" /></span>
                      <div className="flex min-w-0 flex-col gap-0.5">
                        <span className={`truncate text-[7px] ${active ? "text-[#f5c542]" : "text-white"}`}>{AWEP[id].name}</span>
                        <span className="line-clamp-2 text-[5px] leading-[1.5] text-white/55">{AWEP[id].desc}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
              <p className="mt-3 text-[6px] leading-[1.8] text-[#9ae8ff] sm:text-[7px]">KATANA & LIGHTSABER: Klik kiri = kombo 4 tebasan (atas-bawah → tebasan SAMPING → tebasan samping balik → Iai dash / putar 360°). Tekan [F] untuk langsung tebasan SAMPING, dan tangkis peluru/laser musuh!</p>
              <p className="mt-2 text-[6px] leading-[1.8] text-white/45 sm:text-[7px]">Pickup senjata di arena kini mengisi penuh peluru senjata tersebut. Fisika ragdoll penuh aktif di Duel Mode!</p>
            </Section>
            <Section title="KONTROL">
              <ul className="flex flex-col gap-2">
                {KEYS.map(([k, v]) => (
                  <li key={k} className="flex items-center gap-2 text-[7px]">
                    <span className="flex-none bg-[#23212c] px-1.5 py-1 text-[#f5c542]" style={{ boxShadow: "0 0 0 1px #0a0a0f, 0 2px 0 1px #3b3848" }}>{k}</span>
                    <span className="text-white/70">{v}</span>
                  </li>
                ))}
                <li className="text-[7px] leading-[1.8] text-white/40">Di HP: stik kiri jalan + dorong ke atas untuk jetpack (ke bawah = merunduk), stik kanan bidik + dorong jauh untuk menembak.</li>
                <li className="text-[7px] leading-[1.8] text-[#ffb03a]">KAPAK ARGENT [K]: kapak energi membara. Klik = bacokan → tebasan samping → HANTAMAN TANAH berapi yang melempar musuh & memecah lantai. [F] = tebasan samping.</li>
                <li className="text-[7px] leading-[1.8] text-[#8fe8ff]">SENAPAN TESLA [T]: peluru listrik. Musuh yang kena TERSETRUM 1 detik (tak bisa bergerak/menembak), lalu listrik menjalar ke 3 musuh terdekatnya (0,3 detik). Perisai hologram menahannya.</li>
                <li className="text-[7px] leading-[1.8] text-[#8fd0ff]">PISTOL PORTAL [P] (1 pembawa per tim): tembak dinding/lantai RATA untuk portal A, lalu sekali lagi untuk portal B - keduanya terhubung. Prajurit, peluru & granat yang masuk keluar di portal satunya dengan kecepatan yang sama.</li>
                <li className="text-[7px] leading-[1.8] text-[#ffd75e]">CRITICAL HIT: serangan kritis MELEMPAR musuh jauh sampai TERBANTING ke tembok lalu memantul (makin babak belur, makin jauh!) - temboknya ikut retak. Selalu kritis: pukulan terakhir kombo pedang/kapak, serangan dari BELAKANG, roket yang kena telak, dan apa pun yang mengenai musuh yang sedang TERSETRUM. Peluru biasa juga punya peluang kritis (sniper 30%, deagle 20%).</li>
                <li className="text-[7px] leading-[1.8] text-[#9ae8ff]">GOA YANG HIDUP: GEYSER menyembur tiap beberapa detik dan melontarkanmu ke atas; STALAKTIT bisa ditembak jatuh ke kepala musuh; atap yang hancur menjatuhkan bongkahan batu; sesekali GEMPA mengguncang gua; air terjun memadamkan api. Dengan pedang/kapak di tangan, kamera merapat, membingkai duelmu, dan ikut miring di tiap tebasan.</li>
                <li className="text-[7px] leading-[1.8] text-[#e8c08a]">ARENA BISA HANCUR: tembakan meninggalkan RETAKAN, lalu batu PECAH - sesuai kekuatan senjata (pistol butuh belasan peluru, sniper 3, bazooka & granat langsung mengoyak kawah). Kristal & jamur di atasnya ikut hancur.</li>
                <li className="text-[7px] leading-[1.8] text-[#cfe2ff]">ARMOR & KNOCKBACK: setiap pemain punya 100 ARMOR di atas 100 HP. Serangan menggerus armor dulu (percikan api & serpihan baja, tanpa darah) - baru setelah ARMOR PECAH tubuh ikut terluka. Tidak ada lagi yang mati sekali kena: sniper, shotgun, bazooka & pedang kini MELEMPARMU ke belakang (bisa terbanting ke tembok!), peluru ringan membuatmu tersentak. Armor pulih sendiri setelah 4,5 detik tanpa kena serang; medkit memberi +60 HP +50 armor.</li>
                <li className="text-[7px] leading-[1.8] text-[#4fc8ff]">PERISAI HOLOGRAM: tahan [KLIK KANAN] (atau [C]) untuk membentangkan tembok cahaya heksagonal ke arah bidikan. Menahan peluru, laser, api, ledakan & tebasan dari DEPAN - tapi energinya terkikis, dan kalau HANCUR harus menunggu 5 detik sebelum bisa dipakai lagi. Selama perisai terpasang kamu tidak bisa menembak dan jalanmu melambat; turunkan sebentar supaya energinya terisi lagi. Granat kini di tombol [G].</li>
                <li className="text-[7px] leading-[1.8] text-[#7dff9a]">TEMPAT SEMBUNYI (titik hijau di minimap): berdiri di dekat jamur raksasa, ceruk batu, peti, gerobak tambang, semak pakis atau bongkahan kristal lalu tekan [E]. Selama tersembunyi peluru tertahan pelindung, musuh tidak melihatmu & HP pulih lebih cepat. Bergerak atau menembak = keluar.</li>
                <li className="text-[7px] leading-[1.8] text-[#9dffb0]">JALAN TIKUS di Goa Kristal: 3 lorong rahasia setinggi merangkak per sisi (pintu papan di lantai: tekan [S]; mulutnya bercahaya hijau). Bot tidak bisa mengejar ke dalamnya. Tahan [S] di balik tembok batu rendah untuk berlindung dari tembakan.</li>
              </ul>
            </Section>
          </div>
        </div>
      </div>
    );

  const h = hud;
  const myTeam = h?.myTeam ?? 0;
  return (
    <div className="fixed inset-0 z-50 select-none overflow-hidden bg-[#0b0910] font-pixel text-white">
      <canvas ref={cvRef} className="absolute left-0 top-0 block" style={{ imageRendering: "pixelated", cursor: touch ? "auto" : "none" }} aria-label="Arena side-view" />
      {h && (
        <>
          <div className="pointer-events-none absolute left-1/2 top-2 flex -translate-x-1/2 items-stretch gap-1">
            {[0, 1].map((t) => (
              <div key={t} className={`flex min-w-[58px] flex-col items-center justify-center px-2 py-1 ${t === 1 ? "order-3" : ""}`} style={{ background: "rgba(12,10,16,0.85)", boxShadow: `0 0 0 2px #0a0a0f, inset 0 -3px 0 ${TCOL(t)}` }}>
                <span className="text-[5px] sm:text-[6px]" style={{ color: TCOL(t) }}>{t === myTeam ? "TIMMU" : "MUSUH"}</span>
                <span className="ts text-[12px] sm:text-[16px]" style={{ color: TCOL(t) }}>{h.score[t]}</span>
              </div>
            ))}
            <div className="order-2 flex flex-col items-center justify-center px-2 py-1" style={{ background: "rgba(12,10,16,0.85)", boxShadow: "0 0 0 2px #0a0a0f" }}>
              <span className={`ts text-[10px] sm:text-[12px] ${h.time <= 30 && h.phase === "live" ? "blink text-[#ff6b7a]" : "text-white"}`}>{Math.floor(h.time / 60)}:{String(h.time % 60).padStart(2, "0")}</span>
              <span className="text-[5px] text-white/50 sm:text-[6px]">TARGET {h.target}</span>
            </div>
          </div>

          <div className="pointer-events-none absolute left-2 top-2 flex w-[118px] flex-col gap-1 sm:w-[150px]">
            {/* the armour takes every blow first: its bar sits on top of the health it protects */}
            <div className="flex items-center justify-between text-[6px] sm:text-[7px]">
              <span className={h.armor > 0 ? "text-[#cfe2ff]" : "blink text-[#ff9a5a]"}>{h.armor > 0 ? `ARMOR ${h.armor}` : "ARMOR PECAH"}</span>
              {h.shield && <span className="text-[#5ff0e0]">KEBAL</span>}
            </div>
            <div className="h-2 w-full bg-[#0a0a0f] p-[2px]"><div className="h-full" style={{ width: `${h.armor}%`, background: h.armor > 30 ? "#cfe2ff" : "#ff9a5a" }} /></div>
            <div className="text-[6px] text-[#7dff9a] sm:text-[7px]">HP {h.hp}</div>
            <div className="h-2.5 w-full bg-[#0a0a0f] p-[2px]"><div className="h-full" style={{ width: `${h.hp}%`, background: h.hp > 55 ? "#7dff9a" : h.hp > 28 ? "#f5c542" : "#ff4d5e" }} /></div>
            <div className="text-[6px] text-[#5ff0e0] sm:text-[7px]">JETPACK</div>
            <div className="h-2 w-full bg-[#0a0a0f] p-[2px]"><div className="h-full" style={{ width: `${Math.round(h.fuel * 100)}%`, background: h.fuel < 0.2 ? "#ff6b7a" : "#5ff0e0" }} /></div>
            <div className={`text-[6px] sm:text-[7px] ${h.sprint ? "text-white" : "text-[#5fd8ff]"}`}>NOS{!touch && " [SHIFT]"}{h.sprint && " ▶▶"}</div>
            <div className="h-2 w-full bg-[#0a0a0f] p-[2px]"><div className="h-full" style={{ width: `${Math.round(h.nos * 100)}%`, background: h.sprint ? "#ffffff" : h.nos < 0.2 ? "#3a5a8a" : "#5fd8ff" }} /></div>
            {/* the hologram shield: its energy - or, once broken, the five seconds until it can be raised again */}
            <div className={`text-[6px] sm:text-[7px] ${h.holoCd > 0 ? "blink text-[#ff6b7a]" : h.holoUp ? "text-white" : "text-[#4fc8ff]"}`}>
              {h.holoCd > 0 ? `PERISAI HANCUR · ${h.holoCd.toFixed(1)}s` : `PERISAI${touch ? "" : " [KLIK KANAN]"}${h.holoUp ? " ◆" : ""}`}
            </div>
            <div className="h-2 w-full bg-[#0a0a0f] p-[2px]">
              <div className="h-full" style={{ width: `${Math.round((h.holoCd > 0 ? 1 - h.holoCd / 5 : h.holo) * 100)}%`, background: h.holoCd > 0 ? "#7a2a34" : h.holoUp ? "#ffffff" : h.holo < 0.3 ? "#ff9a5a" : "#4fc8ff" }} />
            </div>
            <div className="flex items-center gap-1 text-[6px] text-white/80 sm:text-[7px]">GRANAT {Array.from({ length: 4 }, (_, i) => <span key={i} className="inline-block h-2 w-2" style={{ background: i < h.nades ? "#7dc46a" : "#2a2834", boxShadow: "0 0 0 1px #0a0a0f" }} />)}</div>
            {h.streak >= 2 && <div className="text-[6px] text-[#ff9df0] sm:text-[7px]">STREAK {h.streak}</div>}
          </div>

          <div className="pointer-events-none absolute right-2 top-12 flex flex-col items-end gap-1 sm:top-2">
            {h.feed.map((f) => <Feed key={f.id} f={f} />)}
          </div>

          {/* Active weapon card + Full 12-weapon clickable hotbar */}
          <div className="absolute right-2 flex flex-col items-end gap-1.5" style={{ bottom: touch ? 168 : 8 }}>
            {(() => {
              const curSlot = h.slots[h.cur];
              if (!curSlot) return null;
              const blade = isBlade(AWEP[curSlot.id].kind) || curSlot.id === "portal";
              return (
                <div className="flex items-center gap-2.5 px-2.5 py-1.5" style={{ background: "rgba(12,10,16,0.9)", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #f5c542" }}>
                  <img src={awIcon(curSlot.id)} alt="" className="px h-[16px] w-auto" />
                  <div className="flex flex-col items-end gap-0.5">
                    <span className="text-[7px] text-[#f5c542]">{curSlot.name}</span>
                    {blade ? (
                      <span className="text-[6px] text-[#9ae8ff]">{curSlot.id === "portal" ? `A ${h.portal?.[0] ? "●" : "○"} B ${h.portal?.[1] ? "●" : "○"} · TEMBAK = PORTAL ${h.pnext ? "B" : "A"}` : curSlot.id === "axe" ? "∞ · 3X KLIK = HANTAM TANAH" : "∞ · KLIK / [F] SAMPING"}</span>
                    ) : (
                      <span className={`text-[10px] ${curSlot.mag === 0 ? "text-[#ff6b7a]" : "text-white"}`}>
                        {curSlot.mag}<span className="text-[6px] text-white/50"> / {curSlot.ammo}</span>
                      </span>
                    )}
                  </div>
                </div>
              );
            })()}
            {h.reload >= 0 && <div className="h-1.5 w-[130px] bg-[#0a0a0f] p-[1px]"><div className="h-full bg-[#f5c542]" style={{ width: `${Math.round(h.reload * 100)}%` }} /></div>}
            <div className="grid max-w-[calc(100vw-130px)] grid-cols-6 gap-1 sm:flex sm:flex-wrap sm:justify-end">
              {h.slots.map((s, i) => {
                if (!s) return null;
                const active = i === h.cur, blade = isBlade(AWEP[s.id].kind) || s.id === "portal", empty = !blade && s.mag === 0 && s.ammo === 0;
                return (
                  <button
                    key={s.id}
                    onClick={() => gameRef.current?.selectSlot(i)}
                    title={`${s.name} [${AW_KEYS[i]}]`}
                    className={`relative flex h-9 w-[42px] flex-col items-center justify-between px-1 py-0.5 transition-transform sm:h-10 sm:w-[46px] ${active ? "-translate-y-0.5" : "opacity-70 hover:opacity-100"} ${empty ? "opacity-35" : ""}`}
                    style={{
                      background: active ? "rgba(38,31,18,0.95)" : "rgba(12,10,16,0.82)",
                      boxShadow: `0 0 0 1px #0a0a0f, 0 0 0 2px ${active ? "#f5c542" : "#2a2834"}`,
                    }}
                  >
                    <span className={`self-start text-[5px] leading-none ${active ? "text-[#f5c542]" : "text-white/50"}`}>{AW_KEYS[i]}</span>
                    <img src={awIcon(s.id)} alt={s.name} className="px max-h-[12px] max-w-[36px] object-contain" />
                    <span className={`text-[5px] leading-none ${blade ? "text-[#9ae8ff]" : s.mag === 0 ? "text-[#ff6b7a]" : "text-white/80"}`}>
                      {blade ? "∞" : s.mag}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {h.alive && h.zap > 0 && (
            <div className="blink ts pointer-events-none absolute left-1/2 top-[40%] -translate-x-1/2 whitespace-nowrap text-[10px] text-[#8fe8ff] sm:text-[14px]">⚡ TERSETRUM ⚡</div>
          )}
          {h.banner && (
            <div key={h.banner.id} className="toast pointer-events-none absolute left-1/2 top-[24%] flex -translate-x-1/2 flex-col items-center gap-2 text-center">
              <span className="ts-big text-2xl sm:text-4xl" style={{ color: h.banner.color }}>{h.banner.text}</span>
              {h.banner.sub && <span className="ts text-[8px] text-white sm:text-[10px]">{h.banner.sub}</span>}
            </div>
          )}
          {!h.alive && h.phase === "live" && (
            <div className="pointer-events-none absolute left-1/2 top-[58%] -translate-x-1/2 px-3 py-2 text-center text-[8px] sm:text-[10px]" style={{ background: "rgba(12,10,16,0.85)", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #ff4d5e" }}>
              {h.killer && <div className="mb-2 text-[6px] text-white/60 sm:text-[7px]">KAMERA MENGIKUTI <span className="text-[#ff6b7a]">{h.killer}</span></div>}
              BANGKIT DALAM <span className="text-[#f5c542]">{h.respawn}</span>
            </div>
          )}
          {/* E: step out of hiding / slip into the hiding place within reach / take the weapon underfoot */}
          {h.alive && h.hidden ? (
            <button onClick={() => gameRef.current?.act("pick")} className="btn btn-on absolute left-1/2 -translate-x-1/2 whitespace-nowrap px-3 py-2 text-[7px] sm:text-[9px]" style={{ bottom: touch ? 150 : 60 }}>
              <span className="blink mr-2">●</span>TERSEMBUNYI · PELURU TERTAHAN · {!touch && "[E] "}KELUAR
            </button>
          ) : h.alive && h.hide ? (
            <button onClick={() => gameRef.current?.act("pick")} className="btn absolute left-1/2 -translate-x-1/2 whitespace-nowrap px-3 py-2 text-[7px] sm:text-[9px]" style={{ bottom: touch ? 150 : 60, background: "#7dff9a" }}>
              {!touch && <span className="mr-2">[E]</span>}SEMBUNYI · {h.hide}
            </button>
          ) : h.near && h.alive ? (
            <button onClick={() => gameRef.current?.act("pick")} className="btn absolute left-1/2 -translate-x-1/2 px-3 py-2 text-[7px] sm:text-[9px]" style={{ bottom: touch ? 150 : 60 }}>
              {!touch && <span className="mr-2">[E]</span>}AMBIL {h.near}
            </button>
          ) : null}
          {h.alive && h.tip && !h.hidden && (
            <div className="pointer-events-none absolute left-1/2 -translate-x-1/2 whitespace-nowrap px-2 py-1 text-[6px] text-[#9dffb0] sm:text-[7px]" style={{ bottom: touch ? 190 : 96, background: "rgba(12,10,16,0.85)", boxShadow: "0 0 0 2px #0a0a0f, 0 0 0 3px #2f7a4a" }}>
              {h.tip}
            </div>
          )}

          <div className="absolute left-2 flex gap-1.5" style={{ top: 180 }}>
            <button onClick={() => setPaused(true)} className="btn btn-dark px-2 py-1 text-[7px]">II{!touch && " [ESC]"}</button>
            <button onClick={() => setBoard((b) => !b)} className="btn btn-dark px-2 py-1 text-[7px]">SKOR{!touch && " [TAB]"}</button>
            <button onClick={() => audio.setMusic(!audio.musicOn)} className={`btn px-2 py-1 text-[7px] ${h.music ? "btn-on" : "btn-dark"}`}>♪{!touch && " [N]"}</button>
          </div>

          {hint && !touch && h.phase !== "end" && (
            <div className="pointer-events-none absolute bottom-[92px] left-2 hidden max-w-[65vw] flex-wrap gap-x-3 gap-y-1.5 px-2 py-1.5 text-[6px] text-white/75 sm:flex" style={{ background: "rgba(12,10,16,0.82)", boxShadow: "0 0 0 2px #0a0a0f" }}>
              <span><b className="text-[#f5c542]">A/D</b> jalan</span><span><b className="text-[#f5c542]">W/SPASI</b> jetpack</span><span><b className="text-[#5fd8ff]">SHIFT</b> sprint + NOS</span><span><b className="text-[#f5c542]">KLIK</b> tembak/kombo</span><span><b className="text-[#f5c542]">F</b> tebas samping</span><span><b className="text-[#f5c542]">1-0/-/=/K/T/P / SCROLL</b> semua 15 senjata</span><span><b className="text-[#4fc8ff]">KLIK KANAN</b> perisai hologram</span><span><b className="text-[#f5c542]">G</b> granat</span><span><b className="text-[#f5c542]">Q</b> cepat</span><span><b className="text-[#7dff9a]">E</b> sembunyi</span><span><b className="text-[#7dff9a]">S</b> merunduk / jalan tikus</span>
            </div>
          )}
        </>
      )}

      {touch && h && h.phase !== "end" && !paused && !result && (
        <>
          <div className="absolute bottom-5 left-5"><Stick side="L" game={game} /></div>
          <div className="absolute bottom-5 right-5 flex items-end gap-3">
            <div className="mb-2 grid grid-cols-2 gap-2">
              <button
                aria-label="Sprint dengan NOS (tahan)"
                onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); if (gameRef.current) gameRef.current.touchSprint = true; }}
                onPointerUp={() => { if (gameRef.current) gameRef.current.touchSprint = false; }}
                onPointerCancel={() => { if (gameRef.current) gameRef.current.touchSprint = false; }}
                className="btn h-10 w-14 text-[6px]"
                style={{ background: "#5fd8ff", touchAction: "none" }}
              >
                NOS
              </button>
              <button
                aria-label="Perisai hologram (tahan)"
                onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); if (gameRef.current) gameRef.current.touchGuard = true; }}
                onPointerUp={() => { if (gameRef.current) gameRef.current.touchGuard = false; }}
                onPointerCancel={() => { if (gameRef.current) gameRef.current.touchGuard = false; }}
                className="btn h-10 w-14 text-[6px]"
                style={{ background: "#4fc8ff", touchAction: "none" }}
              >
                PERISAI
              </button>
              <button onClick={() => gameRef.current?.cycleSlot(-1)} className="btn btn-dark h-10 w-14 text-[6px]">◀ SENJ</button>
              <button onClick={() => gameRef.current?.cycleSlot(1)} className="btn btn-dark h-10 w-14 text-[6px]">SENJ ▶</button>
              {([["nade", "GRANAT"], ["reload", "RELOAD"], ["melee", "SAMPING"], ["swap", "CEPAT"]] as const).map(([a, l]) => (
                <button key={a} onClick={() => gameRef.current?.act(a)} className="btn btn-dark h-10 w-14 text-[6px]">{l}</button>
              ))}
            </div>
            <Stick side="R" game={game} />
          </div>
        </>
      )}

      {board && h && !result && (
        <div className="pointer-events-none absolute inset-x-3 top-[16%] mx-auto max-w-2xl"><Board rows={h.rows} score={h.score} /></div>
      )}

      {paused && !result && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-[#0b0910]/80 p-4">
          <div className="panel flex w-full max-w-sm flex-col gap-3 p-5 text-center">
            <h2 className="ts-big text-2xl text-[#f5c542]">PAUSE</h2>
            <button onClick={() => { click(); setPaused(false); }} className="btn px-3 py-3 text-[10px]" autoFocus>LANJUT</button>
            <button onClick={again} className="btn btn-dark px-3 py-3 text-[9px]">MULAI ULANG</button>
            <button onClick={lobby} className="btn btn-dark px-3 py-3 text-[9px]">UBAH PENGATURAN</button>
            <button onClick={exit} className="btn btn-dark px-3 py-3 text-[9px]">MENU UTAMA</button>
          </div>
        </div>
      )}

      {result && (
        <div className="scroll-thin absolute inset-0 z-10 flex items-start justify-center overflow-y-auto bg-[#0b0910]/85 p-4 sm:items-center">
          <div className="panel flex w-full max-w-2xl flex-col items-center gap-4 p-4 text-center sm:p-6">
            <h2 className="ts-big text-3xl sm:text-5xl" style={{ color: result.win < 0 ? "#ffffff" : TCOL(result.win) }}>{result.win < 0 ? "SERI!" : result.win === result.myTeam ? "MENANG!" : "KALAH!"}</h2>
            <p className="ts text-[9px] sm:text-[11px]">
              <span style={{ color: TCOL(0) }}>TIM {TEAMS[0].name} {result.score[0]}</span> <span className="text-white/50">-</span> <span style={{ color: TCOL(1) }}>{result.score[1]} TIM {TEAMS[1].name}</span>
            </p>
            <p className="text-[8px] text-white/70 sm:text-[9px]">MVP: <span style={{ color: TCOL(result.mvpTeam) }}>{result.mvp}</span></p>
            <Board rows={result.rows} score={result.score} />
            <div className="flex flex-wrap justify-center gap-3">
              <button onClick={again} className="btn px-4 py-3 text-[9px] sm:text-[10px]" autoFocus>MAIN LAGI</button>
              <button onClick={lobby} className="btn btn-dark px-4 py-3 text-[9px] sm:text-[10px]">UBAH PENGATURAN</button>
              <button onClick={exit} className="btn btn-dark px-4 py-3 text-[9px] sm:text-[10px]">MENU UTAMA</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import type { SfxName } from "../game/audio";
import type { WeaponId } from "../game/defs";
import { TEAM_PAL, WBARREL, WPIVOT, fromMap, initSprites, mk, whiten } from "../game/sprites";

/** the arena arsenal: what each weapon does, how it sounds, and its sprite (the game's own where it has one) */
export type AW = "pistol" | "uzi" | "shotgun" | "rifle" | "e11" | "magnum" | "sniper" | "saw" | "flame" | "rpg" | "katana" | "saber" | "axe" | "tesla" | "portal";
type Custom = "uzi" | "flame" | "saw" | "e11" | "katana" | "saber" | "axe" | "tesla" | "portal";
export interface AWDef {
  id: AW; name: string; desc: string;
  /** what it fires, or what kind of blade it is: "shock" is the tesla gun's ball of lightning, "portal" the ball of light that opens a portal */
  kind: "bullet" | "laser" | "rocket" | "flame" | "saw" | "katana" | "saber" | "axe" | "shock" | "portal";
  dmg: number; head: number; cd: number; mag: number; ammo: number; reload: number; speed: number; spread: number; bloom: number;
  pellets: number; life: number; auto: boolean; kick: number; shake: number; snd: SfxName | null; pitch: number; vol: number;
  tracer: string; pierce: boolean; rank: number; range: number; sprite: WeaponId | Custom;
}

/** the light of each team: lightsaber blades and blaster bolts glow in it */
export const BEAM = [
  { col: "#ffc82a", hot: "#fff4c2" },
  { col: "#ff2a40", hot: "#ffd0d6" },
];
/** how long the blades are, and how far their cut reaches from the hand */
export const SABER_L = 20;
export const KATANA_L = 21;
/** what is swung, not fired: the katana, the lightsaber, the argent axe */
export const isBlade = (k: AWDef["kind"]) => k === "saber" || k === "katana" || k === "axe";

const base = { head: 1.7, bloom: 0.1, pellets: 1, life: 0.6, auto: false, pitch: 1, vol: 0.8, tracer: "#ffe9a0", pierce: false };
/** (the guns of the duel hit hard and their rounds fly fast: nothing here dawdles across the screen) */
export const AWEP: Record<AW, AWDef> = {
  pistol: { ...base, id: "pistol", name: "PISTOL", desc: "Cepat, akurat, recoil ringan & reload kilat.", kind: "bullet", dmg: 26, head: 1.85, cd: 0.2, mag: 12, ammo: 72, reload: 0.95, speed: 1550, spread: 0.02, bloom: 0.2, kick: 12, shake: 1.7, snd: "pistol", rank: 2, range: 320 },
  uzi: { ...base, id: "uzi", name: "UZI", desc: "Semburan peluru brutal jarak dekat-menengah.", kind: "bullet", dmg: 12, head: 1.65, cd: 0.055, mag: 34, ammo: 136, reload: 1.25, speed: 1450, spread: 0.085, bloom: 0.07, auto: true, kick: 7, shake: 1.4, snd: "ak47", pitch: 1.38, vol: 0.5, rank: 3, range: 240 },
  shotgun: { ...base, id: "shotgun", name: "SHOTGUN", desc: "8 peluru sekaligus dengan hempasan dahsyat!", kind: "bullet", dmg: 13, head: 1.35, cd: 0.7, mag: 6, ammo: 30, reload: 1.6, speed: 1180, spread: 0.19, bloom: 0, pellets: 8, life: 0.19, kick: 100, shake: 5.6, snd: "shotgun", rank: 5, range: 130 },
  rifle: { ...base, id: "rifle", name: "AK-47", desc: "Senapan serbu otomatis andalan segala jarak.", kind: "bullet", dmg: 19, cd: 0.09, mag: 30, ammo: 150, reload: 1.45, speed: 1800, spread: 0.038, bloom: 0.055, auto: true, kick: 13, shake: 2.1, snd: "ak47", rank: 6, range: 360 },
  e11: { ...base, id: "e11", name: "BLASTER E-11", desc: "Senapan plasma stormtrooper - baut laser kencang & keras, menyala warna tim.", kind: "laser", dmg: 24, head: 1.75, cd: 0.115, mag: 30, ammo: 150, reload: 1.35, speed: 1550, spread: 0.028, bloom: 0.055, life: 0.8, auto: true, kick: 12, shake: 2.2, snd: "blaster", vol: 0.68, rank: 6, range: 380 },
  magnum: { ...base, id: "magnum", name: "DEAGLE EMAS", desc: "Hand-cannon kaliber berat yang melempar musuh ke belakang.", kind: "bullet", dmg: 60, head: 1.85, cd: 0.44, mag: 7, ammo: 35, reload: 1.25, speed: 2200, spread: 0.01, bloom: 0.35, kick: 48, shake: 4.2, snd: "goldgun", vol: 0.78, tracer: "#fff3a0", rank: 7, range: 360 },
  sniper: { ...base, id: "sniper", name: "SNIPER", desc: "Laser bidik, jejak supersonik & tembus musuh - sanggup meretakkan batu.", kind: "bullet", dmg: 90, head: 1.65, cd: 1.05, mag: 5, ammo: 25, reload: 1.9, speed: 3400, spread: 0.001, bloom: 0, life: 0.5, kick: 68, shake: 5.4, snd: "sniper", tracer: "#ffffff", pierce: true, rank: 8, range: 540 },
  saw: { ...base, id: "saw", name: "GERGAJI", desc: "Mata gergaji membara yang memantul di dinding.", kind: "saw", dmg: 42, head: 1, cd: 0.5, mag: 6, ammo: 24, reload: 1.5, speed: 620, spread: 0.018, life: 2.2, kick: 22, shake: 1.5, snd: "whoosh", pitch: 1.5, rank: 5, range: 270 },
  flame: { ...base, id: "flame", name: "PENYEMBUR API", desc: "Semburan api panas membara yang membakar musuh.", kind: "flame", dmg: 3.5, head: 1, cd: 0.042, mag: 120, ammo: 240, reload: 1.9, speed: 300, spread: 0.15, life: 0.4, auto: true, kick: 2, shake: 0.6, snd: null, rank: 5, range: 105 },
  rpg: { ...base, id: "rpg", name: "BAZOOKA", desc: "Roket kencang berdaya ledak dahsyat: mengoyak kawah di tanah.", kind: "rocket", dmg: 115, head: 1, cd: 0.88, mag: 1, ammo: 6, reload: 1.55, speed: 440, spread: 0.008, life: 2.2, kick: 78, shake: 4, snd: "bazooka", rank: 8, range: 380 },
  katana: { ...base, id: "katana", name: "KATANA", desc: "Pedang samurai: kombo 4 tebasan (atas-bawah, tebasan SAMPING, & dash Iai) + tangkis peluru!", kind: "katana", dmg: 58, head: 1, cd: 0.24, mag: 1, ammo: 0, reload: 0, speed: 0, spread: 0, bloom: 0, life: 0, auto: true, kick: 0, shake: 2.4, snd: null, rank: 8, range: 36 },
  saber: { ...base, id: "saber", name: "LIGHTSABER", desc: "Pedang cahaya warna tim: kombo 4 tebasan (atas-bawah, tebasan SAMPING, & putar 360°) + pantulkan laser!", kind: "saber", dmg: 64, head: 1, cd: 0.28, mag: 1, ammo: 0, reload: 0, speed: 0, spread: 0, bloom: 0, life: 0, auto: true, kick: 0, shake: 2.4, snd: null, rank: 9, range: 36 },
  axe: { ...base, id: "axe", name: "KAPAK ARGENT", desc: "Kapak energi membara ala Doom: bacokan berat, tebasan samping, lalu HANTAMAN TANAH berapi yang meretakkan arena!", kind: "axe", dmg: 80, head: 1, cd: 0.34, mag: 1, ammo: 0, reload: 0, speed: 0, spread: 0, bloom: 0, life: 0, auto: true, kick: 0, shake: 3.6, snd: null, rank: 9, range: 36 },
  tesla: { ...base, id: "tesla", name: "SENAPAN TESLA", desc: "Peluru listrik: target TERSETRUM 1 detik, lalu menjalar ke 3 musuh terdekatnya (masing-masing 0,3 detik).", kind: "shock", dmg: 12, head: 1, cd: 0.5, mag: 6, ammo: 30, reload: 1.6, speed: 1150, spread: 0.012, bloom: 0.1, life: 0.6, auto: true, kick: 26, shake: 2.8, snd: "zap", vol: 0.85, rank: 7, range: 320 },
  portal: { ...base, id: "portal", name: "PISTOL PORTAL", desc: "Pasang 2 portal yang saling terhubung di dinding/lantai rata: prajurit, peluru & granat bisa lewat. Hanya 1 pembawa per tim!", kind: "portal", dmg: 0, head: 1, cd: 0.45, mag: 1, ammo: 0, reload: 0, speed: 950, spread: 0, bloom: 0, life: 0.9, auto: false, kick: 14, shake: 1.6, snd: null, rank: 0, range: 300 },
} as unknown as Record<AW, AWDef>;
/** (the sprite of each weapon: the game's own by another name for a few of them, its own id for the rest) */
const SPRITE: Partial<Record<AW, WeaponId>> = { rifle: "ak47", magnum: "goldgun", rpg: "bazooka" };
for (const id of Object.keys(AWEP) as AW[]) AWEP[id].sprite = SPRITE[id] ?? (id as WeaponId | Custom);
export const AW_ORDER: AW[] = ["pistol", "uzi", "shotgun", "rifle", "e11", "magnum", "sniper", "saw", "flame", "rpg", "katana", "saber", "axe", "tesla", "portal"];
export const AW_KEYS: string[] = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "=", "K", "T", "P"];

const CUSTOM: Record<Custom, { rows: string[]; pivot: [number, number]; bar: number }> = {
  uzi: {
    rows: ["..KKKKKKKKKK..", ".KGGGGGGGLLLLK", "KKGgGGGGGGKKK.", "KGGKKGGKK.....", ".KK.KAAK......", "....KGGK......", "....KGGK......", ".....KK......."],
    pivot: [5, 3], bar: -2,
  },
  flame: {
    rows: ["..KKK...............", ".KRRRK..KKKKKKKKKK..", ".KRrRKKKGGGGGGGGLLKK", ".KRRRKGGGgGGGGGGLLLK", ".KRRRKKKGGKKKKKKKKK.", ".KRrRK.KAAK.........", "..KKK..KGGK.........", ".......KKK.........."],
    pivot: [8, 4], bar: -1,
  },
  saw: {
    rows: ["........KKKK....", "KKKKKKKKSSSSK...", "KGGGGGGKSssSSK..", "KGgGGGGKSsKsSK..", "KGGKKGGKSssSSK..", "KKK.KAAKKSSSK...", "....KGGK.KKK....", "....KKKK........"],
    pivot: [5, 5], bar: -2,
  },
  // the E-11: a scope on top, the perforated shroud over the barrel, a stripe and a glowing emitter in the team's colour
  e11: {
    rows: [
      "......KKKKKKK.........",
      ".....KLLLLLLLK........",
      "......KKgKKgK.........",
      "KK..KKKKKKKKKKKKKKKKK.",
      "KAKKKGGGGGGGGGKgKgKgVK",
      "KAAAAAAAAGGGGGGGGGGGGK",
      "KKKKKGGKKKGGGKKKKKKKK.",
      ".....KGGK.KAAK........",
      ".....KGGK..KK.........",
      "......KK..............",
    ],
    pivot: [6, 5], bar: -1,
  },
  // a katana hilt: diamond silk-wrapped tsuka handle + ornate gold tsuba handguard + habaki collar
  katana: {
    rows: [
      ".......KKK..",
      ".KKKKKKKYKK.",
      "KAKGAKGKYYKK",
      "KGaKGaKKYSLK",
      ".KKKKKKKYKK.",
      ".......KKK..",
    ],
    pivot: [4, 3], bar: 0,
  },
  // a lightsaber hilt: grip ridges, the activation stud in the team's colour, the emitter shroud
  saber: {
    rows: [".KKKKKKKKK.", "KSKSKSKSSAK", "KsKsKsKssLK", ".KKKKKKKKK."],
    pivot: [3, 2], bar: 0,
  },
  // the argent axe: a long haft bound in the team's colour, a head of dark steel with a rune of fire at its heart, a spike on the back - and an edge that burns
  axe: {
    rows: [
      "....................KK....",
      "...................KDdK...",
      "...................KDdK...",
      "..................KKDdKK..",
      ".................KDDDddDK.",
      "KKKKKKKKKKKKKKKKKKDDOodDK.",
      "KAaGgGGgGGgGGgGGgDDOyOdDK.",
      "KKKKKKKKKKKKKKKKKKDDOodDK.",
      ".................KDDDDdDDK",
      "................KDDDDDdDDK",
      "................KODDDDdDOK",
      "................KyOOOOOOyK",
      ".................KyyyyyyK.",
      "..................KKKKKK..",
    ],
    pivot: [3, 6], bar: 0,
  },
  // the tesla gun: a row of coils along the top, two prongs at the muzzle with the charge held between them
  tesla: {
    rows: [
      "......KKKKKKKK......",
      ".....KCcCcCcCcK.KK..",
      "KKKKKKGGGGGGGGKKKCK.",
      "KAGGGgGGLGGgGGGLLKCK",
      "KAAGGGGGGGGGGGGLLLCK",
      "KKKKGGKKKGGKKKKKKCK.",
      "...KGGK.KAAK.....KK.",
      "...KGGK..KK.........",
      "....KK..............",
    ],
    pivot: [5, 5], bar: -1,
  },
  // the portal gun: a white shell round a core of blue light, a prong tipped with the other colour
  portal: {
    rows: [
      "....KKKKKKK.......",
      "...KWWWWWWWKK.....",
      "KKKWWSSWWWWWWKKK..",
      "KSWWWKPPKWWWSSSWK.",
      "KSSWWKPPKWWSSKKKpK",
      "KKKSSSSSSSSKK..KK.",
      "...KGGKKAAK.......",
      "...KGGK.KK........",
      "....KK............",
    ],
    pivot: [5, 5], bar: -1,
  },
};

export interface WSpr { c: HTMLCanvasElement; w: HTMLCanvasElement; px: number; py: number; bar: number; len: number }
const sprCache: Record<string, WSpr> = {};
/** a weapon sprite (pointing right) with its grip point, barrel line and length to the muzzle */
export function wspr(team: number, id: AW): WSpr {
  const key = `${team}${id}`;
  if (sprCache[key]) return sprCache[key];
  const d = AWEP[id];
  let r: WSpr;
  if (d.sprite in CUSTOM) {
    const cu = CUSTOM[d.sprite as Custom], P = TEAM_PAL[team], wd = Math.max(...cu.rows.map((q) => q.length));
    const c = fromMap(cu.rows.map((q) => q.padEnd(wd, ".")), {
      K: "#0a0a0f", G: "#2a2d38", g: "#4a5064", L: "#8a93a8", S: "#dfe4ec", s: "#9aa3b5", R: "#e0483e", r: "#a8302a", Y: "#f5c542", A: P.A, a: P.a, V: BEAM[team].hot,
      W: "#f6f8fb", O: "#ff6a1e", o: "#c43c12", y: "#ffd75e", D: "#464c60", d: "#262a35", C: "#aef3ff", c: "#2a9ad8", P: "#4fc8ff", p: "#ff9a2a",
    });
    r = { c, w: whiten(c), px: cu.pivot[0], py: cu.pivot[1], bar: cu.bar, len: c.width - cu.pivot[0] };
  } else {
    const sp = d.sprite as WeaponId, c = initSprites().weapon[team][sp], [px, py] = WPIVOT[sp];
    r = { c, w: whiten(c), px, py, bar: WBARREL[sp], len: c.width - px };
  }
  sprCache[key] = r;
  return r;
}

const iconCache: Record<string, string> = {};
/** data-URL of a weapon sprite, for the HUD and the lobby (katana & lightsaber shown full-length) */
export function awIcon(id: AW, team = 0): string {
  const key = id + team;
  if (!iconCache[key]) {
    const s = wspr(team, id);
    if (id === "saber") {
      const B = BEAM[team], [c, g] = mk(s.c.width + 22, 6);
      g.drawImage(s.c, 0, 1);
      g.fillStyle = B.col; g.fillRect(s.c.width, 1, 20, 4);
      g.fillStyle = B.hot; g.fillRect(s.c.width, 2, 21, 2);
      g.fillStyle = "#ffffff"; g.fillRect(s.c.width, 2, 19, 1);
      iconCache[key] = c.toDataURL();
    } else if (id === "katana") {
      const [c, g] = mk(s.c.width + 22, 8);
      g.drawImage(s.c, 0, 2);
      const bx = s.c.width - 1;
      for (let i = 0; i < 21; i++) {
        const curve = i > 14 ? -2 : i > 8 ? -1 : 0;
        const y = 4 + curve;
        g.fillStyle = "#0a0a0f";
        g.fillRect(bx + i, y - 1, 2, i > 18 ? 3 : 4);
      }
      for (let i = 0; i < 20; i++) {
        const curve = i > 14 ? -2 : i > 8 ? -1 : 0;
        const y = 4 + curve;
        g.fillStyle = "#8a99b0";
        g.fillRect(bx + i, y, 1, 1);
        g.fillStyle = i % 3 === 0 ? "#ffffff" : "#e8f2ff";
        g.fillRect(bx + i, y + 1, 1, 1);
      }
      g.fillStyle = "#ffffff";
      g.fillRect(bx + 20, 2, 1, 1);
      iconCache[key] = c.toDataURL();
    } else iconCache[key] = s.c.toDataURL();
  }
  return iconCache[key];
}

let nade: HTMLCanvasElement | null = null, med: HTMLCanvasElement | null = null;
export function nadeSpr(): HTMLCanvasElement {
  if (!nade) nade = fromMap([".KKK.", "KYKK.", "KGgGK", "KGGGK", "KGgGK", ".KKK."], { K: "#0a0a0f", G: "#3f5a34", g: "#5c7c4a", Y: "#c9cdd9" });
  return nade;
}
export function medSpr(): HTMLCanvasElement {
  if (!med) {
    const [c, g] = mk(11, 9);
    const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
    R("#0a0a0f", 0, 1, 11, 8); R("#f2f2f2", 1, 2, 9, 6); R("#c9cdd9", 1, 7, 9, 1); R("#e0483e", 4, 3, 3, 4); R("#e0483e", 3, 4, 5, 2); R("#0a0a0f", 4, 0, 3, 2);
    med = c;
  }
  return med;
}

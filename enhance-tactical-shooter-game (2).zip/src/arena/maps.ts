import { mk } from "../game/sprites";

/**
 * The arenas of the side-view team deathmatch: tile maps built from a few primitives on the left half and mirrored,
 * so both teams get exactly the same ground. Also: painting the terrain pixel by pixel (sand ripples, sandstone strata,
 * crystal veins), a light layer for everything that glows, the parallax backdrops, the minimap, and the navigation grid
 * + pathfinding the bots fly by.
 */
export const AT = 8;
export const AIR = 0;
export const DIRT = 1;
export const ROCK = 2;
export const PLAT = 3;
export const solidT = (t: number) => t === DIRT || t === ROCK;

export type PickKind = "uzi" | "shotgun" | "rifle" | "sniper" | "rpg" | "flame" | "saw" | "magnum" | "e11" | "katana" | "saber" | "axe" | "tesla" | "portal" | "health" | "nades";

export interface Theme {
  id: string; name: string; sub: string;
  sky: [string, string, string];
  far: string; mid: string; near: string;
  dirt: [string, string, string];
  top: [string, string];
  rock: [string, string, string];
  plank: [string, string];
  wall: [string, string];
  cave: [string, string];
  dark: number; rain: number; fog: number; sun: boolean;
  decor: "desert" | "city" | "cave";
  weather: "sand" | "rain" | "spores";
  amb: { wind: number; birds: number; night: number; drone: number; water: number };
}
export interface Decor { x: number; y: number; k: string; v: number; h: number }
/** things that move: flags in the wind, swinging lanterns, waterfalls, crystal light beams, shimmering pools, braziers */
export interface Dyn { k: "flag" | "lantern" | "fall" | "beamlight" | "pool" | "brazier" | "geyser"; x: number; y: number; h: number; t: number; v: number }
export interface Light { x: number; y: number; r: number; col: string; pulse: number }
export interface ArenaMap {
  id: number; theme: Theme; w: number; h: number; grid: Uint8Array; bg: Uint8Array;
  spawns: { x: number; y: number }[][];
  picks: { x: number; y: number; kind: PickKind }[];
  lights: Light[]; decor: Decor[]; dyn: Dyn[];
  nav: Uint8Array; nw: number; nh: number;
  /** hiding places (press E beside one) and the trapdoors over the rat-tunnels */
  hides: HideSpot[]; hatches: { x: number; y: number }[];
}
/** a hiding place: where its foot stands, what it is, and the box of cover (half-width w, height h) that stops a bullet */
export interface HideSpot { x: number; y: number; k: string; name: string; w: number; h: number }
export const HIDE_INFO: Record<string, { name: string; w: number; h: number; light: string }> = {
  grove: { name: "JAMUR RAKSASA", w: 12, h: 17, light: "#5ff0c8" },
  niche: { name: "CERUK BATU", w: 12, h: 17, light: "#ffc870" },
  cart: { name: "GEROBAK TAMBANG", w: 11, h: 14, light: "#ffc870" },
  crates: { name: "PETI TAMBANG", w: 12, h: 15, light: "#ffc870" },
  fern: { name: "SEMAK PAKIS", w: 12, h: 14, light: "#6bffb0" },
  boulder: { name: "BONGKAHAN KRISTAL", w: 12, h: 16, light: "#5ff0e0" },
};

export const hsh = (x: number, y: number, s = 0) => {
  let h = (Math.imul(x | 0, 374761393) + Math.imul(y | 0, 668265263) + Math.imul(s | 0, 1442695041)) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
};
/** smooth value noise */
function vn(x: number, y: number, s: number) {
  const xi = Math.floor(x), yi = Math.floor(y), fx = x - xi, fy = y - yi, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  const a = hsh(xi, yi, s), b = hsh(xi + 1, yi, s), c = hsh(xi, yi + 1, s), d = hsh(xi + 1, yi + 1, s);
  return a + (b - a) * ux + (c - a) * uy + (a - b - c + d) * ux * uy;
}
const ss = (a: number, b: number, x: number) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
const rgb = (h: string): number[] => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
const mixc = (a: number[], b: number[], k: number) => [a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k];
const haloC: Record<string, HTMLCanvasElement> = {};
/** a soft round glow of one colour */
export function halo(col: string): HTMLCanvasElement {
  if (!haloC[col]) {
    const [c, g] = mk(32, 32), gr = g.createRadialGradient(16, 16, 0, 16, 16, 16);
    gr.addColorStop(0, col);
    gr.addColorStop(1, "rgba(0,0,0,0)");
    g.fillStyle = gr;
    g.fillRect(0, 0, 32, 32);
    haloC[col] = c;
  }
  return haloC[col];
}

const THEMES: Theme[] = [
  {
    id: "desert", name: "GURUN BADAI", sub: "Badai pasir, bunker berkarung pasir, reruntuhan kuno & menara tengah",
    sky: ["#a5653c", "#dc9a5c", "#f4d29a"], far: "#c48452", mid: "#d29b64", near: "#b77846",
    dirt: ["#d8a35c", "#c58d4a", "#7a4c26"], top: ["#efc27c", "#ffe2ac"], rock: ["#b47a48", "#cf9660", "#6e4222"],
    plank: ["#9a6a3a", "#5e3e20"], wall: ["#7c6b58", "#665646"], cave: ["#6a4a2e", "#56402a"],
    dark: 0, rain: 0, fog: 0, sun: true, decor: "desert", weather: "sand",
    amb: { wind: 0.85, birds: 0.08, night: 0, drone: 0, water: 0 },
  },
  {
    id: "city", name: "KOTA RUNTUH", sub: "Gedung hancur, jalan layang & kereta bawah tanah",
    sky: ["#231d3a", "#5e4466", "#e6865a"], far: "#3b3150", mid: "#2b2338", near: "#1d1828",
    dirt: ["#4b4549", "#58525a", "#211d26"], top: ["#77777e", "#9a9aa2"], rock: ["#7b7473", "#968f8b", "#3d3939"],
    plank: ["#8f5e3c", "#5a3a24"], wall: ["#3b3539", "#322c30"], cave: ["#2b2830", "#35313a"],
    dark: 0.32, rain: 1, fog: 0.25, sun: false, decor: "city", weather: "rain",
    amb: { wind: 0.45, birds: 0, night: 0.3, drone: 0.2, water: 0 },
  },
  {
    id: "cave", name: "GOA KRISTAL", sub: "Gua yang hidup: geyser pelontar, stalaktit yang bisa ditembak jatuh, gempa & kelelawar - plus tempat sembunyi [E] & jalan tikus",
    sky: ["#050412", "#0f0b28", "#1d1542"], far: "#1c1538", mid: "#130e2a", near: "#0b081c",
    dirt: ["#443963", "#5c4e82", "#1b132e"], top: ["#36b889", "#8ef8d2"], rock: ["#525878", "#7b84ad", "#201e36"],
    plank: ["#a67546", "#5e3e22"], wall: ["#221a35", "#181228"], cave: ["#18122b", "#261d40"],
    dark: 0.45, rain: 0, fog: 0, sun: false, decor: "cave", weather: "spores",
    amb: { wind: 0.12, birds: 0, night: 0, drone: 0.45, water: 0.65 },
  },
];
export const MAP_INFO = THEMES.map((t) => ({ name: t.name, sub: t.sub }));

class Bld {
  g: Uint8Array;
  bg: Uint8Array;
  picks: [number, number, PickKind][] = [];
  cpicks: [number, PickKind][] = [];
  spawns: [number, number][] = [];
  lights: [number, number, number, string, number][] = [];
  decs: [number, number, string][] = [];
  dyns: [number, number, Dyn["k"]][] = [];
  hides: [number, number, string][] = [];
  hatches: [number, number][] = [];
  constructor(public w: number, public h: number) {
    this.g = new Uint8Array(w * h);
    this.bg = new Uint8Array(w * h);
  }
  in(x: number, y: number) { return x >= 0 && y >= 0 && x < this.w && y < this.h; }
  set(x: number, y: number, t: number) { if (this.in(x, y)) this.g[y * this.w + x] = t; }
  get(x: number, y: number) { return this.in(x, y) ? this.g[y * this.w + x] : ROCK; }
  rect(x: number, y: number, w: number, h: number, t: number) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) this.set(xx, yy, t); }
  carve(x: number, y: number, w: number, h: number) { this.rect(x, y, w, h, AIR); }
  wall(x: number, y: number, w: number, h: number, v = 1) { for (let yy = y; yy < y + h; yy++) for (let xx = x; xx < x + w; xx++) if (this.in(xx, yy)) this.bg[yy * this.w + xx] = v; }
  plat(x: number, y: number, w: number) { for (let xx = x; xx < x + w; xx++) if (this.get(xx, y) === AIR) this.set(xx, y, PLAT); }
  ell(cx: number, cy: number, rx: number, ry: number, t: number) {
    for (let y = Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
      for (let x = Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++) {
        const dx = (x + 0.5 - cx) / rx, dy = (y + 0.5 - cy) / ry;
        if (dx * dx + dy * dy <= 1) this.set(x, y, t);
      }
  }
  line(x0: number, y0: number, x1: number, y1: number, r: number, t: number) {
    const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) * 2) + 1;
    for (let i = 0; i <= n; i++) { const k = i / n; this.ell(x0 + (x1 - x0) * k, y0 + (y1 - y0) * k, r, r, t); }
  }
  ground(f: (x: number) => number, x0: number, x1: number) { for (let x = x0; x < x1; x++) for (let y = Math.max(0, f(x)); y < this.h; y++) this.set(x, y, DIRT); }
  pick(x: number, y: number, k: PickKind) { this.picks.push([x, y, k]); }
  /** one pick in the very middle of the map (not mirrored): the prize both teams fight over */
  pickC(y: number, k: PickKind) { this.cpicks.push([y, k]); }
  spawn(x: number, y: number) { this.spawns.push([x, y]); }
  light(x: number, y: number, r: number, col: string, pulse = 0.04) { this.lights.push([x, y, r, col, pulse]); }
  dec(x: number, y: number, k: string) { this.decs.push([x, y, k]); }
  dyn(x: number, y: number, k: Dyn["k"]) { this.dyns.push([x, y, k]); }
  /** a hiding place on the floor at row y: stand beside it and press E to slip in behind its cover */
  hide(x: number, y: number, k: string) { this.hides.push([x, y, k]); }
  /** a trapdoor of planks (two tiles wide) over the shaft of a rat-tunnel: S drops through it */
  hatch(x: number, y: number) { this.plat(x, y, 2); this.hatches.push([x, y]); }
  mirror() {
    const W = this.w;
    for (let y = 0; y < this.h; y++)
      for (let x = 0; x < W >> 1; x++) {
        this.g[y * W + W - 1 - x] = this.g[y * W + x];
        this.bg[y * W + W - 1 - x] = this.bg[y * W + x];
      }
  }
}

/** desert outpost in a sandstorm: a sandbagged bunker each side, a tunnel all the way across under the dunes, ruins, a fortified tower */
function desert(): Bld {
  const b = new Bld(200, 90);
  const hgt = (x: number) => {
    const w = ss(30, 40, x) * (1 - ss(74, 84, x));
    return Math.round(62 - 2 * ss(30, 84, x) + w * (2 * Math.sin((x - 30) * 0.17) - 2.4 * Math.sin((x - 30) * 0.06 + 0.8)));
  };
  b.ground(hgt, 0, 100);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  // the bunker: roof, front wall with a door and a slit, a gallery inside
  b.rect(2, 44, 26, 2, ROCK);
  b.rect(26, 44, 2, 12, ROCK);
  b.rect(2, 41, 2, 3, ROCK);
  b.rect(23, 41, 5, 3, ROCK);
  b.carve(2, 46, 24, 16);
  b.wall(2, 46, 24, 16);
  b.plat(2, 53, 17);
  b.carve(26, 48, 2, 5);
  // the tunnel: down through the bunker floor, all the way to the other side
  b.carve(8, 62, 4, 4);
  b.wall(8, 62, 4, 4, 2);
  b.carve(4, 66, 96, 6);
  b.wall(4, 66, 96, 6, 2);
  for (const sx of [44, 72]) {
    const top = hgt(sx) - 1;
    b.carve(sx, top, 4, 66 - top);
    b.wall(sx, top + 1, 4, 65 - top, 2);
  }
  // a floating rock and scaffolding over the dunes
  b.ell(60, 34, 9, 2.6, ROCK);
  b.ell(60, 33, 7, 1.6, DIRT);
  b.plat(46, 46, 8);
  b.plat(68, 48, 8);
  b.plat(80, 38, 9);
  b.plat(32, 52, 6);
  // the tower in the middle: two floors, doors on both sides, a window you can step out of
  b.rect(92, 26, 8, 36, ROCK);
  b.carve(94, 30, 6, 30);
  b.wall(94, 30, 6, 30);
  b.carve(92, 52, 2, 8);
  b.carve(92, 39, 2, 6);
  b.plat(94, 45, 6);
  b.rect(92, 23, 2, 3, ROCK);
  b.rect(96, 23, 2, 3, ROCK);
  // sandbags on the bunker roof and the team's flag, crates and barrels, palms, the columns of an older city
  for (const x of [6, 12, 18]) b.dec(x, 44, "sandbag");
  b.dyn(25, 41, "flag");
  b.dec(15, 62, "crate"); b.dec(21, 62, "barrel"); b.dec(23, 62, "barrel"); b.dec(5, 53, "crate");
  b.dec(36, hgt(36), "palm"); b.dec(65, hgt(65), "palm"); b.dec(39, hgt(39), "sandbag");
  b.dec(54, hgt(54), "pillar"); b.dec(57, hgt(57), "pillar"); b.dec(79, hgt(79), "pillar");
  b.dec(58, 32, "pillar");
  b.dec(84, hgt(84), "crate"); b.dec(88, hgt(88), "sandbag");
  b.pick(60, 26, "sniper"); b.pick(97, 40, "rpg"); b.pick(84, 30, "magnum"); b.pick(50, 40, "rifle"); b.pick(72, 42, "shotgun");
  b.pick(38, 40, "uzi"); b.pick(56, 66, "health"); b.pick(30, 40, "nades"); b.pick(12, 48, "flame"); b.pick(84, 66, "saw"); b.pick(30, 66, "e11");
  b.pickC(24, "saber");
  b.hide(22, 72, "crates"); b.hide(64, 72, "crates");
  for (const x of [5, 9, 13, 17]) b.spawn(x, 47);
  for (const x of [6, 15, 21]) b.spawn(x, 56);
  return b;
}

/** ruined city at dusk, in the rain: a house each side, a bombed-out block, an overpass, the subway underneath */
function city(): Bld {
  const b = new Bld(200, 90);
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  b.rect(2, 64, 98, 22, DIRT);
  b.carve(2, 70, 98, 6);
  b.wall(2, 70, 98, 6);
  for (const x of [30, 66]) { b.carve(x, 64, 4, 6); b.wall(x, 64, 4, 6); b.plat(x, 67, 4); }
  b.rect(2, 40, 20, 2, ROCK);
  b.rect(20, 42, 2, 12, ROCK);
  b.carve(2, 42, 18, 22);
  b.wall(2, 42, 18, 22);
  b.rect(2, 52, 13, 1, ROCK);
  b.plat(15, 52, 5);
  b.carve(20, 47, 2, 5);
  b.rect(2, 37, 2, 3, ROCK);
  b.rect(17, 37, 5, 3, ROCK);
  b.rect(36, 30, 2, 26, ROCK);
  b.rect(36, 30, 9, 2, ROCK);
  b.rect(50, 38, 2, 16, ROCK);
  b.wall(38, 32, 12, 32);
  b.rect(38, 44, 9, 1, ROCK);
  b.plat(47, 44, 3);
  b.plat(38, 54, 12);
  b.carve(36, 39, 2, 5);
  b.plat(56, 46, 44);
  b.rect(68, 47, 2, 17, ROCK);
  b.rect(86, 47, 2, 17, ROCK);
  b.plat(74, 34, 8);
  b.rect(77, 35, 1, 11, ROCK);
  b.rect(96, 60, 4, 4, ROCK);
  b.ell(57, 64, 4, 1.6, DIRT);
  b.ell(80, 64, 3, 1.3, DIRT);
  b.dyn(18, 37, "flag");
  for (const [x, y] of [[26, 64], [58, 64], [92, 64]]) { b.dec(x, y, "lamp"); b.light(x + 0.5, y - 3.6, 66, "#ffd98a"); }
  b.light(10, 45, 52, "#ffcf7a"); b.light(10, 56, 52, "#ffcf7a"); b.light(44, 48, 44, "#ff9a5a");
  for (const x of [20, 50, 80]) b.light(x, 72, 56, "#bfe0ff");
  b.pick(64, 40, "rifle"); b.pick(77, 28, "sniper"); b.pick(97, 72, "rpg"); b.pick(44, 50, "shotgun"); b.pick(26, 58, "uzi");
  b.pick(48, 72, "health"); b.pick(90, 40, "nades"); b.pick(44, 36, "flame"); b.pick(98, 54, "magnum"); b.pick(16, 72, "saw"); b.pick(82, 58, "e11");
  b.pickC(58, "saber");
  b.hide(38, 76, "crates"); b.hide(72, 76, "crates");
  for (const x of [5, 9, 13]) b.spawn(x, 44);
  b.spawn(17, 44);
  for (const x of [6, 12, 18]) b.spawn(x, 56);
  return b;
}

/** a grand crystal cathedral cave: vaulted chambers, ancient rune arches, luminous pools, mine railway, hanging vines & waterfall */
function cave(): Bld {
  const b = new Bld(200, 90);
  b.rect(0, 0, 100, 90, DIRT);
  // Sanctuary Spawn Grotto (vaulted arch + flat stone terrace)
  b.ell(14, 55, 13, 9, AIR);
  b.rect(2, 63, 24, 4, DIRT);
  b.rect(4, 62, 18, 2, ROCK);
  // Geode Atrium (sculpted dramatic vaulted dome)
  b.ell(46, 49, 18, 12, AIR);
  b.ell(46, 39, 9, 4, AIR);
  // Upper Crystal Observatory Grotto
  b.ell(76, 25, 18, 9, AIR);
  b.ell(76, 18, 7, 3, AIR);
  // Grand Central Crystal Cathedral Hall (tall vaulted ceiling + glowing pool basin)
  b.ell(100, 50, 17, 17, AIR);
  b.ell(100, 34, 8, 6, AIR);
  // Smooth connecting tunnels & mine shaft railway
  b.line(24, 58, 27, 71, 2.7, AIR);
  b.line(27, 71, 100, 72, 3.2, AIR);
  b.line(98, 62, 98, 72, 2.8, AIR);
  b.line(22, 54, 32, 50, 3.3, AIR);
  b.line(56, 42, 66, 29, 3.3, AIR);
  b.line(86, 29, 94, 41, 3.3, AIR);
  b.line(60, 56, 88, 56, 3.1, AIR);
  // Sculpted stone ruins, flanking cathedral balconies & hard mineral rock seams (keeping central waterfall chasm open!)
  b.ell(46, 63, 10, 2.2, ROCK);
  b.ell(76, 36, 9, 1.8, ROCK);
  b.ell(30, 40, 5.5, 3, ROCK);
  b.rect(88, 65, 7, 3, ROCK); // twin carved stone balconies flanking the central waterfall drop
  b.rect(0, 0, 2, 90, ROCK);
  b.rect(0, 86, 100, 4, ROCK);
  // ── JALAN TIKUS: crawl-height rat-tunnels, two tiles tall - a soldier ducks through them, and the bots' flight paths do not reach in ──
  // 1) a trapdoor at the end of the spawn terrace → down through the stone → under the terrace (with a little den on the way) → out into the mine tunnel
  b.carve(5, 62, 2, 10);
  b.carve(7, 70, 17, 2);
  b.carve(11, 69, 4, 3);
  // 2) a hatch in the floor of the long mid tunnel → along underneath it (another den) → out at the foot of the great hall
  b.carve(60, 59, 2, 5);
  b.carve(62, 62, 28, 2);
  b.carve(74, 61, 4, 3);
  // 3) a chimney in the roof of the spawn grotto → over the main tunnel → out high in the wall of the geode atrium
  b.carve(14, 42, 2, 4);
  b.carve(16, 43, 14, 2);
  b.hatch(5, 62);
  b.hatch(60, 59);
  // low rubble walls across the floor of the mid tunnel: crouch (S) behind them and the shots of whoever stands beyond hit the stone
  b.rect(68, 58, 2, 1, ROCK);
  b.rect(80, 58, 2, 1, ROCK);
  // Reinforced mine bridges & lookout scaffolds (including dramatic central bridge across the waterfall!)
  b.plat(34, 52, 10);
  b.plat(49, 44, 9);
  b.plat(67, 30, 12);
  b.plat(89, 46, 11);
  b.plat(87, 59, 13);
  b.plat(8, 54, 7);
  // Warm mine lanterns & crystal sanctuary braziers
  for (const [x, y] of [[38, 49], [53, 41], [72, 27], [93, 43], [11, 50], [23, 56]]) { b.dyn(x, y, "lantern"); b.light(x, y, 64, "#ffc870", 0.09); }
  // Ancient carved rune pillars, giant geode crystals, crystal braziers & team banner
  b.dyn(9, 62, "flag");
  b.dyn(21, 62, "brazier");
  b.dyn(91, 65, "brazier");
  // geysers: vents in the floor that erupt every few seconds and throw whoever stands on them up - one in the geode atrium, one at the foot of the shaft under the spawn grotto (and one in the pool under the great waterfall)
  b.dyn(46, 61, "geyser");
  b.dyn(26, 74, "geyser");
  b.dec(12, 62, "runepillar");
  b.dec(49, 61, "runepillar");
  b.dec(56, 75, "runepillar");
  b.dec(38, 60, "bigcrystal");
  b.dec(53, 60, "bigcrystal");
  b.dec(71, 34, "bigcrystal");
  // Cathedral ceiling crystal chandeliers
  b.dec(46, 35, "ceilcrystal");
  b.dec(76, 15, "ceilcrystal");
  b.dec(98, 28, "ceilcrystal");
  // TEMPAT SEMBUNYI: stand beside one and press E to slip in behind its cover
  b.hide(18, 62, "crates");
  b.hide(43, 61, "grove");
  b.hide(74, 59, "niche");
  b.hide(46, 74, "crates");
  b.hide(64, 75, "cart");
  b.hide(80, 34, "fern");
  b.hide(93, 65, "boulder");
  // the mouths of the rat-tunnels glow faintly green, so that they can be found in the dark; a signpost stands by each hatch
  for (const [x, y] of [[6, 63], [23, 71], [61, 60], [89, 63], [15, 46], [29.5, 44]]) b.light(x, y, 30, "#9dffb0", 0.22);
  b.dec(7, 62, "ratsign");
  b.dec(63, 59, "ratsign");
  // Volumetric glowing crystal light shafts slanting into the great chambers
  b.dyn(45, 36, "beamlight");
  b.dyn(75, 16, "beamlight");
  b.dyn(97, 30, "beamlight");
  // Pickups (ammo super-refills, medkits, grenades, katana & lightsaber energy shrines)
  b.pick(72, 24, "sniper"); b.pick(97, 40, "rpg"); b.pick(54, 38, "magnum"); b.pick(46, 52, "rifle"); b.pick(60, 69, "shotgun");
  b.pick(20, 55, "uzi"); b.pick(80, 69, "health"); b.pick(38, 46, "nades"); b.pick(90, 56, "flame"); b.pick(62, 22, "saw"); b.pick(40, 69, "e11"); b.pick(12, 50, "katana");
  b.pickC(44, "saber");
  for (const x of [5, 8, 11, 14, 17]) b.spawn(x, 52);
  b.spawn(20, 52);
  return b;
}

const BUILDERS = [desert, city, cave];
const cache: ArenaMap[] = [];

export function getMap(id: number): ArenaMap {
  if (cache[id]) return cache[id];
  const b = BUILDERS[id](), theme = THEMES[id];
  b.mirror();
  const W = b.w, H = b.h, g = b.g;
  const tile = (x: number, y: number) => (x < 0 || y < 0 || x >= W || y >= H ? ROCK : g[y * W + x]);
  if (theme.decor === "cave") {
    // the back wall only hugs the rock: the big chambers open onto the deep cave behind them
    for (let y = 0; y < H; y++)
      for (let x = 0; x < W; x++) {
        if (solidT(tile(x, y))) continue;
        let near = false;
        for (let j = -3; j <= 3 && !near; j++) for (let i = -3; i <= 3; i++) if (solidT(tile(x + i, y + j))) { near = true; break; }
        b.bg[y * W + x] = near ? 2 : 0;
      }
  }
  const land = (tx: number, ty: number) => {
    for (let y = Math.max(0, ty); y < H - 1; y++) {
      const d = tile(tx, y + 1);
      if (tile(tx, y) === AIR && (solidT(d) || d === PLAT)) return (y + 1) * AT;
    }
    return ty * AT;
  };
  const mx = (x: number) => W - 1 - x;
  const picks: ArenaMap["picks"] = [];
  for (const [x, y, k] of b.picks) for (const xx of [x, mx(x)]) picks.push({ x: (xx + 0.5) * AT, y: land(xx, y), kind: k });
  for (const [y, k] of b.cpicks) picks.push({ x: (W >> 1) * AT, y: land(W >> 1, y), kind: k });
  const spawns: ArenaMap["spawns"] = [[], []];
  for (const [x, y] of b.spawns) {
    spawns[0].push({ x: (x + 0.5) * AT, y: land(x, y) });
    spawns[1].push({ x: (mx(x) + 0.5) * AT, y: land(mx(x), y) });
  }
  const lights: Light[] = [];
  for (const [x, y, r, col, pulse] of b.lights) for (const xx of [x, W - x]) lights.push({ x: xx * AT, y: y * AT, r, col, pulse });
  const decor: Decor[] = [], dyn: Dyn[] = [];
  for (const [x, y, k] of b.decs) for (const xx of [x, mx(x)]) decor.push({ x: (xx + 0.5) * AT, y: y * AT, k, v: hsh(xx, y, 9), h: 0 });
  for (const [x, y, k] of b.dyns) for (const xx of [x, mx(x)]) dyn.push({ k, x: (xx + 0.5) * AT, y: y * AT, h: 0, t: xx < W / 2 ? 0 : 1, v: hsh(xx, y, 4) });
  // level ground: where the floor (or the roof) is at one height across three tiles, a thing can stand with its whole foot on the rock
  const floorAt = (x: number, y0: number) => { for (let y = Math.max(1, y0); y < H - 1; y++) if (!solidT(tile(x, y)) && solidT(tile(x, y + 1))) return y + 1; return -1; };
  const ceilAt = (x: number, y0: number) => { for (let y = Math.min(H - 2, y0); y > 1; y--) if (!solidT(tile(x, y)) && solidT(tile(x, y - 1))) return y; return -1; };
  const flat = (tx: number, ty: number, roof = false): [number, number] | null => {
    for (let k = 0; k <= 5; k++)
      for (const sx of k ? (tx < W / 2 ? [-k, k] : [k, -k]) : [0]) {
        const x = tx + sx, f = roof ? ceilAt(x, ty + 4) : floorAt(x, ty - 4);
        if (f < 0 || Math.abs(f - ty) > 3) continue;
        if (roof ? ceilAt(x - 1, f + 2) === f && ceilAt(x + 1, f + 2) === f : floorAt(x - 1, f - 2) === f && floorAt(x + 1, f - 2) === f) return [x, f];
      }
    return null;
  };
  // the hiding places: each on level ground, each with a little light of its own
  const hides: HideSpot[] = [];
  for (const [x, y, k] of b.hides) for (const xx of [x, mx(x)]) {
    const at = flat(xx, y), info = HIDE_INFO[k];
    if (!at || !info) continue;
    hides.push({ x: (at[0] + 0.5) * AT, y: at[1] * AT, k, name: info.name, w: info.w, h: info.h });
    lights.push({ x: (at[0] + 0.5) * AT, y: at[1] * AT - 9, r: 46, col: info.light, pulse: 0.1 });
  }
  const hatches: { x: number; y: number }[] = [];
  for (const [x, y] of b.hatches) for (const xx of [x, mx(x) - 1]) hatches.push({ x: (xx + 1) * AT, y: y * AT });
  if (theme.decor === "cave") {
    // the great crystals, the chandeliers and the rune pillars: moved to the nearest level ground, so that nothing hangs over an edge
    for (const d of decor) {
      const roof = d.k === "ceilcrystal";
      if (!roof && d.k !== "bigcrystal" && d.k !== "runepillar") continue;
      const at = flat(Math.floor(d.x / AT), Math.floor(d.y / AT), roof);
      if (!at) { d.k = "none"; continue; }
      d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT;
      const gem = CRYS[(d.v * 5) | 0][0];
      lights.push(roof ? { x: d.x, y: d.y + 9, r: 60, col: gem, pulse: 0.16 } : d.k === "bigcrystal" ? { x: d.x, y: d.y - 11, r: 72, col: gem, pulse: 0.16 } : { x: d.x, y: d.y - 16, r: 52, col: gem, pulse: 0.14 });
    }
    for (const d of dyn) {
      const tx = Math.floor(d.x / AT), ty = Math.floor(d.y / AT);
      if (d.k === "geyser") {
        // on level ground, as tall as the space over it allows
        const at = flat(tx, ty);
        if (at) { d.x = (at[0] + 0.5) * AT; d.y = at[1] * AT; }
        let free = 0;
        while (free < 24 && !solidT(tile(Math.floor(d.x / AT), Math.floor(d.y / AT) - 1 - free))) free++;
        d.h = Math.max(40, Math.min(120, free * AT - 14));
        lights.push({ x: d.x, y: d.y - 6, r: 38, col: "#7fe8ff", pulse: 0.2 });
        continue;
      }
      if (d.k === "brazier") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
        lights.push({ x: d.x, y: d.y - 10, r: 64, col: d.v > 0.5 ? "#d57dff" : "#5ff0e0", pulse: 0.15 });
      } else if (d.k === "flag") {
        const fy = floorAt(tx, Math.max(1, ty - 4));
        if (fy > 0) d.y = fy * AT;
      } else if (d.k === "beamlight") {
        const cy = ceilAt(tx, ty + 4);
        if (cy > 0) d.y = cy * AT;
        const fy = floorAt(tx, Math.floor(d.y / AT));
        d.h = fy > 0 ? (fy - Math.floor(d.y / AT)) * AT : 140;
      }
    }
    // the mine railway along the floor of the deep tunnel, its timber props, glowing crystal carts
    for (let x = 28; x < W - 28; x++) { const f = floorAt(x, 68); if (f > 0 && f < 80) decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "rail", v: 0, h: 0 }); }
    for (const x0 of [36, 52, 70, 84]) for (const x of [x0, mx(x0)]) {
      const f = floorAt(x, 68);
      if (f < 0) continue;
      let c = f - 1;
      while (c > 0 && !solidT(tile(x, c))) c--;
      decor.push({ x: (x + 0.5) * AT, y: f * AT, k: "beam", v: 0, h: (f - c - 1) * AT });
    }
    // (the mine cart full of crystals is a hiding place now: see the hides)
    // grand cathedral waterfall + glowing crystal splash pool beneath it, plus serene turquoise crystal pools in side basins
    const cx = W >> 1;
    let y0 = 20;
    while (y0 < H && solidT(tile(cx, y0))) y0++;
    let y1 = y0;
    while (y1 < H && !solidT(tile(cx, y1))) y1++;
    dyn.push({ k: "fall", x: cx * AT, y: y0 * AT, h: (y1 - y0) * AT, t: 0, v: 0 });
    // (the pool under it erupts too: the tallest geyser of the cave, up the whole height of the great hall)
    dyn.push({ k: "geyser", x: cx * AT, y: y1 * AT, h: Math.max(60, Math.min(190, (y1 - y0) * AT - 30)), t: 0, v: 2 });
    dyn.push({ k: "pool", x: cx * AT, y: y1 * AT, h: 52, t: 0, v: 0.2 });
    lights.push({ x: cx * AT, y: y1 * AT - 4, r: 78, col: "#5ff0e0", pulse: 0.16 });
    for (let k = 0; k < 5; k++) lights.push({ x: cx * AT, y: y0 * AT + ((y1 - y0) * AT * (k + 0.5)) / 5, r: 58, col: "#6fe2ff", pulse: 0.13 });
    for (const [px, py0, pw] of [[46, 54, 30], [75, 30, 28]] as [number, number, number][]) {
      for (const xx of [px, mx(px)]) {
        const fy = floorAt(xx, py0);
        if (fy > 0) {
          dyn.push({ k: "pool", x: (xx + 0.5) * AT, y: fy * AT, h: pw, t: 0, v: hsh(xx, fy, 11) });
          lights.push({ x: (xx + 0.5) * AT, y: fy * AT - 4, r: 50, col: "#5ff0e0", pulse: 0.14 });
        }
      }
    }
  }
  // scattered props on the surfaces (and, in the cave: crystals, bioluminescent mushrooms, stalagmites, stalactites, hanging glowing vines!)
  for (let y = 1; y < H - 2; y++)
    for (let x = 3; x < W - 3; x++) {
      const t = tile(x, y), dn = tile(x, y + 1), up = tile(x, y - 1), q = hsh(x, y, 77);
      if (t === AIR && solidT(dn) && !solidT(tile(x - 1, y)) && !solidT(tile(x + 1, y)) && solidT(tile(x - 1, y + 1)) && solidT(tile(x + 1, y + 1))) {
        // (nothing grows into a great crystal, a pillar, a hiding place or a trapdoor)
        const px = (x + 0.5) * AT, py = (y + 1) * AT;
        if (decor.some((d) => d.k !== "rail" && Math.abs(d.x - px) < (d.k === "bigcrystal" || d.k === "runepillar" ? 24 : 13) && Math.abs(d.y - py) < 12)) continue;
        if (hides.some((h) => Math.abs(h.x - px) < 24 && Math.abs(h.y - py) < 12) || hatches.some((h) => Math.abs(h.x - px) < 14 && Math.abs(h.y - py) < 12)) continue;
        if (dyn.some((d) => (d.k === "flag" || d.k === "brazier" || d.k === "geyser") && Math.abs(d.x - px) < 18 && Math.abs(d.y - py) < 12)) continue;
        const k = hsh(x, y, 78);
        if (theme.decor === "desert" && q < 0.17) decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: k < 0.28 ? "cactus" : k < 0.5 ? "rock" : k < 0.64 ? "bones" : "tuft", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "city" && q < 0.12) decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: k < 0.4 ? "rubble" : k < 0.6 ? "cone" : k < 0.8 ? "tire" : "weed", v: hsh(x, y, 5), h: 0 });
        else if (theme.decor === "cave" && q < 0.22 && !solidT(tile(x, y - 1)) && !solidT(tile(x, y - 2))) {
          const v = hsh(x, y, 5);
          const kind = k < 0.44 ? "crystal" : k < 0.72 ? "shroom" : k < 0.88 ? "stalagmite" : "rock";
          decor.push({ x: (x + 0.5) * AT, y: (y + 1) * AT, k: kind, v, h: 0 });
          if (kind === "crystal") lights.push({ x: (x + 0.5) * AT, y: (y + 1) * AT - 7, r: v > 0.5 ? 58 : 44, col: ["#5ff0e0", "#d57dff", "#6bffb0", "#ffd05a", "#ff72c0"][(v * 5) | 0], pulse: 0.18 });
          else if (kind === "shroom" && v > 0.35) lights.push({ x: (x + 0.5) * AT, y: (y + 1) * AT - 5, r: 30, col: v < 0.65 ? "#5ff0c8" : "#f070b8", pulse: 0.14 });
        }
      }
      if (theme.decor === "cave" && t === AIR && solidT(up) && !solidT(dn)) {
        if (q > 0.85 && !solidT(tile(x, y + 2))) decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "stalag", v: hsh(x, y, 6), h: 0 });
        else if (q < 0.11 && !solidT(tile(x, y + 2)) && !solidT(tile(x, y + 3))) {
          const vh = 10 + Math.round(hsh(x, y, 19) * 18);
          decor.push({ x: (x + 0.5) * AT, y: y * AT, k: "vine", v: hsh(x, y, 21), h: vh });
        }
      }
    }
  // navigation: 16px cells where a soldier fits standing (the cell and the one above it are clear)
  const nw = W >> 1, nh = H >> 1, open = new Uint8Array(nw * nh), nav = new Uint8Array(nw * nh);
  for (let cy = 0; cy < nh; cy++)
    for (let cx = 0; cx < nw; cx++) {
      let ok = 1;
      for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) if (solidT(tile(cx * 2 + dx, cy * 2 + dy))) ok = 0;
      open[cy * nw + cx] = ok;
    }
  for (let cy = 1; cy < nh; cy++) for (let cx = 0; cx < nw; cx++) nav[cy * nw + cx] = open[cy * nw + cx] && open[(cy - 1) * nw + cx] ? 1 : 0;
  const m: ArenaMap = { id, theme, w: W, h: H, grid: g, bg: b.bg, spawns, picks, lights, decor, dyn, nav, nw, nh, hides, hatches };
  cache[id] = m;
  return m;
}

export const tileAt = (m: ArenaMap, tx: number, ty: number) => (tx < 0 || ty < 0 || tx >= m.w || ty >= m.h ? ROCK : m.grid[ty * m.w + tx]);
export const solidPx = (m: ArenaMap, x: number, y: number) => solidT(tileAt(m, Math.floor(x / AT), Math.floor(y / AT)));

// ───────────── pathfinding (BFS over the nav cells, then pulled tight) ─────────────
let prev = new Int32Array(0);
let queue = new Int32Array(0);
const D8 = [1, 0, -1, 0, 0, 1, 0, -1, 1, 1, -1, 1, 1, -1, -1, -1];

function navCell(m: ArenaMap, x: number, y: number): number {
  const cx = Math.max(0, Math.min(m.nw - 1, Math.floor(x / 16))), cy = Math.max(0, Math.min(m.nh - 1, Math.floor((y - 4) / 16)));
  if (m.nav[cy * m.nw + cx]) return cy * m.nw + cx;
  for (let r = 1; r <= 4; r++)
    for (let dy = -r; dy <= r; dy++)
      for (let dx = -r; dx <= r; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== r) continue;
        const x2 = cx + dx, y2 = cy + dy;
        if (x2 >= 0 && y2 >= 0 && x2 < m.nw && y2 < m.nh && m.nav[y2 * m.nw + x2]) return y2 * m.nw + x2;
      }
  return -1;
}
function segClear(m: ArenaMap, x0: number, y0: number, x1: number, y1: number) {
  const n = Math.ceil(Math.hypot(x1 - x0, y1 - y0) / 6);
  for (let i = 1; i < n; i++) {
    const x = x0 + ((x1 - x0) * i) / n, y = y0 + ((y1 - y0) * i) / n;
    const cx = Math.floor(x / 16), cy = Math.floor((y - 4) / 16);
    if (cx < 0 || cy < 0 || cx >= m.nw || cy >= m.nh || !m.nav[cy * m.nw + cx]) return false;
  }
  return true;
}
/** a path for a flying soldier from feet (sx, sy) to (gx, gy): flat [x, y, x, y, ...] of feet positions, start excluded */
export function findPath(m: ArenaMap, sx: number, sy: number, gx: number, gy: number): number[] {
  const nw = m.nw, N = nw * m.nh, nav = m.nav;
  if (prev.length < N) { prev = new Int32Array(N); queue = new Int32Array(N); }
  const s = navCell(m, sx, sy), goal = navCell(m, gx, gy);
  if (s < 0 || goal < 0) return [];
  if (s === goal) return [gx, gy];
  prev.fill(-1, 0, N);
  let head = 0, tail = 0;
  queue[tail++] = s;
  prev[s] = s;
  let found = false;
  while (head < tail) {
    const cur = queue[head++];
    if (cur === goal) { found = true; break; }
    const cx = cur % nw, cy = (cur / nw) | 0;
    for (let d = 0; d < 16; d += 2) {
      const dx = D8[d], dy = D8[d + 1], nx = cx + dx, ny = cy + dy;
      if (nx < 0 || ny < 0 || nx >= nw || ny >= m.nh) continue;
      const ni = ny * nw + nx;
      if (!nav[ni] || prev[ni] !== -1) continue;
      if (dx && dy && (!nav[cy * nw + nx] || !nav[ny * nw + cx])) continue;
      prev[ni] = cur;
      queue[tail++] = ni;
    }
  }
  if (!found) return [];
  const cells: number[] = [];
  for (let c = goal; c !== s; c = prev[c]) cells.push(c);
  cells.reverse();
  const pts: number[] = [];
  for (const c of cells) pts.push(((c % nw) + 0.5) * 16, (((c / nw) | 0) + 1) * 16 - 1);
  pts[pts.length - 2] = gx;
  pts[pts.length - 1] = gy;
  const out: number[] = [];
  let ax = sx, ay = sy, i = 0;
  while (i < pts.length) {
    let j = pts.length - 2;
    while (j > i && !segClear(m, ax, ay, pts[j], pts[j + 1])) j -= 2;
    out.push(pts[j], pts[j + 1]);
    ax = pts[j];
    ay = pts[j + 1];
    i = j + 2;
  }
  return out;
}

// ───────────── painting ─────────────
const CRYS = [
  ["#5ff0e0", "#dcfffb", "#187a82", "#34e0d0"],
  ["#d57dff", "#f7dcff", "#6526a0", "#b854ff"],
  ["#6bffb0", "#e2fff0", "#228252", "#3fe088"],
  ["#ffd05a", "#fff5cc", "#966016", "#ffb228"],
  ["#ff72c0", "#ffdcf0", "#982664", "#ff4ca8"],
];
type Ctx = CanvasRenderingContext2D;

const OUT = "#150d22";
/**
 * One crystal: a chunky six-sided prism - a shaft of even width whose last rows bevel into a flat, two-pixel tip (never a needle).
 * Lit from the left, shaded on the right, glowing softly from inside. dir 1 stands on the floor, -1 hangs from the roof.
 */
function prism(g: Ctx | null, eg: Ctx | null, bx: number, by: number, h: number, w: number, lean: number, pal: string[], dir = 1) {
  const cap = Math.max(2, Math.min(4, w - 1));
  for (let i = 0; i < h; i++) {
    const k = i < h - cap ? 0 : (i - (h - cap) + 1) / cap, ww = Math.max(2, w - Math.round(k * (w - 2)));
    const x0 = Math.round(bx + lean * i) - (ww >> 1), py = dir > 0 ? by - 1 - i : by + i;
    if (g) {
      const lit = Math.max(1, Math.round(ww * 0.34)), dark = ww >= 5 ? 2 : ww >= 3 ? 1 : 0;
      g.fillStyle = OUT; g.fillRect(x0 - 1, py, ww + 2, 1);
      g.fillStyle = pal[0]; g.fillRect(x0, py, ww, 1);
      g.fillStyle = pal[1]; g.fillRect(x0, py, lit, 1);
      if (dark) { g.fillStyle = pal[2]; g.fillRect(x0 + ww - dark, py, dark, 1); }
      // (the shoulder where the tip begins catches the light)
      if (i === h - cap - 1 && ww >= 3) { g.fillStyle = pal[1]; g.fillRect(x0, py, ww - 1, 1); }
    }
    if (eg) { eg.globalAlpha = 0.3; eg.fillStyle = pal[3]; eg.fillRect(x0, py, ww, 1); eg.globalAlpha = 1; }
  }
  if (g) {
    g.fillStyle = OUT; g.fillRect(Math.round(bx + lean * (h - 1)) - 1, dir > 0 ? by - 1 - h : by + h, 2, 1);
    g.fillStyle = "#ffffff"; g.fillRect(Math.round(bx + lean * (h >> 1)) - (w >> 1), dir > 0 ? by - 1 - (h >> 1) : by + (h >> 1), 1, 1);
  }
}

/** the crystals of a cluster, by size: [offset, height, width, lean] - the outer ones first, the tall one in the middle last */
const CLUSTERS: number[][][] = [
  [[-3, 5, 3, -0.18], [3, 6, 3, 0.16], [0, 9, 4, 0.02]],
  [[-6, 5, 3, -0.2], [6, 6, 3, 0.2], [-3, 9, 4, -0.1], [3, 10, 4, 0.08], [0, 14, 5, 0.02]],
  [[-9, 7, 4, -0.2], [9, 8, 4, 0.2], [-5, 13, 5, -0.1], [5, 15, 5, 0.09], [0, 21, 6, -0.02]],
];
/**
 * A cluster of crystals (size 0..2) growing out of a lump of rock whose foot is sunk into the ground - or into the roof (dir -1):
 * nothing floats and nothing sits on a dark strip. One soft, round glow around the whole cluster.
 */
function cluster(g: Ctx | null, eg: Ctx | null, x: number, y: number, pal: string[], size: number, T: Theme, dir = 1) {
  const set = CLUSTERS[size], hw = [5, 8, 12][size], H = set[set.length - 1][1];
  for (const [ox, h, w, lean] of set) prism(g, eg, x + ox, y + dir, h, w, lean, pal, dir);
  if (g)
    for (let i = -hw; i <= hw; i++) {
      const e = Math.abs(i) / hw, rise = e > 0.85 ? 0 : e > 0.5 ? 1 : 2, top = dir > 0 ? y - rise : y + rise - 1;
      g.fillStyle = "#2c2444";
      g.fillRect(x + i, dir > 0 ? y - rise : y - 2, 1, rise + 2);
      if (rise) { g.fillStyle = hsh(i, size, 61) < 0.5 ? "#4f4572" : "#5e5486"; g.fillRect(x + i, top, 1, 1); }
      if (hsh(i, size, 63) < 0.3) { g.fillStyle = T.top[hsh(i, size, 64) < 0.5 ? 0 : 1]; g.fillRect(x + i, top, 1, 1); }
    }
  if (eg) {
    const r = H * 0.95 + hw * 0.5, cy = y - dir * H * 0.42;
    eg.globalAlpha = 0.42; eg.drawImage(halo(pal[3]), x - r, cy - r, r * 2, r * 2);
    eg.globalAlpha = 0.28; eg.drawImage(halo(pal[1]), x - r * 0.45, cy - r * 0.45, r * 0.9, r * 0.9);
    eg.globalAlpha = 1;
  }
}

type Px = (c: string, x: number, y: number, w: number, h: number, a?: number) => void;
/** a clump of fern: fronds fanning out of one root, every one tipped with light */
function fernAt(R: Px, E: Px, cx: number, y: number, hgt: number, seed: number) {
  const fr: number[][] = [];
  for (let f = -3; f <= 3; f++) {
    const len = Math.max(3, hgt - Math.abs(f) * 2 + ((hsh(f, seed, 71) * 3) | 0));
    for (let j = 0; j < len; j++) fr.push([cx + Math.round(f * (0.45 + j * 0.22)), y - 1 - j, j === len - 1 ? 2 : (j + f + 8) % 2]);
  }
  for (const [px, py] of fr) R("#102a22", px - 1, py - 1, 3, 3);
  for (const [px, py, c] of fr) R(c === 2 ? "#b8ffe6" : c ? "#36b889" : "#2d8f68", px, py, 1, 1);
  for (const [px, py, c] of fr) if (c === 2) E("#8ef8d2", px, py, 1, 1);
}

/**
 * A hiding place, painted in two parts: 0 what stands behind whoever hides there (painted onto the arena), 1 the cover in front
 * of them (a sprite the game draws over the soldiers). With g null only what glows is painted, onto the light layer.
 */
function paintHide(g: Ctx | null, eg: Ctx | null, k: string, x: number, y: number, T: Theme, part: number) {
  const R: Px = (c, px, py, w, h) => { if (g) { g.fillStyle = c; g.fillRect(Math.round(px), Math.round(py), w, h); } };
  const E: Px = (c, px, py, w, h, a = 0.7) => { if (eg) { eg.globalAlpha = a; eg.fillStyle = c; eg.fillRect(Math.round(px), Math.round(py), w, h); eg.globalAlpha = 1; } };
  const glow = (c: string, cx: number, cy: number, r: number, a: number) => { if (eg) { eg.globalAlpha = a; eg.drawImage(halo(c), cx - r, cy - r, r * 2, r * 2); eg.globalAlpha = 1; } };
  const K = "#16121a";
  /** a giant mushroom: a pale stem and a domed, spotted cap with glowing gills */
  const shroom = (cx: number, sh: number, hw: number, cap: string, hi: string, dk: string) => {
    const top = y - sh - 5, rows = [hw - 2, hw - 1, hw, hw, hw - 1];
    R(K, cx - 2, y - sh, 5, sh + 1); R("#d9d0bf", cx - 1, y - sh, 3, sh + 1); R("#a89f8f", cx + 1, y - sh, 1, sh + 1); R("#f4eee0", cx - 1, y - sh, 1, sh);
    rows.forEach((w2, r) => R(K, cx - w2 - 1, top + r - (r ? 0 : 1), w2 * 2 + 3, r ? 1 : 2));
    R(K, cx - hw + 1, top + 5, hw * 2 - 1, 1);
    rows.forEach((w2, r) => R(r === 4 ? "#f6ffe9" : r === 3 ? dk : cap, cx - w2, top + r, w2 * 2 + 1, 1));
    R(hi, cx - hw + 2, top, hw - 1, 1); R(hi, cx - hw + 1, top + 1, 2, 1);
    R("#ffffff", cx - 1, top + 1, 1, 1); R("#ffffff", cx + 2, top + 2, 2, 1); if (hw > 5) R("#ffffff", cx - 4, top + 2, 2, 1);
    R("#d9d0bf", cx - 1, top + 5, 3, 1);
    E(cap, cx - hw, top + 1, hw * 2 + 1, 3, 0.55); E("#f6ffe9", cx - hw + 1, top + 4, hw * 2 - 1, 1, 0.8);
    glow(cap, cx, top + 3, hw * 2.2, 0.38);
  };
  /** a wooden crate: boards, a diagonal brace, two nails */
  const crate = (cx: number, by: number, w: number, h: number) => {
    R(K, cx, by - h, w, h); R(T.plank[0], cx + 1, by - h + 1, w - 2, h - 2); R("rgba(255,255,255,0.22)", cx + 1, by - h + 1, w - 2, 1);
    R(T.plank[1], cx + 1, by - 2, w - 2, 1); R(T.plank[1], cx + 1, by - h + 1, 1, h - 2); R(T.plank[1], cx + w - 2, by - h + 1, 1, h - 2);
    for (let i = 2; i < h - 2; i++) R(T.plank[1], cx + 2 + Math.round(((i - 2) * (w - 5)) / Math.max(1, h - 5)), by - h + i, 1, 1);
    R("#9a9eb0", cx + 2, by - h + 2, 1, 1); R("#9a9eb0", cx + w - 3, by - 3, 1, 1);
  };
  switch (k) {
    case "grove":
      if (part === 0) { shroom(x - 9, 7, 5, "#e86cb8", "#ffd4ee", "#b0447f"); shroom(x + 9, 5, 4, "#74c2ff", "#d8f2ff", "#3f86c4"); }
      else { fernAt(R, E, x - 7, y, 8, 1); fernAt(R, E, x + 7, y, 7, 2); shroom(x, 10, 8, "#4ee8c2", "#ccfff2", "#249a82"); fernAt(R, E, x - 2, y, 5, 3); }
      break;
    case "niche":
      if (part === 0) {
        // the hollow in the rock behind: an arch of dressed stones around the dark, a rune of light over it
        R("#0b0814", x - 9, y - 16, 19, 16); R("#0b0814", x - 7, y - 18, 15, 2); R("#0b0814", x - 5, y - 19, 11, 1);
        R("#05040a", x - 6, y - 13, 13, 13);
        for (let i = 0; i < 8; i++) { R(i % 2 ? "#4c5170" : "#3c3d58", x - 11, y - 2 - i * 2, 2, 2); R(i % 2 ? "#3c3d58" : "#4c5170", x + 10, y - 2 - i * 2, 2, 2); }
        R("#4c5170", x - 9, y - 18, 2, 2); R("#3c3d58", x - 7, y - 20, 3, 2); R("#565c80", x - 4, y - 21, 9, 2); R("#3c3d58", x + 5, y - 20, 3, 2); R("#4c5170", x + 8, y - 18, 2, 2);
        R("#ffc870", x, y - 21, 1, 2); R("#ffc870", x - 1, y - 20, 3, 1); E("#ffc870", x, y - 21, 1, 2, 0.9); E("#ffc870", x - 1, y - 20, 3, 1, 0.9); glow("#ffc870", x + 0.5, y - 20, 7, 0.4);
      } else {
        // a parapet of stacked stones in front, a stalagmite post at either end, moss along the top
        R(K, x - 12, y - 10, 25, 11);
        for (let r = 0; r < 3; r++)
          for (let c = 0; c < 5; c++) {
            const bx = x - 11 + c * 6 - (r % 2 ? 3 : 0), by = y - 9 + r * 3, x0 = Math.max(x - 11, bx), x1 = Math.min(x + 12, bx + 5);
            if (x1 <= x0) continue;
            R(hsh(c, r, 81) < 0.5 ? T.rock[0] : "#5c6388", x0, by, x1 - x0, 2); R(T.rock[1], x0, by, x1 - x0, 1);
          }
        for (const sx of [-12, 11]) { R(K, x + sx - 1, y - 15, 4, 16); R(T.rock[0], x + sx, y - 14, 2, 15); R(T.rock[1], x + sx, y - 14, 1, 14); R(K, x + sx, y - 16, 2, 1); }
        for (let i = -11; i <= 11; i++) if (hsh(i, 3, 82) < 0.45) R(T.top[hsh(i, 3, 83) < 0.5 ? 0 : 1], x + i, y - 10, 1, 1);
      }
      break;
    case "cart":
      if (part === 0) {
        // the far wall of the cart, and the crystals heaped in it
        R(K, x - 10, y - 14, 21, 9); R("#1c1e28", x - 9, y - 13, 19, 8);
        prism(g, eg, x - 6, y - 12, 5, 3, -0.1, CRYS[0]); prism(g, eg, x + 5, y - 12, 6, 3, 0.12, CRYS[3]); prism(g, eg, x - 1, y - 12, 7, 4, 0.02, CRYS[1]);
        glow("#5ff0e0", x, y - 15, 12, 0.35);
      } else {
        R(K, x - 11, y - 12, 23, 9); R("#4c5162", x - 10, y - 11, 21, 7); R("#7a8298", x - 10, y - 11, 21, 1); R("#2e3240", x - 10, y - 5, 21, 1); R("#3a3f4e", x - 10, y - 8, 21, 1);
        for (const rx of [-8, -3, 2, 7]) R("#a8aec4", x + rx, y - 10, 1, 1);
        R("#23252f", x - 5, y - 4, 10, 3);
        for (const wx of [-9, 4]) { R(K, x + wx, y - 5, 5, 5); R("#3a3a44", x + wx + 1, y - 4, 3, 3); R("#b0b6ca", x + wx + 2, y - 3, 1, 1); }
        R(K, x + 9, y - 14, 4, 4); R("#ffd05a", x + 10, y - 13, 2, 2); E("#ffd05a", x + 10, y - 13, 2, 2, 0.9); glow("#ffd05a", x + 11, y - 12, 9, 0.5);
      }
      break;
    case "crates":
      if (part === 1) {
        crate(x - 12, y, 13, 12); crate(x, y, 12, 9); crate(x - 9, y - 12, 9, 6);
        R(K, x + 3, y - 14, 5, 5); R("#5a4a2a", x + 4, y - 13, 3, 1); R("#ffd27a", x + 4, y - 12, 3, 2); R("#fff6d8", x + 5, y - 12, 1, 1);
        E("#ffd27a", x + 4, y - 12, 3, 2, 0.9); glow("#ffc870", x + 5.5, y - 11, 9, 0.45);
      }
      break;
    case "fern":
      if (part === 0) { fernAt(R, E, x - 4, y, 13, 4); fernAt(R, E, x + 5, y, 12, 5); }
      else {
        fernAt(R, E, x - 8, y, 9, 6); fernAt(R, E, x + 8, y, 9, 7); fernAt(R, E, x, y, 11, 8);
        // a few buds of light among the fronds
        for (const [bx, by] of [[-6, 6], [4, 8], [9, 4], [-10, 3]]) { R("#fff2a0", x + bx, y - by, 1, 1); E("#fff2a0", x + bx, y - by, 1, 1, 0.9); }
        glow("#6bffb0", x, y - 6, 15, 0.3);
      }
      break;
    case "boulder":
      if (part === 1) {
        const prof = [5, 8, 10, 11, 12, 12, 12, 12, 12, 12, 12, 11, 11, 10];
        prof.forEach((w2, r) => R(K, x - w2 - 1, y - 14 + r, w2 * 2 + 2, 1));
        R(K, x - 5, y - 15, 10, 1);
        prof.forEach((w2, r) => {
          const py = y - 14 + r;
          R(r > 10 ? T.rock[2] : T.rock[0], x - w2, py, w2 * 2, 1);
          if (r < 9) R(T.rock[1], x - w2, py, Math.max(2, Math.round(w2 * (0.9 - r * 0.07))), 1);
          if (r > 2) R(T.rock[2], x + w2 - Math.min(5, r - 1), py, Math.min(5, r - 1), 1);
        });
        // cracks, and moss over the top
        R(T.rock[2], x - 3, y - 9, 1, 3); R(T.rock[2], x - 2, y - 6, 1, 2); R(T.rock[2], x + 4, y - 11, 1, 2);
        for (let i = -9; i <= 9; i++) if (hsh(i, 5, 84) < 0.6) R(T.top[hsh(i, 5, 85) < 0.5 ? 0 : 1], x + i, y - 14 + (Math.abs(i) > 7 ? 2 : Math.abs(i) > 4 ? 1 : 0), 1, 1 + (hsh(i, 5, 86) < 0.3 ? 1 : 0));
        prism(g, eg, x - 6, y - 12, 6, 4, -0.15, CRYS[0]); prism(g, eg, x + 6, y - 11, 5, 3, 0.14, CRYS[0]); prism(g, eg, x + 1, y - 13, 8, 4, 0.03, CRYS[0]);
        glow("#5ff0e0", x, y - 15, 13, 0.4);
      }
      break;
  }
}

const hideC: Record<string, { c: HTMLCanvasElement; ox: number; oy: number }> = {};
/** the cover of a hiding place as a sprite: the game draws it over whoever is tucked in behind it */
export function hideSprite(k: string, T: Theme): { c: HTMLCanvasElement; ox: number; oy: number } {
  const key = T.id + k;
  if (!hideC[key]) {
    const [c, g] = mk(52, 40);
    paintHide(g, null, k, 26, 36, T, 1);
    hideC[key] = { c, ox: 26, oy: 36 };
  }
  return hideC[key];
}
/** the trapdoor over the shaft of a rat-tunnel: iron bands across the planks, a ring to lift it by, two studs of green light */
function hatchDraw(g: Ctx, eg: Ctx | null, x: number, y: number) {
  const R = (c: string, px: number, py: number, w: number, h: number) => { g.fillStyle = c; g.fillRect(px, py, w, h); };
  R("#3d4256", x - 8, y, 2, 3); R("#3d4256", x + 6, y, 2, 3); R("#a4aec6", x - 8, y, 2, 1); R("#a4aec6", x + 6, y, 2, 1);
  R("#16121a", x - 2, y + 1, 4, 2); R("#c9cdd9", x - 1, y + 1, 2, 1);
  for (const sx of [-5, 4]) { R("#9dffb0", x + sx, y + 1, 1, 1); if (eg) { eg.fillStyle = "#9dffb0"; eg.fillRect(x + sx, y + 1, 1, 1); } }
}


export function decorDraw(g: Ctx, eg: Ctx | null, d: Decor, T: Theme) {
  const R = (c: string, x: number, y: number, w: number, h: number) => { g.fillStyle = c; g.fillRect(Math.round(x), Math.round(y), w, h); };
  const x = Math.round(d.x), y = Math.round(d.y), K = "#16121a";
  switch (d.k) {
    case "cactus": {
      const h = 9 + Math.round(d.v * 7);
      R(K, x - 2, y - h - 1, 5, h + 1); R("#3f7a3a", x - 1, y - h, 3, h); R("#5a9a4a", x - 1, y - h, 1, h); R("#2a5a2a", x + 1, y - h, 1, h);
      R(K, x - 5, y - h + 3, 4, 5); R("#3f7a3a", x - 4, y - h + 4, 2, 3); R(K, x + 2, y - h + 5, 4, 4); R("#3f7a3a", x + 3, y - h + 5, 2, 2);
      for (let i = 2; i < h; i += 3) R("#e9e2c8", x + (i % 2 ? -2 : 2), y - i, 1, 1);
      if (d.v > 0.55) { R("#ff6b8a", x, y - h - 2, 1, 2); R("#ffd84a", x, y - h - 1, 1, 1); }
      break;
    }
    case "rock": R(K, x - 5, y - 5, 10, 5); R(T.decor === "cave" ? "#6a6280" : "#a8885e", x - 4, y - 4, 8, 4); R(T.decor === "cave" ? "#8a82a0" : "#c9a676", x - 4, y - 4, 4, 1); R(T.decor === "cave" ? "#4a4258" : "#7a5c38", x + 1, y - 2, 3, 2); break;
    case "bones":
      R("#0a0a0f", x - 5, y - 4, 11, 4); R("#e9e2c8", x - 4, y - 3, 6, 2); R("#c9c0a0", x - 4, y - 2, 6, 1); R("#0a0a0f", x - 2, y - 3, 1, 1); R("#0a0a0f", x, y - 3, 1, 1);
      R("#e9e2c8", x - 6, y - 6, 2, 3); R("#e9e2c8", x + 2, y - 6, 2, 3); R("#e9e2c8", x + 3, y - 2, 3, 1);
      break;
    case "tuft": for (let i = 0; i < 5; i++) R(i % 2 ? "#b8a050" : "#d8c070", x - 2 + i, y - 2 - (i % 3), 1, 2 + (i % 3)); break;
    case "palm": {
      const h = 24 + Math.round(d.v * 10), lean = Math.round((d.v - 0.5) * 12), at = (i: number) => x + Math.round(lean * (i / h) * (i / h));
      for (let i = 0; i < h; i++) R(K, at(i) - 2, y - i - 1, 5, 1);
      for (let i = 0; i < h; i++) { const xx = at(i); R(i % 4 === 0 ? "#6a4826" : "#8e6438", xx - 1, y - i - 1, 3, 1); R("#b08452", xx - 1, y - i - 1, 1, 1); }
      const tx = at(h), ty = y - h;
      const fr: [number, number][] = [[-2.5, 1.1], [-1.9, 1.2], [-1.2, 0.8], [-0.45, 0.5], [0.45, 0.5], [1.2, 0.8], [1.9, 1.2], [2.5, 1.1]];
      for (const pass of [0, 1])
        for (const [a, dr] of fr)
          for (let j = 0; j < 12; j++) {
            const r = j * 1.2, fx = tx + Math.sin(a) * r, fy = ty - Math.cos(a) * r * 0.55 + j * j * 0.07 * dr;
            if (pass === 0) R(K, fx - 1, fy - 1, 3, 3);
            else R(j % 3 === 0 ? "#2c7231" : j % 3 === 1 ? "#4fa046" : "#6cc05a", fx, fy, j < 9 ? 2 : 1, 1);
          }
      R("#0a0a0f", tx - 3, ty, 7, 4); R("#5a3a1a", tx - 2, ty + 1, 2, 2); R("#6a4422", tx + 1, ty + 1, 2, 2);
      break;
    }
    case "sandbag":
      for (let r = 0; r < 2; r++)
        for (let k = 0; k < 3 - r; k++) {
          const bx = x - 9 + k * 6 + r * 3, by = y - 4 - r * 3;
          R(K, bx, by - 1, 7, 5); R("#c9aa76", bx + 1, by, 5, 3); R("#e4cb98", bx + 1, by, 5, 1); R("#9a7e52", bx + 1, by + 2, 5, 1); R("#9a7e52", bx + 3, by, 1, 3);
        }
      break;
    case "crate":
      R(K, x - 6, y - 11, 12, 11); R("#a87a48", x - 5, y - 10, 10, 9); R("#c8965a", x - 5, y - 10, 10, 1); R("#6e4c2a", x - 5, y - 2, 10, 1);
      for (let i = 0; i < 8; i++) R("#7a5430", x - 5 + i + 1, y - 9 + i, 1, 1);
      R("#7a5430", x - 5, y - 10, 1, 9); R("#7a5430", x + 4, y - 10, 1, 9);
      break;
    case "barrel":
      R(K, x - 4, y - 11, 9, 11); R("#5a6a7a", x - 3, y - 10, 7, 9); R("#8a9aaa", x - 2, y - 10, 1, 9); R("#2e3a46", x - 3, y - 8, 7, 1); R("#2e3a46", x - 3, y - 4, 7, 1);
      R("#9a5a2a", x + 1, y - 7, 2, 2); R("#e0483e", x - 1, y - 10, 3, 1);
      break;
    case "pillar": {
      const h = 12 + Math.round(d.v * 12);
      R(K, x - 5, y - 3, 11, 3); R(T.rock[1], x - 4, y - 2, 9, 2);
      R(K, x - 4, y - h, 9, h - 2); R(T.rock[0], x - 3, y - h + 1, 7, h - 3); R(T.rock[1], x - 3, y - h + 1, 1, h - 3); R(T.rock[2], x - 1, y - h + 1, 1, h - 3); R(T.rock[2], x + 2, y - h + 1, 1, h - 3);
      R(K, x - 4, y - h - 2, 3, 3); R(T.rock[0], x - 3, y - h - 1, 2, 2); R(K, x + 1, y - h - 1, 3, 2); R(T.rock[0], x + 2, y - h, 1, 1);
      break;
    }
    case "rubble": R(K, x - 4, y - 3, 9, 3); R("#7a7473", x - 3, y - 2, 3, 2); R("#968f8b", x, y - 3, 3, 3); R("#5a5458", x + 2, y - 1, 2, 1); break;
    case "cone": R(K, x - 3, y - 7, 6, 7); R("#f08a3c", x - 2, y - 6, 4, 6); R("#ffffff", x - 2, y - 4, 4, 1); R(K, x - 4, y - 1, 8, 1); break;
    case "tire": R(K, x - 4, y - 5, 8, 5); R("#2a2a30", x - 3, y - 4, 6, 3); R("#46464e", x - 1, y - 3, 2, 1); break;
    case "weed": for (let i = 0; i < 3; i++) R("#4a6a3a", x - 1 + i, y - 2 - i, 1, 2 + i); break;
    case "lamp":
      R(K, x - 1, y - 30, 3, 30); R("#4a4e5a", x, y - 30, 1, 30); R(K, x - 1, y - 31, 7, 3); R("#4a4e5a", x, y - 30, 5, 1); R("#ffe9a0", x + 3, y - 29, 3, 1);
      if (eg) { eg.fillStyle = "#ffe9a0"; eg.fillRect(x + 3, y - 29, 3, 1); eg.globalAlpha = 0.45; eg.drawImage(halo("#ffd98a"), x - 6, y - 38, 20, 20); eg.globalAlpha = 1; }
      break;
    case "crystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], d.v > 0.48 ? 1 : 0, T); break;
    case "bigcrystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], 2, T); break;
    case "ceilcrystal": cluster(g, eg, x, y, CRYS[(d.v * 5) | 0], d.v > 0.5 ? 2 : 1, T, -1); break;
    case "ratsign": {
      // a little signpost beside the hatch of a rat-tunnel: an arrow pointing down, glowing green
      R(K, x - 1, y - 9, 3, 9); R("#7a5a36", x, y - 9, 1, 9);
      R(K, x - 5, y - 16, 11, 8); R("#a67546", x - 4, y - 15, 9, 6); R("#c8965a", x - 4, y - 15, 9, 1); R("#5e3e22", x - 4, y - 10, 9, 1);
      R("#9dffb0", x, y - 14, 1, 3); R("#9dffb0", x - 1, y - 12, 3, 1); R("#9dffb0", x, y - 11, 1, 1);
      if (eg) { eg.fillStyle = "#9dffb0"; eg.fillRect(x, y - 14, 1, 3); eg.fillRect(x - 1, y - 12, 3, 1); eg.fillRect(x, y - 11, 1, 1); eg.globalAlpha = 0.4; eg.drawImage(halo("#9dffb0"), x - 8, y - 20, 16, 16); eg.globalAlpha = 1; }
      break;
    }
    case "runepillar": {
      const pal = CRYS[(d.v * 5) | 0], h = 24 + Math.round(d.v * 8);
      // ornate stepped plinth
      R(K, x - 7, y - 4, 15, 4); R("#3c3d58", x - 6, y - 3, 13, 3); R("#6a7096", x - 6, y - 3, 12, 1);
      // carved octagonal stone shaft
      R(K, x - 5, y - h, 11, h - 3); R("#34354e", x - 4, y - h + 1, 9, h - 4); R("#565c80", x - 4, y - h + 1, 2, h - 4); R("#201f34", x + 3, y - h + 1, 2, h - 4);
      // mossy temple capital + top crystal cap
      R(K, x - 7, y - h - 4, 15, 5); R("#4c5170", x - 6, y - h - 3, 13, 3); R("#8ef8d2", x - 5, y - h - 3, 6, 1); R("#36b889", x - 6, y - h - 2, 13, 1);
      prism(g, eg, x, y - h - 4, 7, 4, 0, pal);
      // glowing mystic runes etched vertically along the stone shaft
      for (let ry = y - h + 4; ry < y - 6; ry += 5) {
        R(pal[0], x - 1, ry, 3, 1); R(pal[1], x, ry + 1, 1, 2); R(pal[0], x - 1, ry + 2, 3, 1);
        if (eg) { eg.fillStyle = pal[1]; eg.fillRect(x - 1, ry, 3, 1); eg.fillRect(x, ry + 1, 1, 2); }
      }
      if (eg) { eg.globalAlpha = 0.45; eg.drawImage(halo(pal[3]), x - 18, y - h - 10, 36, h + 14); eg.globalAlpha = 1; }
      break;
    }
    case "vine": {
      const h = d.h || 14, pal = CRYS[(d.v * 5) | 0];
      for (let i = 0; i < h; i++) {
        const sx = x + Math.round(Math.sin(i * 0.45 + d.v * 6) * 1.5);
        R("#183c30", sx, y + i, 2, 1);
        R(i % 3 === 0 ? "#4ed89f" : "#2d8f68", sx, y + i, 1, 1);
        if (i > 3 && i % 5 === 0) {
          const leaf = i % 10 === 0 ? -1 : 1;
          R("#36b889", sx + leaf, y + i, 2, 1);
          R(pal[1], sx + leaf, y + i + 1, 1, 1);
          if (eg) { eg.fillStyle = pal[0]; eg.fillRect(sx + leaf, y + i + 1, 1, 1); }
        }
      }
      // glowing dewdrop blossom at the tip
      const tx = x + Math.round(Math.sin(h * 0.45 + d.v * 6) * 1.5);
      R(pal[1], tx, y + h, 2, 2);
      if (eg) { eg.fillStyle = pal[1]; eg.fillRect(tx, y + h, 2, 2); eg.globalAlpha = 0.45; eg.drawImage(halo(pal[3]), tx - 7, y + h - 7, 16, 16); eg.globalAlpha = 1; }
      break;
    }
    case "shroom": {
      // multi-cap bioluminescent mushroom cluster with glowing spotted caps & luminous gills
      const c1 = d.v < 0.34 ? "#4ee8c2" : d.v < 0.67 ? "#e86cb8" : "#74c2ff";
      const hi = d.v < 0.34 ? "#ccfff2" : d.v < 0.67 ? "#ffd4ee" : "#d8f2ff";
      const h = 4 + Math.round(d.v * 5);
      // main cap
      R("#0e0918", x - 1, y - h, 3, h); R("#dfd7c8", x, y - h, 1, h);
      R(K, x - 5, y - h - 4, 11, 5); R(c1, x - 4, y - h - 3, 9, 3); R(hi, x - 3, y - h - 3, 3, 1);
      R("#ffffff", x - 2, y - h - 2, 1, 1); R("#ffffff", x + 2, y - h - 3, 1, 1);
      R(hi, x - 3, y - h, 7, 1); // glowing gills
      // companion baby shrooms
      R("#0e0918", x + 4, y - 3, 2, 3); R("#dfd7c8", x + 5, y - 3, 1, 3);
      R(K, x + 2, y - 5, 6, 3); R(c1, x + 3, y - 4, 4, 1); R("#ffffff", x + 4, y - 4, 1, 1);
      if (d.v > 0.45) {
        R("#0e0918", x - 6, y - 2, 2, 2); R(K, x - 7, y - 4, 5, 3); R(c1, x - 6, y - 3, 3, 1);
      }
      if (eg) {
        eg.fillStyle = c1; eg.fillRect(x - 4, y - h - 3, 9, 3); eg.fillRect(x + 3, y - 4, 4, 1);
        eg.globalAlpha = 0.58; eg.drawImage(halo(c1), x - 13, y - h - 14, 26, 26); eg.globalAlpha = 1;
      }
      break;
    }
    case "stalag": {
      // faceted wet cavern stalactite with glistening specular highlight & water droplet tip
      const h = 5 + Math.round(d.v * 9);
      for (let i = 0; i < h; i++) {
        const w = Math.max(1, 5 - (((i * 5) / h) | 0)), sx = x - (w >> 1);
        R("#140e22", sx - 1, y + i, w + 2, 1);
        R(i < h * 0.45 ? "#4a4068" : "#2f2746", sx, y + i, w, 1);
        if (w >= 2) R("#7a72a0", sx, y + i, 1, 1);
      }
      if (d.v > 0.55) R("#9ae8ff", x, y + h, 1, 1);
      break;
    }
    case "stalagmite": {
      const h = 5 + Math.round(d.v * 8);
      for (let i = 0; i < h; i++) {
        const w = Math.max(1, 5 - (((i * 5) / h) | 0)), sx = x - (w >> 1);
        R("#140e22", sx - 1, y - i - 1, w + 2, 1);
        R(i < h * 0.5 ? "#4a4068" : "#342c4c", sx, y - i - 1, w, 1);
        if (w >= 2) R("#8a82b4", sx, y - i - 1, 1, 1);
      }
      break;
    }
    case "rail":
      R("#2a1e14", x - 4, y - 2, 3, 2); R("#2a1e14", x, y - 2, 3, 2);
      R("#1a1a22", x - 4, y - 4, 8, 2); R("#aeb4c8", x - 4, y - 4, 8, 1);
      break;
    case "beam": {
      const h = d.h;
      R(K, x - 2, y - h, 5, h); R(T.plank[0], x - 1, y - h, 3, h); R(T.plank[1], x + 1, y - h, 1, h);
      // iron brace brackets + overhead crossbeam
      R(K, x - 11, y - h, 23, 5); R(T.plank[0], x - 10, y - h + 1, 21, 3); R("rgba(255,255,255,0.2)", x - 10, y - h + 1, 21, 1);
      R("#3a3e4c", x - 3, y - h + 4, 7, 2); R("#9a9eb0", x - 8, y - h + 2, 1, 1); R("#9a9eb0", x + 8, y - h + 2, 1, 1);
      break;
    }
    case "cart": {
      const pal = CRYS[(d.v * 5) | 0];
      for (let i = 0; i < 7; i++) {
        const ox = -7 + i * 2.3, h = 4 + ((i * 7) % 5);
        R("#0e0818", x + ox - 1, y - 16 - h, 4, h + 1);
        R(pal[i % 2], x + ox, y - 15 - h, 2, h);
        if (eg) { eg.fillStyle = pal[i % 2 === 0 ? 3 : 1]; eg.fillRect(Math.round(x + ox), y - 15 - h, 2, h); }
      }
      R(K, x - 10, y - 15, 21, 11); R("#4c5162", x - 9, y - 14, 19, 9); R("#7a8298", x - 9, y - 14, 19, 1); R("#2e3240", x - 9, y - 7, 19, 1);
      R("#ffd05a", x + 8, y - 12, 2, 2); // minecart front lamp
      for (const rx of [-7, -2, 3]) R("#a8aec4", x + rx, y - 12, 1, 1);
      for (const wx of [-7, 3]) { R(K, x + wx, y - 5, 5, 5); R("#3a3a44", x + wx + 1, y - 4, 3, 3); R("#b0b6ca", x + wx + 2, y - 3, 1, 1); }
      if (eg) { eg.fillStyle = "#ffd05a"; eg.fillRect(x + 8, y - 12, 2, 2); eg.globalAlpha = 0.6; eg.drawImage(halo(pal[3]), x - 18, y - 34, 36, 32); eg.globalAlpha = 1; }
      break;
    }
  }
}

/** the whole arena on one canvas - painted pixel by pixel - and a second one with everything that gives off its own light */
export function paintTerrain(m: ArenaMap): { terr: HTMLCanvasElement; emis: HTMLCanvasElement | null; base: HTMLCanvasElement; ebase: HTMLCanvasElement | null } {
  const T = m.theme, TW = m.w, TH = m.h, W = TW * AT, H = TH * AT, desert = T.decor === "desert", cave = T.decor === "cave", city = T.decor === "city";
  const [c, g] = mk(W, H), img = g.createImageData(W, H), d = img.data;
  let ec: HTMLCanvasElement | null = null, eg: Ctx | null = null;
  if (!desert) [ec, eg] = mk(W, H);
  const eimg = eg ? eg.createImageData(W, H) : null, e = eimg ? eimg.data : null;
  const sol = (x: number, y: number) => solidT(tileAt(m, x, y));
  const depth = new Uint16Array(TW * TH);
  for (let x = 0; x < TW; x++) { let n = 0; for (let y = 0; y < TH; y++) { const i = y * TW + x; n = solidT(m.grid[i]) ? n + 1 : 0; depth[i] = n; } }
  const D0 = rgb(T.dirt[0]), D1 = rgb(T.dirt[1]), D2 = rgb(T.dirt[2]), T0 = rgb(T.top[0]), T1 = rgb(T.top[1]);
  const R0 = rgb(T.rock[0]), R1 = rgb(T.rock[1]), R2 = rgb(T.rock[2]), W0 = rgb(T.wall[0]), W1 = rgb(T.wall[1]), C0 = rgb(T.cave[0]), C1 = rgb(T.cave[1]);
  const BLK = [8, 6, 16], CY = [95, 240, 224], MG = [213, 125, 255], EM = [107, 255, 176], AM = [255, 208, 90], WIN = rgb("#ffcf7a"), WOFF = rgb("#232030"), WFR = rgb("#15131c");
  const glow = (o: number, col: number[], k: number) => { if (e) { e[o] = col[0] * k; e[o + 1] = col[1] * k; e[o + 2] = col[2] * k; e[o + 3] = 255; } };
  for (let py = 0; py < H; py++) {
    const ty = py >> 3, iy = py & 7;
    for (let px = 0; px < W; px++) {
      const tx = px >> 3, ix = px & 7, ti = ty * TW + tx, t = m.grid[ti], o = (py * W + px) * 4;
      let col: number[] | null = null;
      if (solidT(t)) {
        const sd = (depth[ti] - 1) * AT + iy;
        const edge = (ix === 0 && !sol(tx - 1, ty)) || (ix === 7 && !sol(tx + 1, ty)) || (iy === 7 && !sol(tx, ty + 1));
        if (t === DIRT) {
          if (desert) {
            // sand: wind ripples, a bright crust on top, darker and more packed the deeper it goes
            const n = vn(px * 0.045, py * 0.045, 1);
            col = mixc(D0, D1, n);
            const rip = Math.sin(px * 0.4 + py * 1.3 + n * 7);
            if (rip > 0.87) col = mixc(col, T0, 0.6); else if (rip < -0.9) col = mixc(col, D2, 0.25);
            col = mixc(col, D2, Math.min(1, sd / 120) * 0.55);
            if (sd < 2) col = T1; else if (sd < 4) col = T0; else if (sd < 6 && hsh(px, py, 3) < 0.45) col = T0;
            if (hsh(px, py, 4) < 0.004) col = mixc(col, D2, 0.7);
          } else if (cave) {
            // rich stratified amethyst-basalt cave rock: geological layers, glittering mineral specks, luminous emerald moss carpet & multi-gem crystal veins!
            const n = vn(px * 0.055, py * 0.055, 3), n2 = vn(px * 0.19, py * 0.19, 4);
            const strata = Math.sin(py * 0.28 + px * 0.06 + n * 5.2);
            col = mixc(D0, D1, n * 0.68 + n2 * 0.32);
            if (strata > 0.72) col = mixc(col, R1, 0.28);
            else if (strata < -0.78) col = mixc(col, D2, 0.38);
            if (n2 > 0.82) col = mixc(col, D2, 0.48);
            col = mixc(col, D2, Math.min(1, sd / 95) * 0.52);
            const mossEdge = 3 + ((vn(px * 0.22, 0.5, 29) * 3) | 0);
            if (sd < 1) { col = T1; if (hsh(px, py, 31) < 0.28) glow(o, EM, 0.32); }
            else if (sd < 3) col = mixc(T0, T1, 0.35);
            else if (sd < mossEdge && hsh(px, py, 6) < 0.62) col = T0;
            else if (sd >= mossEdge && sd < 105) {
              // glowing multi-color crystal mineral veins & glittering ore flecks
              const vv = Math.abs(Math.sin(px * 0.052 + py * 0.036 + vn(px * 0.015, py * 0.015, 5) * 9.2));
              if (vv < 0.042 && vn(px * 0.02, py * 0.02, 16) > 0.54) {
                const sel = vn(px * 0.011, py * 0.011, 7);
                const vc = sel < 0.33 ? CY : sel < 0.66 ? MG : sel < 0.86 ? EM : AM;
                const core = vv < 0.016;
                col = mixc(col, core ? [255, 255, 255] : vc, core ? 0.78 : 0.72);
                glow(o, vc, core ? 0.75 : 0.46);
              } else if (hsh(px, py, 33) < 0.0045) {
                const sc = hsh(px, py, 34) < 0.5 ? CY : MG;
                col = mixc(col, sc, 0.55);
                glow(o, sc, 0.3);
              }
            }
          } else {
            const n = vn(px * 0.08, py * 0.08, 8);
            col = mixc(D0, D1, n);
            if (hsh(px, py, 9) < 0.01) col = mixc(col, D2, 0.6);
            if (sd < 3) col = sd < 1 ? T1 : T0;
            col = mixc(col, D2, Math.min(1, sd / 100) * 0.4);
          }
        } else if (desert) {
          // sandstone: layered bands, pitted by the wind
          const n = vn(px * 0.03, py * 0.11, 2), bk = (((py + n * 5) / 3) | 0) % 5;
          col = bk === 0 ? R1 : bk === 2 ? mixc(R0, R2, 0.3) : bk === 4 ? mixc(R1, T0, 0.35) : R0;
          if (hsh(px >> 1, py, 5) < 0.03) col = mixc(col, R2, 0.55);
          if (sd < 2) col = mixc(R1, T1, 0.45);
        } else if (cave) {
          // chiseled ancient cavern stonework with beveled icy edges, mossy top trim & faint rune mineral glints
          const row = (py / 5) | 0, off = (row & 1) * 4, mortar = py % 5 === 0 || (px + off) % 8 === 0;
          col = mortar ? R2 : mixc(R0, R1, hsh(((px + off) / 8) | 0, row, 7) * 0.85);
          if (!mortar && py % 5 === 1) col = mixc(col, [185, 200, 240], 0.35);
          if (sd < 2 && hsh(px, py, 37) < 0.55) col = mixc(col, T1, 0.55);
          if (!mortar && hsh(px, py, 39) < 0.005) { col = mixc(col, CY, 0.7); glow(o, CY, 0.38); }
        } else {
          const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
          col = mortar ? R2 : mixc(R0, R1, hsh(((px + off) / 8) | 0, row, 10) * 0.6);
        }
        if (edge) col = mixc(col, BLK, 0.45);
      } else if (m.bg[ti]) {
        const v = m.bg[ti];
        let k = 0;
        if (sol(tx, ty - 1)) k = Math.max(k, (1 - iy / 8) * 0.55);
        if (sol(tx - 1, ty)) k = Math.max(k, (1 - ix / 8) * 0.4);
        if (sol(tx + 1, ty)) k = Math.max(k, (ix / 8) * 0.4);
        if (sol(tx, ty + 1)) k = Math.max(k, (iy / 8) * 0.25);
        if (v === 1) {
          if (city) {
            const row = (py / 4) | 0, off = (row & 1) * 4, mortar = py % 4 === 0 || (px + off) % 8 === 0;
            col = mortar ? W1 : mixc(W0, W1, hsh(((px + off) / 8) | 0, row, 11) * 0.5);
            for (const wx of [tx, tx - 1])
              for (const wy of [ty, ty - 1]) {
                if (wx % 4 !== 1 || wy % 5 !== 1 || hsh(wx, wy, 3) >= 0.55) continue;
                const lx = px - (wx * 8 + 1), ly = py - (wy * 8 + 2);
                if (lx < 0 || ly < 0 || lx >= 10 || ly >= 10) continue;
                const lit = hsh(wx, wy, 4) < 0.25, fr = lx === 0 || ly === 0 || lx === 9 || ly === 9;
                col = fr ? WFR : lit ? WIN : WOFF;
                if (lit && !fr) glow(o, WIN, 0.35);
              }
          } else {
            // the bunker's concrete: panels, seams, stains
            col = px % 16 === 0 || py % 12 === 0 ? W1 : mixc(W0, W1, vn(px * 0.1, py * 0.1, 12) * 0.5);
            if (vn(px * 0.05, py * 0.2, 13) > 0.74) col = mixc(col, BLK, 0.18);
          }
        } else {
          // the back of the tunnels and caves
          const n = vn(px * 0.07, py * 0.07, 14), n2 = vn(px * 0.2, py * 0.2, 15);
          col = mixc(C0, C1, n * 0.7 + n2 * 0.3);
          if (desert && (py + ((n * 4) | 0)) % 6 === 0) col = mixc(col, BLK, 0.15);
          if (cave && n2 > 0.82) col = mixc(col, BLK, 0.25);
        }
        col = mixc(col, BLK, k);
      }
      if (col) { d[o] = col[0]; d[o + 1] = col[1]; d[o + 2] = col[2]; d[o + 3] = 255; }
    }
  }
  g.putImageData(img, 0, 0);
  if (eg && eimg) eg.putImageData(eimg, 0, 0);
  const R = (col: string, x: number, y: number, w: number, h: number) => { g.fillStyle = col; g.fillRect(x, y, w, h); };
  const at = (x: number, y: number) => tileAt(m, x, y);
  for (let y = 0; y < TH; y++)
    for (let x = 0; x < TW; x++) {
      const t = m.grid[y * TW + x], px = x * AT, py = y * AT;
      if (t === PLAT) {
        R("#140e1c", px, py, AT, 4);
        R(T.plank[0], px, py, AT, 3);
        R(T.plank[1], px, py + 2, AT, 1);
        R("rgba(255,255,255,0.22)", px, py, AT, 1);
        if (x % 2 === 0) R("#16121a", px + 1, py + 1, 1, 1);
        R("rgba(0,0,0,0.24)", px, py + 4, AT, 1);
        if (cave) {
          // iron mine bridge rivets & glowing moss tendrils draping beneath cave scaffolds
          if (x % 3 === 0) { R("#3d4256", px + 2, py + 1, 3, 2); R("#a4aec6", px + 3, py + 1, 1, 1); }
          if (hsh(x, y, 47) < 0.38) {
            const mx = px + ((hsh(x, y, 48) * 6) | 0), ml = 2 + ((hsh(x, y, 49) * 4) | 0);
            R("#36b889", mx, py + 3, 1, ml);
            if (hsh(x, y, 50) < 0.45 && eg) { R("#8ef8d2", mx, py + 3 + ml, 1, 1); eg.fillStyle = "#8ef8d2"; eg.fillRect(mx, py + 3 + ml, 1, 1); }
          }
        }
        if (at(x - 1, y) !== PLAT || at(x + 1, y) !== PLAT) { R("#140e1c", px + 3, py + 3, 3, 5); R(cave ? "#525878" : T.plank[1], px + 4, py + 3, 1, 4); }
      } else if (t === AIR && solidT(at(x, y - 1))) {
        R("rgba(0,0,0,0.24)", px, py, AT, 2);
        R("rgba(0,0,0,0.12)", px, py + 2, AT, 3);
        // lush glowing moss tendrils and root curtains hang from the cave roof
        if (cave) {
          const q = hsh(x, y, 91);
          if (q < 0.56) {
            const sx = px + ((hsh(x, y, 92) * 7) | 0), len = 2 + ((hsh(x, y, 93) * 8) | 0);
            R(q < 0.34 ? T.top[0] : "#46375a", sx, py, 1, len);
            if (q < 0.16 && eg) {
              const gc = q < 0.08 ? "#8ef8d2" : "#5ff0e0";
              R(gc, sx, py + len, 1, 2); eg.fillStyle = gc; eg.fillRect(sx, py + len, 1, 2);
            }
          }
        }
      }
    }
  for (const q of m.hatches) hatchDraw(g, eg, Math.round(q.x), Math.round(q.y));
  // the hiding places: what stands behind the one who hides is painted here - the cover in front is a sprite of the game (only its glow goes onto the light layer)
  for (const q of m.hides) { paintHide(g, eg, q.k, Math.round(q.x), Math.round(q.y), T, 0); paintHide(null, eg, q.k, Math.round(q.x), Math.round(q.y), T, 1); }
  // a copy of the bare arena, before anything is stood on it: what shows again where something is shot away
  const [bc, bcg] = mk(W, H);
  bcg.drawImage(c, 0, 0);
  let ebc: HTMLCanvasElement | null = null;
  if (ec) { const [q, qg] = mk(W, H); qg.drawImage(ec, 0, 0); ebc = q; }
  for (const dd of m.decor) decorDraw(g, eg, dd, T);
  return { terr: c, emis: ec, base: bc, ebase: ebc };
}

/** the minimap: one pixel per two tiles */
export function paintMini(m: ArenaMap): HTMLCanvasElement {
  const [c, g] = mk(m.w >> 1, m.h >> 1), T = m.theme;
  g.fillStyle = "rgba(10,10,18,0.72)";
  g.fillRect(0, 0, c.width, c.height);
  for (let y = 0; y < c.height; y++)
    for (let x = 0; x < c.width; x++) {
      const t = tileAt(m, x * 2, y * 2), t2 = tileAt(m, x * 2 + 1, y * 2 + 1);
      if (solidT(t) || solidT(t2)) { g.fillStyle = t === ROCK ? T.rock[1] : T.dirt[0]; g.fillRect(x, y, 1, 1); }
      else if (t === PLAT) { g.fillStyle = T.plank[0]; g.fillRect(x, y, 1, 1); }
    }
  return c;
}

/** a preview of the arena for the lobby */
export function mapPreview(id: number): string {
  const m = getMap(id), T = m.theme, [c, g] = mk(m.w, m.h);
  const grd = g.createLinearGradient(0, 0, 0, m.h);
  grd.addColorStop(0, T.sky[0]); grd.addColorStop(0.6, T.sky[1]); grd.addColorStop(1, T.sky[2]);
  g.fillStyle = grd;
  g.fillRect(0, 0, m.w, m.h);
  for (let y = 0; y < m.h; y++)
    for (let x = 0; x < m.w; x++) {
      const t = m.grid[y * m.w + x];
      const col = t === DIRT ? (tileAt(m, x, y - 1) === DIRT ? T.dirt[0] : T.top[0]) : t === ROCK ? T.rock[0] : t === PLAT ? T.plank[0] : m.bg[y * m.w + x] ? (m.bg[y * m.w + x] === 1 ? T.wall[0] : T.cave[0]) : "";
      if (col) { g.fillStyle = col; g.fillRect(x, y, 1, 1); }
    }
  for (const dd of m.dyn) {
    if (dd.k === "fall") { g.fillStyle = "#7ce6ff"; g.fillRect(Math.floor(dd.x / AT) - 1, Math.floor(dd.y / AT), 2, Math.ceil(dd.h / AT)); }
    else if (dd.k === "pool") { g.fillStyle = "#5ff0e0"; g.fillRect(Math.floor((dd.x - dd.h * 0.5) / AT), Math.floor(dd.y / AT) - 1, Math.max(2, Math.ceil(dd.h / AT)), 2); }
    else if (dd.k === "beamlight") { g.fillStyle = "rgba(130,245,255,0.22)"; g.fillRect(Math.floor(dd.x / AT) - 1, Math.floor(dd.y / AT), 3, Math.ceil(dd.h / AT)); }
  }
  for (const dd of m.decor) {
    if (dd.k === "crystal" || dd.k === "bigcrystal" || dd.k === "ceilcrystal") {
      g.fillStyle = CRYS[(dd.v * 5) | 0][0];
      const sz = dd.k === "bigcrystal" ? 3 : 1;
      g.fillRect(Math.floor(dd.x / AT) - (sz >> 1), Math.floor(dd.y / AT) - sz, sz, sz);
    }
  }
  for (const p of m.picks) { g.fillStyle = p.kind === "saber" ? "#9ae8ff" : p.kind === "katana" ? "#ffffff" : p.kind === "health" ? "#ff6b7a" : p.kind === "nades" ? "#7dff9a" : "#ffe14a"; g.fillRect(Math.floor(p.x / AT), Math.floor(p.y / AT) - 1, 1, 1); }
  for (const q of m.hides) { g.fillStyle = "#4ee08a"; g.fillRect(Math.floor(q.x / AT) - 1, Math.floor(q.y / AT) - 2, 2, 2); }
  for (let t = 0; t < 2; t++) for (const s of m.spawns[t]) { g.fillStyle = t ? "#ff4d5e" : "#f5c542"; g.fillRect(Math.floor(s.x / AT), Math.floor(s.y / AT) - 2, 1, 2); }
  return c.toDataURL();
}

export interface Backdrop { far: HTMLCanvasElement | null; mid: HTMLCanvasElement | null; near: HTMLCanvasElement | null; clouds: HTMLCanvasElement[]; tile: boolean }

/** a horizontal band of the far landscape (960 wide, tileable) */
function band(draw: (g: Ctx, x0: number) => void): HTMLCanvasElement {
  const [c, g] = mk(960, 230);
  for (const x0 of [-960, 0, 960]) draw(g, x0);
  return c;
}
/** one layer of the deep crystal cathedral cave: vaulted arches, ancient subterranean bridges, stalactites, glowing giant crystal spires (tileable both ways) */
function caveLayer(col: string, rim: string, seed: number, depth: "far" | "mid" | "near"): HTMLCanvasElement {
  const W = 480, H = 300, [c, g] = mk(W, H);
  const each = (fn: (dx: number) => void) => { for (const dx of [-W, 0, W]) fn(dx); };
  // faint bioluminescent depth mist in the far cavern abyss
  if (depth === "far") {
    const haze = g.createLinearGradient(0, 0, 0, H);
    haze.addColorStop(0, "rgba(40,26,82,0.08)");
    haze.addColorStop(0.55, "rgba(48,96,120,0.14)");
    haze.addColorStop(1, "rgba(85,220,210,0.22)");
    g.fillStyle = haze;
    g.fillRect(0, 0, W, H);
  }
  g.fillStyle = col;
  g.fillRect(0, 0, W, depth === "near" ? 10 : 16);
  g.fillRect(0, H - (depth === "near" ? 12 : 20), W, depth === "near" ? 12 : 20);
  // ancient underground aqueduct / viaduct arches spanning the mid/far abyss
  if (depth === "mid" || depth === "far") {
    const by = depth === "far" ? H * 0.56 : H * 0.64;
    g.fillRect(0, by, W, depth === "far" ? 6 : 9);
    const span = depth === "far" ? 80 : 120;
    for (let x = 0; x < W; x += span) {
      each((dx) => {
        g.fillRect(x + dx - 5, by, 10, H - by);
        g.beginPath();
        g.arc(x + dx + span * 0.5, by + (depth === "far" ? 28 : 36), span * 0.44, Math.PI, 0);
        g.lineTo(x + dx + span, by);
        g.lineTo(x + dx, by);
        g.closePath();
        g.fill();
      });
    }
  }
  // stalactites & stalagmites
  const count = depth === "near" ? 10 : 18;
  for (let i = 0; i < count; i++) {
    const x = hsh(i, seed, 1) * W, w = (depth === "near" ? 6 : 8) + hsh(i, seed, 2) * (depth === "near" ? 14 : 24), len = 22 + hsh(i, seed, 3) * (depth === "near" ? 46 : 78);
    each((dx) => { g.beginPath(); g.moveTo(x + dx - w, 12); g.lineTo(x + dx + w, 12); g.lineTo(x + dx + w * 0.14, 12 + len); g.closePath(); g.fill(); });
    const x2 = hsh(i, seed, 4) * W, w2 = 7 + hsh(i, seed, 5) * 20, len2 = 18 + hsh(i, seed, 6) * 62;
    each((dx) => { g.beginPath(); g.moveTo(x2 + dx - w2, H - 14); g.lineTo(x2 + dx + w2, H - 14); g.lineTo(x2 + dx - w2 * 0.1, H - 14 - len2); g.closePath(); g.fill(); });
  }
  // towering cavern rock columns
  const cols = depth === "near" ? 2 : 3;
  for (let i = 0; i < cols; i++) {
    const x = (i + 0.25 + hsh(i, seed, 7) * 0.5) * (W / cols), w = (depth === "near" ? 10 : 15) + hsh(i, seed, 8) * 18;
    each((dx) => {
      g.beginPath();
      g.moveTo(x + dx - w * 1.55, 0);
      for (let y = 0; y <= H; y += 18) g.lineTo(x + dx - w * (0.72 + 0.34 * Math.sin(y * 0.032 + i * 2 + seed)), y);
      for (let y = H; y >= 0; y -= 18) g.lineTo(x + dx + w * (0.72 + 0.34 * Math.cos(y * 0.028 + i + seed)), y);
      g.closePath();
      g.fill();
    });
  }
  // rim mineral highlights & subtle carved striations on the silhouettes
  g.globalCompositeOperation = "source-atop";
  g.fillStyle = rim;
  for (let i = 0; i < 340; i++) g.fillRect(Math.floor(hsh(i, seed, 9) * W), Math.floor(hsh(i, seed, 10) * H), 2 + (i % 3), 1);
  // glowing crystal mineral streaks embedded inside distant columns
  for (let i = 0; i < 42; i++) {
    const pal = CRYS[i % 5];
    g.fillStyle = pal[0];
    g.globalAlpha = depth === "far" ? 0.25 : 0.4;
    g.fillRect(Math.floor(hsh(i, seed, 15) * W), Math.floor(hsh(i, seed, 16) * H), 1, 4 + (i % 5));
  }
  g.globalAlpha = 1;
  g.globalCompositeOperation = "source-over";
  // giant glowing distant crystal spires rising out of the cavern abyss + faint glowing ceiling crystal clusters
  const spires = depth === "far" ? 30 : depth === "mid" ? 24 : 14;
  for (let i = 0; i < spires; i++) {
    const x = hsh(i, seed, 11) * W, ceil = i % 4 === 0;
    const y = ceil ? 14 + hsh(i, seed, 12) * 32 : H - 16 - hsh(i, seed, 12) * 55;
    const pal = CRYS[i % 5], sh = (depth === "far" ? 6 : 9) + ((hsh(i, seed, 13) * 10) | 0);
    each((dx) => {
      g.globalAlpha = depth === "far" ? 0.32 : depth === "mid" ? 0.45 : 0.38;
      g.drawImage(halo(pal[3]), x + dx - sh * 1.4, y - sh * 1.4, sh * 2.8, sh * 2.8);
      g.globalAlpha = depth === "far" ? 0.55 : 0.78;
      // (blunt little prisms, like the crystals of the arena itself - not needles)
      const bx = Math.floor(x + dx), w = sh > 11 ? 5 : 4, y0 = Math.floor(ceil ? y : y - sh);
      g.fillStyle = pal[0];
      g.fillRect(bx - (w >> 1), ceil ? y0 : y0 + 2, w, sh - 2);
      g.fillRect(bx - (w >> 1) + 1, ceil ? y0 + sh - 2 : y0, w - 2, 2);
      g.fillStyle = pal[1];
      g.fillRect(bx - (w >> 1), ceil ? y0 : y0 + 2, 1, sh - 2);
    });
  }
  g.globalAlpha = 1;
  return c;
}

/** the parallax layers behind the arena: a skyline, the desert in a storm, or the 3-layer depths of the crystal cathedral cave */
export function paintBackdrop(T: Theme): Backdrop {
  if (T.decor === "cave") return {
    far: caveLayer(T.far, "#34285c", 3, "far"),
    mid: caveLayer(T.mid, "#463774", 7, "mid"),
    near: caveLayer(T.near, "#2d244d", 13, "near"),
    clouds: [],
    tile: true,
  };
  if (T.decor === "desert") {
    const lift = (hex: string, k: number) => { const c = rgb(hex); return `rgb(${Math.min(255, c[0] * k) | 0},${Math.min(255, c[1] * k) | 0},${Math.min(255, c[2] * k) | 0})`; };
    // far: flat-topped mesas and two pyramids, their sunny faces lighter
    const far = band((g, x0) => {
      for (let i = 0; i < 6; i++) {
        const x = x0 + i * 165 + hsh(i, 1, 1) * 50, w = 70 + hsh(i, 2, 1) * 60, h = 46 + hsh(i, 3, 1) * 46;
        g.fillStyle = T.far;
        g.beginPath(); g.moveTo(x, 230); g.lineTo(x + 10, 230 - h); g.lineTo(x + w - 14, 230 - h); g.lineTo(x + w, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.08); g.fillRect(x + 10, 230 - h, w - 24, 3);
      }
      for (const [px, pw, ph] of [[300, 130, 78], [690, 96, 56]]) {
        const x = x0 + px;
        g.fillStyle = lift(T.far, 0.94); g.beginPath(); g.moveTo(x - pw / 2, 230); g.lineTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.closePath(); g.fill();
        g.fillStyle = lift(T.far, 1.1); g.beginPath(); g.moveTo(x, 230 - ph); g.lineTo(x + pw / 2, 230); g.lineTo(x + pw * 0.1, 230); g.closePath(); g.fill();
      }
    });
    const dunes = (col: string, hgt: number, seed: number, ruins: boolean) => band((g, x0) => {
      g.fillStyle = col;
      g.beginPath();
      g.moveTo(x0, 230);
      for (let x = 0; x <= 960; x += 4) { const k = (x / 960) * Math.PI * 2; g.lineTo(x0 + x, 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))); }
      g.lineTo(x0 + 960, 230);
      g.fill();
      // the wind has drawn a bright line along every ridge
      g.fillStyle = lift(col, 1.12);
      for (let x = 0; x <= 960; x += 2) { const k = (x / 960) * Math.PI * 2; g.fillRect(x0 + x, Math.round(230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2) + 0.06 * Math.sin(k * 11 + seed))), 2, 1); }
      if (ruins) {
        g.fillStyle = lift(col, 0.82);
        for (const [rx, n] of [[140, 4], [520, 3], [800, 2]]) for (let i = 0; i < n; i++) {
          const x = x0 + rx + i * 22, k = ((rx + i * 22) / 960) * Math.PI * 2, base = 230 - hgt * (0.55 + 0.25 * Math.sin(k * 2 + seed) + 0.14 * Math.sin(k * 5 + seed * 2)) + 4, h = 26 + ((i * 13 + rx) % 20);
          g.fillRect(x, base - h, 7, h); g.fillRect(x - 2, base - h - 3, 11, 3);
          if (i < n - 1 && i % 2 === 0) g.fillRect(x, base - h - 6, 29, 3);
        }
      }
    });
    const clouds: HTMLCanvasElement[] = [];
    for (let i = 0; i < 4; i++) {
      const [c, g] = mk(120, 36);
      g.fillStyle = "rgba(240,196,140,0.5)";
      for (let k = 0; k < 7; k++) { g.beginPath(); g.ellipse(18 + k * 14 + hsh(i, k, 1) * 6, 20 - hsh(i, k, 2) * 8, 14 + hsh(i, k, 3) * 6, 8 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
      clouds.push(c);
    }
    return { far, mid: dunes(T.mid, 92, 3, false), near: dunes(T.near, 120, 5, true), clouds, tile: false };
  }
  const strip = (col: string, hgt: number, seed: number): HTMLCanvasElement => {
    const [c, g] = mk(960, 220);
    g.fillStyle = col;
    let x = 0;
    while (x < 960) {
      const w = 18 + Math.floor(hsh(x, seed, 1) * 34), h = hgt * (0.35 + hsh(x, seed, 2) * 0.65), broken = hsh(x, seed, 3) < 0.35;
      g.fillRect(x, 220 - h, w, h);
      if (broken) { g.clearRect(x + w * 0.5, 220 - h, w * 0.5, h * 0.18); g.fillRect(x + w * 0.55, 220 - h * 0.86, 2, -h * 0.12); }
      if (seed > 2) {
        g.fillStyle = "rgba(255,200,120,0.5)";
        for (let wy = 220 - h + 6; wy < 214; wy += 7) for (let wx = x + 3; wx < x + w - 3; wx += 5) if (hsh(wx, wy, seed) < 0.1) g.fillRect(wx, wy, 2, 2);
        g.fillStyle = col;
      }
      x += w + Math.floor(hsh(x, seed, 4) * 6);
    }
    return c;
  };
  const clouds: HTMLCanvasElement[] = [];
  for (let i = 0; i < 4; i++) {
    const [c, g] = mk(90, 30);
    g.fillStyle = "rgba(70,56,86,0.85)";
    for (let k = 0; k < 6; k++) { g.beginPath(); g.ellipse(18 + k * 11 + hsh(i, k, 1) * 6, 18 - hsh(i, k, 2) * 8, 12 + hsh(i, k, 3) * 6, 7 + hsh(i, k, 4) * 4, 0, 0, Math.PI * 2); g.fill(); }
    clouds.push(c);
  }
  return { far: strip(T.far, 150, 1), mid: strip(T.mid, 120, 3), near: null, clouds, tile: false };
}

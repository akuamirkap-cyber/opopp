import { pcircle, pfontO, prect, type Ctx } from './pixel';
import { crescent } from './buster';
import { drawStick } from './draw';
import { clamp, rnd } from './rng';
import { solvePose } from './stick';

/**
 * PEMBUKAAN DELAPAN GERBANG (tombol N) — gaya Rock Lee / Might Guy.
 *  Tekan N: gerbang terbuka satu per satu sampai GERBANG 6 (Kaimon, Kyumon, Seimon, Shomon, Tomon, Keimon).
 *  Tiap gerbang menaikkan aura biru, kecepatan lari & serangan, kekuatan pukulan dan dorongan.
 *  Dari GERBANG 3 dan tangan kosong: KLIK KANAN dekat musuh = LOTUS TERSEMBUNYI (Omote Renge) —
 *  menerjang, melontarkan musuh ke udara, berputar bersama, lalu membantingnya ke tanah.
 *  Tenaga terkuras; habis = KELELAHAN sesaat. Tekan N lagi untuk menutup gerbang lebih awal.
 */
type G = any;
type E = any;
const NAMES = ['KAIMON  GERBANG PEMBUKA', 'KYUMON  GERBANG PENYEMBUHAN', 'SEIMON  GERBANG KEHIDUPAN', 'SHOMON  GERBANG LUKA', 'TOMON  GERBANG BATAS', 'KEIMON  GERBANG PANDANG'];
const C_MID = '#6fd6ff', C_OUT = '#2f7bff', C_DEEP = '#1b3fb8';
const MAXG = 6;
const easeOut = (k: number) => 1 - Math.pow(1 - clamp(k, 0, 1), 3);

interface Flame { x: number; y: number; vx: number; vy: number; t: number; max: number; r: number; ph: number; k: number }
interface Pulse { x: number; y: number; t: number; max: number; r: number }
interface Bolt { pts: [number, number][]; t: number }

let SPR: HTMLCanvasElement[] | null = null;
/** sprite gumpalan api bergradasi lembut (dibuat sekali): luar biru, tengah cyan, inti putih */
function sprites(): HTMLCanvasElement[] {
  if (SPR) return SPR;
  const mk = (stops: [number, string][]) => {
    const c = document.createElement('canvas'); c.width = 48; c.height = 48;
    const x = c.getContext('2d')!;
    const g = x.createRadialGradient(24, 24, 0, 24, 24, 24);
    for (const [o, col] of stops) g.addColorStop(o, col);
    x.fillStyle = g; x.fillRect(0, 0, 48, 48);
    return c;
  };
  SPR = [
    mk([[0, 'rgba(60,150,255,0.9)'], [0.45, 'rgba(30,100,255,0.5)'], [1, 'rgba(20,70,255,0)']]),
    mk([[0, 'rgba(180,235,255,0.95)'], [0.5, 'rgba(90,190,255,0.5)'], [1, 'rgba(60,160,255,0)']]),
    mk([[0, 'rgba(255,255,255,1)'], [0.4, 'rgba(225,246,255,0.6)'], [1, 'rgba(200,240,255,0)']]),
  ];
  return SPR;
}

export class EightGates {
  on = false;
  gates = 0;
  energy = 100;
  exhaust = 0;
  openT = 0;
  lotusCd = 0;
  time = 0;
  flames: Flame[] = [];
  pulses: Pulse[] = [];
  bolts: Bolt[] = [];
  private pulseT = 0;
  private glow = 0;
  // lotus
  lotus = false;
  private lt = 0;
  private lphase = 0;
  private ldir = 0;
  private lx = 0; private ly = 0;

  get speedMul() { return this.exhaust > 0 ? 0.62 : this.on ? 1 + 0.05 * this.gates : 1; }
  get atkMul() { return this.exhaust > 0 ? 0.8 : this.on ? 1 + 0.07 * this.gates : 1; }
  get dmgMul() { return this.on ? 1 + 0.3 * this.gates : 1; }
  get kbMul() { return this.on ? 1 + 0.14 * this.gates : 1; }

  reset() { this.on = false; this.gates = 0; this.lotus = false; this.flames.length = 0; this.pulses.length = 0; this.bolts.length = 0; this.exhaust = 0; this.energy = 100; this.openT = 0; this.glow = 0; }

  toggle(g: G) {
    if (g.state !== 'playing') return;
    const p = g.player;
    if (this.lotus || p.fatality) return;
    if (this.on) { this.close(g, false); return; }
    if (this.exhaust > 0) { g.texts?.add?.(p.x, p.y - 24, 'MASIH KELELAHAN', '#7fa8d8', 1, 0.7); g.sfx?.empty?.(); return; }
    if (this.energy < 25) { g.texts?.add?.(p.x, p.y - 24, 'TENAGA BELUM CUKUP', '#7fa8d8', 1, 0.7); g.sfx?.empty?.(); return; }
    this.on = true; this.gates = 0; this.openT = 0;
    g.say?.('PEMBUKAAN DELAPAN GERBANG', C_MID, 2, 1.6);
    g.sfx?.announce?.();
  }

  private openGate(g: G) {
    const p = g.player;
    this.gates++;
    const n = this.gates;
    this.glow = 1;
    g.say?.(`GERBANG ${n}: ${NAMES[n - 1]}`, n >= 5 ? '#bfe8ff' : C_MID, 2, 1.1);
    g.shake?.(0.25 + n * 0.1); g.flash?.(C_OUT, 0.04 + n * 0.012);
    g.zoomKick = Math.max(g.zoomKick ?? 0, 0.025 + n * 0.012);
    g.hitstop = Math.max(g.hitstop ?? 0, 0.03 + n * 0.008);
    g.sfx?.slam?.(); g.sfx?.focus?.(); if (n >= 4) g.sfx?.explosion?.();
    for (let i = 0; i < 2 + (n >> 1); i++) this.pulses.push({ x: p.x, y: p.y, t: -i * 0.07, max: 0.55 + n * 0.03, r: 16 + n * 6 });
    g.particles?.shockwave?.(p.x, p.y - 4, 26 + n * 9, C_MID, 0.4);
    g.particles?.ring?.(p.x, p.y - 8, 3, 18 + n * 4, '#ffffff', 0.3, 2);
    g.particles?.burst?.(p.x, p.y - 8, 10 + n * 4, C_MID, 160 + n * 30, 0.5, 2, 3);
    if (n === 1) { p.holdT = Math.max(p.holdT ?? 0, 0.32); p.holdPose = 'flex'; p.holdPoseT = 0; }
    if (n === MAXG) {
      g.slow?.(0.6, 0.25);
      g.say?.('KEKUATAN PENUH - KLIK KANAN: LOTUS TERSEMBUNYI', '#ffffff', 1, 2.2);
    }
  }

  close(g: G, forced: boolean) {
    const p = g.player;
    const hadHigh = this.gates >= 5;
    this.on = false; this.gates = 0; this.openT = 0;
    g.particles?.burst?.(p.x, p.y - 8, 18, C_MID, 120, 0.5, 2, 2);
    g.particles?.smoke?.(p.x, p.y - 6, 6, '#e9f7ff', 30, 0.6);
    if (forced || hadHigh) {
      this.exhaust = forced ? 2.6 : 1.4;
      g.say?.(forced ? 'KELELAHAN...' : 'GERBANG DITUTUP', '#9fb4d8', 2, 1.2);
    } else g.say?.('GERBANG DITUTUP', '#9fb4d8', 1, 0.9);
    g.sfx?.whoosh?.();
  }

  update(g: G, dt: number) {
    dt = Math.min(dt, 1 / 20);
    this.time += dt;
    this.lotusCd = Math.max(0, this.lotusCd - dt);
    this.glow = Math.max(0, this.glow - dt * 2.5);
    this.exhaust = Math.max(0, this.exhaust - dt);
    for (let i = this.pulses.length - 1; i >= 0; i--) { this.pulses[i].t += dt; if (this.pulses[i].t >= this.pulses[i].max) this.pulses.splice(i, 1); }
    for (let i = this.bolts.length - 1; i >= 0; i--) { this.bolts[i].t += dt; if (this.bolts[i].t > 0.1) this.bolts.splice(i, 1); }
    for (let i = this.flames.length - 1; i >= 0; i--) {
      const f = this.flames[i];
      f.t += dt; f.x += f.vx * dt; f.y += f.vy * dt; f.vx *= 1 - 1.8 * dt; f.vy *= 1 - 0.35 * dt;
      if (f.t >= f.max) this.flames.splice(i, 1);
    }
    if (this.flames.length > 120) this.flames.splice(0, this.flames.length - 120);
    if (g.state !== 'playing') return;
    if (!this.on) { if (!this.lotus) this.energy = Math.min(100, this.energy + dt * (this.exhaust > 0 ? 2 : 6)); return; }
    if (this.lotus) return;
    this.openT -= dt;
    if (this.gates < MAXG && this.openT <= 0) { this.openGate(g); this.openT = 0.58; }
    this.energy -= (1.5 + this.gates * 0.75) * dt;
    if (this.energy <= 0) { this.energy = 0; this.close(g, true); return; }
    // hentakan tekanan di tanah berkala
    this.pulseT -= dt;
    if (this.pulseT <= 0 && this.gates >= 3) {
      this.pulseT = 0.9 - this.gates * 0.06;
      this.pulses.push({ x: g.player.x, y: g.player.y, t: 0, max: 0.6, r: 14 + this.gates * 3.2 });
    }
  }

  // ------------------------------------------------------------------ gambar
  private eyes(opts: any, head: { x: number; y: number }) {
    const s = opts.scale ?? 1, la = opts.look ?? opts.aim, ldx = Math.cos(la), ldy = Math.sin(la);
    const gap = Math.max(1.8, 2 * s), cx = head.x + ldx * 0.5 * s, cy = head.y + ldy * 0.3 * s - 0.3;
    return [{ x: cx - gap, y: cy, ldx }, { x: cx + gap, y: cy, ldx }];
  }
  private skel(g: G, opts: any) {
    const p = g.player, sk = solvePose(opts);
    const ox = p.x, oy = p.y - p.z;
    const J = (v: { x: number; y: number }) => ({ x: ox + v.x, y: oy + v.y });
    return { hip: J(sk.hip), neck: J(sk.neck), head: J(sk.head), fh: J(sk.fhand), bh: J(sk.bhand), ff: J(sk.ffoot), bf: J(sk.bfoot) };
  }

  /** AURA API LEMBUT di BELAKANG tubuh: selubung bercahaya + gumpalan api yang naik pelan, bergoyang, dan memudar (tanpa garis tajam). */
  drawAura(ctx: Ctx, g: G, opts: any, dt: number) {
    if (!this.on && this.glow <= 0 && !this.lotus) return;
    const p = g.player;
    const n = Math.min(MAXG, this.gates + (this.lotus ? 1 : 0));
    const k = Math.min(1, n / MAXG);
    const { hip, neck, head, fh, bh, ff, bf } = this.skel(g, opts);
    const cx = (hip.x + neck.x) / 2, cy = (hip.y + neck.y) / 2;
    const t = this.time;
    const SP = sprites();
    const mvx = p.vx + p.kx * 0.3, mvy = p.vy + p.ky * 0.3, spd = Math.hypot(mvx, mvy);
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    // --- pendar tanah (lembut)
    const gr = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, 15 + k * 14);
    gr.addColorStop(0, `rgba(40,130,255,${0.24 + 0.14 * k})`); gr.addColorStop(1, 'rgba(40,120,255,0)');
    ctx.fillStyle = gr; ctx.beginPath(); ctx.ellipse(p.x, p.y + 1, 16 + k * 16, 5.5 + k * 5, 0, 0, Math.PI * 2); ctx.fill();
    // --- siluet aura (bergetar halus)
    const copies = n >= 5 ? 3 : n >= 3 ? 2 : 1;
    for (let i = 0; i < copies; i++) {
      const sc = (opts.scale ?? 1) * (1.06 + i * 0.09 + Math.sin(t * 11 + i) * 0.015);
      const jx = Math.sin(t * 23 + i * 2) * (0.2 + k * 0.35), jy = Math.cos(t * 19 + i * 3) * 0.2;
      const o2 = { ...opts, x: opts.x + jx, y: opts.y + jy - i * 0.5, scale: sc, c: i === 0 ? '#8fd3ff' : '#4a9bff', c2: C_OUT, alpha: (0.34 - i * 0.09) * (0.8 + 0.2 * Math.sin(t * 7 + i)), outline: null, flash: false, strike: null, impact: 0, trail: null, acc: 'none', handOverride: undefined, bhandOverride: undefined };
      drawStick(ctx, o2);
    }
    // --- selubung api: gumpalan besar bergradasi di belakang tubuh, berdenyut pelan
    const pul = 0.85 + 0.15 * Math.sin(t * 6.5);
    const bw = (13 + k * 11) * pul, bh2 = (24 + k * 20) * (0.92 + 0.08 * Math.sin(t * 5 + 1));
    ctx.globalAlpha = 0.34 + 0.12 * k; ctx.drawImage(SP[0], cx - bw, cy - 8 - bh2 * 0.55, bw * 2, bh2 * 1.5);
    ctx.globalAlpha = 0.30 + 0.1 * k; ctx.drawImage(SP[1], cx - bw * 0.62, cy - 6 - bh2 * 0.5, bw * 1.24, bh2 * 1.2);
    // --- sumber gumpalan api (kaki -> tangan -> badan -> kepala makin banyak seiring gerbang)
    const src: { x: number; y: number; w: number }[] = [{ x: ff.x, y: ff.y - 1, w: 0.8 }, { x: bf.x, y: bf.y - 1, w: 0.8 }];
    if (n >= 2) src.push({ x: fh.x, y: fh.y, w: 0.9 }, { x: bh.x, y: bh.y, w: 0.9 });
    if (n >= 3) src.push({ x: hip.x, y: hip.y, w: 1.15 }, { x: neck.x, y: neck.y, w: 1.15 }, { x: cx, y: cy, w: 1.3 });
    if (n >= 4) src.push({ x: head.x, y: head.y - 1, w: 1.1 });
    const rate = (0.35 + n * 0.32) * Math.min(2, dt * 60);
    for (let i = 0, c = Math.floor(rate + Math.random()); i < c; i++) {
      const s0 = src[Math.floor(Math.random() * src.length)];
      this.flames.push({ x: s0.x + rnd(-1.4, 1.4), y: s0.y + rnd(-1.2, 1.2), vx: rnd(-6, 6) - mvx * 0.12, vy: -rnd(16, 30 + n * 4) - mvy * 0.05, t: 0, max: rnd(0.55, 0.85 + k * 0.3), r: rnd(1.9, 2.8 + k * 1.2) * s0.w, ph: Math.random() * 6.28, k: 0 });
    }
    // percikan bara halus
    if (Math.random() < 0.18 + k * 0.4) this.flames.push({ x: cx + rnd(-8, 8), y: cy + rnd(-12, 8), vx: rnd(-10, 10), vy: -rnd(22, 46), t: 0, max: rnd(0.5, 1.0), r: 0.7, ph: 0, k: 2 });
    // --- gambar gumpalan api: tiga lapis (biru luar, cyan tengah, putih inti), memanjang ke atas, lalu mengecil & memudar
    for (const f of this.flames) {
      const u = f.t / f.max;
      const life = Math.pow(Math.sin(Math.PI * Math.min(1, u)), 0.7);
      const sway = Math.sin(t * 5.5 + f.ph) * f.r * 0.55 * u;
      const x = f.x + sway, y = f.y;
      if (f.k === 2) { ctx.globalAlpha = life * 0.85; ctx.drawImage(SP[2], x - 1.2, y - 1.2, 2.4, 2.4); continue; }
      const sz = f.r * (1.15 - u * 0.5);
      ctx.globalAlpha = life * 0.34; ctx.drawImage(SP[0], x - sz * 1.4, y - sz * 2.5, sz * 2.8, sz * 3.8);
      ctx.globalAlpha = life * 0.42; ctx.drawImage(SP[1], x - sz * 0.9, y - sz * 1.7, sz * 1.8, sz * 2.6);
      ctx.globalAlpha = life * 0.50; ctx.drawImage(SP[2], x - sz * 0.45, y - sz * 0.9, sz * 0.9, sz * 1.4);
    }
    // --- pusaran api lembut (separuh belakang): gerbang 6 dan saat Lotus
    if (n >= 6 || this.lotus) this.vortex(ctx, cx, cy, t, true);
    ctx.globalAlpha = 1;
    ctx.restore();
    // --- cincin tekanan di tanah (halus)
    ctx.save();
    for (const q of this.pulses) {
      if (q.t < 0) continue;
      const u = q.t / q.max, rr = q.r * easeOut(u);
      ctx.globalAlpha = (1 - u) * 0.55;
      ctx.strokeStyle = C_MID; ctx.lineWidth = Math.max(1, 2.4 * (1 - u));
      ctx.beginPath(); ctx.ellipse(q.x, q.y, rr, rr * 0.4, 0, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.globalAlpha = 1;
    // --- pusaran lotus
    if (this.lotus && this.lphase >= 2) {
      const u = this.lt;
      for (let i = 0; i < 3; i++) {
        const a0 = u * 14 + i * 2.1;
        crescent(ctx, cx, cy - 2, 17 + i * 5, a0, a0 + 2.3, 4 - i, i === 0 ? '#ffffff' : C_MID, 0.8 - i * 0.2, 0, i, 0.6);
      }
    }
    ctx.restore();
    // --- efek gerak: bayangan sisa & uap lembut
    if (n >= 4 && spd > 80 && Math.random() < 0.5) g.addAfterimage?.({ x: p.x, y: p.y - p.z, facing: opts.facing, aim: opts.aim, pose: opts.pose, poseT: opts.t }, '#4fb2ff', p.lean);
    if (n >= 4 && Math.random() < 0.4) g.particles?.add?.({ x: cx + rnd(-5, 5), y: cy + rnd(-10, 6), vx: rnd(-8, 8), vy: -rnd(14, 32), life: rnd(0.5, 0.9), c: '#dff3ff', k: 0, s: 1 });
    if (n >= 6) { this.shakeT -= dt; if (this.shakeT <= 0) { this.shakeT = 0.45; g.shake?.(0.05); } }
  }
  private shakeT = 0;

  /** pusaran gumpalan api yang mengitari tubuh; back = separuh di belakang badan */
  private vortex(ctx: Ctx, cx: number, cy: number, t: number, back: boolean) {
    const SP = sprites();
    for (let i = 0; i < 8; i++) {
      const a = t * 4.2 + i * (Math.PI / 4);
      const sn = Math.sin(a);
      if ((sn < 0) !== back) continue;
      const rise = ((t * 26 + i * 9) % 30);
      const x = cx + Math.cos(a) * 13, y = cy + 8 + sn * 5 - rise;
      const life = Math.sin(Math.PI * Math.min(1, rise / 30));
      const sz = 3.2 * (1 - rise / 60);
      ctx.globalAlpha = life * 0.34; ctx.drawImage(SP[0], x - sz * 1.4, y - sz * 2.4, sz * 2.8, sz * 3.6);
      ctx.globalAlpha = life * 0.42; ctx.drawImage(SP[1], x - sz * 0.8, y - sz * 1.5, sz * 1.6, sz * 2.4);
    }
    ctx.globalAlpha = 1;
  }

  /** bagian DEPAN: api lembut dari MATA, kilau di wajah, separuh pusaran depan. Dipanggil setelah drawStick pemain. */
  drawAuraFront(ctx: Ctx, g: G, opts: any) {
    if (!this.on && !this.lotus) return;
    const n = Math.min(MAXG, this.gates + (this.lotus ? 1 : 0));
    if (n <= 0) return;
    const { hip, neck, head } = this.skel(g, opts);
    const cx = (hip.x + neck.x) / 2, cy = (hip.y + neck.y) / 2;
    const t = this.time, SP = sprites();
    const p = g.player;
    const mvx = p.vx + p.kx * 0.3;
    ctx.save();
    ctx.imageSmoothingEnabled = true;
    if (n >= 6 || this.lotus) this.vortex(ctx, cx, cy, t, false);
    // --- MATA: cahaya lembut + api tipis yang mengalir ke belakang-atas
    if (n >= 2) {
      const eyes = this.eyes(opts, head);
      const fl = 0.8 + 0.2 * Math.sin(t * 20);
      const steps = n >= 5 ? 5 : n >= 3 ? 4 : 3;
      for (let ei = 0; ei < 2; ei++) {
        const e = eyes[ei];
        const ex = e.x, ey = e.y;
        ctx.globalAlpha = 0.7 * fl; ctx.drawImage(SP[1], ex - 3.8 - n * 0.3, ey - 3.8 - n * 0.3, 7.6 + n * 0.6, 7.6 + n * 0.6);
        for (let i = 1; i <= steps; i++) {
          const u = i / steps;
          const wob = Math.sin(t * 13 + ei * 2 + i * 1.1) * (0.6 + n * 0.18) * u;
          const x = ex - e.ldx * (1.5 + u * (3.5 + n * 1.1)) - mvx * 0.01 * u + wob, y = ey - u * (4 + n * 2.1) - 0.5;
          const sz = (2.1 + n * 0.2) * (1 - u * 0.65);
          ctx.globalAlpha = (1 - u * 0.75) * 0.42; ctx.drawImage(SP[0], x - sz * 1.2, y - sz * 1.9, sz * 2.4, sz * 3.2);
          ctx.globalAlpha = (1 - u * 0.75) * 0.5; ctx.drawImage(SP[1], x - sz * 0.7, y - sz * 1.2, sz * 1.4, sz * 2);
        }
        ctx.globalAlpha = 0.95; ctx.drawImage(SP[2], ex - 1.4, ey - 1.4, 2.8, 2.8);
      }
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  // ------------------------------------------------------------------ HUD
  drawHud(ctx: Ctx, g: G, VIEW_W: number, VIEW_H: number) {
    if (!this.on && this.energy >= 99.5 && this.exhaust <= 0) return;
    if (g.state !== 'playing' && g.state !== 'paused') return;
    const x = Math.round(VIEW_W / 2 - 40), y = VIEW_H - 22, w = 80;
    prect(ctx, x - 3, y - 12, w + 6, 24, 'rgba(4,8,18,0.7)');
    prect(ctx, x - 3, y - 12, w + 6, 1, 'rgba(255,255,255,0.28)');
    prect(ctx, x - 3, y + 11, w + 6, 1, 'rgba(0,0,0,0.85)');
    prect(ctx, x - 3, y - 12, 2, 24, this.on ? C_MID : '#44546a');
    for (let i = 0; i < MAXG; i++) {
      const open = i < this.gates;
      const bx = x + i * 13;
      prect(ctx, bx, y - 9, 11, 7, open ? C_DEEP : '#141c2c');
      if (open) { prect(ctx, bx + 1, y - 8, 9, 5, i >= 4 ? '#bfeaff' : C_MID); prect(ctx, bx + 1, y - 8, 9, 1, '#ffffff'); }
    }
    prect(ctx, x, y + 2, w, 4, '#0d1422');
    const col = this.exhaust > 0 ? '#7a7a8a' : this.energy < 25 ? '#ff5a5a' : C_MID;
    prect(ctx, x, y + 2, Math.round(w * this.energy / 100), 4, col);
    prect(ctx, x, y + 2, Math.round(w * this.energy / 100), 1, 'rgba(255,255,255,0.5)');
    pfontO(ctx, this.exhaust > 0 ? 'KELELAHAN' : this.on ? `GERBANG ${this.gates}/6  [N] TUTUP` : 'PEMULIHAN', VIEW_W / 2, y + 8, this.exhaust > 0 ? '#9fb0c8' : '#d8f2ff', '#000', 1, 'center');
  }

  /** petunjuk Lotus di atas musuh terdekat */
  drawHint(ctx: Ctx, g: G) {
    const p = g.player;
    if (!this.on || this.gates < 3 || this.lotus || p.fatality || g.state !== 'playing') return;
    const e = this.pickTarget(g);
    if (!e) return;
    const pulse = 0.55 + 0.45 * Math.sin(this.time * 9);
    ctx.globalAlpha = 0.5 + 0.5 * pulse;
    pcircle(ctx, e.x, e.y - 40 * (e.scale ?? 1) - (e.z ?? 0), 1.6, C_MID);
    ctx.globalAlpha = 1;
    pfontO(ctx, this.lotusCd > 0 ? `LOTUS ${this.lotusCd.toFixed(1)}S` : p.weapon === 'fist' ? 'KLIK KANAN: LOTUS' : 'LOTUS: TANGAN KOSONG', e.x, e.y - 50 * (e.scale ?? 1) - (e.z ?? 0), this.lotusCd > 0 ? '#7fa8d8' : '#d8f2ff', '#000', 1, 'center');
  }

  // ------------------------------------------------------------------ LOTUS TERSEMBUNYI
  private pickTarget(g: G): E | null {
    const p = g.player;
    let best: E | null = null, bd = 1e9;
    for (const e of g.enemies) {
      if (e.dead || e.spawnT > 0 || e.z > 1 || e.jack) continue;
      const d = Math.hypot(e.x - p.x, e.y - p.y);
      if (d > 105) continue;
      const ang = Math.atan2(e.y - p.y, e.x - p.x);
      const a = Math.abs(Math.atan2(Math.sin(ang - p.aim), Math.cos(ang - p.aim)));
      const s = d + a * 22;
      if (s < bd) { bd = s; best = e; }
    }
    return best;
  }

  tryLotus(g: G): boolean {
    const p = g.player;
    if (!this.on || this.gates < 3 || p.weapon !== 'fist' || this.lotus || p.fatality || p.stunT > 0 || g.state !== 'playing') return false;
    if (this.lotusCd > 0 || this.energy < 14) return false;
    const e = this.pickTarget(g);
    if (!e) return false;
    this.energy = Math.max(1, this.energy - 14);
    this.lotusCd = 6;
    this.lotus = true; this.lt = 0; this.lphase = 0;
    this.ldir = Math.atan2(e.y - p.y, e.x - p.x);
    this.lx = p.x; this.ly = p.y;
    const F = { kind: 'lotus', id: e.id, t: 0, step: 0, stepT: 0, sx: p.x, sy: p.y, tx: e.x, ty: e.y, dir: this.ldir, hit: false, hitT: 0, perfect: false };
    p.fatality = F;
    p.attackPhase = 'none'; p.buffered = null; p.dashT = 0; p.parryT = 0; p.focusDash = null; p.z = 0; p.runT = 0; p.running = false;
    p.aim = this.ldir; p.attackAim = this.ldir; p.facing = Math.cos(this.ldir) >= 0 ? 1 : -1; p.vx = p.vy = p.kx = p.ky = 0; p.moving = false;
    p.holdPose = 'flying'; p.holdPoseT = 0.2; p.iframes = 8;
    e.stagger = 10; e.state = 'stagger'; e.pose = 'stagger'; e.kx = e.ky = 0; e.vx = e.vy = 0; e.stun = 0; e.fuse = -1; g.releaseToken?.(e);
    for (const o of g.enemies) if (o !== e && !o.dead) o.attackCd = Math.max(o.attackCd, 1.6);
    g.cinematic = true; g.zoomTarget = 1.5 * 1.4;
    g.say?.('LOTUS TERSEMBUNYI!', '#ffffff', 3, 1.4);
    g.sfx?.announce?.(); g.sfx?.dash?.(); g.sfx?.whoosh?.();
    g.flash?.(C_MID, 0.25);
    return true;
  }

  /** dipanggil dari updateFatality saat kind === 'lotus' */
  step(g: G, raw: number, F: any, e: E | null) {
    const p = g.player;
    F.t += raw; this.lt = F.t;
    g.slowT = Math.max(g.slowT ?? 0, 0.2);
    g.slowFactor = this.lphase >= 2 ? 0.34 : 0.5;
    p.iframes = Math.max(p.iframes, 3);
    if (!e || e.dead) { this.endLotus(g); return; }
    const dir = this.ldir, cd = Math.cos(dir), sd = Math.sin(dir);
    const t = F.t;
    const keep = () => { e.kx = e.ky = 0; e.vx = e.vy = 0; e.stagger = 10; e.stun = 0; e.state = 'stagger'; };
    const ez = (z: number) => { e.z = Math.max(0.1, z); e.vz = 0; e.pose = 'launched'; e.rot = Math.sin(t * 16) * 0.25; };
    if (this.lphase === 0) {
      // ---- menerjang
      const u = clamp(t / 0.2, 0, 1);
      const gap = e.r + p.r + 3;
      const tx = e.x - cd * gap, ty = e.y - sd * gap;
      const nx = this.lx + (tx - this.lx) * easeOut(u), ny = this.ly + (ty - this.ly) * easeOut(u);
      if (g.isFree(nx, ny, p.r)) { p.x = nx; p.y = ny; }
      p.holdPose = 'flying'; p.holdPoseT = 0.5;
      keep();
      g.addAfterimage?.({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: 'flying', poseT: 0.5 }, C_MID, p.lean);
      g.particles?.lines?.(p.x - cd * 6, p.y - 6, 2, '#bfeaff', dir + Math.PI, 240);
      g.camFocus = { x: (p.x + e.x) / 2, y: (p.y + e.y) / 2 };
      if (t >= 0.2) {
        this.lphase = 1; F.t = 0;
        g.hitstop = Math.max(g.hitstop ?? 0, 0.07); g.shake?.(0.5);
        g.sfx?.heavy?.(); g.sfx?.punch?.();
        g.particles?.impact?.(e.x, e.y - 8, 10, '#ffffff'); g.particles?.shockwave?.(e.x, e.y - 6, 26, C_MID, 0.3);
      }
      return;
    }
    if (this.lphase === 1) {
      // ---- tendangan naik: musuh terlontar ke atas, pemain menyusul
      const u = clamp(t / 0.32, 0, 1);
      const z = 58 * easeOut(u);
      ez(z); keep();
      p.z = z * 0.85; p.holdPose = 'monkeyflip'; p.holdPoseT = 0.2 + 0.4 * u;
      g.camFocus = { x: p.x, y: p.y - z * 0.45 };
      g.zoomTarget = (1.5 + 0.35 * u) * 1.4;
      if (Math.random() < 0.8) g.particles?.add?.({ x: p.x + rnd(-4, 4), y: p.y - p.z * 0.5 - 4, vx: rnd(-18, 18), vy: rnd(10, 40), life: 0.3, c: C_MID, k: 0, s: 1 });
      if (t >= 0.32) { this.lphase = 2; F.t = 0; g.sfx?.axeSwing?.(); g.sfx?.launch?.(); }
      return;
    }
    if (this.lphase === 2) {
      // ---- berputar bersama di udara
      const u = clamp(t / 0.6, 0, 1);
      const z = 58 + 8 * Math.sin(u * Math.PI);
      ez(z); keep();
      e.rot = u * Math.PI * 6 * (cd >= 0 ? 1 : -1);
      p.z = z * 0.85 + 1; p.holdPose = 'spin'; p.holdPoseT = 0.5 * u;
      const cxx = p.x, cyy = p.y - p.z - 6;
      if (Math.random() < 0.9) g.particles?.add?.({ x: cxx + rnd(-14, 14), y: cyy + rnd(-10, 10), vx: rnd(-40, 40), vy: rnd(-40, 40), life: 0.28, c: Math.random() < 0.5 ? C_MID : '#ffffff', k: 0, s: 1 });
      g.camFocus = { x: p.x, y: p.y - z * 0.5 };
      g.zoomTarget = 2.2 * 1.4;
      if (t >= 0.6) { this.lphase = 3; F.t = 0; g.sfx?.whoosh?.(); }
      return;
    }
    if (this.lphase === 3) {
      // ---- bantingan: jatuh cepat ke tanah
      const u = clamp(t / 0.18, 0, 1);
      const z = 62 * (1 - u * u);
      ez(z); keep();
      e.rot = (1 - u) * 1.2;
      p.z = z * 0.85; p.holdPose = 'kneedrop'; p.holdPoseT = 0.2 + 0.4 * u;
      g.addAfterimage?.({ x: p.x, y: p.y - p.z, facing: p.facing, aim: p.aim, pose: 'kneedrop', poseT: 0.5 }, C_MID, p.lean);
      g.particles?.lines?.(p.x, p.y - p.z - 8, 2, '#ffffff', -Math.PI / 2, 260);
      if (t >= 0.18) {
        this.lphase = 4; F.t = 0;
        p.z = 0; e.z = 0; e.vz = 0; e.rot = 0;
        this.impact(g, e, cd, sd);
      }
      return;
    }
    // ---- akibat
    g.slowFactor = 0.45;
    p.z = 0; p.holdPose = 'flex'; p.holdPoseT = 0;
    g.camFocus = { x: p.x, y: p.y - 4 };
    g.zoomTarget = 1.7 * 1.4;
    if (t >= 0.6) this.endLotus(g);
  }

  private impact(g: G, e: E, cd: number, sd: number) {
    const p = g.player;
    const hard = e.boss || e.kind === 'duelist' || e.ai2 || e.sm || e.jack || e.tb;
    g.hitstop = Math.max(g.hitstop ?? 0, 0.16); g.flash?.('#ffffff', 0.7); g.shake?.(1); g.zoomKick = 0.14;
    g.sfx?.explosion?.(); g.sfx?.slam?.(); g.sfx?.fatality?.(); g.sfx?.kill?.();
    g.particles?.shockwave?.(e.x, e.y, 70, '#ffffff', 0.5);
    g.particles?.shockwave?.(e.x, e.y, 46, C_MID, 0.4);
    g.particles?.ring?.(e.x, e.y - 2, 3, 40, C_MID, 0.4, 2);
    g.particles?.burst?.(e.x, e.y - 3, 38, '#8a7a5a', 300, 0.8, 2, 3);
    g.particles?.burst?.(e.x, e.y - 3, 24, C_MID, 260, 0.6, 2, 3);
    g.particles?.smoke?.(e.x, e.y, 12, '#9a9a9a', 70, 0.8);
    g.splat?.(e.x, e.y, 14);
    for (let i = 0; i < 4; i++) this.pulses.push({ x: e.x, y: e.y, t: -i * 0.06, max: 0.7, r: 44 + i * 10 });
    // musuh di sekitar ikut terhempas
    for (const o of g.enemies) {
      if (o === e || o.dead || o.spawnT > 0) continue;
      const d = Math.hypot(o.x - e.x, o.y - e.y);
      if (d > 56) continue;
      const a = Math.atan2(o.y - e.y, o.x - e.x);
      g.damageEnemy?.(o, 6 * this.dmgMul, 30, a, 520, { melee: false, knockdown: true, hitstop: 0.03, shake: 0.2, launch: 90 });
    }
    p.focus = Math.min(300, p.focus + 50 * (g.stats?.focusGain ?? 1));
    g.addOfa?.(10);
    if (hard) {
      e.stagger = 0; e.structure = 0; e.down = 0;
      const dmg = e.maxHp * 0.3 * (g.ageDmg?.() ?? 1);
      g.damageEnemy?.(e, dmg, 0, Math.atan2(sd, cd), 480, { melee: false, knockdown: true, hitstop: 0.1, shake: 0.9, launch: 40 });
      g.texts?.add?.(e.x, e.y - 30, 'LOTUS: -30%', '#d8f2ff', 2, 1.2);
    } else {
      e.stagger = 0; e.down = 0;
      g.score += 250;
      g.killEnemy?.(e, Math.atan2(sd, cd), 960, false, true, true);
      g.texts?.add?.(e.x, e.y - 30, 'LOTUS TERSEMBUNYI!', '#d8f2ff', 2, 1.2);
    }
    p.iframes = Math.max(p.iframes, 2);
  }

  private endLotus(g: G) {
    this.lotus = false; this.lphase = 0;
    g.player.z = 0;
    g.endFatality?.();
  }
}

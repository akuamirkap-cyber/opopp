import { WeatherMode } from '../types/hamster';

class PixelSoundEngine {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private ambientSource: AudioBufferSourceNode | null = null;
  private ambientSubSource: AudioBufferSourceNode | null = null;
  private ambientGain: GainNode | null = null;
  private rainPatterInterval: number | null = null;
  private weatherMode: WeatherMode = 'clear';

  private ensureContext(): AudioContext | null {
    if (!this.enabled) return null;
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public unlock() {
    const ctx = this.ensureContext();
    if (ctx && this.weatherMode !== 'clear' && !this.ambientSource) {
      this.startWeatherNode(this.weatherMode);
    }
  }

  public setEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (!enabled) {
      this.stopWeatherNode();
    } else if (this.weatherMode !== 'clear') {
      this.startWeatherNode(this.weatherMode);
    }
  }

  public setWeatherAmbience(mode: WeatherMode) {
    if (this.weatherMode === mode && (mode === 'clear' || this.ambientSource)) {
      return;
    }
    this.weatherMode = mode;
    this.stopWeatherNode();
    if (mode !== 'clear' && this.enabled) {
      this.startWeatherNode(mode);
    }
  }

  private startWeatherNode(mode: WeatherMode) {
    if (this.ambientSource || mode === 'clear') return;
    const ctx = this.ensureContext();
    if (!ctx) return;

    const sampleRate = ctx.sampleRate;
    const length = sampleRate * 3;

    if (mode === 'rain') {
      // Layer 1: Rich Heavy Rain Downpour (dense pink/brown noise + rapid droplet spikes)
      const mainBuf = ctx.createBuffer(1, length, sampleRate);
      const data = mainBuf.getChannelData(0);
      let b0 = 0;
      let b1 = 0;
      let b2 = 0;
      let b3 = 0;
      for (let i = 0; i < length; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.969 * b2 + white * 0.153852;
        b3 = 0.8665 * b3 + white * 0.3104856;
        // Occasional crisp heavy raindrop transient
        const dropPop = Math.random() < 0.004 ? (Math.random() * 2 - 1) * 0.65 : 0;
        data[i] = (b0 + b1 + b2 + b3 + white * 0.22) * 0.16 + dropPop;
      }

      const src = ctx.createBufferSource();
      src.buffer = mainBuf;
      src.loop = true;

      // Low-pass + bandpass mix for deep soothing heavy rain roar + crisp patter
      const rainFilter = ctx.createBiquadFilter();
      rainFilter.type = 'lowpass';
      rainFilter.frequency.value = 2600;
      rainFilter.Q.value = 0.5;

      const highShelf = ctx.createBiquadFilter();
      highShelf.type = 'highpass';
      highShelf.frequency.value = 180;

      // Layer 2: Deep cozy storm/roof rumble
      const rumbleBuf = ctx.createBuffer(1, length, sampleRate);
      const rData = rumbleBuf.getChannelData(0);
      let lastOut = 0;
      for (let i = 0; i < length; i++) {
        const w = Math.random() * 2 - 1;
        lastOut = (lastOut + 0.02 * w) / 1.02;
        rData[i] = lastOut * 2.4;
      }
      const subSrc = ctx.createBufferSource();
      subSrc.buffer = rumbleBuf;
      subSrc.loop = true;

      const subFilter = ctx.createBiquadFilter();
      subFilter.type = 'lowpass';
      subFilter.frequency.value = 280;

      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.001, ctx.currentTime);
      masterGain.gain.linearRampToValueAtTime(0.22, ctx.currentTime + 0.6);

      const subGain = ctx.createGain();
      subGain.gain.value = 0.45;

      src.connect(highShelf);
      highShelf.connect(rainFilter);
      rainFilter.connect(masterGain);

      subSrc.connect(subFilter);
      subFilter.connect(subGain);
      subGain.connect(masterGain);

      masterGain.connect(ctx.destination);
      src.start();
      subSrc.start();

      this.ambientSource = src;
      this.ambientSubSource = subSrc;
      this.ambientGain = masterGain;

      // Periodic heavy raindrop splashes & soft distant cozy thunder
      if (typeof window !== 'undefined') {
        this.rainPatterInterval = window.setInterval(() => {
          if (!this.enabled || this.weatherMode !== 'rain' || !this.ctx) return;
          if (Math.random() < 0.08) {
            this.playSoftThunder();
          }
        }, 2800);
      }
    } else if (mode === 'snow') {
      // Soft quiet winter breeze hush
      const buf = ctx.createBuffer(1, length, sampleRate);
      const data = buf.getChannelData(0);
      let b0 = 0;
      for (let i = 0; i < length; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.992 * b0 + w * 0.03;
        data[i] = b0 * 0.4;
      }
      const src = ctx.createBufferSource();
      src.buffer = buf;
      src.loop = true;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.value = 540;
      filter.Q.value = 1.4;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.001, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.045, ctx.currentTime + 0.7);

      src.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      src.start();

      this.ambientSource = src;
      this.ambientGain = gain;
    }
  }

  private playSoftThunder() {
    const ctx = this.ctx;
    if (!ctx || !this.enabled) return;
    const now = ctx.currentTime;
    const dur = 1.8;
    const buf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * dur), ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < d.length; i++) {
      const env = Math.sin((i / d.length) * Math.PI);
      last = (last + 0.03 * (Math.random() * 2 - 1)) / 1.03;
      d[i] = last * env * 2.2;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 140;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(now);
  }

  private stopWeatherNode() {
    if (this.rainPatterInterval !== null && typeof window !== 'undefined') {
      window.clearInterval(this.rainPatterInterval);
      this.rainPatterInterval = null;
    }
    if (this.ambientSource && this.ctx && this.ambientGain) {
      try {
        const now = this.ctx.currentTime;
        this.ambientGain.gain.setValueAtTime(this.ambientGain.gain.value, now);
        this.ambientGain.gain.linearRampToValueAtTime(0.0001, now + 0.18);
        const oldSrc = this.ambientSource;
        const oldSub = this.ambientSubSource;
        setTimeout(() => {
          try {
            oldSrc.stop();
            oldSrc.disconnect();
            if (oldSub) {
              oldSub.stop();
              oldSub.disconnect();
            }
          } catch {
            // ignore
          }
        }, 200);
      } catch {
        // ignore
      }
    }
    this.ambientSource = null;
    this.ambientSubSource = null;
    this.ambientGain = null;
  }

  public playSqueak() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(760, now);
    osc.frequency.exponentialRampToValueAtTime(1240, now + 0.06);
    osc.frequency.exponentialRampToValueAtTime(920, now + 0.12);

    gain.gain.setValueAtTime(0.08, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.14);
  }

  public playGiggleChirp() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const freqs = [960, 1320, 1100, 1480];
    freqs.forEach((f, idx) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + idx * 0.05;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(f, t);
      osc.frequency.exponentialRampToValueAtTime(f * 1.15, t + 0.035);
      gain.gain.setValueAtTime(0.045, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.055);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.06);
    });
  }

  public playPlayFightBap() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    // Rapid cute soft paw-baps + playful mini-squeak
    for (let i = 0; i < 2; i++) {
      const t = now + i * 0.065;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(340 + Math.random() * 110, t);
      osc.frequency.exponentialRampToValueAtTime(180, t + 0.045);
      gain.gain.setValueAtTime(0.065, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.055);
    }
    if (Math.random() < 0.45) {
      const sq = ctx.createOscillator();
      const g = ctx.createGain();
      sq.type = 'triangle';
      sq.frequency.setValueAtTime(1050, now + 0.04);
      sq.frequency.exponentialRampToValueAtTime(1420, now + 0.09);
      g.gain.setValueAtTime(0.04, now + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.11);
      sq.connect(g);
      g.connect(ctx.destination);
      sq.start(now + 0.04);
      sq.stop(now + 0.12);
    }
  }

  public playRagdollFling() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(380, now);
    osc.frequency.exponentialRampToValueAtTime(1120, now + 0.14);
    osc.frequency.exponentialRampToValueAtTime(480, now + 0.28);
    gain.gain.setValueAtTime(0.09, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.31);
  }

  public playRagdollBonk() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(220, now);
    osc.frequency.exponentialRampToValueAtTime(520, now + 0.06);
    osc.frequency.exponentialRampToValueAtTime(260, now + 0.14);
    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.16);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.17);
  }

  public playBurrowRustle() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const len = Math.floor(ctx.sampleRate * 0.14);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.value = 1800;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.07, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    src.start(now);
  }

  public playBoingGembrot(level: number) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';

    if (level === 0) {
      osc.frequency.setValueAtTime(640, now);
      osc.frequency.exponentialRampToValueAtTime(340, now + 0.12);
    } else if (level === 1) {
      osc.frequency.setValueAtTime(240, now);
      osc.frequency.exponentialRampToValueAtTime(520, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(360, now + 0.16);
    } else {
      osc.frequency.setValueAtTime(165, now);
      osc.frequency.exponentialRampToValueAtTime(430, now + 0.11);
      osc.frequency.exponentialRampToValueAtTime(270, now + 0.22);
    }

    gain.gain.setValueAtTime(0.11, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.25);
  }

  public playCheekStuff() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(360, now);
    osc.frequency.exponentialRampToValueAtTime(780, now + 0.075);
    gain.gain.setValueAtTime(0.075, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.095);
  }

  public playUnloadStash() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [680, 540, 720, 960];
    notes.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + i * 0.065;
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(f, t);
      gain.gain.setValueAtTime(0.06, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.11);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.12);
    });
  }

  public playSpawnPop() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [587.33, 739.99, 880, 1174.66];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const t = now + i * 0.05;
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.07, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.17);
    });
  }

  /** Ultra-satisfying crispy ASMR-style hamster nibble crunch! */
  public playSatisfyingCrunch(juicy = false) {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    // 1) Crisp tiny noise crunch burst
    const len = Math.floor(ctx.sampleRate * 0.045);
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) {
      const env = Math.pow(1 - i / len, 1.8);
      d[i] = (Math.random() * 2 - 1) * env;
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buf;
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.frequency.value = juicy ? 1900 : 2800 + Math.random() * 600;
    bp.Q.value = 1.6;
    const nGain = ctx.createGain();
    nGain.gain.setValueAtTime(0.085, now);
    nGain.gain.exponentialRampToValueAtTime(0.001, now + 0.045);
    noise.connect(bp);
    bp.connect(nGain);
    nGain.connect(ctx.destination);
    noise.start(now);

    // 2) Cute warm mouth-nom pop tone
    const osc = ctx.createOscillator();
    const oGain = ctx.createGain();
    osc.type = 'sine';
    const f = juicy ? 580 + Math.random() * 140 : 460 + Math.random() * 140;
    osc.frequency.setValueAtTime(f, now);
    osc.frequency.exponentialRampToValueAtTime(f * 0.65, now + 0.038);
    oGain.gain.setValueAtTime(0.045, now);
    oGain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);
    osc.connect(oGain);
    oGain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.042);
  }

  public playNibble() {
    this.playSatisfyingCrunch(false);
  }

  public playDrop() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(580, now);
    osc.frequency.exponentialRampToValueAtTime(380, now + 0.07);

    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.085);
  }

  public playHappyChime() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      const t = now + i * 0.055;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.055, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.15);
    });
  }

  public playSparkle() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [880, 1174.66, 1396.91];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      const t = now + i * 0.045;
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0.045, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.13);
    });
  }

  public playWheelTick() {
    const ctx = this.ensureContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(290, now);
    osc.frequency.exponentialRampToValueAtTime(160, now + 0.025);
    gain.gain.setValueAtTime(0.025, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.03);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.035);
  }
}

export const pixelSound = new PixelSoundEngine();

import { HAMSTER_COATS } from '../data/hamsterCoats';
import {
  AquariumTheme,
  ChubbyLevel,
  FairyLightStyle,
  HamsterEntity,
  HamsterStats,
  MissionEventType,
  PixelParticle,
  SoftPhysicsState,
  TreatItem,
  TreatKind,
  WeatherMode,
} from '../types/hamster';
import { pixelSound } from '../utils/pixelSound';
import {
  FLOOR_BOTTOM_Y,
  FLOOR_TOP_Y,
  getLadderPoint,
  getSlidePoint,
  LOFT_SPEC,
  PROP_POS,
  VIRTUAL_W,
} from './terrariumRenderer';

const EXTRA_NAMES = ['Boba', 'Pudding', 'Berry', 'Matcha', 'Koko', 'Choco', 'Yuzu', 'Kuma', 'Milo', 'Taro'];

export interface SimWorld {
  aquariumId: string;
  aquariumName: string;
  theme: AquariumTheme;
  hamsters: HamsterEntity[];
  selectedHamsterId: number;
  treats: TreatItem[];
  iglooStash: TreatKind[];
  particles: PixelParticle[];
  bowlSeeds: number;
  waterLevel: number;
  cleanliness: number;
  nightMode: boolean;
  weather: WeatherMode;
  fairyLightStyle: FairyLightStyle;
  rainbowSlide: boolean;
  flowerLoft: boolean;
  wheelAngle: number;
  wheelSpeed: number;
  nextId: number;
  globalStatusText: string;
  onMissionEvent?: (eventType: MissionEventType) => void;
}

function createInitialPhysics(): SoftPhysicsState {
  return {
    squashY: 0,
    squashVelY: 0,
    furShearX: 0,
    furShearVelX: 0,
    wobblePhase: Math.random() * Math.PI * 2,
    wobbleAmp: 0,
    wobbleVel: 0,
    squeezeAmount: 0,
    earBounceL: 0,
    earVelL: 0,
    earBounceR: 0,
    earVelR: 0,
    cheekJiggle: 0,
    cheekVel: 0,
    tailWag: 0,
    tailVel: 0,
  };
}

export function createHamsterEntity(
  id: number,
  name: string,
  coatId: string,
  x: number,
  y: number
): HamsterEntity {
  return {
    id,
    name,
    coatId,
    accessory: 'none',
    chubbyLevel: 0,
    storedPouch: [],
    activeSnack: null,
    eatDuration: 2.5,
    stats: {
      hunger: 78,
      happiness: 86,
      energy: 86,
      cleanliness: 94,
      cheekPuff: 0,
      affection: 14,
    },
    x,
    y,
    vx: 0,
    vy: 0,
    facing: Math.random() < 0.5 ? 1 : -1,
    onLoft: false,
    climbProgress: 0,
    slideProgress: 0,
    state: 'idle',
    stateTimer: 1.1 + Math.random() * 1.1,
    animFrame: Math.random() * 10,
    blinkTimer: 1.5 + Math.random() * 2.5,
    isBlinking: false,
    earTwitchTimer: 0,
    targetX: null,
    targetY: null,
    targetAction: 'none',
    targetTreatId: null,
    wheelAngle: 0,
    wheelSpeed: 0,
    wheelPhase: 'none',
    wheelSwing: 0,
    wheelSwingVel: 0,
    wheelOverspinLoops: 0,
    ragdollAngle: 0,
    ragdollSpin: 0,
    ragdollGroundY: FLOOR_TOP_Y + 20,
    ragdollBounces: 0,
    climbLookTimer: 0,
    slideStyle: 0,
    slideSpin: 0,
    heldWiggleTimer: 0,
    lickPawTimer: 0,
    playFightPartnerId: null,
    buriedWiggleTimer: 0,
    squish: 0,
    hopOffset: 0,
    hopVel: 0,
    socialCooldown: 3,
    phys: createInitialPhysics(),
    statusText: `${name} mengendus udara dengan hidung mungilnya~`,
  };
}

export function emitMission(world: SimWorld, evt: MissionEventType) {
  if (world.onMissionEvent) {
    world.onMissionEvent(evt);
  }
}

export function spawnParticle(
  world: SimWorld,
  kind: PixelParticle['kind'],
  x: number,
  y: number,
  color: string,
  vx = 0,
  vy = -12,
  life = 1.1,
  size = 1
) {
  world.particles.push({
    id: world.nextId++,
    kind,
    x,
    y,
    vx,
    vy,
    life,
    maxLife: life,
    color,
    size,
  });
}

export function applySquishImpulse(
  hamster: HamsterEntity,
  squashImpulse: number,
  shearImpulse = 0
) {
  hamster.phys.squashVelY += squashImpulse;
  hamster.phys.furShearVelX += shearImpulse;
  // Pudding wobble excitation!
  hamster.phys.wobbleAmp = clamp(
    hamster.phys.wobbleAmp + Math.abs(squashImpulse) * 0.24 + Math.abs(shearImpulse) * 0.12,
    0,
    3.0
  );
  hamster.phys.earVelL += Math.abs(squashImpulse) * 0.65;
  hamster.phys.earVelR += Math.abs(squashImpulse) * 0.85;
  hamster.phys.cheekVel += Math.abs(squashImpulse) * 0.55;
  hamster.phys.tailVel -= squashImpulse * 0.4;
}

export function triggerHappyHop(
  world: SimWorld,
  hamster: HamsterEntity,
  text?: string
) {
  hamster.state = 'happy_hop';
  hamster.stateTimer = 0.85;
  hamster.hopVel = -52;
  hamster.ragdollAngle = 0;
  applySquishImpulse(hamster, -5.2, 0);
  hamster.phys.earVelL = -6.0;
  hamster.phys.earVelR = -7.2;
  if (text) {
    hamster.statusText = text;
    world.globalStatusText = text;
  }
  spawnParticle(world, 'heart', hamster.x - 5, hamster.y - 25, '#FF6B93', -8, -18, 1.1);
  spawnParticle(world, 'star', hamster.x + 6, hamster.y - 26, '#FFE066', 8, -18, 1.0);
}

export function createInitialWorld(
  aquariumId: string,
  aquariumName: string,
  theme: AquariumTheme,
  starterHamsters: Array<{ name: string; coatId: string }>
): SimWorld {
  const list: HamsterEntity[] = starterHamsters.map((info, idx) =>
    createHamsterEntity(
      idx + 1,
      info.name,
      info.coatId,
      118 + idx * 54,
      160 + (idx % 2 === 0 ? 0 : 4)
    )
  );
  const first = list[0];
  return {
    aquariumId,
    aquariumName,
    theme,
    hamsters: list,
    selectedHamsterId: first.id,
    treats: [],
    iglooStash: [],
    particles: [],
    bowlSeeds: 88,
    waterLevel: 94,
    cleanliness: 94,
    nightMode: false,
    weather: 'clear',
    fairyLightStyle: 'warm-gold',
    rainbowSlide: false,
    flowerLoft: false,
    wheelAngle: 0,
    wheelSpeed: 0,
    nextId: list.length + 1,
    globalStatusText: `${first.name} dan teman-teman siap bermain di ${aquariumName}~`,
  };
}

export function getSelectedHamster(world: SimWorld): HamsterEntity {
  return (
    world.hamsters.find((h) => h.id === world.selectedHamsterId) ||
    world.hamsters[0]
  );
}

export function spawnExtraHamster(world: SimWorld): HamsterEntity | null {
  if (world.hamsters.length >= 5) return null;

  const usedCoats = new Set(world.hamsters.map((h) => h.coatId));
  const availableCoats = HAMSTER_COATS.filter((c) => !usedCoats.has(c.id));
  const coatPool = availableCoats.length > 0 ? availableCoats : HAMSTER_COATS;
  const chosenCoat = coatPool[Math.floor(Math.random() * coatPool.length)];

  const usedNames = new Set(world.hamsters.map((h) => h.name));
  const availableNames = EXTRA_NAMES.filter((n) => !usedNames.has(n));
  const chosenName =
    availableNames.length > 0
      ? availableNames[Math.floor(Math.random() * availableNames.length)]
      : `Mochi ${world.hamsters.length + 1}`;

  const x = 75 + Math.random() * 145;
  const y = FLOOR_TOP_Y + 14 + Math.random() * 20;
  const newHam = createHamsterEntity(
    world.nextId++,
    chosenName,
    chosenCoat.id,
    x,
    y
  );
  newHam.hopOffset = -28;
  newHam.hopVel = 15;
  newHam.state = 'happy_hop';
  newHam.stateTimer = 1.0;
  newHam.statusText = `${chosenName} (${chosenCoat.name}) baru saja bergabung ke ${world.aquariumName}!`;

  world.hamsters.push(newHam);
  world.selectedHamsterId = newHam.id;
  world.globalStatusText = newHam.statusText;

  for (let i = 0; i < 8; i++) {
    spawnParticle(
      world,
      i % 2 === 0 ? 'heart' : 'star',
      x + (Math.random() * 20 - 10),
      y - 18 - Math.random() * 10,
      i % 2 === 0 ? '#FF6B93' : '#FFE066',
      (Math.random() - 0.5) * 28,
      -20 - Math.random() * 12,
      1.2
    );
  }
  pixelSound.playSpawnPop();
  return newHam;
}

export function cycleChubbyMode(
  world: SimWorld,
  hamsterId?: number
): ChubbyLevel {
  const ham =
    (hamsterId !== undefined
      ? world.hamsters.find((h) => h.id === hamsterId)
      : null) || getSelectedHamster(world);

  const nextLevel = (((ham.chubbyLevel + 1) % 3) as ChubbyLevel);
  ham.chubbyLevel = nextLevel;

  applySquishImpulse(ham, nextLevel === 0 ? -5.5 : 9.2, 3.5);
  if (
    nextLevel > 0 &&
    ham.state !== 'run_wheel' &&
    ham.state !== 'buried' &&
    ham.state !== 'hide_house' &&
    ham.state !== 'sleep_house' &&
    ham.state !== 'climb_ladder' &&
    ham.state !== 'slide_down'
  ) {
    ham.hopVel = -22;
  }

  for (let i = 0; i < 6; i++) {
    spawnParticle(
      world,
      i % 2 === 0 ? 'fluff' : 'sparkle',
      ham.x + (Math.random() * 18 - 9),
      ham.y - 10 - Math.random() * 10,
      nextLevel === 2 ? '#FFB5C8' : '#FFF2D6',
      (Math.random() - 0.5) * 32,
      -18 - Math.random() * 10,
      0.7
    );
  }

  if (nextLevel === 1) {
    ham.statusText = `POOF! ${ham.name} jadi GEMUK bulat seperti bakpao puding!`;
  } else if (nextLevel === 2) {
    ham.statusText = `BOING!! ${ham.name} berubah jadi SUPER GEMBROT mochi raksasa!!`;
  } else {
    ham.statusText = `${ham.name} kembali ke ukuran imut normalnya~`;
  }
  world.globalStatusText = ham.statusText;
  pixelSound.playBoingGembrot(nextLevel);
  emitMission(world, 'chubby_boing');
  return nextLevel;
}

/** Squeeze & wiggle hamster like soft mochi pudding! */
export function triggerPuddingSqueeze(world: SimWorld, hamster: HamsterEntity, strokeDx = 0) {
  releaseFromSpecialSpot(hamster);
  hamster.state = 'squeeze';
  hamster.stateTimer = 0.55;
  hamster.phys.squeezeAmount = 1.0;
  applySquishImpulse(hamster, 7.5, clamp(strokeDx * 2.5, -10, 10));
  hamster.phys.wobbleAmp = 2.6;
  hamster.statusText = `Squishy~ ${hamster.name} membal empuk kayak puding mochi!!`;
  world.globalStatusText = hamster.statusText;
  hamster.stats.happiness = Math.min(100, hamster.stats.happiness + 5);
  hamster.stats.affection += 2;
  spawnParticle(world, 'heart', hamster.x, hamster.y - 24, '#FF6B93', 0, -16, 0.9);
  pixelSound.playBoingGembrot(1);
  emitMission(world, 'pet_squeeze');
}

/** Send selected hamster to climb the ladder up to the 2nd floor, or slide down! */
export function triggerLadderOrSlide(world: SimWorld) {
  const sel = getSelectedHamster(world);
  releaseFromSpecialSpot(sel);

  if (sel.onLoft) {
    // Already on 2nd floor -> go straight to the slide top!
    sel.targetTreatId = null;
    sel.targetAction = 'go_slide_down';
    sel.targetX = LOFT_SPEC.slideTop.x - 4;
    sel.targetY = LOFT_SPEC.y;
    sel.state = 'walk';
    sel.stateTimer = 4.5;
    setHamsterStatus(
      world,
      sel,
      `${sel.name} berlari di lantai 2 menuju perosotan!`
    );
  } else {
    // On ground floor -> walk to ladder bottom, climb up, explore loft, and slide down!
    sel.targetTreatId = null;
    sel.targetAction = 'go_ladder_up';
    sel.targetX = LOFT_SPEC.ladderBottom.x;
    sel.targetY = LOFT_SPEC.ladderBottom.y;
    sel.state = 'walk';
    sel.stateTimer = 5.5;
    setHamsterStatus(
      world,
      sel,
      `${sel.name} berlari menuju tangga kayu untuk naik ke lantai 2!`
    );
  }
  pixelSound.playSqueak();
}

export function triggerWheelRagdollDemo(world: SimWorld) {
  const sel = getSelectedHamster(world);
  if (sel.state === 'run_wheel') {
    sel.wheelPhase = 'overspin';
    sel.wheelOverspinLoops = 0;
    sel.stateTimer = 1.6;
    setHamsterStatus(
      world,
      sel,
      `WADUH! Roda ${sel.name} KEBANTERAN! Ikut muter-muter di dalam roda!!`
    );
    pixelSound.playSqueak();
    return;
  }

  if (sel.onLoft) {
    sel.onLoft = false;
    sel.y = FLOOR_TOP_Y + 14;
  }
  releaseFromSpecialSpot(sel);
  sel.targetTreatId = null;
  sel.targetAction = 'wheel';
  sel.targetX = PROP_POS.wheel.x;
  sel.targetY = PROP_POS.wheel.y + PROP_POS.wheel.radius - 3;
  sel.state = 'walk';
  sel.stateTimer = 4.5;
  sel.wheelOverspinLoops = -1;
  setHamsterStatus(
    world,
    sel,
    `${sel.name} lari kencang mau ngebut pol di roda putar!`
  );
  pixelSound.playSqueak();
}

export function triggerPlayFight(world: SimWorld) {
  if (world.hamsters.length < 2) {
    const sel = getSelectedHamster(world);
    setHamsterStatus(world, sel, `Tambah 1 hamster lagi biar ${sel.name} punya teman gelut lucu!`);
    return;
  }
  const a = getSelectedHamster(world);
  const candidates = world.hamsters.filter(
    (h) => h.id !== a.id && h.state !== 'ragdoll'
  );
  const b = candidates[0];
  if (!b) return;

  a.onLoft = false;
  b.onLoft = false;
  releaseFromSpecialSpot(a);
  releaseFromSpecialSpot(b);

  const midX = clamp((a.x + b.x) / 2, 56, VIRTUAL_W - 60);
  const midY = clamp((a.y + b.y) / 2, FLOOR_TOP_Y + 14, FLOOR_BOTTOM_Y - 8);
  a.x = midX - 9;
  b.x = midX + 9;
  a.y = midY;
  b.y = midY;

  startPlayFightPair(world, a, b);
}

function startPlayFightPair(world: SimWorld, a: HamsterEntity, b: HamsterEntity) {
  a.socialCooldown = 11;
  b.socialCooldown = 11;
  a.targetX = null;
  a.targetY = null;
  b.targetX = null;
  b.targetY = null;
  a.targetAction = 'none';
  b.targetAction = 'none';
  a.facing = b.x >= a.x ? 1 : -1;
  b.facing = a.x >= b.x ? 1 : -1;
  a.state = 'play_fight';
  b.state = 'play_fight';
  const dur = 3.0 + Math.random() * 1.2;
  a.stateTimer = dur;
  b.stateTimer = dur;
  a.playFightPartnerId = b.id;
  b.playFightPartnerId = a.id;
  a.hopVel = -24;
  b.hopVel = -24;
  applySquishImpulse(a, -4);
  applySquishImpulse(b, -4);
  pixelSound.playPlayFightBap();
  emitMission(world, 'play_fight');

  const msg = `${a.name} & ${b.name} gelut lucu kayak kucing main tepok-tepokan! Pap pap pap~ (Bercanda kok ♥)`;
  a.statusText = msg;
  b.statusText = msg;
  world.globalStatusText = msg;
}

export function sendToBuryPile(world: SimWorld) {
  const sel = getSelectedHamster(world);
  if (sel.onLoft) {
    sel.onLoft = false;
    sel.y = FLOOR_TOP_Y + 14;
  }
  releaseFromSpecialSpot(sel);
  sel.targetTreatId = null;
  sel.targetAction = 'pile_bury';
  sel.targetX = PROP_POS.pile.x;
  sel.targetY = PROP_POS.pile.y - 2;
  sel.state = 'walk';
  sel.stateTimer = 5.0;
  setHamsterStatus(
    world,
    sel,
    `${sel.name} berlari mau mengubur diri di tumpukan sekam empuk!`
  );
  pixelSound.playSqueak();
}

export function sendToHouse(world: SimWorld, shouldSleep: boolean) {
  const sel = getSelectedHamster(world);
  if (sel.onLoft) {
    sel.onLoft = false;
    sel.y = FLOOR_TOP_Y + 14;
  }
  releaseFromSpecialSpot(sel);
  sel.targetTreatId = null;
  sel.targetAction = shouldSleep ? 'igloo_sleep' : 'igloo_hide';
  sel.targetX = PROP_POS.igloo.x;
  sel.targetY = PROP_POS.igloo.y + 7;
  sel.state = 'walk';
  sel.stateTimer = 5.5;
  setHamsterStatus(
    world,
    sel,
    shouldSleep
      ? `${sel.name} masuk ke dalam rumah hamster untuk tidur nyenyak~`
      : `${sel.name} menyelinap masuk untuk sembunyi di rumah hamster!`
  );
  pixelSound.playSqueak();
}

export function releaseFromSpecialSpot(h: HamsterEntity) {
  if (h.state === 'run_wheel') {
    h.wheelPhase = 'none';
    h.y = FLOOR_TOP_Y + 14;
  } else if (h.state === 'hide_house' || h.state === 'sleep_house') {
    h.y = PROP_POS.igloo.y + 9;
  } else if (h.state === 'buried') {
    h.hopVel = -36;
    h.y = PROP_POS.pile.y + 2;
  } else if (h.state === 'climb_ladder' || h.state === 'slide_down' || h.state === 'wall_climb') {
    h.onLoft = false;
    h.y = FLOOR_TOP_Y + 16;
  }
  h.ragdollAngle = 0;
  h.playFightPartnerId = null;
}

/** Pick up & hold a hamster in your hand like a soft squishy mochi! */
export function pickUpHamster(
  world: SimWorld,
  hamster: HamsterEntity,
  px: number,
  py: number
) {
  const wasHeld = hamster.state === 'held';
  hamster.onLoft = false;
  releaseFromSpecialSpot(hamster);
  hamster.state = 'held';
  hamster.stateTimer = 9999;
  hamster.targetX = null;
  hamster.targetY = null;
  hamster.targetAction = 'none';
  hamster.targetTreatId = null;
  hamster.x = px;
  hamster.y = py;
  hamster.hopOffset = 0;
  hamster.hopVel = 0;
  hamster.ragdollAngle = 0;
  hamster.facing = 1;
  if (!wasHeld) {
    hamster.heldWiggleTimer = 0;
    hamster.lickPawTimer = 0.65 + Math.random() * 0.5;
    hamster.phys.squeezeAmount = 0.85;
    applySquishImpulse(hamster, 6.2, 3);
    hamster.statusText = `Gemeshh! ${hamster.name} diangkat ke genggaman tanganmu, pipinya tembem menggantung~`;
    world.globalStatusText = hamster.statusText;
    hamster.stats.happiness = Math.min(100, hamster.stats.happiness + 6);
    hamster.stats.affection += 3;
    emitMission(world, 'lift_hamster');
    spawnParticle(world, 'heart', hamster.x, hamster.y - 24, '#FF6B93', 0, -16, 1.0);
    pixelSound.playSqueak();
  }
}

/** Release held hamster with a cute little downward plop! */
export function dropHeldHamster(world: SimWorld, hamster: HamsterEntity) {
  if (hamster.state !== 'held') return;
  hamster.phys.squeezeAmount = 0;
  hamster.ragdollAngle = 0;
  hamster.x = clamp(hamster.x, 34, VIRTUAL_W - 36);
  hamster.y = clamp(hamster.y, FLOOR_TOP_Y + 8, FLOOR_BOTTOM_Y - 6);
  hamster.state = 'ragdoll';
  hamster.stateTimer = 1.5;
  hamster.ragdollGroundY = clamp(hamster.y + 14, FLOOR_TOP_Y + 12, FLOOR_BOTTOM_Y - 6);
  hamster.ragdollBounces = 2;
  hamster.vx = 0;
  hamster.vy = 35;
  hamster.ragdollSpin = 0;
  applySquishImpulse(hamster, 7.5);
  hamster.statusText = `Plop! ${hamster.name} diturunkan kembali ke sekam empuk~`;
  world.globalStatusText = hamster.statusText;
  pixelSound.playBoingGembrot(0);
}

/** Send hamster to press its paws on the front glass & look right at YOU, or climb the side wall! */
export function triggerGlassPeekOrWallClimb(world: SimWorld) {
  const sel = getSelectedHamster(world);
  if (sel.onLoft) {
    sel.onLoft = false;
    sel.y = FLOOR_TOP_Y + 14;
  }
  releaseFromSpecialSpot(sel);
  sel.targetX = null;
  sel.targetY = null;
  sel.targetAction = 'none';
  sel.targetTreatId = null;

  if (Math.random() < 0.62) {
    // Press cute face & paws onto front glass!
    sel.x = clamp(sel.x, 60, VIRTUAL_W - 60);
    sel.y = FLOOR_BOTTOM_Y - 5;
    sel.state = 'glass_peek';
    sel.stateTimer = 4.0 + Math.random() * 1.5;
    sel.facing = 1;
    applySquishImpulse(sel, 4.5);
    emitMission(world, 'glass_peek');
    setHamsterStatus(
      world,
      sel,
      `${sel.name} menempel di kaca depan dan melambai padamu! Halo!! 👋`
    );
  } else {
    // Silly wall climbing attempt!
    const goLeft = Math.random() < 0.5;
    sel.x = goLeft ? 26 : VIRTUAL_W - 26;
    sel.y = FLOOR_TOP_Y + 10;
    sel.state = 'wall_climb';
    sel.climbProgress = 0;
    sel.facing = goLeft ? -1 : 1;
    sel.stateTimer = 5.5;
    applySquishImpulse(sel, -3.5);
    setHamsterStatus(
      world,
      sel,
      `EH?! ${sel.name} tiba-tiba mencoba memanjat dinding kaca! Kok bisa?!`
    );
  }
  pixelSound.playSqueak();
}

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

function stepSpring(
  val: number,
  vel: number,
  target: number,
  stiffness: number,
  damping: number,
  dt: number
): [number, number] {
  const force = (target - val) * stiffness - vel * damping;
  const nextVel = vel + force * dt;
  const nextVal = val + nextVel * dt;
  return [nextVal, nextVel];
}

function updateSoftPhysics(hamster: HamsterEntity, dt: number, timeSec: number) {
  const p = hamster.phys;

  let targetSquash = 0;
  let targetShear = 0;
  let targetEarL = 0;
  let targetEarR = 0;
  let targetCheek = 0;
  let targetTail = 0;

  const weightDamp = hamster.chubbyLevel === 2 ? 0.8 : 1;

  // Decay pudding wobble & squeeze gently
  p.wobblePhase += dt * (16 + hamster.chubbyLevel * 2);
  p.wobbleAmp *= Math.pow(0.14, dt);
  if (hamster.state !== 'squeeze') {
    p.squeezeAmount *= Math.pow(0.05, dt);
  }

  if (hamster.state === 'held') {
    targetSquash = 0.85 + Math.sin(timeSec * 6) * 0.15;
    targetEarL = 0.9;
    targetEarR = 0.9;
    targetCheek = 0.7;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.65);
  } else if (hamster.state === 'glass_peek') {
    targetSquash = 0.6;
    targetEarL = 0.4;
    targetEarR = 0.4;
    targetCheek = 0.5;
  } else if (hamster.state === 'wall_climb') {
    targetSquash = Math.sin(timeSec * 18) * 0.3;
    targetShear = hamster.facing * 0.8;
    targetEarL = Math.sin(timeSec * 18) * 0.8;
    targetEarR = -Math.sin(timeSec * 18) * 0.8;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.5);
  } else if (hamster.state === 'squeeze') {
    targetSquash = 1.15 + Math.sin(timeSec * 18) * 0.16;
    targetEarL = 1.2;
    targetEarR = 1.2;
    targetCheek = 1.1;
  } else if (hamster.state === 'petted') {
    targetSquash = 0.72 + Math.sin(timeSec * 14) * 0.12;
    targetEarL = 0.9;
    targetEarR = 0.9;
    targetCheek = 0.65;
  } else if (hamster.state === 'sleep' || hamster.state === 'sleep_house') {
    targetSquash = 0.45 + Math.sin(timeSec * 2.8 + hamster.id) * 0.14;
    targetEarL = 0.6;
    targetEarR = 0.6;
  } else if (hamster.state === 'stretch') {
    targetSquash = 0.55;
    targetShear = hamster.facing * 1.4;
    targetEarL = 0.8;
    targetEarR = 0.8;
  } else if (hamster.state === 'shake') {
    targetShear = Math.sin(timeSec * 46) * 2.2;
    targetSquash = -0.18;
    targetEarL = Math.sin(timeSec * 46) * 1.2;
    targetEarR = -Math.sin(timeSec * 46) * 1.2;
    targetCheek = 0.7;
  } else if (hamster.state === 'play_fight') {
    targetSquash = Math.sin(timeSec * 20 + hamster.id) * 0.25;
    targetShear = hamster.facing * 0.9;
    targetEarL = Math.sin(timeSec * 22) * 0.8;
    targetEarR = -Math.sin(timeSec * 22) * 0.8;
    targetTail = Math.sin(timeSec * 24) * 1.2;
  } else if (hamster.state === 'slide_down') {
    targetSquash = -0.22;
    targetShear = -1.2;
    targetEarL = -1.1;
    targetEarR = -1.1;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.85);
  } else if (hamster.state === 'climb_ladder') {
    targetSquash = Math.sin(timeSec * 14) * 0.2;
    targetEarL = Math.sin(timeSec * 14) * 0.5;
    targetEarR = -Math.sin(timeSec * 14) * 0.5;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.55);
  } else if (hamster.state === 'ragdoll') {
    targetSquash = Math.sin(timeSec * 18) * 0.28;
    targetEarL = -1.0;
    targetEarR = -1.0;
  } else if (hamster.state === 'eat' || hamster.state === 'stuff_cheek') {
    targetCheek = 0.75 + Math.sin(timeSec * 24) * 0.55;
    targetSquash = Math.sin(timeSec * 16) * 0.18;
    targetEarL = Math.sin(timeSec * 16) * 0.35;
    targetEarR = -Math.sin(timeSec * 16) * 0.35;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.4);
  } else if (hamster.state === 'unload_stash') {
    targetCheek = Math.sin(timeSec * 24) * 0.65;
    targetSquash = 0.3 + Math.sin(timeSec * 16) * 0.2;
  } else if (hamster.state === 'run_wheel') {
    const speedNorm = clamp(Math.abs(hamster.wheelSpeed) / 12, 0, 1);
    targetShear = -hamster.facing * (0.8 + speedNorm * 1.1);
    targetEarL = 0.6 + Math.sin(timeSec * 26) * 0.45;
    targetEarR = 0.7 + Math.cos(timeSec * 26) * 0.45;
    targetTail = Math.sin(timeSec * 22) * 1.0;
    targetCheek = Math.sin(timeSec * 18) * 0.25;
  } else if (hamster.state === 'walk') {
    targetShear = -hamster.facing * 0.6;
    targetEarL = Math.sin(timeSec * 16) * 0.4;
    targetEarR = -Math.sin(timeSec * 16) * 0.4;
    targetTail = Math.sin(timeSec * 16) * 0.7;
    // Gentle chubby pudding jiggle on every step!
    p.wobbleAmp = Math.max(p.wobbleAmp, hamster.chubbyLevel > 0 ? 0.75 : 0.45);
  } else if (hamster.state === 'happy_hop') {
    targetSquash = hamster.hopOffset < -3 ? -0.45 : 0.35;
    targetEarL = hamster.hopOffset < -3 ? -1.1 : 0.5;
    targetEarR = hamster.hopOffset < -3 ? -1.2 : 0.6;
  } else {
    // Subtle pudding breathing idle jiggle
    targetSquash = Math.sin(timeSec * 3.1 + hamster.id) * 0.1;
    targetTail = Math.sin(timeSec * 2.4 + hamster.id) * 0.2;
    p.wobbleAmp = Math.max(p.wobbleAmp, 0.18);
  }

  const stiff = 165 * weightDamp;
  [p.squashY, p.squashVelY] = stepSpring(p.squashY, p.squashVelY, targetSquash, stiff, 9.5, dt);
  [p.furShearX, p.furShearVelX] = stepSpring(p.furShearX, p.furShearVelX, targetShear, 190, 13, dt);
  [p.earBounceL, p.earVelL] = stepSpring(p.earBounceL, p.earVelL, targetEarL, 210, 12, dt);
  [p.earBounceR, p.earVelR] = stepSpring(p.earBounceR, p.earVelR, targetEarR, 195, 11.5, dt);
  [p.cheekJiggle, p.cheekVel] = stepSpring(p.cheekJiggle, p.cheekVel, targetCheek, 175, 10, dt);
  [p.tailWag, p.tailVel] = stepSpring(p.tailWag, p.tailVel, targetTail, 220, 12, dt);
}

function getWheelTargetPos() {
  return {
    x: PROP_POS.wheel.x,
    y: PROP_POS.wheel.y + PROP_POS.wheel.radius - 3,
  };
}

function getIglooStashTarget() {
  return {
    x: PROP_POS.igloo.x + 25,
    y: PROP_POS.igloo.y + 7,
  };
}

function isWheelOccupied(world: SimWorld, excludeId: number): boolean {
  return world.hamsters.some(
    (h) => h.id !== excludeId && h.state === 'run_wheel'
  );
}

function isHouseOccupied(world: SimWorld, excludeId: number): boolean {
  return world.hamsters.some(
    (h) =>
      h.id !== excludeId &&
      (h.state === 'hide_house' || h.state === 'sleep_house')
  );
}

function isPileOccupied(world: SimWorld, excludeId: number): boolean {
  return world.hamsters.some(
    (h) => h.id !== excludeId && h.state === 'buried'
  );
}

function setHamsterStatus(world: SimWorld, hamster: HamsterEntity, text: string) {
  hamster.statusText = text;
  if (hamster.id === world.selectedHamsterId) {
    world.globalStatusText = text;
  }
}

function pickNextBehavior(world: SimWorld, hamster: HamsterEntity) {
  const { stats } = hamster;

  // If hamster is currently on the 2nd Floor Loft -> explore loft, rest on mat, or slide down!
  if (hamster.onLoft) {
    const r = Math.random();
    if (r < 0.42) {
      // Slide down to 1st floor!
      hamster.targetAction = 'go_slide_down';
      hamster.targetX = LOFT_SPEC.slideTop.x - 4;
      hamster.targetY = LOFT_SPEC.y;
      hamster.state = 'walk';
      hamster.stateTimer = 4.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} menuju perosotan untuk meluncur turun dari lantai 2!`
      );
      return;
    } else if (r < 0.65) {
      hamster.targetAction = 'loft_nap';
      hamster.targetX = LOFT_SPEC.loftMat.x;
      hamster.targetY = LOFT_SPEC.y;
      hamster.state = 'walk';
      hamster.stateTimer = 3.5;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} jalan-jalan di lantai 2 menuju bantal awan atas~`
      );
      return;
    } else {
      hamster.targetAction = 'none';
      hamster.targetX = LOFT_SPEC.minX + 10 + Math.random() * (LOFT_SPEC.maxX - LOFT_SPEC.minX - 24);
      hamster.targetY = LOFT_SPEC.y;
      hamster.state = 'walk';
      hamster.stateTimer = 3.5;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} jalan-jalan santai menikmati pemandangan dari lantai atas~`
      );
      return;
    }
  }

  // Priority 0: Unload cheek pouch stash at Igloo
  const hasLooseTreats = world.treats.some((t) => t.landed);
  if (hamster.storedPouch.length > 0 && !hasLooseTreats) {
    const stashSpot = getIglooStashTarget();
    hamster.targetAction = 'stash_unload';
    hamster.targetX = stashSpot.x;
    hamster.targetY = stashSpot.y;
    hamster.state = 'walk';
    hamster.stateTimer = 5.5;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} membawa pipi penuh simpanan menuju rumah hamster untuk ditimbun!`
    );
    return;
  }

  // Priority 1: Sleepy
  if (stats.energy < 24) {
    const useHouse = !isHouseOccupied(world, hamster.id) && Math.random() < 0.65;
    if (useHouse) {
      hamster.targetAction = 'igloo_sleep';
      hamster.targetX = PROP_POS.igloo.x;
      hamster.targetY = PROP_POS.igloo.y + 7;
    } else {
      hamster.targetAction = 'cushion';
      hamster.targetX = PROP_POS.cushion.x;
      hamster.targetY = PROP_POS.cushion.y + 1;
    }
    hamster.state = 'walk';
    hamster.stateTimer = 4.8;
    setHamsterStatus(
      world,
      hamster,
      useHouse
        ? `${hamster.name} mengantuk dan masuk ke rumah hamster untuk tidur~`
        : `${hamster.name} mulai mengantuk dan mencari bantal empuk...`
    );
    return;
  }

  // Priority 2: Hungry
  if (stats.hunger < 60) {
    if (world.iglooStash.length > 0 && Math.random() < 0.6) {
      const stashSpot = getIglooStashTarget();
      hamster.targetAction = 'stash_eat';
      hamster.targetX = stashSpot.x;
      hamster.targetY = stashSpot.y;
      hamster.state = 'walk';
      hamster.stateTimer = 5.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} lapar dan pergi mengintip simpanan makanan di rumah!`
      );
      return;
    }
    if (world.bowlSeeds > 0) {
      hamster.targetAction = 'bowl';
      hamster.targetX = PROP_POS.bowl.x - 12;
      hamster.targetY = PROP_POS.bowl.y + 4;
      hamster.state = 'walk';
      hamster.stateTimer = 5.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} berlari menuju mangkuk kuaci!`
      );
      return;
    }
  }

  const roll = Math.random();

  if (roll < 0.08) {
    // Occasionally walk to the front glass & interact with YOU, or try silly wall climbing!
    if (Math.random() < 0.65) {
      hamster.targetAction = 'none';
      hamster.targetX = 50 + Math.random() * 160;
      hamster.targetY = FLOOR_BOTTOM_Y - 5;
      hamster.state = 'walk';
      hamster.stateTimer = 4.0;
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} berjalan mendekati kaca depan untuk menyapamu!`
      );
      // Arrive -> glass peek
      setTimeout(() => {
        if (hamster.state !== 'walk' || hamster.onLoft) return;
        hamster.state = 'glass_peek';
        hamster.stateTimer = 4.0;
        hamster.targetX = null;
        hamster.targetY = null;
        emitMission(world, 'glass_peek');
        spawnParticle(world, 'heart', hamster.x, hamster.y - 24, '#FF6B93', 0, -14, 1.0);
      }, 1600);
    } else {
      hamster.state = 'wall_climb';
      hamster.x = Math.random() < 0.5 ? 24 : VIRTUAL_W - 24;
      hamster.y = FLOOR_TOP_Y + 10;
      hamster.facing = hamster.x < 100 ? -1 : 1;
      hamster.climbProgress = 0;
      hamster.stateTimer = 5.5;
      setHamsterStatus(
        world,
        hamster,
        `Aneh tapi gemas! ${hamster.name} tiba-tiba ingin memanjat tembok kaca!`
      );
    }
  } else if (roll < 0.28) {
    // Climb ladder up to 2nd floor loft!
    hamster.targetAction = 'go_ladder_up';
    hamster.targetX = LOFT_SPEC.ladderBottom.x;
    hamster.targetY = LOFT_SPEC.ladderBottom.y;
    hamster.state = 'walk';
    hamster.stateTimer = 5.5;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} penasaran ingin memanjat tangga lucu ke lantai 2!`
    );
  } else if (roll < 0.38 && stats.energy > 28 && !isWheelOccupied(world, hamster.id)) {
    const wt = getWheelTargetPos();
    hamster.targetAction = 'wheel';
    hamster.targetX = wt.x;
    hamster.targetY = wt.y;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} bersemangat menuju roda putar!`
    );
  } else if (roll < 0.5 && !isPileOccupied(world, hamster.id)) {
    hamster.targetAction = 'pile_bury';
    hamster.targetX = PROP_POS.pile.x;
    hamster.targetY = PROP_POS.pile.y - 2;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} menuju tumpukan sekam untuk menggali & mengubur diri!`
    );
  } else if (roll < 0.6 && !isHouseOccupied(world, hamster.id)) {
    const sleepInside = world.nightMode || world.weather === 'rain' || Math.random() < 0.45;
    hamster.targetAction = sleepInside ? 'igloo_sleep' : 'igloo_hide';
    hamster.targetX = PROP_POS.igloo.x;
    hamster.targetY = PROP_POS.igloo.y + 7;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      sleepInside
        ? `${hamster.name} mau masuk tidur di dalam rumah hamsternya~`
        : `${hamster.name} menyelinap sembunyi di dalam rumah hamster!`
    );
  } else if (roll < 0.7) {
    hamster.state = 'groom';
    hamster.stateTimer = 2.6 + Math.random() * 1.4;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} mencuci muka dengan kaki mungilnya~`
    );
  } else if (roll < 0.78) {
    hamster.state = 'dig';
    hamster.stateTimer = 2.2 + Math.random() * 1.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} asyik menggali serbuk kayu yang empuk!`
    );
  } else if (roll < 0.85) {
    hamster.state = 'stand';
    hamster.stateTimer = 2.0 + Math.random() * 1.2;
    applySquishImpulse(hamster, -3.5);
    const msg =
      world.weather === 'rain'
        ? `${hamster.name} berdiri imut dengar suara hujan deras di luar jendela~`
        : world.weather === 'snow'
        ? `${hamster.name} berdiri takjub melihat salju turun di luar jendela~`
        : `${hamster.name} berdiri mengintip dengan telinga tegak!`;
    setHamsterStatus(world, hamster, msg);
    spawnParticle(world, 'question', hamster.x, hamster.y - 28, '#6C8CE8', 0, -6, 1.0);
  } else if (roll < 0.92 && world.waterLevel > 10) {
    hamster.targetAction = 'bottle';
    hamster.targetX = PROP_POS.bottle.spoutX - 9;
    hamster.targetY = FLOOR_TOP_Y + 12;
    hamster.state = 'walk';
    hamster.stateTimer = 5.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} berjalan ke botol minum besarnya~`
    );
  } else {
    hamster.targetAction = 'none';
    hamster.targetX = 48 + Math.random() * 200;
    hamster.targetY = FLOOR_TOP_Y + 8 + Math.random() * (FLOOR_BOTTOM_Y - FLOOR_TOP_Y - 14);
    hamster.state = 'walk';
    hamster.stateTimer = 4.0;
    setHamsterStatus(
      world,
      hamster,
      `${hamster.name} berjalan gembul keliling aquarium~`
    );
  }
}

export function stepSimulation(world: SimWorld, dt: number, timeSec: number) {
  const { treats } = world;

  world.cleanliness = clamp(world.cleanliness - dt * 0.2, 0, 100);

  // 1) Update falling treats (can land on 2nd floor loft OR ground floor!)
  for (const t of treats) {
    if (!t.landed) {
      t.vy += 260 * dt;
      t.y += t.vy * dt;
      // Check if treat was dropped above the 2nd floor loft!
      if (t.x >= LOFT_SPEC.minX + 6 && t.x <= LOFT_SPEC.maxX - 6 && t.y <= LOFT_SPEC.y + 4) {
        if (t.y >= LOFT_SPEC.y - 1 && t.vy > 0) {
          t.y = LOFT_SPEC.y - 1;
          t.landed = true;
          t.onLoft = true;
          t.vy = 0;
          spawnParticle(world, 'sparkle', t.x, t.y - 2, '#FFE066', 0, -14, 0.45);
        }
      } else {
        const landY = clamp(t.y, FLOOR_TOP_Y + 10, FLOOR_BOTTOM_Y - 8);
        if (t.y >= landY && t.vy > 0 && t.y > FLOOR_TOP_Y + 14) {
          t.y = clamp(t.y, FLOOR_TOP_Y + 14, FLOOR_BOTTOM_Y - 8);
          t.landed = true;
          t.onLoft = false;
          t.vy = 0;
          spawnParticle(world, 'shaving', t.x - 2, t.y, '#FFF1DC', -14, -20, 0.35, 1);
          spawnParticle(world, 'shaving', t.x + 2, t.y, '#E7C8A1', 14, -20, 0.35, 1);
        }
      }
    }
  }

  // 2) Wheel coasting when nobody is running on it
  const runner = world.hamsters.find((h) => h.state === 'run_wheel');
  if (!runner) {
    world.wheelSpeed *= Math.pow(0.28, dt);
    world.wheelAngle += world.wheelSpeed * dt;
  }

  // 3) Step each hamster
  for (const hamster of world.hamsters) {
    stepSingleHamster(world, hamster, dt, timeSec);
  }

  // 4) Ragdoll collision against OTHER hamsters!!
  for (const flyer of world.hamsters) {
    if (flyer.state !== 'ragdoll') continue;
    for (const other of world.hamsters) {
      if (other.id === flyer.id) continue;
      if (
        other.state === 'ragdoll' ||
        other.state === 'hide_house' ||
        other.state === 'sleep_house' ||
        other.state === 'held' ||
        other.onLoft
      ) {
        continue;
      }
      const dist = Math.hypot(flyer.x - other.x, flyer.y - other.y);
      if (dist < 22) {
        const pushDir: 1 | -1 = other.x >= flyer.x ? 1 : -1;
        other.wheelPhase = 'none';
        other.state = 'ragdoll';
        other.stateTimer = 1.6;
        other.ragdollGroundY = clamp(other.y, FLOOR_TOP_Y + 10, FLOOR_BOTTOM_Y - 8);
        other.ragdollBounces = 0;
        other.vx = pushDir * (75 + Math.random() * 35);
        other.vy = -85;
        other.ragdollSpin = pushDir * 12;
        other.ragdollAngle = 0;
        applySquishImpulse(other, 8.5, pushDir * 10);

        flyer.vx *= -0.45;
        flyer.vy = Math.min(flyer.vy, -45);

        const cx = (flyer.x + other.x) / 2;
        const cy = (flyer.y + other.y) / 2 - 12;
        spawnParticle(world, 'bap', cx, cy, '#FF8FB1', 0, -12, 0.55);
        spawnParticle(world, 'star', cx - 6, cy - 4, '#FFE066', -22, -26, 0.8);
        spawnParticle(world, 'star', cx + 6, cy - 4, '#FFE066', 22, -26, 0.8);
        spawnParticle(world, 'exclaim', other.x, other.y - 26, '#FF5C8A', 0, -10, 0.8);

        pixelSound.playRagdollBonk();
        const msg = `BOING!! ${flyer.name} terlempar dari roda & NABRAK ${other.name} sampai ikut terpental lucu!!`;
        flyer.statusText = msg;
        other.statusText = msg;
        world.globalStatusText = msg;
      }
    }
  }

  // 5) Cute Play-Fighting or friendly nose-boop when two hamsters meet on same level!
  for (let i = 0; i < world.hamsters.length; i++) {
    for (let j = i + 1; j < world.hamsters.length; j++) {
      const a = world.hamsters[i];
      const b = world.hamsters[j];
      if (a.onLoft !== b.onLoft) continue;
      if (a.socialCooldown > 0 || b.socialCooldown > 0) continue;
      if (
        (a.state === 'idle' || a.state === 'walk') &&
        (b.state === 'idle' || b.state === 'walk')
      ) {
        const dist = Math.hypot(a.x - b.x, a.y - b.y);
        if (dist < 24) {
          if (Math.random() < 0.7 && !a.onLoft) {
            startPlayFightPair(world, a, b);
          } else {
            a.socialCooldown = 10;
            b.socialCooldown = 10;
            a.facing = b.x >= a.x ? 1 : -1;
            b.facing = a.x >= b.x ? 1 : -1;
            a.state = 'stand';
            b.state = 'stand';
            a.stateTimer = 1.4;
            b.stateTimer = 1.4;
            applySquishImpulse(a, -3);
            applySquishImpulse(b, -3);
            spawnParticle(world, 'heart', (a.x + b.x) / 2, Math.min(a.y, b.y) - 24, '#FF6B93', 0, -16, 1.2);
            pixelSound.playGiggleChirp();
            world.globalStatusText = `${a.name} dan ${b.name} saling menyapa sambil mengendus hidung!`;
          }
        }
      }
    }
  }

  // 6) Update particles
  for (let i = world.particles.length - 1; i >= 0; i--) {
    const p = world.particles[i];
    p.life -= dt;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    if (p.kind === 'shaving' || p.kind === 'crumb' || p.kind === 'droplet' || p.kind === 'fluff') {
      p.vy += 80 * dt;
    }
    if (p.life <= 0) {
      world.particles.splice(i, 1);
    }
  }
}

function stepSingleHamster(
  world: SimWorld,
  hamster: HamsterEntity,
  dt: number,
  timeSec: number
) {
  const { stats } = hamster;
  const { treats } = world;

  hamster.socialCooldown = Math.max(0, hamster.socialCooldown - dt);
  stats.hunger = clamp(stats.hunger - dt * 0.4, 0, 100);
  stats.cleanliness = world.cleanliness;

  if (hamster.state === 'sleep' || hamster.state === 'sleep_house') {
    stats.energy = clamp(stats.energy + dt * 4.0, 0, 100);
  } else if (hamster.state === 'run_wheel') {
    stats.energy = clamp(stats.energy - dt * 1.6, 0, 100);
    stats.happiness = clamp(stats.happiness + dt * 1.6, 0, 100);
  } else if (hamster.state === 'play_fight') {
    stats.happiness = clamp(stats.happiness + dt * 2.2, 0, 100);
    stats.energy = clamp(stats.energy - dt * 0.7, 0, 100);
  } else {
    stats.energy = clamp(stats.energy - dt * 0.3, 0, 100);
    stats.happiness = clamp(stats.happiness - dt * 0.18, 0, 100);
  }

  const desiredPuff = Math.min(4, hamster.storedPouch.length * 1.15);
  if (hamster.state !== 'eat' && hamster.state !== 'stuff_cheek' && hamster.state !== 'unload_stash') {
    stats.cheekPuff += (desiredPuff - stats.cheekPuff) * Math.min(1, dt * 4);
  }

  hamster.squish = Math.max(0, hamster.squish - dt * 2.5);

  // Check for unclaimed landed treats on same floor!
  if (
    treats.length > 0 &&
    hamster.state !== 'eat' &&
    hamster.state !== 'stuff_cheek' &&
    hamster.state !== 'unload_stash' &&
    hamster.state !== 'petted' &&
    hamster.state !== 'squeeze' &&
    hamster.state !== 'ragdoll' &&
    hamster.state !== 'play_fight' &&
    hamster.state !== 'held' &&
    hamster.state !== 'glass_peek' &&
    hamster.state !== 'wall_climb' &&
    hamster.state !== 'climb_ladder' &&
    hamster.state !== 'slide_down' &&
    hamster.targetTreatId === null &&
    hamster.storedPouch.length < 4
  ) {
    const claimedIds = new Set(
      world.hamsters
        .map((h) => h.targetTreatId)
        .filter((id): id is number => id !== null)
    );
    const sameLevelTreats = treats.filter(
      (t) => t.landed && Boolean(t.onLoft) === hamster.onLoft && !claimedIds.has(t.id)
    );
    const target = sameLevelTreats[0];
    if (target) {
      releaseFromSpecialSpot(hamster);
      hamster.targetTreatId = target.id;
      hamster.targetAction = 'none';
      hamster.targetX = target.x + (hamster.x < target.x ? -9 : 9);
      hamster.targetY = hamster.onLoft ? LOFT_SPEC.y : target.y + 1;
      hamster.state = 'walk';
      hamster.stateTimer = 6.0;
      applySquishImpulse(hamster, -4.0);
      setHamsterStatus(
        world,
        hamster,
        `${hamster.name} mencium camilan enak dan langsung berlari!`
      );
      spawnParticle(world, 'exclaim', hamster.x, hamster.y - 27, '#FF5C8A', 0, -8, 0.8);
      pixelSound.playSqueak();
    }
  }

  hamster.blinkTimer -= dt;
  if (hamster.blinkTimer <= 0) {
    if (!hamster.isBlinking) {
      hamster.isBlinking = true;
      hamster.blinkTimer = 0.14;
    } else {
      hamster.isBlinking = false;
      hamster.blinkTimer = 2.0 + Math.random() * 3.2;
    }
  }

  hamster.earTwitchTimer = Math.max(0, hamster.earTwitchTimer - dt);
  if (Math.random() < dt * 0.45) {
    hamster.earTwitchTimer = 0.45;
    hamster.phys.earVelL -= 3.5;
  }

  if (hamster.state !== 'ragdoll' && (hamster.hopOffset < 0 || hamster.hopVel < 0)) {
    hamster.hopVel += 185 * dt;
    hamster.hopOffset += hamster.hopVel * dt;
    if (hamster.hopOffset >= 0) {
      hamster.hopOffset = 0;
      if (hamster.hopVel > 25) {
        applySquishImpulse(hamster, 7.2);
      }
      hamster.hopVel = 0;
    }
  }

  hamster.stateTimer -= dt;
  const animSpeed =
    hamster.state === 'run_wheel'
      ? hamster.wheelPhase === 'overspin'
        ? 34
        : hamster.wheelPhase === 'turbo'
        ? 28
        : hamster.wheelPhase === 'coast'
        ? 6
        : 20
      : hamster.state === 'play_fight'
      ? 16
      : hamster.state === 'climb_ladder'
      ? 13
      : hamster.state === 'dig' ||
        hamster.state === 'eat' ||
        hamster.state === 'stuff_cheek' ||
        hamster.state === 'unload_stash'
      ? 12
      : hamster.state === 'walk'
      ? 10
      : 4;
  hamster.animFrame += dt * animSpeed;

  switch (hamster.state) {
    case 'idle': {
      hamster.hopOffset = 0;
      hamster.ragdollAngle = 0;
      if (hamster.stateTimer <= 0) {
        pickNextBehavior(world, hamster);
      }
      break;
    }

    case 'stand': {
      hamster.hopOffset = 0;
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'walk': {
      if (hamster.targetX !== null && hamster.targetY !== null) {
        const dx = hamster.targetX - hamster.x;
        const dy = hamster.targetY - hamster.y;
        const dist = Math.hypot(dx, dy);
        const chubbyFactor = hamster.chubbyLevel === 2 ? 0.82 : 1;
        const speed = (hamster.targetTreatId !== null ? 68 : 44) * chubbyFactor;

        if (dist <= 2.8 || hamster.stateTimer <= 0) {
          hamster.x = hamster.targetX;
          hamster.y = hamster.targetY;
          const action = hamster.targetAction;
          hamster.targetX = null;
          hamster.targetY = null;
          hamster.targetAction = 'none';
          hamster.hopOffset = 0;
          applySquishImpulse(hamster, 3.2);

          if (hamster.targetTreatId !== null) {
            const idx = treats.findIndex((t) => t.id === hamster.targetTreatId);
            hamster.targetTreatId = null;
            if (idx !== -1) {
              const t = treats[idx];
              hamster.facing = t.x >= hamster.x ? 1 : -1;
              hamster.activeSnack = t.type;
              treats.splice(idx, 1);

              const shouldStuff =
                !hamster.onLoft &&
                (treats.length >= 2 ||
                  (hamster.storedPouch.length > 0 && hamster.stats.hunger > 75));

              if (shouldStuff && hamster.storedPouch.length < 4) {
                hamster.state = 'stuff_cheek';
                hamster.stateTimer = 0.72;
                setHamsterStatus(
                  world,
                  hamster,
                  `${hamster.name} memasukkan makanan ke kantong pipinya! Pipinya makin tembem~`
                );
              } else {
                const dur = t.type === 'strawberry' ? 3.2 : t.type === 'corn' ? 2.6 : 2.3;
                hamster.eatDuration = dur;
                hamster.state = 'eat';
                hamster.stateTimer = dur;
                emitMission(world, 'feed_treat');
                setHamsterStatus(
                  world,
                  hamster,
                  t.type === 'strawberry'
                    ? `${hamster.name} duduk imut menggigit stroberi manis~ nyam nyam nyam!`
                    : t.type === 'corn'
                    ? `${hamster.name} mengunyah jagung manis dengan kedua tangan mungilnya!`
                    : `${hamster.name} mengunyah kuaci kriuk-kriuk dengan gembira!`
                );
              }
              break;
            }
          }

          if (action === 'go_ladder_up') {
            hamster.state = 'climb_ladder';
            hamster.climbProgress = 0;
            hamster.climbLookTimer = 0;
            hamster.facing = -1;
            hamster.stateTimer = 6.5;
            setHamsterStatus(
              world,
              hamster,
              `Hap hap hap~ ${hamster.name} memanjat tangga kayu menuju lantai 2!`
            );
            break;
          }

          if (action === 'go_slide_down') {
            hamster.state = 'slide_down';
            hamster.slideProgress = 0;
            // Random silly slide poses: normal sit / head-first / sideways!
            const styleRoll = Math.random();
            hamster.slideStyle = styleRoll < 0.4 ? 0 : styleRoll < 0.72 ? 1 : 2;
            hamster.slideSpin = 0;
            hamster.ragdollAngle = hamster.slideStyle === 1 ? 2.45 : hamster.slideStyle === 2 ? 1.05 : 0;
            hamster.facing = 1;
            hamster.stateTimer = 2.5;
            pixelSound.playRagdollFling();
            setHamsterStatus(
              world,
              hamster,
              hamster.slideStyle === 1
                ? `WEEEE!! ${hamster.name} nekat meluncur KEPALA DULUAN di perosotan!`
                : hamster.slideStyle === 2
                ? `Hihi~ ${hamster.name} meluncur miring-miring sambil terguling lucu!`
                : `WEEEEEEE!! ${hamster.name} meluncur seru di perosotan lantai 2!`
            );
            break;
          }

          if (action === 'loft_nap') {
            hamster.state = 'yawn';
            hamster.stateTimer = 1.0;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} menguap di bantal awan lantai 2~`
            );
            break;
          }

          if (action === 'stash_eat' && world.iglooStash.length > 0) {
            hamster.activeSnack = world.iglooStash.pop() || 'seed';
            hamster.facing = -1;
            hamster.eatDuration = 2.4;
            hamster.state = 'eat';
            hamster.stateTimer = 2.4;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} makan camilan dari simpanan rahasianya di rumah!`
            );
            break;
          }

          if (action === 'stash_unload' && hamster.storedPouch.length > 0) {
            hamster.facing = -1;
            hamster.state = 'unload_stash';
            hamster.stateTimer = 1.4;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} mengeluarkan makanan dari pipi dan menumpuknya di depan rumah!`
            );
            break;
          }

          if (action === 'wheel') {
            if (!isWheelOccupied(world, hamster.id)) {
              const forceOverspin = hamster.wheelOverspinLoops === -1;
              hamster.state = 'run_wheel';
              hamster.wheelPhase = forceOverspin ? 'turbo' : 'accel';
              hamster.stateTimer = forceOverspin ? 0.8 : 0.85;
              hamster.wheelOverspinLoops = 0;
              hamster.facing = Math.random() < 0.8 ? 1 : -1;
              hamster.wheelSwing = 0;
              hamster.wheelSwingVel = 0;
              hamster.hopVel = -26;
              setHamsterStatus(
                world,
                hamster,
                forceOverspin
                  ? `${hamster.name} langsung NGEBUT POL di roda putar!!`
                  : `${hamster.name} melompat naik ke roda putar!`
              );
            } else {
              hamster.state = 'stand';
              hamster.stateTimer = 1.6;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} melihat temannya sedang asyik lari di roda~`
              );
            }
          } else if (action === 'pile_bury') {
            hamster.x = PROP_POS.pile.x;
            hamster.y = PROP_POS.pile.y;
            hamster.state = 'buried';
            hamster.stateTimer = 4.2 + Math.random() * 2.5;
            hamster.buriedWiggleTimer = 0.8;
            pixelSound.playBurrowRustle();
            emitMission(world, 'bury_pile');
            for (let i = 0; i < 6; i++) {
              spawnParticle(
                world,
                'shaving',
                hamster.x + (Math.random() * 14 - 7),
                hamster.y - 4,
                i % 2 === 0 ? '#FFF1DC' : '#E7C8A1',
                (Math.random() - 0.5) * 32,
                -24 - Math.random() * 12,
                0.55,
                2
              );
            }
            setHamsterStatus(
              world,
              hamster,
              `Srook srook~ ${hamster.name} mengubur dirinya di dalam tumpukan empuk! Imut banget~`
            );
          } else if (action === 'igloo_hide' || action === 'igloo_sleep') {
            hamster.x = PROP_POS.igloo.x;
            hamster.y = PROP_POS.igloo.y;
            emitMission(world, 'house_hide');
            if (action === 'igloo_sleep') {
              hamster.state = 'sleep_house';
              hamster.stateTimer = 6.5 + Math.random() * 3.5;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} masuk dan tidur pulas di dalam rumah hamster~ Zzz`
              );
            } else {
              hamster.state = 'hide_house';
              hamster.stateTimer = 4.5 + Math.random() * 2.5;
              setHamsterStatus(
                world,
                hamster,
                `${hamster.name} bersembunyi sambil mengintip lucu dari dalam rumah hamster!`
              );
            }
          } else if (action === 'bowl') {
            hamster.activeSnack = 'seed';
            world.bowlSeeds = Math.max(0, world.bowlSeeds - 14);
            hamster.facing = 1;
            hamster.eatDuration = 2.5;
            hamster.state = 'eat';
            hamster.stateTimer = 2.5;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} makan lahap dari mangkuk kuaci!`
            );
          } else if (action === 'bottle') {
            hamster.facing = 1;
            hamster.state = 'drink';
            hamster.stateTimer = 2.2;
            world.waterLevel = Math.max(0, world.waterLevel - 4);
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} minum air segar dari botol minum besar~ gluk gluk`
            );
          } else if (action === 'cushion') {
            hamster.state = 'yawn';
            hamster.stateTimer = 1.1;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} menguap lebar lalu menggulung diri di bantal...`
            );
          } else {
            hamster.state = 'idle';
            hamster.stateTimer = 1.2 + Math.random() * 1.1;
          }
        } else {
          const nextFacing: 1 | -1 = dx >= 0 ? 1 : -1;
          if (nextFacing !== hamster.facing) {
            hamster.phys.furShearVelX -= nextFacing * 10;
            hamster.facing = nextFacing;
          }
          hamster.x += (dx / dist) * speed * dt;
          hamster.y += (dy / dist) * speed * dt;
          hamster.hopOffset = Math.floor(hamster.animFrame) % 2 === 0 ? -1 : 0;
        }
      } else {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'climb_ladder': {
      hamster.hopOffset = 0;

      // Sometimes pause on the ladder to look around curiously, twitch ears, and glance at YOU!
      if (hamster.climbLookTimer > 0) {
        hamster.climbLookTimer -= dt;
      } else {
        hamster.climbProgress += dt * 0.62;
        if (hamster.climbProgress > 0.2 && hamster.climbProgress < 0.88 && Math.random() < dt * 0.55) {
          hamster.climbLookTimer = 0.7 + Math.random() * 0.65;
          hamster.facing = hamster.facing === 1 ? -1 : 1;
          spawnParticle(world, 'question', hamster.x + 3, hamster.y - 26, '#6C8CE8', 0, -8, 0.7);
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} berhenti sebentar di tangga untuk melihat sekeliling!`
          );
        }
      }

      const pt = getLadderPoint(clamp(hamster.climbProgress, 0, 1));
      hamster.x = pt.x;
      hamster.y = pt.y;

      if (hamster.climbLookTimer <= 0 && Math.floor(hamster.animFrame) % 3 === 0 && Math.random() < dt * 7) {
        pixelSound.playWheelTick();
      }

      if (hamster.climbProgress >= 1) {
        hamster.onLoft = true;
        hamster.y = LOFT_SPEC.y;
        hamster.x = LOFT_SPEC.ladderTop.x + 12;
        hamster.facing = 1;
        applySquishImpulse(hamster, -4.5, 4);
        // Walk across loft toward slide!
        hamster.targetAction = 'go_slide_down';
        hamster.targetX = LOFT_SPEC.slideTop.x - 4;
        hamster.targetY = LOFT_SPEC.y;
        hamster.state = 'walk';
        hamster.stateTimer = 4.5;
        spawnParticle(world, 'star', hamster.x, hamster.y - 24, '#FFE066', 0, -14, 0.8);
        setHamsterStatus(
          world,
          hamster,
          `Yeay! ${hamster.name} sampai di lantai 2 dan berjalan menuju perosotan!`
        );
      }
      break;
    }

    case 'slide_down': {
      hamster.hopOffset = 0;
      // Accelerating smooth Bezier slide with silly pose styles (head-first / sideways)!
      const speed = hamster.slideStyle === 1 ? 0.82 + hamster.slideProgress * 1.25 : 0.72 + hamster.slideProgress * 1.1;
      hamster.slideProgress += dt * speed;
      const pt = getSlidePoint(clamp(hamster.slideProgress, 0, 1));
      hamster.x = pt.x;
      hamster.y = pt.y;
      hamster.facing = 1;

      if (hamster.slideStyle === 1) {
        // Head-first flopping spin down the slide!
        hamster.ragdollAngle = 2.45 + Math.sin(hamster.slideProgress * 14) * 0.22;
      } else if (hamster.slideStyle === 2) {
        // Sideways tumbling down the slide!
        hamster.ragdollAngle = 1.05 + Math.sin(hamster.slideProgress * 22) * 0.5;
      } else {
        hamster.ragdollAngle = 0;
      }

      if (Math.random() < dt * 8) {
        spawnParticle(
          world,
          'sparkle',
          hamster.x - 4,
          hamster.y - 6,
          world.rainbowSlide ? '#FF9EC4' : '#FFE8B5',
          -14,
          -12,
          0.4
        );
      }

      if (hamster.slideProgress >= 1) {
        hamster.onLoft = false;
        hamster.x = LOFT_SPEC.slideBottom.x + 6;
        hamster.y = LOFT_SPEC.slideBottom.y + 4;
        applySquishImpulse(hamster, 8.8, 8);
        stats.happiness = clamp(stats.happiness + 12, 0, 100);
        stats.affection += 3;
        emitMission(world, 'climb_slide');

        // Sometimes hamster loses balance at slide end and tumbles out adorably!
        const tumbleChance = hamster.slideStyle === 1 ? 0.85 : hamster.slideStyle === 2 ? 0.7 : 0.32;
        if (Math.random() < tumbleChance) {
          hamster.state = 'ragdoll';
          hamster.stateTimer = 2.2;
          hamster.ragdollGroundY = clamp(
            LOFT_SPEC.slideBottom.y + 12,
            FLOOR_TOP_Y + 12,
            FLOOR_BOTTOM_Y - 6
          );
          hamster.ragdollBounces = 0;
          hamster.vx = 70 + Math.random() * 65;
          hamster.vy = -85 - Math.random() * 40;
          hamster.ragdollSpin = 10 + Math.random() * 7;
          pixelSound.playRagdollFling();
          const funnyMsg =
            hamster.slideStyle === 1
              ? `WADUH! ${hamster.name} meluncur kepala duluan & mental terpelanting lucu di ujung seluncuran!!`
              : `Ups! ${hamster.name} salah posisi di ujung seluncuran lalu terguling gemas!!`;
          setHamsterStatus(world, hamster, funnyMsg);
        } else {
          hamster.ragdollAngle = 0;
          pixelSound.playHappyChime();
          triggerHappyHop(
            world,
            hamster,
            `BOING!! ${hamster.name} mendarat empuk sehabis meluncur di perosotan!!`
          );
        }
      }
      break;
    }

    case 'glass_peek': {
      hamster.hopOffset = 0;
      hamster.ragdollAngle = 0;
      // Wave tiny paws on the front glass!
      if (Math.random() < dt * 2.2) {
        spawnParticle(
          world,
          'heart',
          hamster.x + (Math.random() * 12 - 6),
          hamster.y - 26,
          '#FF6B93',
          0,
          -12,
          0.9
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'wall_climb': {
      hamster.hopOffset = 0;
      hamster.climbProgress += dt * 0.42;
      const wallX = hamster.facing === -1 ? 24 : VIRTUAL_W - 24;
      hamster.x = wallX;
      hamster.y = FLOOR_TOP_Y + 10 - hamster.climbProgress * 38;

      if (hamster.climbProgress < 0.85) {
        hamster.ragdollAngle = hamster.facing === -1 ? -Math.PI / 2 : Math.PI / 2;
        if (Math.floor(hamster.animFrame) % 3 === 0 && Math.random() < dt * 6) {
          pixelSound.playWheelTick();
        }
      } else {
        // Losing grip and sliding down the glass with cute sweat!
        hamster.ragdollAngle = hamster.facing === -1 ? -1.1 : 1.1;
        if (Math.random() < dt * 3) {
          spawnParticle(world, 'sweat', hamster.x, hamster.y - 22, '#7CD4FF', 6 * hamster.facing, 8, 0.5);
        }
      }

      if (hamster.climbProgress >= 1.05) {
        hamster.state = 'ragdoll';
        hamster.stateTimer = 1.6;
        hamster.ragdollGroundY = FLOOR_TOP_Y + 20;
        hamster.ragdollBounces = 0;
        hamster.vx = (hamster.facing === -1 ? 1 : -1) * 65;
        hamster.vy = -45;
        hamster.ragdollSpin = (hamster.facing === -1 ? 1 : -1) * 9;
        pixelSound.playRagdollFling();
        setHamsterStatus(
          world,
          hamster,
          `Upsy daisy! ${hamster.name} kehilangan pegangan & melorot jatuh dari dinding kaca!`
        );
      }
      break;
    }

    case 'held': {
      // While held: wiggle paws, blink, and occasionally lick own paw to clean itself!
      hamster.ragdollAngle = 0;
      hamster.hopOffset = 0;
      hamster.lickPawTimer -= dt;
      if (hamster.lickPawTimer <= 0 && Math.random() < dt * 0.7) {
        hamster.lickPawTimer = 1.6 + Math.random() * 1.2;
        pixelSound.playSqueak();
        spawnParticle(world, 'sparkle', hamster.x + 3, hamster.y - 12, '#FFE066', 0, -12, 0.7);
        hamster.statusText = `${hamster.name} menjilat kaki mungilnya lalu mengusap pipi tembemnya~ bersih-bersih!`;
        world.globalStatusText = hamster.statusText;
      }
      // Gentle pudding jiggle while held
      hamster.phys.squeezeAmount = 0.8 + Math.sin(timeSec * 7) * 0.12;
      if (Math.random() < dt * 1.2) {
        spawnParticle(
          world,
          'heart',
          hamster.x + (Math.random() * 10 - 5),
          hamster.y - 24,
          '#FF8FA8',
          0,
          -14,
          0.85
        );
      }
      break;
    }

    case 'squeeze': {
      if (hamster.stateTimer <= 0) {
        hamster.phys.squeezeAmount = 0;
        applySquishImpulse(hamster, -6.5, 4);
        hamster.state = 'idle';
        hamster.stateTimer = 1.2;
      }
      break;
    }

    case 'buried': {
      hamster.hopOffset = 0;
      hamster.buriedWiggleTimer = Math.max(0, hamster.buriedWiggleTimer - dt);
      if (Math.random() < dt * 0.7) {
        hamster.buriedWiggleTimer = 0.65;
        pixelSound.playBurrowRustle();
        spawnParticle(
          world,
          'shaving',
          hamster.x + (Math.random() * 10 - 5),
          hamster.y - 6,
          '#FFF1DC',
          (Math.random() - 0.5) * 18,
          -18,
          0.45,
          1
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.y = PROP_POS.pile.y + 3;
        hamster.hopVel = -45;
        pixelSound.playBurrowRustle();
        for (let i = 0; i < 6; i++) {
          spawnParticle(
            world,
            'shaving',
            hamster.x + (Math.random() * 14 - 7),
            hamster.y - 8,
            '#F3D29C',
            (Math.random() - 0.5) * 38,
            -30 - Math.random() * 12,
            0.6,
            2
          );
        }
        triggerHappyHop(
          world,
          hamster,
          `POP! ${hamster.name} keluar dari tumpukan sekam dengan muka puas!`
        );
      }
      break;
    }

    case 'hide_house': {
      if (Math.random() < dt * 0.6) {
        spawnParticle(
          world,
          'question',
          hamster.x + 2,
          hamster.y - 20,
          '#6C8CE8',
          2,
          -8,
          0.7
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.y = PROP_POS.igloo.y + 9;
        hamster.hopVel = -28;
        triggerHappyHop(
          world,
          hamster,
          `${hamster.name} keluar dari persembunyian di rumah hamsternya~ cilukba!`
        );
      }
      break;
    }

    case 'sleep_house': {
      if (Math.random() < dt * 0.95) {
        spawnParticle(
          world,
          'zzz',
          hamster.x + 6,
          hamster.y - 18,
          world.nightMode ? '#C2CEFF' : '#8BA4F5',
          5,
          -12,
          1.4
        );
      }
      if (hamster.stateTimer <= 0 && stats.energy > 65) {
        hamster.y = PROP_POS.igloo.y + 9;
        hamster.state = 'stretch';
        hamster.stateTimer = 1.2;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} keluar dari rumah sambil menggeliat habis tidur nyenyak~`
        );
      }
      break;
    }

    case 'play_fight': {
      const partner = world.hamsters.find((h) => h.id === hamster.playFightPartnerId);
      if (partner) {
        hamster.facing = partner.x >= hamster.x ? 1 : -1;
      }
      if (Math.random() < dt * 4.2) {
        const pxX = hamster.x + hamster.facing * 7;
        const pxY = hamster.y - 10;
        spawnParticle(world, 'bap', pxX, pxY, '#FFB5C8', (Math.random() - 0.5) * 18, -14, 0.35);
        if (Math.random() < 0.45) {
          spawnParticle(world, 'heart', hamster.x, hamster.y - 24, '#FF6B93', 0, -16, 0.9);
        } else {
          spawnParticle(world, 'note', hamster.x, hamster.y - 24, '#FF8CB0', (Math.random() - 0.5) * 14, -14, 0.85);
        }
        pixelSound.playPlayFightBap();
      }
      if (hamster.hopOffset === 0 && Math.random() < dt * 3.5) {
        hamster.hopVel = -26;
      }
      if (hamster.stateTimer <= 0) {
        hamster.playFightPartnerId = null;
        stats.happiness = clamp(stats.happiness + 14, 0, 100);
        stats.affection += 4;
        triggerHappyHop(
          world,
          hamster,
          `${hamster.name} selesai gelut lucu dan malah makin akrab! ♥`
        );
      }
      break;
    }

    case 'stuff_cheek': {
      hamster.hopOffset = 0;
      if (hamster.stateTimer <= 0) {
        const snack = hamster.activeSnack || 'seed';
        hamster.activeSnack = null;
        hamster.storedPouch.push(snack);
        stats.cheekPuff = Math.min(4, hamster.storedPouch.length * 1.15);
        stats.happiness = clamp(stats.happiness + 10, 0, 100);
        stats.affection += 2;
        applySquishImpulse(hamster, 3.6);
        pixelSound.playCheekStuff();
        emitMission(world, 'feed_treat');
        spawnParticle(world, 'heart', hamster.x, hamster.y - 25, '#FF8FA8', 0, -14, 0.9);

        const moreTreats = treats.some((t) => t.landed && !t.onLoft);
        if (moreTreats && hamster.storedPouch.length < 4) {
          hamster.state = 'idle';
          hamster.stateTimer = 0.08;
        } else {
          const stashSpot = getIglooStashTarget();
          hamster.targetAction = 'stash_unload';
          hamster.targetX = stashSpot.x;
          hamster.targetY = stashSpot.y;
          hamster.state = 'walk';
          hamster.stateTimer = 6.0;
          setHamsterStatus(
            world,
            hamster,
            `Pipi ${hamster.name} penuh (${hamster.storedPouch.length} simpanan)! Menuju rumah untuk menyimpannya~`
          );
        }
      }
      break;
    }

    case 'unload_stash': {
      hamster.hopOffset = 0;
      if (Math.random() < dt * 5) {
        spawnParticle(
          world,
          'crumb',
          hamster.x - 6,
          hamster.y - 10,
          '#E6DDD5',
          -14 - Math.random() * 10,
          -12,
          0.45,
          2
        );
      }
      if (hamster.stateTimer <= 0) {
        while (hamster.storedPouch.length > 0) {
          const item = hamster.storedPouch.shift();
          if (item) {
            if (world.iglooStash.length >= 16) world.iglooStash.shift();
            world.iglooStash.push(item);
          }
        }
        stats.cheekPuff = 0;
        stats.happiness = clamp(stats.happiness + 12, 0, 100);
        stats.affection += 3;
        pixelSound.playUnloadStash();
        triggerHappyHop(
          world,
          hamster,
          `${hamster.name} berhasil menyimpan tumpukan camilan di depan rumah! (Total: ${world.iglooStash.length})`
        );
      }
      break;
    }

    case 'run_wheel': {
      const { x: wcx, y: wcy, radius } = PROP_POS.wheel;
      const trackR = radius - 4;

      if (hamster.wheelPhase === 'accel') {
        hamster.wheelSpeed += (7.5 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 4);
        hamster.wheelSwing += (0.24 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 5);
        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'cruise';
          hamster.stateTimer = 1.6 + Math.random() * 0.8;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} lari gembira di roda putar~ tap tap tap!`
          );
        }
      } else if (hamster.wheelPhase === 'cruise') {
        hamster.wheelSpeed += (8.8 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 5);
        hamster.wheelSwing += (0.28 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 5);
        if (Math.random() < dt * 2.5) {
          spawnParticle(
            world,
            'note',
            hamster.x + (Math.random() * 12 - 6),
            hamster.y - 26,
            '#FF8FB1',
            (Math.random() - 0.5) * 10,
            -16,
            1.0
          );
        }
        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'turbo';
          hamster.stateTimer = 1.4 + Math.random() * 0.7;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} MODE TURBO!! Kaki mungilnya super ngebut!!`
          );
          spawnParticle(world, 'exclaim', hamster.x, hamster.y - 28, '#FF5C8A', 0, -10, 0.7);
          pixelSound.playSqueak();
        }
      } else if (hamster.wheelPhase === 'turbo') {
        hamster.wheelSpeed += (13.4 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 6);
        hamster.wheelSwing += (0.45 * hamster.facing - hamster.wheelSwing) * Math.min(1, dt * 6);
        if (Math.random() < dt * 7) {
          spawnParticle(
            world,
            'sparkle',
            hamster.x - hamster.facing * 9,
            hamster.y - 3,
            '#FFE8B5',
            -hamster.facing * 22,
            -10,
            0.35
          );
        }
        if (hamster.stateTimer <= 0) {
          if (Math.random() < 0.65) {
            hamster.wheelPhase = 'overspin';
            hamster.wheelOverspinLoops = 0;
            hamster.stateTimer = 1.5;
            setHamsterStatus(
              world,
              hamster,
              `WADUH!! ${hamster.name} KEBANTERAN! Ikut muter 360° di dalam roda!!`
            );
            spawnParticle(world, 'exclaim', hamster.x, hamster.y - 28, '#FF5C8A', 0, -12, 0.8);
            pixelSound.playSqueak();
          } else {
            hamster.wheelPhase = 'coast';
            hamster.stateTimer = 1.25;
            hamster.wheelSwingVel = 2.6 * hamster.facing;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} berhenti mendadak dan ikut berayun di roda~ wiiiii!`
            );
          }
        }
      } else if (hamster.wheelPhase === 'overspin') {
        // REAL floppy physics: hamster tumbles & rolls loosely inside the spinning wheel!
        const spinRate = 10.5 * hamster.facing;
        hamster.wheelSpeed += (15.0 * hamster.facing - hamster.wheelSpeed) * Math.min(1, dt * 6);
        hamster.wheelSwing += spinRate * dt;

        // Independent body-spin angular momentum with floppy wobble + centrifugal bounce
        hamster.ragdollSpin += hamster.facing * 22 * dt;
        hamster.ragdollSpin *= Math.pow(0.82, dt);
        hamster.ragdollSpin = clamp(hamster.ragdollSpin, -24, 24);
        hamster.ragdollAngle += hamster.ragdollSpin * dt;
        hamster.hopOffset = Math.sin(hamster.ragdollAngle * 1.7) * 3;

        if (Math.random() < dt * 8) {
          spawnParticle(
            world,
            'star',
            hamster.x,
            hamster.y - 6,
            '#FFE066',
            (Math.random() - 0.5) * 30,
            -15,
            0.4
          );
        }

        if (Math.abs(hamster.wheelSwing) >= Math.PI * 2.25 || hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'none';
          hamster.state = 'ragdoll';
          hamster.stateTimer = 2.4;
          const launchDir: 1 | -1 = Math.random() < 0.72 ? 1 : -1;
          hamster.vx = launchDir * (135 + Math.random() * 45);
          hamster.vy = -125 - Math.random() * 35;
          hamster.ragdollSpin = launchDir * 15;
          hamster.ragdollGroundY = clamp(
            FLOOR_TOP_Y + 18 + Math.random() * 14,
            FLOOR_TOP_Y + 12,
            FLOOR_BOTTOM_Y - 8
          );
          hamster.ragdollBounces = 0;
          pixelSound.playRagdollFling();
          emitMission(world, 'ragdoll_wheel');
          setHamsterStatus(
            world,
            hamster,
            `WIIIIII!! ${hamster.name} TERLEMPAR dari roda putar kayak bola mochi!!`
          );
          break;
        }
      } else if (hamster.wheelPhase === 'coast') {
        hamster.wheelSpeed *= Math.pow(0.18, dt);
        const force = -24 * hamster.wheelSwing - 3.6 * hamster.wheelSwingVel;
        hamster.wheelSwingVel += force * dt;
        hamster.wheelSwing += hamster.wheelSwingVel * dt;

        if (hamster.stateTimer <= 0) {
          hamster.wheelPhase = 'none';
          hamster.hopOffset = 0;
          hamster.hopVel = -28;
          hamster.ragdollAngle = 0;
          hamster.x = wcx + hamster.facing * 6;
          hamster.y = FLOOR_TOP_Y + 14;
          if (Math.random() < 0.55) {
            hamster.state = 'dizzy';
            hamster.stateTimer = 1.8;
            setHamsterStatus(
              world,
              hamster,
              `${hamster.name} turun sambil sedikit pusing imut~ @_@`
            );
          } else {
            triggerHappyHop(
              world,
              hamster,
              `${hamster.name} turun dari roda dengan lompatan bangga!`
            );
          }
          break;
        }
      }

      hamster.wheelAngle += hamster.wheelSpeed * dt;
      world.wheelAngle = hamster.wheelAngle;
      world.wheelSpeed = hamster.wheelSpeed;

      hamster.x = wcx + Math.sin(hamster.wheelSwing) * trackR;
      hamster.y = wcy + Math.cos(hamster.wheelSwing) * trackR;

      if (
        hamster.wheelPhase !== 'coast' &&
        Math.floor(hamster.animFrame) % 4 === 0 &&
        Math.random() < dt * 8
      ) {
        pixelSound.playWheelTick();
      }
      break;
    }

    case 'ragdoll': {
      hamster.vy += 320 * dt;
      hamster.x += hamster.vx * dt;
      hamster.y += hamster.vy * dt;
      hamster.ragdollAngle += hamster.ragdollSpin * dt;

      if (hamster.x < 30) {
        hamster.x = 30;
        hamster.vx = Math.abs(hamster.vx) * 0.65;
        hamster.ragdollSpin = -hamster.ragdollSpin * 0.8;
        applySquishImpulse(hamster, 6, 8);
        pixelSound.playRagdollBonk();
      } else if (hamster.x > VIRTUAL_W - 34) {
        hamster.x = VIRTUAL_W - 34;
        hamster.vx = -Math.abs(hamster.vx) * 0.65;
        hamster.ragdollSpin = -hamster.ragdollSpin * 0.8;
        applySquishImpulse(hamster, 6, -8);
        pixelSound.playRagdollBonk();
      }

      if (hamster.y >= hamster.ragdollGroundY && hamster.vy > 0) {
        hamster.y = hamster.ragdollGroundY;
        hamster.ragdollBounces += 1;
        applySquishImpulse(hamster, 8.5, hamster.vx * 0.08);
        for (let i = 0; i < 4; i++) {
          spawnParticle(
            world,
            'shaving',
            hamster.x + (Math.random() * 10 - 5),
            hamster.y,
            i % 2 === 0 ? '#FFF1DC' : '#E7C8A1',
            (Math.random() - 0.5) * 35,
            -25 - Math.random() * 15,
            0.45,
            2
          );
        }

        if (hamster.ragdollBounces < 3 && Math.abs(hamster.vy) > 45) {
          hamster.vy = -hamster.vy * 0.52;
          hamster.vx *= 0.72;
          hamster.ragdollSpin *= 0.7;
          pixelSound.playRagdollBonk();
        } else {
          hamster.vx = 0;
          hamster.vy = 0;
          hamster.ragdollAngle = 0;
          hamster.ragdollSpin = 0;
          hamster.state = 'dizzy';
          hamster.stateTimer = 2.4;
          setHamsterStatus(
            world,
            hamster,
            `Gubrak empuk~ ${hamster.name} mendarat di sekam sambil pusing muter @_@`
          );
        }
      }
      break;
    }

    case 'dizzy': {
      hamster.hopOffset = 0;
      hamster.ragdollAngle = 0;
      if (Math.random() < dt * 4.5) {
        const ang = timeSec * 6;
        spawnParticle(
          world,
          'star',
          hamster.x + Math.cos(ang) * 10,
          hamster.y - 26 + Math.sin(ang) * 2.5,
          '#FFE066',
          0,
          -4,
          0.45
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'shake';
        hamster.stateTimer = 0.85;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} menggoyangkan bulu halusnya biar sadar lagi!`
        );
      }
      break;
    }

    case 'shake': {
      if (Math.random() < dt * 8) {
        spawnParticle(
          world,
          'fluff',
          hamster.x + (Math.random() * 14 - 7),
          hamster.y - 10 - Math.random() * 8,
          '#FFF5E6',
          (Math.random() - 0.5) * 32,
          -14 - Math.random() * 10,
          0.45
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.4;
      }
      break;
    }

    case 'stretch': {
      if (hamster.stateTimer <= 0) {
        hamster.state = 'stand';
        hamster.stateTimer = 1.2;
        applySquishImpulse(hamster, -4.5);
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} bangun tidur dengan tubuh segar!`
        );
      }
      break;
    }

    case 'happy_hop': {
      if (hamster.stateTimer <= 0 && hamster.hopOffset >= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.5;
      }
      break;
    }

    case 'eat': {
      hamster.hopOffset = 0;
      if (Math.random() < dt * 6.2) {
        const crumbCol =
          hamster.activeSnack === 'strawberry'
            ? '#FF6B8E'
            : hamster.activeSnack === 'corn'
            ? '#FFD54F'
            : '#D9CFC7';
        spawnParticle(
          world,
          'crumb',
          hamster.x + hamster.facing * 7,
          hamster.y - 13,
          crumbCol,
          (Math.random() - 0.5) * 28,
          -16 - Math.random() * 12,
          0.55,
          1
        );
        if (Math.random() < 0.35) {
          spawnParticle(
            world,
            'heart',
            hamster.x + (Math.random() * 12 - 6),
            hamster.y - 24,
            '#FF7EA5',
            0,
            -14,
            0.75
          );
        }
        pixelSound.playSatisfyingCrunch(hamster.activeSnack === 'strawberry');
      }

      if (hamster.stateTimer <= 0) {
        const snack = hamster.activeSnack;
        hamster.activeSnack = null;
        stats.hunger = clamp(stats.hunger + (snack === 'strawberry' ? 22 : 16), 0, 100);
        stats.happiness = clamp(stats.happiness + (snack === 'strawberry' ? 18 : 12), 0, 100);
        stats.affection += 3;
        pixelSound.playHappyChime();

        if (snack === 'strawberry') {
          triggerHappyHop(
            world,
            hamster,
            `${hamster.name} meloncat kegirangan karena stroberi favoritnya!`
          );
        } else {
          spawnParticle(world, 'heart', hamster.x, hamster.y - 26, '#FF6B93', 0, -14, 1.2);
          hamster.state = 'idle';
          hamster.stateTimer = 1.8;
          setHamsterStatus(
            world,
            hamster,
            `${hamster.name} selesai makan dengan puas~ nyam!`
          );
        }
      }
      break;
    }

    case 'drink': {
      if (Math.random() < dt * 3.0) {
        spawnParticle(
          world,
          'droplet',
          PROP_POS.bottle.spoutX - 1,
          PROP_POS.bottle.spoutY + 2,
          '#7CD4FF',
          -6,
          12,
          0.4,
          1
        );
      }
      if (hamster.stateTimer <= 0) {
        stats.happiness = clamp(stats.happiness + 6, 0, 100);
        hamster.state = 'idle';
        hamster.stateTimer = 1.5;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} selesai minum dari botol besarnya~ segaaar!`
        );
      }
      break;
    }

    case 'groom': {
      if (hamster.stateTimer <= 0) {
        world.cleanliness = clamp(world.cleanliness + 6, 0, 100);
        stats.happiness = clamp(stats.happiness + 5, 0, 100);
        spawnParticle(world, 'sparkle', hamster.x, hamster.y - 22, '#FFE066', 0, -10, 0.8);
        hamster.state = 'idle';
        hamster.stateTimer = 1.6;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} jadi wangi, bersih, dan super fluffy!`
        );
      }
      break;
    }

    case 'dig': {
      if (Math.random() < dt * 6.5) {
        spawnParticle(
          world,
          'shaving',
          hamster.x + hamster.facing * 5,
          hamster.y - 2,
          Math.random() < 0.5 ? '#FFF1DC' : '#E7C8A1',
          -hamster.facing * (12 + Math.random() * 14),
          -24 - Math.random() * 14,
          0.55,
          2
        );
      }
      if (hamster.stateTimer <= 0) {
        stats.happiness = clamp(stats.happiness + 6, 0, 100);
        hamster.state = 'shake';
        hamster.stateTimer = 0.75;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} mengibaskan serbuk kayu dari bulunya~`
        );
      }
      break;
    }

    case 'yawn': {
      if (hamster.stateTimer <= 0) {
        hamster.state = 'sleep';
        hamster.stateTimer = 6.5 + Math.random() * 4.0;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} tidur pulas berbentuk mochi gepeng~ Zzz`
        );
      }
      break;
    }

    case 'sleep': {
      if (Math.random() < dt * 0.85) {
        spawnParticle(
          world,
          'zzz',
          hamster.x + 8,
          hamster.y - 18,
          world.nightMode ? '#C2CEFF' : '#8BA4F5',
          4,
          -10,
          1.4
        );
      }
      if (hamster.stateTimer <= 0 && stats.energy > 65) {
        hamster.state = 'stretch';
        hamster.stateTimer = 1.3;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} menggeliat panjang sehabis tidur~`
        );
      }
      break;
    }

    case 'petted': {
      hamster.squish = 1;
      if (Math.random() < dt * 4.0) {
        spawnParticle(
          world,
          'heart',
          hamster.x + (Math.random() * 14 - 7),
          hamster.y - 24,
          '#FF6B93',
          (Math.random() - 0.5) * 10,
          -16,
          1.1
        );
      }
      if (hamster.stateTimer <= 0) {
        hamster.state = 'idle';
        hamster.stateTimer = 1.6;
        setHamsterStatus(
          world,
          hamster,
          `${hamster.name} senang sekali dielus~`
        );
      }
      break;
    }
  }

  if (
    hamster.state !== 'run_wheel' &&
    hamster.state !== 'ragdoll' &&
    hamster.state !== 'hide_house' &&
    hamster.state !== 'sleep_house' &&
    hamster.state !== 'buried' &&
    hamster.state !== 'climb_ladder' &&
    hamster.state !== 'slide_down' &&
    hamster.state !== 'held' &&
    hamster.state !== 'wall_climb'
  ) {
    if (hamster.onLoft) {
      hamster.x = clamp(hamster.x, LOFT_SPEC.minX + 8, LOFT_SPEC.maxX - 8);
      hamster.y = LOFT_SPEC.y;
    } else {
      hamster.x = clamp(hamster.x, 30, VIRTUAL_W - 34);
      hamster.y = clamp(hamster.y, FLOOR_TOP_Y + 6, FLOOR_BOTTOM_Y - 4);
    }
  }

  updateSoftPhysics(hamster, dt, timeSec);
}

export type { HamsterStats };

import {
  AquariumTheme,
  FairyLightStyle,
  PixelParticle,
  TreatItem,
  TreatKind,
  WeatherMode,
} from '../types/hamster';
import { drawMatrix, px, rect } from './pixelPrimitives';

export const VIRTUAL_W = 304;
export const VIRTUAL_H = 192;
export const FLOOR_TOP_Y = 142;
export const FLOOR_BOTTOM_Y = 180;

export const LOFT_SPEC = {
  minX: 22,
  maxX: 146,
  y: 84, // Standing floor surface of 2nd floor
  ladderBottom: { x: 70, y: 148 },
  ladderTop: { x: 64, y: 84 },
  slideTop: { x: 144, y: 84 },
  slideCtrl: { x: 168, y: 126 },
  slideBottom: { x: 202, y: 152 },
  loftMat: { x: 108, y: 84 },
};

export const PROP_POS = {
  igloo: { x: 38, y: 152 },
  wheel: { x: 108, y: 125, radius: 22, standY: 151 },
  pile: { x: 162, y: 171 },
  cushion: { x: 218, y: 158 },
  bowl: { x: 252, y: 168 },
  bottle: { x: 282, y: 106, spoutX: 268, spoutY: 128 },
};

/** Exact quadratic Bezier point along the slide chute so hamster & visual slide match 1:1 */
export function getSlidePoint(t: number): { x: number; y: number } {
  const u = 1 - t;
  const p0 = LOFT_SPEC.slideTop;
  const p1 = LOFT_SPEC.slideCtrl;
  const p2 = LOFT_SPEC.slideBottom;
  return {
    x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x,
    y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y,
  };
}

/** Exact linear point along the climbable ladder */
export function getLadderPoint(t: number): { x: number; y: number } {
  const b = LOFT_SPEC.ladderBottom;
  const top = LOFT_SPEC.ladderTop;
  return {
    x: b.x + (top.x - b.x) * t,
    y: b.y + (top.y - b.y) * t,
  };
}

const HEART_SPRITE = [
  '.RR.RR.',
  'RRRRRRR',
  'RRWRRRR',
  '.RRRRR.',
  '..RRR..',
  '...R...',
];

const NOTE_SPRITE = [
  '...NN',
  '..NNN',
  '..N..',
  '.NN..',
  'NNN..',
  '.N...',
];

const ZZZ_SPRITE = [
  'ZZZZ',
  '..Z.',
  '.Z..',
  'ZZZZ',
];

const STAR_SPRITE = [
  '..S..',
  '.SSS.',
  'SSWSS',
  '.SSS.',
  '..S..',
];

const COIN_SPRITE = [
  '.GGG.',
  'GYYWG',
  'GYWYG',
  'GYYYG',
  '.GGG.',
];

const THEME_PALETTES: Record<
  AquariumTheme,
  {
    wallDay: string;
    stripeDay: string;
    wallRain: string;
    stripeRain: string;
    wallSnow: string;
    stripeSnow: string;
    wallNight: string;
    stripeNight: string;
    trimDay: string;
    trimHi: string;
    houseBody: string;
    houseLight: string;
    houseShadow: string;
    cushionMain: string;
    cushionHi: string;
    cushionShadow: string;
    pileMain: string;
    pileLight: string;
    pileShadow: string;
    bottleCap: string;
    loftWood: string;
    loftWoodHi: string;
    loftWoodShadow: string;
    slideMain: string;
    slideHi: string;
    slideShadow: string;
    bunting: string[];
  }
> = {
  'pastel-room': {
    wallDay: '#FFF4E4',
    stripeDay: '#FCEAD2',
    wallRain: '#EFE5DC',
    stripeRain: '#E3D5C9',
    wallSnow: '#F3F7FF',
    stripeSnow: '#E4ECFA',
    wallNight: '#302B4A',
    stripeNight: '#3A3459',
    trimDay: '#EBC69E',
    trimHi: '#F6DAB8',
    houseBody: '#B5E8DE',
    houseLight: '#D9FAF3',
    houseShadow: '#8CCAC0',
    cushionMain: '#FFBFD0',
    cushionHi: '#FFE0E9',
    cushionShadow: '#E895AC',
    pileMain: '#F3D29C',
    pileLight: '#FFF0D1',
    pileShadow: '#D7AE74',
    bottleCap: '#FF9CB5',
    loftWood: '#DFAA7B',
    loftWoodHi: '#F5CCA3',
    loftWoodShadow: '#B88054',
    slideMain: '#FFB5C8',
    slideHi: '#FFD9E3',
    slideShadow: '#DE8AA2',
    bunting: ['#FFB5C8', '#FFE59E', '#B5EAD7', '#C7CEEA', '#FFDAC1'],
  },
  'sakura-garden': {
    wallDay: '#EEF8EC',
    stripeDay: '#E0F0DC',
    wallRain: '#DEE8E2',
    stripeRain: '#CFDCD4',
    wallSnow: '#ECF5F9',
    stripeSnow: '#DDECF4',
    wallNight: '#28353D',
    stripeNight: '#31404A',
    trimDay: '#C7A17A',
    trimHi: '#DFBE9B',
    houseBody: '#FFB5C8',
    houseLight: '#FFD9E3',
    houseShadow: '#E28CA3',
    cushionMain: '#FFE29A',
    cushionHi: '#FFF2C9',
    cushionShadow: '#DFB968',
    pileMain: '#F7C9CE',
    pileLight: '#FFE6EA',
    pileShadow: '#DF9FA8',
    bottleCap: '#8BE0B2',
    loftWood: '#D4A57B',
    loftWoodHi: '#ECC5A1',
    loftWoodShadow: '#A87A54',
    slideMain: '#AEEBD9',
    slideHi: '#D6FAF0',
    slideShadow: '#7DC7B2',
    bunting: ['#FF9BB8', '#FFF0A8', '#A8E6CF', '#FFD3B6', '#FFAAA5'],
  },
  'starlight-cafe': {
    wallDay: '#F4EEFF',
    stripeDay: '#E8DFFC',
    wallRain: '#E2DDF0',
    stripeRain: '#D4CEE6',
    wallSnow: '#EEF2FF',
    stripeSnow: '#DFE6FA',
    wallNight: '#252140',
    stripeNight: '#2E294D',
    trimDay: '#D4AC86',
    trimHi: '#ECC8A6',
    houseBody: '#FFD89E',
    houseLight: '#FFEDCC',
    houseShadow: '#DEA96A',
    cushionMain: '#B9D6FF',
    cushionHi: '#DCEBFF',
    cushionShadow: '#8FB3EB',
    pileMain: '#E8D5C4',
    pileLight: '#FFF4EB',
    pileShadow: '#C8B09B',
    bottleCap: '#A5C8FF',
    loftWood: '#D6AC85',
    loftWoodHi: '#F0CFAF',
    loftWoodShadow: '#A97E59',
    slideMain: '#C7CEEA',
    slideHi: '#E5E9FA',
    slideShadow: '#9CA6CF',
    bunting: ['#C7CEEA', '#FFE59E', '#FFB5C8', '#B5EAD7', '#E2C6FF'],
  },
};

export function drawTerrariumBack(
  ctx: CanvasRenderingContext2D,
  theme: AquariumTheme,
  nightMode: boolean,
  weather: WeatherMode,
  timeSec: number,
  cleanliness: number,
  iglooStash: TreatKind[],
  rainbowSlide: boolean,
  flowerLoft: boolean
) {
  const pal = THEME_PALETTES[theme];

  // 1) Cozy pastel wallpaper
  const wallBg = nightMode
    ? pal.wallNight
    : weather === 'rain'
    ? pal.wallRain
    : weather === 'snow'
    ? pal.wallSnow
    : pal.wallDay;
  const wallStripe = nightMode
    ? pal.stripeNight
    : weather === 'rain'
    ? pal.stripeRain
    : weather === 'snow'
    ? pal.stripeSnow
    : pal.stripeDay;

  rect(ctx, 0, 0, VIRTUAL_W, FLOOR_TOP_Y, wallBg);
  for (let x = 0; x < VIRTUAL_W; x += 12) {
    rect(ctx, x, 0, 4, FLOOR_TOP_Y, wallStripe);
  }

  // Wooden wainscoting trim behind cage
  rect(ctx, 0, FLOOR_TOP_Y - 10, VIRTUAL_W, 10, nightMode ? '#523C4A' : pal.trimDay);
  rect(ctx, 0, FLOOR_TOP_Y - 10, VIRTUAL_W, 2, nightMode ? '#6B4F5F' : pal.trimHi);

  // 2) Window on back-right showing Clear / Gorgeous Heavy Rain / Snow!
  drawWeatherWindow(ctx, nightMode, weather, timeSec);

  // 3) Framed tiny wall picture above loft left
  const picX = 24;
  const picY = 26;
  rect(ctx, picX, picY, 22, 22, '#5A392C');
  rect(ctx, picX + 1, picY + 1, 20, 20, '#D9A06B');
  rect(ctx, picX + 3, picY + 3, 16, 16, '#FFF9EE');
  if (theme === 'sakura-garden') {
    rect(ctx, picX + 5, picY + 14, 10, 2, '#70442E');
    rect(ctx, picX + 6, picY + 7, 4, 4, '#FF9EBB');
    rect(ctx, picX + 12, picY + 9, 4, 4, '#FFB8CD');
  } else if (theme === 'starlight-cafe') {
    rect(ctx, picX + 4, picY + 4, 14, 14, '#2E2A4A');
    rect(ctx, picX + 11, picY + 6, 4, 4, '#FFE680');
    rect(ctx, picX + 13, picY + 7, 2, 2, '#2E2A4A');
    rect(ctx, picX + 6, picY + 12, 5, 4, '#FFF5E6');
  } else {
    rect(ctx, picX + 10, picY + 12, 2, 5, '#6AC46E');
    rect(ctx, picX + 8, picY + 7, 6, 6, '#FFC947');
    rect(ctx, picX + 9, picY + 8, 4, 4, '#70442E');
  }

  // 4) Cute pastel pennant bunting along top
  for (let i = 0; i < 13; i++) {
    const bx = 6 + i * 24;
    const col = pal.bunting[i % pal.bunting.length];
    rect(ctx, bx, 5, 12, 2, '#5A392C');
    rect(ctx, bx + 1, 6, 10, 3, col);
    rect(ctx, bx + 3, 9, 6, 3, col);
    rect(ctx, bx + 5, 12, 2, 1, col);
  }
  rect(ctx, 0, 4, VIRTUAL_W, 1, '#7A5442');

  // 5) Fluffy Wood-Shaving Bedding Layer
  const bedTop = FLOOR_TOP_Y;
  const bedH = VIRTUAL_H - bedTop;
  rect(ctx, 0, bedTop, VIRTUAL_W, bedH, nightMode ? '#8D7366' : '#F5DFC2');

  for (let x = 0; x < VIRTUAL_W; x += 4) {
    const bump = (x / 4) % 3 === 0 ? -2 : (x / 4) % 2 === 0 ? -1 : 0;
    rect(ctx, x, bedTop + bump, 4, 3, nightMode ? '#A48879' : '#FFF1DC');
    px(ctx, x + 1, bedTop + bump - 1, '#5A392C');
    px(ctx, x + 2, bedTop + bump - 1, '#5A392C');
  }

  const chipA = nightMode ? '#7A6256' : '#E7C8A1';
  const chipB = nightMode ? '#A88C7D' : '#FFF7EA';
  for (let row = 0; row < 5; row++) {
    for (let col = 0; col < 19; col++) {
      const cx = (col * 17 + row * 9) % (VIRTUAL_W - 8);
      const cy = bedTop + 5 + row * 7 + (col % 3);
      rect(ctx, cx, cy, 4, 2, col % 2 === 0 ? chipA : chipB);
    }
  }

  if (cleanliness < 70) {
    const messCount = Math.floor((75 - cleanliness) / 8);
    for (let i = 0; i < messCount; i++) {
      const mx = (i * 53 + 29) % (VIRTUAL_W - 20);
      const my = bedTop + 8 + ((i * 19) % 26);
      rect(ctx, mx, my, 2, 1, '#7D5C4C');
    }
  }

  // Bottom wooden terrarium frame bar
  rect(ctx, 0, VIRTUAL_H - 8, VIRTUAL_W, 8, '#7A4E3B');
  rect(ctx, 0, VIRTUAL_H - 8, VIRTUAL_W, 2, '#A36D54');
  rect(ctx, 0, VIRTUAL_H - 9, VIRTUAL_W, 1, '#5A392C');

  // 6) 2ND FLOOR LOFT DECK, CUTE LADDER & CURVED SLIDE!
  drawLoftStructure(ctx, theme, nightMode, rainbowSlide, flowerLoft, timeSec);

  // 7) Cozy Pastel Hamster House (under left side of loft)
  drawHouseBack(ctx, PROP_POS.igloo.x, PROP_POS.igloo.y, theme, nightMode);
  drawIglooStash(ctx, PROP_POS.igloo.x + 20, PROP_POS.igloo.y + 3, iglooStash);

  // 8) Plush Star Cushion
  drawCushion(ctx, PROP_POS.cushion.x, PROP_POS.cushion.y, theme);

  // 9) Back half of the Burrowable Bedding/Hay Pile
  drawBeddingPileBack(ctx, PROP_POS.pile.x, PROP_POS.pile.y, theme, nightMode);

  // 10) Running Wheel (under center-right of loft)
  drawWheelBack(ctx, PROP_POS.wheel.x, PROP_POS.wheel.y, nightMode);
}

function drawWeatherWindow(
  ctx: CanvasRenderingContext2D,
  nightMode: boolean,
  weather: WeatherMode,
  timeSec: number
) {
  const winX = 194;
  const winY = 20;
  const winW = 62;
  const winH = 54;
  rect(ctx, winX - 3, winY - 3, winW + 6, winH + 6, '#5A392C');
  rect(ctx, winX - 2, winY - 2, winW + 4, winH + 4, nightMode ? '#8B6B61' : '#DFAA7B');

  const skyCol =
    weather === 'rain'
      ? nightMode
        ? '#121830'
        : '#4A648A'
      : weather === 'snow'
      ? nightMode
        ? '#1E2544'
        : '#9ABBE0'
      : nightMode
      ? '#222447'
      : '#BCE8FF';

  rect(ctx, winX, winY, winW, winH, skyCol);

  if (weather === 'rain') {
    // Occasional soft atmospheric lightning flash
    const thunderPulse = Math.sin(timeSec * 3.1) * Math.sin(timeSec * 13.7);
    if (thunderPulse > 0.955) {
      rect(ctx, winX, winY, winW, winH, '#D9EAFF');
    }

    // Distant silhouette trees/hills misted by heavy rain
    rect(ctx, winX, winY + 33, winW, 21, nightMode ? '#1A2442' : '#5D79A1');
    rect(ctx, winX + 4, winY + 37, 16, 17, nightMode ? '#161F38' : '#4E6A91');
    rect(ctx, winX + 34, winY + 35, 22, 19, nightMode ? '#161F38' : '#4E6A91');

    // Rolling dark storm clouds
    const drift = Math.floor((timeSec * 8) % 28);
    const cloudCol = nightMode ? '#293457' : '#7388A8';
    const cloudLight = nightMode ? '#394875' : '#95A9C7';
    rect(ctx, winX + ((drift + 2) % 36), winY + 3, 24, 7, cloudCol);
    rect(ctx, winX + ((drift + 6) % 36), winY + 1, 14, 3, cloudLight);
    rect(ctx, winX + ((drift + 24) % 34), winY + 7, 22, 6, cloudCol);

    // Layer A: Distant fine soft rain streaks
    for (let i = 0; i < 36; i++) {
      const speed = 58 + (i % 3) * 14;
      const prog = (timeSec * speed + i * 11) % (winH - 2);
      const rx = winX + ((i * 9 + Math.floor(prog * 0.4)) % (winW - 2));
      const ry = winY + 2 + Math.floor(prog);
      const col = nightMode ? '#5274B3' : '#96C2EB';
      px(ctx, rx, ry, col);
      if (ry + 1 < winY + winH) px(ctx, rx - 1, ry + 1, col);
    }

    // Layer B: Foreground fast bright heavy rain streaks!
    for (let i = 0; i < 42; i++) {
      const speed = 88 + (i % 4) * 18;
      const prog = (timeSec * speed + i * 17) % (winH - 4);
      const rx = winX + ((i * 7 + Math.floor(prog * 0.5)) % (winW - 3));
      const ry = winY + 2 + Math.floor(prog);
      const col = i % 2 === 0 ? '#E8F7FF' : '#B3E3FF';
      px(ctx, rx, ry, col);
      if (ry + 1 < winY + winH) px(ctx, rx - 1, ry + 1, col);
      if (ry + 2 < winY + winH) px(ctx, rx - 1, ry + 2, '#94D4FF');
      if (ry + 3 < winY + winH) px(ctx, rx - 2, ry + 3, '#7BC7FF');
    }

    // Layer C: Slow sliding water beads clinging & dripping down the glass pane!
    for (let b = 0; b < 8; b++) {
      const beadY = winY + 6 + Math.floor((timeSec * (8 + (b % 3) * 4) + b * 23) % (winH - 10));
      const beadX = winX + 6 + ((b * 13) % (winW - 12));
      px(ctx, beadX, beadY, '#FFFFFF');
      px(ctx, beadX, beadY + 1, '#BCE8FF');
    }

    // Layer D: Heavy bouncing splash crowns on window sill
    for (let s = 0; s < 12; s++) {
      const phase = Math.floor(timeSec * 18 + s * 3) % 3;
      if (phase === 0) {
        const sx = winX + 3 + s * 5;
        px(ctx, sx, winY + winH - 2, '#FFFFFF');
        px(ctx, sx + 1, winY + winH - 3, '#B3E3FF');
        px(ctx, sx - 1, winY + winH - 3, '#B3E3FF');
      }
    }
  } else if (weather === 'snow') {
    rect(ctx, winX, winY + 33, winW, 21, nightMode ? '#29355A' : '#BFD7F2');
    const drift = Math.floor((timeSec * 2.5) % 26);
    rect(ctx, winX + ((drift + 2) % 36), winY + 5, 22, 6, nightMode ? '#4A5980' : '#DCE9F7');
    rect(ctx, winX + ((drift + 20) % 34), winY + 8, 18, 5, nightMode ? '#414F73' : '#EEF5FC');

    for (let i = 0; i < 38; i++) {
      const fallSpeed = 13 + (i % 4) * 4;
      const progress = (timeSec * fallSpeed + i * 19) % (winH - 4);
      const sway = Math.round(Math.sin(timeSec * 2.2 + i) * 3);
      const sx = winX + 3 + ((i * 9 + sway + 120) % (winW - 6));
      const sy = winY + 4 + Math.floor(progress);
      const col = i % 4 === 0 ? '#D6ECFF' : '#FFFFFF';
      px(ctx, sx, sy, col);
      if (i % 5 === 0 && sx + 1 < winX + winW - 1 && sy + 1 < winY + winH - 1) {
        px(ctx, sx + 1, sy, '#FFFFFF');
        px(ctx, sx, sy + 1, '#E6F3FF');
      }
    }

    for (let x = 0; x < winW; x += 2) {
      const h = x % 6 === 0 ? 3 : 2;
      rect(ctx, winX + x, winY + winH - h, 2, h, '#FFFFFF');
    }
    rect(ctx, winX, winY + winH - 1, winW, 1, '#D8EBFF');
  } else if (!nightMode) {
    rect(ctx, winX, winY + 30, winW, 24, '#D9F4FF');
    const cloudOffset = Math.floor((timeSec * 3) % 44);
    const cx = winX + ((cloudOffset + 8) % 40);
    rect(ctx, cx, winY + 11, 14, 5, '#FFFFFF');
    rect(ctx, cx + 3, winY + 8, 8, 3, '#FFFFFF');
    rect(ctx, winX + 4, winY + 24, 10, 4, '#FFFFFF');
    rect(ctx, winX + 6, winY + 22, 6, 2, '#FFFFFF');
  } else {
    const twinkle = Math.floor(timeSec * 2) % 2 === 0;
    px(ctx, winX + 10, winY + 12, twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 22, winY + 24, !twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 48, winY + 16, twinkle ? '#FFF7B2' : '#B8C4F2');
    px(ctx, winX + 16, winY + 38, '#B8C4F2');
    rect(ctx, winX + 40, winY + 9, 7, 7, '#FFE994');
    rect(ctx, winX + 43, winY + 10, 4, 4, '#222447');
  }

  // Window mullions & sill
  rect(ctx, winX + winW / 2 - 1, winY, 2, winH, nightMode ? '#8B6B61' : '#DFAA7B');
  rect(ctx, winX, winY + winH / 2 - 1, winW, 2, nightMode ? '#8B6B61' : '#DFAA7B');
  px(ctx, winX + 5, winY + 6, 'rgba(255,255,255,0.45)');
  px(ctx, winX + 6, winY + 5, 'rgba(255,255,255,0.45)');
  rect(ctx, winX - 4, winY + winH + 2, winW + 8, 3, '#5A392C');
  rect(ctx, winX - 3, winY + winH + 2, winW + 6, 2, nightMode ? '#9E7B6E' : '#F2C79B');

  if (weather === 'snow') {
    rect(ctx, winX - 3, winY - 4, winW + 6, 2, '#FFFFFF');
    rect(ctx, winX - 2, winY + winH + 1, winW + 4, 2, '#FFFFFF');
  }
}

/**
 * Cozy 2nd-Floor Loft Platform + Cute Climbable Ladder + Curved Slide!
 */
function drawLoftStructure(
  ctx: CanvasRenderingContext2D,
  theme: AquariumTheme,
  nightMode: boolean,
  rainbowSlide: boolean,
  flowerLoft: boolean,
  timeSec: number
) {
  const pal = THEME_PALETTES[theme];
  const { minX, maxX, y } = LOFT_SPEC;
  const w = maxX - minX;

  // 1) Support pillars descending down to floor
  const pillarCol = nightMode ? '#8A6752' : pal.loftWoodShadow;
  const pillarHi = nightMode ? '#A68068' : pal.loftWood;
  rect(ctx, minX + 1, y + 6, 5, FLOOR_TOP_Y - y - 4, '#5A392C');
  rect(ctx, minX + 2, y + 6, 3, FLOOR_TOP_Y - y - 4, pillarCol);
  rect(ctx, minX + 2, y + 6, 1, FLOOR_TOP_Y - y - 4, pillarHi);

  rect(ctx, maxX - 10, y + 6, 5, FLOOR_TOP_Y - y - 4, '#5A392C');
  rect(ctx, maxX - 9, y + 6, 3, FLOOR_TOP_Y - y - 4, pillarCol);
  rect(ctx, maxX - 9, y + 6, 1, FLOOR_TOP_Y - y - 4, pillarHi);

  // 2) Cute Loft Safety Railing (leaves gap at ladder x=58..72 and slide exit at right!)
  const railTopY = y - 9;
  // Left railing segment (x=minX..56)
  rect(ctx, minX, railTopY, 34, 3, '#5A392C');
  rect(ctx, minX + 1, railTopY + 1, 32, 1, pal.loftWoodHi);
  for (let pxX = minX + 3; pxX <= 53; pxX += 7) {
    rect(ctx, pxX, railTopY + 2, 3, 7, '#5A392C');
    rect(ctx, pxX + 1, railTopY + 2, 1, 7, pal.loftWood);
  }
  // Center-right railing segment (x=74..138)
  rect(ctx, 74, railTopY, 64, 3, '#5A392C');
  rect(ctx, 75, railTopY + 1, 62, 1, pal.loftWoodHi);
  for (let pxX = 77; pxX <= 134; pxX += 8) {
    rect(ctx, pxX, railTopY + 2, 3, 7, '#5A392C');
    rect(ctx, pxX + 1, railTopY + 2, 1, 7, pal.loftWood);
  }
  // Cute heart/star rail finials
  rect(ctx, minX - 1, railTopY - 2, 4, 3, '#FF9BB8');
  rect(ctx, 73, railTopY - 2, 4, 3, '#FFE066');
  rect(ctx, 136, railTopY - 2, 4, 3, '#FF9BB8');

  // 3) 2nd Floor Main Wooden Deck
  rect(ctx, minX - 2, y, w + 4, 7, '#5A392C');
  rect(ctx, minX - 1, y + 1, w + 2, 5, nightMode ? '#A67F64' : pal.loftWood);
  rect(ctx, minX - 1, y + 1, w + 2, 2, nightMode ? '#BD977B' : pal.loftWoodHi);
  rect(ctx, minX - 1, y + 5, w + 2, 1, nightMode ? '#7A5B47' : pal.loftWoodShadow);

  // Cute Loft Cloud/Flower Mat on 2nd floor
  const matX = LOFT_SPEC.loftMat.x - 12;
  const matY = y - 3;
  rect(ctx, matX, matY, 24, 4, '#5A392C');
  rect(ctx, matX + 1, matY + 1, 22, 2, flowerLoft ? '#FFD6E8' : '#FFF1C9');
  if (flowerLoft) {
    // Mini potted sprout + flower garland on loft!
    rect(ctx, minX + 6, y - 6, 7, 6, '#5A392C');
    rect(ctx, minX + 7, y - 5, 5, 4, '#FF9EBB');
    rect(ctx, minX + 9, y - 9, 2, 3, '#69D471');
    rect(ctx, minX + 8, y - 11, 4, 3, '#FFE066');
    px(ctx, minX + 9, y - 10, '#FF6B93');

    const blink = Math.floor(timeSec * 3) % 2 === 0;
    px(ctx, matX + 4, matY + 1, blink ? '#FF6B93' : '#85D8FF');
    px(ctx, matX + 18, matY + 1, !blink ? '#FF6B93' : '#FFE066');
  }

  // 4) CUTE CLIMBABLE WOODEN LADDER (from ground x=70,y=148 up to loft x=64,y=84)
  const rungColors = ['#FFB5C8', '#FFE59E', '#B5EAD7', '#C7CEEA', '#FFDAC1', '#FFB5C8', '#FFE59E'];
  const steps = 42;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const pt = getLadderPoint(t);
    const lx = Math.round(pt.x - 6);
    const rx = Math.round(pt.x + 5);
    const py = Math.round(pt.y);
    // Left and right wooden rails
    rect(ctx, lx, py, 2, 2, '#5A392C');
    px(ctx, lx, py, '#DFAA7B');
    rect(ctx, rx, py, 2, 2, '#5A392C');
    px(ctx, rx, py, '#DFAA7B');
  }
  // 7 colorful pastel rungs
  for (let r = 1; r <= 7; r++) {
    const t = r / 8;
    const pt = getLadderPoint(t);
    const rx = Math.round(pt.x - 5);
    const ry = Math.round(pt.y);
    rect(ctx, rx, ry - 1, 11, 3, '#5A392C');
    rect(ctx, rx, ry, 11, 1, rungColors[r - 1]);
  }

  // 5) SMOOTH CURVED SLIDE (from loft right x=144,y=84 down to ground x=202,y=152)
  const rainbowCols = ['#FF9BB8', '#FFD19A', '#FFF099', '#B5EAD7', '#A5D8FF', '#D6C7FF'];
  const slideSteps = 56;
  // Dark outline underside first
  for (let i = 0; i <= slideSteps; i++) {
    const t = i / slideSteps;
    const pt = getSlidePoint(t);
    rect(ctx, Math.round(pt.x - 4), Math.round(pt.y - 2), 9, 7, '#5A392C');
  }
  // Smooth colored slide chute body
  for (let i = 0; i <= slideSteps; i++) {
    const t = i / slideSteps;
    const pt = getSlidePoint(t);
    const sx = Math.round(pt.x - 3);
    const sy = Math.round(pt.y - 1);
    const colIdx = Math.floor(t * rainbowCols.length) % rainbowCols.length;
    const bodyCol = rainbowSlide ? rainbowCols[colIdx] : pal.slideMain;
    const hiCol = rainbowSlide ? '#FFFFFF' : pal.slideHi;
    rect(ctx, sx, sy, 7, 4, bodyCol);
    rect(ctx, sx, sy, 7, 1, hiCol);
    px(ctx, sx, sy + 3, pal.slideShadow);
  }
  // Cute safety side-guard rails at top & bottom lip of slide
  rect(ctx, LOFT_SPEC.slideTop.x - 4, LOFT_SPEC.slideTop.y - 6, 4, 6, '#5A392C');
  rect(ctx, LOFT_SPEC.slideTop.x - 3, LOFT_SPEC.slideTop.y - 5, 2, 4, '#FFE066');
}

function drawIglooStash(
  ctx: CanvasRenderingContext2D,
  bx: number,
  by: number,
  stash: TreatKind[]
) {
  if (stash.length === 0) return;
  const maxShow = Math.min(10, stash.length);
  for (let i = 0; i < maxShow; i++) {
    const item = stash[i];
    const row = Math.floor(i / 4);
    const col = i % 4;
    const sx = bx - 5 + col * 3 + (row % 2);
    const sy = by - row * 2;
    if (item === 'strawberry') {
      rect(ctx, sx, sy - 2, 3, 2, '#5A392C');
      rect(ctx, sx, sy - 1, 2, 2, '#FF5478');
      px(ctx, sx, sy - 2, '#69D471');
    } else if (item === 'corn') {
      rect(ctx, sx, sy - 1, 3, 2, '#5A392C');
      rect(ctx, sx, sy - 1, 2, 1, '#FFD54F');
    } else {
      px(ctx, sx, sy, '#4F3C35');
      px(ctx, sx + 1, sy, '#E6DDD5');
      px(ctx, sx + 1, sy - 1, '#4F3C35');
    }
  }
}

function drawHouseBack(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  theme: AquariumTheme,
  nightMode: boolean
) {
  const pal = THEME_PALETTES[theme];
  const x = cx - 22;
  const y = baseY - 28;
  const body = nightMode ? '#7EA6A0' : pal.houseBody;
  const light = nightMode ? '#9EC4BE' : pal.houseLight;
  const shadow = nightMode ? '#5E827D' : pal.houseShadow;
  const trim = '#5A392C';

  rect(ctx, x + 7, y - 4, 8, 6, trim);
  rect(ctx, x + 8, y - 3, 6, 5, body);
  rect(ctx, x + 9, y - 2, 4, 3, '#FFA6B8');

  rect(ctx, x + 29, y - 4, 8, 6, trim);
  rect(ctx, x + 30, y - 3, 6, 5, body);
  rect(ctx, x + 31, y - 2, 4, 3, '#FFA6B8');

  rect(ctx, x + 4, y + 1, 36, 27, trim);
  rect(ctx, x + 2, y + 5, 40, 23, trim);
  rect(ctx, x, y + 11, 44, 17, trim);

  rect(ctx, x + 5, y + 2, 34, 25, body);
  rect(ctx, x + 3, y + 6, 38, 21, body);
  rect(ctx, x + 1, y + 12, 42, 15, body);

  rect(ctx, x + 6, y + 4, 18, 4, light);
  rect(ctx, x + 4, y + 8, 8, 6, light);
  rect(ctx, x + 1, y + 23, 42, 4, shadow);

  rect(ctx, x + 13, y + 11, 18, 17, trim);
  rect(ctx, x + 11, y + 14, 22, 14, trim);
  rect(ctx, x + 14, y + 12, 16, 15, '#2E1E1B');
  rect(ctx, x + 12, y + 15, 20, 12, '#2E1E1B');
}

export function drawHouseFrontArch(
  ctx: CanvasRenderingContext2D,
  theme: AquariumTheme,
  nightMode: boolean
) {
  const pal = THEME_PALETTES[theme];
  const cx = PROP_POS.igloo.x;
  const baseY = PROP_POS.igloo.y;
  const x = cx - 22;
  const y = baseY - 28;
  const body = nightMode ? '#7EA6A0' : pal.houseBody;
  const shadow = nightMode ? '#5E827D' : pal.houseShadow;
  const trim = '#5A392C';

  rect(ctx, x + 13, y + 10, 18, 2, trim);
  rect(ctx, x + 11, y + 12, 3, 4, trim);
  rect(ctx, x + 30, y + 12, 3, 4, trim);
  rect(ctx, x + 10, y + 15, 3, 12, body);
  rect(ctx, x + 31, y + 15, 3, 12, body);
  rect(ctx, x + 10, y + 23, 3, 4, shadow);
  rect(ctx, x + 31, y + 23, 3, 4, shadow);
  rect(ctx, x + 12, y + 15, 1, 12, trim);
  rect(ctx, x + 31, y + 15, 1, 12, trim);
}

function drawCushion(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  theme: AquariumTheme
) {
  const pal = THEME_PALETTES[theme];
  const x = cx - 15;
  const y = baseY - 6;
  rect(ctx, x + 2, y - 1, 26, 8, '#5A392C');
  rect(ctx, x, y + 1, 30, 5, '#5A392C');
  rect(ctx, x + 3, y, 24, 6, pal.cushionMain);
  rect(ctx, x + 1, y + 2, 28, 3, pal.cushionMain);
  rect(ctx, x + 4, y + 1, 20, 2, pal.cushionHi);
  rect(ctx, x + 3, y + 5, 24, 1, pal.cushionShadow);
  px(ctx, cx, y + 2, pal.cushionShadow);
  px(ctx, cx - 1, y + 2, pal.cushionShadow);
}

function drawBeddingPileBack(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  theme: AquariumTheme,
  nightMode: boolean
) {
  const pal = THEME_PALETTES[theme];
  const main = nightMode ? '#9C7E66' : pal.pileMain;
  const hi = nightMode ? '#B5967C' : pal.pileLight;
  const x = cx - 16;
  const y = baseY - 12;

  rect(ctx, x + 6, y, 20, 10, '#5A392C');
  rect(ctx, x + 3, y + 3, 26, 8, '#5A392C');
  rect(ctx, x + 7, y + 1, 18, 9, main);
  rect(ctx, x + 4, y + 4, 24, 7, main);
  rect(ctx, x + 9, y + 2, 12, 3, hi);
}

export function drawBeddingPileFront(
  ctx: CanvasRenderingContext2D,
  theme: AquariumTheme,
  nightMode: boolean,
  timeSec: number,
  hasBuriedHamster: boolean
) {
  const pal = THEME_PALETTES[theme];
  const cx = PROP_POS.pile.x;
  const baseY = PROP_POS.pile.y;
  const main = nightMode ? '#9C7E66' : pal.pileMain;
  const hi = nightMode ? '#B5967C' : pal.pileLight;
  const sh = nightMode ? '#755D4B' : pal.pileShadow;

  const wiggle = hasBuriedHamster && Math.sin(timeSec * 8) > 0.65 ? 1 : 0;
  const x = cx - 17 + wiggle;
  const y = baseY - 8;

  rect(ctx, x + 2, y + 2, 30, 8, '#5A392C');
  rect(ctx, x, y + 4, 34, 6, '#5A392C');
  rect(ctx, x + 4, y, 26, 6, '#5A392C');

  rect(ctx, x + 5, y + 1, 24, 7, main);
  rect(ctx, x + 2, y + 4, 30, 5, main);
  rect(ctx, x + 7, y + 2, 16, 2, hi);
  rect(ctx, x + 3, y + 7, 28, 2, sh);

  rect(ctx, x + 6, y + 4, 3, 1, hi);
  rect(ctx, x + 15, y + 3, 4, 1, hi);
  rect(ctx, x + 22, y + 5, 3, 1, sh);
  rect(ctx, x + 10, y + 6, 3, 1, sh);
  px(ctx, x + 19, y + 1, '#FFE08A');
  px(ctx, x + 8, y + 2, '#FFB5C8');
}

function drawWheelBack(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  nightMode: boolean
) {
  const r = PROP_POS.wheel.radius;

  rect(ctx, cx - 3, cy, 6, 26, '#5A392C');
  rect(ctx, cx - 2, cy + 1, 4, 24, '#C78E5D');
  rect(ctx, cx - 18, cy + 24, 36, 4, '#5A392C');
  rect(ctx, cx - 17, cy + 25, 34, 2, '#DFAA7B');

  for (let dy = -r; dy <= r; dy++) {
    for (let dx = -r; dx <= r; dx++) {
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist <= r && dist >= r - 2.2) {
        px(ctx, cx + dx, cy + dy, '#5A392C');
      } else if (dist < r - 2.2 && dist >= r - 5.4) {
        px(ctx, cx + dx, cy + dy, nightMode ? '#C9A47C' : '#FFE0AD');
      } else if (dist < r - 5.4) {
        px(ctx, cx + dx, cy + dy, nightMode ? '#4A3F57' : '#FFF7E8');
      }
    }
  }
}

export function drawWheelSpokes(
  ctx: CanvasRenderingContext2D,
  wheelAngle: number,
  wheelSpeed: number
) {
  const { x: cx, y: cy, radius } = PROP_POS.wheel;
  const r = radius - 4;

  const treadCount = 12;
  for (let i = 0; i < treadCount; i++) {
    const ang = wheelAngle + (i * Math.PI * 2) / treadCount;
    const tx = Math.round(cx + Math.cos(ang) * (radius - 3.6));
    const ty = Math.round(cy + Math.sin(ang) * (radius - 3.6));
    const col = i % 2 === 0 ? '#FF9BB8' : '#E8BA84';
    rect(ctx, tx, ty, 2, 2, col);
  }

  for (let i = 0; i < 6; i++) {
    const ang = wheelAngle + (i * Math.PI) / 3;
    for (let step = 4; step <= r - 2; step++) {
      const sx = Math.round(cx + Math.cos(ang) * step);
      const sy = Math.round(cy + Math.sin(ang) * step);
      px(ctx, sx, sy, i % 2 === 0 ? '#E8BA84' : '#F5D3A6');
    }
  }

  rect(ctx, cx - 3, cy - 3, 6, 6, '#5A392C');
  rect(ctx, cx - 2, cy - 2, 4, 4, '#FFB8C8');
  const petalAng = wheelAngle;
  for (let p = 0; p < 4; p++) {
    const a = petalAng + (p * Math.PI) / 2;
    px(
      ctx,
      Math.round(cx + Math.cos(a) * 2),
      Math.round(cy + Math.sin(a) * 2),
      '#FFF5F7'
    );
  }
  px(ctx, cx, cy, '#FFE066');

  if (Math.abs(wheelSpeed) > 8.5) {
    const flicker = Math.floor(wheelAngle * 4) % 2 === 0;
    if (flicker) {
      rect(ctx, cx - 15, cy - 16, 5, 1, '#FFFFFF');
      rect(ctx, cx + 9, cy - 17, 6, 1, '#FFE8B8');
    } else {
      rect(ctx, cx - 18, cy - 11, 4, 1, '#FFE8B8');
      rect(ctx, cx + 12, cy - 13, 5, 1, '#FFFFFF');
    }
  }
}

export function drawWheelFrontRim(ctx: CanvasRenderingContext2D, wheelAngle: number) {
  const { x: cx, y: cy, radius } = PROP_POS.wheel;
  for (let deg = 25; deg <= 155; deg += 5) {
    const rad = (deg * Math.PI) / 180;
    const fx = Math.round(cx + Math.cos(rad) * (radius - 1.5));
    const fy = Math.round(cy + Math.sin(rad) * (radius - 1.5));
    px(ctx, fx, fy, '#5A392C');
    const fxIn = Math.round(cx + Math.cos(rad) * (radius - 2.6));
    const fyIn = Math.round(cy + Math.sin(rad) * (radius - 2.6));
    px(ctx, fxIn, fyIn, '#FFD8B0');
  }
  for (let i = 0; i < 6; i++) {
    const ang = ((wheelAngle + (i * Math.PI) / 3) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2);
    if (ang > 0.35 && ang < Math.PI - 0.35) {
      const gx = Math.round(cx + Math.cos(ang) * (radius - 2.4));
      const gy = Math.round(cy + Math.sin(ang) * (radius - 2.4));
      px(ctx, gx, gy, '#FF9BB8');
    }
  }
}

export function drawTerrariumForeground(
  ctx: CanvasRenderingContext2D,
  theme: AquariumTheme,
  bowlSeeds: number,
  waterLevel: number,
  treats: TreatItem[],
  nightMode: boolean,
  weather: WeatherMode,
  wheelAngle: number,
  timeSec: number,
  fairyLightStyle: FairyLightStyle
) {
  const pal = THEME_PALETTES[theme];

  drawWheelFrontRim(ctx, wheelAngle);

  drawLargeWaterBottle(
    ctx,
    PROP_POS.bottle.x,
    PROP_POS.bottle.y,
    waterLevel,
    pal.bottleCap,
    timeSec
  );

  drawFoodBowl(ctx, PROP_POS.bowl.x, PROP_POS.bowl.y, bowlSeeds);

  for (const t of treats) {
    drawTreat(ctx, t);
  }

  // Cozy lighting / weather indoor atmosphere
  if (nightMode) {
    ctx.fillStyle = 'rgba(20, 16, 46, 0.28)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
  } else if (weather === 'rain') {
    ctx.fillStyle = 'rgba(78, 112, 166, 0.12)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
    // Subtle cozy rain condensation shimmer near window edge
    for (let i = 0; i < 14; i++) {
      const rx = (i * 29 + Math.floor(timeSec * 12)) % VIRTUAL_W;
      const ry = 14 + ((i * 19 + Math.floor(timeSec * 28)) % 22);
      ctx.fillStyle = 'rgba(200, 234, 255, 0.18)';
      ctx.fillRect(rx, ry, 1, 2);
    }
  } else if (weather === 'snow') {
    ctx.fillStyle = 'rgba(205, 228, 255, 0.08)';
    ctx.fillRect(0, 0, VIRTUAL_W, VIRTUAL_H);
  } else {
    ctx.fillStyle = 'rgba(255, 250, 210, 0.08)';
    ctx.beginPath();
    ctx.moveTo(194, 20);
    ctx.lineTo(256, 20);
    ctx.lineTo(186, FLOOR_TOP_Y + 26);
    ctx.lineTo(114, FLOOR_TOP_Y + 26);
    ctx.closePath();
    ctx.fill();
  }

  // Gorgeous Decorative Fairy Lights ("Lampu Hias Indahhh")!
  if (fairyLightStyle !== 'none') {
    drawFairyLights(ctx, fairyLightStyle, timeSec, nightMode);
  }
}

/**
 * Draped 16-bit Fairy Lights + Hanging Star/Sakura Lanterns with multi-layer warm glow halos!
 */
function drawFairyLights(
  ctx: CanvasRenderingContext2D,
  style: Exclude<FairyLightStyle, 'none'>,
  timeSec: number,
  nightMode: boolean
) {
  const palettes: Record<Exclude<FairyLightStyle, 'none'>, string[]> = {
    'warm-gold': ['#FFF6B3', '#FFE066', '#FFC44D', '#FFE89E'],
    'pastel-rainbow': ['#FF9EC4', '#FFE680', '#9FF2CF', '#A5DCFF', '#D6B8FF'],
    'sakura-glow': ['#FFB5CE', '#FFD6E6', '#FF85AE', '#FFF0F5'],
  };
  const colors = palettes[style];

  // Draw draped wire across 3 cozy arches along top of terrarium & underside of loft!
  const spans = [
    { x0: 0, x1: 102, sag: 11, baseY: 8 },
    { x0: 102, x1: 204, sag: 10, baseY: 8 },
    { x0: 204, x1: VIRTUAL_W, sag: 11, baseY: 8 },
    // Under-loft warm fairy string!
    { x0: LOFT_SPEC.minX + 4, x1: LOFT_SPEC.maxX - 8, sag: 5, baseY: LOFT_SPEC.y + 7 },
  ];

  for (let sIdx = 0; sIdx < spans.length; sIdx++) {
    const sp = spans[sIdx];
    const len = sp.x1 - sp.x0;
    for (let x = sp.x0; x <= sp.x1; x += 2) {
      const t = (x - sp.x0) / len;
      const wy = Math.round(sp.baseY + Math.sin(t * Math.PI) * sp.sag);
      px(ctx, x, wy, '#5A392C');
    }

    const bulbCount = sIdx === 3 ? 6 : 7;
    for (let b = 1; b < bulbCount; b++) {
      const t = b / bulbCount;
      const bx = Math.round(sp.x0 + t * len);
      const by = Math.round(sp.baseY + Math.sin(t * Math.PI) * sp.sag) + 2;
      const col = colors[(b + sIdx * 2) % colors.length];
      const twinkle = 0.65 + 0.35 * Math.sin(timeSec * 3.8 + b * 1.3 + sIdx);
      const glowAlpha = (nightMode ? 0.32 : 0.17) * twinkle;

      // Soft multi-layer radial glow halo
      ctx.save();
      ctx.fillStyle = col;
      ctx.globalAlpha = glowAlpha * 0.45;
      ctx.beginPath();
      ctx.arc(bx, by + 1, 9, 0, Math.PI * 2);
      ctx.fill();

      ctx.globalAlpha = glowAlpha;
      ctx.beginPath();
      ctx.arc(bx, by + 1, 5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Bulb socket & crisp pixel bulb
      rect(ctx, bx - 1, by - 1, 2, 1, '#5A392C');
      rect(ctx, bx - 1, by, 3, 3, '#5A392C');
      rect(ctx, bx - 1, by, 2, 2, col);
      px(ctx, bx - 1, by, '#FFFFFF');

      // Hanging star lantern on middle bulb of top arches
      if (sIdx < 3 && b === 3) {
        rect(ctx, bx, by + 2, 1, 2, '#5A392C');
        rect(ctx, bx - 2, by + 4, 5, 5, '#5A392C');
        rect(ctx, bx - 1, by + 5, 3, 3, col);
        px(ctx, bx, by + 6, '#FFFFFF');
      }
    }
  }
}

function drawLargeWaterBottle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  waterLevel: number,
  capColor: string,
  timeSec: number
) {
  rect(ctx, x - 11, y - 34, 24, 5, '#5A392C');
  rect(ctx, x - 10, y - 33, 22, 3, '#FFC7D8');
  rect(ctx, x - 11, y - 14, 24, 5, '#5A392C');
  rect(ctx, x - 10, y - 13, 22, 3, '#FFC7D8');

  rect(ctx, x - 5, y - 44, 12, 5, '#5A392C');
  rect(ctx, x - 4, y - 43, 10, 3, capColor);

  rect(ctx, x - 10, y - 40, 22, 40, '#5A392C');
  rect(ctx, x - 9, y - 39, 20, 38, '#EBF9FF');

  const maxFillH = 34;
  const fillH = Math.max(3, Math.round((waterLevel / 100) * maxFillH));
  const waterTop = y - 1 - fillH;
  rect(ctx, x - 9, waterTop, 20, fillH, '#7CD4FF');
  rect(ctx, x - 9, waterTop, 20, 3, '#BCEEFF');
  rect(ctx, x - 9, y - 5, 20, 4, '#59BBE8');

  const bubOffset = Math.floor((timeSec * 5) % Math.max(4, fillH - 2));
  if (fillH > 6) {
    px(ctx, x + 2, y - 3 - bubOffset, '#EBF9FF');
    px(ctx, x - 2, y - 2 - ((bubOffset + 6) % Math.max(4, fillH - 2)), '#FFFFFF');
  }
  for (let m = 0; m < 4; m++) {
    rect(ctx, x + 6, y - 9 - m * 8, 3, 1, '#5A392C');
  }

  rect(ctx, x - 7, y - 37, 3, 33, '#FFFFFF');
  rect(ctx, x - 3, y - 37, 1, 18, 'rgba(255,255,255,0.65)');

  rect(ctx, x - 7, y, 16, 7, '#5A392C');
  rect(ctx, x - 6, y + 1, 14, 5, capColor);
  rect(ctx, x - 5, y + 1, 12, 2, '#FFD9E3');

  rect(ctx, x - 11, y + 7, 10, 5, '#5A392C');
  rect(ctx, x - 14, y + 11, 7, 10, '#5A392C');
  rect(ctx, x - 10, y + 8, 8, 3, '#DDE8F0');
  rect(ctx, x - 13, y + 12, 5, 8, '#C3D3DF');
  rect(ctx, x - 12, y + 12, 2, 7, '#FFFFFF');
  rect(ctx, x - 14, y + 20, 3, 2, '#9EB2C2');
  const drip = Math.sin(timeSec * 3.5) > 0.3 ? 1 : 0;
  rect(ctx, x - 14, y + 22 + drip, 2, 2, '#7CD4FF');
  px(ctx, x - 14, y + 22 + drip, '#FFFFFF');
}

function drawFoodBowl(
  ctx: CanvasRenderingContext2D,
  cx: number,
  baseY: number,
  bowlSeeds: number
) {
  const x = cx - 11;
  const y = baseY - 7;
  ctx.fillStyle = 'rgba(130, 96, 68, 0.25)';
  ctx.fillRect(x - 1, y + 8, 24, 2);

  rect(ctx, x, y, 22, 8, '#5A392C');
  rect(ctx, x + 2, y + 7, 18, 2, '#5A392C');
  rect(ctx, x + 1, y + 1, 20, 6, '#FF9EBB');
  rect(ctx, x + 1, y + 1, 20, 2, '#FFC4D6');
  rect(ctx, x + 3, y + 5, 16, 2, '#E57C9D');
  rect(ctx, x + 3, y + 1, 16, 2, '#7A4F3D');

  if (bowlSeeds > 0) {
    const count = Math.min(8, Math.ceil(bowlSeeds / 12));
    for (let i = 0; i < count; i++) {
      const sx = x + 4 + ((i * 3) % 13);
      const sy = y - (i >= 4 ? 1 : 0);
      px(ctx, sx, sy, i % 2 === 0 ? '#4F3C35' : '#D9CFC7');
      px(ctx, sx + 1, sy, i % 2 === 0 ? '#D9CFC7' : '#FFD54F');
    }
  }
}

function drawTreat(ctx: CanvasRenderingContext2D, t: TreatItem) {
  const x = Math.round(t.x);
  const y = Math.round(t.y);
  ctx.fillStyle = 'rgba(130, 96, 68, 0.25)';
  ctx.fillRect(x - 2, y + 2, 5, 1);

  if (t.type === 'strawberry') {
    rect(ctx, x - 3, y - 3, 6, 5, '#5A392C');
    rect(ctx, x - 2, y - 2, 4, 3, '#FF5478');
    px(ctx, x - 1, y - 1, '#FF9EB3');
    px(ctx, x + 1, y, '#FFE49E');
    rect(ctx, x - 2, y - 4, 4, 2, '#69D471');
  } else if (t.type === 'corn') {
    rect(ctx, x - 2, y - 2, 5, 4, '#5A392C');
    rect(ctx, x - 1, y - 1, 3, 2, '#FFD54F');
    px(ctx, x, y - 1, '#FFF3B0');
  } else {
    rect(ctx, x - 2, y - 2, 5, 4, '#5A392C');
    px(ctx, x - 1, y - 1, '#4A3A35');
    px(ctx, x, y - 1, '#E6DDD5');
    px(ctx, x + 1, y - 1, '#4A3A35');
    px(ctx, x - 1, y, '#E6DDD5');
    px(ctx, x, y, '#4A3A35');
  }
}

export function drawParticles(ctx: CanvasRenderingContext2D, particles: PixelParticle[]) {
  for (const p of particles) {
    const x = Math.round(p.x);
    const y = Math.round(p.y);
    const alpha = Math.min(1, p.life / (p.maxLife * 0.35));
    ctx.save();
    ctx.globalAlpha = Math.max(0.15, alpha);

    if (p.kind === 'heart') {
      drawMatrix(ctx, x - 3, y - 3, HEART_SPRITE, {
        R: p.color || '#FF6B93',
        W: '#FFE5EC',
      });
    } else if (p.kind === 'note') {
      drawMatrix(ctx, x - 2, y - 3, NOTE_SPRITE, { N: p.color || '#FF8CB0' });
    } else if (p.kind === 'zzz') {
      drawMatrix(ctx, x - 2, y - 2, ZZZ_SPRITE, { Z: p.color || '#9FB4FF' });
    } else if (p.kind === 'star') {
      drawMatrix(ctx, x - 2, y - 2, STAR_SPRITE, {
        S: p.color || '#FFE066',
        W: '#FFFFFF',
      });
    } else if (p.kind === 'coin') {
      drawMatrix(ctx, x - 2, y - 2, COIN_SPRITE, {
        G: '#D98E2B',
        Y: '#FFE066',
        W: '#FFFFFF',
      });
    } else if (p.kind === 'bap') {
      rect(ctx, x - 2, y - 1, 5, 3, '#FFFFFF');
      rect(ctx, x - 1, y - 2, 3, 5, '#FFFFFF');
      px(ctx, x, y, p.color || '#FFB5C8');
    } else if (p.kind === 'sparkle') {
      const big = Math.floor(p.life * 8) % 2 === 0;
      px(ctx, x, y, '#FFFFFF');
      if (big) {
        px(ctx, x - 1, y, p.color);
        px(ctx, x + 1, y, p.color);
        px(ctx, x, y - 1, p.color);
        px(ctx, x, y + 1, p.color);
      }
    } else if (p.kind === 'fluff') {
      rect(ctx, x, y, 2, 2, p.color || '#FFF7EB');
    } else if (p.kind === 'exclaim') {
      rect(ctx, x - 2, y - 7, 5, 8, '#5A392C');
      rect(ctx, x - 1, y - 6, 3, 6, '#FFFDF7');
      rect(ctx, x, y - 5, 1, 3, '#FF5C8A');
      px(ctx, x, y - 1, '#FF5C8A');
    } else if (p.kind === 'question') {
      rect(ctx, x - 3, y - 7, 7, 8, '#5A392C');
      rect(ctx, x - 2, y - 6, 5, 6, '#FFFDF7');
      px(ctx, x - 1, y - 5, '#6C8CE8');
      px(ctx, x, y - 5, '#6C8CE8');
      px(ctx, x + 1, y - 4, '#6C8CE8');
      px(ctx, x, y - 3, '#6C8CE8');
      px(ctx, x, y - 1, '#6C8CE8');
    } else {
      const sz = p.size || 1;
      rect(ctx, x, y, sz, sz, p.color);
    }
    ctx.restore();
  }
}

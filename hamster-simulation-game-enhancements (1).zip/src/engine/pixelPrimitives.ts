export function px(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), 1, 1);
}

export function rect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string
) {
  ctx.fillStyle = color;
  ctx.fillRect(Math.round(x), Math.round(y), Math.round(w), Math.round(h));
}

export function drawMatrix(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rows: string[],
  palette: Record<string, string>,
  flipX = false
) {
  const rx = Math.round(x);
  const ry = Math.round(y);
  for (let row = 0; row < rows.length; row++) {
    const line = rows[row];
    for (let col = 0; col < line.length; col++) {
      const ch = line[col];
      if (ch === '.' || ch === ' ') continue;
      const color = palette[ch];
      if (!color) continue;
      const drawX = flipX ? rx + (line.length - 1 - col) : rx + col;
      ctx.fillStyle = color;
      ctx.fillRect(drawX, ry + row, 1, 1);
    }
  }
}

export interface PuddingDeform {
  scaleX: number; // >1 wider when squished/squeezed
  scaleY: number; // <1 flatter when squished/squeezed
  wobbleX: number; // horizontal top wobble offset in pixels
}

/**
 * Mini integer pixel buffer that lets us compose overlapping fluffy shapes
 * (ears, chubby cheeks, pear body, tail, paws, accessories) and automatically apply a crisp
 * 1px 16-bit pixel outline + elastic pudding squash/wobble deformation!
 */
export class PixelSpriteBuffer {
  public readonly w: number;
  public readonly h: number;
  private grid: (string | null)[][];
  private outlineMask: boolean[][];

  constructor(w: number, h: number) {
    this.w = w;
    this.h = h;
    this.grid = Array.from({ length: h }, () => Array<string | null>(w).fill(null));
    this.outlineMask = Array.from({ length: h }, () => Array<boolean>(w).fill(false));
  }

  public set(x: number, y: number, color: string, outlineable = true) {
    const ix = Math.round(x);
    const iy = Math.round(y);
    if (ix < 0 || ix >= this.w || iy < 0 || iy >= this.h) return;
    this.grid[iy][ix] = color;
    if (outlineable) {
      this.outlineMask[iy][ix] = true;
    }
  }

  public has(x: number, y: number): boolean {
    const ix = Math.round(x);
    const iy = Math.round(y);
    if (ix < 0 || ix >= this.w || iy < 0 || iy >= this.h) return false;
    return this.grid[iy][ix] !== null;
  }

  public fillEllipse(
    cx: number,
    cy: number,
    rx: number,
    ry: number,
    color: string,
    outlineable = true
  ) {
    const x0 = Math.floor(cx - rx - 1);
    const x1 = Math.ceil(cx + rx + 1);
    const y0 = Math.floor(cy - ry - 1);
    const y1 = Math.ceil(cy + ry + 1);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1.0) {
          this.set(x, y, color, outlineable);
        }
      }
    }
  }

  public fillCircle(
    cx: number,
    cy: number,
    r: number,
    color: string,
    outlineable = true
  ) {
    this.fillEllipse(cx, cy, r, r, color, outlineable);
  }

  public paintIfFilled(
    cx: number,
    cy: number,
    rx: number,
    ry: number,
    color: string
  ) {
    const x0 = Math.floor(cx - rx - 1);
    const x1 = Math.ceil(cx + rx + 1);
    const y0 = Math.floor(cy - ry - 1);
    const y1 = Math.ceil(cy + ry + 1);

    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        if (x < 0 || x >= this.w || y < 0 || y >= this.h) continue;
        if (this.grid[y][x] === null) continue;
        const dx = (x - cx) / rx;
        const dy = (y - cy) / ry;
        if (dx * dx + dy * dy <= 1.0) {
          this.grid[y][x] = color;
        }
      }
    }
  }

  public flush(
    ctx: CanvasRenderingContext2D,
    destX: number,
    destY: number,
    outlineColor: string,
    flipX = false,
    angleRad = 0,
    pivotLocalX = 28,
    pivotLocalY = 32,
    pudding?: PuddingDeform
  ) {
    const usePudding =
      pudding &&
      (Math.abs(pudding.scaleX - 1) > 0.015 ||
        Math.abs(pudding.scaleY - 1) > 0.015 ||
        Math.abs(pudding.wobbleX) > 0.12);

    // Non-rotated path (with optional elastic pudding squash/wobble!)
    if (Math.abs(angleRad) < 0.04) {
      if (!usePudding) {
        const ox = Math.round(destX);
        const oy = Math.round(destY);

        ctx.fillStyle = outlineColor;
        for (let y = 0; y < this.h; y++) {
          for (let x = 0; x < this.w; x++) {
            if (this.grid[y][x] !== null) continue;
            const n = y > 0 && this.outlineMask[y - 1][x];
            const s = y < this.h - 1 && this.outlineMask[y + 1][x];
            const w = x > 0 && this.outlineMask[y][x - 1];
            const e = x < this.w - 1 && this.outlineMask[y][x + 1];
            if (n || s || w || e) {
              const pxX = flipX ? ox + (this.w - 1 - x) : ox + x;
              ctx.fillRect(pxX, oy + y, 1, 1);
            }
          }
        }

        for (let y = 0; y < this.h; y++) {
          for (let x = 0; x < this.w; x++) {
            const col = this.grid[y][x];
            if (!col) continue;
            const pxX = flipX ? ox + (this.w - 1 - x) : ox + x;
            ctx.fillStyle = col;
            ctx.fillRect(pxX, oy + y, 1, 1);
          }
        }
        return;
      }

      // Elastic Pudding Deformation Path (bottom-anchored at y=42!)
      const ox = Math.round(destX);
      const oy = Math.round(destY);
      const anchorX = 28;
      const anchorY = 42;
      const sX = pudding!.scaleX;
      const sY = pudding!.scaleY;
      const wob = pudding!.wobbleX;

      const outW = this.w;
      const outH = this.h;
      const defGrid: (string | null)[][] = Array.from({ length: outH }, () =>
        Array<string | null>(outW).fill(null)
      );
      const defMask: boolean[][] = Array.from({ length: outH }, () =>
        Array<boolean>(outW).fill(false)
      );

      for (let dy = 0; dy < outH; dy++) {
        // Height ratio above feet (0 at feet, ~1 at top of ears)
        const hRatio = Math.max(0, Math.min(1.2, (anchorY - dy) / 22));
        // Pudding wobble shifts upper rows smoothly while keeping feet planted!
        const rowShift = wob * hRatio * hRatio;
        const srcY = Math.round(anchorY + (dy - anchorY) / sY);
        if (srcY < 0 || srcY >= this.h) continue;

        for (let dx = 0; dx < outW; dx++) {
          const srcXFloat = anchorX + (dx - anchorX - rowShift) / sX;
          const srcX = Math.round(flipX ? this.w - 1 - srcXFloat : srcXFloat);
          if (srcX < 0 || srcX >= this.w) continue;
          const c = this.grid[srcY][srcX];
          if (c) {
            defGrid[dy][dx] = c;
            defMask[dy][dx] = this.outlineMask[srcY][srcX];
          }
        }
      }

      // Crisp 1px pixel outline around deformed silhouette
      ctx.fillStyle = outlineColor;
      for (let y = 0; y < outH; y++) {
        for (let x = 0; x < outW; x++) {
          if (defGrid[y][x] !== null) continue;
          const n = y > 0 && defMask[y - 1][x];
          const s = y < outH - 1 && defMask[y + 1][x];
          const w = x > 0 && defMask[y][x - 1];
          const e = x < outW - 1 && defMask[y][x + 1];
          if (n || s || w || e) {
            ctx.fillRect(ox + x, oy + y, 1, 1);
          }
        }
      }

      for (let y = 0; y < outH; y++) {
        for (let x = 0; x < outW; x++) {
          const col = defGrid[y][x];
          if (!col) continue;
          ctx.fillStyle = col;
          ctx.fillRect(ox + x, oy + y, 1, 1);
        }
      }
      return;
    }

    // Rotated nearest-neighbor pixel stamp so ragdoll spinning looks 100% 16-bit crisp!
    const worldPivotX = Math.round(destX + (flipX ? this.w - 1 - pivotLocalX : pivotLocalX));
    const worldPivotY = Math.round(destY + pivotLocalY);
    const cos = Math.cos(angleRad);
    const sin = Math.sin(angleRad);
    const bound = 26;

    for (let dy = -bound; dy <= bound; dy++) {
      for (let dx = -bound; dx <= bound; dx++) {
        const rx = dx * cos + dy * sin;
        const ry = -dx * sin + dy * cos;
        const localX = Math.round(
          flipX ? this.w - 1 - (pivotLocalX + rx) : pivotLocalX + rx
        );
        const localY = Math.round(pivotLocalY + ry);
        if (localX < 0 || localX >= this.w || localY < 0 || localY >= this.h) continue;

        const col = this.grid[localY][localX];
        if (col) {
          ctx.fillStyle = col;
          ctx.fillRect(worldPivotX + dx, worldPivotY + dy, 1, 1);
        } else {
          const n = localY > 0 && this.outlineMask[localY - 1][localX];
          const s = localY < this.h - 1 && this.outlineMask[localY + 1][localX];
          const w = localX > 0 && this.outlineMask[localY][localX - 1];
          const e = localX < this.w - 1 && this.outlineMask[localY][localX + 1];
          if (n || s || w || e) {
            ctx.fillStyle = outlineColor;
            ctx.fillRect(worldPivotX + dx, worldPivotY + dy, 1, 1);
          }
        }
      }
    }
  }
}

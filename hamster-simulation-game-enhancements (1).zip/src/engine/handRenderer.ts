import { HamsterEntity } from '../types/hamster';

/**
 * Cute 16-bit player hand gently cradling the hamster from below while you drag it around!
 */
export function drawHeldHamsterHand(
  ctx: CanvasRenderingContext2D,
  hamster: HamsterEntity,
  timeSec: number
) {
  const hx = Math.round(hamster.x);
  const hy = Math.round(hamster.y);
  const sway = Math.sin(timeSec * 3) > 0 ? 0 : 1;

  const OUTLINE = '#5A392C';
  const SKIN = '#FFD4BC';
  const SKIN_SHADOW = '#E9AE94';
  const SKIN_HI = '#FFE7D8';
  const NAIL = '#FFC2D1';

  // Palm silhouette beneath the hamster belly
  ctx.fillStyle = OUTLINE;
  ctx.fillRect(hx - 13, hy - 8 + sway, 26, 11);
  ctx.fillRect(hx - 11, hy - 11 + sway, 22, 5);

  // Thumb wrapping on left side (like holding hamster gently)
  ctx.fillStyle = OUTLINE;
  ctx.fillRect(hx - 17, hy - 20 + sway, 7, 17);
  ctx.fillStyle = SKIN;
  ctx.fillRect(hx - 16, hy - 19 + sway, 5, 14);
  ctx.fillStyle = SKIN_HI;
  ctx.fillRect(hx - 16, hy - 19 + sway, 2, 9);
  ctx.fillStyle = NAIL;
  ctx.fillRect(hx - 15, hy - 18 + sway, 3, 3);

  // Index finger curling on right side of hamster belly
  ctx.fillStyle = OUTLINE;
  ctx.fillRect(hx + 10, hy - 19 + sway, 7, 16);
  ctx.fillStyle = SKIN;
  ctx.fillRect(hx + 11, hy - 18 + sway, 5, 13);
  ctx.fillStyle = SKIN_HI;
  ctx.fillRect(hx + 11, hy - 18 + sway, 2, 8);
  ctx.fillStyle = NAIL;
  ctx.fillRect(hx + 12, hy - 17 + sway, 3, 3);

  // Main palm soft peach color
  ctx.fillStyle = SKIN;
  ctx.fillRect(hx - 12, hy - 8 + sway, 24, 9);
  ctx.fillStyle = SKIN_HI;
  ctx.fillRect(hx - 10, hy - 7 + sway, 20, 2);
  ctx.fillStyle = SKIN_SHADOW;
  ctx.fillRect(hx - 11, hy - 1 + sway, 22, 2);

  // Wrist descending downward
  ctx.fillStyle = OUTLINE;
  ctx.fillRect(hx - 8, hy + 2 + sway, 16, 18);
  ctx.fillStyle = SKIN;
  ctx.fillRect(hx - 7, hy + 2 + sway, 14, 18);
  ctx.fillStyle = SKIN_SHADOW;
  ctx.fillRect(hx + 3, hy + 2 + sway, 4, 18);
  ctx.fillStyle = SKIN_HI;
  ctx.fillRect(hx - 6, hy + 2 + sway, 3, 16);
}

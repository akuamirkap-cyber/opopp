import { HamsterCoat, HamsterEntity } from '../types/hamster';
import { PixelSpriteBuffer, PuddingDeform } from './pixelPrimitives';

const PAW_PINK = '#FFB8C8';
const PAW_SHADOW = '#E594A8';
const EYE_SHINE = '#FFFFFF';
const EYE_GLINT = '#FFD9E8';
const SEED_DARK = '#4F3C35';
const SEED_STRIPE = '#D9CFC7';
const BERRY_RED = '#FF5E7E';
const BERRY_HI = '#FF9EB3';
const BERRY_LEAF = '#6BD472';
const CORN_GOLD = '#FFD54F';
const CORN_HI = '#FFF3B0';

function clamp(v: number, min: number, max: number) {
  return Math.max(min, Math.min(max, v));
}

export function drawHamster(
  ctx: CanvasRenderingContext2D,
  hamster: HamsterEntity,
  coat: HamsterCoat,
  timeSec: number,
  showSelectionMarker = false
) {
  const frame = Math.floor(hamster.animFrame);
  const breath = Math.sin(timeSec * 3.1 + hamster.id) > 0.35 ? 1 : 0;

  if (hamster.state === 'hide_house' || hamster.state === 'sleep_house') {
    drawHamsterInHouse(ctx, hamster, coat, timeSec, showSelectionMarker);
    return;
  }

  const buf = new PixelSpriteBuffer(56, 48);
  const cx = 28;

  const isSleeping = hamster.state === 'sleep';
  const isPetted = hamster.state === 'petted';
  const isSqueezed = hamster.state === 'squeeze';
  const isHeld = hamster.state === 'held';
  const isGlassPeek = hamster.state === 'glass_peek';
  const isWallClimb = hamster.state === 'wall_climb';
  const isLickingPaw = isHeld && hamster.lickPawTimer <= 0;
  const isClimbing = hamster.state === 'climb_ladder';
  const isClimbLooking = isClimbing && hamster.climbLookTimer > 0;
  const isSliding = hamster.state === 'slide_down';
  const isStanding = hamster.state === 'stand' || hamster.state === 'drink';
  const isRunning = hamster.state === 'run_wheel';
  const isOverspin = isRunning && hamster.wheelPhase === 'overspin';
  const isRagdoll = hamster.state === 'ragdoll' || isOverspin;
  const isPlayFight = hamster.state === 'play_fight';
  const isBuried = hamster.state === 'buried';
  const isWalking = hamster.state === 'walk';
  const isEating = hamster.state === 'eat';
  const isStuffing = hamster.state === 'stuff_cheek';
  const isUnloading = hamster.state === 'unload_stash';
  const isGrooming = hamster.state === 'groom';
  const isDigging = hamster.state === 'dig';
  const isYawning = hamster.state === 'yawn';
  const isDizzy = hamster.state === 'dizzy';
  const isStretching = hamster.state === 'stretch';
  const isShaking = hamster.state === 'shake';
  const isHappyHop = hamster.state === 'happy_hop';

  const { phys, chubbyLevel } = hamster;
  const squash = clamp(phys.squashY, -0.85, 1.55);
  const localShear = clamp(phys.furShearX * hamster.facing, -2.5, 2.5);
  const shearPx = Math.round(localShear);
  const earOffsetL = Math.round(clamp(phys.earBounceL, -2.2, 2.2));
  const earOffsetR = Math.round(clamp(phys.earBounceR, -2.2, 2.2));
  const cheekJig = clamp(phys.cheekJiggle, -0.8, 1.5);
  const tailLag = Math.round(clamp(phys.tailWag, -2, 2));

  // Chubby / Gembrot multipliers!
  const chonkyRx = chubbyLevel === 2 ? 4.0 : chubbyLevel === 1 ? 2.1 : 0;
  const chonkyRy = chubbyLevel === 2 ? 2.2 : chubbyLevel === 1 ? 1.1 : 0;
  const chonkyCheek = chubbyLevel === 2 ? 1.8 : chubbyLevel === 1 ? 0.9 : 0;

  const eatChewPulse = isEating ? Math.abs(Math.sin(timeSec * 14 + hamster.id)) * 1.15 : 0;
  const squeezeCheek = isSqueezed ? 1.8 : phys.squeezeAmount * 1.4;
  // DEFAULT chubby adorable chipmunk cheeks (pipi default lebih tembem cute!)
  const baseChubbyCheeks = 1.75 + (isHeld ? 0.5 : 0) + (isGlassPeek ? 0.5 : 0);
  const cheekExtra =
    baseChubbyCheeks +
    Math.min(4, hamster.stats.cheekPuff) +
    (isShaking ? 0.8 : 0) +
    eatChewPulse +
    squeezeCheek;
  const squishY = (isSleeping ? 2 : isPetted || isSqueezed ? 1.8 : 0) + squash * 1.3;
  const squishX = (isSleeping ? 2 : isPetted || isSqueezed ? 1.9 : 0) + squash * 1.5;

  // Compute elastic Pudding Deformation (squash-stretch + gelatin wobble!)
  const puddingScaleY = clamp(
    1 - squash * 0.14 - phys.squeezeAmount * 0.24,
    0.72,
    1.26
  );
  const puddingScaleX = clamp(1 / Math.sqrt(puddingScaleY), 0.84, 1.28);
  const puddingWobbleX = clamp(
    phys.wobbleAmp * Math.sin(phys.wobblePhase) +
      (isSqueezed ? Math.sin(timeSec * 22) * 1.1 : 0),
    -3.2,
    3.2
  );
  const puddingDeform: PuddingDeform | undefined =
    isRagdoll || isBuried || isSliding || isWallClimb
      ? undefined
      : {
          scaleX: puddingScaleX,
          scaleY: puddingScaleY,
          wobbleX: puddingWobbleX,
        };

  // Ground shadow under hamster
  const airFactor = clamp(Math.abs(hamster.hopOffset) / 14, 0, 0.55);
  const shadowW = Math.max(
    6,
    Math.round(
      ((isSleeping ? 14 : isStretching ? 15 : isStanding || isEating ? 9.5 : 12) +
        chonkyRx +
        cheekExtra * 0.45) *
        (1 - airFactor * 0.4) *
        puddingScaleX
    )
  );
  const shadowY = Math.round(
    hamster.state === 'ragdoll' ? hamster.ragdollGroundY + 1 : hamster.y + 1
  );
  if (!isRunning && !isBuried && !isClimbing && !isSliding) {
    ctx.fillStyle = 'rgba(130, 96, 68, 0.24)';
    ctx.fillRect(Math.round(hamster.x - shadowW), shadowY, shadowW * 2, 2);
    ctx.fillStyle = 'rgba(130, 96, 68, 0.13)';
    ctx.fillRect(Math.round(hamster.x - shadowW - 1), shadowY, shadowW * 2 + 2, 1);
  }

  const baseFeetY = 42;
  const runCycle = frame % 4;
  const bobY =
    isWalking || isClimbing
      ? frame % 2 === 0
        ? -1
        : 0
      : isRunning
      ? runCycle === 1 || runCycle === 3
        ? -1
        : 0
      : isPlayFight
      ? frame % 2 === 0
        ? -2
        : 0
      : isEating
      ? frame % 2 === 0
        ? 0
        : 1
      : isSleeping
      ? breath
      : isDigging
      ? frame % 2 === 0
        ? 1
        : 0
      : 0;

  const bodyCx = cx - (isStretching ? 1 : 0);
  let bodyCy =
    baseFeetY -
    7 -
    Math.round(chonkyRy * 0.45) +
    Math.round(squishY * 0.6) +
    bobY +
    (isStretching ? 2 : 0);
  let headCx =
    cx +
    (isRunning
      ? 3
      : isDigging
      ? 2
      : isStretching
      ? 4
      : isPlayFight
      ? 2
      : isClimbing
      ? 0
      : isHeld || isGlassPeek
      ? 0
      : 1) +
    shearPx;
  let headCy =
    bodyCy -
    (isStanding || isEating || isClimbing || isSliding || isHeld || isGlassPeek || isWallClimb ? 8 : isSleeping ? 3 : isStretching ? 3 : 6) +
    Math.round(squash * 0.5);

  // Occasionally tilt head to look around while climbing!
  if (isClimbLooking) {
    headCx += hamster.facing * 2;
    headCy -= 1;
  }

  if (isHeld) {
    // Cute belly-up held pose in your hand (like the reference photo!)
    bodyCy = baseFeetY - 13 + Math.round(squishY * 0.4);
    headCy = bodyCy - 7 + Math.round(squash * 0.3);
  } else if (isGlassPeek) {
    bodyCy = baseFeetY - 9 + Math.round(squishY * 0.5);
    headCy = bodyCy - 8;
  } else if (isWallClimb) {
    bodyCy = baseFeetY - 10 + Math.round(squishY * 0.4);
    headCy = bodyCy - 8;
  } else if (isStanding || isEating || isClimbing || isSliding) {
    bodyCy =
      baseFeetY -
      8 -
      Math.round(chonkyRy * 0.35) +
      Math.round(squishY * 0.45) +
      (isEating ? bobY : 0);
    headCy = bodyCy - 8 + Math.round(squash * 0.35);
  }

  if (isBuried) {
    const wiggle = Math.sin(timeSec * 12) > 0.5 ? (frame % 2 === 0 ? -1 : 1) : 0;
    bodyCy += 9;
    headCy += 7 + (hamster.buriedWiggleTimer > 0 ? wiggle : 0);
    headCx += hamster.buriedWiggleTimer > 0 ? wiggle : 0;
  }

  // ---- 1) COTTON-BALL FLUFFY TAIL ----
  if (!isBuried) {
    const tailX =
      bodyCx -
      (isSleeping ? 11 : isStretching ? 13 : 10) -
      Math.round(chonkyRx) -
      Math.round(squishX) -
      Math.round(shearPx * 0.4);
    const tailY = bodyCy + (isDigging ? -2 : isRunning ? 1 : 2) + tailLag;
    buf.fillCircle(tailX, tailY, 2.4, coat.belly);
    buf.set(tailX - 2, tailY - 1, coat.belly);
    buf.set(tailX - 2, tailY, coat.furLight);
  }

  // ---- 2) BACK EAR ----
  const earTwitch = hamster.earTwitchTimer > 0 && frame % 2 === 0 ? 1 : 0;
  const backEarX = headCx + 4 + Math.round(localShear * 0.35);
  const backEarY = headCy - 7 + earOffsetR + (isRunning || isPetted || isSqueezed ? 1 : 0);
  buf.fillEllipse(backEarX, backEarY, 2.7, 2.9, coat.earOuter);
  buf.set(backEarX, backEarY, coat.earInner);
  buf.set(backEarX + 1, backEarY, coat.earInner);

  // ---- 3) TORSO ----
  const bodyRx = clamp(
    (isStanding || isEating ? 8.6 : isStretching ? 11.4 : 9.6) +
      chonkyRx +
      squishX +
      (isShaking ? 1.1 : 0),
    7.0,
    16.2
  );
  const bodyRy = clamp(
    (isStanding || isEating ? 8.4 : isStretching ? 5.8 : 7.5) +
      chonkyRy -
      squishY * 0.45,
    4.8,
    12.0
  );
  if (!isBuried) {
    buf.fillEllipse(bodyCx - 1, bodyCy, bodyRx, bodyRy, coat.furBase);

    if (chubbyLevel >= 1 && !isStretching) {
      buf.fillEllipse(
        bodyCx,
        bodyCy + 2.2,
        bodyRx * 0.94,
        bodyRy * 0.72,
        coat.furBase
      );
    }

    const rumpX = bodyCx - Math.round(bodyRx) - 1;
    buf.set(rumpX, bodyCy, coat.furLight);
    buf.set(rumpX, bodyCy + 2, coat.furBase);
    buf.set(rumpX + 1, bodyCy + 4, coat.furShadow);
    if (isShaking || cheekExtra > 1 || chubbyLevel > 0) {
      buf.set(rumpX - 1, bodyCy + 1, coat.furBase);
    }
  }

  // ---- 4) HEAD & EXTRA-STUFFABLE FLUFFY CHEEKS ----
  const headRx = clamp(
    8.4 + chonkyRx * 0.35 + squishX * 0.5 + (isShaking ? 0.8 : 0),
    7.2,
    12.8
  );
  const headRy = clamp(7.2 + chonkyRy * 0.2 - squishY * 0.4, 5.5, 9.6);
  buf.fillEllipse(headCx, headCy, headRx, headRy, coat.furBase);

  const puff = cheekExtra * 0.95 + chonkyCheek + cheekJig * 0.65;
  const puffBump = (isStuffing || isEating) && frame % 2 === 0 ? 0.95 : 0;
  buf.fillEllipse(
    headCx - 4.2 - puff * 0.6,
    headCy + 2.6 + squash * 0.35,
    4.9 + puff + puffBump,
    4.3 + puff * 0.55 + puffBump * 0.5,
    coat.furBase
  );
  buf.fillEllipse(
    headCx + 4.2 + puff * 0.55,
    headCy + 2.5 + squash * 0.35,
    4.5 + puff * 0.85 + puffBump,
    4.0 + puff * 0.48 + puffBump * 0.5,
    coat.furBase
  );

  const cheekEdgeL = Math.round(headCx - 9 - puff);
  buf.set(cheekEdgeL, headCy + 1, coat.furLight);
  buf.set(cheekEdgeL, headCy + 3, coat.furBase);
  buf.set(cheekEdgeL + 1, headCy + 5, coat.furShadow);

  if (!isSleeping) {
    const tuftShift = Math.round(localShear * 0.6);
    buf.set(headCx - 1 + tuftShift, headCy - 8, coat.furLight);
    buf.set(headCx + tuftShift, headCy - 8, coat.furBase);
    buf.set(headCx - 2 + tuftShift, headCy - 7, coat.furLight);
  }

  // ---- 5) COAT SHADING, HIGHLIGHTS, PATCHES & CREAM BELLY ----
  if (!isBuried) {
    buf.paintIfFilled(bodyCx - 5, bodyCy + 4, bodyRx * 0.88, bodyRy * 0.72, coat.furShadow);
  }

  if ((coat.id === 'taro-boba' || coat.id === 'matcha-latte') && coat.stripe) {
    if (!isBuried) {
      buf.paintIfFilled(bodyCx - 5, bodyCy - 3, 4.5 + chonkyRx * 0.3, 2.2, coat.stripe);
    }
    buf.paintIfFilled(headCx - 2, headCy - 5, 2.2, 2.6, coat.stripe);
  } else if (coat.id === 'choco-panda' && coat.stripe) {
    if (!isBuried) {
      buf.paintIfFilled(bodyCx - 5, bodyCy - 1, 5.2 + chonkyRx * 0.4, 4.8 + chonkyRy * 0.4, coat.stripe);
    }
    buf.paintIfFilled(headCx + 3, headCy - 1, 3.4, 3.2, coat.stripe);
    buf.paintIfFilled(headCx - 5, headCy - 1, 3.1, 3.0, coat.stripe);
  }

  buf.paintIfFilled(headCx - 2, headCy - 4, 4.5, 2.4, coat.furLight);
  if (!isBuried) {
    buf.paintIfFilled(bodyCx - 3, bodyCy - 4, 4.8 + chonkyRx * 0.3, 2.2, coat.furLight);
    const bellyCx = bodyCx + 2;
    const bellyCy = bodyCy + 2;
    buf.paintIfFilled(
      bellyCx,
      bellyCy,
      6.4 + chonkyRx * 0.75 + squishX * 0.5,
      5.6 + chonkyRy * 0.75 - squishY * 0.4,
      coat.belly
    );
    buf.paintIfFilled(bellyCx, bodyCy + 6 + chonkyRy * 0.4, 5.4 + chonkyRx * 0.5, 2.2, coat.bellyShadow);
  }
  buf.paintIfFilled(headCx + 2, headCy + 4, 5.6 + puff * 0.6, 2.8 + chonkyCheek * 0.3, coat.belly);

  if (cheekExtra >= 2) {
    buf.set(Math.round(headCx - 6 - puff * 0.4), headCy + 2, coat.furLight);
    buf.set(Math.round(headCx + 7 + puff * 0.35), headCy + 2, coat.furLight);
  }

  // ---- 6) FRONT EAR ----
  const frontEarX = headCx - 5 + Math.round(localShear * 0.35);
  const frontEarY = headCy - 6 - earTwitch + earOffsetL + (isRunning || isPetted || isSqueezed ? 1 : 0);
  buf.fillEllipse(frontEarX, frontEarY, 2.8, 3.1, coat.earOuter);
  buf.set(frontEarX, frontEarY, coat.earInner);
  buf.set(frontEarX + 1, frontEarY, coat.earInner);
  buf.set(frontEarX, frontEarY + 1, coat.earInner);
  buf.set(frontEarX, frontEarY + 3, coat.furShadow);

  // ---- 7) ROSY SHIMMER BLUSH CHEEKS ----
  const blushIntensity =
    isPetted ||
    isSqueezed ||
    isEating ||
    isStuffing ||
    isUnloading ||
    isHappyHop ||
    isPlayFight ||
    isSliding
      ? 1
      : 0;
  const blushLeftX = headCx - 3 - Math.round(puff * 0.3);
  const blushRightX = headCx + 6 + Math.round(puff * 0.3);
  const blushY = headCy + 2;

  buf.set(blushLeftX, blushY, coat.blush);
  buf.set(blushLeftX + 1, blushY, coat.blush);
  buf.set(blushLeftX + 2, blushY, coat.blush);
  buf.set(blushLeftX + 1, blushY + 1, coat.blush);
  if (blushIntensity > 0) {
    buf.set(blushLeftX, blushY + 1, coat.blush);
    buf.set(blushLeftX + 2, blushY + 1, coat.blush);
    buf.set(blushLeftX + 1, blushY, '#FFC2D1');
  }

  buf.set(blushRightX, blushY, coat.blush);
  buf.set(blushRightX + 1, blushY, coat.blush);
  if (blushIntensity > 0) {
    buf.set(blushRightX, blushY + 1, coat.blush);
  }

  // ---- 8) EXPRESSIVE DOUBLE-SPARKLE BOBA EYES ----
  const eyeLeftX = headCx - 1;
  const eyeRightX = headCx + 5;
  const eyeY = headCy - 1;

  // Big curious front-facing eyes when looking right at YOU through glass / held in hand!
  if (isGlassPeek || (isHeld && !isLickingPaw)) {
    const eyeShift = Math.sin(timeSec * 1.6) > 0.6 ? 1 : 0;
    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 2; dx++) {
        buf.set(eyeLeftX - 1 + dx + eyeShift, eyeY - 1 + dy, coat.eye);
        buf.set(eyeRightX + dx + eyeShift, eyeY - 1 + dy, coat.eye);
      }
    }
    buf.set(eyeLeftX - 1 + eyeShift, eyeY - 1, EYE_SHINE);
    buf.set(eyeRightX + eyeShift, eyeY - 1, EYE_SHINE);
    buf.set(eyeLeftX + eyeShift, eyeY + 1, EYE_GLINT);
    buf.set(eyeRightX + 1 + eyeShift, eyeY + 1, EYE_GLINT);
  } else if (isSleeping || isStretching) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY + 2, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 2, coat.outline);
    buf.set(eyeRightX + 2, eyeY + 1, coat.outline);
  } else if (
    isPetted ||
    isGrooming ||
    isYawning ||
    isHappyHop ||
    isUnloading ||
    isEating ||
    isSliding ||
    (isRunning && frame % 8 < 2)
  ) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY, coat.outline);
    buf.set(eyeRightX + 2, eyeY + 1, coat.outline);
  } else if (isDizzy || isShaking || isRagdoll || isPlayFight || isSqueezed) {
    // > < squeezed/goofy eyes!
    buf.set(eyeLeftX - 1, eyeY, coat.outline);
    buf.set(eyeLeftX, eyeY + 1, coat.outline);
    buf.set(eyeLeftX - 1, eyeY + 2, coat.outline);

    buf.set(eyeRightX + 1, eyeY, coat.outline);
    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 2, coat.outline);
  } else if (hamster.isBlinking) {
    buf.set(eyeLeftX - 1, eyeY + 1, coat.outline);
    buf.set(eyeLeftX, eyeY + 1, coat.outline);
    buf.set(eyeLeftX + 1, eyeY + 1, coat.outline);

    buf.set(eyeRightX, eyeY + 1, coat.outline);
    buf.set(eyeRightX + 1, eyeY + 1, coat.outline);
  } else {
    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 3; dx++) {
        if ((dx === 0 && dy === 2) || (dx === 2 && dy === 2)) continue;
        buf.set(eyeLeftX - 1 + dx, eyeY - 1 + dy, coat.eye);
      }
    }
    buf.set(eyeLeftX - 1, eyeY - 1, EYE_SHINE);
    buf.set(eyeLeftX + 1, eyeY + 1, EYE_GLINT);

    for (let dy = 0; dy < 3; dy++) {
      for (let dx = 0; dx < 2; dx++) {
        buf.set(eyeRightX + dx, eyeY - 1 + dy, coat.eye);
      }
    }
    buf.set(eyeRightX, eyeY - 1, EYE_SHINE);
    buf.set(eyeRightX + 1, eyeY + 1, EYE_GLINT);
  }

  // ---- 9) TWITCHY PINK NOSE & CUTE MOUTH ----
  const sniffBob =
    hamster.state === 'idle' || hamster.state === 'stand' || isBuried
      ? frame % 4 === 0
        ? -1
        : 0
      : 0;
  const noseX = headCx + 3;
  const noseY = headCy + 1 + sniffBob;
  buf.set(noseX, noseY, coat.nose);
  buf.set(noseX + 1, noseY, coat.nose);

  if (!isSleeping) {
    buf.set(headCx - 6 - Math.round(puff * 0.4), headCy + 2 + sniffBob, coat.furLight);
    buf.set(headCx + 8 + Math.round(puff * 0.3), headCy + 1 + sniffBob, coat.furLight);
  }

  if (isYawning || isStuffing || isRagdoll || isSliding) {
    buf.set(noseX, noseY + 2, '#D95D7A');
    buf.set(noseX + 1, noseY + 2, '#D95D7A');
    buf.set(noseX, noseY + 3, '#FF9CB2');
    buf.set(noseX + 1, noseY + 3, '#FF9CB2');
  } else if (isEating || isUnloading) {
    if (frame % 2 === 0) {
      buf.set(noseX, noseY + 2, '#D95D7A');
      buf.set(noseX + 1, noseY + 2, '#D95D7A');
      buf.set(noseX, noseY + 3, '#FF9CB2');
    } else {
      buf.set(noseX, noseY + 2, coat.outline);
      buf.set(noseX + 1, noseY + 2, coat.outline);
    }
  } else if (!isSleeping) {
    if (isHappyHop || isPetted || isPlayFight || isSqueezed) {
      buf.set(noseX, noseY + 2, '#FF7596');
      buf.set(noseX + 1, noseY + 2, '#FF7596');
      buf.set(noseX - 1, noseY + 1, coat.outline);
      buf.set(noseX + 2, noseY + 1, coat.outline);
    } else {
      buf.set(noseX - 1, noseY + 2, coat.outline);
      buf.set(noseX + 1, noseY + 2, coat.outline);
      buf.set(noseX, noseY + 1, coat.outline);
    }
  }

  // ---- 10) TINY PINK FEET & EXPRESSIVE PAWS (full limb animation!) ----
  if (!isSleeping && !isBuried) {
    const footY = baseFeetY - 1;
    if (isHeld) {
      // Wiggly dangling hind feet & toes while held in your hand!
      const wiggle = Math.sin(timeSec * 9 + hamster.id) * 1.8;
      const kick = hamster.lickPawTimer > 0 ? Math.sin(timeSec * 14) * 2.5 : 0;
      const legLeftY = footY - 6 + Math.round(wiggle + kick);
      const legRightY = footY - 5 - Math.round(wiggle + kick * 0.5);
      // Left leg
      buf.set(bodyCx - 6, legLeftY - 1, coat.bellyShadow);
      buf.set(bodyCx - 6, legLeftY, PAW_PINK);
      buf.set(bodyCx - 7, legLeftY, PAW_PINK);
      buf.set(bodyCx - 7, legLeftY + 1, '#FF7DA3');
      buf.set(bodyCx - 6, legLeftY + 1, '#FF7DA3');
      // Right leg
      buf.set(bodyCx + 5, legRightY - 1, coat.bellyShadow);
      buf.set(bodyCx + 5, legRightY, PAW_PINK);
      buf.set(bodyCx + 6, legRightY, PAW_PINK);
      buf.set(bodyCx + 6, legRightY + 1, '#FF7DA3');
      buf.set(bodyCx + 7, legRightY, '#FF7DA3');
    } else if (isWallClimb) {
      // Alternating feet pawing up the glass wall!
      const fA = frame % 2 === 0 ? -3 : 0;
      const fB = frame % 2 === 0 ? 0 : -3;
      buf.set(bodyCx - 4, footY - 2 + fA, PAW_PINK);
      buf.set(bodyCx - 5, footY - 2 + fA, PAW_PINK);
      buf.set(bodyCx + 4, footY - 2 + fB, PAW_PINK);
      buf.set(bodyCx + 5, footY - 2 + fB, PAW_PINK);
    } else if (isGlassPeek) {
      // Both tiny feet pressed on glass bottom
      const shuffle = frame % 4 === 0 ? 1 : 0;
      buf.set(bodyCx - 5, footY - shuffle, PAW_PINK);
      buf.set(bodyCx - 4, footY - shuffle, PAW_PINK);
      buf.set(bodyCx + 3, footY + shuffle, PAW_PINK);
      buf.set(bodyCx + 4, footY + shuffle, PAW_PINK);
    } else if (isRagdoll) {
      buf.set(bodyCx - 6, footY + 1, PAW_PINK);
      buf.set(bodyCx - 7, footY + 1, PAW_PINK);
      buf.set(bodyCx + 5, footY + 1, PAW_PINK);
      buf.set(bodyCx + 6, footY + 1, PAW_PINK);
    } else if (isSliding) {
      // Both little feet kicked forward in excitement while sliding down!
      buf.set(bodyCx + 4, footY - 2, PAW_PINK);
      buf.set(bodyCx + 5, footY - 2, PAW_PINK);
      buf.set(bodyCx + 7, footY - 2, PAW_PINK);
      buf.set(bodyCx + 8, footY - 2, PAW_PINK);
    } else if (isClimbing) {
      // Alternating climbing feet stepping up ladder rungs (freeze when looking around!)
      const stepL = isClimbLooking ? -1 : frame % 2 === 0 ? -2 : 0;
      const stepR = isClimbLooking ? 0 : frame % 2 === 0 ? 0 : -2;
      buf.set(bodyCx - 4, footY + stepL, PAW_PINK);
      buf.set(bodyCx - 3, footY + stepL, PAW_PINK);
      buf.set(bodyCx + 3, footY + stepR, PAW_PINK);
      buf.set(bodyCx + 4, footY + stepR, PAW_PINK);
    } else if (isRunning) {
      const backLegA = [
        { dx: -2, dy: 0 },
        { dx: 1, dy: -1 },
        { dx: 3, dy: 0 },
        { dx: 0, dy: 0 },
      ][runCycle];
      const backLegB = [
        { dx: 3, dy: 0 },
        { dx: 0, dy: 0 },
        { dx: -2, dy: 0 },
        { dx: 1, dy: -1 },
      ][runCycle];

      buf.set(bodyCx - 4 + backLegA.dx, footY + backLegA.dy, PAW_PINK);
      buf.set(bodyCx - 3 + backLegA.dx, footY + backLegA.dy, PAW_PINK);
      buf.set(bodyCx - 5 + backLegA.dx, footY + backLegA.dy, PAW_SHADOW);

      buf.set(bodyCx + 2 + backLegB.dx, footY + backLegB.dy, PAW_PINK);
      buf.set(bodyCx + 3 + backLegB.dx, footY + backLegB.dy, PAW_PINK);
      buf.set(bodyCx + 1 + backLegB.dx, footY + backLegB.dy, PAW_SHADOW);
    } else if (isHappyHop || isPlayFight) {
      buf.set(bodyCx - 5, footY - 1, PAW_PINK);
      buf.set(bodyCx - 4, footY - 1, PAW_PINK);
      buf.set(bodyCx + 3, footY - 1, PAW_PINK);
      buf.set(bodyCx + 4, footY - 1, PAW_PINK);
    } else if (isStretching) {
      buf.set(bodyCx - 9, footY, PAW_PINK);
      buf.set(bodyCx - 8, footY, PAW_PINK);
    } else {
      const stepA = isWalking ? (frame % 2 === 0 ? -2 : 2) : 0;
      const stepB = isWalking ? (frame % 2 === 0 ? 2 : -2) : 0;

      buf.set(bodyCx - 4 + stepA, footY, PAW_PINK);
      buf.set(bodyCx - 3 + stepA, footY, PAW_PINK);
      buf.set(bodyCx - 5 + stepA, footY, PAW_SHADOW);

      buf.set(bodyCx + 3 + stepB, footY, PAW_PINK);
      buf.set(bodyCx + 4 + stepB, footY, PAW_PINK);
      buf.set(bodyCx + 2 + stepB, footY, PAW_SHADOW);
    }
  }

  // Front tiny paws (pose-dependent!)
  if (isHeld) {
    if (isLickingPaw) {
      // ADORABLE: Licking little paw to clean itself, then rubbing face!
      const lickBob = frame % 2 === 0 ? 0 : 1;
      const pawLickX = noseX - 1;
      const pawLickY = noseY + 1 + lickBob;
      buf.set(pawLickX - 1, pawLickY, PAW_PINK);
      buf.set(pawLickX, pawLickY, PAW_PINK);
      buf.set(pawLickX - 1, pawLickY + 1, PAW_SHADOW);
      // Tiny pink tongue flicking out!
      buf.set(noseX + 1, noseY + 2 + lickBob, '#FF7596');
      buf.set(noseX + 1, noseY + 3 + lickBob, '#FF9CB2');
      // Other paw scrubbing cheek
      buf.set(headCx + 5, headCy + 3 - lickBob, PAW_PINK);
      buf.set(headCx + 6, headCy + 3 - lickBob, PAW_PINK);
    } else {
      // Curled-up mochi paws with gentle waving wiggles!
      const pawWig = Math.sin(timeSec * 8 + hamster.id) > 0 ? 1 : 0;
      buf.set(headCx + 2, headCy + 4 + pawWig, PAW_PINK);
      buf.set(headCx + 3, headCy + 4 + pawWig, PAW_PINK);
      buf.set(bodyCx + 4, bodyCy - 1 - pawWig, PAW_PINK);
      buf.set(bodyCx + 5, bodyCy - 1 - pawWig, PAW_PINK);
      buf.set(bodyCx - 1, bodyCy - 2 + pawWig, PAW_PINK);
      buf.set(bodyCx - 2, bodyCy - 2 + pawWig, PAW_PINK);
    }
  } else if (isGlassPeek) {
    // Pressing both tiny paws flat on the front glass and waving at YOU!
    const wave = frame % 4 < 2 ? 0 : -2;
    buf.set(headCx - 2, headCy + 3, PAW_PINK);
    buf.set(headCx - 3, headCy + 3, PAW_PINK);
    buf.set(headCx + 4, headCy + 3 + wave, PAW_PINK);
    buf.set(headCx + 5, headCy + 3 + wave, PAW_PINK);
  } else if (isWallClimb) {
    // Alternating little paws reaching up on the glass!
    const pawUp = frame % 2 === 0 ? -4 : 0;
    const pawUpB = frame % 2 === 0 ? 0 : -4;
    buf.set(bodyCx + 3, bodyCy - 3 + pawUp, PAW_PINK);
    buf.set(bodyCx + 4, bodyCy - 3 + pawUp, PAW_PINK);
    buf.set(bodyCx + 6, bodyCy - 3 + pawUpB, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 3 + pawUpB, PAW_PINK);
  } else if (isEating || isStuffing) {
    const nibbleBob = frame % 2 === 0 ? 0 : 1;
    const treatX = headCx + 4;
    const treatY = headCy + (isStuffing ? 3 : 4) + nibbleBob;

    const progress =
      isEating && hamster.eatDuration > 0
        ? clamp(1 - hamster.stateTimer / hamster.eatDuration, 0, 1)
        : 0;
    const biteStage = progress < 0.35 ? 0 : progress < 0.72 ? 1 : 2;

    if (hamster.activeSnack === 'strawberry') {
      if (biteStage === 0) {
        buf.set(treatX, treatY - 1, BERRY_LEAF);
        buf.set(treatX + 1, treatY - 1, BERRY_LEAF);
        buf.set(treatX, treatY, BERRY_RED);
        buf.set(treatX + 1, treatY, BERRY_RED);
        buf.set(treatX + 2, treatY, BERRY_RED);
        buf.set(treatX, treatY + 1, BERRY_HI);
        buf.set(treatX + 1, treatY + 1, BERRY_RED);
        buf.set(treatX + 1, treatY + 2, BERRY_RED);
      } else if (biteStage === 1) {
        buf.set(treatX, treatY, BERRY_LEAF);
        buf.set(treatX, treatY + 1, BERRY_RED);
        buf.set(treatX + 1, treatY + 1, BERRY_HI);
        buf.set(treatX + 1, treatY + 2, BERRY_RED);
      } else {
        buf.set(treatX + 1, treatY + 1, BERRY_RED);
        buf.set(treatX + 1, treatY + 2, BERRY_HI);
      }
    } else if (hamster.activeSnack === 'corn') {
      if (biteStage === 0) {
        buf.set(treatX, treatY, CORN_GOLD);
        buf.set(treatX + 1, treatY, CORN_HI);
        buf.set(treatX + 2, treatY, CORN_GOLD);
        buf.set(treatX, treatY + 1, CORN_GOLD);
        buf.set(treatX + 1, treatY + 1, CORN_GOLD);
      } else if (biteStage === 1) {
        buf.set(treatX, treatY, CORN_GOLD);
        buf.set(treatX + 1, treatY, CORN_HI);
        buf.set(treatX + 1, treatY + 1, CORN_GOLD);
      } else {
        buf.set(treatX + 1, treatY + 1, CORN_GOLD);
      }
    } else {
      if (biteStage < 2) {
        buf.set(treatX, treatY, SEED_DARK);
        buf.set(treatX + 1, treatY, SEED_STRIPE);
        buf.set(treatX, treatY + 1, SEED_STRIPE);
        buf.set(treatX + 1, treatY + 1, SEED_DARK);
      } else {
        buf.set(treatX + 1, treatY + 1, SEED_STRIPE);
      }
    }

    buf.set(treatX - 1, treatY + 1, PAW_PINK);
    buf.set(treatX - 1, treatY + 2, PAW_SHADOW);
    buf.set(treatX + 2, treatY + 1, PAW_PINK);
    buf.set(treatX + 2, treatY + 2, PAW_SHADOW);
  } else if (isClimbing) {
    // Alternating tiny pink paws gripping ladder rungs!
    const pawA = isClimbLooking ? -2 : frame % 2 === 0 ? -3 : 0;
    const pawB = isClimbLooking ? 0 : frame % 2 === 0 ? 0 : -3;
    buf.set(bodyCx + 3, bodyCy - 2 + pawA, PAW_PINK);
    buf.set(bodyCx + 4, bodyCy - 2 + pawA, PAW_PINK);
    buf.set(bodyCx + 6, bodyCy - 2 + pawB, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 2 + pawB, PAW_PINK);
  } else if (isSliding) {
    // Both paws raised up in joy: "Weeee!"
    buf.set(bodyCx + 3, bodyCy - 5, PAW_PINK);
    buf.set(bodyCx + 4, bodyCy - 5, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 5, PAW_PINK);
    buf.set(bodyCx + 8, bodyCy - 5, PAW_PINK);
  } else if (isPlayFight) {
    const bapA = frame % 2 === 0 ? 3 : 0;
    const bapB = frame % 2 === 0 ? 0 : 3;
    buf.set(bodyCx + 6 + bapA, bodyCy - 2, PAW_PINK);
    buf.set(bodyCx + 7 + bapA, bodyCy - 2, PAW_PINK);
    buf.set(bodyCx + 5 + bapB, bodyCy + 1, PAW_PINK);
    buf.set(bodyCx + 6 + bapB, bodyCy + 1, PAW_PINK);
  } else if (isRagdoll) {
    buf.set(bodyCx + 6, bodyCy - 4, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 4, PAW_PINK);
    buf.set(bodyCx - 2, bodyCy - 5, PAW_PINK);
    buf.set(bodyCx - 1, bodyCy - 5, PAW_PINK);
  } else if (isBuried) {
    buf.set(headCx - 3, headCy + 5, PAW_PINK);
    buf.set(headCx + 4, headCy + 5, PAW_PINK);
  } else if (isUnloading) {
    const push = frame % 2 === 0 ? 1 : 0;
    buf.set(headCx - 3 + push, headCy + 3, PAW_PINK);
    buf.set(headCx - 2 + push, headCy + 3, PAW_PINK);
    buf.set(headCx + 5 - push, headCy + 3, PAW_PINK);
    buf.set(headCx + 6 - push, headCy + 3, PAW_PINK);
  } else if (isGrooming) {
    const scrub = frame % 2 === 0 ? 0 : -1;
    buf.set(headCx - 1, headCy + 2 + scrub, PAW_PINK);
    buf.set(headCx, headCy + 2 + scrub, PAW_PINK);
    buf.set(headCx + 4, headCy + 3 - scrub, PAW_PINK);
    buf.set(headCx + 5, headCy + 3 - scrub, PAW_PINK);
  } else if (isStanding || isHappyHop) {
    const raise = isHappyHop ? -2 : 0;
    buf.set(bodyCx + 2, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 3, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 6, bodyCy - 2 + raise, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy - 2 + raise, PAW_PINK);
  } else if (isStretching) {
    buf.set(bodyCx + 9, baseFeetY - 1, PAW_PINK);
    buf.set(bodyCx + 10, baseFeetY - 1, PAW_PINK);
    buf.set(bodyCx + 11, baseFeetY - 1, PAW_SHADOW);
  } else if (isDigging) {
    const digF = frame % 2 === 0 ? 1 : -1;
    buf.set(bodyCx + 6, bodyCy + 3 + digF, PAW_PINK);
    buf.set(bodyCx + 7, bodyCy + 3 + digF, PAW_PINK);
    buf.set(bodyCx + 8, bodyCy + 2 - digF, PAW_PINK);
  } else if (isRunning) {
    const frontPawA = [
      { dx: 7, dy: 2 },
      { dx: 8, dy: 1 },
      { dx: 6, dy: 0 },
      { dx: 5, dy: 1 },
    ][runCycle];
    buf.set(bodyCx + frontPawA.dx, bodyCy + frontPawA.dy, PAW_PINK);
    buf.set(bodyCx + frontPawA.dx + 1, bodyCy + frontPawA.dy, PAW_PINK);
    buf.set(bodyCx + 5, bodyCy + 2, PAW_SHADOW);
  } else if (!isSleeping) {
    const pawOut = Math.round(chonkyRx * 0.45);
    buf.set(bodyCx + 1 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 2 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 5 + pawOut, bodyCy + 2, PAW_PINK);
    buf.set(bodyCx + 6 + pawOut, bodyCy + 2, PAW_PINK);
  }

  // ---- 11) SHOP REWARD ACCESSORIES! ----
  if (hamster.accessory && hamster.accessory !== 'none') {
    if (hamster.accessory === 'crown') {
      const kx = headCx - 2;
      const ky = headCy - 10;
      buf.set(kx, ky, '#FFE066');
      buf.set(kx, ky + 1, '#FFE066');
      buf.set(kx + 1, ky + 1, '#FFC947');
      buf.set(kx + 2, ky - 1, '#FFE066');
      buf.set(kx + 2, ky, '#FF5E7E');
      buf.set(kx + 2, ky + 1, '#FFE066');
      buf.set(kx + 3, ky + 1, '#FFC947');
      buf.set(kx + 4, ky, '#FFE066');
      buf.set(kx + 4, ky + 1, '#FFE066');
    } else if (hamster.accessory === 'strawberry-hat') {
      const sx = headCx - 3;
      const sy = headCy - 9;
      buf.set(sx + 2, sy - 1, BERRY_LEAF);
      buf.set(sx + 3, sy - 1, BERRY_LEAF);
      for (let dx = 0; dx < 6; dx++) {
        buf.set(sx + dx, sy, BERRY_RED);
        buf.set(sx + dx, sy + 1, dx % 2 === 0 ? BERRY_RED : BERRY_HI);
      }
      buf.set(sx + 2, sy + 1, '#FFF3B0');
    } else if (hamster.accessory === 'flower-clip') {
      const fx = frontEarX + 2;
      const fy = frontEarY - 1;
      buf.set(fx, fy - 1, '#FFB5C8');
      buf.set(fx - 1, fy, '#FFB5C8');
      buf.set(fx + 1, fy, '#FFB5C8');
      buf.set(fx, fy + 1, '#FFB5C8');
      buf.set(fx, fy, '#FFE066');
    } else if (hamster.accessory === 'star-glasses' && !isSleeping) {
      buf.set(eyeLeftX - 1, eyeY, '#4FB8FF');
      buf.set(eyeLeftX, eyeY, '#85D4FF');
      buf.set(eyeLeftX + 1, eyeY, '#4FB8FF');
      buf.set(eyeLeftX + 2, eyeY, '#5A392C');
      buf.set(eyeRightX - 1, eyeY, '#5A392C');
      buf.set(eyeRightX, eyeY, '#4FB8FF');
      buf.set(eyeRightX + 1, eyeY, '#85D4FF');
      buf.set(eyeRightX + 2, eyeY, '#4FB8FF');
    }
  }

  // Stamp buffer onto virtual canvas centered on (hamster.x, hamster.y)
  const destX = Math.round(hamster.x - cx);
  const destY = Math.round(hamster.y - baseFeetY + hamster.hopOffset);
  const spinAngle = isRagdoll
    ? hamster.ragdollAngle
    : isWallClimb
    ? hamster.ragdollAngle
    : isSliding
    ? hamster.ragdollAngle
    : 0;
  buf.flush(
    ctx,
    destX,
    destY,
    coat.outline,
    hamster.facing === -1,
    spinAngle,
    28,
    33,
    puddingDeform
  );

  // Subtle floating pastel arrow over currently selected hamster
  if (showSelectionMarker) {
    const bob = Math.round(Math.sin(timeSec * 5) * 1.5);
    const mx = Math.round(hamster.x);
    const my = Math.round(
      hamster.y - (isBuried ? 21 : 30) + hamster.hopOffset + bob - chonkyRy
    );
    ctx.fillStyle = '#5A392C';
    ctx.fillRect(mx - 2, my - 2, 5, 2);
    ctx.fillRect(mx - 1, my, 3, 1);
    ctx.fillRect(mx, my + 1, 1, 1);
    ctx.fillStyle = '#FF7DA3';
    ctx.fillRect(mx - 1, my - 1, 3, 1);
    ctx.fillRect(mx, my, 1, 1);
  }
}

function drawHamsterInHouse(
  ctx: CanvasRenderingContext2D,
  hamster: HamsterEntity,
  coat: HamsterCoat,
  timeSec: number,
  showSelectionMarker: boolean
) {
  const hx = Math.round(hamster.x);
  const hy = Math.round(hamster.y);
  const isSleep = hamster.state === 'sleep_house';
  const breath = Math.sin(timeSec * 2.8 + hamster.id) > 0.35 ? 1 : 0;

  if (isSleep) {
    ctx.fillStyle = coat.furShadow;
    ctx.fillRect(hx - 6, hy - 8 + breath, 12, 7 - breath);
    ctx.fillStyle = coat.furBase;
    ctx.fillRect(hx - 5, hy - 9 + breath, 10, 6);
    ctx.fillStyle = coat.earOuter;
    ctx.fillRect(hx - 4, hy - 10 + breath, 3, 2);
    ctx.fillRect(hx + 2, hy - 10 + breath, 3, 2);
    ctx.fillStyle = coat.outline;
    ctx.fillRect(hx - 3, hy - 6 + breath, 2, 1);
    ctx.fillRect(hx + 2, hy - 6 + breath, 2, 1);
  } else {
    ctx.fillStyle = coat.furShadow;
    ctx.fillRect(hx - 5, hy - 10, 10, 9);
    ctx.fillStyle = coat.furBase;
    ctx.fillRect(hx - 4, hy - 11, 8, 8);
    ctx.fillStyle = coat.earOuter;
    ctx.fillRect(hx - 4, hy - 12, 2, 2);
    ctx.fillRect(hx + 2, hy - 12, 2, 2);
    if (!hamster.isBlinking) {
      ctx.fillStyle = coat.eye;
      ctx.fillRect(hx - 3, hy - 8, 2, 2);
      ctx.fillRect(hx + 1, hy - 8, 2, 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fillRect(hx - 3, hy - 8, 1, 1);
      ctx.fillRect(hx + 1, hy - 8, 1, 1);
    } else {
      ctx.fillStyle = coat.outline;
      ctx.fillRect(hx - 3, hy - 7, 2, 1);
      ctx.fillRect(hx + 1, hy - 7, 2, 1);
    }
    ctx.fillStyle = coat.nose;
    ctx.fillRect(hx - 1, hy - 6, 2, 1);
    ctx.fillStyle = coat.blush;
    ctx.fillRect(hx - 4, hy - 6, 1, 1);
    ctx.fillRect(hx + 3, hy - 6, 1, 1);
  }

  if (showSelectionMarker) {
    const bob = Math.round(Math.sin(timeSec * 5) * 1.5);
    const mx = hx;
    const my = hy - 22 + bob;
    ctx.fillStyle = '#5A392C';
    ctx.fillRect(mx - 2, my - 2, 5, 2);
    ctx.fillRect(mx - 1, my, 3, 1);
    ctx.fillRect(mx, my + 1, 1, 1);
    ctx.fillStyle = '#FF7DA3';
    ctx.fillRect(mx - 1, my - 1, 3, 1);
    ctx.fillRect(mx, my, 1, 1);
  }
}

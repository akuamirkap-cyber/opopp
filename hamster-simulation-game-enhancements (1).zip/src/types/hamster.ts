export type HamsterState =
  | 'idle'
  | 'stand'
  | 'walk'
  | 'climb_ladder'
  | 'slide_down'
  | 'run_wheel'
  | 'ragdoll'
  | 'held'
  | 'glass_peek'
  | 'wall_climb'
  | 'dizzy'
  | 'play_fight'
  | 'buried'
  | 'hide_house'
  | 'sleep_house'
  | 'eat'
  | 'stuff_cheek'
  | 'unload_stash'
  | 'drink'
  | 'groom'
  | 'dig'
  | 'sleep'
  | 'petted'
  | 'squeeze'
  | 'yawn'
  | 'stretch'
  | 'shake'
  | 'happy_hop';

export type WeatherMode = 'clear' | 'rain' | 'snow';

export type AquariumTheme = 'pastel-room' | 'sakura-garden' | 'starlight-cafe';

export type FairyLightStyle = 'none' | 'warm-gold' | 'pastel-rainbow' | 'sakura-glow';

export type HamsterAccessoryId = 'none' | 'crown' | 'strawberry-hat' | 'flower-clip' | 'star-glasses';

export type ToolMode = 'pet' | 'seed' | 'strawberry' | 'corn';

export type TreatKind = 'seed' | 'strawberry' | 'corn';

export type ChubbyLevel = 0 | 1 | 2; // 0 = Normal, 1 = Gemuk, 2 = Super Gembrot

export interface HamsterCoat {
  id: string;
  name: string;
  subtitle: string;
  badgeColor: string;
  outline: string;
  furBase: string;
  furLight: string;
  furShadow: string;
  belly: string;
  bellyShadow: string;
  earOuter: string;
  earInner: string;
  blush: string;
  nose: string;
  eye: string;
  stripe?: string;
}

export interface TreatItem {
  id: number;
  type: TreatKind;
  x: number;
  y: number;
  vy: number;
  landed: boolean;
  onLoft?: boolean;
  bitesLeft: number;
}

export type ParticleKind =
  | 'heart'
  | 'sparkle'
  | 'crumb'
  | 'shaving'
  | 'zzz'
  | 'note'
  | 'droplet'
  | 'sweat'
  | 'exclaim'
  | 'question'
  | 'fluff'
  | 'star'
  | 'bap'
  | 'coin';

export interface PixelParticle {
  id: number;
  kind: ParticleKind;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  color: string;
  size?: number;
}

export interface HamsterStats {
  hunger: number; // 0-100
  happiness: number; // 0-100
  energy: number; // 0-100
  cleanliness: number; // 0-100
  cheekPuff: number; // 0-4 visual puffiness
  affection: number; // total love points
}

/** Damped harmonic spring state for soft pudding-like plush fur & body physics */
export interface SoftPhysicsState {
  squashY: number;
  squashVelY: number;
  furShearX: number;
  furShearVelX: number;
  wobblePhase: number;
  wobbleAmp: number;
  wobbleVel: number;
  squeezeAmount: number;
  earBounceL: number;
  earVelL: number;
  earBounceR: number;
  earVelR: number;
  cheekJiggle: number;
  cheekVel: number;
  tailWag: number;
  tailVel: number;
}

export interface HamsterEntity {
  id: number;
  name: string;
  coatId: string;
  accessory: HamsterAccessoryId;
  chubbyLevel: ChubbyLevel;
  storedPouch: TreatKind[];
  activeSnack: TreatKind | null;
  eatDuration: number;
  stats: HamsterStats;
  x: number;
  y: number;
  vx: number;
  vy: number;
  facing: 1 | -1; // 1 = right, -1 = left
  onLoft: boolean;
  climbProgress: number; // 0 (bottom) -> 1 (top of ladder)
  slideProgress: number; // 0 (top) -> 1 (bottom of slide)
  state: HamsterState;
  stateTimer: number;
  animFrame: number;
  blinkTimer: number;
  isBlinking: boolean;
  earTwitchTimer: number;
  targetX: number | null;
  targetY: number | null;
  targetAction:
    | 'none'
    | 'wheel'
    | 'cushion'
    | 'igloo_sleep'
    | 'igloo_hide'
    | 'pile_bury'
    | 'bowl'
    | 'bottle'
    | 'stash_unload'
    | 'stash_eat'
    | 'go_ladder_up'
    | 'go_slide_down'
    | 'loft_nap';
  targetTreatId: number | null;
  wheelAngle: number;
  wheelSpeed: number;
  wheelPhase: 'none' | 'accel' | 'cruise' | 'turbo' | 'overspin' | 'coast';
  wheelSwing: number;
  wheelSwingVel: number;
  wheelOverspinLoops: number;
  ragdollAngle: number;
  ragdollSpin: number;
  ragdollGroundY: number;
  ragdollBounces: number;
  climbLookTimer: number;
  slideStyle: 0 | 1 | 2; // 0 normal sit, 1 head-first, 2 sideways silly
  slideSpin: number;
  heldWiggleTimer: number;
  lickPawTimer: number;
  playFightPartnerId: number | null;
  buriedWiggleTimer: number;
  squish: number;
  hopOffset: number;
  hopVel: number;
  socialCooldown: number;
  phys: SoftPhysicsState;
  statusText: string;
}

export interface HamsterSummary {
  id: number;
  name: string;
  coatId: string;
  chubbyLevel: ChubbyLevel;
  state: HamsterState;
  pouchCount: number;
}

export type MissionEventType =
  | 'pet_squeeze'
  | 'feed_treat'
  | 'climb_slide'
  | 'ragdoll_wheel'
  | 'play_fight'
  | 'bury_pile'
  | 'house_hide'
  | 'lift_hamster'
  | 'glass_peek'
  | 'chubby_boing';

export interface MissionItem {
  id: string;
  eventType: MissionEventType;
  title: string;
  description: string;
  progress: number;
  target: number;
  rewardCoins: number;
  rewardXp: number;
  claimed: boolean;
  badgeEmoji: string;
}

export interface ShopItem {
  id: string;
  category: 'lights' | 'accessory' | 'decor';
  name: string;
  description: string;
  price: number;
  badgeColor: string;
  fairyLightStyle?: FairyLightStyle;
  accessoryId?: HamsterAccessoryId;
  decorType?: 'rainbow-slide' | 'flower-loft';
}

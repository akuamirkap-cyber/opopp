import React, { useEffect, useRef } from 'react';
import { HAMSTER_COATS } from '../data/hamsterCoats';
import {
  applySquishImpulse,
  dropHeldHamster,
  emitMission,
  getSelectedHamster,
  pickUpHamster,
  sendToBuryPile,
  sendToHouse,
  SimWorld,
  spawnParticle,
  stepSimulation,
  triggerHappyHop,
  triggerLadderOrSlide,
  triggerPuddingSqueeze,
  triggerWheelRagdollDemo,
} from '../engine/hamsterAI';
import { drawHamster } from '../engine/hamsterRenderer';
import { drawHeldHamsterHand } from '../engine/handRenderer';
import {
  drawBeddingPileFront,
  drawHouseFrontArch,
  drawParticles,
  drawTerrariumBack,
  drawTerrariumForeground,
  drawWheelSpokes,
  FLOOR_BOTTOM_Y,
  FLOOR_TOP_Y,
  LOFT_SPEC,
  PROP_POS,
  VIRTUAL_H,
  VIRTUAL_W,
} from '../engine/terrariumRenderer';
import { HamsterEntity, ToolMode } from '../types/hamster';
import { pixelSound } from '../utils/pixelSound';

interface TerrariumCanvasProps {
  world: SimWorld;
  isActive: boolean;
  zoomedOut: boolean;
  toolMode: ToolMode;
  onSelectAquarium: () => void;
  onZoomInAquarium: () => void;
  onWorldMutated: () => void;
  registerCanvas?: (el: HTMLCanvasElement | null) => void;
}

export const TerrariumCanvas: React.FC<TerrariumCanvasProps> = ({
  world,
  isActive,
  zoomedOut,
  toolMode,
  onSelectAquarium,
  onZoomInAquarium,
  onWorldMutated,
  registerCanvas,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const worldRef = useRef<SimWorld>(world);
  const toolRef = useRef<ToolMode>(toolMode);
  const zoomedOutRef = useRef<boolean>(zoomedOut);
  const isPointerDownRef = useRef(false);
  const lastPetTimeRef = useRef(0);
  const lastPointerXRef = useRef<number | null>(null);
  const pettingHamsterIdRef = useRef<number | null>(null);
  const heldHamsterIdRef = useRef<number | null>(null);

  useEffect(() => {
    worldRef.current = world;
  }, [world]);

  useEffect(() => {
    toolRef.current = toolMode;
  }, [toolMode]);

  useEffect(() => {
    zoomedOutRef.current = zoomedOut;
  }, [zoomedOut]);

  useEffect(() => {
    if (registerCanvas) {
      registerCanvas(canvasRef.current);
      return () => registerCanvas(null);
    }
  }, [registerCanvas]);

  const triggerPetOn = (hamster: HamsterEntity, strokeDx = 0, squeezeHold = false) => {
    const w = worldRef.current;
    w.selectedHamsterId = hamster.id;

    if (squeezeHold) {
      hamster.state = 'squeeze';
      hamster.stateTimer = 0.45;
      hamster.phys.squeezeAmount = 1.0;
      applySquishImpulse(hamster, 5.2, Math.max(-12, Math.min(12, strokeDx * 3.5)));
    } else {
      applySquishImpulse(hamster, 4.6, Math.max(-14, Math.min(14, strokeDx * 4.2)));
    }

    const now = performance.now();
    if (now - lastPetTimeRef.current < 210) return;
    lastPetTimeRef.current = now;

    if (squeezeHold) {
      triggerPuddingSqueeze(w, hamster, strokeDx);
      return;
    }

    if (hamster.state === 'sleep' || hamster.state === 'sleep_house') {
      if (hamster.state === 'sleep_house') {
        hamster.y = PROP_POS.igloo.y + 9;
      }
      hamster.state = 'stretch';
      hamster.stateTimer = 1.1;
      hamster.statusText = `${hamster.name} menggeliat manja saat dibangunkan elusanmu~`;
      w.globalStatusText = hamster.statusText;
      pixelSound.playSqueak();
      return;
    }

    if (hamster.state === 'buried') {
      hamster.y = PROP_POS.pile.y + 3;
      hamster.hopVel = -34;
      pixelSound.playBurrowRustle();
    } else if (hamster.state === 'hide_house') {
      hamster.y = PROP_POS.igloo.y + 9;
    } else if (hamster.state === 'run_wheel') {
      hamster.wheelPhase = 'none';
      hamster.ragdollAngle = 0;
      hamster.y = FLOOR_TOP_Y + 14;
    } else if (hamster.state === 'climb_ladder' || hamster.state === 'slide_down') {
      hamster.onLoft = false;
      hamster.y = FLOOR_TOP_Y + 16;
    }

    hamster.state = 'petted';
    hamster.stateTimer = 1.35;
    hamster.ragdollAngle = 0;
    hamster.squish = 1;
    hamster.targetX = null;
    hamster.targetY = null;
    hamster.targetTreatId = null;
    hamster.statusText = `${hamster.name} memejamkan mata menikmati elusan lembutmu~`;
    w.globalStatusText = hamster.statusText;

    hamster.stats.happiness = Math.min(100, hamster.stats.happiness + 7);
    hamster.stats.affection += 2;
    emitMission(w, 'pet_squeeze');

    spawnParticle(w, 'heart', hamster.x - 4, hamster.y - 24, '#FF6B93', -6, -16, 1.1);
    spawnParticle(w, 'heart', hamster.x + 5, hamster.y - 26, '#FF8FA8', 6, -18, 1.2);
    spawnParticle(
      w,
      'sparkle',
      hamster.x + (Math.random() * 14 - 7),
      hamster.y - 16,
      '#FFE066',
      0,
      -10,
      0.6
    );
    pixelSound.playSqueak();
  };

  useEffect(() => {
    let rafId = 0;
    let lastTime = performance.now();
    let hudSyncAccum = 0;

    const renderLoop = (now: number) => {
      const rawDt = (now - lastTime) / 1000;
      lastTime = now;
      const dt = Math.min(0.05, Math.max(0.001, rawDt));
      const timeSec = now / 1000;

      const w = worldRef.current;
      stepSimulation(w, dt, timeSec);

      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.imageSmoothingEnabled = false;
          ctx.clearRect(0, 0, VIRTUAL_W, VIRTUAL_H);

          drawTerrariumBack(
            ctx,
            w.theme,
            w.nightMode,
            w.weather,
            timeSec,
            w.cleanliness,
            w.iglooStash,
            w.rainbowSlide,
            w.flowerLoft
          );
          drawWheelSpokes(ctx, w.wheelAngle, w.wheelSpeed);

          const showMarker = w.hamsters.length > 1;
          const getCoat = (coatId: string) =>
            HAMSTER_COATS.find((c) => c.id === coatId) || HAMSTER_COATS[0];

          const inHouse = w.hamsters.filter(
            (h) => h.state === 'hide_house' || h.state === 'sleep_house'
          );
          for (const h of inHouse) {
            drawHamster(ctx, h, getCoat(h.coatId), timeSec, showMarker && h.id === w.selectedHamsterId);
          }
          drawHouseFrontArch(ctx, w.theme, w.nightMode);

          const buried = w.hamsters.filter((h) => h.state === 'buried');
          for (const h of buried) {
            drawHamster(ctx, h, getCoat(h.coatId), timeSec, showMarker && h.id === w.selectedHamsterId);
          }
          drawBeddingPileFront(ctx, w.theme, w.nightMode, timeSec, buried.length > 0);

          const outside = w.hamsters
            .filter(
              (h) =>
                h.state !== 'hide_house' &&
                h.state !== 'sleep_house' &&
                h.state !== 'buried'
            )
            .sort((a, b) => a.y - b.y);
          for (const h of outside) {
            drawHamster(ctx, h, getCoat(h.coatId), timeSec, showMarker && h.id === w.selectedHamsterId);
            // Draw cute cradling hand beneath a held hamster!
            if (h.state === 'held') {
              drawHeldHamsterHand(ctx, h, timeSec);
            }
          }

          // Glass-front smudge & shine highlight when hamster presses on the glass!
          for (const h of outside) {
            if (h.state === 'glass_peek') {
              const gx = Math.round(h.x);
              const gy = Math.round(h.y - 14);
              ctx.fillStyle = 'rgba(255, 255, 255, 0.22)';
              ctx.fillRect(gx - 10, gy - 4, 20, 16);
              ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
              ctx.fillRect(gx - 8, gy - 2, 3, 8);
              ctx.fillRect(gx + 5, gy + 4, 2, 5);
            }
          }

          drawTerrariumForeground(
            ctx,
            w.theme,
            w.bowlSeeds,
            w.waterLevel,
            w.treats,
            w.nightMode,
            w.weather,
            w.wheelAngle,
            timeSec,
            w.fairyLightStyle
          );
          drawParticles(ctx, w.particles);
        }
      }

      hudSyncAccum += dt;
      if (hudSyncAccum >= 0.14) {
        hudSyncAccum = 0;
        onWorldMutated();
      }

      rafId = requestAnimationFrame(renderLoop);
    };

    rafId = requestAnimationFrame(renderLoop);
    return () => cancelAnimationFrame(rafId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toVirtualCoords = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: VIRTUAL_W / 2, y: FLOOR_TOP_Y + 12 };
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * VIRTUAL_W;
    const y = ((e.clientY - rect.top) / rect.height) * VIRTUAL_H;
    return { x, y };
  };

  const findHamsterNear = (x: number, y: number, radius = 24): HamsterEntity | null => {
    let best: HamsterEntity | null = null;
    let bestDist = radius;
    for (const h of worldRef.current.hamsters) {
      const d = Math.hypot(x - h.x, y - (h.y - 11));
      if (d <= bestDist) {
        bestDist = d;
        best = h;
      }
    }
    return best;
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    pixelSound.unlock();
    onSelectAquarium();

    if (zoomedOutRef.current) {
      onZoomInAquarium();
      return;
    }

    isPointerDownRef.current = true;
    const { x, y } = toVirtualCoords(e);
    lastPointerXRef.current = x;
    const w = worldRef.current;

    // 1) Direct hit on any hamster -> SQUEEZE / PET like pudding!
    const hitHamster = findHamsterNear(x, y, 22);
    if (hitHamster) {
      pettingHamsterIdRef.current = hitHamster.id;
      heldHamsterIdRef.current = hitHamster.id;
      w.selectedHamsterId = hitHamster.id;
      pickUpHamster(w, hitHamster, x, y + 12);
      onWorldMutated();
      return;
    }

    // 2) Dropping treats (even onto the 2nd floor loft!)
    if (toolRef.current !== 'pet') {
      if (w.treats.length >= 8) w.treats.shift();
      const tx = Math.max(32, Math.min(VIRTUAL_W - 42, x));
      const ty = Math.max(30, Math.min(FLOOR_BOTTOM_Y - 10, y));
      w.treats.push({
        id: w.nextId++,
        type: toolRef.current,
        x: tx,
        y: ty,
        vy: 0,
        landed: false,
        onLoft: false,
        bitesLeft: 1,
      });
      pixelSound.playDrop();
      return;
    }

    const hamster = getSelectedHamster(w);

    // 3) Clicking Ladder or Slide or Loft -> Climb up & Slide down!
    if (
      (Math.abs(x - LOFT_SPEC.ladderBottom.x) <= 14 && y >= 82 && y <= 150) ||
      (x >= 140 && x <= 204 && y >= 78 && y <= 148)
    ) {
      triggerLadderOrSlide(w);
      onWorldMutated();
      return;
    }

    // 4) Clicking on 2nd Floor Loft deck -> walk to loft spot
    if (x >= LOFT_SPEC.minX && x <= LOFT_SPEC.maxX && y >= 64 && y <= 92) {
      if (hamster.onLoft) {
        hamster.targetTreatId = null;
        hamster.targetAction = 'none';
        hamster.targetX = Math.max(LOFT_SPEC.minX + 8, Math.min(LOFT_SPEC.maxX - 8, x));
        hamster.targetY = LOFT_SPEC.y;
        hamster.state = 'walk';
        hamster.stateTimer = 4.0;
        hamster.statusText = `${hamster.name} berjalan di lantai 2~`;
        w.globalStatusText = hamster.statusText;
      } else {
        triggerLadderOrSlide(w);
      }
      onWorldMutated();
      return;
    }

    // 5) Clicking the Wheel -> Ragdoll overspin!
    if (Math.hypot(x - PROP_POS.wheel.x, y - PROP_POS.wheel.y) <= 23) {
      triggerWheelRagdollDemo(w);
      onWorldMutated();
      return;
    }

    // 6) Clicking the Bedding Pile -> bury or pop out!
    if (Math.hypot(x - PROP_POS.pile.x, y - (PROP_POS.pile.y - 5)) <= 19) {
      const buried = w.hamsters.find((h) => h.state === 'buried');
      if (buried) {
        buried.y = PROP_POS.pile.y + 3;
        buried.hopVel = -45;
        pixelSound.playBurrowRustle();
        triggerHappyHop(w, buried, `Cilukba! ${buried.name} melompat keluar dari tumpukan!`);
      } else {
        sendToBuryPile(w);
      }
      onWorldMutated();
      return;
    }

    // 7) Clicking the Hamster House -> hide/sleep or pop out!
    if (Math.hypot(x - PROP_POS.igloo.x, y - (PROP_POS.igloo.y - 10)) <= 22) {
      const inside = w.hamsters.find(
        (h) => h.state === 'hide_house' || h.state === 'sleep_house'
      );
      if (inside) {
        inside.y = PROP_POS.igloo.y + 9;
        inside.hopVel = -30;
        triggerHappyHop(w, inside, `${inside.name} keluar menyapa dari rumah hamsternya!`);
        pixelSound.playSqueak();
      } else {
        sendToHouse(w, false);
      }
      onWorldMutated();
      return;
    }

    // 8) Clicking cushion -> nap
    if (Math.hypot(x - PROP_POS.cushion.x, y - PROP_POS.cushion.y) <= 18) {
      hamster.onLoft = false;
      hamster.targetTreatId = null;
      hamster.targetAction = 'cushion';
      hamster.targetX = PROP_POS.cushion.x;
      hamster.targetY = PROP_POS.cushion.y + 1;
      hamster.state = 'walk';
      hamster.stateTimer = 4.5;
      hamster.statusText = `${hamster.name} berjalan menuju bantal empuk~`;
      w.globalStatusText = hamster.statusText;
      return;
    }

    // 9) Clicking bedding -> waddle over curiously
    if (y >= FLOOR_TOP_Y - 6) {
      hamster.onLoft = false;
      hamster.targetTreatId = null;
      hamster.targetAction = 'none';
      hamster.targetX = Math.max(32, Math.min(VIRTUAL_W - 36, x));
      hamster.targetY = Math.max(FLOOR_TOP_Y + 8, Math.min(FLOOR_BOTTOM_Y - 5, y));
      hamster.state = 'walk';
      hamster.stateTimer = 4.5;
      hamster.statusText = `${hamster.name} menghampiri jarimu dengan penuh rasa ingin tahu!`;
      w.globalStatusText = hamster.statusText;
      spawnParticle(w, 'question', hamster.x, hamster.y - 26, '#6C8CE8', 0, -8, 0.7);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (zoomedOutRef.current) return;
    if (!isPointerDownRef.current || toolRef.current !== 'pet') return;
    const { x, y } = toVirtualCoords(e);
    const dx = lastPointerXRef.current !== null ? x - lastPointerXRef.current : 0;
    lastPointerXRef.current = x;

    // If currently holding a hamster -> carry it around in your hand!
    if (heldHamsterIdRef.current !== null) {
      const held = worldRef.current.hamsters.find(
        (h) => h.id === heldHamsterIdRef.current
      );
      if (held) {
        held.x = Math.max(28, Math.min(VIRTUAL_W - 28, x));
        held.y = Math.max(48, Math.min(FLOOR_BOTTOM_Y - 2, y + 12));
        held.phys.wobbleAmp = Math.min(2.4, Math.abs(dx) * 0.25 + 0.4);
        held.phys.wobblePhase += dx * 0.35;
      }
      return;
    }

    const target =
      (pettingHamsterIdRef.current !== null
        ? worldRef.current.hamsters.find((h) => h.id === pettingHamsterIdRef.current)
        : null) || findHamsterNear(x, y, 26);

    if (target && Math.hypot(x - target.x, y - (target.y - 11)) <= 28) {
      triggerPetOn(target, dx, false);
    }
  };

  const handlePointerUp = () => {
    if (heldHamsterIdRef.current !== null) {
      const held = worldRef.current.hamsters.find(
        (h) => h.id === heldHamsterIdRef.current
      );
      if (held) {
        dropHeldHamster(worldRef.current, held);
      }
      heldHamsterIdRef.current = null;
    }
    if (pettingHamsterIdRef.current !== null) {
      const target = worldRef.current.hamsters.find(
        (h) => h.id === pettingHamsterIdRef.current
      );
      if (target && target.state === 'squeeze') {
        target.phys.squeezeAmount = 0;
        applySquishImpulse(target, -7.2, 4);
        target.state = 'idle';
        target.stateTimer = 1.0;
      }
    }
    isPointerDownRef.current = false;
    lastPointerXRef.current = null;
    pettingHamsterIdRef.current = null;
  };

  return (
    <div
      className={`relative w-full overflow-hidden rounded-xl border-4 bg-[#3E2820] transition-all duration-200 ${
        isActive
          ? 'border-[#5A392C] shadow-[0_6px_0_#5A392C]'
          : 'border-[#8C6854] shadow-[0_4px_0_#8C6854] opacity-95 hover:opacity-100'
      }`}
    >
      <canvas
        ref={canvasRef}
        width={VIRTUAL_W}
        height={VIRTUAL_H}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className={`pixel-canvas block w-full aspect-[304/192] select-none ${
          zoomedOut
            ? 'cursor-zoom-in'
            : toolMode === 'pet'
            ? 'cursor-grab active:cursor-grabbing'
            : 'cursor-crosshair'
        }`}
      />
    </div>
  );
};

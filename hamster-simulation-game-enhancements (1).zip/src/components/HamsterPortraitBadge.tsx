import React from 'react';
import { HamsterCoat } from '../types/hamster';

interface Props {
  coat: HamsterCoat;
  size?: number;
}

export const HamsterPortraitBadge: React.FC<Props> = ({ coat, size = 32 }) => {
  return (
    <svg
      viewBox="0 0 16 16"
      width={size}
      height={size}
      shapeRendering="crispEdges"
      className="shrink-0"
    >
      {/* Ears */}
      <rect x="2" y="2" width="3" height="3" fill={coat.outline} />
      <rect x="11" y="2" width="3" height="3" fill={coat.outline} />
      <rect x="3" y="3" width="2" height="2" fill={coat.earOuter} />
      <rect x="11" y="3" width="2" height="2" fill={coat.earOuter} />
      <rect x="3" y="3" width="1" height="1" fill={coat.earInner} />
      <rect x="12" y="3" width="1" height="1" fill={coat.earInner} />

      {/* Head Outline */}
      <path
        fill={coat.outline}
        d="M4 3h8v1h2v2h1v5h-1v2h-2v1H4v-1H2v-2H1V6h1V4h2V3z"
      />
      {/* Fur Base */}
      <path
        fill={coat.furBase}
        d="M4 4h8v1h2v5h-1v2h-2v1H5v-1H3v-2H2V5h2V4z"
      />
      {/* Highlight */}
      <rect x="5" y="4" width="6" height="2" fill={coat.furLight} />
      {/* Stripe / Panda Patch */}
      {(coat.id === 'taro-boba' || coat.id === 'matcha-latte') && coat.stripe && (
        <rect x="7" y="4" width="2" height="3" fill={coat.stripe} />
      )}
      {coat.id === 'choco-panda' && coat.stripe && (
        <>
          <rect x="3" y="6" width="3" height="3" fill={coat.stripe} />
          <rect x="10" y="6" width="3" height="3" fill={coat.stripe} />
        </>
      )}
      {/* Belly/Chin */}
      <rect x="5" y="10" width="6" height="3" fill={coat.belly} />
      {/* Eyes */}
      <rect x="4" y="7" width="2" height="2" fill={coat.eye} />
      <rect x="10" y="7" width="2" height="2" fill={coat.eye} />
      <rect x="4" y="7" width="1" height="1" fill="#FFFFFF" />
      <rect x="10" y="7" width="1" height="1" fill="#FFFFFF" />
      {/* Blush */}
      <rect x="3" y="9" width="2" height="1" fill={coat.blush} />
      <rect x="11" y="9" width="2" height="1" fill={coat.blush} />
      {/* Nose */}
      <rect x="7" y="9" width="2" height="1" fill={coat.nose} />
    </svg>
  );
};

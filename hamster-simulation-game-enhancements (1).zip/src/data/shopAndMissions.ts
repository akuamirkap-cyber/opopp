import { MissionEventType, MissionItem, ShopItem } from '../types/hamster';

export const SHOP_CATALOG: ShopItem[] = [
  {
    id: 'light-warm-gold',
    category: 'lights',
    name: 'Lampu Fairy Hangat',
    description: 'Untaian lampu kuning keemasan yang berkedip hangat di atas kandang.',
    price: 30,
    badgeColor: '#FFE8A3',
    fairyLightStyle: 'warm-gold',
  },
  {
    id: 'light-pastel-rainbow',
    category: 'lights',
    name: 'Lampu Bintang Pastel',
    description: 'Lampu hias warna pelangi pastel lembut dengan kilau bintang!',
    price: 55,
    badgeColor: '#FFD6E8',
    fairyLightStyle: 'pastel-rainbow',
  },
  {
    id: 'light-sakura-glow',
    category: 'lights',
    name: 'Lampion Sakura Glow',
    description: 'Lampion kelopak sakura bercahaya merah muda romantis!',
    price: 80,
    badgeColor: '#FFC4D6',
    fairyLightStyle: 'sakura-glow',
  },
  {
    id: 'acc-flower-clip',
    category: 'accessory',
    name: 'Jepit Bunga Imut',
    description: 'Jepit bunga sakura mungil di kepala hamstermu!',
    price: 35,
    badgeColor: '#FFD6E2',
    accessoryId: 'flower-clip',
  },
  {
    id: 'acc-strawberry-hat',
    category: 'accessory',
    name: 'Topi Stroberi Mini',
    description: 'Topi stroberi super gemas dipakai hamster favoritmu!',
    price: 60,
    badgeColor: '#FFC2CE',
    accessoryId: 'strawberry-hat',
  },
  {
    id: 'acc-star-glasses',
    category: 'accessory',
    name: 'Kacamata Bintang Keren',
    description: 'Biar makin kece pas ngebut di roda atau gelut lucu!',
    price: 75,
    badgeColor: '#D6ECFF',
    accessoryId: 'star-glasses',
  },
  {
    id: 'acc-crown',
    category: 'accessory',
    name: 'Mahkota Raja Mochi',
    description: 'Mahkota emas berkilau untuk hamster sultan paling disayang!',
    price: 110,
    badgeColor: '#FFE599',
    accessoryId: 'crown',
  },
  {
    id: 'decor-rainbow-slide',
    category: 'decor',
    name: 'Perosotan Pelangi',
    description: 'Ubah perosotan lantai 2 jadi warna pelangi pastel berkilau!',
    price: 65,
    badgeColor: '#D9F7E8',
    decorType: 'rainbow-slide',
  },
  {
    id: 'decor-flower-loft',
    category: 'decor',
    name: 'Taman Mini Lantai 2',
    description: 'Tambahkan tanaman pot & bantal awan mewah di lantai atas!',
    price: 70,
    badgeColor: '#E5DBFF',
    decorType: 'flower-loft',
  },
];

interface MissionTemplate {
  eventType: MissionEventType;
  title: string;
  description: string;
  target: number;
  rewardCoins: number;
  rewardXp: number;
  badgeEmoji: string;
}

const MISSION_TEMPLATES: MissionTemplate[] = [
  {
    eventType: 'pet_squeeze',
    title: 'Remas Puding Mochi',
    description: 'Elus atau tekan-tahan hamster sampai membal kayak puding 3x!',
    target: 3,
    rewardCoins: 35,
    rewardXp: 25,
    badgeEmoji: '🍮',
  },
  {
    eventType: 'climb_slide',
    title: 'Petualang Lantai 2',
    description: 'Naik tangga kayu & meluncur di perosotan lantai atas 1x!',
    target: 1,
    rewardCoins: 45,
    rewardXp: 35,
    badgeEmoji: '🛝',
  },
  {
    eventType: 'feed_treat',
    title: 'Pesta Nyam-Nyam',
    description: 'Beri camilan Kuaci / Stroberi / Jagung ke hamster 3x!',
    target: 3,
    rewardCoins: 40,
    rewardXp: 30,
    badgeEmoji: '🍓',
  },
  {
    eventType: 'ragdoll_wheel',
    title: 'Turbo Roda Ragdoll!',
    description: 'Buat hamster kebanteran muter & terlempar ragdoll dari roda 1x!',
    target: 1,
    rewardCoins: 50,
    rewardXp: 40,
    badgeEmoji: '🎡',
  },
  {
    eventType: 'play_fight',
    title: 'Duel Paw Lucu',
    description: 'Ajak dua hamster main gelut lucu ala kucing 1x!',
    target: 1,
    rewardCoins: 40,
    rewardXp: 30,
    badgeEmoji: '🐾',
  },
  {
    eventType: 'bury_pile',
    title: 'Siluman Sekam',
    description: 'Kubur hamster ke dalam tumpukan sekam empuk 1x!',
    target: 1,
    rewardCoins: 35,
    rewardXp: 25,
    badgeEmoji: '🌾',
  },
  {
    eventType: 'house_hide',
    title: 'Cilukba Rumah Hamster',
    description: 'Masukkan hamster untuk sembunyi atau tidur di rumah 1x!',
    target: 1,
    rewardCoins: 35,
    rewardXp: 25,
    badgeEmoji: '🏠',
  },
  {
    eventType: 'chubby_boing',
    title: 'Bakpao Super Gembrot',
    description: 'Ubah hamster jadi Gemuk / Gembrot (tekan B) 2x!',
    target: 2,
    rewardCoins: 30,
    rewardXp: 20,
    badgeEmoji: '🥟',
  },
  {
    eventType: 'lift_hamster',
    title: 'Gendong Mochi Tembem',
    description: 'Angkat & gendong hamster di genggaman tanganmu 2x!',
    target: 2,
    rewardCoins: 40,
    rewardXp: 30,
    badgeEmoji: '🤲',
  },
  {
    eventType: 'glass_peek',
    title: 'Sapa di Kaca Depan',
    description: 'Buat hamster menempel di kaca & melambai padamu 1x!',
    target: 1,
    rewardCoins: 35,
    rewardXp: 25,
    badgeEmoji: '👋',
  },
];

let missionSeq = 1;

export function createMissionFromTemplate(tpl: MissionTemplate): MissionItem {
  return {
    id: `m-${missionSeq++}-${tpl.eventType}`,
    eventType: tpl.eventType,
    title: tpl.title,
    description: tpl.description,
    progress: 0,
    target: tpl.target,
    rewardCoins: tpl.rewardCoins,
    rewardXp: tpl.rewardXp,
    claimed: false,
    badgeEmoji: tpl.badgeEmoji,
  };
}

export function createInitialMissions(): MissionItem[] {
  return [
    createMissionFromTemplate(MISSION_TEMPLATES[0]), // Remas Puding
    createMissionFromTemplate(MISSION_TEMPLATES[1]), // Naik Tangga & Perosotan
    createMissionFromTemplate(MISSION_TEMPLATES[2]), // Pesta Nyam-Nyam
  ];
}

export function pickNextMission(existingTypes: Set<MissionEventType>): MissionItem {
  const candidates = MISSION_TEMPLATES.filter((t) => !existingTypes.has(t.eventType));
  const pool = candidates.length > 0 ? candidates : MISSION_TEMPLATES;
  const chosen = pool[Math.floor(Math.random() * pool.length)];
  return createMissionFromTemplate(chosen);
}

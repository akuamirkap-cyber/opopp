import React, { useCallback, useEffect, useRef, useState } from 'react';
import { HamsterPortraitBadge } from './components/HamsterPortraitBadge';
import {
  PixelBerryIcon,
  PixelBoltIcon,
  PixelBowlIcon,
  PixelCameraIcon,
  PixelChubbyIcon,
  PixelCoinIcon,
  PixelCornIcon,
  PixelFairyLightIcon,
  PixelHandIcon,
  PixelHeartIcon,
  PixelHouseIcon,
  PixelLadderSlideIcon,
  PixelMoonSunIcon,
  PixelPawFightIcon,
  PixelPileIcon,
  PixelPlusHamIcon,
  PixelRainIcon,
  PixelSeedIcon,
  PixelShopIcon,
  PixelSnowIcon,
  PixelSoundIcon,
  PixelSparkleIcon,
  PixelWheelIcon,
  PixelZoomIcon,
} from './components/PixelIcons';
import { TerrariumCanvas } from './components/TerrariumCanvas';
import { HAMSTER_COATS } from './data/hamsterCoats';
import {
  createInitialMissions,
  pickNextMission,
  SHOP_CATALOG,
} from './data/shopAndMissions';
import {
  applySquishImpulse,
  createInitialWorld,
  cycleChubbyMode,
  getSelectedHamster,
  sendToBuryPile,
  sendToHouse,
  SimWorld,
  spawnExtraHamster,
  spawnParticle,
  triggerGlassPeekOrWallClimb,
  triggerLadderOrSlide,
  triggerPlayFight,
  triggerPuddingSqueeze,
  triggerWheelRagdollDemo,
} from './engine/hamsterAI';
import { FLOOR_TOP_Y, VIRTUAL_H, VIRTUAL_W } from './engine/terrariumRenderer';
import {
  ChubbyLevel,
  FairyLightStyle,
  HamsterState,
  MissionEventType,
  MissionItem,
  ShopItem,
  ToolMode,
  WeatherMode,
} from './types/hamster';
import { pixelSound } from './utils/pixelSound';

const STATE_BADGE_LABELS: Record<HamsterState, string> = {
  idle: 'Santai',
  stand: 'Kepo',
  walk: 'Jalan Gembul',
  climb_ladder: 'Panjat Tangga',
  slide_down: 'Meluncur Weee!',
  run_wheel: 'Ngebut Roda',
  ragdoll: 'Terlempar Boing!',
  held: 'Diangkat Gemes!',
  glass_peek: 'Halo di Kaca!',
  wall_climb: 'Manjat Tembok?!',
  dizzy: 'Pusing Lucu @_@',
  play_fight: 'Gelut Lucu!',
  buried: 'Ngubur Diri',
  hide_house: 'Sembunyi Rumah',
  sleep_house: 'Tidur di Rumah',
  eat: 'Nyam Nyam~',
  stuff_cheek: 'Isi Pipi!',
  unload_stash: 'Simpan Rumah!',
  drink: 'Minum Botol',
  groom: 'Cuci Muka',
  dig: 'Gali Sekam',
  sleep: 'Tidur Mochi',
  petted: 'Manja~',
  squeeze: 'Membal Puding!',
  yawn: 'Menguap',
  stretch: 'Menggeliat',
  shake: 'Bulu Brrr~',
  happy_hop: 'Lompat Senang!',
};

const CHUBBY_LABELS: Record<ChubbyLevel, string> = {
  0: 'Normal',
  1: 'Gemuk',
  2: 'Super Gembrot!',
};

function createStarterAquariums(): SimWorld[] {
  return [
    createInitialWorld('aq-1', 'Aquarium 1: Kamar Mochi', 'pastel-room', [
      { name: 'Mochi', coatId: 'mochi-cream' },
      { name: 'Boba', coatId: 'taro-boba' },
    ]),
    createInitialWorld('aq-2', 'Aquarium 2: Taman Sakura', 'sakura-garden', [
      { name: 'Sakura', coatId: 'sakura-berry' },
      { name: 'Choco', coatId: 'choco-panda' },
    ]),
  ];
}

export function App() {
  const worldsRef = useRef<SimWorld[]>(createStarterAquariums());
  const canvasMapRef = useRef<Record<string, HTMLCanvasElement | null>>({});
  const shelfRef = useRef<HTMLDivElement | null>(null);
  const shelfDragRef = useRef<{ dragging: boolean; startX: number; scrollLeft: number }>({
    dragging: false,
    startX: 0,
    scrollLeft: 0,
  });

  const [activeAquariumIdx, setActiveAquariumIdx] = useState<number>(0);
  const [zoomedOut, setZoomedOut] = useState<boolean>(true);
  const [, setTick] = useState<number>(0);

  const [isEditingName, setIsEditingName] = useState<boolean>(false);
  const [nameDraft, setNameDraft] = useState<string>('Mochi');

  const [nightMode, setNightMode] = useState<boolean>(false);
  const [weather, setWeather] = useState<WeatherMode>('clear');
  const [fairyLightsOn, setFairyLightsOn] = useState<boolean>(true);
  const [activeLightStyle, setActiveLightStyle] =
    useState<Exclude<FairyLightStyle, 'none'>>('warm-gold');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [toolMode, setToolMode] = useState<ToolMode>('pet');
  const [snapshotUrl, setSnapshotUrl] = useState<string | null>(null);

  // Progression: Coins, XP, Missions, and Shop!
  const [coins, setCoins] = useState<number>(75);
  const [xp, setXp] = useState<number>(0);
  const [missions, setMissions] = useState<MissionItem[]>(createInitialMissions);
  const [shopOpen, setShopOpen] = useState<boolean>(false);
  const [ownedIds, setOwnedIds] = useState<string[]>(['light-warm-gold']);
  const [rainbowSlideUnlocked, setRainbowSlideUnlocked] = useState<boolean>(false);
  const [flowerLoftUnlocked, setFlowerLoftUnlocked] = useState<boolean>(false);

  const level = Math.floor(xp / 100) + 1;
  const xpIntoLevel = xp % 100;

  const forceRefresh = useCallback(() => {
    setTick((t) => (t + 1) % 1000000);
  }, []);

  // Mission event handler attached to all worlds
  const handleMissionEvent = useCallback((eventType: MissionEventType) => {
    setMissions((prev) => {
      let changed = false;
      const next = prev.map((m) => {
        if (m.eventType === eventType && !m.claimed && m.progress < m.target) {
          changed = true;
          return { ...m, progress: Math.min(m.target, m.progress + 1) };
        }
        return m;
      });
      return changed ? next : prev;
    });
  }, []);

  useEffect(() => {
    for (const w of worldsRef.current) {
      w.onMissionEvent = handleMissionEvent;
    }
  }, [handleMissionEvent]);

  const worlds = worldsRef.current;
  const activeWorld = worlds[activeAquariumIdx] || worlds[0];
  const selectedHamster = getSelectedHamster(activeWorld);
  const currentCoat =
    HAMSTER_COATS.find((c) => c.id === selectedHamster.coatId) || HAMSTER_COATS[0];

  // Sync nightMode, weather, fairy lights, and decor unlocks to all aquariums
  useEffect(() => {
    const lightVal: FairyLightStyle = fairyLightsOn ? activeLightStyle : 'none';
    for (const w of worldsRef.current) {
      w.nightMode = nightMode;
      w.weather = weather;
      w.fairyLightStyle = lightVal;
      w.rainbowSlide = rainbowSlideUnlocked;
      w.flowerLoft = flowerLoftUnlocked;
    }
    pixelSound.setWeatherAmbience(weather);
  }, [nightMode, weather, fairyLightsOn, activeLightStyle, rainbowSlideUnlocked, flowerLoftUnlocked]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (isEditingName || shopOpen) return;
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }
      if (e.key === 'b' || e.key === 'B') {
        e.preventDefault();
        pixelSound.unlock();
        cycleChubbyMode(worldsRef.current[activeAquariumIdx] || worldsRef.current[0]);
        forceRefresh();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isEditingName, shopOpen, activeAquariumIdx, forceRefresh]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    pixelSound.setEnabled(next);
    if (next) {
      pixelSound.unlock();
      pixelSound.playSqueak();
    }
  };

  const handleSetWeather = (nextWeather: WeatherMode) => {
    pixelSound.unlock();
    setWeather(nextWeather);
    pixelSound.setWeatherAmbience(nextWeather);
    pixelSound.playSparkle();
  };

  const handleAddThirdAquarium = () => {
    if (worldsRef.current.length >= 3) return;
    pixelSound.unlock();
    const third = createInitialWorld('aq-3', 'Aquarium 3: Kafe Bintang', 'starlight-cafe', [
      { name: 'Matcha', coatId: 'matcha-latte' },
      { name: 'Pudding', coatId: 'caramel-pudding' },
    ]);
    third.nightMode = nightMode;
    third.weather = weather;
    third.fairyLightStyle = fairyLightsOn ? activeLightStyle : 'none';
    third.rainbowSlide = rainbowSlideUnlocked;
    third.flowerLoft = flowerLoftUnlocked;
    third.onMissionEvent = handleMissionEvent;
    worldsRef.current.push(third);
    setActiveAquariumIdx(worldsRef.current.length - 1);
    pixelSound.playSpawnPop();
    forceRefresh();
  };

  const handleClaimMission = (missionId: string) => {
    pixelSound.unlock();
    const target = missions.find((m) => m.id === missionId);
    if (!target || target.progress < target.target || target.claimed) return;

    setCoins((c) => c + target.rewardCoins);
    setXp((prevXp) => prevXp + target.rewardXp);
    pixelSound.playHappyChime();

    // Celebrate with floating coin & star particles inside the active aquarium!
    for (let i = 0; i < 6; i++) {
      spawnParticle(
        activeWorld,
        i % 2 === 0 ? 'coin' : 'star',
        selectedHamster.x + (Math.random() * 24 - 12),
        selectedHamster.y - 24,
        '#FFE066',
        (Math.random() - 0.5) * 32,
        -26 - Math.random() * 14,
        1.15
      );
    }
    activeWorld.globalStatusText = `YEAY! Misi "${target.title}" selesai! +${target.rewardCoins} Koin Kuaci & +${target.rewardXp} XP!`;

    setMissions((prev) => {
      const otherTypes = new Set(
        prev.filter((m) => m.id !== missionId).map((m) => m.eventType)
      );
      const replacement = pickNextMission(otherTypes);
      return prev.map((m) => (m.id === missionId ? replacement : m));
    });
    forceRefresh();
  };

  const handleBuyOrEquipShopItem = (item: ShopItem) => {
    pixelSound.unlock();
    const isOwned = ownedIds.includes(item.id);

    if (!isOwned) {
      if (coins < item.price) {
        pixelSound.playDrop();
        return;
      }
      setCoins((c) => c - item.price);
      setOwnedIds((prev) => [...prev, item.id]);
      pixelSound.playSpawnPop();
    } else {
      pixelSound.playSqueak();
    }

    // Equip / activate item immediately!
    if (item.category === 'lights' && item.fairyLightStyle && item.fairyLightStyle !== 'none') {
      setActiveLightStyle(item.fairyLightStyle);
      setFairyLightsOn(true);
      activeWorld.globalStatusText = `✨ ${item.name} terpasang indah di atas semua aquarium!`;
    } else if (item.category === 'accessory' && item.accessoryId) {
      selectedHamster.accessory =
        selectedHamster.accessory === item.accessoryId ? 'none' : item.accessoryId;
      applySquishImpulse(selectedHamster, -4.5);
      activeWorld.globalStatusText =
        selectedHamster.accessory === 'none'
          ? `${selectedHamster.name} melepas aksesorinya~`
          : `👑 ${selectedHamster.name} memakai ${item.name}! Lucu banget!`;
    } else if (item.category === 'decor') {
      if (item.decorType === 'rainbow-slide') {
        setRainbowSlideUnlocked(true);
        activeWorld.globalStatusText = `🌈 Perosotan Lantai 2 sekarang berwarna pelangi pastel!`;
      } else if (item.decorType === 'flower-loft') {
        setFlowerLoftUnlocked(true);
        activeWorld.globalStatusText = `🌸 Lantai 2 dipercantik dengan tanaman pot & bantal awan mewah!`;
      }
    }
    forceRefresh();
  };

  const panShelf = (dir: -1 | 1) => {
    if (shelfRef.current) {
      shelfRef.current.scrollBy({ left: dir * 360, behavior: 'smooth' });
    }
  };

  const commitName = () => {
    const trimmed = nameDraft.trim().slice(0, 14);
    if (trimmed) {
      selectedHamster.name = trimmed;
      forceRefresh();
    } else {
      setNameDraft(selectedHamster.name);
    }
    setIsEditingName(false);
  };

  const handleSelectTreat = (mode: 'seed' | 'strawberry' | 'corn') => {
    pixelSound.unlock();
    setToolMode(mode);
    const w = activeWorld;
    if (w.treats.length >= 8) w.treats.shift();
    const tx = 85 + Math.random() * 120;
    w.treats.push({
      id: w.nextId++,
      type: mode,
      x: tx,
      y: 68,
      vy: 0,
      landed: false,
      onLoft: false,
      bitesLeft: 1,
    });
    pixelSound.playDrop();
    forceRefresh();
  };

  const handleRefillAll = () => {
    pixelSound.unlock();
    activeWorld.bowlSeeds = 100;
    activeWorld.waterLevel = 100;
    activeWorld.globalStatusText = `Mangkuk kuaci & botol minum besar sudah diisi penuh lagi!`;
    pixelSound.playHappyChime();
    forceRefresh();
  };

  const handleCleanBedding = () => {
    pixelSound.unlock();
    activeWorld.cleanliness = 100;
    for (const h of activeWorld.hamsters) {
      h.stats.happiness = Math.min(100, h.stats.happiness + 10);
    }
    for (let i = 0; i < 8; i++) {
      spawnParticle(
        activeWorld,
        'sparkle',
        40 + Math.random() * 210,
        FLOOR_TOP_Y + Math.random() * 26,
        '#FFE066',
        (Math.random() - 0.5) * 14,
        -16 - Math.random() * 10,
        1.1
      );
    }
    activeWorld.globalStatusText = `Serbuk kayu ${activeWorld.aquariumName} sudah diganti bersih dan harum!`;
    pixelSound.playSparkle();
    forceRefresh();
  };

  const handleTakeSnapshot = () => {
    const canvas = canvasMapRef.current[activeWorld.aquariumId];
    if (!canvas) return;
    const out = document.createElement('canvas');
    out.width = VIRTUAL_W * 4;
    out.height = VIRTUAL_H * 4;
    const octx = out.getContext('2d');
    if (!octx) return;
    octx.imageSmoothingEnabled = false;
    octx.drawImage(canvas, 0, 0, out.width, out.height);
    setSnapshotUrl(out.toDataURL('image/png'));
    pixelSound.playSparkle();
  };

  const cheekPuffDots = Math.min(4, Math.round(selectedHamster.stats.cheekPuff));
  const claimableCount = missions.filter((m) => m.progress >= m.target && !m.claimed).length;

  return (
    <div className="min-h-screen w-full px-3 py-4 sm:px-6 sm:py-5 flex flex-col items-center">
      <div className="w-full max-w-5xl flex flex-col gap-3">
        {/* Top Cozy 16-Bit Header */}
        <header className="pixel-panel rounded-2xl px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="p-1.5 rounded-xl bg-[#FFE9C9] border-2 border-[#5A392C] animate-float-slow">
              <HamsterPortraitBadge coat={currentCoat} size={36} />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="font-pixel text-xl sm:text-2xl font-bold tracking-tight text-[#4A3228]">
                  MochiHamu!
                </h1>
                <span className="font-pixel text-[11px] px-2 py-0.5 rounded-md bg-[#FFD6E2] border-2 border-[#5A392C] text-[#5A392C] font-semibold">
                  Lv.{level} ({xpIntoLevel}/100 XP)
                </span>
                <span className="inline-flex items-center gap-1 font-pixel text-xs px-2 py-0.5 rounded-md bg-[#FFF0A8] border-2 border-[#5A392C] text-[#5A392C] font-bold">
                  <PixelCoinIcon className="w-3.5 h-3.5" />
                  {coins} Koin
                </span>
                {selectedHamster.chubbyLevel > 0 && (
                  <span className="font-pixel text-[11px] px-2 py-0.5 rounded-md bg-[#FFE29E] border-2 border-[#5A392C] text-[#5A392C] font-bold">
                    ★ {CHUBBY_LABELS[selectedHamster.chubbyLevel]}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2 mt-0.5 text-sm flex-wrap">
                <span className="font-soft text-xs font-bold text-[#8A6552]">
                  {activeWorld.aquariumName} • Aktif:
                </span>
                {isEditingName ? (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      commitName();
                    }}
                    className="inline-flex items-center gap-1"
                  >
                    <input
                      type="text"
                      value={nameDraft}
                      onChange={(e) => setNameDraft(e.target.value)}
                      onBlur={commitName}
                      autoFocus
                      maxLength={14}
                      className="font-pixel text-sm px-2 py-0.5 w-28 rounded bg-white border-2 border-[#5A392C] focus:outline-none"
                    />
                  </form>
                ) : (
                  <button
                    onClick={() => {
                      setNameDraft(selectedHamster.name);
                      setIsEditingName(true);
                    }}
                    title="Klik untuk ganti nama hamster aktif"
                    className="font-pixel text-sm font-bold text-[#5A392C] hover:text-[#D95D82] underline decoration-dotted cursor-pointer"
                  >
                    {selectedHamster.name} ✎
                  </button>
                )}
                <span className="text-[#C6A892]">•</span>
                <span className="inline-flex items-center gap-1 font-pixel text-xs font-semibold text-[#D95D82]">
                  <PixelHeartIcon className="w-3.5 h-3.5" />
                  Sayang {selectedHamster.stats.affection}
                </span>
              </div>
            </div>
          </div>

          {/* Right Quick Toggles: Shop, Lights, Zoom, Weather, Night/Day, Sound */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                pixelSound.unlock();
                setShopOpen(true);
                pixelSound.playSparkle();
              }}
              className="pixel-btn rounded-xl px-2.5 py-1.5 bg-[#FFD6E8] text-xs font-pixel font-bold flex items-center gap-1.5"
              title="Buka Toko Mochi untuk beli Lampu Hias, Topi Hamster & Dekorasi!"
            >
              <PixelShopIcon className="w-4 h-4" />
              <span>Toko Mochi</span>
            </button>

            <button
              onClick={() => {
                pixelSound.unlock();
                setFairyLightsOn((v) => !v);
                pixelSound.playSparkle();
              }}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1.5 ${
                fairyLightsOn ? 'pixel-btn-active bg-[#FFF0B3]' : 'bg-[#F2E4DC]'
              }`}
              title="Nyalakan / matikan Lampu Hias indah"
            >
              <PixelFairyLightIcon active={fairyLightsOn} className="w-4 h-4" />
              <span className="hidden sm:inline">
                {fairyLightsOn ? 'Lampu On' : 'Lampu Off'}
              </span>
            </button>

            <button
              onClick={() => {
                pixelSound.unlock();
                setZoomedOut((z) => !z);
                pixelSound.playSqueak();
              }}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1.5 ${
                zoomedOut ? 'pixel-btn-active bg-[#FFE2AD]' : 'bg-[#DDF5FF]'
              }`}
            >
              <PixelZoomIcon zoomedOut={zoomedOut} className="w-4 h-4" />
              <span>{zoomedOut ? 'Zoom In' : 'Zoom Out'}</span>
            </button>

            {/* 3-Way Weather Selector */}
            <div className="inline-flex items-center gap-1 bg-[#F5E6D3] p-1 rounded-xl border-2 border-[#5A392C]">
              <button
                onClick={() => handleSetWeather('clear')}
                className={`px-2 py-1 rounded-lg font-pixel text-xs font-bold cursor-pointer transition ${
                  weather === 'clear'
                    ? 'bg-[#FFE59E] border-2 border-[#5A392C]'
                    : 'hover:bg-[#FFF5E6]'
                }`}
                title="Cuaca Cerah"
              >
                ☀
              </button>
              <button
                onClick={() => handleSetWeather('rain')}
                className={`px-2 py-1 rounded-lg font-pixel text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition ${
                  weather === 'rain'
                    ? 'bg-[#B9DCFF] border-2 border-[#5A392C]'
                    : 'hover:bg-[#FFF5E6]'
                }`}
                title="Hujan Deras + Suara Hujan"
              >
                <PixelRainIcon raining className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Hujan</span>
              </button>
              <button
                onClick={() => handleSetWeather('snow')}
                className={`px-2 py-1 rounded-lg font-pixel text-xs font-bold inline-flex items-center gap-1 cursor-pointer transition ${
                  weather === 'snow'
                    ? 'bg-[#E2F3FF] border-2 border-[#5A392C]'
                    : 'hover:bg-[#FFF5E6]'
                }`}
                title="Cuaca Salju"
              >
                <PixelSnowIcon className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Salju</span>
              </button>
            </div>

            <button
              onClick={() => {
                pixelSound.unlock();
                setNightMode((v) => !v);
              }}
              className="pixel-btn rounded-xl px-2.5 py-1.5 bg-[#FFF1D6] text-xs font-pixel font-bold flex items-center gap-1"
              title="Ubah suasana pagi / lampu malam"
            >
              <PixelMoonSunIcon night={nightMode} className="w-4 h-4" />
            </button>

            <button
              onClick={toggleSound}
              className={`pixel-btn rounded-xl px-2.5 py-1.5 text-xs font-pixel font-bold flex items-center gap-1 ${
                soundEnabled ? 'bg-[#DCF5E4]' : 'bg-[#F2E4DC]'
              }`}
              title="Nyalakan / matikan suara"
            >
              <PixelSoundIcon enabled={soundEnabled} className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Aquarium Collection Navigation & Zoom Controls */}
        <section className="pixel-panel rounded-xl px-3 py-2 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-pixel text-xs font-bold text-[#6E4A3A]">
              Aquarium Bertingkat:
            </span>
            {worlds.map((w, idx) => {
              const isSel = idx === activeAquariumIdx;
              return (
                <button
                  key={w.aquariumId}
                  onClick={() => {
                    pixelSound.unlock();
                    setActiveAquariumIdx(idx);
                    pixelSound.playSqueak();
                    if (zoomedOut && shelfRef.current) {
                      const card = shelfRef.current.children[idx] as HTMLElement | undefined;
                      card?.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
                    }
                  }}
                  className={`pixel-btn rounded-lg px-2.5 py-1 font-pixel text-xs font-bold flex items-center gap-1.5 ${
                    isSel ? 'pixel-btn-active bg-[#FFE2AD]' : 'bg-[#FFFDF9]'
                  }`}
                >
                  <span>{w.aquariumName}</span>
                  <span className="px-1.5 rounded bg-[#FFD6E2] border border-[#5A392C] text-[10px]">
                    {w.hamsters.length} 🐹
                  </span>
                </button>
              );
            })}
            {worlds.length < 3 && (
              <button
                onClick={handleAddThirdAquarium}
                className="pixel-btn rounded-lg px-2.5 py-1 bg-[#C9F7DB] font-pixel text-xs font-bold"
              >
                + Aquarium Baru
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5">
            {zoomedOut ? (
              <>
                <button
                  onClick={() => panShelf(-1)}
                  className="pixel-btn rounded-lg px-2 py-1 bg-[#FFF1D6] font-pixel text-xs font-bold"
                >
                  ◀ Geser Kiri
                </button>
                <button
                  onClick={() => panShelf(1)}
                  className="pixel-btn rounded-lg px-2 py-1 bg-[#FFF1D6] font-pixel text-xs font-bold"
                >
                  Geser Kanan ▶
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() =>
                    setActiveAquariumIdx((i) => (i - 1 + worlds.length) % worlds.length)
                  }
                  className="pixel-btn rounded-lg px-2 py-1 bg-[#FFF1D6] font-pixel text-xs font-bold"
                >
                  ◀ Aq Sebelumnya
                </button>
                <button
                  onClick={() =>
                    setActiveAquariumIdx((i) => (i + 1) % worlds.length)
                  }
                  className="pixel-btn rounded-lg px-2 py-1 bg-[#FFF1D6] font-pixel text-xs font-bold"
                >
                  Aq Berikutnya ▶
                </button>
              </>
            )}
          </div>
        </section>

        {/* MAIN VIEWPORT: Zoom Out Shelf OR Zoom In Single Aquarium */}
        <main className="relative">
          {zoomedOut ? (
            <div className="pixel-panel rounded-2xl p-3 bg-[#F6E5CC]">
              <div className="flex items-center justify-between mb-2 px-1 flex-wrap gap-1">
                <span className="font-pixel text-xs font-bold text-[#5A392C]">
                  🔎 MODE ZOOM OUT — Geser kiri/kanan lihat koleksi aquarium bertingkat, klik salah satu untuk Zoom In!
                </span>
                <span className="font-soft text-[11px] font-bold text-[#8A6552]">
                  {weather === 'rain'
                    ? '🌧️ Hujan Deras + Suara'
                    : weather === 'snow'
                    ? '❄️ Salju Turun'
                    : '☀️ Cerah'}
                  {fairyLightsOn ? ' • ✨ Lampu Hias' : ''}
                </span>
              </div>

              <div
                ref={shelfRef}
                onMouseDown={(e) => {
                  if (!shelfRef.current) return;
                  shelfDragRef.current = {
                    dragging: true,
                    startX: e.pageX - shelfRef.current.offsetLeft,
                    scrollLeft: shelfRef.current.scrollLeft,
                  };
                }}
                onMouseMove={(e) => {
                  if (!shelfDragRef.current.dragging || !shelfRef.current) return;
                  e.preventDefault();
                  const x = e.pageX - shelfRef.current.offsetLeft;
                  const walk = (x - shelfDragRef.current.startX) * 1.4;
                  shelfRef.current.scrollLeft = shelfDragRef.current.scrollLeft - walk;
                }}
                onMouseUp={() => {
                  shelfDragRef.current.dragging = false;
                }}
                onMouseLeave={() => {
                  shelfDragRef.current.dragging = false;
                }}
                className="aquarium-scroll flex gap-4 overflow-x-auto pb-3 pt-1 px-1 snap-x snap-mandatory cursor-grab active:cursor-grabbing"
              >
                {worlds.map((w, idx) => {
                  const isSel = idx === activeAquariumIdx;
                  return (
                    <div
                      key={w.aquariumId}
                      className={`shrink-0 w-[86%] sm:w-[465px] snap-center flex flex-col gap-2 p-2.5 rounded-2xl border-3 transition-all ${
                        isSel
                          ? 'bg-[#FFF9EE] border-[#5A392C] shadow-[0_4px_0_#5A392C]'
                          : 'bg-[#F9EFE0] border-[#8C6854]'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="font-pixel text-sm font-bold text-[#4A3228] truncate">
                            {w.aquariumName}
                          </span>
                          <span className="font-pixel text-[10px] px-1.5 py-0.5 rounded bg-[#FFE29E] border border-[#5A392C]">
                            {w.hamsters.map((h) => h.name).join(', ')}
                          </span>
                        </div>
                        <button
                          onClick={() => {
                            pixelSound.unlock();
                            setActiveAquariumIdx(idx);
                            setZoomedOut(false);
                            pixelSound.playSqueak();
                          }}
                          className="pixel-btn rounded-lg px-2 py-0.5 bg-[#DDF5FF] font-pixel text-[11px] font-bold shrink-0"
                        >
                          🔍 Zoom In
                        </button>
                      </div>

                      <TerrariumCanvas
                        world={w}
                        isActive={isSel}
                        zoomedOut={true}
                        toolMode={toolMode}
                        onSelectAquarium={() => setActiveAquariumIdx(idx)}
                        onZoomInAquarium={() => {
                          setActiveAquariumIdx(idx);
                          setZoomedOut(false);
                        }}
                        onWorldMutated={forceRefresh}
                        registerCanvas={(el) => {
                          canvasMapRef.current[w.aquariumId] = el;
                        }}
                      />

                      <p className="font-soft text-xs font-bold text-[#6E4A3A] truncate px-1">
                        {w.globalStatusText}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <div className="relative">
              <TerrariumCanvas
                world={activeWorld}
                isActive={true}
                zoomedOut={false}
                toolMode={toolMode}
                onSelectAquarium={() => {}}
                onZoomInAquarium={() => {}}
                onWorldMutated={forceRefresh}
                registerCanvas={(el) => {
                  canvasMapRef.current[activeWorld.aquariumId] = el;
                }}
              />
            </div>
          )}

          {/* Live Status Ticker Bar */}
          <div className="mt-2.5 pixel-panel rounded-xl px-3.5 py-2 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <span className="shrink-0 font-pixel text-[11px] px-2 py-0.5 rounded bg-[#FFE4B8] border-2 border-[#5A392C] font-bold uppercase">
                {STATE_BADGE_LABELS[selectedHamster.state]}
              </span>
              <p className="font-soft text-xs sm:text-sm font-bold text-[#4A3228] truncate">
                {activeWorld.globalStatusText}
              </p>
            </div>
            <span className="font-pixel text-[11px] text-[#8A6552] hidden lg:inline">
              Klik &amp; drag hamster untuk mengangkat/gendong • Klik tangga/perosotan untuk naik lantai 2!
            </span>
          </div>
        </main>

        {/* EXCITING REWARDING MISSIONS PANEL */}
        <section className="pixel-panel rounded-2xl p-3 bg-[#FFF8EB]">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <span className="font-pixel text-sm font-bold text-[#5A392C]">
                🎯 Misi Seru Mochi
              </span>
              {claimableCount > 0 && (
                <span className="font-pixel text-[11px] px-2 py-0.5 rounded-full bg-[#9FF2C8] border-2 border-[#5A392C] font-bold animate-bounce">
                  {claimableCount} Hadiah Siap Diklaim!
                </span>
              )}
            </div>
            <button
              onClick={() => {
                pixelSound.unlock();
                setShopOpen(true);
                pixelSound.playSparkle();
              }}
              className="font-pixel text-xs font-bold text-[#D95D82] hover:underline cursor-pointer"
            >
              Belanjakan Koin di Toko Mochi →
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5">
            {missions.map((m) => {
              const done = m.progress >= m.target;
              const pct = Math.min(100, Math.round((m.progress / m.target) * 100));
              return (
                <div
                  key={m.id}
                  className={`rounded-xl border-2 border-[#5A392C] p-2.5 flex flex-col justify-between gap-2 transition-colors ${
                    done ? 'bg-[#E3FCEB]' : 'bg-[#FFFDF8]'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-1">
                      <span className="font-pixel text-xs font-bold text-[#4A3228]">
                        {m.badgeEmoji} {m.title}
                      </span>
                      <span className="inline-flex items-center gap-1 font-pixel text-[11px] px-1.5 py-0.5 rounded bg-[#FFF0A8] border border-[#5A392C] font-bold">
                        +{m.rewardCoins}🪙
                      </span>
                    </div>
                    <p className="font-soft text-[11px] font-bold text-[#7A5442] mt-0.5 leading-snug">
                      {m.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-3 rounded bg-[#EAD8C0] border-2 border-[#5A392C] overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          done ? 'bg-[#6EDB9B]' : 'bg-[#FF9EBB]'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    {done ? (
                      <button
                        onClick={() => handleClaimMission(m.id)}
                        className="pixel-btn rounded-lg px-2 py-0.5 bg-[#95F0BE] font-pixel text-[11px] font-bold text-[#4A3228] shrink-0"
                      >
                        Klaim!
                      </button>
                    ) : (
                      <span className="font-pixel text-[11px] font-bold text-[#5A392C] shrink-0">
                        {m.progress}/{m.target}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Multi-Hamster Switcher Bar inside Active Aquarium */}
        <section className="pixel-panel rounded-xl px-3 py-2 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-pixel text-xs font-bold text-[#6E4A3A]">
              Penghuni {activeWorld.aquariumName}:
            </span>
            {activeWorld.hamsters.map((h) => {
              const c =
                HAMSTER_COATS.find((coat) => coat.id === h.coatId) || HAMSTER_COATS[0];
              const isSel = h.id === activeWorld.selectedHamsterId;
              return (
                <div
                  key={h.id}
                  className={`inline-flex items-center gap-1.5 rounded-lg border-2 border-[#5A392C] pl-1.5 pr-1 py-0.5 transition-colors ${
                    isSel ? 'bg-[#FFE2AD] shadow-sm' : 'bg-[#FFFDF9] hover:bg-[#FFF3DE]'
                  }`}
                >
                  <button
                    onClick={() => {
                      activeWorld.selectedHamsterId = h.id;
                      activeWorld.globalStatusText = h.statusText;
                      applySquishImpulse(h, -2.8);
                      pixelSound.playSqueak();
                      forceRefresh();
                    }}
                    className="inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <HamsterPortraitBadge coat={c} size={20} />
                    <span className="font-pixel text-xs font-bold text-[#4A3228]">
                      {h.name}
                    </span>
                    {h.chubbyLevel > 0 && (
                      <span className="font-pixel text-[10px] px-1 rounded bg-[#FFD6E2] border border-[#5A392C]">
                        {h.chubbyLevel === 2 ? 'Gembrot' : 'Gemuk'}
                      </span>
                    )}
                  </button>
                  {activeWorld.hamsters.length > 1 && (
                    <button
                      onClick={() => {
                        const idx = activeWorld.hamsters.findIndex((x) => x.id === h.id);
                        if (idx !== -1) {
                          activeWorld.hamsters.splice(idx, 1);
                          if (activeWorld.selectedHamsterId === h.id) {
                            activeWorld.selectedHamsterId = activeWorld.hamsters[0].id;
                          }
                          forceRefresh();
                        }
                      }}
                      title={`Keluarkan ${h.name}`}
                      className="ml-0.5 w-4 h-4 rounded text-[10px] font-bold text-[#8A6552] hover:bg-[#FFBFD0] hover:text-[#4A3228] cursor-pointer"
                    >
                      ×
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <button
            onClick={() => {
              pixelSound.unlock();
              spawnExtraHamster(activeWorld);
              forceRefresh();
            }}
            disabled={activeWorld.hamsters.length >= 5}
            className={`pixel-btn rounded-xl px-2.5 py-1 text-xs font-pixel font-bold flex items-center gap-1.5 ${
              activeWorld.hamsters.length >= 5
                ? 'bg-[#EAE0D5] opacity-60 cursor-not-allowed'
                : 'bg-[#C9F7DB]'
            }`}
          >
            <PixelPlusHamIcon className="w-4 h-4" />
            <span>+ Hamster ({activeWorld.hamsters.length}/5)</span>
          </button>
        </section>

        {/* Stat Meters Row */}
        <section className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
          <StatMeter
            label="Kenyang"
            value={selectedHamster.stats.hunger}
            barColor="bg-[#FFB36B]"
            icon={<PixelSeedIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Senang"
            value={selectedHamster.stats.happiness}
            barColor="bg-[#FF7EA5]"
            icon={<PixelHeartIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Energi"
            value={selectedHamster.stats.energy}
            barColor="bg-[#FFE066]"
            icon={<PixelBoltIcon className="w-4 h-4" />}
          />
          <StatMeter
            label="Bersih"
            value={activeWorld.cleanliness}
            barColor="bg-[#88E0B4]"
            icon={<PixelSparkleIcon className="w-4 h-4" />}
          />
          <div className="col-span-2 sm:col-span-1 pixel-panel rounded-xl px-3 py-2 flex items-center justify-between sm:flex-col sm:items-start sm:justify-center gap-1">
            <div className="w-full flex items-center justify-between">
              <span className="font-pixel text-xs font-bold text-[#6E4A3A]">
                Pipi &amp; Rumah
              </span>
              <span className="font-pixel text-[11px] font-bold text-[#B36B43]">
                Stok: {activeWorld.iglooStash.length}
              </span>
            </div>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4].map((dot) => (
                <span
                  key={dot}
                  className={`inline-block w-3 h-3 rounded-sm border-2 border-[#5A392C] transition-transform ${
                    cheekPuffDots >= dot
                      ? 'bg-[#FF9CB8] scale-110'
                      : 'bg-[#F5E6D3]'
                  }`}
                />
              ))}
              <span className="font-pixel text-[11px] text-[#8A6552] ml-1">
                {selectedHamster.storedPouch.length > 0
                  ? `${selectedHamster.storedPouch.length} di pipi`
                  : 'Kosong'}
              </span>
            </div>
          </div>
        </section>

        {/* Bottom Care & Fun Toy Action Dock */}
        <section className="pixel-panel rounded-2xl p-3">
          <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-7 gap-2">
            <ActionButton
              active={toolMode === 'pet'}
              bg="bg-[#FFD6E2]"
              label="Remas Puding"
              icon={<PixelHandIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                setToolMode('pet');
                triggerPuddingSqueeze(activeWorld, selectedHamster, 4);
                forceRefresh();
              }}
            />
            <ActionButton
              active={toolMode === 'seed'}
              bg="bg-[#F5E1C8]"
              label="Kuaci"
              icon={<PixelSeedIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('seed')}
            />
            <ActionButton
              active={toolMode === 'strawberry'}
              bg="bg-[#FFC7D4]"
              label="Stroberi"
              icon={<PixelBerryIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('strawberry')}
            />
            <ActionButton
              active={toolMode === 'corn'}
              bg="bg-[#FFF0A8]"
              label="Jagung"
              icon={<PixelCornIcon className="w-5 h-5" />}
              onClick={() => handleSelectTreat('corn')}
            />
            <ActionButton
              bg="bg-[#D6F5FF]"
              label="Tangga & Seluncur"
              icon={<PixelLadderSlideIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                if (zoomedOut) setZoomedOut(false);
                triggerLadderOrSlide(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#FFE9B8]"
              label="Roda Ragdoll"
              icon={<PixelWheelIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                if (zoomedOut) setZoomedOut(false);
                triggerWheelRagdollDemo(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#FFD2E8]"
              label="Gelut Lucu"
              icon={<PixelPawFightIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                if (zoomedOut) setZoomedOut(false);
                triggerPlayFight(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#DDF5FF]"
              label="Kaca / Manjat"
              icon={<PixelHandIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                if (zoomedOut) setZoomedOut(false);
                triggerGlassPeekOrWallClimb(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              active={selectedHamster.chubbyLevel > 0}
              bg="bg-[#FFE2A8]"
              label="Gembrot [B]"
              icon={<PixelChubbyIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                cycleChubbyMode(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#F9E3C0]"
              label="Kubur Diri"
              icon={<PixelPileIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                sendToBuryPile(activeWorld);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#C8F2E8]"
              label="Sembunyi"
              icon={<PixelHouseIcon className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                sendToHouse(activeWorld, false);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#DCE3FF]"
              label="Tidur Rumah"
              icon={<PixelMoonSunIcon night className="w-5 h-5" />}
              onClick={() => {
                pixelSound.unlock();
                sendToHouse(activeWorld, true);
                forceRefresh();
              }}
            />
            <ActionButton
              bg="bg-[#FFE5EC]"
              label="Isi Botol"
              icon={<PixelBowlIcon className="w-5 h-5" />}
              onClick={handleRefillAll}
            />
            <ActionButton
              bg="bg-[#D5F5E3]"
              label="Bersihkan"
              icon={<PixelSparkleIcon className="w-5 h-5" />}
              onClick={handleCleanBedding}
            />
            <ActionButton
              bg="bg-[#EBDDFB]"
              label="Foto"
              icon={<PixelCameraIcon className="w-5 h-5" />}
              onClick={handleTakeSnapshot}
            />
          </div>
        </section>

        {/* Hamster Breed / Coat Selector */}
        <section className="pixel-panel rounded-2xl p-3">
          <div className="flex items-center justify-between mb-2 flex-wrap gap-1">
            <h2 className="font-pixel text-sm font-bold text-[#5A392C]">
              Warna Bulu untuk {selectedHamster.name} (16-Bit Fur Coats)
            </h2>
            <span className="font-soft text-xs font-bold text-[#8A6552]">
              {currentCoat.subtitle}
            </span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
            {HAMSTER_COATS.map((coat) => {
              const selected = coat.id === selectedHamster.coatId;
              return (
                <button
                  key={coat.id}
                  onClick={() => {
                    pixelSound.unlock();
                    selectedHamster.coatId = coat.id;
                    applySquishImpulse(selectedHamster, -3);
                    pixelSound.playSqueak();
                    forceRefresh();
                  }}
                  className={`pixel-btn rounded-xl px-2.5 py-2 flex items-center gap-2 text-left ${
                    selected
                      ? 'pixel-btn-active bg-[#FFE4B5]'
                      : 'bg-[#FFFDF9] hover:bg-[#FFF5E4]'
                  }`}
                >
                  <div
                    className="p-1 rounded-lg border-2 border-[#5A392C]"
                    style={{ backgroundColor: coat.badgeColor }}
                  >
                    <HamsterPortraitBadge coat={coat} size={24} />
                  </div>
                  <div className="min-w-0">
                    <div className="font-pixel text-xs font-bold text-[#4A3228] truncate">
                      {coat.name}
                    </div>
                    <div className="font-soft text-[10px] font-bold text-[#8A6552]">
                      {selected ? '★ Aktif' : 'Pilih'}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </section>
      </div>

      {/* TOKO MOCHI SHOP MODAL */}
      {shopOpen && (
        <div
          className="fixed inset-0 z-50 bg-[#3B241C]/65 flex items-center justify-center p-4"
          onClick={() => setShopOpen(false)}
        >
          <div
            className="pixel-panel rounded-2xl p-4 max-w-2xl w-full max-h-[85vh] overflow-y-auto flex flex-col gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <PixelShopIcon className="w-6 h-6" />
                <h2 className="font-pixel text-lg font-bold text-[#4A3228]">
                  Toko Mochi — Lampu Hias, Topi &amp; Dekorasi!
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <span className="inline-flex items-center gap-1 font-pixel text-sm px-2.5 py-1 rounded-lg bg-[#FFF0A8] border-2 border-[#5A392C] font-bold">
                  <PixelCoinIcon className="w-4 h-4" />
                  {coins} Koin
                </span>
                <button
                  onClick={() => setShopOpen(false)}
                  className="pixel-btn rounded-lg px-2.5 py-1 bg-[#FFD6E2] font-pixel text-xs font-bold"
                >
                  Tutup
                </button>
              </div>
            </div>

            <p className="font-soft text-xs font-bold text-[#7A5442]">
              Selesaikan Misi Seru untuk mengumpulkan Koin Kuaci, lalu beli lampu hias cantik, aksesori imut untuk {selectedHamster.name}, dan upgrade lantai 2!
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SHOP_CATALOG.map((item) => {
                const isOwned = ownedIds.includes(item.id);
                const canAfford = coins >= item.price;
                const isEquipped =
                  (item.category === 'lights' &&
                    fairyLightsOn &&
                    activeLightStyle === item.fairyLightStyle) ||
                  (item.category === 'accessory' &&
                    selectedHamster.accessory === item.accessoryId) ||
                  (item.decorType === 'rainbow-slide' && rainbowSlideUnlocked) ||
                  (item.decorType === 'flower-loft' && flowerLoftUnlocked);

                return (
                  <div
                    key={item.id}
                    className={`rounded-xl border-2 border-[#5A392C] p-3 flex flex-col justify-between gap-2 ${
                      isEquipped ? 'bg-[#FFF1D6]' : 'bg-[#FFFDF9]'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span
                            className="inline-block w-3 h-3 rounded-sm border border-[#5A392C]"
                            style={{ backgroundColor: item.badgeColor }}
                          />
                          <span className="font-pixel text-sm font-bold text-[#4A3228]">
                            {item.name}
                          </span>
                        </div>
                        <p className="font-soft text-[11px] font-bold text-[#7A5442] mt-1">
                          {item.description}
                        </p>
                      </div>
                      <span className="font-pixel text-[10px] px-1.5 py-0.5 rounded bg-[#F5E6D3] border border-[#5A392C] uppercase shrink-0">
                        {item.category === 'lights'
                          ? 'Lampu'
                          : item.category === 'accessory'
                          ? 'Topi/Aksesori'
                          : 'Dekorasi'}
                      </span>
                    </div>

                    <button
                      onClick={() => handleBuyOrEquipShopItem(item)}
                      disabled={!isOwned && !canAfford}
                      className={`pixel-btn rounded-xl px-3 py-1.5 font-pixel text-xs font-bold w-full ${
                        isEquipped
                          ? 'bg-[#B8F2D0]'
                          : isOwned
                          ? 'bg-[#DDF5FF]'
                          : canAfford
                          ? 'bg-[#FFE59E]'
                          : 'bg-[#EAE0D5] opacity-60 cursor-not-allowed'
                      }`}
                    >
                      {isEquipped
                        ? item.category === 'accessory'
                          ? `✓ Dipakai ${selectedHamster.name} (Klik Lepas)`
                          : '✓ Sedang Terpasang'
                        : isOwned
                        ? item.category === 'accessory'
                          ? `Pakaikan ke ${selectedHamster.name}`
                          : 'Pasang Sekarang'
                        : `Beli (${item.price} 🪙)`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Polaroid Pixel Photo Modal */}
      {snapshotUrl && (
        <div
          className="fixed inset-0 z-50 bg-[#3B241C]/65 flex items-center justify-center p-4"
          onClick={() => setSnapshotUrl(null)}
        >
          <div
            className="pixel-panel rounded-2xl p-4 max-w-md w-full flex flex-col items-center gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-full flex items-center justify-between">
              <span className="font-pixel text-base font-bold text-[#5A392C]">
                Foto Polaroid {selectedHamster.name}!
              </span>
              <button
                onClick={() => setSnapshotUrl(null)}
                className="pixel-btn rounded-lg px-2.5 py-0.5 bg-[#FFD6E2] font-pixel text-xs font-bold"
              >
                Tutup
              </button>
            </div>
            <div className="p-2.5 pb-5 bg-white border-3 border-[#5A392C] rounded-lg shadow-md w-full">
              <img
                src={snapshotUrl}
                alt={`Foto ${selectedHamster.name}`}
                className="pixel-canvas w-full rounded border-2 border-[#5A392C]"
              />
              <p className="font-pixel text-center text-sm font-bold text-[#5A392C] mt-2">
                ♥ {selectedHamster.name} ({activeWorld.aquariumName}) ♥
              </p>
            </div>
            <a
              href={snapshotUrl}
              download={`${selectedHamster.name.toLowerCase()}-16bit.png`}
              className="pixel-btn rounded-xl px-4 py-2 bg-[#B8F2D0] font-pixel text-sm font-bold text-[#4A3228] w-full text-center"
            >
              Simpan Foto Pixel (.PNG)
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

interface StatMeterProps {
  label: string;
  value: number;
  barColor: string;
  icon: React.ReactNode;
}

const StatMeter: React.FC<StatMeterProps> = ({
  label,
  value,
  barColor,
  icon,
}) => {
  const pct = Math.max(0, Math.min(100, Math.round(value)));
  return (
    <div className="pixel-panel rounded-xl px-3 py-2 flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 font-pixel text-xs font-bold text-[#5A392C]">
          {icon}
          {label}
        </span>
        <span className="font-pixel text-xs font-bold text-[#7A5442]">
          {pct}%
        </span>
      </div>
      <div className="w-full h-3 rounded-sm bg-[#EAD8C0] border-2 border-[#5A392C] overflow-hidden">
        <div
          className={`h-full ${barColor} transition-all duration-300`}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
};

interface ActionButtonProps {
  label: string;
  icon: React.ReactNode;
  bg: string;
  active?: boolean;
  onClick: () => void;
}

const ActionButton: React.FC<ActionButtonProps> = ({
  label,
  icon,
  bg,
  active,
  onClick,
}) => (
  <button
    onClick={onClick}
    className={`pixel-btn rounded-xl px-1.5 py-2 flex flex-col items-center justify-center gap-1 ${bg} ${
      active ? 'pixel-btn-active ring-2 ring-[#FF6B93]' : ''
    }`}
  >
    {icon}
    <span className="font-pixel text-[10px] font-bold text-[#4A3228] leading-tight text-center">
      {label}
    </span>
  </button>
);

export default App;

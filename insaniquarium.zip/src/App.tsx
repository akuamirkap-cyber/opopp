import { useCallback, useEffect, useRef, useState } from 'react';
import { Aquarium, MAX_FISH, MAX_TURTLES } from './sim/engine';
import { VARIETIES, drawFish } from './sim/fish';
import { THEMES } from './sim/scene';
import { Turtle, drawTurtle } from './sim/turtle';
import { pack } from './sim/palette';

const ICON = 24;

function iconBuffer() {
  const buf = new Uint32Array(ICON * ICON).fill(pack(98, 204, 224));
  for (let y = 0; y < ICON; y++) {
    for (let x = 0; x < ICON; x++) if (y > 13 + ((x + y) & 1)) buf[y * ICON + x] = pack(74, 168, 220);
  }
  return buf;
}

function blit(canvas: HTMLCanvasElement | null, buf: Uint32Array) {
  const ctx = canvas?.getContext('2d');
  if (!ctx) return;
  ctx.putImageData(new ImageData(new Uint8ClampedArray(buf.buffer as ArrayBuffer), ICON, ICON), 0, 0);
}

// posisi & ukuran tiap jenis di dalam ikon 24×24: [x, y, unit]
const ICON_POSE: Record<string, [number, number, number]> = {
  koki: [14, 12, 6.2],
  cupang: [12, 12, 5.6],
  badut: [14, 12, 6.4],
  dori: [13, 12, 6.2],
  diskus: [14, 10, 6.4],
};

/** Ikon ikan mungil yang dirender langsung dari sprite aslinya */
function FishIcon({ vi }: { vi: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const buf = iconBuffer();
    const [x, y, unit] = ICON_POSE[VARIETIES[vi].kind ?? 'koki'];
    drawFish(buf, ICON, ICON, {
      x,
      y,
      unit,
      facing: 1,
      pitch: 0,
      wave: 1.2,
      swim: 0.5,
      seed: 11,
      variety: VARIETIES[vi],
      eye: 'open',
      mouthOpen: false,
      tint: [0, 0, 0],
      tintAmt: 0,
    });
    blit(ref.current, buf);
  }, [vi]);
  return <canvas ref={ref} width={ICON} height={ICON} className="pixelated" aria-hidden="true" />;
}

/** Ikon kura-kura lumut (besar / kecil) */
function TurtleIcon({ baby }: { baby: boolean }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const buf = iconBuffer();
    const t = new Turtle(baby ? 14 : 15, baby ? 15 : 16, baby ? 4 : 5.6, '', baby, baby ? 31 : 77);
    t.settle();
    drawTurtle(buf, ICON, ICON, t, 0, [0, 0, 0], 0);
    blit(ref.current, buf);
  }, [baby]);
  return <canvas ref={ref} width={ICON} height={ICON} className="pixelated" aria-hidden="true" />;
}

// ---------- isi slot: 3 kelompok, masing-masing paling banyak 7 slot ----------
interface SlotDef {
  key: string;
  label: string; // teks pendek di layar kecil bawah slot
  full: string;
  vi?: number;
  baby?: boolean;
}

const SHORT: Record<string, string> = {
  'cupang-mustard': 'Mustard',
  'cupang-dumbo': 'Dumbo',
  'cupang-platinum': 'Platina',
  'cupang-lavender': 'Lavender',
  'cupang-koi': 'Koi',
  'cupang-bluerim': 'Blue Rim',
  badut: 'Nemo',
  dori: 'Dory',
  diskus: 'Diskus',
};

const SLOT_COUNT = 7;
const CATS = ['Demekin', 'Cupang', 'Laut & kura'];
const SLOTS: SlotDef[][] = [[], [], []];
VARIETIES.forEach((v, i) => {
  SLOTS[v.kind === undefined ? 0 : v.kind === 'cupang' ? 1 : 2].push({ key: v.id, label: SHORT[v.id] ?? v.name, full: v.name, vi: i });
});
SLOTS[2].push({ key: 'kura-besar', label: 'Kura', full: 'Kura-kura lumut besar', baby: false }, { key: 'kura-kecil', label: 'Bayi', full: 'Kura-kura lumut kecil', baby: true });

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tankRef = useRef<HTMLDivElement>(null);
  const tagRef = useRef<HTMLDivElement>(null);
  const tagNameRef = useRef<HTMLSpanElement>(null);
  const tagKindRef = useRef<HTMLSpanElement>(null);
  const menuBtnRef = useRef<HTMLButtonElement>(null);
  const menuFirstRef = useRef<HTMLButtonElement>(null);
  const engineRef = useRef<Aquarium | null>(null);
  const scaleRef = useRef(4);
  const tankWRef = useRef(0);
  const pausedRef = useRef(false);

  const [count, setCount] = useState(0);
  const [turtles, setTurtles] = useState(0);
  const [theme, setTheme] = useState(0);
  const [paused, setPaused] = useState(false);
  const [hint, setHint] = useState(true);
  const [cat, setCat] = useState(0);
  const [menu, setMenu] = useState(false);

  const sync = useCallback(() => {
    const aq = engineRef.current;
    if (!aq) return;
    setCount(aq.fish.length);
    setTurtles(aq.turtles.length);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const tank = tankRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !tank || !ctx) return;
    const aq = new Aquarium();
    engineRef.current = aq;
    let img: ImageData | null = null;

    // kanvas mengisi area tank (di bawah bar), dengan piksel yang diperbesar bulat
    const fit = () => {
      const vw = tank.clientWidth || window.innerWidth;
      const vh = tank.clientHeight || Math.max(120, window.innerHeight - 120);
      const scale = Math.max(2, Math.min(8, Math.round(Math.min(vw, vh) / 210)));
      const W = Math.ceil(vw / scale);
      const H = Math.ceil(vh / scale);
      if (W === canvas.width && H === canvas.height && scale === scaleRef.current && img) return;
      scaleRef.current = scale;
      tankWRef.current = vw;
      canvas.width = W;
      canvas.height = H;
      canvas.style.width = `${W * scale}px`;
      canvas.style.height = `${H * scale}px`;
      aq.resize(W, H);
      img = new ImageData(new Uint8ClampedArray(aq.buf.buffer as ArrayBuffer), W, H);
      sync();
    };
    fit();

    let resizeT = 0;
    const ro = new ResizeObserver(() => {
      window.clearTimeout(resizeT);
      resizeT = window.setTimeout(fit, 120);
    });
    ro.observe(tank);

    let raf = 0;
    let last = performance.now();
    let tagKey = '';
    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (img) {
        if (!pausedRef.current) aq.step(dt);
        aq.render();
        ctx.putImageData(img, 0, 0);

        const tag = tagRef.current;
        if (tag) {
          const lb = aq.label();
          if (lb) {
            const s = scaleRef.current;
            const x = Math.max(70, Math.min(tankWRef.current - 70, lb.x * s));
            const y = Math.max(82, lb.y * s); // tetap di bawah tab yang menggantung
            tag.style.opacity = '1';
            tag.style.transform = `translate(${Math.round(x)}px, ${Math.round(y)}px) translate(-50%, -100%)`;
            const key = `${lb.name}|${lb.variety}`;
            if (key !== tagKey) {
              tagKey = key;
              if (tagNameRef.current) tagNameRef.current.textContent = lb.name;
              if (tagKindRef.current) tagKindRef.current.textContent = lb.variety;
            }
          } else tag.style.opacity = '0';
        }
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(resizeT);
      ro.disconnect();
    };
  }, [sync]);

  // dialog menu: fokus masuk saat dibuka, Escape menutup, fokus kembali ke tombol MENU
  useEffect(() => {
    if (!menu) return;
    menuFirstRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenu(false);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      menuBtnRef.current?.focus();
    };
  }, [menu]);

  const onTap = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const aq = engineRef.current;
    if (!aq) return;
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - r.left) / scaleRef.current;
    const y = (e.clientY - r.top) / scaleRef.current;
    aq.pointer(x, y);
    aq.tap(x, y);
    setHint(false);
  }, []);

  // cupang penasaran mengikuti kursor / jari
  const onMove = useCallback((e: React.PointerEvent<HTMLCanvasElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    engineRef.current?.pointer((e.clientX - r.left) / scaleRef.current, (e.clientY - r.top) / scaleRef.current);
  }, []);

  const add = (slot: SlotDef) => {
    const aq = engineRef.current;
    if (!aq) return;
    if (slot.vi !== undefined ? aq.addFish(slot.vi) : aq.addTurtle(slot.baby === true)) sync();
  };
  const removeLast = () => {
    if (engineRef.current?.removeFish()) sync();
  };
  const feed = () => {
    engineRef.current?.feed();
    setHint(false);
  };
  const nextTheme = () => {
    const n = (theme + 1) % THEMES.length;
    engineRef.current?.setTheme(n);
    setTheme(n);
  };
  const togglePause = () => {
    pausedRef.current = !pausedRef.current;
    setPaused(pausedRef.current);
  };

  const th = THEMES[theme];
  const fishFull = count >= MAX_FISH;
  const turtleFull = turtles >= MAX_TURTLES;
  const slots = SLOTS[cat];

  return (
    <main className="fixed inset-0 flex flex-col overflow-hidden bg-[#3b4592] font-pixel text-ink select-none">
      <h1 className="sr-only">Akuarium piksel: demekin, cupang, ikan badut, blue tang, diskus, dan kura-kura lumut</h1>

      {/* ============ bar atas ala Insaniquarium ============ */}
      <header className="iq-bar">
        <div className="iq-bar-inner">
          {/* tab jenis hewan, menggantung di bawah bar */}
          <div role="tablist" aria-label="Jenis hewan di slot" className="iq-tabs">
            {CATS.map((label, i) => (
              <button key={label} type="button" role="tab" aria-selected={cat === i} aria-controls="slot-panel" onClick={() => setCat(i)} className="iq-tab">
                {label}
              </button>
            ))}
          </div>

          <div id="slot-panel" role="tabpanel" aria-label={`Tambah ${CATS[cat]}`} className="iq-slots">
            {Array.from({ length: SLOT_COUNT }, (_, i) => {
              const slot = slots[i];
              if (!slot) {
                return (
                  <span key={`kosong-${i}`} className="iq-slot iq-slot-empty" aria-hidden="true">
                    <span className="iq-slot-edge">
                      <span className="iq-slot-ring">
                        <span className="iq-glass iq-glass-empty" />
                      </span>
                    </span>
                    <span className="iq-tag" />
                  </span>
                );
              }
              const full = slot.vi !== undefined ? fishFull : turtleFull;
              return (
                <button key={slot.key} type="button" className="iq-slot" data-full={full} disabled={full} onClick={() => add(slot)} title={slot.full} aria-label={`Tambah ${slot.full}`}>
                  <span className="iq-slot-edge">
                    <span className="iq-slot-ring">
                      <span className="iq-glass">{slot.vi !== undefined ? <FishIcon vi={slot.vi} /> : <TurtleIcon baby={slot.baby === true} />}</span>
                    </span>
                  </span>
                  <span className="iq-tag">{full ? 'Penuh' : slot.label}</span>
                </button>
              );
            })}
          </div>

          <div className="iq-side">
            <p className="iq-led" aria-live="polite">
              IKAN {count}/{MAX_FISH} · KURA {turtles}/{MAX_TURTLES}
            </p>
            <button type="button" className="iq-plaque" onClick={feed} aria-label="Pakan: tabur pelet ke seluruh akuarium">
              Pakan
            </button>
            <button ref={menuBtnRef} type="button" className="iq-plaque" onClick={() => setMenu(true)} aria-haspopup="dialog" aria-expanded={menu}>
              Menu
            </button>
          </div>

        </div>
      </header>

      {/* ============ tank ============ */}
      <div ref={tankRef} className="relative min-h-0 flex-1 overflow-hidden">
        <canvas
          ref={canvasRef}
          onPointerDown={onTap}
          onPointerMove={onMove}
          role="img"
          aria-label="Akuarium piksel berisi ikan mas koki demekin, ikan cupang, ikan badut, blue tang, diskus, dan kura-kura berambut alga. Ketuk air untuk memberi pelet, ketuk hewan untuk mengelus."
          className="pixelated absolute left-0 top-0 block cursor-pointer touch-none"
        />

        {/* label nama hewan */}
        <div ref={tagRef} className="iq-note pointer-events-none absolute left-0 top-0 px-2 py-1 text-center opacity-0 transition-opacity duration-200" aria-hidden="true">
          <span ref={tagNameRef} className="block text-base font-bold leading-none" />
          <span ref={tagKindRef} className="mt-0.5 block text-xs leading-none text-[#a8482a]" />
        </div>

        {hint && (
          <p className="hint-float iq-note pointer-events-none absolute bottom-10 left-1/2 w-max max-w-[92%] px-3 py-1.5 text-center text-sm sm:text-base">
            Ketuk air untuk kasih pelet · ketuk hewan untuk mengelus <span className="text-coral">♥</span>
          </p>
        )}

        <p className="iq-tanklabel pointer-events-none absolute bottom-2 left-2.5 m-0">
          Tank {theme + 1}-{THEMES.length} {th.name}
          {paused ? ' (JEDA)' : ''}
        </p>
      </div>

      {/* ============ dialog menu ============ */}
      {menu && (
        <div
          className="iq-veil"
          onPointerDown={(e) => {
            if (e.target === e.currentTarget) setMenu(false);
          }}
        >
          <div role="dialog" aria-modal="true" aria-labelledby="menu-title" className="iq-dialog">
            <h2 id="menu-title" className="iq-dialog-title">
              MENU
            </h2>
            <div className="flex flex-col gap-2.5">
              <button ref={menuFirstRef} type="button" className="iq-plaque" onClick={() => setMenu(false)}>
                Kembali ke tank
              </button>
              <button type="button" className="iq-plaque" onClick={nextTheme} aria-label={`Ganti suasana. Sekarang: ${th.name}`}>
                Suasana: {th.name}
              </button>
              <button type="button" className="iq-plaque" onClick={togglePause} aria-pressed={paused}>
                {paused ? 'Lanjutkan' : 'Jeda'}
              </button>
              <button type="button" className="iq-plaque" onClick={removeLast} disabled={count + turtles === 0}>
                Lepas hewan terakhir
              </button>
            </div>
            <p className="mb-0 mt-3.5 text-sm font-semibold leading-snug">
              Ketuk slot di bar atas untuk menambah hewan. Ketuk air untuk menjatuhkan pelet, ketuk ikan atau kura-kura untuk mengelus. Cupang suka mengikuti kursormu.
            </p>
          </div>
        </div>
      )}
    </main>
  );
}

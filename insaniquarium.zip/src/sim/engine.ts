// Mesin simulasi akuarium: state, update, dan render ke buffer piksel.

import { BAYER, RGB, blend, clamp, hex, pack, packRGB } from './palette';
import { EyeState, VARIETIES, drawFish, mouthOffset } from './fish';
import { Plant, Scene, THEMES, buildScene, drawPlant, makePlants } from './scene';
import { Turtle, TurtleEnv, drawTurtle } from './turtle';

export const MAX_FISH = 24;
export const MAX_TURTLES = 6;
// per jenis: [ukuran minimum, variasi ukuran, ukuran maksimum saat tumbuh, laju jelajah minimum, variasi laju]
const SPEC: Record<string, [number, number, number, number, number]> = {
  koki: [6.3, 2.7, 11.4, 7, 6],
  cupang: [3.96, 1, 5.6, 11, 4],
  badut: [5.4, 1, 7.4, 10, 4],
  dori: [8.4, 1.4, 11, 11, 4],
  diskus: [9.5, 1.5, 12.5, 4.5, 2.5],
};
const T_BIG = ['Lumut', 'Ganggang', 'Pakis', 'Rimba', 'Semak', 'Beringin'];
const T_SMALL = ['Cilik', 'Tunas', 'Pucuk', 'Benih', 'Kecambah', 'Biji'];

const NAMES = [
  'Mochi', 'Boba', 'Klepon', 'Cendol', 'Onde', 'Dango', 'Bakpao', 'Cilok', 'Nastar', 'Lapis',
  'Bolu', 'Serabi', 'Putu', 'Momo', 'Cimol', 'Puding', 'Lemper', 'Getuk', 'Dodol', 'Pukis',
  'Wajik', 'Lupis', 'Apem', 'Cucur', 'Bika', 'Combro', 'Kolak', 'Rujak', 'Cenil', 'Gemblong',
];

export interface Fish {
  id: number;
  name: string;
  vi: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  tx: number;
  ty: number;
  unit: number;
  dir: number;
  facing: number;
  pitch: number;
  phase: number;
  wave: number;
  swim: number;
  seed: number;
  cruise: number;
  wanderT: number;
  idle: boolean;
  blinkT: number;
  happy: number;
  mouth: number;
  cup: boolean; // ikan cupang
  maxU: number; // ukuran maksimum saat tumbuh
  mo: number; // jarak mulut dari pusat (unit)
  // dinamika surai & gaya renang cupang
  fs: number; // sapuan sirip ke belakang (pegas)
  fsv: number;
  fl: number; // seretan sirip naik/turun (pegas)
  flv: number;
  flare: number; // 0..1 sirip mekar
  dash: number; // sisa waktu melesat
  pose: number; // sisa waktu pose anggun
}

interface Food {
  x: number;
  y: number;
  vy: number;
  ph: number;
  rest: boolean;
  life: number;
}
interface Bubble {
  x: number;
  y: number;
  r: number;
  vy: number;
  ph: number;
}
interface Heart {
  x: number;
  y: number;
  life: number;
  ph: number;
  big: boolean;
}
interface Dust {
  x: number;
  y: number;
  vx: number;
  vy: number;
  ph: number;
}

const HEART_L = ['.a.a.', 'abaaa', 'aaaaa', '.aaa.', '..a..'];
const HEART_S = ['a.a', 'aaa', '.a.'];
const BUB_L = ['.###.', '#w..#', '#...#', '#...#', '.###.'];
const HEART_A = hex('#ff6a94');
const HEART_B = hex('#ffd0dc');
const FOOD_C = [hex('#ffc460'), hex('#f08c40'), hex('#b8582c')];
const BUB_C = hex('#ecfcff');

export class Aquarium {
  W = 1;
  H = 1;
  buf = new Uint32Array(1);
  fish: Fish[] = [];
  turtles: Turtle[] = [];
  private selT: Turtle | null = null;
  themeIdx = 0;
  time = 0;
  selected: Fish | null = null;
  selectedUntil = 0;

  private scene!: Scene;
  private plants: Plant[] = [];
  private food: Food[] = [];
  private bubbles: Bubble[] = [];
  private hearts: Heart[] = [];
  private dust: Dust[] = [];
  private rayTab = new Float32Array(1);
  private emitT = 0;
  private nextId = 1;
  private ready = false;
  private ptr: { x: number; y: number; t: number } | null = null;

  resize(W: number, H: number) {
    const ow = this.W;
    const oh = this.H;
    this.W = W;
    this.H = H;
    this.buf = new Uint32Array(W * H);
    this.rayTab = new Float32Array(2 * W + H + 2);
    this.rebuild();
    this.dust = [];
    const nd = Math.round((W * H) / 1400);
    for (let i = 0; i < nd; i++) {
      this.dust.push({
        x: Math.random() * W,
        y: 6 + Math.random() * (this.scene.sandBase - 8),
        vx: (Math.random() - 0.5) * 1.6,
        vy: (Math.random() - 0.6) * 1.2,
        ph: Math.random() * 6.28,
      });
    }
    this.food = [];
    this.bubbles = [];
    if (!this.ready) {
      this.ready = true;
      this.populate();
      this.spawnTurtles();
    } else {
      for (const f of this.fish) {
        f.x = (f.x / ow) * W;
        f.y = (f.y / oh) * H;
        f.wanderT = 0;
      }
      for (const tt of this.turtles) {
        tt.x = (tt.x / ow) * W;
        tt.y = (tt.y / oh) * H;
        tt.wanderT = 0;
      }
    }
  }

  /** Kura-kura lumut + bayinya yang menumpang di punggung */
  private spawnTurtles() {
    const small = Math.min(this.W, this.H) < 190;
    const U = small ? 12 : 14;
    const big = new Turtle(this.W * 0.62, this.scene.sandBase * 0.62, U, 'Lumut', false, 77);
    const baby = new Turtle(big.x, big.y - U, small ? 7 : 8, 'Cilik', true, 31);
    baby.parent = big;
    baby.mode = 'ride';
    big.id = -2; // hewan awal dilepas paling akhir
    baby.id = -1;
    this.turtles = [big, baby];
  }

  private rebuild() {
    const th = THEMES[this.themeIdx];
    this.scene = buildScene(this.W, this.H, th);
    this.plants = makePlants(this.W, this.H, th, this.scene);
  }

  setTheme(i: number) {
    this.themeIdx = i % THEMES.length;
    this.rebuild();
  }

  private populate() {
    const small = Math.min(this.W, this.H) < 190;
    const k = small ? 0.86 : 1;
    const starters: [number, number][] = [
      [0, 10.2],
      [1, 7.8],
      [2, 8.1],
      [3, 7.2],
      [4, 7.8],
      [6, 6.6],
    ];
    // dua cupang halfmoon: Mustard (biru-kuning) & Dumbo (biru tua berkuping putih)
    const cupang: [string, string, number, number, number, number][] = [
      ['cupang-mustard', 'Samudra', 4.95, 0.22, 0.3, 1],
      ['cupang-dumbo', 'Safir', 4.8, 0.8, 0.66, -1],
      ['cupang-platinum', 'Mutiara', 5.05, 0.4, 0.2, 1],
      ['cupang-lavender', 'Anggrek', 4.95, 0.64, 0.42, -1],
      ['cupang-koi', 'Pelangi', 4.85, 0.3, 0.6, 1],
      ['cupang-bluerim', 'Awan', 4.85, 0.9, 0.32, -1],
      // ikan laut & diskus
      ['badut', 'Nemo', 6.2, 0.5, 0.72, 1],
      ['dori', 'Dory', 9.2, 0.16, 0.5, 1],
      ['diskus', 'Batik', 10.5, 0.74, 0.2, -1],
    ];
    for (const [id, name, size, fx, fy, dir] of cupang) {
      const vi = VARIETIES.findIndex((v) => v.id === id);
      if (vi < 0 || !this.addFish(vi, size * k, true)) continue;
      const f = this.fish.find((o) => o.vi === vi);
      if (!f) continue;
      const b = this.bounds(f.unit, true);
      f.x = f.tx = clamp(this.W * fx, b.x0, b.x1);
      f.y = f.ty = this.scene.sandBase * fy;
      f.dir = f.facing = dir;
      f.name = name;
    }
    const n = this.W * this.H < 62000 ? 4 : starters.length;
    for (let i = 0; i < n; i++) this.addFish(starters[i][0], starters[i][1] * k, true);
    // ikan utama (seperti di foto) mulai di tengah
    const hero = this.fish.find((f) => f.vi === 0);
    if (hero) {
      hero.x = this.W * 0.5;
      hero.y = this.scene.sandBase * 0.46;
      hero.dir = hero.facing = 1;
      hero.seed = 11;
      hero.name = 'Mochi';
    }
  }

  private bounds(u: number, cup = false) {
    const x0 = Math.min((cup ? 1.9 : 1.5) * u, this.W / 2);
    const y0 = 9 + 1.6 * u;
    return { x0, x1: this.W - x0, y0, y1: Math.max(y0 + 2, this.scene.sandBase - (cup ? 1.45 : 1.25) * u) };
  }

  addFish(vi: number, unit?: number, inside = false): boolean {
    if (this.fish.length >= MAX_FISH) return false;
    const kind = VARIETIES[vi].kind;
    const cup = kind === 'cupang';
    const [uMin, uVar, maxU, cMin, cVar] = SPEC[kind ?? 'koki'];
    const u = unit ?? uMin + Math.random() * uVar;
    const b = this.bounds(u, cup);
    const used = new Set(this.fish.map((f) => f.name));
    const free = NAMES.filter((n) => !used.has(n));
    const name = free[(Math.random() * free.length) | 0] ?? 'Mochi';
    const dir = Math.random() < 0.5 ? -1 : 1;
    const x = b.x0 + Math.random() * (b.x1 - b.x0);
    const y = inside ? b.y0 + Math.random() * (b.y1 - b.y0) : -u * 1.6;
    const f: Fish = {
      id: this.nextId++,
      name,
      vi,
      x,
      y,
      vx: 0,
      vy: inside ? 0 : 22,
      tx: x,
      ty: inside ? y : b.y0 + Math.random() * (b.y1 - b.y0) * 0.6,
      unit: u,
      dir,
      facing: dir,
      pitch: 0,
      phase: Math.random() * 6.28,
      wave: Math.random() * 6.28,
      swim: 0.5,
      seed: (Math.random() * 9999) | 0,
      cruise: cMin + Math.random() * cVar,
      wanderT: inside ? Math.random() * 3 : 2.5,
      idle: false,
      blinkT: 1 + Math.random() * 4,
      happy: inside ? 0 : 1.2,
      mouth: 0,
      cup,
      maxU: Math.max(maxU, u),
      mo: mouthOffset(VARIETIES[vi]),
      fs: 0,
      fsv: 0,
      fl: 0,
      flv: 0,
      flare: 0,
      dash: 0,
      pose: 0,
    };
    this.fish.push(f);
    this.fish.sort((a, c) => a.unit - c.unit);
    if (!inside) {
      for (let i = 0; i < 7; i++) this.bubble(x + (Math.random() - 0.5) * u * 2, 6 + Math.random() * 10, (Math.random() * 3) | 0);
      this.selected = f;
      this.selT = null;
      this.selectedUntil = this.time + 3.5;
    }
    return true;
  }

  removeFish(): boolean {
    let bf = -1;
    for (let i = 0; i < this.fish.length; i++) if (bf < 0 || this.fish[i].id > this.fish[bf].id) bf = i;
    let bt = -1;
    for (let i = 0; i < this.turtles.length; i++) if (bt < 0 || this.turtles[i].id > this.turtles[bt].id) bt = i;
    if (bf < 0 && bt < 0) return false;
    if (bt >= 0 && (bf < 0 || this.turtles[bt].id > this.fish[bf].id)) {
      const [tt] = this.turtles.splice(bt, 1);
      for (const o of this.turtles) {
        if (o.parent === tt) {
          o.parent = null; // penumpangnya jadi berenang bebas
          o.mode = 'free';
        }
      }
      if (this.selT === tt) this.selT = null;
      for (let i = 0; i < 6; i++) this.bubble(tt.x + (Math.random() - 0.5) * tt.unit * 2, tt.y - Math.random() * tt.unit, (Math.random() * 3) | 0);
      return true;
    }
    const [f] = this.fish.splice(bf, 1);
    if (this.selected === f) this.selected = null;
    for (let i = 0; i < 6; i++) this.bubble(f.x + (Math.random() - 0.5) * f.unit, f.y + (Math.random() - 0.5) * f.unit, (Math.random() * 3) | 0);
    return true;
  }

  /** Tambah kura-kura lumut besar atau kecil. Yang kecil mencari punggung kura besar yang masih kosong. */
  addTurtle(baby: boolean): boolean {
    if (this.turtles.length >= MAX_TURTLES) return false;
    const used = new Set(this.turtles.map((o) => o.name));
    const pool = (baby ? T_SMALL : T_BIG).filter((n) => !used.has(n));
    const name = pool[(Math.random() * pool.length) | 0] ?? (baby ? 'Cilik' : 'Lumut');
    const small = Math.min(this.W, this.H) < 190;
    const U = baby ? (small ? 6.4 : 7) + Math.random() * 1.6 : (small ? 11 : 12.5) + Math.random() * 2.5;
    const x = U * 2 + Math.random() * Math.max(1, this.W - U * 4);
    const tt = new Turtle(x, -U * 1.5, U, name, baby, (Math.random() * 9999) | 0);
    tt.id = this.nextId++;
    tt.vy = 18;
    tt.dir = tt.facing = Math.random() < 0.5 ? -1 : 1;
    tt.happy = 1.2;
    if (baby) {
      const host = this.turtles.find((b) => !b.baby && !this.turtles.some((o) => o.parent === b));
      if (host) tt.parent = host; // berenang menghampiri lalu naik ke punggungnya
    }
    this.turtles.push(tt);
    this.turtles.sort((a, b) => Number(a.baby) - Number(b.baby)); // induk diperbarui & digambar sebelum penumpangnya
    for (let i = 0; i < 7; i++) this.bubble(x + (Math.random() - 0.5) * U * 2, 6 + Math.random() * 10, (Math.random() * 3) | 0);
    this.selected = null;
    this.selT = tt;
    this.selectedUntil = this.time + 3.5;
    return true;
  }

  private bubble(x: number, y: number, r: number) {
    if (this.bubbles.length > 90) return;
    this.bubbles.push({ x, y, r, vy: 9 + r * 4 + Math.random() * 5, ph: Math.random() * 6.28 });
  }

  private dropFood(x: number, y: number) {
    if (this.food.length > 60) return;
    this.food.push({
      x: clamp(x, 2, this.W - 3),
      y,
      vy: 6.5 + Math.random() * 4,
      ph: Math.random() * 6.28,
      rest: false,
      life: 14,
    });
  }

  /** Posisi kursor/jari: cupang yang penasaran akan menghampirinya */
  pointer(x: number, y: number) {
    this.ptr = { x, y, t: this.time };
  }

  feed() {
    for (let i = 0; i < 9; i++) this.dropFood(8 + Math.random() * (this.W - 16), 5 + Math.random() * 6);
  }

  /** Ketuk: elus ikan kalau kena, kalau tidak jatuhkan makanan */
  tap(x: number, y: number): 'pet' | 'food' {
    for (let i = this.fish.length - 1; i >= 0; i--) {
      const f = this.fish[i];
      // area sentuh minimal 8 piksel supaya ikan mungil tetap mudah dielus
      const dx = (x - f.x) / Math.max(8, (f.cup ? 1.85 : 1.5) * f.unit);
      const dy = (y - f.y) / Math.max(8, (f.cup ? 1.5 : 1.3) * f.unit);
      if (dx * dx + dy * dy < 1) {
        f.happy = 1.7;
        if (f.cup) f.pose = Math.max(f.pose, 1.8); // memamerkan surainya saat dielus
        for (let k = 0; k < 3; k++) {
          this.hearts.push({
            x: f.x + (k - 1) * f.unit * 0.7,
            y: f.y - f.unit * (1.1 + Math.random() * 0.5),
            life: 1.1 + k * 0.15,
            ph: Math.random() * 6.28,
            big: k === 1,
          });
        }
        this.selected = f;
      this.selT = null;
        this.selectedUntil = this.time + 3.5;
        return 'pet';
      }
    }
    for (let i = this.turtles.length - 1; i >= 0; i--) {
      const tt = this.turtles[i];
      if (!tt.hit(x, y)) continue;
      tt.pet();
      for (let k = 0; k < 3; k++) {
        this.hearts.push({
          x: tt.x + (k - 1) * tt.unit * 0.8,
          y: tt.y - tt.unit * (1.6 + Math.random() * 0.5),
          life: 1.1 + k * 0.15,
          ph: Math.random() * 6.28,
          big: k === 1 && !tt.baby,
        });
      }
      this.selected = null;
      this.selT = tt;
      this.selectedUntil = this.time + 3.5;
      return 'pet';
    }
    for (let k = 0; k < 3; k++) this.dropFood(x + (k - 1) * 3 + Math.random(), Math.max(6, y) + Math.random() * 3);
    return 'food';
  }

  label() {
    const tt = this.selT;
    if (tt && this.time <= this.selectedUntil) {
      return { name: tt.name, variety: tt.baby ? 'Bayi kura-kura lumut' : 'Kura-kura lumut', x: tt.x, y: tt.y - tt.unit * 2.4 };
    }
    const f = this.selected;
    if (!f || this.time > this.selectedUntil) return null;
    return { name: f.name, variety: VARIETIES[f.vi].name, x: f.x, y: f.y - f.unit * 1.75 };
  }

  // ------------------------------------------------------------------ update
  step(dt: number) {
    this.time += dt;
    const t = this.time;
    const W = this.W;
    const sc = this.scene;

    // makanan
    for (let i = this.food.length - 1; i >= 0; i--) {
      const fd = this.food[i];
      if (!fd.rest) {
        fd.y += fd.vy * dt;
        fd.x = clamp(fd.x + Math.sin(t * 2 + fd.ph) * 4 * dt, 1, W - 3);
        const gy = sc.sandTop[clamp(Math.round(fd.x), 0, W - 1)] - 1;
        if (fd.y >= gy) {
          fd.y = gy;
          fd.rest = true;
        }
      } else {
        fd.life -= dt;
        if (fd.life <= 0) this.food.splice(i, 1);
      }
    }

    // ikan
    const reach = Math.max(W, this.H) * 0.8;
    for (const f of this.fish) {
      const u = f.unit;
      const b = this.bounds(u, f.cup);
      f.happy = Math.max(0, f.happy - dt);
      f.mouth = Math.max(0, f.mouth - dt);
      f.dash = Math.max(0, f.dash - dt);
      f.pose = Math.max(0, f.pose - dt);
      const prevDir = f.dir;
      f.blinkT -= dt;
      if (f.blinkT < -0.14) f.blinkT = 1.8 + Math.random() * 4.5;

      let best: Food | null = null;
      let bd = reach;
      for (const fd of this.food) {
        const d = Math.hypot(fd.x - f.x, fd.y - f.y);
        if (d < bd) {
          bd = d;
          best = fd;
        }
      }

      let tx = f.tx;
      let ty = f.ty;
      const chase = best !== null;
      let curious = false;
      if (best) {
        f.pose = 0;
        f.dash = 0;
        // hadap ke makanan; kalau sudah sejajar, kunci arah supaya tidak bolak-balik
        const dxf = best.x - f.x;
        if (Math.abs(dxf) > 0.8 * f.mo * u) f.dir = dxf > 0 ? 1 : -1;
        tx = best.x - f.dir * f.mo * u;
        ty = Math.min(best.y - 0.08 * u, b.y1);
        const fs = f.facing >= 0 ? 1 : -1;
        const mx = f.x + fs * f.mo * u * Math.abs(f.facing);
        const my = f.y + 0.08 * u;
        const md = Math.hypot(best.x - mx, best.y - my);
        if (md < (best.rest ? 1.3 * u : 0.5 * u + 2)) {
          this.food.splice(this.food.indexOf(best), 1);
          f.happy = Math.max(f.happy, 1.1);
          f.mouth = 0.6;
          f.unit = Math.min(f.maxU, f.unit + (f.cup ? 0.04 : 0.06));
          this.hearts.push({ x: f.x + fs * u * 0.6, y: f.y - u * 1.2, life: 1.1, ph: Math.random() * 6.28, big: Math.random() < 0.5 });
        }
      } else {
        f.wanderT -= dt;
        const ptr = this.ptr;
        if (f.cup && ptr && t - ptr.t < 2.4 && Math.hypot(ptr.x - f.x, ptr.y - f.y) < reach * 0.75) {
          // cupang penasaran: menghampiri kursor/jari lalu memamerkan siripnya
          curious = true;
          f.dash = 0;
          const dxp = ptr.x - f.x;
          if (Math.abs(dxp) > 0.9 * f.mo * u) f.dir = dxp > 0 ? 1 : -1;
          tx = clamp(ptr.x - f.dir * (f.mo + 0.7) * u, b.x0, b.x1);
          ty = clamp(ptr.y, b.y0, b.y1);
          if (Math.hypot(tx - f.x, ty - f.y) < 7) f.pose = Math.max(f.pose, 0.4);
        } else if (f.wanderT <= 0) {
          if (f.cup) {
            const r = Math.random();
            f.idle = false;
            f.dash = 0;
            f.pose = 0;
            if (r < 0.24) {
              // pose anggun: melayang pelan sambil memekarkan sirip
              f.pose = 2.6 + Math.random() * 2.4;
              f.wanderT = f.pose;
              f.tx = clamp(f.x + f.dir * (6 + Math.random() * 10), b.x0, b.x1);
              f.ty = clamp(f.y + (Math.random() - 0.5) * 12, b.y0, b.y1);
            } else {
              // melesat (kadang) atau menjelajah lincah
              if (r < 0.52) f.dash = 0.55 + Math.random() * 0.35;
              f.tx = b.x0 + Math.random() * (b.x1 - b.x0);
              f.ty = b.y0 + Math.random() * (b.y1 - b.y0);
              f.wanderT = f.dash > 0 ? f.dash + 0.5 + Math.random() * 0.8 : 1.3 + Math.random() * 2;
            }
          } else {
            f.idle = Math.random() < 0.22;
            if (f.idle) {
              f.tx = clamp(f.x + (Math.random() - 0.5) * 20, b.x0, b.x1);
              f.ty = clamp(f.y + (Math.random() - 0.5) * 14, b.y0, b.y1);
              f.wanderT = 1.5 + Math.random() * 2.5;
            } else {
              f.tx = b.x0 + Math.random() * (b.x1 - b.x0);
              f.ty = b.y0 + Math.random() * (b.y1 - b.y0);
              f.wanderT = 3 + Math.random() * 5;
            }
          }
          tx = f.tx;
          ty = f.ty;
        }
      }

      const ddx = tx - f.x;
      const ddy = ty - f.y;
      const dist = Math.hypot(ddx, ddy) || 0.001;
      if (!chase && !curious && f.pose <= 0 && dist < 4 && f.wanderT > 1.4) f.wanderT = 0.3 + Math.random() * 1.1;
      let sp: number;
      let acc: number;
      if (f.cup) {
        if (chase) {
          sp = 30 + f.cruise;
          acc = 5.5;
        } else if (curious) {
          sp = 26;
          acc = 4.5;
        } else if (f.pose > 0) {
          sp = 3;
          acc = 2.2;
        } else if (f.dash > 0) {
          sp = 40;
          acc = 6;
        } else {
          sp = f.cruise;
          acc = 2.6;
        }
      } else {
        sp = chase ? 24 + f.cruise : f.idle ? f.cruise * 0.35 : f.cruise;
        acc = chase ? 3.2 : 1.3;
      }
      sp *= clamp(dist / (chase ? 5 : f.cup ? 10 : 16), 0, 1);
      const k = Math.min(1, acc * dt);
      f.vx += ((ddx / dist) * sp - f.vx) * k;
      f.vy += ((ddy / dist) * sp * 0.85 - f.vy) * k;

      // jaga jarak antar ikan
      for (const o of this.fish) {
        if (o === f) continue;
        const dx = f.x - o.x;
        const dy = f.y - o.y;
        const d = Math.hypot(dx, dy);
        const min = (u + o.unit) * 1.15;
        if (d < min && d > 0.01) {
          const push = ((min - d) / min) * (chase ? 14 : 26) * dt;
          f.vx += (dx / d) * push;
          f.vy += (dy / d) * push;
        }
      }
      // batas akuarium (lembut)
      if (f.x < b.x0) f.vx += (b.x0 - f.x) * 5 * dt;
      if (f.x > b.x1) f.vx -= (f.x - b.x1) * 5 * dt;
      if (f.y < b.y0) f.vy += (b.y0 - f.y) * 5 * dt;
      if (f.y > b.y1) f.vy -= (f.y - b.y1) * 8 * dt;

      f.x += f.vx * dt;
      f.y += f.vy * dt;

      if (!chase && !curious && Math.abs(f.vx) > 2.2) f.dir = f.vx > 0 ? 1 : -1;
      const turn = f.cup ? 12 : 8;
      f.facing += clamp(f.dir - f.facing, -dt * turn, dt * turn);
      let pt = f.cup ? clamp(f.vy * 0.034, -0.44, 0.44) : clamp(f.vy * 0.022, -0.32, 0.32);
      if (f.cup && f.pose > 0 && !chase) pt = -0.1; // pose anggun: moncong sedikit terangkat
      if (best && best.rest && bd < 2.2 * u) pt = 0.34; // menungging saat makan di dasar
      f.pitch += (pt - f.pitch) * Math.min(1, dt * (f.cup ? 7 : 4));
      const speed = Math.hypot(f.vx, f.vy);
      f.swim += (clamp(speed / (f.cup ? 16 : 12), 0.3, 1.3) - f.swim) * Math.min(1, dt * 3);
      f.wave += dt * (f.cup ? 3.4 + speed * 0.13 : 3.2 + speed * 0.28);

      if (f.cup) {
        // surai = pegas teredam: tertinggal saat ikan melaju, lalu mengembang & berayun saat berhenti/berbalik
        if (f.dir !== prevDir) f.fsv -= 1.6;
        f.fsv += ((clamp(speed / 22, 0, 1.2) - f.fs) * 42 - f.fsv * 6) * dt;
        f.fs = clamp(f.fs + f.fsv * dt, -0.4, 1.4);
        f.flv += ((clamp(-f.vy / 13, -1, 1) - f.fl) * 42 - f.flv * 6) * dt;
        f.fl = clamp(f.fl + f.flv * dt, -1.3, 1.3);
        f.flare += ((f.pose > 0 || f.happy > 0 ? 1 : 0) - f.flare) * Math.min(1, dt * 3.5);
      }

      if (Math.random() < dt * 0.1) {
        const fs = f.facing >= 0 ? 1 : -1;
        this.bubble(f.x + fs * (f.mo + 0.05) * u, f.y, Math.random() < 0.7 ? 0 : 1);
      }
    }

    // kura-kura (induk dulu, baru bayinya yang menumpang)
    const env: TurtleEnv = {
      W,
      H: this.H,
      time: t,
      sandBase: sc.sandBase,
      food: this.food,
      eat: (fd) => {
        const i = this.food.indexOf(fd as Food);
        if (i >= 0) this.food.splice(i, 1);
      },
      heart: (x, y, big) => this.hearts.push({ x, y, life: 1.1, ph: Math.random() * 6.28, big }),
      bubble: (x, y, r) => this.bubble(x, y, r),
    };
    for (const tt of this.turtles) tt.update(dt, env);

    // gelembung
    this.emitT -= dt;
    if (this.emitT <= 0) {
      this.emitT = 0.25 + Math.random() * 0.9;
      const e = sc.emitters[(Math.random() * sc.emitters.length) | 0];
      this.bubble(e.x + (Math.random() - 0.5) * 3, e.y, (Math.random() * 3) | 0);
    }
    for (let i = this.bubbles.length - 1; i >= 0; i--) {
      const bb = this.bubbles[i];
      bb.y -= bb.vy * dt;
      bb.x += Math.sin(t * 3 + bb.ph) * 7 * dt;
      if (bb.y < 4) this.bubbles.splice(i, 1);
    }

    for (let i = this.hearts.length - 1; i >= 0; i--) {
      const h = this.hearts[i];
      h.y -= 10 * dt;
      h.x += Math.sin(t * 4 + h.ph) * 5 * dt;
      h.life -= dt;
      if (h.life <= 0) this.hearts.splice(i, 1);
    }

    const dy1 = sc.sandBase - 2;
    for (const d of this.dust) {
      d.x += (d.vx + Math.sin(t * 0.5 + d.ph) * 0.8) * dt;
      d.y += d.vy * dt;
      if (d.x < 0) d.x += W;
      else if (d.x >= W) d.x -= W;
      if (d.y < 6) d.y = dy1;
      else if (d.y > dy1) d.y = 6;
    }
  }

  // ------------------------------------------------------------------ render
  render() {
    const W = this.W;
    const H = this.H;
    const buf = this.buf;
    const t = this.time;
    const th = THEMES[this.themeIdx];
    const sc = this.scene;
    const bg = sc.bg;
    const ray: RGB = th.ray;

    // latar + berkas cahaya miring (dither)
    const tab = this.rayTab;
    const nt = 2 * W + H + 1;
    for (let i = 0; i < nt; i++) {
      const s = (i - H) * 0.5;
      tab[i] = (Math.sin(s * 0.045 + t * 0.22) * 0.6 + Math.sin(s * 0.11 - t * 0.15 + 1.3) * 0.4 - 0.3) * 1.7;
    }
    const rayH = H * 0.82;
    const amt = th.rayAmt;
    for (let y = 0; y < H; y++) {
      const row = y * W;
      const fade = 1 - y / rayH;
      if (fade <= 0) {
        buf.set(bg.subarray(row, row + W), row);
        continue;
      }
      const by = (y & 3) << 2;
      const base = H - y;
      for (let x = 0; x < W; x++) {
        const c = bg[row + x];
        const inten = tab[2 * x + base] * fade;
        const bth = BAYER[by | (x & 3)];
        if (inten > bth) {
          const a = inten > bth + 0.55 ? amt * 1.8 : amt;
          const r = c & 255;
          const g = (c >> 8) & 255;
          const b = (c >> 16) & 255;
          buf[row + x] = pack((r + (ray[0] - r) * a) | 0, (g + (ray[1] - g) * a) | 0, (b + (ray[2] - b) * a) | 0);
        } else buf[row + x] = c;
      }
    }

    // kaustik di pasir
    for (let x = 0; x < W; x++) {
      for (let y = sc.sandTop[x]; y < H; y++) {
        const c = Math.sin(x * 0.13 + t * 0.9 + Math.sin(y * 0.35 + t * 0.6) * 1.4) + Math.sin(x * 0.071 - t * 0.5 + y * 0.22);
        if (c > 1.25) blend(buf, y * W + x, ray[0], ray[1], ray[2], th.glow ? 0.14 : 0.24);
      }
    }

    const put = (x: number, y: number, c: number) => {
      if (x >= 0 && x < W && y >= 0 && y < H) buf[y * W + x] = c;
    };
    const mixPx = (x: number, y: number, c: RGB, a: number) => {
      if (x >= 0 && x < W && y >= 0 && y < H) blend(buf, y * W + x, c[0], c[1], c[2], a);
    };

    // plankton / debu berkilau
    for (const d of this.dust) {
      const x = d.x | 0;
      const y = d.y | 0;
      const s = Math.sin(t * 1.6 + d.ph);
      mixPx(x, y, ray, th.glow ? 0.4 + 0.35 * s : 0.2 + 0.16 * s);
      if (th.glow && s > 0.82) {
        mixPx(x - 1, y, ray, 0.3);
        mixPx(x + 1, y, ray, 0.3);
        mixPx(x, y - 1, ray, 0.3);
        mixPx(x, y + 1, ray, 0.3);
      }
    }

    for (const p of this.plants) if (!p.front) drawPlant(put, p, t);

    for (const tt of this.turtles) drawTurtle(buf, W, H, tt, t, th.tint, th.tintAmt);

    // ikan
    for (const f of this.fish) {
      const bob = Math.sin(t * 1.7 + f.phase) * 1.3;
      const hop = f.happy > 0 ? -Math.abs(Math.sin(f.happy * 9)) * 2.2 * Math.min(1, f.happy * 2) : 0;
      const waddle = Math.sin(f.wave * 0.5) * 0.035 * f.swim;
      const eye: EyeState = f.happy > 0 ? 'happy' : f.blinkT < 0 ? 'blink' : 'open';
      drawFish(buf, W, H, {
        x: Math.round(f.x),
        y: Math.round(f.y + bob + hop),
        unit: f.unit,
        facing: f.facing,
        pitch: Math.round((f.pitch + waddle) / 0.045) * 0.045,
        wave: f.wave,
        swim: f.swim,
        seed: f.seed,
        variety: VARIETIES[f.vi],
        eye,
        mouthOpen: f.mouth > 0 || Math.sin(t * 2.3 + f.phase) > 0.78,
        tint: th.tint,
        tintAmt: th.tintAmt,
        stream: f.fs,
        lift: f.fl,
        flare: f.flare,
      });
    }

    // makanan
    for (const fd of this.food) {
      const x = Math.round(fd.x);
      const y = Math.round(fd.y);
      const a = fd.life < 2 ? fd.life / 2 : 1;
      mixPx(x, y, FOOD_C[0], a);
      mixPx(x + 1, y, FOOD_C[1], a);
      mixPx(x, y + 1, FOOD_C[1], a);
      mixPx(x + 1, y + 1, FOOD_C[2], a);
    }

    for (const p of this.plants) if (p.front) drawPlant(put, p, t);

    // gelembung
    for (const bb of this.bubbles) {
      const x = Math.round(bb.x);
      const y = Math.round(bb.y);
      if (bb.r === 0) mixPx(x, y, BUB_C, 0.75);
      else if (bb.r === 1) {
        mixPx(x, y - 1, BUB_C, 0.8);
        mixPx(x - 1, y, BUB_C, 0.8);
        mixPx(x + 1, y, BUB_C, 0.55);
        mixPx(x, y + 1, BUB_C, 0.55);
        mixPx(x, y, BUB_C, 0.2);
      } else {
        for (let j = 0; j < 5; j++) {
          for (let i = 0; i < 5; i++) {
            const ch = BUB_L[j][i];
            if (ch === '#') mixPx(x + i - 2, y + j - 2, BUB_C, i + j < 5 ? 0.85 : 0.55);
            else mixPx(x + i - 2, y + j - 2, BUB_C, ch === 'w' ? 0.95 : j > 0 && j < 4 ? 0.14 : 0);
          }
        }
      }
    }

    // hati
    for (const h of this.hearts) {
      const tpl = h.big ? HEART_L : HEART_S;
      const a = Math.min(1, h.life * 3);
      const x0 = Math.round(h.x) - (tpl[0].length >> 1);
      const y0 = Math.round(h.y);
      for (let j = 0; j < tpl.length; j++) {
        for (let i = 0; i < tpl[j].length; i++) {
          const ch = tpl[j][i];
          if (ch !== '.') mixPx(x0 + i, y0 + j, ch === 'b' ? HEART_B : HEART_A, a);
        }
      }
    }

    // permukaan air bergelombang
    const sky = packRGB(th.sky);
    for (let x = 0; x < W; x++) {
      const sy = 3 + Math.sin(x * 0.09 + t * 1.4) * 1.1 + Math.sin(x * 0.23 - t * 1.9) * 0.6;
      const iy = sy | 0;
      for (let y = 0; y < iy; y++) buf[y * W + x] = sky;
      buf[iy * W + x] = th.glow ? sky : 0xffffffff;
      blend(buf, (iy + 1) * W + x, th.sky[0], th.sky[1], th.sky[2], 0.5);
      blend(buf, (iy + 2) * W + x, th.sky[0], th.sky[1], th.sky[2], 0.22);
    }
  }
}

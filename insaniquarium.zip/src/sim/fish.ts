// Renderer ikan mas koki (demekin/ryukin) prosedural bergaya pixel-art.
// Bentuk didefinisikan dalam koordinat lokal (u, v): ikan menghadap kanan (+u),
// v ke bawah, 1 unit ≈ setengah tinggi badan. Tiap piksel di-sample lalu
// diwarnai dengan ramp warna + ordered dithering supaya gradasinya khas piksel.

import { RGB, TAU, blend, clamp, dither, hash, hex, ramp, sstep, vnoise } from './palette';

export type Pattern = 'sarasa' | 'full' | 'calico' | 'patch' | 'cap';

export interface Variety {
  id: string;
  name: string;
  pattern: Pattern;
  base: RGB[]; // 5 tone terang→gelap (perut)
  patch: RGB[]; // 5 tone (corak)
  head: RGB[]; // 5 tone
  fin: RGB[]; // 4 tone: pangkal → tepi
  finShade: RGB;
  finLine: RGB;
  ring: RGB;
  pupil: RGB;
  blush: RGB;
  mouth: RGB;
  speck?: RGB;
  swatch: [string, string];
  // khusus ikan cupang
  kind?: 'cupang' | 'badut' | 'dori' | 'diskus';
  fin2?: RGB[]; // ramp aksen sirip (pangkal → tepi)
  ear?: RGB[]; // ramp sirip dada
  acc?: [number, number, number]; // kadar aksen: punggung, ekor, anal
  marble?: boolean; // kepala putih berbintik
  dumbo?: boolean; // sirip dada besar seperti kuping gajah
  fin3?: RGB[]; // jari-jari sirip warna ketiga (koi)
  rim?: RGB[]; // pita warna di tepi sirip (blue rim)
  alt?: RGB[]; // sisik warna ketiga di badan (koi)
  koi?: boolean; // badan bercak-bercak
  finLen?: number; // pengali panjang sirip (plakat < 1)
}

const WHITE_BODY = ['#ffffff', '#fff0e8', '#f9d3cf', '#dba9bb', '#a7859f'] as const;
const RED_PATCH = ['#ffa068', '#ff623f', '#ee3530', '#c41f3c', '#861641'] as const;

export const VARIETIES: Variety[] = [
  {
    id: 'sarasa',
    name: 'Sarasa',
    pattern: 'sarasa',
    base: ramp(...WHITE_BODY),
    patch: ramp(...RED_PATCH),
    head: ramp('#fffbe2', '#ffeab8', '#fbc894', '#e79c80', '#b3716f'),
    fin: ramp('#ffc4be', '#ffe2da', '#fff4ee', '#ffffff'),
    finShade: hex('#c7a6d6'),
    finLine: hex('#b582b4'),
    ring: hex('#fff3d6'),
    pupil: hex('#1d1230'),
    blush: hex('#ff8098'),
    mouth: hex('#c9485a'),
    swatch: ['#ff5d3d', '#fff0e8'],
  },
  {
    id: 'sakura',
    name: 'Sakura',
    pattern: 'patch',
    base: ramp('#ffffff', '#fff1f1', '#fbd5dc', '#e0aac6', '#aa86a8'),
    patch: ramp('#ffd3de', '#ffa5bf', '#f7789f', '#d2568c', '#963c7a'),
    head: ramp('#fff8f0', '#ffe3d8', '#f9c2c2', '#de97ad', '#a86c92'),
    fin: ramp('#ffbdd2', '#ffdae6', '#fff0f5', '#ffffff'),
    finShade: hex('#cfa2d4'),
    finLine: hex('#c07ab0'),
    ring: hex('#fff6ee'),
    pupil: hex('#2a1436'),
    blush: hex('#ff7aa2'),
    mouth: hex('#d0507c'),
    swatch: ['#ff8fb3', '#fff1f1'],
  },
  {
    id: 'emas',
    name: 'Emas',
    pattern: 'full',
    base: ramp('#fff8cc', '#ffe38e', '#ffc463', '#f09c4e', '#b8684a'),
    patch: ramp('#ffdc72', '#ffae40', '#ff8232', '#e3562f', '#a0343f'),
    head: ramp('#ffe890', '#ffc256', '#ff9642', '#e56b38', '#a34340'),
    fin: ramp('#ff9a52', '#ffc27c', '#ffe4b0', '#fff8e0'),
    finShade: hex('#e0806a'),
    finLine: hex('#c05a4a'),
    ring: hex('#fff6d0'),
    pupil: hex('#24122a'),
    blush: hex('#ff6a70'),
    mouth: hex('#b8403c'),
    swatch: ['#ffd76a', '#ff7a30'],
  },
  {
    id: 'calico',
    name: 'Calico',
    pattern: 'calico',
    base: ramp('#ffffff', '#e6f3ff', '#bfd6f7', '#96abde', '#6d7bb5'),
    patch: ramp('#ffc47c', '#ff9852', '#f2703e', '#c94c44', '#8c3350'),
    head: ramp('#fff9ea', '#ffe5c2', '#f7c29e', '#dc9792', '#a56c84'),
    fin: ramp('#c4d8ff', '#e0ebff', '#f4f9ff', '#ffffff'),
    finShade: hex('#8f9ed6'),
    finLine: hex('#7a82c0'),
    ring: hex('#f4fbff'),
    pupil: hex('#1a1634'),
    blush: hex('#ff8fa3'),
    mouth: hex('#b85a6a'),
    speck: hex('#2c2440'),
    swatch: ['#bfd6f7', '#ff9852'],
  },
  {
    id: 'kuro',
    name: 'Kuro',
    pattern: 'full',
    base: ramp('#c9a890', '#94788a', '#625072', '#3f3558', '#251e3c'),
    patch: ramp('#8884b8', '#5a5688', '#3c3862', '#282546', '#18162e'),
    head: ramp('#9690c2', '#646092', '#44406a', '#2c294c', '#1b1932'),
    fin: ramp('#36315c', '#4a4578', '#6964a0', '#a09cd6'),
    finShade: hex('#1f1c3a'),
    finLine: hex('#17142c'),
    ring: hex('#ffd76a'),
    pupil: hex('#0d0a18'),
    blush: hex('#ff7a9a'),
    mouth: hex('#c0789a'),
    swatch: ['#5a5688', '#c9a890'],
  },
  {
    id: 'tancho',
    name: 'Tancho',
    pattern: 'cap',
    base: ramp(...WHITE_BODY),
    patch: ramp(...RED_PATCH),
    head: ramp('#ffffff', '#fff3e8', '#f8d8ce', '#dcacb8', '#a8869c'),
    fin: ramp('#ffd2cc', '#ffe8e2', '#fff6f2', '#ffffff'),
    finShade: hex('#c7a6d6'),
    finLine: hex('#b582b4'),
    ring: hex('#fff3d6'),
    pupil: hex('#1d1230'),
    blush: hex('#ff8098'),
    mouth: hex('#c9485a'),
    swatch: ['#ffffff', '#ee3530'],
  },
  {
    id: 'lila',
    name: 'Lila',
    pattern: 'sarasa',
    base: ramp('#ffffff', '#f4efff', '#dbd1f8', '#b5a5e2', '#8676ba'),
    patch: ramp('#dcc0ff', '#b890ff', '#9069ee', '#6a4cc8', '#46348f'),
    head: ramp('#fff8fc', '#fbe2f3', '#e9c1e7', '#c49ad3', '#8f6fae'),
    fin: ramp('#d4bcff', '#e8daff', '#f6efff', '#ffffff'),
    finShade: hex('#9d8fdc'),
    finLine: hex('#8672c8'),
    ring: hex('#fff6ff'),
    pupil: hex('#1c1238'),
    blush: hex('#ff94c6'),
    mouth: hex('#a8589c'),
    swatch: ['#b890ff', '#f4efff'],
  },
  {
    id: 'cupang-mustard',
    name: 'Cupang Mustard',
    kind: 'cupang',
    pattern: 'full',
    base: ramp('#a6ecff', '#4fc3f7', '#1f8fe8', '#1c62c8', '#1b3f96'),
    patch: ramp('#a6ecff', '#4fc3f7', '#1f8fe8', '#1c62c8', '#1b3f96'),
    head: ramp('#ffffff', '#f6f1ea', '#e2dad8', '#b9b1c4', '#8c86a8'),
    fin: ramp('#173a9e', '#1c62d6', '#2a94ee', '#56c0f8', '#9ee2ff', '#e6faff'),
    fin2: ramp('#c07a22', '#e8a232', '#f8c044', '#ffd45c', '#ffe288', '#fff0b8'),
    ear: ramp('#6fc4f5', '#b4ecff', '#fff4c4'),
    acc: [0.44, 0.6, 0.56],
    marble: true,
    finShade: hex('#1d3690'),
    finLine: hex('#1f3c92'),
    ring: hex('#d8ecf6'),
    pupil: hex('#141a38'),
    blush: hex('#ff9cb0'),
    mouth: hex('#d08a96'),
    speck: hex('#3c4468'),
    swatch: ['#2a94ee', '#f6ba44'],
  },
  {
    id: 'cupang-dumbo',
    name: 'Cupang Dumbo',
    kind: 'cupang',
    pattern: 'full',
    base: ramp('#8696ff', '#4c5ae6', '#3038ba', '#22258e', '#181a62'),
    patch: ramp('#8696ff', '#4c5ae6', '#3038ba', '#22258e', '#181a62'),
    head: ramp('#6a78e8', '#3c46c2', '#2a2e9a', '#1e2076', '#141552'),
    fin: ramp('#1a1870', '#2826ae', '#3a40e2', '#6076fa', '#a0b2ff', '#eef2ff'),
    fin2: ramp('#8c1c5e', '#c8305e', '#f05a6e', '#ff9aa2', '#ffd0d2', '#fff4f4'),
    ear: ramp('#3a44c4', '#6a7cf0', '#a8b8ff', '#dfe8ff', '#ffffff'),
    acc: [0, 0.1, 0.42],
    dumbo: true,
    finShade: hex('#14144a'),
    finLine: hex('#181856'),
    ring: hex('#93a4f4'),
    pupil: hex('#0a0a20'),
    blush: hex('#f070a8'),
    mouth: hex('#a8baff'),
    swatch: ['#3a40e2', '#eef2ff'],
  },
  {
    id: 'cupang-platinum',
    name: 'Cupang Platinum',
    kind: 'cupang',
    pattern: 'full',
    base: ramp('#ffffff', '#f7f4ee', '#e6e3ea', '#c6c8de', '#a2a6ca'),
    patch: ramp('#ffffff', '#f7f4ee', '#e6e3ea', '#c6c8de', '#a2a6ca'),
    head: ramp('#fffdf6', '#fcf0e0', '#f0dccf', '#d2c2c9', '#aaa2be'),
    fin: ramp('#b4bbe0', '#d2d7ee', '#e7eaf8', '#f5f6ff', '#ffffff', '#ffffff'),
    ear: ramp('#c8ceea', '#e2e5f5', '#f5f6ff', '#ffffff', '#ffffff'),
    dumbo: true,
    finShade: hex('#8a93c4'),
    finLine: hex('#8a93c4'),
    ring: hex('#ffffff'),
    pupil: hex('#191a30'),
    blush: hex('#ffa2ba'),
    mouth: hex('#d99aa6'),
    swatch: ['#ffffff', '#d2d7ee'],
  },
  {
    id: 'cupang-lavender',
    name: 'Cupang Lavender',
    kind: 'cupang',
    pattern: 'full',
    base: ramp('#ffeaf4', '#ffc8e0', '#f9a2ca', '#d97eb6', '#a85e9e'),
    patch: ramp('#ffeaf4', '#ffc8e0', '#f9a2ca', '#d97eb6', '#a85e9e'),
    head: ramp('#fff2f7', '#ffd4e4', '#f9aecb', '#da88b6', '#a9629e'),
    fin: ramp('#f07cb2', '#f09ad0', '#dda6ee', '#c6a8fb', '#cfbfff', '#eee7ff'),
    fin2: ramp('#b8246a', '#dc3f84', '#f6649c', '#ff92b8', '#ffc0d6', '#ffe9f1'),
    ear: ramp('#f6a0cc', '#ffc8e0', '#fff0f6'),
    acc: [0, 0.08, 0.95],
    finShade: hex('#8858b8'),
    finLine: hex('#8858b8'),
    ring: hex('#ffe6f0'),
    pupil: hex('#22142e'),
    blush: hex('#ff5c94'),
    mouth: hex('#cf4c80'),
    swatch: ['#ffc8e0', '#c6a8fb'],
  },
  {
    id: 'cupang-koi',
    name: 'Cupang Koi Galaxy',
    kind: 'cupang',
    pattern: 'full',
    koi: true,
    finLen: 0.76,
    base: ramp('#ffe58a', '#ffbc42', '#ff8c22', '#ea601c', '#b23e24'),
    patch: ramp('#ff8468', '#f2442e', '#d2222c', '#a21a34', '#721330'),
    alt: ramp('#9ae0ff', '#48a8f2', '#2c70da', '#2448aa', '#1c2e7a'),
    head: ramp('#fff3c8', '#ffd884', '#ffae4a', '#f27e2e', '#ba542c'),
    fin: ramp('#74c4ec', '#a4e0fa', '#cef2ff', '#eafaff', '#ffffff', '#ffffff'),
    fin2: ramp('#b21a2a', '#e2322e', '#f95c3e', '#ff8c5e', '#ffba92', '#ffe2ca'),
    fin3: ramp('#1c2e7a', '#2448aa', '#2c70da', '#48a8f2', '#9ae0ff', '#d4f4ff'),
    ear: ramp('#e2322e', '#ff8c5e', '#ffffff'),
    acc: [0.55, 0.32, 0.5],
    finShade: hex('#3458a8'),
    finLine: hex('#3458a8'),
    ring: hex('#fff0d0'),
    pupil: hex('#16121e'),
    blush: hex('#ff6a70'),
    mouth: hex('#a83a24'),
    swatch: ['#ff8c22', '#48a8f2'],
  },
  {
    id: 'cupang-bluerim',
    name: 'Cupang Blue Rim',
    kind: 'cupang',
    pattern: 'full',
    finLen: 0.82,
    base: ramp('#ffffff', '#f2efff', '#ded8f7', '#bcb4e3', '#968ec5'),
    patch: ramp('#ffffff', '#f2efff', '#ded8f7', '#bcb4e3', '#968ec5'),
    head: ramp('#ffffff', '#f7f1fb', '#e8dcf1', '#c6b8dd', '#9e92c1'),
    fin: ramp('#d2cef0', '#e6e4f9', '#f3f2ff', '#ffffff', '#ffffff', '#ffffff'),
    fin2: ramp('#1a1a86', '#2226b4', '#3440e0', '#6a78ff', '#aab4ff', '#e8ecff'),
    rim: ramp('#6a78ff', '#3440e0', '#2226b4', '#1a1a86'),
    ear: ramp('#2226b4', '#3440e0', '#8a94ff'),
    finShade: hex('#8f8ac8'),
    finLine: hex('#8f8ac8'),
    ring: hex('#ffffff'),
    pupil: hex('#16162e'),
    blush: hex('#ffa0c0'),
    mouth: hex('#c890b0'),
    swatch: ['#ffffff', '#3440e0'],
  },
  {
    id: 'badut',
    name: 'Ikan Badut',
    kind: 'badut',
    pattern: 'full',
    base: ramp('#ffc24c', '#ff9c2c', '#fa7818', '#da5a14', '#a8401c'),
    patch: ramp('#ffffff', '#fbfbff', '#e6ecfa', '#c6d0ee', '#9ca8d4'),
    head: ramp('#ffc24c', '#ff9c2c', '#fa7818', '#da5a14', '#a8401c'),
    fin: ramp('#ff9c2c', '#fa7818', '#da5a14', '#a8401c'),
    finShade: hex('#a8401c'),
    finLine: hex('#2a1a2a'),
    ring: hex('#fff6ea'),
    pupil: hex('#1a1226'),
    blush: hex('#ff5a6a'),
    mouth: hex('#9a3418'),
    swatch: ['#ff8a22', '#ffffff'],
  },
  {
    id: 'dori',
    name: 'Blue Tang',
    kind: 'dori',
    pattern: 'full',
    base: ramp('#74bcff', '#4290f8', '#2c66ea', '#2548c8', '#1c309a'),
    patch: ramp('#fff68a', '#ffe04a', '#f8c22c', '#d89a20', '#a8701c'),
    head: ramp('#74bcff', '#4290f8', '#2c66ea', '#2548c8', '#1c309a'),
    fin: ramp('#4290f8', '#2c66ea', '#2548c8', '#1c309a'),
    finShade: hex('#1c309a'),
    finLine: hex('#141238'),
    ring: hex('#f6f2ff'),
    pupil: hex('#141230'),
    blush: hex('#ff8ab4'),
    mouth: hex('#141238'),
    swatch: ['#2c66ea', '#ffe04a'],
  },
  {
    id: 'diskus',
    name: 'Diskus Batik',
    kind: 'diskus',
    pattern: 'full',
    base: ramp('#ffffff', '#fff1ee', '#f6dede', '#dabed2', '#b296be'),
    patch: ramp('#ffa43c', '#ff7230', '#f1422c', '#ce2636', '#901e3a'),
    head: ramp('#ffffff', '#fff1ee', '#f6dede', '#dabed2', '#b296be'),
    fin: ramp('#4a1830', '#7c2438', '#c86a70', '#fff0ec'),
    finShade: hex('#5a2038'),
    finLine: hex('#5a2038'),
    ring: hex('#ee3a3a'),
    pupil: hex('#1c1024'),
    blush: hex('#ffa0a0'),
    mouth: hex('#a82c34'),
    swatch: ['#f1422c', '#fff1ee'],
  },
];

/** Jarak mulut dari pusat ikan (dalam unit) */
export const mouthOffset = (v: Variety) =>
  v.kind === 'cupang' ? 1.6 : v.kind === 'dori' ? 1.3 : v.kind === 'diskus' ? 1.0 : v.kind === 'badut' ? 1.16 : 1.15;

export type EyeState = 'open' | 'blink' | 'happy';

export interface FishPose {
  x: number; // pusat ikan di layar (bilangan bulat)
  y: number;
  unit: number; // piksel per unit lokal
  facing: number; // -1..1 (tanda = arah, besaran = fase berbalik)
  pitch: number; // + = moncong turun
  wave: number; // fase kibasan sirip
  swim: number; // 0..1.3 kekuatan kibasan
  seed: number;
  variety: Variety;
  eye: EyeState;
  mouthOpen: boolean;
  tint: RGB;
  tintAmt: number;
  // khusus cupang: dinamika surai
  stream?: number; // sirip tersapu ke belakang oleh laju renang (negatif = mengembang ke depan)
  lift?: number; // + = sedang naik → sirip terseret ke bawah
  flare?: number; // 0..1 sirip mekar penuh (pose anggun)
}

// ---------- buffer sprite sementara ----------
const SPR = 151;
const sR = new Uint8ClampedArray(SPR * SPR);
const sG = new Uint8ClampedArray(SPR * SPR);
const sB = new Uint8ClampedArray(SPR * SPR);
const sA = new Float32Array(SPR * SPR);
const sK = new Uint8Array(SPR * SPR); // 0 kosong, 1 sirip (tembus), 2 badan (solid)

// keluaran sample()
let oR = 0;
let oG = 0;
let oB = 0;
let oA = 0;
let oK = 0;

// parameter pose aktif
let qV: Variety = VARIETIES[0];
let qSeed = 0;
let qLx = 1;
let qWave = 0;
let qTail = 0.16;
let qDors = 0.05;
let qFlap = 0;
let qStream = 0;
let qLift = 0;
let qAmp = 0.1;
let qLen = 1;
let qFold = 0.1;
let qRip = 0.06;
let qBend = 0.05;
let qCrisp = false; // cupang mungil: warna rata & tegas (tanpa dither) supaya tidak tampak buram
const flat = (n: number, t: number) => Math.round((t < 0 ? 0 : t > 1 ? 1 : t) * (n - 1));
let qPx = 0.07;

const win = (x: number, lo: number, hi: number, s: number) => sstep(lo, lo + s, x) * (1 - sstep(hi - s, hi, x));
const gauss = (x: number, s: number) => Math.exp(-(x * x) / (s * s));

/** Ekor bercagak dua cuping lebar (0 = lurus ke belakang, + = ke bawah) */
function tailR(th: number): number {
  const w = win(th, -1.34, 1.3, 0.2);
  if (w <= 0) return 0;
  return (
    (0.56 + 0.44 * gauss(th + 0.9, 0.42) + 0.38 * gauss(th - 0.84, 0.42) - 0.07 * gauss(th - 0.12, 0.22) + 0.012 * Math.sin(th * 30)) *
    Math.sqrt(w)
  );
}

// Sirip punggung "layar": tabel (sudut, jarak dari pusat badan). 0 = ke atas, + = ke belakang.
// Tinggi di depan (di atas puncak punuk), lalu menurun mengikuti punggung sampai pangkal ekor.
const DT = [-0.85, 1.22, -0.42, 1.37, -0.24, 1.37, -0.02, 1.31, 0.2, 1.21, 0.55, 1.1, 1.0, 1.0, 1.25, 0.95];
function dorsalR(ph: number): number {
  if (ph < DT[0] || ph > 1.22) return 0;
  let r = DT[DT.length - 1];
  for (let k = 0; k < DT.length - 2; k += 2) {
    if (ph < DT[k + 2]) {
      const t = (ph - DT[k]) / (DT[k + 2] - DT[k]);
      r = DT[k + 1] + (DT[k + 3] - DT[k + 1]) * t;
      break;
    }
  }
  return (r + 0.012 * Math.sin(ph * 38)) * Math.sqrt(1 - sstep(1.02, 1.22, ph));
}

/** Bayangan bola semu: 0 = paling terang, 1 = paling gelap */
function shade(nx: number, ny: number): number {
  const d2 = nx * nx + ny * ny;
  const nz = Math.sqrt(Math.max(0, 1 - d2));
  const l = nx * (-0.42 * qLx) + ny * -0.62 + nz * 0.66;
  let t = 0.54 - 0.5 * l;
  if (d2 > 0.78) t += (d2 - 0.78) * 0.5;
  return t < 0 ? 0 : t > 1 ? 1 : t;
}

/** 0 = warna dasar, 1 = corak, 2 = bintik */
function mask(u: number, v: number): number {
  const seed = qSeed;
  const s = seed % 89;
  switch (qV.pattern) {
    case 'sarasa': {
      const k = (hash(1, 2, seed) - 0.5) * 0.16;
      const edge = -0.36 + k + 0.98 * sstep(-0.16, -0.52, u);
      const wob = (vnoise(u * 3.1 + s, v * 3.1, seed) - 0.5) * 0.26;
      if (v < edge + wob) return 1;
      let dx = u + 0.06;
      let dy = v - 0.36;
      if (dx * dx + dy * dy < 0.0075) return 1; // titik merah kecil di badan
      dx = (u - 0.55) / 0.08;
      dy = (v - 0.22) / 0.12;
      if (dx * dx + dy * dy < 1) return 1; // tanda merah di tutup insang
      return 0;
    }
    case 'full': {
      const wob = (vnoise(u * 2.6 + s, v * 2.6, seed) - 0.5) * 0.2;
      return v < 0.4 + wob - 0.25 * u ? 1 : 0;
    }
    case 'cap': {
      const dx = (u - 0.3) / 0.5;
      const dy = (v + 0.72) / 0.36;
      const wob = (vnoise(u * 4 + s, v * 4, seed) - 0.5) * 0.35;
      return dx * dx + dy * dy < 1 + wob ? 1 : 0;
    }
    case 'calico': {
      const cs = 0.17;
      const gx = Math.floor(u / cs);
      const gy = Math.floor(v / cs);
      if (hash(gx, gy, seed + 7) > 0.84) {
        const fx = u / cs - gx - 0.5;
        const fy = v / cs - gy - 0.5;
        if (fx * fx + fy * fy < 0.11) return 2;
      }
      return vnoise(u * 2.1 + s, v * 2.1 + 3, seed) > 0.55 ? 1 : 0;
    }
    case 'patch':
      return vnoise(u * 1.9 + s, v * 1.9 + 5, seed) + 0.1 * Math.max(0, -v) > 0.57 ? 1 : 0;
  }
}

function finOut(rn: number, ang: number, freq: number, rim: boolean, far: boolean, px: number, py: number) {
  const V = qV;
  const ray = Math.sin(ang * freq);
  const hi = ray > 0.45;
  const idx = dither(4, rn * 0.9 + (hi ? 0.14 : 0), px, py, 0.7);
  let c = V.fin[idx];
  let al = Math.min(1, 0.99 - 0.22 * rn + (hi ? 0.06 : 0));
  let m = 0;
  if (ray < -0.5 && rn > 0.22) m = 0.4;
  if (rim) {
    c = V.fin[3];
    al = 0.92;
    m = 0;
  }
  if (far) {
    m = m + (1 - m) * 0.4;
    al *= 0.94;
  }
  const sh = V.finShade;
  oR = c[0] + (sh[0] - c[0]) * m;
  oG = c[1] + (sh[1] - c[1]) * m;
  oB = c[2] + (sh[2] - c[2]) * m;
  oA = al;
  oK = 1;
}

function sample(u: number, v: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  if (u < -2.0 || u > 1.34 || v < -1.7 || v > 1.8) return;
  const V = qV;

  // --- sirip dada (di depan badan, mengepak; pangkalnya merona) ---
  let dx = u - 0.62;
  let dy = v - 0.4;
  let r2 = dx * dx + dy * dy;
  if (r2 < 0.2) {
    let a = Math.atan2(dy, dx) - (2.2 + qFlap);
    if (a < -Math.PI) a += TAU;
    const w = win(a, -0.6, 0.6, 0.3);
    if (w > 0) {
      const R = 0.44 * Math.sqrt(w);
      const r = Math.sqrt(r2);
      if (r < R) {
        const edge = R - r < qPx * 0.9;
        const c = edge ? V.finLine : V.fin[r < R * 0.5 ? 0 : Math.sin(a * 11) > 0.3 ? 3 : 2];
        oR = c[0];
        oG = c[1];
        oB = c[2];
        oA = 1;
        oK = 2;
        return;
      }
    }
  }

  // --- kepala: kerucut membulat kecil yang menyembul dari badan + bibir monyong ---
  const ht = u <= 0.85 ? 0 : u >= 1.03 ? 1 : (u - 0.85) / 0.18;
  const hr = 0.34 - 0.115 * ht;
  const hdx = u - (0.85 + 0.18 * ht);
  const hdy = v - (0.06 + 0.035 * ht);
  const hd2 = hdx * hdx + hdy * hdy;
  const lx = u - 1.2;
  const ly = v - 0.16;
  const inHead = hd2 < hr * hr || lx * lx + ly * ly < 0.0049;

  // --- badan: perut bola kembung + punuk tinggi (depan curam, belakang melandai) + pangkal ekor ---
  const ax = (u - 0.05) / 0.8;
  const ay = (v - 0.2) / 0.87;
  let inBody = ax * ax + ay * ay < 1;
  if (!inBody) {
    const by = (v + 0.3) / 0.7;
    const bu = u - 0.3;
    if (by > -1 && by < 1 && bu > -0.92 && bu < 0.54) {
      if (bu >= 0) inBody = Math.pow(bu / 0.54, 2.25) + Math.pow(by < 0 ? -by : by, 2.25) < 1;
      else {
        const bx = bu / 0.92;
        inBody = bx * bx + by * by < 1;
      }
    }
    if (!inBody) {
      const cx = (u + 0.7) / 0.2;
      const cy = (v + 0.16) / 0.2;
      inBody = cx * cx + cy * cy < 1;
    }
  }

  if (inHead) {
    let t = shade((u - 0.9) / 0.5, (v - 0.06) / 0.48) - 0.05;
    const gl = 0.34 - qPx * 1.1;
    if (inBody && ht === 0 && u < 0.8 && hd2 > gl * gl) t += 0.3; // garis tutup insang
    const m = V.pattern === 'full' ? 0 : mask(u, v);
    let c: RGB;
    if (m === 2 && V.speck) c = V.speck;
    else c = (m === 1 ? V.patch : V.head)[dither(5, t, px, py, 0.55)];
    oR = c[0];
    oG = c[1];
    oB = c[2];
    oA = 1;
    oK = 2;
    return;
  }
  if (inBody) {
    const t = shade((u - 0.03) / 0.9, (v - 0.03) / 1.12);
    const m = mask(u, v);
    let c: RGB;
    if (m === 2 && V.speck) c = V.speck;
    else c = (m === 1 ? V.patch : V.base)[dither(5, t, px, py, 0.55)];
    oR = c[0];
    oG = c[1];
    oB = c[2];
    oA = 1;
    oK = 2;
    return;
  }

  // --- sirip perut: dua kipas pendek lebar di bawah perut (dekat & jauh) ---
  if (v > 0.8) {
    const sway = Math.sin(qWave * 0.5) * 0.08;
    dx = u - 0.14;
    dy = v - 0.98;
    r2 = dx * dx + dy * dy;
    if (r2 < 0.5) {
      const a = Math.atan2(dy, dx) - 1.84 - sway;
      const w = win(a, -0.54, 0.54, 0.16);
      if (w > 0) {
        const R = (0.67 + 0.012 * Math.sin(a * 26)) * Math.sqrt(w);
        const r = Math.sqrt(r2);
        if (r < R) {
          finOut(r / R, a, 19, R - r < qPx * 1.05, false, px, py);
          return;
        }
      }
    }
    dx = u - 0.32;
    dy = v - 0.98;
    r2 = dx * dx + dy * dy;
    if (r2 < 0.42) {
      const a = Math.atan2(dy, dx) - 1.42 + sway;
      const w = win(a, -0.44, 0.44, 0.16);
      if (w > 0) {
        const R = 0.61 * Math.sqrt(w);
        const r = Math.sqrt(r2);
        if (r < R) {
          finOut(r / R, a, 19, false, true, px, py);
          return;
        }
      }
    }
  }

  // --- ekor bercagak; lapis jauh mengintip di bawah seperti sirip anal ---
  dx = u + 0.76;
  dy = v + 0.18;
  if (dx < 0.3) {
    r2 = dx * dx + dy * dy;
    if (r2 < 1.3) {
      const r = Math.sqrt(r2);
      const th = Math.atan2(dy, -dx);
      const thw = th + qTail * Math.sin(qWave - r * 3) * (0.2 + r);
      let R = tailR(thw);
      if (r < R) {
        finOut(r / R, thw, 27, R - r < qPx * 1.05, false, px, py);
        return;
      }
      const thf = th - 0.36 + qTail * Math.sin(qWave - r * 3 - 0.9) * (0.2 + r);
      R = 0.9 * tailR(thf);
      if (r < R) {
        finOut(r / R, thf, 27, false, true, px, py);
        return;
      }
    }
  }

  // --- sirip punggung: layar panjang dari puncak punuk sampai pangkal ekor ---
  const fe = 0.6 + 0.32 * Math.min(0, v + 1);
  if (v < -0.25 && u < fe) {
    dx = u;
    dy = v + 0.2;
    r2 = dx * dx + dy * dy;
    if (r2 < 2.1) {
      const r = Math.sqrt(r2);
      const ph = Math.atan2(-dx, -dy);
      const wob = qDors * Math.sin(qWave * 0.6 - ph * 3) * Math.max(0, r - 0.8) * 2.2;
      const R = dorsalR(ph + wob);
      if (r < R) {
        // jari-jari sirip memancar dari dalam badan: tegak di depan, rebah ke belakang
        const ra = Math.atan2(0.45 - u, 0.1 - v) + wob;
        const rn = clamp((r - 0.8) / (R - 0.8), 0, 1);
        finOut(0.2 + 0.8 * rn, ra, 52, R - r < qPx * 1.05 || u > fe - qPx * 1.05, false, px, py);
        return;
      }
    }
  }
}

// ====================== IKAN CUPANG (halfmoon) ======================
// Badan ramping di kanan; tiga sirip besar (punggung, ekor, anal) membentuk kipas
// setengah bulan di belakang. Tanpa garis tepi: ujung jari-jari sirip yang tidak rata
// dan warnanya sendiri yang membentuk siluet.
const B_SHIFT = 0.5;
const B_DORSAL = [-0.5, 0.45, -0.3, 0.86, 0.0, 1.22, 0.4, 1.5, 0.8, 1.64, 1.1, 1.56, 1.3, 1.16, 1.42, 0.4];
const B_ANAL = [-0.36, 0.5, -0.15, 0.9, 0.2, 1.32, 0.6, 1.6, 0.95, 1.62, 1.2, 1.38, 1.38, 0.5];
let RAYK = 6.5; // jumlah jari-jari sirip per radian (dikurangi untuk cupang mungil supaya tiap jari ≥ 1 piksel)

function lut(tab: number[], x: number): number {
  const n = tab.length;
  if (x <= tab[0] || x >= tab[n - 2]) return 0;
  for (let k = 0; k < n - 2; k += 2) {
    if (x < tab[k + 2]) return tab[k + 1] + ((tab[k + 3] - tab[k + 1]) * (x - tab[k])) / (tab[k + 2] - tab[k]);
  }
  return 0;
}

/** Panjang tiap jari sirip sedikit berbeda → tepi bergerigi alami */
const fringe = (ak: number) => 1 + 0.04 * Math.sin(ak * 9) + (qCrisp ? 0 : 0.045 * (hash(Math.floor(ak * RAYK), 3, qSeed) - 0.5));

let bTop = 0;
let bBot = 0;
/** Profil cupang pada posisi u: tepi atas (bTop) & bawah (bBot) */
function bettaProfile(u: number) {
  if (u < 0.5) {
    const h = 0.19 + 0.21 * sstep(-0.78, 0.25, u);
    bTop = -h;
    bBot = h;
  } else {
    // kepala baji: dahi melandai lurus, rahang bawah melengkung naik → mulut mendongak
    const t = Math.min(1, (u - 0.5) / 0.72);
    bTop = -0.4 + 0.33 * Math.pow(t, 1.2);
    bBot = 0.4 - 0.4 * Math.pow(t, 2.4);
  }
}

function bTone(pal: RGB[], t: number, depth: number, px: number, py: number) {
  const c = pal[qCrisp ? flat(pal.length, t) : dither(pal.length, t, px, py, 0.6)];
  const sh = qV.finShade;
  oR = c[0] + (sh[0] - c[0]) * depth;
  oG = c[1] + (sh[1] - c[1]) * depth;
  oB = c[2] + (sh[2] - c[2]) * depth;
  oA = 1;
  oK = 1;
}

/**
 * Warna sirip cupang per jari-jari: pangkal gelap → tepi terang, tiap jari punya
 * kecerahan sendiri, dan sebagian jari berubah ke warna aksen (emas / merah) ke arah tepi.
 */
function bFin(rn: number, ak: number, acc: number, depth: number, fold: number, px: number, py: number) {
  const V = qV;
  const ri = Math.floor(ak * RAYK);
  const h2 = hash(ri, 3, qSeed);
  const fd = fold * (0.35 + 0.65 * rn) * (qCrisp ? 0.35 : 1); // lipatan kain yang ikut mengalir
  let pal = V.fin;
  let t = Math.pow(rn, 1.2) * 0.86 + (h2 - 0.5) * (qCrisp ? 0.14 : 0.34) * (0.25 + rn) + fd;
  const rimAt = 0.56 + (h2 - 0.5) * 0.06;
  if (V.rim && rn > rimAt) {
    // pita warna pekat di tepi sirip (blue rim)
    pal = V.rim;
    t = 0.12 + 0.8 * ((rn - rimAt) / (1.001 - rimAt)) + fd;
  } else {
    if (acc > 0 && V.fin2) {
      const g = clamp((vnoise(ri * 0.62 + (qSeed % 37), 0.5, qSeed) - 0.5) * 1.5 + 0.5, 0, 1) * 0.55 + hash(ri, 8, qSeed) * 0.45;
      if (g > 1 - acc) {
        const start = 0.24 + (0.5 * (1 - g)) / acc + (h2 - 0.5) * 0.12;
        if (rn > start) {
          pal = V.fin2;
          t = 0.24 + 0.6 * ((rn - start) / (1.001 - start)) + (h2 - 0.5) * 0.16 + fd;
        }
      }
    }
    // jari-jari warna ketiga (koi): garis biru di antara putih & merah
    if (pal === V.fin && V.fin3 && hash(ri, 12, qSeed) < 0.3 && rn > 0.16 + 0.3 * h2 && rn < 0.94) {
      pal = V.fin3;
      t = 0.2 + 0.55 * rn + fd;
    }
  }
  // warna aksen tidak ikut digelapkan supaya tetap cerah
  bTone(pal, t, pal === V.fin ? depth : depth * 0.25, px, py);
}

function sampleBetta(u0: number, v0: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  const u = u0 - B_SHIFT;
  // badan belakang & pangkal sirip ikut meliuk saat berenang
  const v = u < 0.3 ? v0 + qBend * Math.sin(qWave + u * 2.6) * sstep(0.3, -1.5, u) : v0;
  if (u < -3 || u > 1.24 || v < -2.1 || v > 2.1) return;
  const V = qV;
  const big = V.dumbo === true;

  // --- sirip dada (kuping dumbo kalau besar) ---
  const ear = V.ear;
  if (ear) {
    const R0 = big ? 0.78 : 0.36;
    const dx = u - 0.44;
    const dy = v - 0.1;
    const r2 = dx * dx + dy * dy;
    if (r2 < R0 * R0 * 1.25) {
      let a = Math.atan2(dy, dx) - ((big ? 2.62 : 2.3) + qFlap * (big ? 0.5 : 1));
      if (a < -Math.PI) a += TAU;
      const half = big ? 1.08 : 0.6;
      const w = win(a, -half, half, big ? 0.55 : 0.3);
      if (w > 0) {
        const R = big ? R0 * (1 + 0.045 * Math.sin(a * 10 + 1)) * Math.pow(Math.cos((a / half) * 1.5708), 0.42) : R0 * Math.sqrt(w);
        const r = Math.sqrt(r2);
        if (r < R) {
          const er = r / R;
          const et = big ? 0.16 + er * er * 0.84 : er * 0.95;
          let c = ear[qCrisp ? flat(ear.length, et) : dither(ear.length, et, px, py, 0.6)];
          if (big && er > 0.4 && er < 0.86 && Math.sin(a * 13) < -0.62) c = ear[ear.length - 3]; // jari-jari kipas
          oR = c[0];
          oG = c[1];
          oB = c[2];
          oA = 1;
          oK = 2;
          return;
        }
      }
    }
  }

  // --- badan & kepala ---
  if (u > -0.97 && v > -0.45 && v < 0.45) {
    let inside: boolean;
    if (u < -0.78) {
      bTop = -0.19;
      bBot = 0.19;
      inside = (u + 0.78) * (u + 0.78) + v * v < 0.0361;
    } else {
      bettaProfile(u);
      inside = v > bTop && v < bBot;
    }
    if (inside) {
      const ny = (v - (bTop + bBot) / 2) / ((bBot - bTop) / 2);
      let t = shade((u - 0.2) * 0.75, ny * 0.92);
      const gx = 0.5 + 0.13 * ny * ny; // tepi belakang tutup insang
      const isHead = u > gx + (V.marble ? (vnoise(v * 7 + 3, u * 5, qSeed) - 0.5) * 0.12 : 0);
      let c: RGB;
      if (isHead) {
        if (!V.marble && u - gx < qPx * 1.1) t += 0.3;
        c = V.head[qCrisp ? flat(5, t - 0.04) : dither(5, t - 0.04, px, py, 0.55)];
        if (V.marble && V.speck && u < 1.0 && hash(Math.floor(u / qPx), Math.floor(v / qPx), qSeed + 5) > 0.85) c = V.speck;
      } else {
        // sisik berkilau: satu piksel terang di tiap sel 2×2 yang berselang-seling
        const row = py >> 1;
        if (!qCrisp) t += ((px + (row & 1)) & 1) === 0 && (py & 1) === 0 ? -0.18 : 0.03;
        if (V.marble) {
          t += 0.2 * Math.exp(-((u - 0.02) * (u - 0.02)) / 0.08 - ((v - 0.1) * (v - 0.1)) / 0.03); // bercak kobalt
          if (u > gx - qPx * 1.2) t += 0.2;
        }
        if (V.koi) {
          // koi: bercak merah di atas jingga, sisik biru di badan belakang
          const kn = vnoise(u * 2.1 + (qSeed % 23), v * 2.6 + 4, qSeed);
          c = (kn > 0.58 ? V.patch : kn < 0.4 && u < 0.3 && V.alt ? V.alt : V.base)[qCrisp ? flat(5, t) : dither(5, t, px, py, 0.55)];
        } else c = V.base[qCrisp ? flat(5, t) : dither(5, t, px, py, 0.55)];
      }
      oR = c[0];
      oG = c[1];
      oB = c[2];
      oA = 1;
      oK = 2;
      return;
    }
  }

  // ---------------------------------------------------------------- surai
  // Semua sirip dilengkungkan oleh SATU medan gelombang halus (seperti kain/bendera):
  //  • gelombang naik-turun merambat dari badan ke belakang, makin besar di ujung surai
  //  • gelombang maju-mundur merambat dari badan ke ujung atas & bawah
  // Karena bentuk siripnya sendiri mulus, hasilnya kontur S yang mengalir, bukan getar acak.
  // Lalu ditambah sapuan ke belakang sebanding laju (qStream) & seretan naik/turun (qLift).
  let dx: number;
  let dy: number;
  let r2: number;
  const W = qWave;
  let uf = u;
  let vf = v;
  let fold = 0;
  const d = 0.25 - u;
  if (d > 0) {
    const p1 = W - d * 2.6 + v * 0.9;
    const av = v < 0 ? -v : v;
    vf += qAmp * Math.pow(d, 1.2) * (Math.sin(p1) * 0.75 + Math.sin(p1 * 1.9 + 1.3) * 0.25);
    uf += qAmp * 0.9 * av * Math.sin(W * 1.15 - av * 3.2 + d * 0.8 + (v < 0 ? 0 : 2.1));
    fold = qFold * Math.cos(p1 - 0.6); // lipatan terang-gelap ikut mengalir
  }

  // --- sirip perut: dua helai panjang yang terseret arus ---
  if (v > 0.1 && u > -1.2 && u < 0.8) {
    dx = uf - 0.42;
    dy = vf - 0.26;
    r2 = dx * dx + dy * dy;
    if (r2 < 1.5) {
      const r = Math.sqrt(r2);
      const a0 = Math.atan2(-dx, dy) - (qStream * 0.6 + Math.max(0, -qLift) * 0.3) * r;
      let a = a0 - 0.34;
      let w = win(a, -0.23, 0.23, 0.2);
      if (w > 0 && r < 1.06 * qLen * Math.sqrt(w)) {
        bTone(V.fin2 ?? V.fin, 0.15 + (r / 1.06) * 0.8, 0, px, py);
        return;
      }
      a = a0 - 0.02;
      w = win(a, -0.19, 0.19, 0.16);
      if (w > 0 && r < 0.86 * qLen * Math.sqrt(w)) {
        bTone(V.fin, 0.1 + (r / 0.86) * 0.6, 0.2, px, py);
        return;
      }
    }
  }

  // --- sirip punggung: kipas tinggi yang berkibar ke belakang ---
  if (v < 0.7 && u < 0.5) {
    dx = uf + 0.3;
    dy = vf + 0.05;
    r2 = dx * dx + dy * dy;
    if (r2 < 4.6) {
      const r = Math.sqrt(r2);
      const ph = Math.atan2(-dx, -dy) - (qStream * 0.27 + qLift * 0.2) * r;
      const R = lut(B_DORSAL, ph) * fringe(ph + 11) * qLen * (1 + qRip * Math.sin(ph * 4.3 - W * 0.9));
      if (r < R) {
        bFin(clamp((r - 0.36) / Math.max(0.05, R - 0.36), 0, 1), ph + 11, V.acc ? V.acc[0] : 0, 0, fold, px, py);
        return;
      }
    }
  }

  // --- sirip anal: menjuntai panjang ke bawah-belakang ---
  if (v > -0.7 && u < 0.5) {
    dx = uf + 0.2;
    dy = vf - 0.1;
    r2 = dx * dx + dy * dy;
    if (r2 < 4.6) {
      const r = Math.sqrt(r2);
      const pa = Math.atan2(-dx, dy) - (qStream * 0.27 - qLift * 0.2) * r;
      const R = lut(B_ANAL, pa) * fringe(pa + 23) * qLen * (1 + qRip * Math.sin(pa * 4.3 - W * 0.9 + 2));
      if (r < R) {
        bFin(clamp((r - 0.38) / Math.max(0.05, R - 0.38), 0, 1), pa + 23, V.acc ? V.acc[2] : 0, 0.05, fold, px, py);
        return;
      }
    }
  }

  // --- ekor setengah bulan: kipas 180° yang menguncup saat melaju & mekar saat diam ---
  dx = uf + 0.82;
  dy = vf;
  if (dx < 0.3) {
    r2 = dx * dx + dy * dy;
    if (r2 < 4.6) {
      const r = Math.sqrt(r2);
      const th = (Math.atan2(dy, -dx) - qLift * 0.2 * r) * (1 + qStream * 0.2 * Math.min(r, 1.5));
      const w = win(th, -1.56, 1.56, 0.26);
      if (w > 0) {
        const R =
          1.58 * fringe(th + 37) * Math.sqrt(w) * qLen * (1 + qRip * Math.sin(th * 4.3 - W * 0.9 + 4)) * (1 + 0.08 * clamp(qStream, 0, 1.2));
        if (r < R) bFin(r / R, th + 37, V.acc ? V.acc[1] : 0, 0.16, fold, px, py);
      }
    }
  }
}

// ====================== IKAN BADUT · BLUE TANG · DISKUS ======================
const INK: RGB = hex('#1a1430');
const TRIM: RGB = hex('#3a1a26'); // tepi gelap Nemo (cokelat tua, lebih lembut dari hitam)
const DISC_TAIL = ramp('#5a4488', '#8a7cc0', '#c0b8e8');

function solid(c: RGB) {
  oR = c[0];
  oG = c[1];
  oB = c[2];
  oA = 1;
  oK = 2;
}

/** Sirip dada bentuk kipas kecil; mengembalikan r/R (0..1) atau -1 kalau di luar */
function paddle(u: number, v: number, cu: number, cv: number, ang: number, R0: number, half: number): number {
  const dx = u - cu;
  const dy = v - cv;
  const r2 = dx * dx + dy * dy;
  if (r2 >= R0 * R0) return -1;
  let a = Math.atan2(dy, dx) - ang;
  if (a < -Math.PI) a += TAU;
  else if (a > Math.PI) a -= TAU;
  const w = win(a, -half, half, half * 0.5);
  if (w <= 0) return -1;
  const R = R0 * Math.sqrt(w);
  const r = Math.sqrt(r2);
  return r < R ? r / R : -1;
}

function seg2(u: number, v: number, x0: number, y0: number, x1: number, y1: number) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const k = clamp(((u - x0) * dx + (v - y0) * dy) / (dx * dx + dy * dy), 0, 1);
  const ex = u - x0 - dx * k;
  const ey = v - y0 - dy * k;
  return ex * ex + ey * ey;
}

/** Ikan badut (Nemo): jingga, tiga pita putih bertepi gelap tipis, sirip bulat bertepi gelap tipis */
function sampleClown(u: number, v0: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  if (u < -1.8 || u > 1.3 || v0 < -1.3 || v0 > 1.3) return;
  const V = qV;
  const e = qPx * 0.72; // tebal tepi gelap: di bawah 1 piksel → garis tipis
  // badan belakang & ekor melenggok
  const v = u < 0.4 ? v0 + qTail * 0.75 * Math.sin(qWave + u * 2.2) * (0.4 - u) : v0;

  const pr = paddle(u, v, 0.32, 0.16, 2.45 + qFlap, 0.34, 0.75);
  if (pr >= 0) {
    solid(pr > 1 - e / 0.34 ? TRIM : V.base[pr < 0.5 ? 2 : 1]);
    return;
  }

  const q = (u - 0.1) / 1.1;
  const av = v < 0 ? -v : v;
  const h = q > -1 && q < 1 ? 0.62 * Math.pow(1 - q * q, 0.55) : 0;
  if (av < h) {
    const t = shade(q * 0.9, v / 0.68);
    const d1 = Math.abs(u - (0.56 - 0.35 * v * v)) - 0.11; // pita kepala
    const d2 = Math.abs(u - (-0.3 + 0.12 * Math.exp(-(v * v) / 0.05))) - 0.13; // pita tengah
    const d3 = Math.abs(u + 0.86) - 0.08; // pita pangkal ekor
    const d = d1 < d2 ? (d1 < d3 ? d1 : d3) : d2 < d3 ? d2 : d3;
    if (d < 0) solid(V.patch[dither(5, t * 0.8, px, py, 0.6)]);
    else if (d < e * 0.6) solid(TRIM);
    else solid(V.base[dither(5, t, px, py, 0.55)]);
    return;
  }
  if (h > 0) {
    let fh = 0;
    if (v < 0) {
      if (u > -0.82 && u < 0.7) fh = 0.05 + 0.27 * gauss(u - 0.3, 0.27) + 0.34 * gauss(u + 0.42, 0.24); // punggung dua cuping
    } else if (u > -0.84 && u < -0.02) fh = 0.34 * gauss(u + 0.46, 0.22); // anal
    else if (u > 0 && u < 0.52) fh = 0.3 * gauss(u - 0.24, 0.15); // perut
    if (fh > 0.04 && av < h + fh) {
      solid(av > h + fh - e ? TRIM : V.base[Math.sin(u * 24) > 0.1 ? 1 : 2]);
      return;
    }
  }
  // ekor bulat
  const dx = -(u + 0.9);
  if (dx > -0.05) {
    const r = Math.sqrt(dx * dx + v * v);
    if (r < 0.8) {
      const th = Math.atan2(v, dx);
      const w = win(th, -1.05, 1.05, 0.4);
      if (w > 0) {
        const R = 0.74 * Math.sqrt(w);
        if (r < R) solid(R - r < e ? TRIM : V.base[Math.sin(th * 12) > 0.2 ? 1 : 2]);
      }
    }
  }
}

/** Blue tang (Dory): biru royal, pola hitam "palet" yang mengurung oval biru, ekor kuning */
function sampleTang(u: number, v0: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  if (u < -1.85 || u > 1.42 || v0 < -1.3 || v0 > 1.3) return;
  const V = qV;
  const e = qPx * 1.05;
  const v = u < 0.4 ? v0 + qTail * 0.6 * Math.sin(qWave + u * 2.1) * (0.4 - u) : v0;

  // sirip dada: pangkal biru, ujung kuning
  const pr = paddle(u, v, 0.46, 0.16, 2.5 + qFlap, 0.36, 0.6);
  if (pr >= 0) {
    solid(pr > 0.5 ? V.patch[pr > 0.85 ? 2 : 1] : V.base[3]);
    return;
  }

  const q = (u - 0.14) / 1.2;
  const av = v < 0 ? -v : v;
  const h = q > -1 && q < 1 ? 0.72 * Math.pow(1 - q * q, 0.6) : 0;
  if (av < h) {
    const t = shade(q * 0.9, v / 0.8);
    const ax = (u + 0.14) / 0.84;
    const ay = (v + 0.08) / 0.4;
    const bx = (u + 0.02) / 0.42;
    const by = (v + 0.02) / 0.15;
    // pita punggung dari mata sampai ekor + lengkung di tengah badan, dikurangi oval biru
    const black = ((u < 0.84 && v < -h + 0.28) || ax * ax + ay * ay < 1) && bx * bx + by * by > 1;
    solid(black ? INK : V.base[dither(5, t, px, py, 0.55)]);
    return;
  }
  if (h > 0) {
    let fh = 0;
    if (v < 0) {
      if (u > -0.96 && u < 0.72) fh = 0.24 * Math.min(1, (0.72 - u) / 0.35, (u + 0.96) / 0.2);
    } else if (u > -0.96 && u < 0.1) fh = 0.22 * Math.min(1, (0.1 - u) / 0.35, (u + 0.96) / 0.2);
    else if (u > 0.28 && u < 0.5) fh = 0.16 * gauss(u - 0.39, 0.09);
    if (fh > 0.03 && av < h + fh) {
      solid(av > h + fh - e ? INK : V.base[Math.sin(u * 30) > 0.3 ? 2 : 3]);
      return;
    }
  }
  // ekor kuning bertepi hitam di atas & bawah
  const dx = -(u + 1.0);
  if (dx > -0.06 && dx < 0.66) {
    const r = Math.sqrt(dx * dx + v * v);
    const th = Math.atan2(v, dx);
    const ath = th < 0 ? -th : th;
    if (ath < 0.78 && r < 0.82) solid(ath > 0.5 ? INK : V.patch[dither(5, 0.1 + 0.5 * (r / 0.82), px, py, 0.6)]);
  }
}

/** Jarak ke tepi sel (Worley): kecil = di garis jala antar sel */
function cellEdge(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  let f1 = 9;
  let f2 = 9;
  for (let j = -1; j <= 1; j++) {
    for (let i = -1; i <= 1; i++) {
      const cx = ix + i + 0.2 + 0.6 * hash(ix + i, iy + j, seed);
      const cy = iy + j + 0.2 + 0.6 * hash(ix + i, iy + j, seed + 17);
      const d = (x - cx) * (x - cx) + (y - cy) * (y - cy);
      if (d < f1) {
        f2 = f1;
        f1 = d;
      } else if (d < f2) f2 = d;
    }
  }
  return Math.sqrt(f2) - Math.sqrt(f1);
}

/**
 * Diskus batik (pigeon checkerboard), bentuk mengikuti foto: badan pipih TINGGI (lebih tinggi
 * daripada panjang), dahi curam membulat, moncong kecil di depan-bawah, sisi belakang lebih
 * tegak dengan dua "sudut" tempat sirip punggung & anal berakhir, lalu ekor kipas terpisah.
 * Corak: jala merah-jingga mengurung sel putih; wajah jingga bergaris putih; sirip punggung &
 * anal merah → marun gelap ke belakang dengan garis putih memancar; mata merah.
 */
function sampleDiscus(u: number, v0: number, px: number, py: number) {
  oK = 0;
  oA = 0;
  if (u < -1.9 || u > 1.2 || v0 < -1.35 || v0 > 1.95) return;
  const V = qV;
  const v = u < -0.5 ? v0 + qTail * 0.6 * Math.sin(qWave + u * 2) * (-0.5 - u) : v0;

  const du = u - 0.02;
  const av = v < 0 ? -v : v;
  // depan: elips; belakang: super-elips (lebih kotak) → siluet seperti perisai / huruf D
  const rn = du >= 0 ? Math.sqrt((du * du) / 0.81 + (v * v) / 1.44) : Math.pow(Math.pow(-du / 0.9, 2.7) + Math.pow(av / 1.2, 2.7), 0.3704);
  const sx = u - 0.76;
  const sy = v - 0.3;
  const snout = sx * sx + sy * sy < 0.073;
  if (rn < 1 || snout) {
    const ang = Math.atan2(v, du);
    const aa = ang < 0 ? -ang : ang;
    // sirip punggung & anal: pita di tepi cakram, tidak ada di wajah, melebar ke belakang, hilang di pangkal ekor
    const bw = rn < 1 ? (0.13 + 0.2 * sstep(1.2, 2.5, aa)) * sstep(0.6, 0.95, aa) * (1 - sstep(2.72, 3.05, aa)) : 0;
    if (bw > 0.02 && rn > 1 - bw) {
      const k = (rn - (1 - bw)) / bw; // 0 = pangkal sirip, 1 = tepi luar
      const rear = sstep(1.25, 2.2, aa);
      if (k < 0.82 && Math.sin(ang * 42) > 0.3) solid(V.fin[3]); // garis putih memancar
      else if (k > 0.82) solid(V.fin[0]);
      else solid(rear > 0.5 ? V.fin[k > 0.45 ? 0 : 1] : V.patch[k > 0.45 ? 3 : 2]);
      return;
    }
    const t = shade((du / 0.95) * 0.9, (v / 1.2) * 0.9);
    const cs = Math.max(0.24, qPx * 2.9); // sel ≈ 3 piksel: 2 putih + 1 garis jala
    const white =
      u > 0.44
        ? Math.sin(v * 13 + 2.4 * Math.sin(u * 7 + 1)) > 0.6 // garis putih bergelombang di wajah
        : cellEdge(u / (cs * 1.1) + 31, v / (cs * 0.9) + 17, qSeed) > 0.3;
    if (white) solid(V.base[dither(5, t * 0.75, px, py, 0.6)]);
    else solid(V.patch[dither(5, clamp(0.44 - 0.42 * u + 0.2 * (rn - 0.5), 0, 0.99), px, py, 0.6)]);
    return;
  }
  // sirip perut: dua helai tipis merah menjuntai ke belakang-bawah
  if (v > 0.9 && u > -0.4 && u < 0.5) {
    const sway = Math.sin(qWave * 0.5) * 0.08;
    const th2 = qPx * qPx * 0.3; // setebal ±1 piksel
    if (seg2(u, v, 0.36, 1.08, 0.04 + sway, 1.82) < th2 || seg2(u, v, 0.12, 1.14, -0.3 - sway, 1.6) < th2) {
      solid(v > 1.5 ? V.fin[3] : V.patch[2]);
      return;
    }
  }
  // ekor kipas tembus pandang: pangkal marun, lalu ungu kebiruan dengan jari-jari pucat
  const dx = -(u + 0.84);
  if (dx > -0.05) {
    const r = Math.sqrt(dx * dx + (v + 0.04) * (v + 0.04));
    if (r < 0.86) {
      const th = Math.atan2(v + 0.04, dx);
      const w = win(th, -0.98, 0.98, 0.3);
      if (w > 0) {
        const R = 0.8 * Math.sqrt(w);
        if (r < R) {
          const k = r / R;
          const c = k < 0.2 ? V.fin[1] : DISC_TAIL[Math.sin(th * 24) > 0.35 ? 2 : k > 0.75 ? 1 : 0];
          oR = c[0];
          oG = c[1];
          oB = c[2];
          oA = k < 0.2 ? 1 : 0.88;
          oK = 1;
        }
      }
    }
  }
}

const FACE_BADUT = [0.86, 0.22, 1.16, 0.1, 0.92, -0.08];
const FACE_DORI = [0.84, 0.14, 1.28, 0.12, 0.92, -0.2];
const FACE_DISKUS = [0.5, 0.4, 1.0, 0.36, 0.62, 0.12];

// posisi wajah [pipi, mulut, mata] dalam koordinat lokal
const FACE_KOKI = [0.8, 0.25, 1.2, 0.16, 0.93, -0.03];
const FACE_CUPANG = [1.4, 0.13, 1.63, 0.0, 1.35, -0.05];

// ---------- stempel mata (biar imut & tajam di piksel) ----------
const EYE_L = [' RRR ', 'RWKKR', 'RKKKR', 'RKKSR', ' RRR '];
const EYE_M = [' RR ', 'RWKR', 'RKKR', ' RR '];
const EYE_S = ['RR ', 'WKR', 'KKR'];
const HAPPY_L = ['     ', '  K  ', ' K K ', 'K   K', '     '];
const HAPPY_M = ['    ', ' KK ', 'K  K', '    '];
const BLINK_L = ['     ', '     ', 'KKKKK', '     ', '     '];
const BLINK_M = ['    ', '    ', 'KKKK', '    '];
const HAPPY_S = ['   ', ' K ', 'K K'];
const BLINK_S = ['   ', 'KKK', '   '];
// cupang mungil: mata 2×2 dengan satu kilau
const EYE_T = ['WK', 'KK'];
const LINE_T = ['  ', 'KK'];

function setPx(idx: number, c: RGB) {
  sR[idx] = c[0];
  sG[idx] = c[1];
  sB[idx] = c[2];
  sA[idx] = 1;
}

const WHITE: RGB = [255, 255, 255];

export function drawFish(buf: Uint32Array, W: number, H: number, p: FishPose) {
  const unit = p.unit;
  const inv = 1 / unit;
  const sgn = p.facing >= 0 ? 1 : -1;
  const fm = Math.max(0.3, Math.abs(p.facing));
  const f = sgn * fm;
  const a = p.pitch * sgn;
  const ca = Math.cos(a);
  const sa = Math.sin(a);
  const kind = p.variety.kind;
  const thinLine = kind === 'badut' || kind === 'dori';
  const cup = kind === 'cupang';
  const FC = cup ? FACE_CUPANG : kind === 'badut' ? FACE_BADUT : kind === 'dori' ? FACE_DORI : kind === 'diskus' ? FACE_DISKUS : FACE_KOKI;
  const hw = Math.min((SPR - 1) >> 1, Math.ceil((cup ? 2.5 : 2.25) * unit) + 2);
  const sw = hw * 2 + 1;
  const V = p.variety;

  qV = V;
  qSeed = p.seed;
  qLx = sgn;
  qWave = p.wave;
  qTail = cup ? 0.05 + 0.05 * p.swim : 0.09 + 0.1 * p.swim;
  qDors = 0.035 + 0.035 * p.swim;
  qFlap = Math.sin(p.wave * 0.9) * 0.3;
  qPx = inv;
  const flare = p.flare ?? 0;
  // fase gelombang surai dibuat bertahap (≈15 langkah/detik) supaya terasa animasi piksel, bukan piksel merayap
  if (cup) qWave = Math.round(p.wave / 0.24) * 0.24;
  RAYK = cup ? clamp(unit * 0.72, 3.2, 6.5) : 6.5;
  qCrisp = cup && unit < 7;
  qStream = p.stream ?? 0;
  qLift = p.lift ?? 0;
  // diam/pose → ombak besar & pelan; melaju → surai menegang, riak kecil & cepat
  qAmp = 0.13 + 0.06 * flare - 0.04 * clamp(qStream, 0, 1);
  qLen = (1 + 0.1 * flare) * (V.finLen ?? 1);
  qFold = 0.11;
  qRip = 0.03 + 0.02 * p.swim;
  qBend = 0.03 + 0.045 * p.swim;

  for (let j = 0; j < sw; j++) {
    const Y = (j - hw) * inv;
    for (let i = 0; i < sw; i++) {
      const X = (i - hw) * inv;
      if (cup) sampleBetta((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      else if (kind === 'badut') sampleClown((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      else if (kind === 'dori') sampleTang((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      else if (kind === 'diskus') sampleDiscus((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      else sample((X * ca + Y * sa) / f, -X * sa + Y * ca, i, j);
      const idx = j * sw + i;
      sK[idx] = oK;
      if (oK) {
        sR[idx] = oR;
        sG[idx] = oG;
        sB[idx] = oB;
        sA[idx] = oA;
      }
    }
  }

  // lokal → koordinat sprite
  const toX = (u: number, v: number) => Math.round((u * f * ca - v * sa) * unit) + hw;
  const toY = (u: number, v: number) => Math.round((u * f * sa + v * ca) * unit) + hw;

  if (fm > 0.55) {
    // pipi merona
    const bxp = toX(FC[0], FC[1]);
    const byp = toY(FC[0], FC[1]);
    const bw = cup ? 1 : unit >= 14 ? 3 : 2;
    const bh = cup && unit < 6.5 ? 0 : p.eye === 'happy' && unit >= 12 ? 2 : 1;
    for (let j = 0; j < bh; j++) {
      for (let i = 0; i < bw; i++) {
        const xx = bxp + (sgn > 0 ? i - bw + 1 : -i + bw - 1);
        const idx = (byp + j) * sw + xx;
        if (xx < 0 || xx >= sw || byp + j < 0 || byp + j >= sw || sK[idx] !== 2) continue;
        sR[idx] += (V.blush[0] - sR[idx]) * 0.62;
        sG[idx] += (V.blush[1] - sG[idx]) * 0.62;
        sB[idx] += (V.blush[2] - sB[idx]) * 0.62;
      }
    }
    // mulut mungil
    const mx = toX(FC[2], FC[3]);
    const my = toY(FC[2], FC[3]);
    for (let j = 0; j < (p.mouthOpen ? 2 : 1); j++) {
      const idx = (my + j) * sw + mx;
      if (mx >= 0 && mx < sw && my + j >= 0 && my + j < sw && sK[idx] === 2) setPx(idx, V.mouth);
    }
    // mata
    const big = unit >= (cup ? 16.5 : 14.5);
    const small = unit < (cup ? 11 : 9.5);
    let tpl: string[];
    if (cup && unit < 6.5) tpl = p.eye === 'open' ? EYE_T : LINE_T;
    else if (cup) tpl = p.eye === 'happy' ? HAPPY_S : p.eye === 'blink' ? BLINK_S : EYE_S;
    else if (p.eye === 'happy') tpl = big ? HAPPY_L : HAPPY_M;
    else if (p.eye === 'blink') tpl = big ? BLINK_L : BLINK_M;
    else tpl = big ? EYE_L : small ? EYE_S : EYE_M;
    const n = tpl.length;
    const ex = toX(FC[4], FC[5]) - (n >> 1);
    const ey = toY(FC[4], FC[5]) - (n >> 1);
    for (let j = 0; j < n; j++) {
      const row = tpl[j];
      for (let i = 0; i < row.length; i++) {
        const ch = row[i];
        if (ch === ' ') continue;
        const xx = ex + (cup && sgn < 0 ? row.length - 1 - i : i);
        const yy = ey + j;
        if (xx < 0 || xx >= sw || yy < 0 || yy >= sw) continue;
        const idx = yy * sw + xx;
        if (sK[idx] !== 2) continue;
        if (ch === 'R') setPx(idx, V.ring);
        else if (ch === 'W') setPx(idx, WHITE);
        else if (ch === 'S') setPx(idx, [V.pupil[0] + 60, V.pupil[1] + 50, V.pupil[2] + 90]);
        else setPx(idx, V.pupil);
      }
    }
  }

  // komposit + outline halus (selout)
  const x0 = p.x - hw;
  const y0 = p.y - hw;
  const tr = p.tint[0];
  const tg = p.tint[1];
  const tb = p.tint[2];
  const ta = p.tintAmt;
  const fl = V.finLine;
  for (let j = 0; j < sw; j++) {
    const Y = y0 + j;
    if (Y < 0 || Y >= H) continue;
    for (let i = 0; i < sw; i++) {
      const X = x0 + i;
      if (X < 0 || X >= W) continue;
      const idx = j * sw + i;
      const k = sK[idx];
      let r = 0;
      let g = 0;
      let b = 0;
      let al = 0;
      const kl = i > 0 ? sK[idx - 1] : 0;
      const kr = i < sw - 1 ? sK[idx + 1] : 0;
      const ku = j > 0 ? sK[idx - sw] : 0;
      const kd = j < sw - 1 ? sK[idx + sw] : 0;
      if (k) {
        r = sR[idx];
        g = sG[idx];
        b = sB[idx];
        al = sA[idx];
        if (k === 1 && (kl === 2 || kr === 2 || ku === 2 || kd === 2)) {
          r += (fl[0] - r) * 0.55;
          g += (fl[1] - g) * 0.55;
          b += (fl[2] - b) * 0.55;
          if (al < 0.9) al = 0.9;
        }
      } else {
        let n = -1;
        if (kl === 2) n = idx - 1;
        else if (kr === 2) n = idx + 1;
        else if (ku === 2) n = idx - sw;
        else if (kd === 2) n = idx + sw;
        if (n >= 0) {
          r = sR[n] * 0.42 + 8;
          g = sG[n] * 0.28 + 4;
          b = sB[n] * 0.38 + 22;
          // ikan bersirip tepi hitam (Nemo, Dory): jangan tumpuk garis luar lagi di atas tepi gelapnya
          al = cup ? (qCrisp ? 0.72 : 0.5) : thinLine ? (sR[n] + sG[n] + sB[n] < 190 ? 0 : 0.5) : 0.92;
        } else if (!cup && (kl || kr || ku || kd)) {
          r = fl[0];
          g = fl[1];
          b = fl[2];
          al = 0.6;
        } else continue;
      }
      if (ta > 0) {
        r += (tr - r) * ta;
        g += (tg - g) * ta;
        b += (tb - b) * ta;
      }
      blend(buf, Y * W + X, r, g, b, al);
    }
  }
}

// Helper warna, dithering, dan noise untuk render piksel.

export type RGB = readonly [number, number, number];

export const TAU = Math.PI * 2;

export const clamp = (x: number, a: number, b: number) => (x < a ? a : x > b ? b : x);

/** smoothstep; juga bekerja kalau a > b (arah terbalik) */
export const sstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function hex(h: string): RGB {
  const n = parseInt(h.slice(1), 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export const ramp = (...hs: string[]): RGB[] => hs.map(hex);

export const mix = (a: RGB, b: RGB, t: number): RGB => [
  a[0] + (b[0] - a[0]) * t,
  a[1] + (b[1] - a[1]) * t,
  a[2] + (b[2] - a[2]) * t,
];

/** Kemas ke Uint32 little-endian (ABGR) untuk ImageData */
export const pack = (r: number, g: number, b: number) =>
  (0xff000000 | ((b & 255) << 16) | ((g & 255) << 8) | (r & 255)) >>> 0;

export const packRGB = (c: RGB) => pack(c[0] | 0, c[1] | 0, c[2] | 0);

/** Alpha-blend satu piksel ke buffer */
export function blend(buf: Uint32Array, i: number, r: number, g: number, b: number, a: number) {
  const d = buf[i];
  const dr = d & 255;
  const dg = (d >> 8) & 255;
  const db = (d >> 16) & 255;
  buf[i] = pack((dr + (r - dr) * a) | 0, (dg + (g - dg) * a) | 0, (db + (b - db) * a) | 0);
}

const B4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
export const BAYER = new Float32Array(16);
B4.forEach((v, i) => (BAYER[i] = (v + 0.5) / 16));

/**
 * Pilih indeks tone (0..n-1) dari nilai t (0..1) dengan ordered dithering.
 * `soft` = lebar zona dither di antara dua tone (kecil = pita warna lebih tegas).
 */
export function dither(n: number, t: number, x: number, y: number, soft = 0.5): number {
  const f = clamp(t, 0, 0.9999) * (n - 1);
  const i = f | 0;
  const fr = (f - i - (1 - soft) / 2) / soft;
  return fr > BAYER[((y & 3) << 2) | (x & 3)] ? i + 1 : i;
}

export function hash(ix: number, iy: number, seed: number): number {
  let h = Math.imul(ix | 0, 374761393) ^ Math.imul(iy | 0, 668265263) ^ Math.imul(seed | 0, 1442695041);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}

export function vnoise(x: number, y: number, seed: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const fx = x - ix;
  const fy = y - iy;
  const sx = fx * fx * (3 - 2 * fx);
  const sy = fy * fy * (3 - 2 * fy);
  const a = hash(ix, iy, seed);
  const b = hash(ix + 1, iy, seed);
  const c = hash(ix, iy + 1, seed);
  const d = hash(ix + 1, iy + 1, seed);
  return a + (b - a) * sx + (c + (d - c) * sx - (a + (b - a) * sx)) * sy;
}

/** RNG ber-seed (mulberry32) supaya dekorasi konsisten antar tema */
export function rng(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

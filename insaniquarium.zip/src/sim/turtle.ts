// Kura-kura lumut: tempurung berambut alga yang mengalir, bayi yang menempel di punggung,
// kaki mendayung, leher yang menjulur ke pelet. Semua gerak sekunder memakai pegas teredam
// (rasa "ragdoll"): rambut alga, kaki, kepala, kemiringan badan, dan si bayi yang berpegangan.

import { RGB, blend, clamp, dither, hash, hex, mix, ramp, rng } from './palette';

export interface FoodLike {
  x: number;
  y: number;
  rest: boolean;
}

export interface TurtleEnv {
  W: number;
  H: number;
  time: number;
  sandBase: number;
  food: FoodLike[];
  eat(f: FoodLike): void;
  heart(x: number, y: number, big: boolean): void;
  bubble(x: number, y: number, r: number): void;
}

// ---------- palet ----------
// kulit hijau tua khas kura-kura telinga merah, dengan garis kuning & bercak merah
const SKIN = ramp('#a4dc8c', '#6cbc74', '#479a62', '#2f7256', '#205048').map((c) => mix(c, [0, 0, 0], 0.183)); // kulit digelapkan (5% lalu 14% lagi)
const CHIN = ramp('#fff6a8', '#ffe35e', '#f2bd3e', '#c8932f');
const YEL: RGB = hex('#ffe24a');
const YEL_D: RGB = hex('#e6b838');
const YEL_FAR: RGB = hex('#b9a84a');
const RED = ramp('#ff5a44', '#d8303e');
const IRIS_Y: RGB = hex('#ffe84a');
const IRIS_G: RGB = hex('#b9dc3c');
const MOSS = ramp('#b8f24c', '#80dc2c', '#4cb824', '#2e8e28', '#1c662c');
const RIM = ramp('#f6f6a0', '#dde070', '#aebc52', '#7a8e44');
const PLAS = ramp('#fff3a0', '#f6dc6c', '#dcb850', '#b08a44');
// rambut alga sutra: hijau limau menyala (A) bergeser ke hijau zamrud terang (B) di sisi ekor
const SILK_A = ramp('#1c6a1e', '#289020', '#3cb41e', '#5cd01c', '#84e420', '#a8f22c', '#c8fa48', '#e2fe78', '#f6ffb4');
const SILK_B = ramp('#0f6a2e', '#149434', '#1eb93a', '#34d640', '#58ea4c', '#84f65e', '#aefc7c', '#d0ffa2', '#eeffd0');
const LINE: RGB = hex('#2e2a58');
const EYE: RGB = hex('#15122e');
const BLUSH: RGB = hex('#ff8fb0');
const WHITE: RGB = [255, 255, 255];
const CLAW: RGB = hex('#fff8dc');
const CLAW_FAR: RGB = hex('#cfc8c8');

// ---------- geometri lokal (1 unit = setengah panjang tempurung; +u = depan, +v = bawah) ----------
const CX = -0.05; // pusat tempurung
const CY = 0.14; // garis tepi tempurung
const DA = 1.0; // kubah: setengah panjang
const DB = 0.72; // kubah: tinggi
const PA = 0.9; // plastron
const PB = 0.3;
const NBU = 0.8; // pangkal leher
const NBV = 0.12;
// pangkal kaki: jauh-depan, jauh-belakang, dekat-depan, dekat-belakang
const PIV = [0.66, 0.26, -0.5, 0.27, 0.52, 0.3, -0.64, 0.3];

interface Strand {
  ru: number; // pangkal (lokal)
  rv: number;
  rest: number; // arah tumbuh: 0 = tegak lurus ke atas, + = tersisir ke ekor
  seg: number; // panjang ruas (unit)
  n: number;
  a: Float32Array; // sudut tiap ruas di kerangka kura-kura (0 = atas, − = ke arah ekor)
  w: Float32Array; // kecepatan sudut
  ph: number; // fase gelombang: mengikuti posisi di tempurung → ombak merambat melintasi surai
  layer: number; // 0 = lapis belakang (siluet), makin besar makin dekat ke penonton
  lk: number; // geser fase per ikal → tiap ikal berkibar sedikit berbeda
  gain: number; // besar ombak per ikal
  cols: RGB[];
  base: number;
  span: number;
  spark: boolean;
}

/**
 * Rambut panjang ditanam merata di SELURUH kubah tempurung (baris-baris konsentris, kerapatan
 * sama dari depan sampai belakang). Arah tumbuhnya tersisir ke belakang seperti rambut panjang
 * yang tergerai — bukan tegak seperti sikat.
 */
function makeStrands(seed: number, baby: boolean): Strand[] {
  const R = rng(seed);
  const out: Strand[] = [];
  const kks = baby ? [0.97, 0.7, 0.43, 0.16] : [0.97, 0.8, 0.63, 0.46, 0.29, 0.12];
  const per = baby ? 12.5 : 28;
  const n = baby ? 6 : 9;
  kks.forEach((kk0, layer) => {
    const count = Math.max(3, Math.round(per * kk0));
    for (let k = 0; k < count; k++) {
      const th = 0.1 + ((k + 0.5 + (R() - 0.5) * 0.5) / count) * 2.94; // 0 = depan tempurung, π = belakang
      const kk = kk0 - R() * 0.04;
      // panjang berubah halus di sepanjang tempurung → garis luar rambut mulus
      // rambut terbagi jadi beberapa ikal: tengah ikal lebih panjang & terang, tepinya lebih pendek & gelap
      const lp = ((th - 0.1) / 2.94) * (baby ? 4 : 7);
      const li = Math.floor(lp);
      const edge = Math.abs(lp - li - 0.5) * 2;
      const total = ((layer === 0 ? 2.4 : 1.95) + 0.3 * Math.sin(th * 2.3 + 1) + R() * 0.3 - 0.55 * edge * edge) * (baby ? 0.75 : 1);
      const m = clamp((th / Math.PI) * 0.8 - 0.14 + (R() - 0.5) * 0.14, 0, 0.64);
      const r = R();
      out.push({
        ru: CX + DA * Math.cos(th) * kk,
        rv: CY - 0.12 - (DB - 0.12) * Math.sin(th) * kk,
        rest: 0.85 + (th - 1.5708) * 0.2 + (R() - 0.5) * 0.06, // tumbuh naik-serong ke belakang // tersisir ke ekor, sedikit terangkat
        seg: total / n,
        n,
        a: new Float32Array(n),
        w: new Float32Array(n),
        ph: th * 1.7 + (R() - 0.5) * 0.14, // helai bertetangga hampir sefase → bergerak sebagai satu lembar
        lk: (hash(li, 7, seed) - 0.5) * 1.7,
        gain: 0.8 + 0.45 * hash(li, 9, seed),
        layer,
        cols: SILK_A.map((c, i) => mix(c, SILK_B[i], m)),
        base: (layer === 0 ? 0 : 0.07 + 0.03 * layer) + (r < 0.08 ? -0.1 : r > 0.9 ? 0.08 : (r - 0.5) * 0.05) + (baby ? 0.08 : 0) - 0.07 * edge * edge,
        span: layer === 0 ? 0.55 : 0.62,
        spark: R() < 0.22,
      });
    }
  });
  return out;
}

// ombak angin: kecepatan sudut, bilangan gelombang per ruas, dan rambatan melintasi surai (kepala → ekor)
const WV_W = 2.6;
const WV_K = 0.62;
const WV_X = 0.6;

// keluaran sementara (hindari alokasi)
let wx = 0;
let wy = 0;
let hcU = 0;
let hcV = 0;

export class Turtle {
  x: number;
  y: number;
  vx = 0;
  vy = 0;
  tx: number;
  ty: number;
  unit: number;
  dir = 1;
  facing = 1;
  pitch = 0;
  pitchV = 0;
  phase: number; // fase dayung
  effort = 0.2;
  neck = 0.3; // juluran leher 0..1
  headA = 0; // tengokan kepala (+ = menunduk)
  headV = 0;
  blinkT = 2;
  happy = 0;
  mouth = 0;
  wanderT = 0;
  idle = false;
  cool = 0;
  eaten = 0;
  name: string;
  baby: boolean;
  parent: Turtle | null = null;
  mode: 'free' | 'ride' = 'free';
  seed: number;
  strands: Strand[];
  la = new Float32Array(8); // sudut kaki: [atas, telapak] × 4
  lw = new Float32Array(8);
  hvx = 0; // kecepatan nyata yang dihaluskan (untuk aliran rambut)
  hvy = 0;
  cp = 1;
  sp = 0;
  fb = 1;
  private inited = false;
  id = 0;

  constructor(x: number, y: number, unit: number, name: string, baby: boolean, seed: number) {
    this.x = this.tx = x;
    this.y = this.ty = y;
    this.unit = unit;
    this.name = name;
    this.baby = baby;
    this.seed = seed;
    this.phase = seed % 6;
    this.strands = makeStrands(seed, baby);
    for (let j = 0; j < 4; j++) this.la[j * 2] = this.la[j * 2 + 1] = j % 2 === 0 ? 0.4 : -0.7;
  }

  /** Perbarui basis rotasi (pitch) & cermin (facing) */
  frame() {
    this.cp = Math.cos(this.pitch);
    this.sp = Math.sin(this.pitch);
    const m = Math.max(0.3, Math.abs(this.facing));
    this.fb = this.facing >= 0 ? m : -m;
  }

  /** lokal → dunia, hasil di wx/wy */
  toW(u: number, v: number, ox = this.x, oy = this.y) {
    wx = ox + this.fb * (u * this.cp - v * this.sp) * this.unit;
    wy = oy + (u * this.sp + v * this.cp) * this.unit;
  }

  headCenter() {
    const hl = 0.5 + 0.22 * this.neck;
    hcU = NBU + hl * Math.cos(this.headA);
    hcV = NBV + hl * Math.sin(this.headA);
  }

  /** posisi mulut di dunia, hasil di wx/wy */
  mouthW() {
    this.headCenter();
    const ct = Math.cos(this.headA);
    const st = Math.sin(this.headA);
    this.toW(hcU + 0.42 * ct - 0.1 * st, hcV + 0.42 * st + 0.1 * ct);
  }

  hit(x: number, y: number) {
    const dx = (x - this.x) / (1.75 * this.unit);
    const dy = (y - this.y + 0.3 * this.unit) / (1.5 * this.unit);
    return dx * dx + dy * dy < 1;
  }

  pet() {
    this.happy = 1.8;
  }

  // ------------------------------------------------------------------ update
  update(dt: number, env: TurtleEnv) {
    const U = this.unit;
    const t = env.time;
    this.happy = Math.max(0, this.happy - dt);
    this.mouth = Math.max(0, this.mouth - dt);
    this.cool = Math.max(0, this.cool - dt);
    this.blinkT -= dt;
    if (this.blinkT < -0.16) this.blinkT = 2 + Math.random() * 4;
    const ox = this.x;
    const oy = this.y;
    const x0 = Math.min(1.9 * U, env.W / 2);
    const x1 = env.W - x0;
    const y0 = 10 + 2.0 * U;
    const y1 = Math.max(y0 + 2, env.sandBase - 0.62 * U);

    // pelet terdekat (bayi hanya tertarik pelet yang dekat)
    let best: FoodLike | null = null;
    let bd = this.baby ? 78 : Math.max(env.W, env.H) * 0.75;
    for (const fd of env.food) {
      const d = Math.hypot(fd.x - this.x, fd.y - this.y);
      if (d < bd) {
        bd = d;
        best = fd;
      }
    }

    const p = this.parent;
    let rideX = 0;
    let rideY = 0;
    if (p) {
      p.frame();
      p.toW(-0.2, -0.98);
      rideX = wx;
      rideY = wy - 0.2 * U;
      if (this.mode === 'ride' && best && this.cool <= 0) {
        this.mode = 'free'; // loncat dari punggung induk untuk mengejar pelet
        this.vy -= 12;
      }
    }

    if (p && this.mode === 'ride') {
      // berpegangan: pegas teredam ke titik tumpu → ikut bergoyang saat induk bergerak
      const ddx = rideX - this.x;
      const ddy = rideY - this.y;
      if (ddx * ddx + ddy * ddy > 9 * U * U) {
        this.x = rideX;
        this.y = rideY;
        this.vx = p.vx;
        this.vy = p.vy;
      } else {
        this.vx += (ddx * 150 - (this.vx - p.vx) * 15) * dt;
        this.vy += (ddy * 150 - (this.vy - p.vy) * 15) * dt;
        this.x += this.vx * dt;
        this.y += this.vy * dt;
      }
      this.dir = p.dir;
      const lag = (this.vx - p.vx) * (this.facing >= 0 ? 1 : -1);
      const pt = clamp(p.pitch + clamp(lag * 0.045, -0.22, 0.22) + clamp((this.vy - p.vy) * 0.03, -0.12, 0.12), -0.6, 0.6);
      this.pitchV += ((pt - this.pitch) * 40 - this.pitchV * 7) * dt;
      this.effort += (0.1 - this.effort) * Math.min(1, dt * 3);
      this.phase += dt * (1.2 + (this.happy > 0 ? 6 : 0));
      this.neck += ((this.happy > 0 ? 0.7 : 0.3 + 0.1 * Math.sin(t * 0.8 + this.seed)) - this.neck) * Math.min(1, dt * 5);
      const tt = this.happy > 0 ? -0.25 : Math.sin(t * 0.6 + this.seed) * 0.18;
      this.headV += ((tt - this.headA) * 60 - this.headV * 10) * dt;
    } else {
      let tx: number;
      let ty: number;
      let sp: number;
      let acc: number;
      let ffx = 0;
      let ffy = 0;
      let urgent = false;
      if (best) {
        urgent = true;
        this.idle = false;
        // hadap ke pelet; zona mati supaya tidak bolak-balik saat pelet tepat di atas/bawah
        const dxf = best.x - this.x;
        if (Math.abs(dxf) > 1.1 * U) this.dir = dxf > 0 ? 1 : -1;
        // badan berhenti sejarak leher dari pelet → sudut makan tetap landai & natural
        tx = best.x - this.dir * 1.5 * U;
        ty = Math.min(best.y - 0.15 * U, y1);
        sp = this.baby ? 26 : 22;
        acc = 3.2;
      } else if (p) {
        // pulang ke punggung induk
        urgent = true;
        tx = rideX;
        ty = rideY;
        ffx = p.vx;
        ffy = p.vy;
        sp = 26;
        acc = 4;
        const dxp = tx - this.x;
        if (Math.abs(dxp) > U) this.dir = dxp > 0 ? 1 : -1;
        else this.dir = p.dir;
        if (Math.hypot(dxp, ty - this.y) < 3.5) {
          this.mode = 'ride';
          this.cool = 1.5;
          this.vx = p.vx;
          this.vy = p.vy;
        }
      } else {
        this.wanderT -= dt;
        if (this.wanderT <= 0) {
          this.idle = Math.random() < 0.25;
          if (this.idle) {
            this.tx = clamp(this.x + (Math.random() - 0.5) * 16, x0, x1);
            this.ty = clamp(this.y + (Math.random() - 0.5) * 10, y0, y1);
            this.wanderT = 2 + Math.random() * 3;
          } else {
            // lebih sering lanjut searah (jarang putar balik) supaya rambut panjangnya tetap tergerai
            const ahead = this.x + this.dir * (40 + Math.random() * 90);
            this.tx = Math.random() < 0.65 && ahead > x0 && ahead < x1 ? ahead : x0 + Math.random() * (x1 - x0);
            this.ty = y0 + (0.15 + 0.85 * Math.random()) * (y1 - y0);
            this.wanderT = 4 + Math.random() * 5;
          }
        }
        tx = this.tx;
        ty = this.ty;
        sp = this.idle ? 2.5 : 9;
        acc = 1.5;
      }

      const ddx = tx - this.x;
      const ddy = ty - this.y;
      const dist = Math.hypot(ddx, ddy) || 0.001;
      if (!urgent && dist < 4 && this.wanderT > 1.5) this.wanderT = 0.4 + Math.random();
      let s = sp * clamp(dist / (urgent ? 5 : 12), 0, 1);
      this.effort += (clamp(s / 22, 0.1, 1.15) - this.effort) * Math.min(1, dt * 3);
      this.phase += dt * (1.5 + 5.2 * this.effort + (this.happy > 0 ? 3 : 0));
      // dayung–meluncur: dorongan mengikuti kayuhan kaki
      const stroke = Math.max(0, Math.sin(this.phase - 0.4));
      s *= urgent ? 0.82 + 0.36 * stroke : 0.55 + 0.8 * stroke;
      const k = Math.min(1, acc * dt);
      this.vx += ((ddx / dist) * s + ffx - this.vx) * k;
      this.vy += ((ddy / dist) * s * 0.85 + ffy - this.vy) * k;
      if (this.x < x0) this.vx += (x0 - this.x) * 4 * dt;
      if (this.x > x1) this.vx -= (this.x - x1) * 4 * dt;
      if (this.y < y0) this.vy += (y0 - this.y) * 5 * dt;
      if (this.y > y1) this.vy -= (this.y - y1) * 9 * dt;
      this.x += this.vx * dt;
      this.y += this.vy * dt;
      if (!urgent && Math.abs(this.vx) > 1.6) this.dir = this.vx > 0 ? 1 : -1;

      // kemiringan badan: ikut arah renang; saat makan diarahkan ke pelet tapi dibatasi (tidak jungkir)
      let pt = clamp(this.vy * 0.036, -0.36, 0.36);
      if (best) pt = clamp(Math.atan2(best.y - this.y, Math.max(Math.abs(best.x - this.x), 1.5 * U)) * 0.7, -0.4, 0.4);
      pt += Math.sin(this.phase) * 0.035 * this.effort;
      this.pitchV += ((pt - this.pitch) * 30 - this.pitchV * 8.5) * dt;

      // kepala & leher: menengok dan menjulur ke pelet
      let tt = this.happy > 0 ? -0.25 : Math.sin(t * 0.6 + this.seed) * 0.14;
      let nt = this.happy > 0 ? 0.7 : 0.28 + 0.08 * Math.sin(t * 0.9 + this.seed);
      if (best) {
        this.frame();
        const X = (best.x - this.x) / this.fb;
        const Y = best.y - this.y;
        const fu = (X * this.cp + Y * this.sp) / U;
        const fv = (-X * this.sp + Y * this.cp) / U;
        tt = clamp(Math.atan2(fv - NBV, Math.max(0.4, fu - NBU)), -0.65, 0.65);
        this.mouthW();
        const md = Math.hypot(best.x - wx, best.y - wy);
        nt = md < 3 * U ? 1 : 0.45;
        if (md < (best.rest ? 1.0 * U : 0.5 * U + 2)) {
          env.eat(best);
          this.eaten++;
          this.happy = Math.max(this.happy, 1.1);
          this.mouth = 0.7;
          env.heart(wx, wy - 1.3 * U, !this.baby);
        }
      }
      this.headV += ((tt - this.headA) * 60 - this.headV * 10) * dt;
      this.neck += (nt - this.neck) * Math.min(1, dt * 6);
    }

    this.pitchV = clamp(this.pitchV, -6, 6);
    this.pitch = clamp(this.pitch + this.pitchV * dt, -0.6, 0.6);
    this.headV = clamp(this.headV, -8, 8);
    this.headA = clamp(this.headA + this.headV * dt, -0.8, 0.8);
    this.facing += clamp(this.dir - this.facing, -dt * 5, dt * 5);
    this.frame();

    if (Math.random() < dt * 0.12) {
      this.mouthW();
      env.bubble(wx, wy - 1, Math.random() < 0.7 ? 0 : 1);
    }

    const sm = Math.min(1, dt * 10);
    this.hvx += ((this.x - ox) / dt - this.hvx) * sm;
    this.hvy += ((this.y - oy) / dt - this.hvy) * sm;

    this.updateLimbs(dt, t);
    this.updateHair(dt, t);

    // "pearling": gelembung oksigen mungil lepas dari ujung alga
    if (Math.random() < dt * (this.baby ? 0.1 : 0.4)) {
      const s = this.strands[(Math.random() * this.strands.length) | 0];
      this.toW(s.ru, s.rv);
      let x = wx;
      let y = wy;
      for (let i = 0; i < s.n; i++) {
        x += Math.sin(s.a[i]) * s.seg * U * this.fb;
        y -= Math.cos(s.a[i]) * s.seg * U;
      }
      env.bubble(x, y, 0);
    }
  }

  /** Kaki mendayung: ruas atas mengejar target, telapak menyusul terlambat (follow-through) */
  private updateLimbs(dt: number, t: number) {
    const ride = this.mode === 'ride' && this.parent !== null;
    const amp = 0.3 + 0.7 * Math.min(1, this.effort);
    for (let j = 0; j < 4; j++) {
      const front = j % 2 === 0;
      const ph = this.phase + (j >= 2 ? 0 : Math.PI) + (front ? 0 : 2.4);
      let tgt: number;
      if (ride) tgt = (front ? 0.8 : -0.5) + Math.sin(t * 1.4 + j * 1.7) * 0.1 + (this.happy > 0 ? Math.sin(ph * 2) * 0.4 : 0);
      else tgt = front ? 0.35 + amp * 0.95 * Math.sin(ph) : -0.8 + amp * 0.6 * Math.sin(ph);
      const i = j * 2;
      this.lw[i] += ((tgt - this.la[i]) * 110 - this.lw[i] * 13) * dt;
      this.la[i] += this.lw[i] * dt;
      const tf = this.la[i] - this.lw[i] * 0.06;
      this.lw[i + 1] += ((tf - this.la[i + 1]) * 60 - this.lw[i + 1] * 7) * dt;
      this.la[i + 1] += this.lw[i + 1] * dt;
    }
  }

  /**
   * Rambut alga = rantai ruas dengan pegas sudut (ruang dunia). Ruas pangkal mengejar arah
   * "tumbuh + arus", ruas berikutnya menyusul ruas sebelumnya → gelombang merambat ke ujung.
   *
   * Anti-anomali: arah arus selalu dijaga punya komponen ke luar tempurung (minUp). Tanpa ini,
   * saat kura-kura naik arus menunjuk lurus ke bawah, sudutnya melompat antara +π dan −π, dan
   * rambut berkedip/menembus badan. Dengan ini rambut hanya rebah menempel di punggung.
   */
  private updateHair(dt: number, t: number) {
    const cp = this.cp;
    const sp = this.sp;
    // Rambut disimulasikan di kerangka kura-kura (seolah selalu menghadap kanan; ekor = −x), lalu
    // digambar ikut cermin & pipih badannya. Saat kura-kura berbalik, rambut tampak memendek lalu
    // memanjang ke sisi baru (seperti berputar 3D) — tidak pernah harus melewati posisi tegak.
    const sgn = this.facing >= 0 ? 1 : -1;
    const ux = sp; // sumbu "atas" lokal
    const uy = -cp;
    // ANGIN: hembusan yang menguat lalu melemah. Saat menguat, rambut merentang ke belakang dan
    // ombaknya membesar; saat melemah, rambut mengendur dan melayang naik. Laju renang menambah angin.
    const gust = 0.55 + 0.3 * Math.sin(t * 0.62 + this.seed) + 0.15 * Math.sin(t * 1.63 + this.seed * 2.1);
    const wind = clamp(gust * 0.8 + Math.min(1, Math.hypot(this.hvx, this.hvy) / 18) * 0.55, 0.2, 1.25);
    // dorongan ke arah kepala (+0.25), ke atas (−0.45) dan ke bawah (+0.5) dibatasi → tidak njabrik, tidak rebah turun
    const fx = clamp(-this.hvx * sgn * 0.065, -2.2, 0.25) - 0.36 - 0.34 * gust;
    const fy = clamp(-this.hvy * 0.05, -0.45, 0.1) - 0.33 + 0.12 * gust;
    const cph = Math.cos(this.pitch * 0.4);
    const sph = Math.sin(this.pitch * 0.4);
    const first = !this.inited;
    this.inited = true;
    for (const s of this.strands) {
      const du = -Math.sin(s.rest);
      const dv = -Math.cos(s.rest);
      const rx = du * cph - dv * sph;
      const ry = du * sph + dv * cph;
      let gx = rx + fx * 0.8;
      let gy = ry + fy * 0.8;
      let gu = gx * ux + gy * uy;
      if (gu < 0.3) {
        gx += (0.3 - gu) * ux;
        gy += (0.3 - gu) * uy;
      }
      const aRoot = Math.atan2(gx, -gy);
      gx = rx * 0.4 + fx * 1.2;
      gy = ry * 0.4 + fy * 1.2;
      gu = gx * ux + gy * uy;
      if (gu < 0.2) {
        gx += (0.2 - gu) * ux;
        gy += (0.2 - gu) * uy;
      }
      const aTip = Math.atan2(gx, -gy);
      const n = s.n;
      for (let i = 0; i < n; i++) {
        const m = i / (n - 1);
        // arah dasar: dari arah tumbuh di pangkal, melengkung halus mengikuti arah angin
        const flow = aRoot + (aTip - aRoot) * (1 - (1 - m) * (1 - m));
        if (first) {
          s.a[i] = flow;
          s.w[i] = 0;
          continue;
        }
        const tgt =
          flow +
          // ombak besar yang berjalan dari pangkal ke ujung, dan dari sisi kepala ke sisi ekor
          (0.08 + 0.76 * Math.pow(m, 1.2)) * wind * s.gain * Math.sin(t * WV_W - i * WV_K - s.ph * WV_X + s.lk) +
          // kibasan kecil & cepat di ujung rambut
          0.2 * m * m * Math.sin(t * 5.4 - i * 1.4 + s.lk * 3 - s.ph);
        // pangkal kaku, ujung lentur & ringan → ujung menyusul terlambat lalu sedikit melecut
        const w = clamp(s.w[i] + ((tgt - s.a[i]) * (62 - 44 * m) - s.w[i] * (9 - 4.4 * m)) * dt, -9, 9);
        s.w[i] = w;
        s.a[i] = clamp(s.a[i] + w * dt, -2.9, 2.9);
      }
    }
  }

  /** Pose diam seketika (dipakai ikon): rambut langsung tergerai di posisi alaminya */
  settle() {
    this.frame();
    this.inited = false;
    this.updateHair(0.016, 0);
  }
}

// ====================================================================== render
let gB: Uint32Array = new Uint32Array(1);
let gW = 1;
let gH = 1;
let gT: RGB = [0, 0, 0];
let gTa = 0;

function plot(x: number, y: number, c: RGB, a: number) {
  if (x < 0 || x >= gW || y < 0 || y >= gH) return;
  blend(gB, y * gW + x, c[0] + (gT[0] - c[0]) * gTa, c[1] + (gT[1] - c[1]) * gTa, c[2] + (gT[2] - c[2]) * gTa, a);
}

/** kapsul terisi; ring = hanya garis tepi 1 piksel di luar radius */
function capsule(x0: number, y0: number, x1: number, y1: number, r: number, c: RGB, ring: boolean) {
  const R = ring ? r + 1 : r;
  const xa = Math.floor(Math.min(x0, x1) - R);
  const xb = Math.ceil(Math.max(x0, x1) + R);
  const ya = Math.floor(Math.min(y0, y1) - R);
  const yb = Math.ceil(Math.max(y0, y1) + R);
  const dx = x1 - x0;
  const dy = y1 - y0;
  const l2 = dx * dx + dy * dy || 1e-6;
  for (let y = ya; y <= yb; y++) {
    for (let x = xa; x <= xb; x++) {
      const k = clamp(((x - x0) * dx + (y - y0) * dy) / l2, 0, 1);
      const ex = x - x0 - dx * k;
      const ey = y - y0 - dy * k;
      if (ex * ex + ey * ey <= R * R) plot(x, y, c, ring ? 0.85 : 1);
    }
  }
}

/**
 * Tangan & kaki mungil: lengan pendek + telapak bulat gemuk ("sarung tangan") dengan kuku kecil
 * krem di ujungnya. Kuku ditaruh tepat di garis tepi telapak sehingga terbaca sebagai jari.
 */
function pxLine(x0: number, y0: number, x1: number, y1: number, c: RGB) {
  const n = Math.max(1, Math.ceil(Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0))));
  for (let k = 0; k <= n; k++) plot(Math.round(x0 + ((x1 - x0) * k) / n), Math.round(y0 + ((y1 - y0) * k) / n), c, 1);
}

function drawLimbs(t: Turtle, from: number, ox: number, oy: number) {
  const U = t.unit;
  const near = from >= 2;
  const r1 = Math.max(0.9, 0.15 * U);
  const r2 = Math.max(1.2, 0.2 * U);
  const pts: number[] = [];
  for (let j = from; j < from + 2; j++) {
    t.toW(PIV[j * 2], PIV[j * 2 + 1], ox, oy);
    let x = wx;
    let y = wy;
    pts.push(x, y);
    for (let sgm = 0; sgm < 2; sgm++) {
      const b = t.la[j * 2 + sgm];
      const du = Math.sin(b);
      const dv = Math.cos(b);
      const L = (sgm === 0 ? 0.19 : 0.2) * U;
      x += t.fb * (du * t.cp - dv * t.sp) * L;
      y += (du * t.sp + dv * t.cp) * L;
      pts.push(x, y);
    }
  }
  for (let pass = 0; pass < 2; pass++) {
    for (let j = 0; j < 2; j++) {
      const o = j * 6;
      const ring = pass === 0;
      capsule(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], r1, ring ? LINE : SKIN[near ? 2 : 3], ring);
      capsule(pts[o + 2], pts[o + 3], pts[o + 4], pts[o + 5], r2, ring ? LINE : SKIN[near ? 1 : 2], ring);
    }
  }
  // garis kuning khas di lengan & kaki
  if (U >= 10) {
    const sc = near ? YEL : YEL_FAR;
    for (let j = 0; j < 2; j++) {
      const o = j * 6;
      pxLine(pts[o], pts[o + 1], pts[o + 2], pts[o + 3], sc);
      pxLine(pts[o + 2], pts[o + 3], (pts[o + 2] + pts[o + 4]) / 2, (pts[o + 3] + pts[o + 5]) / 2, sc);
    }
  }
  // kilau telapak + kuku
  const nClaw = U >= 10 ? 3 : 2;
  const spread = Math.max(2, r2 * 0.8);
  const rr = r2 + 0.8;
  const claw = near ? CLAW : CLAW_FAR;
  for (let j = 0; j < 2; j++) {
    const o = j * 6;
    const ex = pts[o + 4];
    const ey = pts[o + 5];
    let dx = ex - pts[o + 2];
    let dy = ey - pts[o + 3];
    const l = Math.hypot(dx, dy) || 1;
    dx /= l;
    dy /= l;
    if (near && r2 >= 2) plot(Math.round(ex - 1), Math.round(ey - 1), SKIN[0], 0.75);
    for (let k = 0; k < nClaw; k++) {
      const off = (k - (nClaw - 1) / 2) * spread;
      const fwd = Math.sqrt(Math.max(0, rr * rr - off * off));
      plot(Math.round(ex + dx * fwd - dy * off), Math.round(ey + dy * fwd + dx * off), claw, 1);
      if (U >= 12) plot(Math.round(ex + dx * (fwd + 1) - dy * off * 1.15), Math.round(ey + dy * (fwd + 1) + dx * off * 1.15), claw, 1);
    }
  }
}

const PX = new Float32Array(12);
const PY = new Float32Array(12);

/**
 * Tiap helai digambar sebagai kurva Catmull-Rom yang melewati sendi-sendinya (tanpa patahan),
 * tebal di pangkal dan menipis–memudar di ujung. Pita kilau bergeser pelan sepanjang helai dan
 * sefase dengan helai tetangganya, sehingga cahaya tampak meluncur di atas kain sutra.
 */
function drawStrands(t: Turtle, back: boolean, ox: number, oy: number, time: number) {
  const U = t.unit;
  const thickTo = t.baby ? 0.3 : 0.52;
  for (const s of t.strands) {
    if ((s.layer === 0) !== back) continue;
    const n = s.n;
    const L = s.seg * U;
    t.toW(s.ru, s.rv, ox, oy);
    PX[0] = wx;
    PY[0] = wy;
    for (let i = 0; i < n; i++) {
      PX[i + 1] = PX[i] + Math.sin(s.a[i]) * L * t.fb; // ikut cermin & pipih badan
      PY[i + 1] = PY[i] - Math.cos(s.a[i]) * L;
    }
    const cols = s.cols;
    const nc = cols.length;
    const sheen = ((time * 0.36 + s.ph * 0.16) % 1.4) - 0.2; // pita cahaya naik berulang-ulang
    const steps = Math.max(2, Math.ceil(L * 1.4));
    let lx = -999;
    let ly = -999;
    for (let i = 0; i < n; i++) {
      const i0 = i > 0 ? i - 1 : 0;
      const i3 = i + 2 <= n ? i + 2 : n;
      const x0 = PX[i0];
      const x1 = PX[i];
      const x2 = PX[i + 1];
      const x3 = PX[i3];
      const y0 = PY[i0];
      const y1 = PY[i];
      const y2 = PY[i + 1];
      const y3 = PY[i3];
      const steep = Math.abs(y2 - y1) > Math.abs(x2 - x1);
      for (let k = 0; k < steps; k++) {
        const f = k / steps;
        const f2 = f * f;
        const f3 = f2 * f;
        const px = Math.round(0.5 * (2 * x1 + (x2 - x0) * f + (2 * x0 - 5 * x1 + 4 * x2 - x3) * f2 + (3 * x1 - x0 - 3 * x2 + x3) * f3));
        const py = Math.round(0.5 * (2 * y1 + (y2 - y0) * f + (2 * y0 - 5 * y1 + 4 * y2 - y3) * f2 + (3 * y1 - y0 - 3 * y2 + y3) * f3));
        if (px === lx && py === ly) continue;
        lx = px;
        ly = py;
        const tl = (i + f) / n;
        const ds = (tl - sheen) / 0.14;
        // pita kilau + lipatan terang-gelap yang berjalan melintasi surai (seperti kain sutra tertiup)
        // punggung ombak menangkap cahaya, lembahnya lebih gelap → ombak terbaca sebagai lekuk rambut
        const tone =
          s.base +
          tl * s.span +
          (back ? 0.06 : 0.14) * Math.exp(-ds * ds) +
          (back ? 0.5 : 1) * (0.03 + 0.17 * tl) * Math.sin(time * WV_W - tl * n * WV_K - s.ph * WV_X + s.lk + 1.1);
        const c = cols[dither(nc, tone, px, py, 0.4)];
        plot(px, py, c, tl > 0.86 ? 0.68 : 1);
        if (tl < thickTo) plot(steep ? px + 1 : px, steep ? py : py + 1, c, 1);
      }
    }
    // kerlip cahaya di ujung beberapa helai
    if (s.spark && !back) {
      const tw = Math.sin(time * 2.3 + s.ph * 7);
      if (tw > 0.9) {
        const tx = Math.round(PX[n]);
        const ty = Math.round(PY[n]);
        plot(tx, ty, WHITE, 0.95);
        if (tw > 0.97) {
          plot(tx - 1, ty, WHITE, 0.45);
          plot(tx + 1, ty, WHITE, 0.45);
          plot(tx, ty - 1, WHITE, 0.45);
          plot(tx, ty + 1, WHITE, 0.45);
        }
      }
    }
  }
}

// ---------- sprite badan (tempurung, leher, kepala, ekor) ----------
const SPR = 99;
const sR = new Uint8ClampedArray(SPR * SPR);
const sG = new Uint8ClampedArray(SPR * SPR);
const sB = new Uint8ClampedArray(SPR * SPR);
const sK = new Uint8Array(SPR * SPR);

// Mata kura-kura telinga merah: iris kuning-hijau (Y/G), pupil hitam (K) dengan garis hitam
// melintang yang menembus kedua sisi iris, plus satu kilau putih (W).
// D = lanjutan garis gelap di luar iris, sehingga terbaca sebagai garis yang menembus mata.
const EYE_L = ['  GYG  ', ' YWKKY ', 'DKKKKKD', ' YKKKY ', '  GYG  '];
const EYE_S = ['GYG', 'WKK', 'GYG'];
const HAPPY_L = ['       ', '  KKK  ', ' K   K '];
const HAPPY_S = ['   ', ' K ', 'K K'];
const BLINK_L = ['       ', '       ', ' KKKKK '];
const BLINK_S = ['   ', 'KKK'];
const EYE_A = 0.1; // posisi mata di koordinat kepala
const EYE_B = -0.07;

let qInv = 0.07;
let qCt = 1;
let qSt = 0;
let qSeed = 0;
let qYoung = 0;
let oC: RGB = SKIN[0];
let oOk = false;

function segDist2(u: number, v: number, x0: number, y0: number, x1: number, y1: number) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const k = clamp(((u - x0) * dx + (v - y0) * dy) / (dx * dx + dy * dy), 0, 1);
  const ex = u - x0 - dx * k;
  const ey = v - y0 - dy * k;
  return ex * ex + ey * ey;
}

function sampleBody(u: number, v: number, px: number, py: number) {
  oOk = false;
  if (u < -1.45 || u > 2.2 || v < -0.75 || v > 1.3) return;

  // --- kepala: bulat besar + moncong kecil. Corak dihitung per BARIS piksel relatif terhadap
  //     baris garis mata (rb), supaya garis kuning selalu tepat 1 piksel & sejajar dengan mata ---
  const hx = u - hcU;
  const hy = v - hcV;
  const a = hx * qCt + hy * qSt;
  const b = -hx * qSt + hy * qCt;
  let inHead = (a * a) / 0.16 + (b * b) / 0.1089 < 1;
  if (!inHead) {
    const sx = a - 0.32;
    const sy = b - 0.05;
    inHead = sx * sx + sy * sy < 0.0324;
  }
  if (inHead) {
    oOk = true;
    const tiny = qInv > 0.09;
    const rb = (b - EYE_B) / qInv;
    const chinRow = tiny ? 1.5 : 3.5;
    if (rb > chinRow) {
      // dagu & rahang kuning cerah
      oC = CHIN[dither(4, 0.06 + 1.5 * (b - EYE_B - chinRow * qInv), px, py, 0.6)];
      return;
    }
    if (a < -0.1 && a > -0.38 && rb >= -1.5 && rb < 0.5) {
      // bercak merah di belakang mata ("telinga merah")
      oC = RED[rb < -0.5 ? 0 : 1];
      return;
    }
    const stripe =
      (!tiny && rb >= 1.5 && rb < 2.5 && a < -0.14) || // pipi: dari belakang mata ke leher
      (rb >= 0.5 && rb < 1.5 && a > 0.24) || // moncong, di bawah garis mata
      (rb >= -1.5 && rb < -0.5 && a > 0.24) || // moncong, di atas garis mata
      (rb >= -3.5 && rb < -2.5 && a < -0.12); // ubun-ubun belakang
    if (stripe) {
      oC = a > 0.36 ? YEL_D : YEL;
      return;
    }
    oC = SKIN[dither(5, 0.3 + 0.9 * (b + 0.25), px, py, 0.6)];
    return;
  }

  // --- tempurung: kubah berlumut + pinggiran bersisik + plastron kuning ---
  const nx = (u - CX) / DA;
  if (v < CY) {
    const ny = (v - CY) / DB;
    if (nx * nx + ny * ny < 1) {
      if (v > CY - 0.15) {
        const sc = (u + 3) * 2.6;
        let tn = 0.12 + 0.5 * ((v - (CY - 0.15)) / 0.15);
        if (sc - Math.floor(sc) < qInv * 2.6) tn += 0.42; // sekat sisik pinggir
        oC = RIM[dither(4, tn, px, py, 0.6)];
      } else {
        const tn = 0.08 - qYoung + 0.66 * Math.pow(1 + ny, 1.2) + (hash(Math.floor(u / qInv), Math.floor(v / qInv), qSeed) - 0.5) * 0.24;
        oC = MOSS[dither(5, tn, px, py, 0.7)];
      }
      oOk = true;
      return;
    }
  } else {
    const mx = (u - CX) / PA;
    const my = (v - CY) / PB;
    if (mx * mx + my * my < 1) {
      oC = PLAS[dither(4, 0.1 + 0.75 * my, px, py, 0.6)];
      oOk = true;
      return;
    }
  }

  // --- leher: hijau tua, satu garis kuning memanjang, tenggorokan kuning ---
  if (u > 0.5) {
    const x0 = NBU - 0.1;
    if (segDist2(u, v, x0, NBV, hcU, hcV) < 0.0361) {
      const dx = hcU - x0;
      const dy = hcV - NBV;
      const d = ((v - NBV) * dx - (u - x0) * dy) / Math.sqrt(dx * dx + dy * dy); // + = sisi bawah
      if (d > 0.06) oC = CHIN[dither(4, 0.3 + 2 * (d - 0.06), px, py, 0.6)];
      else if (d > -0.09 && d <= -0.09 + qInv) oC = YEL;
      else oC = SKIN[dither(5, 0.5 + 1.2 * d, px, py, 0.6)];
      oOk = true;
      return;
    }
  }
  // --- ekor mungil ---
  if (u < -0.85 && segDist2(u, v, -0.95, 0.24, -1.3, 0.36) < 0.0064) {
    oC = SKIN[3];
    oOk = true;
  }
}

function drawBody(t: Turtle, ox: number, oy: number) {
  const U = t.unit;
  const inv = 1 / U;
  const hw = Math.min((SPR - 1) >> 1, Math.ceil(2.25 * U) + 2);
  const sw = hw * 2 + 1;
  const cp = t.cp;
  const sp = t.sp;
  const fb = t.fb;
  const sgn = fb >= 0 ? 1 : -1;
  t.headCenter();
  qInv = inv;
  qCt = Math.cos(t.headA);
  qSt = Math.sin(t.headA);
  qSeed = t.seed;
  qYoung = t.baby ? 0.14 : 0;

  for (let j = 0; j < sw; j++) {
    const Y = (j - hw) * inv;
    for (let i = 0; i < sw; i++) {
      const X = ((i - hw) * inv) / fb;
      sampleBody(X * cp + Y * sp, -X * sp + Y * cp, i, j);
      const idx = j * sw + i;
      if (oOk) {
        sK[idx] = 2;
        sR[idx] = oC[0];
        sG[idx] = oC[1];
        sB[idx] = oC[2];
      } else sK[idx] = 0;
    }
  }

  // wajah (koordinat kepala → sprite)
  const hx = (a: number, b: number) => Math.round(fb * ((hcU + a * qCt - b * qSt) * cp - (hcV + a * qSt + b * qCt) * sp) * U) + hw;
  const hy = (a: number, b: number) => Math.round(((hcU + a * qCt - b * qSt) * sp + (hcV + a * qSt + b * qCt) * cp) * U) + hw;
  const set = (x: number, y: number, c: RGB, al: number) => {
    if (x < 0 || x >= sw || y < 0 || y >= sw) return;
    const idx = y * sw + x;
    if (sK[idx] !== 2) return;
    sR[idx] += (c[0] - sR[idx]) * al;
    sG[idx] += (c[1] - sG[idx]) * al;
    sB[idx] += (c[2] - sB[idx]) * al;
  };
  if (Math.abs(t.facing) > 0.5) {
    const big = U >= 11;
    // rona pipi (di atas rahang kuning → jadi rona persik)
    const bx = hx(0.0, 0.2);
    const by = hy(0.0, 0.2);
    set(bx, by, BLUSH, 0.6);
    if (big) set(bx - sgn, by, BLUSH, 0.6);
    // mulut tersenyum: garis gelap di atas rahang kuning, sudutnya naik satu piksel
    const mrow = EYE_B + (big ? 3 : 1) * inv;
    const mlen = big ? 3 : 1;
    for (let k = 0; k < mlen; k++) set(hx(0.46 - k * inv, mrow), hy(0.46 - k * inv, mrow), LINE, 0.8);
    if (big) set(hx(0.46 - mlen * inv, mrow - inv), hy(0.46 - mlen * inv, mrow - inv), LINE, 0.65);
    if (t.mouth > 0) set(hx(0.46, mrow + inv), hy(0.46, mrow + inv), LINE, 0.85); // mulut terbuka saat makan
    // mata: iris kuning-hijau dengan garis hitam melintang
    const eye = t.happy > 0 ? (big ? HAPPY_L : HAPPY_S) : t.blinkT < 0 ? (big ? BLINK_L : BLINK_S) : big ? EYE_L : EYE_S;
    const n = eye[0].length;
    const ex = hx(EYE_A, EYE_B) - (n >> 1);
    const ey = hy(EYE_A, EYE_B) - (big ? 2 : 1);
    for (let j = 0; j < eye.length; j++) {
      for (let i = 0; i < n; i++) {
        const ch = eye[j][i];
        if (ch === ' ') continue;
        set(ex + (sgn < 0 ? n - 1 - i : i), ey + j, ch === 'W' ? WHITE : ch === 'Y' ? IRIS_Y : ch === 'G' ? IRIS_G : ch === 'D' ? SKIN[4] : EYE, 1);
      }
    }
  }

  // komposit + garis tepi lembut
  const x0 = ox - hw;
  const y0 = oy - hw;
  for (let j = 0; j < sw; j++) {
    const Y = y0 + j;
    if (Y < 0 || Y >= gH) continue;
    for (let i = 0; i < sw; i++) {
      const X = x0 + i;
      if (X < 0 || X >= gW) continue;
      const idx = j * sw + i;
      let r: number;
      let g: number;
      let b: number;
      let al = 1;
      if (sK[idx]) {
        r = sR[idx];
        g = sG[idx];
        b = sB[idx];
      } else {
        let n = -1;
        if (i > 0 && sK[idx - 1]) n = idx - 1;
        else if (i < sw - 1 && sK[idx + 1]) n = idx + 1;
        else if (j > 0 && sK[idx - sw]) n = idx - sw;
        else if (j < sw - 1 && sK[idx + sw]) n = idx + sw;
        if (n < 0) continue;
        r = sR[n] * 0.36 + 14;
        g = sG[n] * 0.32 + 10;
        b = sB[n] * 0.4 + 34;
        al = 0.9;
      }
      blend(gB, Y * gW + X, r + (gT[0] - r) * gTa, g + (gT[1] - g) * gTa, b + (gT[2] - b) * gTa, al);
    }
  }
}

const bobOf = (t: Turtle, time: number) =>
  Math.sin(time * 1.3 + t.seed) * 0.9 + (t.happy > 0 ? -Math.abs(Math.sin(t.happy * 9)) * 1.8 * Math.min(1, t.happy * 2) : 0);

export function drawTurtle(buf: Uint32Array, W: number, H: number, t: Turtle, time: number, tint: RGB, tintAmt: number) {
  gB = buf;
  gW = W;
  gH = H;
  gT = tint;
  gTa = tintAmt;
  t.frame();
  // bayi yang menumpang ikut naik-turun bersama induknya
  let bob = bobOf(t, time);
  if (t.parent && t.mode === 'ride') bob = bobOf(t.parent, time) + (t.happy > 0 ? bob - Math.sin(time * 1.3 + t.seed) * 0.9 : 0);
  const ox = Math.round(t.x);
  const oy = Math.round(t.y + bob);
  drawLimbs(t, 0, ox, oy); // kaki sisi jauh
  drawStrands(t, true, ox, oy, time); // alga lapis belakang (siluet surai)
  drawBody(t, ox, oy);
  drawLimbs(t, 2, ox, oy); // kaki sisi dekat
  drawStrands(t, false, ox, oy, time); // baris-baris alga depan
}

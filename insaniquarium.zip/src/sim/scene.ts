// Latar akuarium statis (air, bukit jauh, pasir, batu, karang) + data tanaman.

import { RGB, clamp, dither, hash, hex, mix, packRGB, ramp, rng, vnoise } from './palette';

export interface Theme {
  id: string;
  name: string;
  water: RGB[]; // 7 tone, atas → bawah
  ray: RGB;
  rayAmt: number;
  sand: RGB[]; // 5 tone
  sky: RGB;
  tint: RGB;
  tintAmt: number;
  glow: boolean;
  swatch: [string, string, string];
}

export const THEMES: Theme[] = [
  {
    id: 'siang',
    name: 'Siang',
    water: ramp('#b9f6e6', '#84e5df', '#56c8de', '#3da3d9', '#3c7dce', '#4260b6', '#3b4592'),
    ray: hex('#f6fff0'),
    rayAmt: 0.17,
    sand: ramp('#fff4d6', '#fbdeb2', '#eebf96', '#d09a86', '#a1757d'),
    sky: hex('#effff8'),
    tint: hex('#ffffff'),
    tintAmt: 0,
    glow: false,
    swatch: ['#b9f6e6', '#3da3d9', '#3b4592'],
  },
  {
    id: 'senja',
    name: 'Senja',
    water: ramp('#ffe3b4', '#ffc2a4', '#fb9bac', '#d87fc0', '#a06bc6', '#6c57b0', '#483e8a'),
    ray: hex('#fff2cc'),
    rayAmt: 0.18,
    sand: ramp('#ffe8ce', '#f9c7ae', '#e4a19d', '#ba7c95', '#875a8b'),
    sky: hex('#fff4d6'),
    tint: hex('#ff9ab8'),
    tintAmt: 0.09,
    glow: false,
    swatch: ['#ffe3b4', '#d87fc0', '#483e8a'],
  },
  {
    id: 'malam',
    name: 'Malam',
    water: ramp('#3a5aa2', '#2e4990', '#263a7e', '#202d6a', '#1c2458', '#181c48', '#131438'),
    ray: hex('#b4d0ff'),
    rayAmt: 0.13,
    sand: ramp('#979bd0', '#767ab6', '#5a5e9c', '#444784', '#32346a'),
    sky: hex('#6484c8'),
    tint: hex('#3848a4'),
    tintAmt: 0.24,
    glow: true,
    swatch: ['#3a5aa2', '#202d6a', '#131438'],
  },
];

export interface Scene {
  bg: Uint32Array;
  sandTop: Int16Array;
  sandBase: number;
  emitters: { x: number; y: number }[];
}

const ROCK = ramp('#c9b8e6', '#9e8fcc', '#7767b0', '#56498f', '#3d3670');
const MOSS = ramp('#b8f0a0', '#6fd08a', '#3fa07c');
const CORALS = [
  ramp('#ffd0dc', '#ff9cb8', '#ea6c9c', '#b84c8a'),
  ramp('#ffe6a8', '#ffc06c', '#f08c50', '#b85c50'),
  ramp('#e2d0ff', '#b89cf4', '#8a6cd4', '#5c489c'),
];
const PEBBLES = [
  ramp('#f4ecff', '#c4b4e0', '#8c7cb4'),
  ramp('#fff0e0', '#f0c0a4', '#b88484'),
  ramp('#e4fff0', '#a4dcc4', '#6c9ca0'),
];

const STAR = ['...a...', '..aba..', 'aabbbaa', '.abbba.', '.ab.ba.', 'aa...aa'];
const SHELL = ['.abab.', 'ababab', 'ababab', '.bbbb.', '..cc..'];

export function buildScene(W: number, H: number, th: Theme): Scene {
  const bg = new Uint32Array(W * H);
  const sandTop = new Int16Array(W);
  const sandH = Math.max(20, Math.round(H * 0.13));
  const sandBase = H - sandH;
  const nW = th.water.length;
  const wcol = th.water.map(packRGB);
  const tc = (c: RGB) => packRGB(mix(c, th.tint, th.tintAmt * 1.35));
  const R = rng(7);

  const depth = (x: number, y: number) => {
    const vx = x / W - 0.5;
    return y / (H * 0.94) + vx * vx * 0.24 - 0.03;
  };
  const put = (x: number, y: number, c: number) => {
    if (x >= 0 && x < W && y >= 0 && y < H) bg[y * W + x] = c;
  };

  // air: gradasi vertikal ber-dither
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) bg[y * W + x] = wcol[dither(nW, depth(x, y), x, y, 0.62)];
  }

  // siluet bukit & rumput jauh (satu tone lebih gelap dari air)
  const hillY = (x: number) =>
    Math.round(
      sandBase - 5 - H * 0.045 * (1 + Math.sin(x * 0.019 + 1.1)) - 2.5 * (Math.sin(x * 0.051 + 0.3) + 1) - vnoise(x * 0.08, 0, 3) * 6,
    );
  const farCol = (x: number, y: number) => wcol[Math.min(nW - 1, dither(nW, depth(x, y) + 0.02, x, y, 0.62) + 1)];
  for (let x = 0; x < W; x++) {
    for (let y = hillY(x); y < H; y++) put(x, y, farCol(x, y));
  }
  const nFar = Math.round(W / 13);
  for (let k = 0; k < nFar; k++) {
    const x = Math.round(R() * W);
    const h = 10 + R() * H * 0.2;
    const ph = R() * 6;
    const y0 = hillY(clamp(x, 0, W - 1));
    for (let i = 0; i < h; i++) {
      const xx = Math.round(x + Math.sin(i * 0.17 + ph) * 2.5);
      put(xx, y0 - i, farCol(xx, y0 - i));
      if (i < h * 0.6) put(xx + 1, y0 - i, farCol(xx + 1, y0 - i));
    }
  }

  // pasir
  const sand = th.sand.map(packRGB);
  for (let x = 0; x < W; x++) {
    sandTop[x] = Math.round(sandBase + Math.sin(x * 0.033 + 0.6) * 2.4 + Math.sin(x * 0.094 + 2.1) * 1.1);
    for (let y = sandTop[x]; y < H; y++) {
      const d = y - sandTop[x];
      const t = (d / (sandH + 4)) * 0.75 + (vnoise(x * 0.15, y * 0.3, 5) - 0.5) * 0.25 + 0.08;
      let idx = d === 0 ? 0 : dither(5, t, x, y, 0.9);
      const hsh = hash(x, y, 9);
      if (hsh > 0.965) idx = Math.min(4, idx + 1);
      else if (hsh < 0.02) idx = Math.max(0, idx - 1);
      bg[y * W + x] = sand[idx];
    }
  }
  const groundAt = (x: number) => sandTop[clamp(Math.round(x), 0, W - 1)];

  // batu berlumut
  const rock = (cx: number, s: number, seed: number) => {
    const by = groundAt(cx) + 3;
    const cs = [
      [0, -0.55 * s, 0.78 * s],
      [-0.62 * s, -0.3 * s, 0.5 * s],
      [0.66 * s, -0.25 * s, 0.46 * s],
      [0.22 * s, -0.98 * s, 0.42 * s],
    ];
    const inside = (x: number, y: number) => {
      for (const c of cs) {
        const dx = x - cx - c[0];
        const dy = y - by - c[1];
        if (dx * dx + dy * dy < c[2] * c[2]) return true;
      }
      return false;
    };
    const rc = ROCK.map(tc);
    const mc = MOSS.map(tc);
    for (let y = Math.floor(by - 1.5 * s); y <= by; y++) {
      for (let x = Math.floor(cx - 1.3 * s); x <= cx + 1.3 * s; x++) {
        if (!inside(x, y) || x < 0 || x >= W || y > sandTop[x] + 2) continue;
        const nx = (x - cx) / (1.1 * s);
        const ny = (y - (by - 0.6 * s)) / (0.9 * s);
        const t = 0.5 + 0.36 * nx + 0.42 * ny + (vnoise(x * 0.35, y * 0.35, seed) - 0.5) * 0.45;
        let c = rc[dither(5, t, x, y, 0.6)];
        const mossy = vnoise(x * 0.22, 1, seed) > 0.38;
        if (mossy && !inside(x, y - 1)) c = mc[0];
        else if (mossy && !inside(x, y - 2)) c = mc[(x + y) & 1 ? 1 : 2];
        put(x, y, c);
      }
    }
  };

  // karang bercabang
  const coral = (x0: number, pal: RGB[], size: number) => {
    const cc = pal.map(tc);
    const branch = (x: number, y: number, ang: number, len: number, d: number) => {
      for (let i = 0; i < len; i++) {
        x += Math.cos(ang);
        y -= Math.sin(ang);
        const xi = Math.round(x);
        const yi = Math.round(y);
        put(xi, yi, cc[1]);
        put(xi + 1, yi, cc[2]);
        if (d === 0) put(xi - 1, yi, cc[1]);
      }
      const xi = Math.round(x);
      const yi = Math.round(y);
      put(xi, yi - 1, cc[0]);
      put(xi + 1, yi - 1, cc[0]);
      put(xi, yi, cc[0]);
      if (d < 3 && len > 3) {
        branch(x, y, ang + 0.45 + R() * 0.3, len * 0.72, d + 1);
        branch(x, y, ang - 0.45 - R() * 0.3, len * 0.72, d + 1);
      }
    };
    branch(x0, groundAt(x0) + 2, Math.PI / 2 + (R() - 0.5) * 0.3, size, 0);
  };

  const big = Math.min(26, Math.max(13, H * 0.1));
  rock(W * 0.1, big, 11);
  coral(W * 0.1 + big * 1.25, CORALS[0], big * 0.62);
  rock(W * 0.84, big * 0.82, 23);
  coral(W * 0.84 - big * 1.15, CORALS[1], big * 0.5);
  if (W > 260) {
    rock(W * 0.52, big * 0.5, 31);
    coral(W * 0.52 + big * 0.8, CORALS[2], big * 0.42);
  }

  // kerikil
  const nPeb = Math.round(W / 20);
  for (let k = 0; k < nPeb; k++) {
    const cx = Math.round(R() * W);
    const pal = PEBBLES[(R() * PEBBLES.length) | 0].map(tc);
    const rx = 1.5 + R() * 3;
    const ry = 1 + R() * 1.6;
    const cy = groundAt(cx) + 3 + Math.round(R() * (sandH - 8));
    for (let y = -Math.ceil(ry); y <= Math.ceil(ry); y++) {
      for (let x = -Math.ceil(rx); x <= Math.ceil(rx); x++) {
        const q = (x * x) / (rx * rx) + (y * y) / (ry * ry);
        if (q > 1) continue;
        const l = -x / rx - (y / ry) * 1.2;
        put(cx + x, cy + y, pal[l > 0.6 ? 0 : l > -0.5 ? 1 : 2]);
      }
    }
    for (let x = -Math.floor(rx); x <= Math.floor(rx); x++) put(cx + x, cy + Math.ceil(ry) + 1, sand[4]);
  }

  // bintang laut & kerang
  const stamp = (tpl: string[], x0: number, y0: number, cols: Record<string, number>) => {
    for (let j = 0; j < tpl.length; j++) {
      for (let i = 0; i < tpl[j].length; i++) {
        const ch = tpl[j][i];
        if (ch !== '.') put(x0 + i, y0 + j, cols[ch]);
      }
    }
  };
  const sx = Math.round(W * 0.3);
  stamp(STAR, sx, groundAt(sx) + Math.round(sandH * 0.4), { a: tc(hex('#ff9478')), b: tc(hex('#ffc8a0')) });
  const hx = Math.round(W * 0.68);
  stamp(SHELL, hx, groundAt(hx) + Math.round(sandH * 0.35), {
    a: tc(hex('#fff4f8')),
    b: tc(hex('#ffc0d8')),
    c: tc(hex('#d888b0')),
  });

  const emitters = [
    { x: Math.round(W * 0.1 + big * 0.5), y: groundAt(W * 0.1) - Math.round(big * 0.9) },
    { x: hx + 3, y: groundAt(hx) + Math.round(sandH * 0.35) },
  ];

  return { bg, sandTop, sandBase, emitters };
}

// ---------- tanaman bergoyang ----------
export interface Plant {
  type: 0 | 1 | 2; // 0 kelp, 1 rumput, 2 daun bulat
  x: number;
  y: number;
  h: number;
  ph: number;
  sp: number;
  amp: number;
  cols: number[];
  front: boolean;
  seed: number;
  n: number;
}

const PLANT_PALS = [
  ramp('#ccf8a8', '#84de8c', '#42b080', '#2c7e74'),
  ramp('#acf2da', '#5cd2b2', '#309e98', '#267080'),
  ramp('#ffd2e8', '#ff9eca', '#de6eb0', '#9e4e96'),
  ramp('#e2ccff', '#b898f2', '#886cd2', '#5c4a9e'),
];

export function makePlants(W: number, H: number, th: Theme, scene: Scene): Plant[] {
  const R = rng(21);
  const out: Plant[] = [];
  const nBack = Math.round(W / 24);
  const nFront = W > 300 ? 5 : 3;
  for (let k = 0; k < nBack + nFront; k++) {
    const front = k >= nBack;
    let x: number;
    if (front) {
      const side = k % 2 === 0;
      x = side ? 3 + R() * W * 0.13 : W - 3 - R() * W * 0.13;
    } else x = 4 + R() * (W - 8);
    x = Math.round(x);
    const r = R();
    const type = (r < 0.42 ? 0 : r < 0.72 ? 1 : 2) as 0 | 1 | 2;
    const palI = R() < 0.68 ? ((R() * 2) | 0) : 2 + ((R() * 2) | 0);
    const hBase = front ? 0.26 + R() * 0.3 : 0.14 + R() * 0.3;
    const h = Math.round(H * hBase * (type === 1 ? 0.6 : 1));
    const cols = PLANT_PALS[palI].map((c) => {
      let m: RGB = c;
      if (!front) m = mix(m, th.water[4], 0.42);
      return packRGB(mix(m, th.tint, th.tintAmt * 1.3));
    });
    out.push({
      type,
      x,
      y: scene.sandTop[clamp(x, 0, W - 1)] + (front ? 4 : 1),
      h,
      ph: R() * 6.28,
      sp: 0.6 + R() * 0.7,
      amp: 2 + h * 0.07,
      cols,
      front,
      seed: (R() * 1000) | 0,
      n: 4 + ((R() * 4) | 0),
    });
  }
  return out;
}

export function drawPlant(put: (x: number, y: number, c: number) => void, p: Plant, t: number) {
  const c = p.cols;
  const h = p.h;
  if (p.type === 0) {
    for (let i = 0; i < h; i++) {
      const k = i / h;
      const sway = Math.sin(t * p.sp + p.ph + i * 0.1) * p.amp * Math.pow(k, 1.3) + Math.sin(i * 0.33 + p.ph) * 1.3 * k;
      const cx = Math.round(p.x + sway);
      const y = p.y - i;
      const w = k > 0.93 ? 0 : k > 0.78 ? 1 : Math.sin(i * 0.5 + p.ph) > 0.1 ? 2 : 1;
      if (w === 0) put(cx, y, c[0]);
      else {
        for (let dx = -w; dx <= w; dx++) put(cx + dx, y, dx === -w ? c[0] : dx === w ? c[3] : dx <= 0 ? c[1] : c[2]);
      }
    }
  } else if (p.type === 1) {
    for (let b = 0; b < p.n; b++) {
      const bh = h * (0.45 + 0.55 * hash(b, 1, p.seed));
      const lean = (hash(b, 2, p.seed) - 0.5) * 12;
      const off = (b - p.n / 2) * 2;
      const col = c[b % 3];
      for (let i = 0; i < bh; i++) {
        const k = i / bh;
        const x = Math.round(p.x + off + lean * k * k + Math.sin(t * p.sp + p.ph + b * 0.9) * p.amp * 0.8 * k * k);
        put(x, p.y - i, col);
        if (k < 0.45) put(x + 1, p.y - i, c[3]);
      }
    }
  } else {
    let cx = p.x;
    for (let i = 0; i < h; i++) {
      const k = i / h;
      cx = Math.round(p.x + Math.sin(t * p.sp + p.ph + i * 0.08) * p.amp * Math.pow(k, 1.3));
      const y = p.y - i;
      put(cx, y, c[3]);
      if (i % 6 === 3 && i > 4) {
        const s = ((i / 6) | 0) % 2 ? 1 : -1;
        put(cx + s, y, c[2]);
        put(cx + 2 * s, y, c[1]);
        put(cx + 3 * s, y, c[1]);
        put(cx + 4 * s, y, c[2]);
        put(cx + 2 * s, y - 1, c[0]);
        put(cx + 3 * s, y - 1, c[0]);
        put(cx + 4 * s, y - 1, c[1]);
        put(cx + 2 * s, y + 1, c[2]);
        put(cx + 3 * s, y + 1, c[3]);
      }
    }
    const y = p.y - h;
    put(cx, y, c[0]);
    put(cx + 1, y, c[1]);
    put(cx, y - 1, c[0]);
    put(cx - 1, y, c[1]);
  }
}

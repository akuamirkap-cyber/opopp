import { rand, clamp } from "./pixel";
import type { WeatherKind } from "./data";

type Drop = { x: number; y: number; v: number; l: number; layer: 0 | 1 | 2; depth: number };
type Flake = { x: number; y: number; v: number; s: number; ph: number; sw: number };
type Bolt = { pts: [number, number][]; branches: [number, number][][]; t: number; max: number };
export type SkyRect = { x0: number; y0: number; x1: number; y1: number };

const LAYER = [
  { frac: 0.46, lMin: 3, lMax: 5, vMin: 250, vMax: 320, col: "185,208,238", a: 0.32 },
  { frac: 0.34, lMin: 6, lMax: 9, vMin: 380, vMax: 470, col: "214,230,250", a: 0.55 },
  { frac: 0.2, lMin: 11, lMax: 16, vMin: 560, vMax: 720, col: "245,250,255", a: 0.9 },
];

/**
 * Cuaca HANYA di luar kaca: digambar di latar (langit & pemandangan) tiap aquarium,
 * di belakang rak, lantai, dan hamster. Tidak pernah menutupi kamera.
 */
export class WeatherFX {
  kind: WeatherKind = "clear";
  rain = 0;
  storm = 0;
  snow = 0;
  W = 440;
  H = 330;
  flash = 0;
  onThunder: ((delay: number) => void) | null = null;

  private drops: Drop[] = [];
  private flakes: Flake[] = [];
  private bolt: Bolt | null = null;
  private nextBolt = 3;
  private flick = 0;
  private t = 0;
  private gust = 0;

  constructor() {
    this.resize(440, 330);
  }

  resize(W: number, H: number) {
    this.W = W;
    this.H = H;
    const n = Math.min(1900, Math.max(600, Math.round(W * H * 0.011)));
    this.drops = [];
    for (let i = 0; i < n; i++) {
      const r = Math.random();
      const layer: 0 | 1 | 2 = r < LAYER[0].frac ? 0 : r < LAYER[0].frac + LAYER[1].frac ? 1 : 2;
      const L = LAYER[layer];
      this.drops.push({
        x: rand(-20, W + 80), y: rand(-30, H), v: rand(L.vMin, L.vMax),
        l: Math.round(rand(L.lMin, L.lMax)), layer, depth: rand(0, 26),
      });
    }
    const nf = Math.min(700, Math.max(160, Math.round(W * H * 0.0035)));
    this.flakes = [];
    for (let i = 0; i < nf; i++) {
      const s = i % 5 === 0 ? 3 : i % 2 === 0 ? 2 : 1;
      this.flakes.push({ x: rand(0, W), y: rand(0, H), v: rand(10, 24) + s * 5, s, ph: rand(0, 6.28), sw: rand(0.6, 1.6) });
    }
  }

  setKind(k: WeatherKind) {
    this.kind = k;
    if (k === "storm") this.nextBolt = rand(1.2, 3);
  }

  update(dt: number) {
    const d = Math.min(dt, 0.05);
    this.t += d;
    const k = this.kind;
    const ease = Math.min(1, d * 1.3);
    this.rain += ((k === "rain" ? 1 : 0) - this.rain) * ease;
    this.storm += ((k === "storm" ? 1 : 0) - this.storm) * ease;
    this.snow += ((k === "snow" ? 1 : 0) - this.snow) * ease;

    const { W, H } = this;
    const gustTarget = Math.max(0, Math.sin(this.t * 0.37) * Math.sin(this.t * 0.91 + 1)) * (0.12 + this.storm * 0.2);
    this.gust += (gustTarget - this.gust) * Math.min(1, d * 2);
    const slant = 0.2 + this.storm * 0.18 + this.gust;

    const nDrops = Math.floor(this.drops.length * (this.rain * 0.5 + this.storm));
    for (let i = 0; i < nDrops; i++) {
      const o = this.drops[i];
      o.y += o.v * d;
      o.x -= o.v * d * slant;
      if (o.y > H + 12 || o.x < -30) {
        o.y = rand(-50, -4);
        o.x = rand(-10, W + H * slant + 10);
      }
    }
    const nFlakes = Math.floor(this.flakes.length * this.snow);
    for (let i = 0; i < nFlakes; i++) {
      const f = this.flakes[i];
      f.y += f.v * d;
      f.x += Math.sin(this.t * f.sw + f.ph) * 9 * d + 3 * d;
      if (f.y > H + 4) {
        f.y = rand(-12, -2);
        f.x = rand(0, W);
      }
      if (f.x > W + 4) f.x = -3;
    }

    if (this.storm > 0.7) {
      this.nextBolt -= d;
      if (this.nextBolt <= 0) this.strike();
    }
    this.flash = Math.max(0, this.flash - d * 3.1);
    if (this.flick > 0) {
      this.flick -= d;
      if (this.flick <= 0) this.flash = 0.85;
    }
    if (this.bolt) {
      this.bolt.t -= d;
      if (this.bolt.t <= 0) this.bolt = null;
    }
  }

  strike() {
    const { W, H } = this;
    this.flash = 1;
    this.flick = 0.1;
    this.nextBolt = rand(4.5, 10);
    const pts: [number, number][] = [];
    let x = rand(W * 0.2, W * 0.8);
    let y = 0;
    pts.push([x, y]);
    const branches: [number, number][][] = [];
    while (y < H * 0.7) {
      y += rand(7, 15);
      x += rand(-10, 10);
      pts.push([x, y]);
      if (Math.random() < 0.34 && y > 18) {
        const br: [number, number][] = [[x, y]];
        let bx = x;
        let by = y;
        const dir = Math.random() < 0.5 ? -1 : 1;
        for (let k = 0; k < 3; k++) {
          bx += dir * rand(5, 10);
          by += rand(4, 10);
          br.push([bx, by]);
        }
        branches.push(br);
      }
    }
    this.bolt = { pts, branches, t: 0.22, max: 0.22 };
    this.onThunder?.(rand(0.2, 1.4));
  }

  private line(ctx: CanvasRenderingContext2D, pts: [number, number][], a: number, sx: number) {
    for (let i = 1; i < pts.length; i++) {
      let x0 = Math.round(pts[i - 1][0] + sx);
      let y0 = Math.round(pts[i - 1][1]);
      const x1 = Math.round(pts[i][0] + sx);
      const y1 = Math.round(pts[i][1]);
      const dx = Math.abs(x1 - x0);
      const dy = -Math.abs(y1 - y0);
      const stx = x0 < x1 ? 1 : -1;
      const sty = y0 < y1 ? 1 : -1;
      let err = dx + dy;
      for (let guard = 0; guard < 90; guard++) {
        ctx.fillStyle = `rgba(150,170,255,${(0.35 * a).toFixed(2)})`;
        ctx.fillRect(x0 - 1, y0, 3, 1);
        ctx.fillRect(x0, y0 - 1, 1, 3);
        ctx.fillStyle = `rgba(255,255,255,${a.toFixed(2)})`;
        ctx.fillRect(x0, y0, 1, 1);
        if (x0 === x1 && y0 === y1) break;
        const e2 = 2 * err;
        if (e2 >= dy) { err += dy; x0 += stx; }
        if (e2 <= dx) { err += dx; y0 += sty; }
      }
    }
  }

  /** Gambar cuaca di area langit/pemandangan sebuah aquarium (koordinat lokal aquarium). */
  drawScene(ctx: CanvasRenderingContext2D, r: SkyRect, off: number) {
    const rainy = Math.max(this.rain, this.storm);
    if (rainy < 0.01 && this.snow < 0.01 && this.flash < 0.01 && !this.bolt) return;
    const { W } = this;
    const w = r.x1 - r.x0;
    ctx.save();
    ctx.beginPath();
    ctx.rect(r.x0, r.y0, w, r.y1 - r.y0);
    ctx.clip();
    ctx.globalAlpha = 1;

    if (rainy > 0.01) {
      // kabut tipis di kaki bukit + pita kabut melayang
      const h = 28;
      const mg = ctx.createLinearGradient(0, r.y1 - h, 0, r.y1);
      mg.addColorStop(0, "rgba(200,216,238,0)");
      mg.addColorStop(1, `rgba(200,216,238,${(0.34 * rainy).toFixed(3)})`);
      ctx.fillStyle = mg;
      ctx.fillRect(r.x0, r.y1 - h, w, h);
      for (let i = 0; i < 3; i++) {
        const mx = r.x0 + (((this.t * (4 + i * 2) + i * 130 + off) % (w + 120)) - 60);
        const my = r.y1 - 10 - i * 7;
        ctx.fillStyle = `rgba(214,228,246,${(0.1 * rainy).toFixed(3)})`;
        ctx.fillRect(mx, my, 90, 4);
        ctx.fillStyle = `rgba(214,228,246,${(0.07 * rainy).toFixed(3)})`;
        ctx.fillRect(mx + 14, my - 3, 62, 3);
      }

      const n = Math.floor(this.drops.length * (this.rain * 0.5 + this.storm));
      const slant = 0.2 + this.storm * 0.18 + this.gust;
      for (let i = 0; i < n; i++) {
        const o = this.drops[i];
        const Ly = LAYER[o.layer];
        let x = o.x + off;
        x = ((x + 20) % (W + 100)) - 20;
        const ground = r.y1 - o.depth;
        const y = o.y;
        if (y > ground) {
          // percikan mungil di kaki bukit (hanya tetes dekat)
          const ts = (y - ground) / o.v;
          if (o.layer > 0 && ts < 0.2 && x > r.x0 && x < r.x1) {
            const u = ts / 0.2;
            const a = 1 - u;
            const rr = 1 + Math.floor(u * (o.layer === 2 ? 4 : 3));
            const hh = Math.round(Math.sin(u * Math.PI) * (o.layer === 2 ? 3 : 2));
            const gx = Math.round(x);
            const gy = Math.round(ground);
            ctx.fillStyle = `rgba(225,240,255,${(a * 0.85).toFixed(2)})`;
            ctx.fillRect(gx - rr, gy - hh, 1, 1);
            ctx.fillRect(gx + rr, gy - hh, 1, 1);
            ctx.fillRect(gx, gy - hh - 1, 1, 1);
            ctx.fillStyle = `rgba(190,215,245,${(a * 0.4).toFixed(2)})`;
            ctx.fillRect(gx - rr, gy, rr * 2 + 1, 1);
          }
          continue;
        }
        if (y < r.y0 - 20 || x < r.x0 - 10 || x > r.x1 + 20) continue;
        const px = Math.round(x);
        const py = Math.round(y);
        const segs = Math.ceil(o.l / 3);
        for (let k = 0; k < segs; k++) {
          const a = Ly.a * (1 - (k / segs) * 0.78);
          ctx.fillStyle = `rgba(${Ly.col},${a.toFixed(2)})`;
          const so = k * 3;
          ctx.fillRect(px + Math.round(so * slant), py - so, 1, Math.min(3, o.l - so));
          if (o.layer === 2) ctx.fillRect(px + Math.round(so * slant) + 1, py - so - 1, 1, 2);
        }
        if (o.layer === 2) {
          ctx.fillStyle = "rgba(255,255,255,0.95)";
          ctx.fillRect(px, py, 1, 1);
        }
      }
    }

    if (this.snow > 0.01) {
      const n = Math.floor(this.flakes.length * this.snow);
      for (let i = 0; i < n; i++) {
        const f = this.flakes[i];
        let fx = f.x + off;
        fx = ((fx % W) + W) % W;
        if (f.y > r.y1 - 2 || f.y < r.y0 - 4 || fx < r.x0 - 3 || fx > r.x1 + 3) continue;
        const x = Math.round(fx);
        const y = Math.round(f.y);
        ctx.fillStyle = f.s === 1 ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.95)";
        if (f.s === 1) ctx.fillRect(x, y, 1, 1);
        else if (f.s === 2) ctx.fillRect(x, y, 2, 2);
        else {
          ctx.fillRect(x, y - 1, 1, 3);
          ctx.fillRect(x - 1, y, 3, 1);
          ctx.fillStyle = "rgba(190,215,255,0.9)";
          ctx.fillRect(x - 1, y - 1, 1, 1);
          ctx.fillRect(x + 1, y + 1, 1, 1);
        }
      }
    }

    if (this.bolt) {
      const a = clamp(this.bolt.t / this.bolt.max + 0.25, 0, 1);
      const sx = (off % 90) - 30;
      this.line(ctx, this.bolt.pts, a, sx);
      for (const br of this.bolt.branches) this.line(ctx, br, a * 0.7, sx);
    }
    if (this.flash > 0.01) {
      const f = clamp(this.flash, 0, 1);
      ctx.fillStyle = `rgba(226,234,255,${(f * 0.55).toFixed(3)})`;
      ctx.fillRect(r.x0, r.y0, w, r.y1 - r.y0);
      const g = ctx.createLinearGradient(0, r.y0, 0, r.y0 + (r.y1 - r.y0) * 0.7);
      g.addColorStop(0, `rgba(255,255,255,${(f * 0.35).toFixed(3)})`);
      g.addColorStop(1, "rgba(255,255,255,0)");
      ctx.fillStyle = g;
      ctx.fillRect(r.x0, r.y0, w, (r.y1 - r.y0) * 0.7);
    }
    ctx.restore();
  }
}

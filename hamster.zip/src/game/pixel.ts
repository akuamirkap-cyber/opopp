// ====== Mesin gambar pixel-art (semua serba integer, tanpa anti-alias) ======

export class Px {
  ctx: CanvasRenderingContext2D;
  ox = 0;
  oy = 0;
  flip = 1;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
  }

  origin(x: number, y: number, flip = 1) {
    this.ox = Math.round(x);
    this.oy = Math.round(y);
    this.flip = flip < 0 ? -1 : 1;
  }

  reset() {
    this.ox = 0;
    this.oy = 0;
    this.flip = 1;
    this.stack.length = 0;
  }

  private stack: [number, number, number][] = [];

  push() {
    this.stack.push([this.ox, this.oy, this.flip]);
  }

  pop() {
    const s = this.stack.pop();
    if (s) {
      this.ox = s[0];
      this.oy = s[1];
      this.flip = s[2];
    }
  }

  /** Pindahkan titik asal relatif terhadap asal saat ini (tanpa flip). */
  local(x: number, y: number) {
    this.ox = this.ox + this.flip * Math.round(x);
    this.oy = this.oy + Math.round(y);
    this.flip = 1;
  }

  px(x: number, y: number, c: string) {
    const xi = Math.round(x);
    const yi = Math.round(y);
    this.ctx.fillStyle = c;
    this.ctx.fillRect(this.ox + this.flip * xi, this.oy + yi, 1, 1);
  }

  rect(x: number, y: number, w: number, h: number, c: string) {
    const xi = Math.round(x);
    const yi = Math.round(y);
    const wi = Math.max(1, Math.round(w));
    const hi = Math.max(1, Math.round(h));
    this.ctx.fillStyle = c;
    this.ctx.fillRect(this.flip > 0 ? this.ox + xi : this.ox - xi - wi, this.oy + yi, wi, hi);
  }

  /** Lingkaran / elips pixel sempurna ( sampling tengah piksel ). */
  ellipse(cx: number, cy: number, rx: number, ry: number, c: string) {
    if (rx < 0.5 || ry < 0.5) {
      this.px(cx, cy, c);
      return;
    }
    const rows = Math.ceil(ry);
    for (let i = 0; i < rows; i++) {
      const t = (i + 0.5) / ry;
      if (t > 1) continue;
      const half = Math.round(rx * Math.sqrt(1 - t * t));
      this.rect(cx - half, cy + i, half * 2 + 1, 1, c);
      this.rect(cx - half, cy - i - 1, half * 2 + 1, 1, c);
    }
  }

  /** Bagian dalam elips diarsir checkerboard (gaya dithering 18-bit). */
  ellipseDither(cx: number, cy: number, rx: number, ry: number, c: string, phase = 0) {
    const rows = Math.ceil(ry);
    for (let i = 0; i < rows; i++) {
      const t = (i + 0.5) / ry;
      if (t > 1) continue;
      const half = Math.round(rx * Math.sqrt(1 - t * t));
      for (const yy of [Math.round(cy + i), Math.round(cy - i - 1)]) {
        for (let x = Math.round(cx - half); x <= Math.round(cx + half); x++) {
          if (((x + yy + phase) & 1) === 0) this.px(x, yy, c);
        }
      }
    }
  }

  /** Pita arsir di antara dua elips (untuk bayangan bulu). */
  ellipseBand(cx: number, cy: number, rx: number, ry: number, irx: number, iry: number, icx: number, icy: number, c: string) {
    const rows = Math.ceil(ry);
    for (let i = -rows; i < rows; i++) {
      const yy = Math.round(cy + i);
      const t = (i + 0.5) / ry;
      if (Math.abs(t) > 1) continue;
      const half = Math.round(rx * Math.sqrt(Math.max(0, 1 - t * t)));
      for (let x = Math.round(cx - half); x <= Math.round(cx + half); x++) {
        const dx = (x - icx) / Math.max(0.5, irx);
        const dy = (yy + 0.5 - icy) / Math.max(0.5, iry);
        if (dx * dx + dy * dy > 1 && ((x + yy) & 1) === 0) this.px(x, yy, c);
      }
    }
  }

  line(x0: number, y0: number, x1: number, y1: number, c: string) {
    let x = Math.round(x0);
    let y = Math.round(y0);
    const ex = Math.round(x1);
    const ey = Math.round(y1);
    const dx = Math.abs(ex - x);
    const dy = -Math.abs(ey - y);
    const sx = x < ex ? 1 : -1;
    const sy = y < ey ? 1 : -1;
    let err = dx + dy;
    for (let guard = 0; guard < 4096; guard++) {
      this.px(x, y, c);
      if (x === ex && y === ey) break;
      const e2 = 2 * err;
      if (e2 >= dy) {
        err += dy;
        x += sx;
      }
      if (e2 <= dx) {
        err += dx;
        y += sy;
      }
    }
  }

  /** Kurva senyum / lengkungan mata dari titik-titik. */
  arc(cx: number, cy: number, r: number, from: number, to: number, c: string, steps = 14) {
    for (let i = 0; i <= steps; i++) {
      const a = from + ((to - from) * i) / steps;
      this.px(cx + Math.cos(a) * r, cy + Math.sin(a) * r, c);
    }
  }

  sprite(x: number, y: number, rows: string[], map: Record<string, string>) {
    for (let j = 0; j < rows.length; j++) {
      const row = rows[j];
      for (let i = 0; i < row.length; i++) {
        const ch = row[i];
        const col = map[ch];
        if (col) this.px(x + i, y + j, col);
      }
    }
  }
}

export function hexToRgb(hex: string) {
  const h = hex.replace("#", "");
  const n = parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function rgbToHex(r: number, g: number, b: number) {
  const cl = (v: number) => Math.max(0, Math.min(255, Math.round(v)));
  return "#" + [cl(r), cl(g), cl(b)].map((v) => v.toString(16).padStart(2, "0")).join("");
}

export function mix(a: string, b: string, t: number) {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  return rgbToHex(A.r + (B.r - A.r) * t, A.g + (B.g - A.g) * t, A.b + (B.b - A.b) * t);
}

export function shade(hex: string, amt: number) {
  const { r, g, b } = hexToRgb(hex);
  if (amt < 0) return rgbToHex(r * (1 + amt), g * (1 + amt), b * (1 + amt));
  return rgbToHex(r + (255 - r) * amt, g + (255 - g) * amt, b + (255 - b) * amt);
}

/** Noise deterministik supaya tekstur tidak berkedip tiap frame. */
export function hash2(x: number, y: number, seed = 1) {
  let h = x * 374761393 + y * 668265263 + seed * 1442695040;
  h = (h ^ (h >> 13)) * 1274126177;
  return ((h ^ (h >> 16)) >>> 0) / 4294967295;
}

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const rand = (a: number, b: number) => a + Math.random() * (b - a);
export const pick = <T,>(arr: T[]) => arr[Math.floor(Math.random() * arr.length)];
export const smooth = (t: number) => {
  const x = t < 0 ? 0 : t > 1 ? 1 : t;
  return x * x * (3 - 2 * x);
};
export const wrapAngle = (a: number) => {
  const tp = Math.PI * 2;
  return ((((a + Math.PI) % tp) + tp) % tp) - Math.PI;
};
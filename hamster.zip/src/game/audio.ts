// ====== Audio chiptune mungil: musik, efek suara, hujan deras, petir, dan angin salju ======
import type { WeatherKind } from "./data";

type SfxName =
  | "squeak" | "happy" | "munch" | "crunch" | "coin" | "clean" | "pop" | "level"
  | "sleep" | "drink" | "tick" | "shutter" | "ui" | "nope" | "dig" | "water"
  | "bonk" | "boing" | "dizzy" | "rustle" | "gulp" | "mmm" | "whoosh" | "giggle" | "spin"
  | "zip" | "tap" | "lick" | "climb" | "slip" | "claim" | "wobble" | "chest";

export class GameAudio {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  musicBus: GainNode | null = null;
  sfxBus: GainNode | null = null;
  weatherBus: GainNode | null = null;
  noise: AudioBuffer | null = null;
  pink: AudioBuffer | null = null;
  brown: AudioBuffer | null = null;
  muted = false;
  musicOn = true;
  sfxOn = true;
  private gesture = false;
  private timer: number | null = null;
  private step = 0;
  private nextTime = 0;

  private wx: { rainG: GainNode; rumG: GainNode; windG: GainNode } | null = null;
  private wxKind: WeatherKind = "clear";
  private wxVol = 0.8;
  private patterTimer: number | null = null;
  private chimeCd = 0;

  /** Dipanggil pada interaksi pertama pengguna; baru setelah itu AudioContext boleh dibuat. */
  unlock() {
    this.gesture = true;
    const c = this.ensure();
    if (c && !this.muted && this.musicOn) this.startMusic();
    return c;
  }

  ensure() {
    if (this.ctx) {
      if (this.ctx.state === "suspended") void this.ctx.resume();
      return this.ctx;
    }
    if (!this.gesture) return null;
    const Ctor: typeof AudioContext | undefined =
      window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    const ctx = new Ctor();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 0.85;
    this.master.connect(ctx.destination);
    this.musicBus = ctx.createGain();
    this.musicBus.gain.value = 0.3;
    this.musicBus.connect(this.master);
    this.sfxBus = ctx.createGain();
    this.sfxBus.gain.value = 0.7;
    this.sfxBus.connect(this.master);
    this.weatherBus = ctx.createGain();
    this.weatherBus.gain.value = 1;
    this.weatherBus.connect(this.master);

    const sr = ctx.sampleRate;
    const len = Math.floor(sr * 0.4);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);
    for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    this.noise = buf;

    // noise merah muda & cokelat untuk hujan, angin, dan guruh
    const L = sr * 4;
    const pk = ctx.createBuffer(1, L, sr);
    const pd = pk.getChannelData(0);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
    for (let i = 0; i < L; i++) {
      const w = Math.random() * 2 - 1;
      b0 = 0.99886 * b0 + w * 0.0555179;
      b1 = 0.99332 * b1 + w * 0.0750759;
      b2 = 0.969 * b2 + w * 0.153852;
      b3 = 0.8665 * b3 + w * 0.3104856;
      b4 = 0.55 * b4 + w * 0.5329522;
      b5 = -0.7616 * b5 - w * 0.016898;
      pd[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.11;
      b6 = w * 0.115926;
    }
    this.pink = pk;
    const bw = ctx.createBuffer(1, L, sr);
    const bd = bw.getChannelData(0);
    let last = 0;
    for (let i = 0; i < L; i++) {
      const w = Math.random() * 2 - 1;
      last = (last + 0.02 * w) / 1.02;
      bd[i] = last * 3.5;
    }
    this.brown = bw;

    if (this.wxKind !== "clear") this.applyWx();
    return ctx;
  }

  setMuted(m: boolean) {
    this.muted = m;
    if (this.master && this.ctx) {
      this.master.gain.cancelScheduledValues(this.ctx.currentTime);
      this.master.gain.setTargetAtTime(m ? 0 : 0.85, this.ctx.currentTime, 0.05);
    }
    if (!m) this.startMusic();
  }

  setMusic(on: boolean) {
    this.musicOn = on;
    if (on) this.startMusic();
    else this.stopMusic();
  }

  setSfx(on: boolean) {
    this.sfxOn = on;
  }

  private tone(
    freq: number, dur: number, type: OscillatorType, gain: number,
    bus: GainNode, at = 0, slideTo?: number,
  ) {
    const ctx = this.ctx!;
    const t0 = ctx.currentTime + at;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, t0);
    if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(30, slideTo), t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + Math.min(0.02, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(g);
    g.connect(bus);
    osc.start(t0);
    osc.stop(t0 + dur + 0.03);
  }

  private noiseHit(dur: number, freq: number, gain: number, at = 0, q = 1, type: BiquadFilterType = "bandpass", bus?: GainNode) {
    const ctx = this.ctx!;
    if (!this.noise) return;
    const t0 = ctx.currentTime + at;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const filt = ctx.createBiquadFilter();
    filt.type = type;
    filt.frequency.setValueAtTime(freq, t0);
    filt.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(filt);
    filt.connect(g);
    g.connect(bus ?? this.sfxBus!);
    src.start(t0);
    src.stop(t0 + dur + 0.02);
  }

  play(name: SfxName) {
    if (!this.sfxOn || this.muted) return;
    const ctx = this.ensure();
    if (!ctx || !this.sfxBus) return;
    const b = this.sfxBus;
    switch (name) {
      case "squeak":
        this.tone(760, 0.1, "triangle", 0.2, b, 0, 1500);
        this.tone(1500, 0.08, "triangle", 0.13, b, 0.09, 1050);
        break;
      case "giggle":
        [1180, 1400, 1180, 1500, 1260].forEach((f, i) => this.tone(f, 0.07, "triangle", 0.1, b, i * 0.07, f * 1.15));
        break;
      case "happy":
        [1046, 1318, 1568].forEach((f, i) => this.tone(f, 0.1, "square", 0.1, b, i * 0.06));
        break;
      case "munch":
        this.noiseHit(0.07, 900, 0.22, 0, 1.4);
        this.noiseHit(0.06, 620, 0.16, 0.09, 1.2);
        break;
      case "crunch":
        this.noiseHit(0.06, 1500, 0.3, 0, 1.2);
        this.noiseHit(0.05, 2700, 0.2, 0.04, 1.5);
        this.noiseHit(0.08, 700, 0.18, 0.09, 1.1);
        this.tone(520, 0.06, "square", 0.05, b, 0.02, 380);
        break;
      case "gulp":
        this.tone(320, 0.09, "sine", 0.2, b, 0, 130);
        this.tone(230, 0.11, "sine", 0.16, b, 0.11, 100);
        break;
      case "mmm":
        this.tone(430, 0.34, "triangle", 0.11, b, 0, 560);
        this.tone(645, 0.3, "sine", 0.05, b, 0.02, 800);
        break;
      case "coin":
        this.tone(988, 0.06, "square", 0.13, b);
        this.tone(1319, 0.12, "square", 0.12, b, 0.06);
        break;
      case "clean":
        this.noiseHit(0.22, 1600, 0.16, 0, 0.7, "highpass");
        this.tone(700, 0.16, "sine", 0.07, b, 0.02, 1800);
        break;
      case "pop":
        this.tone(420, 0.07, "sine", 0.18, b, 0, 980);
        break;
      case "level":
        [523, 659, 784, 1046, 1318].forEach((f, i) => this.tone(f, 0.18, "triangle", 0.16, b, i * 0.08));
        break;
      case "sleep":
        this.tone(520, 0.4, "sine", 0.12, b, 0, 180);
        break;
      case "drink":
        [0, 0.11, 0.22].forEach((d, i) => this.tone(500 - i * 70, 0.07, "sine", 0.13, b, d, 320 - i * 60));
        break;
      case "tick":
        this.noiseHit(0.03, 2400, 0.05, 0, 2);
        break;
      case "spin":
        this.noiseHit(0.5, 1100, 0.09, 0, 0.5);
        this.tone(300, 0.5, "sawtooth", 0.035, b, 0, 900);
        break;
      case "shutter":
        this.noiseHit(0.05, 3000, 0.24, 0, 1, "highpass");
        this.noiseHit(0.07, 1200, 0.16, 0.06, 1);
        break;
      case "ui":
        this.tone(880, 0.04, "square", 0.07, b);
        break;
      case "nope":
        this.tone(220, 0.12, "square", 0.11, b, 0, 150);
        break;
      case "dig":
        this.noiseHit(0.12, 480, 0.14, 0, 0.8);
        break;
      case "rustle":
        this.noiseHit(0.2, 2300, 0.11, 0, 0.6);
        this.noiseHit(0.16, 1700, 0.09, 0.12, 0.7);
        this.noiseHit(0.14, 2800, 0.07, 0.24, 0.6);
        break;
      case "water":
        this.tone(300, 0.2, "sine", 0.1, b, 0, 900);
        break;
      case "bonk":
        this.tone(190, 0.14, "square", 0.2, b, 0, 70);
        this.noiseHit(0.09, 320, 0.26, 0, 0.9);
        this.tone(1250, 0.08, "triangle", 0.08, b, 0.08, 700);
        break;
      case "boing":
        this.tone(250, 0.3, "triangle", 0.2, b, 0, 880);
        this.tone(880, 0.22, "triangle", 0.1, b, 0.22, 310);
        break;
      case "dizzy":
        [880, 760, 640, 560, 470, 400].forEach((f, i) => this.tone(f, 0.12, "triangle", 0.09, b, i * 0.09, f * 0.85));
        break;
      case "whoosh":
        this.noiseHit(0.34, 900, 0.17, 0, 0.5);
        this.noiseHit(0.3, 2100, 0.08, 0.06, 0.5, "highpass");
        break;
      case "zip":
        this.noiseHit(0.55, 2000, 0.11, 0, 0.6);
        this.tone(1000, 0.55, "triangle", 0.06, b, 0, 280);
        this.tone(1500, 0.3, "sine", 0.03, b, 0.02, 600);
        break;
      case "tap":
        this.tone(1750, 0.045, "triangle", 0.1, b, 0, 1500);
        this.noiseHit(0.03, 3600, 0.08, 0, 2);
        break;
      case "lick":
        this.tone(900, 0.05, "sine", 0.06, b, 0, 1400);
        this.tone(1100, 0.05, "sine", 0.05, b, 0.07, 1500);
        break;
      case "climb":
        this.noiseHit(0.04, 1300, 0.07, 0, 2);
        this.tone(520, 0.04, "square", 0.025, b, 0, 440);
        break;
      case "slip":
        this.tone(980, 0.38, "triangle", 0.14, b, 0, 150);
        this.noiseHit(0.1, 1800, 0.07, 0.3, 1);
        break;
      case "wobble":
        this.tone(260, 0.18, "sine", 0.12, b, 0, 520);
        this.tone(520, 0.14, "sine", 0.08, b, 0.14, 300);
        break;
      case "claim":
        [784, 988, 1175, 1568, 1976].forEach((f, i) => this.tone(f, 0.16, "triangle", 0.14, b, i * 0.07));
        this.tone(2637, 0.45, "sine", 0.06, b, 0.4);
        break;
      case "chest":
        [523, 659, 784, 1046, 1318, 1568, 2093].forEach((f, i) => this.tone(f, 0.2, "square", 0.08, b, i * 0.075));
        this.tone(262, 0.6, "triangle", 0.12, b, 0);
        this.noiseHit(0.4, 3200, 0.07, 0.3, 1, "highpass");
        break;
    }
  }

  // ================= cuaca =================
  setWeather(kind: WeatherKind, vol: number) {
    this.wxKind = kind;
    this.wxVol = vol;
    if (this.ctx) this.applyWx();
  }

  private initWx() {
    const ctx = this.ctx!;
    const bus = this.weatherBus!;
    const loop = (buf: AudioBuffer) => {
      const s = ctx.createBufferSource();
      s.buffer = buf;
      s.loop = true;
      s.start();
      return s;
    };
    const rainSrc = loop(this.pink!);
    const hp = ctx.createBiquadFilter();
    hp.type = "highpass";
    hp.frequency.value = 650;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 8200;
    const rainG = ctx.createGain();
    rainG.gain.value = 0;
    rainSrc.connect(hp);
    hp.connect(lp);
    lp.connect(rainG);
    rainG.connect(bus);

    const rumSrc = loop(this.brown!);
    const rlp = ctx.createBiquadFilter();
    rlp.type = "lowpass";
    rlp.frequency.value = 240;
    const rumG = ctx.createGain();
    rumG.gain.value = 0;
    rumSrc.connect(rlp);
    rlp.connect(rumG);
    rumG.connect(bus);

    const windSrc = loop(this.pink!);
    const bp = ctx.createBiquadFilter();
    bp.type = "bandpass";
    bp.frequency.value = 480;
    bp.Q.value = 0.6;
    const windG = ctx.createGain();
    windG.gain.value = 0;
    windSrc.connect(bp);
    bp.connect(windG);
    windG.connect(bus);
    this.wx = { rainG, rumG, windG };
  }

  private applyWx() {
    const ctx = this.ctx;
    if (!ctx) return;
    const k = this.wxKind;
    if (k !== "clear" && !this.wx) this.initWx();
    const wx = this.wx;
    const v = this.wxVol;
    if (wx) {
      const now = ctx.currentTime;
      const rain = k === "rain" ? 0.22 : k === "storm" ? 0.46 : 0;
      const rum = k === "rain" ? 0.04 : k === "storm" ? 0.22 : 0;
      const wind = k === "snow" ? 0.12 : k === "storm" ? 0.05 : 0;
      wx.rainG.gain.setTargetAtTime(rain * v, now, 0.9);
      wx.rumG.gain.setTargetAtTime(rum * v, now, 0.9);
      wx.windG.gain.setTargetAtTime(wind * v, now, 1.1);
    }
    const needPatter = k !== "clear";
    if (needPatter && this.patterTimer === null) {
      this.patterTimer = window.setInterval(() => this.patter(), 90);
    } else if (!needPatter && this.patterTimer !== null) {
      clearInterval(this.patterTimer);
      this.patterTimer = null;
    }
  }

  /** Percikan butir hujan acak, hembusan, dan lonceng salju lembut. */
  private patter() {
    const ctx = this.ctx;
    const wx = this.wx;
    if (!ctx || !wx || this.muted) return;
    const k = this.wxKind;
    const v = this.wxVol;
    if (k === "rain" || k === "storm") {
      const n = k === "storm" ? 5 : 2;
      for (let i = 0; i < n; i++) {
        this.noiseHit(0.012 + Math.random() * 0.012, 2200 + Math.random() * 4200, (0.05 + Math.random() * 0.05) * v, Math.random() * 0.09, 1.4, "bandpass", this.weatherBus!);
      }
      const base = (k === "storm" ? 0.46 : 0.22) * v;
      wx.rainG.gain.setTargetAtTime(base * (0.85 + Math.random() * 0.3), ctx.currentTime, 0.35);
    } else if (k === "snow") {
      const base = 0.12 * v;
      wx.windG.gain.setTargetAtTime(base * (0.55 + Math.random() * 0.9), ctx.currentTime, 0.9);
      this.chimeCd -= 0.09;
      if (this.chimeCd <= 0 && this.sfxOn) {
        this.chimeCd = 3 + Math.random() * 5;
        const f = [1318, 1568, 1760, 2093][Math.floor(Math.random() * 4)];
        this.tone(f, 0.9, "sine", 0.025 * v, this.weatherBus!);
        this.tone(f * 2, 0.5, "sine", 0.01 * v, this.weatherBus!, 0.02);
      }
    }
  }

  /** Guruh yang menyusul setelah kilat. */
  thunder(delay = 0.4) {
    if (this.muted) return;
    const ctx = this.ensure();
    if (!ctx || !this.brown || !this.weatherBus) return;
    const v = this.wxVol;
    const t0 = ctx.currentTime + delay;
    // retakan
    this.noiseHit(0.14, 1900, 0.5 * v, delay, 0.8, "highpass", this.weatherBus);
    // gemuruh
    const src = ctx.createBufferSource();
    src.buffer = this.brown;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.setValueAtTime(900, t0);
    lp.frequency.exponentialRampToValueAtTime(70, t0 + 2.8);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(1.1 * v, t0 + 0.09);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + 3.3);
    src.connect(lp);
    lp.connect(g);
    g.connect(this.weatherBus);
    src.start(t0, Math.random() * 0.5);
    src.stop(t0 + 3.4);
    // dentuman rendah
    const o = ctx.createOscillator();
    o.type = "sine";
    o.frequency.setValueAtTime(62, t0);
    o.frequency.exponentialRampToValueAtTime(30, t0 + 2.4);
    const og = ctx.createGain();
    og.gain.setValueAtTime(0.0001, t0);
    og.gain.exponentialRampToValueAtTime(0.5 * v, t0 + 0.1);
    og.gain.exponentialRampToValueAtTime(0.0001, t0 + 2.6);
    o.connect(og);
    og.connect(this.weatherBus);
    o.start(t0);
    o.stop(t0 + 2.7);
  }

  // ---- musik: lagu nina bobo 8-bit yang lembut ----
  private melody = [
    76, 0, 79, 0, 81, 0, 79, 0, 76, 0, 72, 0, 74, 0, 0, 0,
    76, 0, 79, 0, 84, 0, 81, 0, 79, 0, 76, 0, 74, 0, 0, 0,
    72, 0, 76, 0, 79, 0, 76, 0, 74, 0, 71, 0, 72, 0, 0, 0,
    79, 0, 76, 0, 74, 0, 72, 0, 71, 0, 72, 0, 0, 0, 0, 0,
  ];
  private bass = [48, 55, 53, 55];

  startMusic() {
    if (!this.musicOn || this.muted) return;
    const ctx = this.ensure();
    if (!ctx || this.timer !== null) return;
    this.nextTime = ctx.currentTime + 0.1;
    this.timer = window.setInterval(() => this.schedule(), 60);
  }

  stopMusic() {
    if (this.timer !== null) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  private schedule() {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const spb = 0.1875;
    while (this.nextTime < ctx.currentTime + 0.25) {
      const s = this.step % this.melody.length;
      const n = this.melody[s];
      const at = this.nextTime - ctx.currentTime;
      if (n > 0) {
        const f = 440 * Math.pow(2, (n - 69) / 12);
        this.tone(f, 0.34, "triangle", 0.09, this.musicBus, Math.max(0, at));
        this.tone(f * 2, 0.16, "sine", 0.025, this.musicBus, Math.max(0, at));
      }
      if (s % 16 === 0) {
        const bn = this.bass[(s / 16) % this.bass.length];
        const bf = 440 * Math.pow(2, (bn - 69) / 12);
        this.tone(bf, 0.7, "sine", 0.11, this.musicBus, Math.max(0, at));
        this.tone(bf * 1.5, 0.5, "triangle", 0.03, this.musicBus, Math.max(0, at) + 0.02);
      }
      this.nextTime += spb;
      this.step++;
    }
  }

  dispose() {
    this.stopMusic();
    if (this.patterTimer !== null) clearInterval(this.patterTimer);
    if (this.ctx) void this.ctx.close();
    this.ctx = null;
  }
}

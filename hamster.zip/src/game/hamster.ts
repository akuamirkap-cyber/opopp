import { Px, hash2, mix, shade, clamp, lerp, smooth } from "./pixel";
import { getPalette, type Look } from "./data";
import { drawFood, foodSize } from "./scene";

/** Seluruh hamster digambar 30% lebih kecil dari versi awal. */
export const HAMSTER_SIZE = 0.7;

/** Bentuk pose berjalan (satuan pra-skala): pendek, bulat gembul, bulu menutupi kaki & tangan. */
export const CRAWL = { brx: 16.8, bry: 15.6, hr: 15.8, headDx: 0.55, lift: 1.8, bob: 1.1, A: 3.6, B: 2.2 };

/** Tinggi badan (pra-skala) saat diangkat; dipakai untuk menaruh hamster di tangan hantu. */
export const HELD_BODY_Y = -27;
export const HELD_BODY_RY = 19.5;
export const heldHandDY = (S: number) => (HELD_BODY_Y + HELD_BODY_RY * 0.5) * S;

const WORLD_G = 300;

// =====================================================================
//  FISIKA — pegas lembut di KERANGKA LOKAL sprite (ikut berputar bersama badan)
// =====================================================================
type Sp = { x: number; y: number; vx: number; vy: number };
const mk = (): Sp => ({ x: 0, y: 0, vx: 0, vy: 0 });

function stepSpring(s: Sp, k: number, c: number, fx: number, fy: number, dt: number, lim: number) {
  const n = 3;
  const h = dt / n;
  for (let i = 0; i < n; i++) {
    s.vx += (-k * s.x - c * s.vx + fx) * h;
    s.vy += (-k * s.y - c * s.vy + fy) * h;
    s.x += s.vx * h;
    s.y += s.vy * h;
  }
  s.x = clamp(s.x, -lim, lim);
  s.y = clamp(s.y, -lim, lim);
}

export type RagIn = { on: boolean; spin: number; rot: number; air?: boolean };

export class FurPhysics {
  head = mk();
  earL = mk();
  earR = mk();
  cheek = mk();
  fur = mk();
  tail = mk();
  body = mk();
  acc = mk();
  jel = mk(); // "puding": squash & stretch yang bergoyang
  rear = mk(); // pantat yang tertinggal
  aL = mk();
  aR = mk();
  lL = mk();
  lR = mk();
  ragOn = 0;
  speed = 0;
  private px = NaN;
  private py = NaN;
  private pvx = 0;
  private pvy = 0;
  private ax = 0;
  private ay = 0;
  private time = 0;

  update(dt: number, x: number, y: number, wind = 0, rag?: RagIn) {
    if (dt <= 0) return;
    const d = Math.min(dt, 0.05);
    this.time += d;
    if (Number.isNaN(this.px)) {
      this.px = x;
      this.py = y;
    }
    let vx = (x - this.px) / d;
    let vy = (y - this.py) / d;
    this.px = x;
    this.py = y;
    if (Math.abs(vx) > 520 || Math.abs(vy) > 520) {
      vx = 0;
      vy = 0;
    }
    const rax = clamp((vx - this.pvx) / d, -800, 800);
    const ray = clamp((vy - this.pvy) / d, -800, 800);
    this.pvx = vx;
    this.pvy = vy;
    this.ax += (rax - this.ax) * 0.6;
    this.ay += (ray - this.ay) * 0.6;
    this.speed = Math.hypot(vx, vy);

    // percepatan semu: saat jatuh bebas gravitasi dibuang (tubuh tidak "merasakan" apa-apa)
    const ayw = this.ay - (rag?.air ? WORLD_G : 0);
    const rot = rag ? rag.rot : 0;
    const cs = Math.cos(rot);
    const sn = Math.sin(rot);
    const ax = this.ax * cs + ayw * sn;
    const ay = -this.ax * sn + ayw * cs;
    const vxl = vx * cs + vy * sn;
    const vyl = -vx * sn + vy * cs;
    const wl = wind * cs;
    const wly = -wind * sn;
    const br = Math.sin(this.time * 1.7) * 12 + Math.sin(this.time * 3.3 + 1) * 6;
    const brl = br * cs;

    const on = rag?.on ? 1 : 0;
    this.ragOn += (on - this.ragOn) * Math.min(1, d * 14);
    const R = this.ragOn;
    const gx = sn; // arah gravitasi di kerangka lokal
    const gy = cs;
    const spin = rag ? rag.spin : 0;
    const cf = clamp(spin * spin * 0.5, 0, 46) * R; // gaya sentrifugal
    const G = 150 * R;

    stepSpring(this.head, 230 - 80 * R, 15 - 8 * R, -ax * 0.9 - vxl * 0.5 + gx * G * 0.55, -ay * 0.9 + gy * G * 0.55 - cf * 0.5, d, 3.5 + 2 * R);
    stepSpring(this.earL, 135, 5.2 - 1.6 * R, -ax * 1.8 - vxl * 3 + wl * 0.8 + brl * 0.4 + gx * G * 0.5 - cf * 0.5, -ay * 1.8 - vyl * 1.6 + wly * 0.8 + gy * G * 0.5 - cf * 0.5, d, 5);
    stepSpring(this.earR, 150, 5.5 - 1.8 * R, -ax * 1.8 - vxl * 3 + wl * 0.8 + brl * 0.28 - 3 + gx * G * 0.5 + cf * 0.5, -ay * 1.8 - vyl * 1.6 + wly * 0.8 + gy * G * 0.5 - cf * 0.5, d, 5);
    stepSpring(this.cheek, 260, 7, -ax * 1.5 - vxl * 0.6 + gx * G * 0.35, -ay * 2.1 + gy * G * 0.35, d, 3);
    stepSpring(this.fur, 95, 4.2, -ax * 1.1 - vxl * 4.6 + wl + brl + gx * G * 0.3, -ay * 1.1 - vyl * 1.8 + wly + Math.sin(this.time * 2.3) * 3 + gy * G * 0.3, d, 4.4);
    stepSpring(this.tail, 110, 4, -ax * 1.2 - vxl * 2.5 + wl * 0.5 + gx * G * 0.5, -ay * 1.2 + gy * G * 0.5, d, 4);
    stepSpring(this.body, 210, 10, -ax * 0.4, -ay * 1.0, d, 6);
    stepSpring(this.acc, 170, 6, -ax * 1.3 - vxl * 0.8 + wl * 0.3, -ay * 1.5, d, 3);
    stepSpring(this.jel, 150, 4.4, 0, -ay * 0.32 * (1 - 0.75 * R), d, 12);
    stepSpring(this.rear, 110, 3.8, -ax * 0.9 - vxl * 1.8, -ay * 0.9, d, 5);

    // ---- anggota badan: pendulum lunglai (turun ke arah gravitasi dunia) ----
    const kk = 46 + (1 - R) * 94;
    const cc = 2.8 + (1 - R) * 10.2;
    const limbs: [Sp, number, number, number][] = [
      [this.aL, -0.8, -0.6, 1.25],
      [this.aR, 0.8, -0.6, 1.1],
      [this.lL, -0.55, 0.85, 1.0],
      [this.lR, 0.55, 0.85, 1.2],
    ];
    for (const [sp, dx, dy, m] of limbs) {
      const fx = R * (-ax * 0.45 * m - vxl * 0.45 + dx * cf + gx * G * 0.95 * m);
      const fy = R * (-ay * 0.45 * m - vyl * 0.45 + dy * cf + gy * G * 0.95 * m);
      stepSpring(sp, kk, cc, fx, fy, d, 7);
    }
  }

  kick(fx: number, fy: number) {
    const all: [Sp, number][] = [
      [this.head, 0.4], [this.earL, 1.3], [this.earR, 1.3], [this.cheek, 1.2],
      [this.fur, 1], [this.tail, 1.2], [this.acc, 1.2], [this.body, 0.8], [this.rear, 1],
    ];
    for (const [s, m] of all) {
      s.vx += fx * m;
      s.vy += fy * m;
    }
    this.jel.vy += Math.abs(fy) * 0.7 + Math.abs(fx) * 0.12;
  }

  /** Pencet seperti puding: positif = gepeng dulu lalu membal. */
  squish(a: number) {
    this.jel.vy += a * 0.85;
    this.rear.vy += a * 0.08;
  }
}

// =====================================================================

export type HamsterVisual = {
  x: number;
  y: number;
  dir: number;
  act: string;
  actT: number;
  cheek: number;
  blink: number;
  mood: number;
  hop: number;
  scale: number;
  sand: number;
  gaze?: { x: number; y: number };
  phys?: FurPhysics;
  rot?: number;
  sink?: number;
  clipY?: number;
  clip?: { x0: number; y0: number; x1: number; y1: number };
  tint?: number;
  eatP?: number;
  food?: string;
  pulse?: number;
  dizzy?: number;
  sleepy?: boolean;
  fear?: number;
  shadow?: boolean;
  variant?: string; // slide: sit/head/back/spin/roll · climb: look/wave · wall: hang
  climbPh?: number;
  lick?: number;
  squeeze?: number;
  ragOn?: boolean;
  viewer?: boolean;
  gait?: number; // fase langkah (rad) untuk merangkak, mengikuti jarak tempuh
  faceTurn?: number; // 0 = membelakangi kamera, 1 = wajah menoleh ke kamera
  faceSide?: number; // arah menoleh saat setengah menoleh (-1 kiri, 1 kanan)
};

type Blob = { x: number; y: number; rx: number; ry: number; c: string };
type Clip = { x: number; y: number; rx: number; ry: number };
type ArmPose = "down" | "hold" | "lick" | "dig" | "reach" | "up" | "wave" | "run" | "box" | "belly" | "glass" | "heldArms" | "lickArm" | "none";
type Legs = "sit" | "walk" | "run" | "tuck" | "dangle" | "stand" | "up" | "climb" | "hang" | "crawl";
type Eyes = "open" | "happy" | "joy" | "sleep" | "wide" | "sad" | "sparkle" | "blink" | "squeeze" | "spiral";
type Mouth = "w" | "chew" | "smile" | "yawn" | "tiny" | "tongue" | "grin" | "frown" | "lick" | "scream" | "cat3" | "oh";

function inEllipse(x: number, y: number, e: Clip) {
  const dx = (x - e.x) / e.rx;
  const dy = (y + 0.5 - e.y) / e.ry;
  return dx * dx + dy * dy <= 1;
}

function patch(p: Px, cx: number, cy: number, rx: number, ry: number, c: string, clips: Clip[], soft = true) {
  const draw = (RX: number, RY: number, dither: boolean) => {
    for (let y = Math.round(cy - RY); y < Math.round(cy + RY); y++) {
      for (let x = Math.round(cx - RX); x <= Math.round(cx + RX); x++) {
        if (dither && ((x + y) & 1)) continue;
        if (!inEllipse(x, y, { x: cx, y: cy, rx: RX, ry: RY })) continue;
        for (const cl of clips) {
          if (inEllipse(x, y, cl)) {
            p.px(x, y, c);
            break;
          }
        }
      }
    }
  };
  draw(rx, ry, false);
  if (soft) draw(rx + 1.5, ry + 1.5, true);
}

function star(p: Px, cx: number, cy: number, c: string, hi: string) {
  p.sprite(cx - 3, cy - 3, [
    "...a...",
    "...a...",
    "a.aaa.a",
    ".aaaaa.",
    "..aaa..",
    ".aa.aa.",
    ".a...a.",
  ], { a: c });
  p.px(cx, cy - 1, hi);
  p.px(cx - 1, cy, hi);
}

// ---------- kanvas sementara untuk sprite berputar ----------
const SC = 160;
let scratch: { cv: HTMLCanvasElement; p: Px } | null = null;
function getScratch() {
  if (!scratch) {
    const cv = document.createElement("canvas");
    cv.width = SC;
    cv.height = SC;
    const ctx = cv.getContext("2d")!;
    ctx.imageSmoothingEnabled = false;
    scratch = { cv, p: new Px(ctx) };
  }
  return scratch;
}

function drawShadow(p: Px, v: HamsterVisual, look: Look) {
  const S = look.scale * v.scale * HAMSTER_SIZE;
  const brx = 19.5 * look.chub * S;
  const shR = brx * (0.95 - Math.min(0.4, v.hop / 60));
  p.origin(v.x, v.y, 1);
  p.ellipseDither(0, -1, shR, 3 * S + 0.6, "rgba(70,40,22,0.26)");
  p.ellipse(0, -1, shR * 0.6, 1.8 * S + 0.4, "rgba(70,40,22,0.18)");
}

export function drawHamster(p: Px, v: HamsterVisual, look: Look, t: number) {
  if (v.shadow !== false) drawShadow(p, v, look);
  if (v.rot !== undefined && Math.abs(v.rot) > 0.02) {
    const S = look.scale * v.scale * HAMSTER_SIZE;
    const sc = getScratch();
    sc.p.ctx.clearRect(0, 0, SC, SC);
    const ox = SC / 2;
    const oy = SC - 30;
    drawBody(sc.p, { ...v, x: ox, y: oy, hop: 0, rot: 0, sink: 0, clip: undefined, clipY: undefined }, look, t);
    const pivot = 15 * S;
    const ctx = p.ctx;
    ctx.save();
    ctx.translate(Math.round(v.x), Math.round(v.y - v.hop - pivot));
    ctx.rotate(v.rot);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(sc.cv, -ox, -(oy - pivot));
    ctx.restore();
  } else {
    drawBody(p, v, look, t);
  }
  p.reset();
}

function drawBody(p: Px, v: HamsterVisual, look: Look, t: number) {
  const pal = getPalette(look.palette);
  const S = look.scale * v.scale * HAMSTER_SIZE;
  const dir = v.dir < 0 ? -1 : 1;
  const act = v.act;
  const at = v.actT;
  const ph = v.phys;
  const wob = Math.sin(t * 2.3);
  const rp = at * 17;
  const cph = v.gait ?? rp; // fase langkah merangkak
  const variant = v.variant ?? "";

  const loc = (s: Sp | undefined, k = 1) => ({ x: (s ? s.x : 0) * dir * k, y: (s ? s.y : 0) * k });
  const lg = { x: (v.gaze?.x ?? 0) * dir, y: v.gaze?.y ?? 0 };

  const isPanda = look.pattern === "panda";
  const furBase = isPanda ? pal.light : pal.base;
  const furLight = isPanda ? "#FFFFFF" : pal.light;
  const furDark = pal.dark;
  const line = pal.line;

  const ctx = p.ctx;
  let clipped = false;
  if (v.clip) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(v.clip.x0, v.clip.y0, v.clip.x1 - v.clip.x0, v.clip.y1 - v.clip.y0);
    ctx.clip();
    clipped = true;
  } else if (v.clipY !== undefined) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, ctx.canvas.width, v.clipY);
    ctx.clip();
    clipped = true;
  }

  // ---------- pose dasar ----------
  let brx = 19.5 * look.chub;
  let bry = 15.5;
  let bx = 0;
  let by = -15.5;
  let hr = 17.4;
  let hx = 3;
  let hy = -33;
  let earBack = 0;
  let earDroop = 0;
  let armPose: ArmPose = "down";
  let legs: Legs = "sit";
  let eyes: Eyes = "open";
  let mouth: Mouth = "w";
  let headTilt = 0;
  let blushBoost = 0;
  let eatP = -1;
  let foodBite = 0;
  let showStars = false;
  let stepSq = 0;
  let front = false; // tampak depan penuh (simetris, perut menghadap kita)
  let back = false; // tampak belakang (membelakangi kamera): memanjat tangga / dinding
  let crawl = false; // merangkak khas hamster
  let tears = false;
  let lickSide = 1;
  let lickPh = 0;
  let sweat = false;
  const viewer = !!v.viewer;
  const late: (() => void)[] = [];

  bry += wob * 0.45;
  hy += wob * 0.5;
  hx += Math.sin(t * 0.8) * 0.5;
  if (act === "idle" && v.mood > 0.8) {
    hx += Math.sin(t * 2.6) * 0.6;
    bx -= Math.sin(t * 2.6) * 0.3;
  }

  switch (act) {
    case "walk":
    case "stash":
    case "play": {
      // berjalan pendek & gembul: badan bulat seperti mochi, kepala menyatu di depan,
      // bulu menutupi kaki dan tangan; hanya telapak pink yang mengintip di bawah badan
      crawl = true;
      const C = CRAWL;
      const bounce = Math.abs(Math.sin(cph));
      brx = C.brx * look.chub;
      bry = C.bry + Math.sin(cph * 2) * 0.35;
      bx = -4 + Math.sin(cph) * 0.45; // goyang kiri-kanan (waddle)
      by = -(C.lift + bry) - bounce * C.bob;
      hr = C.hr;
      hx = bx + brx * C.headDx + 1.5 + Math.sin(cph) * 0.5;
      hy = -(C.lift + hr * 0.95) + Math.sin(cph * 2 + 0.6) * 0.5 - bounce * C.bob * 0.7;
      earBack = 2;
      legs = "crawl";
      armPose = "none";
      mouth = act === "stash" ? "tiny" : "w";
      blushBoost = 0.2;
      stepSq = Math.cos(cph * 2) * 0.05;
      if (act === "play") {
        hy += 1.2;
        hx += 1.2;
      }
      break;
    }
    case "skid": {
      brx *= 1.05;
      bry *= 0.9;
      hx += 2;
      hy += 2;
      legs = "tuck";
      armPose = "up";
      eyes = "joy";
      mouth = "grin";
      break;
    }
    case "run":
    case "chase": {
      const bob = Math.abs(Math.sin(rp));
      by -= 0.6 + bob * 1.7;
      hy -= 0.6 + bob * 1.7;
      hy += Math.sin(rp * 2) * 0.6;
      brx *= 1.1;
      bry *= 0.9 + Math.sin(rp * 2) * 0.02;
      hx += 6;
      hy += 3;
      earBack = 4;
      legs = "run";
      armPose = "run";
      mouth = "grin";
      blushBoost = 0.3;
      stepSq = Math.cos(rp * 2) * 0.05;
      break;
    }
    case "wall": {
      // memanjat dinding membelakangi kamera; saat nyangkut kepalanya menoleh ke kamera
      back = true;
      brx = 14.5 * look.chub;
      bry = 19.5;
      by = -21;
      hx = 0;
      hy = -44;
      legs = "climb";
      armPose = "none";
      const hang = variant === "hang";
      eyes = hang ? "wide" : "open";
      mouth = hang ? "oh" : "tiny";
      sweat = hang;
      blushBoost = 0.25;
      if (hang) {
        bx += Math.sin(t * 15) * 0.8;
        hx += Math.sin(t * 15 + 1) * 0.6;
      }
      break;
    }
    case "shake": {
      const w = Math.sin(at * 38);
      hx += w * 1.7;
      bx -= w * 0.9;
      brx *= 1 + Math.abs(w) * 0.05;
      eyes = "joy";
      mouth = "smile";
      earDroop = -1;
      blushBoost = 0.3;
      break;
    }
    case "eat": {
      const P = clamp(v.eatP ?? 0, 0, 1);
      eatP = P;
      const total = 5;
      if (P < 0.14) {
        const g = P / 0.14;
        armPose = "hold";
        eyes = "sparkle";
        mouth = "tiny";
        hy += (1 - g) * 5;
        hx += (1 - g) * 2;
        blushBoost = 0.2;
      } else if (P < 0.8) {
        const u = (P - 0.14) / 0.66;
        const cyc = (u * total) % 1;
        const bi = Math.floor(u * total);
        const lunge = cyc < 0.22 ? Math.sin((cyc / 0.22) * Math.PI) : 0;
        armPose = "hold";
        hy += lunge * 2.4;
        hx += lunge * 1.2;
        eyes = lunge > 0.25 ? "open" : "joy";
        mouth = "chew";
        foodBite = (bi + Math.min(1, cyc * 4)) / total;
        bx += Math.sin(at * 6) * 0.7;
        hx += Math.sin(at * 6 + 1) * 0.6;
        by += Math.abs(Math.sin(at * 9)) * 0.5;
        blushBoost = 0.35;
      } else if (P < 0.92) {
        const g = (P - 0.8) / 0.12;
        eyes = "squeeze";
        mouth = g < 0.5 ? "tiny" : "tongue";
        hy -= Math.sin(g * Math.PI) * 2.2;
        blushBoost = 0.45;
      } else {
        armPose = "belly";
        eyes = "sparkle";
        mouth = "grin";
        hx += Math.sin(at * 8) * 0.5;
        by -= Math.abs(Math.sin(at * 10)) * 0.8;
        blushBoost = 0.55;
      }
      break;
    }
    case "groom":
    case "lickhand": {
      // membersihkan diri: jilat telapak tangan lalu usapkan ke wajah & telinga, gantian kiri-kanan
      armPose = "lick";
      mouth = "lick";
      const cyc = at * 1.55;
      lickSide = Math.floor(cyc) % 2 === 0 ? -1 : 1;
      lickPh = cyc % 1;
      eyes = lickPh < 0.5 ? "happy" : "joy";
      hx += lickSide * (lickPh < 0.5 ? 1.5 : 0.7);
      hy += lickPh < 0.5 ? Math.abs(Math.sin(at * 11)) * 0.7 : 0;
      headTilt = lickPh < 0.5 ? 0.5 : -0.3;
      earDroop = lickPh >= 0.5 ? 0.8 : 0;
      blushBoost = 0.25;
      break;
    }
    case "sleep": {
      brx = 23 * look.chub;
      bry = 12.5 + Math.sin(t * 1.4) * 0.9;
      by = -bry;
      hx = 13;
      hy = -15 - Math.sin(t * 1.4) * 0.6;
      hr = 15;
      earDroop = 4;
      legs = "tuck";
      eyes = "sleep";
      mouth = "tiny";
      break;
    }
    case "bury":
    case "hide": {
      eyes = v.sleepy ? "sleep" : "open";
      mouth = "tiny";
      earDroop = v.sleepy ? 3 : 0;
      if (!v.sleepy) hx += Math.sin(at * 1.7) * 0.8;
      blushBoost = 0.2;
      break;
    }
    case "dig": {
      brx = 22 * look.chub;
      bry = 15;
      by = -16;
      hx = 14;
      hy = -24 + Math.sin(at * 14) * 1.2;
      armPose = "dig";
      legs = "stand";
      mouth = "tiny";
      earBack = 1;
      break;
    }
    case "bath": {
      const phase = Math.floor(at * 1.1) % 2;
      if (phase === 0) {
        brx = 23 * look.chub;
        bry = 13;
        by = -13;
        hx = 10;
        hy = -16;
        legs = "up";
        eyes = "joy";
        mouth = "smile";
        earDroop = 2;
      } else {
        eyes = "joy";
        mouth = "smile";
        hx += Math.sin(at * 22) * 1.6;
        hy += Math.cos(at * 20) * 1.2;
      }
      blushBoost = 0.2;
      break;
    }
    case "drink": {
      bry = 18;
      by = -18;
      hx = 8;
      hy = -38;
      armPose = "reach";
      legs = "stand";
      mouth = Math.sin(at * 14) > 0 ? "tongue" : "tiny";
      eyes = "happy";
      headTilt = -1;
      break;
    }
    case "held": {
      // diangkat tangan hantu: perut menghadap kita, kaki mungil menggantung
      front = true;
      brx = 16.5 * look.chub;
      bry = HELD_BODY_RY;
      by = HELD_BODY_Y;
      hx = 1;
      hy = -50;
      legs = "hang";
      armPose = "heldArms";
      eyes = "open";
      mouth = "cat3";
      earDroop = -1;
      blushBoost = 0.3;
      if ((v.lick ?? 0) > 0.05) {
        armPose = "lickArm";
        eyes = "happy";
        mouth = "lick";
        earDroop = 1;
        headTilt = 1;
        hx += 1.2;
      } else if (v.squeeze && v.squeeze > 0.7) {
        eyes = "squeeze";
        mouth = "tongue";
      }
      break;
    }
    case "pet": {
      eyes = "joy";
      mouth = "smile";
      blushBoost = 0.55;
      bry *= 0.94;
      brx *= 1.05;
      by += 1;
      hy += 2.5;
      hx += Math.sin(at * 4) * 1.4;
      headTilt = 1;
      break;
    }
    case "hop":
    case "cheer": {
      legs = "tuck";
      armPose = "up";
      eyes = "sparkle";
      mouth = "grin";
      earDroop = -2;
      bry *= v.hop > 1 ? 1.06 : 0.9;
      brx *= v.hop > 1 ? 0.95 : 1.08;
      break;
    }
    case "stretch": {
      brx = 24 * look.chub;
      bry = 12.5;
      by = -12.5;
      hx = 17;
      hy = -19;
      armPose = "reach";
      legs = "stand";
      eyes = "sleep";
      mouth = "yawn";
      break;
    }
    case "beg": {
      armPose = "wave";
      eyes = "sparkle";
      mouth = "oh";
      by -= Math.abs(Math.sin(at * 5)) * 1.4;
      hy -= Math.abs(Math.sin(at * 5)) * 1.4;
      break;
    }
    case "sniff": {
      hx += Math.sin(at * 16) * 1.1;
      hy += Math.cos(at * 16) * 0.7;
      mouth = "tiny";
      break;
    }
    case "look": {
      // melihat sekitar: kepala menoleh, telinga berdiri, kadang mengangguk
      mouth = "tiny";
      earDroop = lg.y < -0.3 ? -1.8 : 0;
      hy += Math.sin(at * 3.4) * 0.4;
      break;
    }
    case "roll": {
      legs = "tuck";
      armPose = "up";
      eyes = "joy";
      mouth = "grin";
      earDroop = -1;
      blushBoost = 0.4;
      break;
    }
    case "alert": {
      legs = "stand";
      armPose = "up";
      eyes = "wide";
      mouth = "oh";
      earDroop = -2;
      hy -= 1 + Math.abs(Math.sin(at * 10)) * 1.5;
      break;
    }
    case "spar": {
      const ph2 = at * 9;
      legs = "stand";
      armPose = "box";
      eyes = "open";
      mouth = "grin";
      hx += 3 + Math.sin(ph2) * 0.9;
      by -= 1 + Math.abs(Math.sin(ph2)) * 0.8;
      hy -= 1 + Math.abs(Math.sin(ph2)) * 0.8;
      bry *= 1.06;
      blushBoost = 0.4;
      earBack = -1;
      break;
    }
    case "tussle": {
      legs = "tuck";
      armPose = "up";
      eyes = "squeeze";
      mouth = "grin";
      earDroop = -1;
      blushBoost = 0.5;
      break;
    }
    case "flop": {
      legs = "up";
      armPose = "up";
      eyes = "squeeze";
      mouth = "grin";
      hy += 4;
      brx *= 1.04;
      bry *= 0.92;
      blushBoost = 0.6;
      break;
    }
    case "tumble":
    case "fly":
    case "knocked": {
      legs = "dangle";
      armPose = "up";
      eyes = v.dizzy ? "spiral" : "wide";
      mouth = v.dizzy ? "tongue" : "scream";
      earDroop = -3;
      earBack = 2;
      showStars = !!v.dizzy;
      break;
    }
    case "dizzy": {
      eyes = "spiral";
      mouth = "tongue";
      hx += Math.sin(t * 3.1) * 1.4;
      earDroop = 2;
      showStars = true;
      blushBoost = 0.3;
      break;
    }
    case "scared": {
      eyes = "wide";
      mouth = "frown";
      earBack = 3;
      brx *= 0.96;
      hy += 1;
      sweat = true;
      break;
    }
    case "climb": {
      // memanjat tangga MEMBELAKANGI kamera; saat berhenti, kepalanya menoleh melihat sekitar
      back = true;
      brx = 14.5 * look.chub;
      bry = 19.5;
      by = -21;
      hx = 0;
      hy = -44;
      legs = "climb";
      armPose = "none";
      const calm = variant === "look" || variant === "wave";
      eyes = "open";
      mouth = calm ? "cat3" : "oh";
      const cp = v.climbPh ?? at * 6;
      const bob = Math.abs(Math.sin(cp));
      if (!calm) {
        by -= bob * 0.9;
        hy -= bob * 0.9;
        bx += Math.sin(cp) * 0.5;
        hx += Math.sin(cp) * 0.6;
      }
      blushBoost = 0.25;
      break;
    }
    case "glass": {
      // menyapa penonton lewat kaca (tampak depan)
      front = true;
      brx = 14.5 * look.chub;
      bry = 19.5;
      by = -21;
      hx = 0;
      hy = -43;
      hr *= 1.03;
      legs = "stand";
      armPose = "glass";
      eyes = "open";
      mouth = variant === "kiss" ? "oh" : "cat3";
      blushBoost = 0.4;
      earDroop = -1;
      break;
    }
    case "slide": {
      front = true;
      earBack = 3;
      if (variant === "head") {
        legs = "tuck";
        armPose = "up";
        eyes = "wide";
        mouth = "scream";
        tears = true;
        earBack = 4;
      } else if (variant === "back") {
        legs = "up";
        armPose = "up";
        eyes = "squeeze";
        mouth = "grin";
        tears = true;
      } else if (variant === "spin") {
        legs = "tuck";
        armPose = "up";
        eyes = "spiral";
        mouth = "tongue";
        earBack = 2;
      } else if (variant === "roll") {
        legs = "tuck";
        armPose = "up";
        eyes = "joy";
        mouth = "grin";
        earBack = 2;
      } else {
        legs = "hang";
        armPose = "up";
        eyes = "sparkle";
        mouth = "cat3";
        brx *= 0.95;
        bry *= 1.04;
        by = -16.5;
        hy = -34;
      }
      blushBoost = 0.4;
      break;
    }
  }

  const fear = v.fear ?? 0;
  if (fear > 0.05) {
    hx += Math.sin(t * 55) * 0.7 * fear;
    bx += Math.sin(t * 55 + 1) * 0.4 * fear;
  }
  const noBlink = eyes === "spiral" || eyes === "squeeze" || eyes === "sleep";
  if (!noBlink && v.mood < 0.28 && eyes === "open") {
    eyes = "sad";
    if (mouth === "w") mouth = "frown";
  }
  if (look.sparkle && v.mood > 0.8 && eyes === "open" && act !== "glass") eyes = "sparkle";
  if (v.blink > 0.5 && (eyes === "open" || eyes === "sparkle" || eyes === "wide" || eyes === "sad")) eyes = "blink";

  // ---------- skala ----------
  brx *= S; bry *= S; bx *= S; by *= S; hr *= S; hx *= S; hy *= S;

  // ---------- "puding": squash & stretch dengan alas badan tetap, kepala ikut menempel ----------
  const sqz = clamp(v.squeeze ?? 0, 0, 1);
  const jelRaw = ph ? ph.jel.y * 0.024 : 0;
  const jv = v.ragOn ? clamp(jelRaw, -0.12, 0.2) : clamp(jelRaw, -0.18, 0.26);
  let sqv = jv + clamp((ph?.body.y ?? 0) * 0.02, -0.08, 0.1) + stepSq + Math.sin(t * 2.7 + 1) * 0.012;
  sqv = clamp(sqv + sqz * 0.1, -0.2, 0.28);
  const botY = by + bry;
  const topY0 = by - bry;
  bry *= 1 - sqv;
  brx *= 1 + sqv * 0.8;
  by = botY - bry;
  hy += by - bry - topY0;
  hr *= 1 + sqv * 0.06;

  const ho = loc(ph?.head);
  hx += ho.x + lg.x * 0.9;
  hy += ho.y * 0.8 + lg.y * 0.4;
  const rr = loc(ph?.rear);
  const rag = v.ragOn && ph ? ph : undefined;
  const rg = (s: Sp | undefined) => (rag && s ? { x: s.x * dir, y: s.y } : { x: 0, y: 0 });

  // fitur wajah ikut bergeser saat menoleh (kesan 3D)
  const fm = act === "look" ? 1.7 : 1;
  const sym = front || back;
  const faceVis = back ? clamp(v.faceTurn ?? 0, 0, 1) : 1; // seberapa terlihat wajahnya
  const showFace = faceVis > 0.2;
  const sideLocal = (v.faceSide ?? 0) * dir;
  const look3d = clamp(lg.x + (crawl ? 0.9 : 0) + (back ? sideLocal * (1 - faceVis) * 1.6 : 0), -1, 1);
  const fOx = look3d * hr * (back ? 0.3 : 0.17) * fm;
  const fOy = clamp(lg.y, -1, 1) * hr * 0.11 * fm;
  const fx0 = hx + fOx;

  const cj = loc(ph?.cheek);
  const cheekAmt = clamp(look.cheek * 0.55 + v.cheek, 0, 1.25);
  const cheekR = (5.6 + cheekAmt * 7.4) * S * (1 + (v.pulse ?? 0) * 0.2);
  const cheekY = hy + hr * 0.34 + cj.y * 0.9;
  const cheekDX = hr * 0.66 + cheekAmt * 1.8 * S;

  const bodyClip: Clip = { x: bx, y: by, rx: brx, ry: bry };
  const headClip: Clip = { x: hx, y: hy, rx: hr, ry: hr * 0.95 };
  const cheekLc: Clip = { x: hx - cheekDX + cj.x * 0.6, y: cheekY, rx: cheekR, ry: cheekR * 0.92 };
  const cheekRc: Clip = { x: hx + cheekDX + cj.x * 0.6, y: cheekY, rx: cheekR, ry: cheekR * 0.92 };

  p.origin(v.x, v.y - v.hop + (v.sink ?? 0), v.dir);

  // ---------- tangan mungil: berjari tiga dengan bantalan telapak merah muda ----------
  const armC = mix(look.pattern === "tuxedo" ? "#FFF8EC" : mix(pal.belly, furBase, 0.3), "#FFD2D2", 0.3);
  const handY = hy + hr * 0.92;
  const handLine = shade(line, 0.1);
  const aLo = rg(ph?.aL);
  const aRo = rg(ph?.aR);
  const drawHand = (x: number, y: number, r = 2.7, tone = armC, pad = true) => {
    const R = r * S * 1.1;
    p.ellipse(x, y, R + 1, R + 1, handLine);
    p.ellipse(x, y, R, R * 0.96, tone);
    if (R >= 1.8) {
      // dua garis tipis memisahkan tiga jari mungil
      const fc = mix(shade(tone, -0.2), "#FF9EB5", 0.25);
      const fy0 = Math.round(y - R * 0.8);
      const fy1 = Math.round(y - R * 0.1);
      const o = Math.max(1, Math.round(R * 0.42));
      for (let yy = fy0; yy <= fy1; yy++) {
        p.px(x - o, yy, fc);
        p.px(x + o, yy, fc);
      }
      if (pad) {
        // bantalan telapak
        const pc = mix(tone, "#FF8FAA", 0.8);
        const py0 = Math.round(y + R * 0.28);
        p.rect(x - 1, py0, 2, 1, pc);
        p.px(x, py0 + 1, shade(pc, 0.12));
      }
      p.px(x - R * 0.5, y - R * 0.45, shade(tone, 0.4));
    }
  };

  // ---- lengan memanjat: di BELAKANG kepala (dilihat dari belakang) ----
  const limb = (x0: number, y0: number, x1: number, y1: number, c: string, th?: number) => {
    const n = Math.max(2, Math.ceil(Math.hypot(x1 - x0, y1 - y0)));
    for (let pass = 0; pass < 2; pass++) {
      for (let k = 0; k <= n; k++) {
        const u = k / n;
        const rr = (th ?? 1.7 * S + 0.6) + (pass === 0 ? 1 : 0);
        p.ellipse(lerp(x0, x1, u), lerp(y0, y1, u), rr, rr, pass === 0 ? line : c);
      }
    }
  };
  if (back && (act === "climb" || act === "wall")) {
    const cp = v.climbPh ?? at * 6;
    const still = variant === "look" || variant === "wave" || variant === "hang";
    for (let i = 0; i < 2; i++) {
      if (variant === "wave" && i === 1) continue;
      const f = cp + (i ? Math.PI : 0);
      const reach = still ? 0 : Math.sin(f);
      const sg = i ? 1 : -1;
      const hxx = hx + sg * hr * 0.5;
      const hyy = hy - hr * 1.0 - 2.6 * S - reach * 4.6 * S;
      limb(hx + sg * hr * 0.3, hy - hr * 0.35, hxx, hyy, furBase);
      drawHand(hxx, hyy, 3.1, mix(furBase, "#FFE6D5", 0.4), false);
    }
  }

  // ---------- kaki ----------
  const pinkC = mix(pal.belly, "#FFB9C8", 0.6);
  const pawC = look.pattern === "tuxedo" ? "#FFF8EC" : mix(pal.belly, furBase, 0.18);
  const feet: Blob[] = [];
  const legPhase = at * 11;
  const tap = Math.pow(Math.max(0, Math.sin(t * 1.7 + 2)), 12);
  const wig = Math.pow(Math.max(0, Math.sin(t * 2.9 + 0.6)), 10);
  const fL = rg(ph?.lL);
  const fR = rg(ph?.lR);
  let soles = false;
  let legBlobs: Blob[] = [];
  if (legs === "sit") {
    feet.push({ x: -brx * 0.46, y: -2 * S - wig * 1.2, rx: 4.6 * S, ry: 2.9 * S, c: pawC });
    feet.push({ x: brx * 0.5, y: -2 * S - tap * 1.8 * S, rx: 4.8 * S, ry: 3 * S, c: pawC });
  } else if (legs === "stand") {
    const a = Math.sin(legPhase) * 3 * S;
    const b = Math.sin(legPhase + Math.PI) * 3 * S;
    feet.push({ x: -brx * 0.52 + a, y: -2 * S - Math.max(0, Math.cos(legPhase)) * S * 1.4, rx: 3.9 * S, ry: 2.6 * S, c: pawC });
    feet.push({ x: brx * 0.5 + b, y: -2 * S - Math.max(0, -Math.cos(legPhase)) * S * 1.4, rx: 4.3 * S, ry: 2.8 * S, c: pawC });
    if (!front) feet.push({ x: -brx * 0.08 + b, y: -1.5 * S, rx: 3.4 * S, ry: 2.3 * S, c: shade(pawC, -0.08) });
  } else if (legs === "run") {
    const A = 6 * S;
    const B = 4.6 * S;
    for (let i = 0; i < 2; i++) {
      const f = rp + i * Math.PI;
      feet.push({
        x: -brx * 0.46 + Math.cos(f) * A,
        y: -2 * S - Math.max(0, -Math.sin(f)) * B,
        rx: 3.9 * S, ry: 2.5 * S, c: i ? shade(pawC, -0.1) : pawC,
      });
    }
  } else if (legs === "crawl") {
    // telapak mungil digambar lebih dulu dari badan: tertutup bulu, hanya ujungnya yang mengintip
    const A = CRAWL.A * S;
    const B = CRAWL.B * S;
    const pawP = mix(pawC, "#FFB9C8", 0.5);
    const paws = [
      { px: bx - brx * 0.3, ph: 0, front: false, near: false },
      { px: hx + hr * 0.62, ph: Math.PI, front: true, near: false },
      { px: bx - brx * 0.58, ph: Math.PI, front: false, near: true },
      { px: hx + hr * 0.12, ph: 0, front: true, near: true },
    ];
    for (const d of paws) {
      const f = cph + d.ph;
      const fx = d.px + Math.cos(f) * A;
      const fy = -1.3 * S - Math.max(0, -Math.sin(f)) * B;
      const rx = (d.front ? 3.2 : 4.2) * S;
      const ry = (d.front ? 2.2 : 2.4) * S;
      const col = d.near ? pawP : shade(pawP, -0.1);
      p.ellipse(fx, fy, rx + 1, ry + 1, line);
      p.ellipse(fx, fy, rx, ry, col);
      p.px(fx + rx * 0.5, fy - 0.5, shade(col, -0.3));
      p.px(fx + rx * 0.5, fy + 0.8, shade(col, -0.3));
    }
  } else if (legs === "climb") {
    const cp = v.climbPh ?? at * 6;
    const still = variant === "look" || variant === "wave" || variant === "hang";
    if (back) soles = true;
    for (let i = 0; i < 2; i++) {
      const f = cp + i * Math.PI;
      const up = still ? 0 : Math.max(0, Math.sin(f)) * 7 * S;
      feet.push({ x: (i ? 1 : -1) * (back ? brx * 0.52 : 8), y: -2 * S - up, rx: 3.9 * S, ry: 2.7 * S, c: back ? pinkC : pawC });
    }
  } else if (legs === "dangle") {
    const a = Math.sin(t * 13) * 2.4 * S;
    feet.push({ x: -brx * 0.4 + a + fL.x, y: 1 * S + fL.y, rx: 3.7 * S, ry: 3.1 * S, c: pawC });
    feet.push({ x: brx * 0.42 - a + fR.x, y: 1.5 * S + fR.y, rx: 3.9 * S, ry: 3.2 * S, c: pawC });
  } else if (legs === "hang") {
    soles = true;
    const kick = Math.sin(t * 7.5) * 1.8 * S;
    const kick2 = Math.sin(t * 7.5 + 2.1) * 1.8 * S;
    const by0 = by + bry;
    legBlobs = [
      { x: -brx * 0.42, y: by0 + 1.2 * S, rx: 3.6 * S, ry: 5.4 * S, c: furBase },
      { x: brx * 0.42, y: by0 + 1.2 * S, rx: 3.6 * S, ry: 5.4 * S, c: furBase },
    ];
    feet.push({ x: -brx * 0.47 + kick * 0.7, y: by0 + 7.6 * S + Math.max(0, kick) * 0.6, rx: 4.3 * S, ry: 3.7 * S, c: pinkC });
    feet.push({ x: brx * 0.47 + kick2 * 0.7, y: by0 + 8.2 * S + Math.max(0, kick2) * 0.6, rx: 4.3 * S, ry: 3.7 * S, c: pinkC });
  } else if (legs === "up") {
    const a = Math.sin(t * 13) * 2 * S;
    feet.push({ x: -brx * 0.22, y: -bry * 1.7 + a, rx: 3.5 * S, ry: 2.7 * S, c: pawC });
    feet.push({ x: brx * 0.36, y: -bry * 1.75 - a, rx: 3.7 * S, ry: 2.8 * S, c: pawC });
  } else {
    feet.push({ x: -brx * 0.3, y: -3 * S, rx: 3.4 * S, ry: 2.4 * S, c: pawC });
    feet.push({ x: brx * 0.4, y: -3 * S, rx: 3.6 * S, ry: 2.5 * S, c: pawC });
  }

  // ---------- telinga ----------
  const flick = Math.pow(Math.max(0, Math.sin(t * 1.9 + 0.7)), 30);
  const earR = 6 * look.earSize * S;
  const earY = hy - hr * 0.74 + earDroop * S;
  const eL = loc(ph?.earL);
  const eR = loc(ph?.earR);
  const ears: Blob[] = [
    {
      x: hx - hr * 0.66 - earBack * S + eL.x, y: earY + 1.5 * S + eL.y,
      rx: earR * 0.94, ry: earR, c: sym ? furBase : shade(furBase, -0.08),
    },
    {
      x: hx + hr * 0.66 - (sym ? -earBack : earBack) * S * (sym ? 0.4 : 1) + eR.x + flick * 0.8, y: earY + eR.y - flick * 1.6,
      rx: earR, ry: earR * 1.02, c: furBase,
    },
  ];
  if (sym) ears[0].x = hx - hr * 0.66 + earBack * S * 0.4 + eL.x;

  const tl = loc(ph?.tail);
  const tail: Blob = {
    x: bx - brx * 0.97 + tl.x, y: by + bry * 0.3 + tl.y + Math.sin(t * 5) * 0.5 + (act === "eat" ? Math.sin(at * 12) * 1.2 : 0),
    rx: 2.8 * S + 0.4, ry: 2.4 * S + 0.3, c: mix(pal.belly, furBase, 0.4),
  };
  const body: Blob = { x: bx, y: by, rx: brx, ry: bry, c: furBase };
  const haunch: Blob = crawl
    ? { x: bx, y: by, rx: brx, ry: bry, c: furBase }
    : back
    ? { x: bx, y: by + bry * 0.3, rx: brx * 1.04, ry: bry * 0.7, c: furBase }
    : front
    ? { x: bx + rr.x * 0.4, y: by + bry * 0.18 + rr.y * 0.7, rx: brx * 0.86, ry: bry * 0.86, c: furBase }
    : { x: bx - brx * 0.46 + rr.x * 1.2, y: by + bry * 0.2 + rr.y * 0.9, rx: brx * 0.62, ry: bry * 0.78, c: furBase };
  const head: Blob = { x: hx, y: hy, rx: hr, ry: hr * 0.95, c: furBase };
  const cheekBlobs: Blob[] = [
    { x: cheekLc.x, y: cheekLc.y, rx: cheekR, ry: cheekR * 0.92, c: shade(furBase, 0.03) },
    { x: cheekRc.x, y: cheekRc.y, rx: cheekR, ry: cheekR * 0.92, c: shade(furBase, 0.07) },
  ];

  // ---------- bulu: tepi bergelombang halus dengan jarak antar-gumpal SERAGAM (rapi & merata) ----------
  const fluff = look.fluff;
  const fw = loc(ph?.fur);
  const furBumps = (cx: number, cy: number, rx: number, ry: number, a0: number, a1: number, tag: number): Blob[] => {
    if (fluff < 0.05 || rx < 2 || ry < 2) return [];
    const bR = (0.85 + fluff * 1.0) * Math.max(0.85, S);
    const spacing = bR * 2.15;
    // tabel panjang busur: gumpal ditempatkan tiap jarak yang sama sepanjang kontur
    const N = 72;
    const ts: number[] = [];
    const cum: number[] = [0];
    for (let i = 0; i <= N; i++) ts.push(a0 + ((a1 - a0) * i) / N);
    for (let i = 1; i <= N; i++) {
      const tm = (ts[i] + ts[i - 1]) / 2;
      cum.push(cum[i - 1] + Math.hypot(rx * Math.sin(tm), ry * Math.cos(tm)) * (ts[i] - ts[i - 1]));
    }
    const total = cum[N];
    const n = Math.max(4, Math.round(total / spacing));
    const out: Blob[] = [];
    let j = 0;
    for (let k = 0; k <= n; k++) {
      const target = (total * k) / n;
      while (j < N - 1 && cum[j + 1] < target) j++;
      const u = (target - cum[j]) / Math.max(1e-6, cum[j + 1] - cum[j]);
      const tt = ts[j] + (ts[j + 1] - ts[j]) * u;
      const nx0 = Math.cos(tt) / rx;
      const ny0 = Math.sin(tt) / ry;
      const nl = Math.hypot(nx0, ny0) || 1;
      const nx = nx0 / nl;
      const ny = ny0 / nl;
      const free = Math.max(0, -ny);
      const sway = 0.5 + 0.5 * Math.sin(t * 2.2 + k * 0.55 + tag);
      out.push({
        x: cx + Math.cos(tt) * rx + nx * bR * 0.5 + fw.x * 0.2 * free,
        y: cy + Math.sin(tt) * ry + ny * bR * 0.5 + fw.y * 0.16 * free - sway * 0.25 * free * fluff,
        rx: bR, ry: bR, c: furBase,
      });
    }
    return out;
  };
  const bodyFur = furBumps(bx, by, brx, bry, Math.PI * 0.88, Math.PI * 2.12, 3);
  const headFur = furBumps(hx, hy, hr, hr * 0.95, Math.PI * 0.94, Math.PI * 2.06, 7);

  const silhouette: Blob[] = [...(sym ? [] : [tail]), ...ears, ...legBlobs, haunch, body, ...bodyFur, head, ...headFur, ...cheekBlobs, ...feet];
  for (const b of silhouette) p.ellipse(b.x, b.y, b.rx + 1, b.ry + 1, line);
  for (const b of silhouette) p.ellipse(b.x, b.y, b.rx, b.ry, b.c);

  // jari-jari kaki mungil
  for (const f of feet) {
    if (soles || f.rx < 2.6) continue;
    const toeC = shade(f.c, -0.3);
    if (legs === "crawl") {
      p.px(f.x + f.rx * 0.55, f.y - 0.6, toeC);
      p.px(f.x + f.rx * 0.55, f.y + 0.7, toeC);
    } else {
      p.px(f.x - f.rx * 0.32, f.y + f.ry * 0.2, toeC);
      p.px(f.x + f.rx * 0.32, f.y + f.ry * 0.2, toeC);
    }
  }
  if (back) {
    // ekor mungil menyembul di bawah pantat
    const tx0 = bx + tl.x * 0.3;
    const ty0 = by + bry * 0.88 + tl.y * 0.3;
    p.ellipse(tx0, ty0, 2.8 * S + 1, 2.2 * S + 1, line);
    p.ellipse(tx0, ty0, 2.8 * S, 2.2 * S, mix(pal.belly, furBase, 0.4));
  }
  if (soles) {
    for (const f of feet) {
      p.ellipse(f.x, f.y + 0.6, f.rx * 0.62, f.ry * 0.58, "#FF9FB4");
      p.px(f.x - 2, f.y - f.ry * 0.6, "#FFD0DA");
      p.px(f.x, f.y - f.ry * 0.8, "#FFD0DA");
      p.px(f.x + 2, f.y - f.ry * 0.6, "#FFD0DA");
    }
  }

  // ---------- perut & bayangan lembut ----------
  const bellyC = look.pattern === "tuxedo" || isPanda ? "#FFF8EC" : pal.belly;
  const heldBelly = act === "held";
  const bRx = brx * (look.pattern === "tuxedo" ? 0.72 : 0.6) * (heldBelly || front ? 1.08 : 1);
  const bRy = bry * (look.pattern === "tuxedo" ? 0.66 : 0.54) * (heldBelly ? 1.2 : front ? 1.1 : 1);
  if (!back && !crawl) patch(p, bx + (front ? 0 : brx * 0.1), by + bry * (heldBelly ? 0.1 : front ? 0.12 : 0.42), bRx, bRy, bellyC, [bodyClip]);

  patch(p, bx - brx * 0.3, by - bry * 0.48, brx * 0.46, bry * 0.3, furLight, [bodyClip]);
  patch(p, hx - hr * 0.34, hy - hr * 0.5, hr * 0.44, hr * 0.28, furLight, [headClip]);
  patch(p, bx + brx * 0.12, by + bry * 0.94, brx * 0.8, bry * 0.3, shade(furBase, -0.14), [bodyClip]);
  // saat berjalan, perut yang lebih terang hanya tampak sebagai jalur tipis di bagian bawah badan
  if (crawl) patch(p, bx + brx * 0.04, by + bry * 0.8, brx * 0.8, bry * 0.28, bellyC, [bodyClip]);

  if (look.pattern === "bercak") {
    patch(p, bx - brx * 0.48, by - bry * 0.3, brx * 0.3, bry * 0.34, furDark, [bodyClip]);
    patch(p, bx + brx * 0.38, by - bry * 0.5, brx * 0.22, bry * 0.24, furDark, [bodyClip]);
    patch(p, hx - hr * 0.58, hy - hr * 0.42, hr * 0.28, hr * 0.24, furDark, [headClip]);
  } else if (look.pattern === "belang") {
    if (back) {
      patch(p, bx, by - bry * 0.05, brx * 0.2, bry * 0.9, furDark, [bodyClip]);
      patch(p, hx, hy - hr * 0.45, hr * 0.17, hr * 0.5, furDark, [headClip]);
    } else {
      patch(p, bx - brx * 0.1, by - bry * 0.8, brx * 0.8, bry * 0.26, furDark, [bodyClip]);
      patch(p, hx, hy - hr * 0.74, hr * 0.46, hr * 0.24, furDark, [headClip]);
    }
  } else if (isPanda) {
    patch(p, bx - brx * 0.32, by - bry * 0.55, brx * 0.6, bry * 0.48, furDark, [bodyClip]);
    for (const e of ears) p.ellipse(e.x, e.y, e.rx * 0.92, e.ry * 0.92, furDark);
  } else if (look.pattern === "siam") {
    patch(p, bx - brx * 0.6, by - bry * 0.2, brx * 0.45, bry * 0.7, shade(furBase, -0.2), [bodyClip]);
    patch(p, hx, hy + hr * 0.52, hr * 0.5, hr * 0.34, shade(furBase, -0.16), [headClip]);
    for (const e of ears) p.ellipse(e.x, e.y, e.rx * 0.86, e.ry * 0.86, shade(furBase, -0.24));
  }

  if (back && faceVis < 0.5) {
    // pusaran bulu kecil di belakang kepala
    const wc2 = shade(furBase, -0.14);
    p.line(hx - 2.4, hy - hr * 0.46, hx - 0.4, hy - hr * 0.62, wc2);
    p.line(hx - 0.4, hy - hr * 0.62, hx + 1.8, hy - hr * 0.44, wc2);
    p.px(hx + 1.8, hy - hr * 0.4, wc2);
  }
  for (const e of ears) {
    if (back && faceVis < 0.45) {
      p.ellipse(e.x, e.y + 0.8 * S, e.rx * 0.5, e.ry * 0.5, shade(furBase, -0.1));
      p.px(e.x - e.rx * 0.4, e.y - e.ry * 0.44, shade(furLight, 0.1));
      continue;
    }
    if (isPanda || look.pattern === "siam") {
      p.ellipse(e.x, e.y + 0.6 * S, e.rx * 0.5, e.ry * 0.5, mix(pal.ear, furDark, 0.45));
    } else {
      p.ellipse(e.x, e.y + 0.7 * S, e.rx * 0.58, e.ry * 0.6, pal.ear);
      p.ellipse(e.x, e.y + 1.4 * S, e.rx * 0.3, e.ry * 0.3, shade(pal.ear, -0.18));
    }
    p.px(e.x - e.rx * 0.42, e.y - e.ry * 0.44, shade(furLight, 0.1));
  }

  if (isPanda && showFace) {
    patch(p, fx0 - hr * 0.46, hy + fOy - hr * 0.06, hr * 0.34, hr * 0.38, furDark, [headClip]);
    patch(p, fx0 + hr * 0.46, hy + fOy - hr * 0.06, hr * 0.34, hr * 0.38, furDark, [headClip]);
  }

  if (crawl) {
    // garis lembut yang memisahkan kepala dari gundukan badan (kontur belakang kepala)
    p.arc(hx, hy, hr * 0.99, Math.PI * 0.6, Math.PI * 0.98, mix(line, furBase, 0.55), Math.max(16, Math.round(hr * 2)));
  }
  // moncong krem (dekat dengan mata)
  const muzC = look.pattern === "tuxedo" || isPanda ? "#FFFBF2" : mix(pal.belly, "#FFFFFF", 0.35);
  if (showFace) patch(p, fx0, hy + fOy + hr * 0.4, hr * 0.38, hr * 0.26, muzC, [headClip, cheekLc, cheekRc]);

  // ---------- wajah: konstanta ----------
  const eyeR = Math.max(1.9, (1.55 + look.eyeSize * 4.4) * S);
  const eyeRy = eyeR * 1.2;
  const eyeY = hy - hr * 0.02 + headTilt * S + fOy;
  const eyeDX = hr * 0.55;
  const eyeCol = look.eye;
  const noseY = hy + hr * 0.27 + fOy;
  const eyeLine = mix(line, "#000000", 0.2);
  const my = noseY + 2;
  const mc = fx0;

  // (tangan mungil didefinisikan sebelum siluet, supaya bisa digambar di belakang kepala)
  if (armPose === "hold") {
    if (v.food && eatP >= 0 && eatP < 0.8) {
      const e = eatP < 0.14 ? smooth(eatP / 0.14) : 1;
      const fs = foodSize(v.food);
      const fx = lerp(hx + 13 * S, hx - 0.5 * S, e);
      const fyB = lerp(0, handY + 9 * S, e) + (eatP >= 0.14 ? Math.sin(at * 18) * 0.35 : 0);
      drawFood(p, v.food, fx, fyB, foodBite, true);
      const hh = fyB - fs.h * 0.45;
      drawHand(fx - fs.w / 2 - 0.5, hh, 2.5);
      drawHand(fx + fs.w / 2 + 0.5, hh - 0.5, 2.5);
    } else {
      const m = Math.sin(at * 9) * 0.8 * S;
      drawHand(hx - 4.4 * S, handY + 1 * S + m);
      drawHand(hx + 5 * S, handY + 1 * S - m);
    }
  } else if (armPose === "belly") {
    const tapB = Math.abs(Math.sin(at * 12)) * 1.4 * S;
    drawHand(hx - 3.2 * S, by - bry * 0.05 - tapB, 2.5);
    drawHand(hx + 4.4 * S, by - bry * 0.1 + tapB * 0.4, 2.5);
  } else if (armPose === "box") {
    const b = at * 9;
    drawHand(hx + hr * 0.7 + Math.max(0, Math.sin(b)) * 5 * S, hy + hr * 0.55, 2.7);
    drawHand(hx + hr * 0.75 + Math.max(0, -Math.sin(b)) * 5 * S, hy + hr * 0.75, 2.7);
  } else if (armPose === "lick") {
    // satu tangan naik ke mulut (dijilat) lalu mengusap pipi, mata, telinga; tangan lain menyangga
    const sd = lickSide;
    const mouthPx = fx0 + sd * hr * 0.2;
    const mouthPy = my + 0.5;
    const restX = hx - sd * hr * 0.42;
    drawHand(restX, handY + 1.5 * S, 2.5);
    late.push(() => {
      if (lickPh < 0.5) {
        const bobL = Math.sin(at * 22) * 0.7;
        drawHand(mouthPx, mouthPy + 1.2 * S + bobL, 3.0);
      } else {
        const u = smooth((lickPh - 0.5) / 0.5);
        const wx = lerp(mouthPx, hx + sd * hr * 0.74, u) + Math.sin(at * 13) * 0.7;
        const wy = lerp(mouthPy + 1.2 * S, hy - hr * 0.64, u) - Math.sin(u * Math.PI) * 1.2;
        drawHand(wx, wy, 3.0);
      }
    });
  } else if (armPose === "dig") {
    const m = Math.sin(at * 14) * 3 * S;
    drawHand(hx + 6 * S + m, hy + hr * 0.8);
    drawHand(hx + 10 * S - m, hy + hr * 0.9);
  } else if (armPose === "reach") {
    drawHand(hx + hr * 0.5, hy + hr * 0.95);
    drawHand(hx + hr * 0.95, hy + hr * 0.72);
  } else if (armPose === "up") {
    const m = Math.sin(t * (act === "tumble" || act === "fly" || act === "slide" || act === "roll" ? 14 : 7)) * 1.4 * S;
    drawHand(hx - hr * 0.88 + aLo.x, hy - hr * 0.3 + m + aLo.y);
    drawHand(hx + hr * 0.92 + aRo.x, hy - hr * 0.35 - m + aRo.y);
  } else if (armPose === "wave") {
    const m = Math.sin(at * 8) * 2.4 * S;
    drawHand(hx - hr * 0.72, hy + hr * 0.5 + m);
    drawHand(hx + hr * 0.78, hy + hr * 0.5 - m);
  } else if (armPose === "run") {
    for (let i = 0; i < 2; i++) {
      const f = rp + Math.PI + i * Math.PI;
      drawHand(
        hx + hr * 0.25 + Math.cos(f) * 5 * S,
        handY + 1.5 * S - Math.max(0, -Math.sin(f)) * 4 * S,
        2.5,
      );
    }
  } else if (armPose === "none") {
    if (back && variant === "wave") {
      late.push(() => drawHand(hx + hr * 1.02 + Math.sin(t * 9) * 2 * S, hy - hr * 0.05 + Math.sin(t * 9 + 1) * 2 * S, 2.8));
    }
  } else if (armPose === "glass") {
    for (let i = 0; i < 2; i++) {
      const press = Math.max(0, Math.sin(at * 5.2 + i * Math.PI));
      drawHand(hx + (i ? 1 : -1) * hr * 0.8, hy + hr * 0.3 - press * 3 * S, 3.0 + press * 0.3);
    }
  } else if (armPose === "heldArms") {
    const w1 = Math.sin(t * 3.2) * 1.4 * S;
    drawHand(hx - hr * 0.62, hy + hr * 0.98 + w1, 2.7);
    drawHand(hx + hr * 0.7, hy + hr * 1.0 - w1, 2.7);
  } else if (armPose === "lickArm") {
    const m = Math.sin(t * 13) * 0.9 * S;
    drawHand(hx - hr * 0.62, hy + hr * 1.0, 2.7);
    late.push(() => drawHand(fx0 + hr * 0.22 + m, my + 1.5 * S, 3.0));
  } else {
    const idleArm = mix(armC, furBase, 0.22);
    const sway = Math.sin(t * 2.4) * 0.6 * S;
    const hand = (x: number, r: number, oy: number) => drawHand(x, handY + 1.5 * S + oy, r, idleArm);
    const rub = Math.pow(Math.max(0, Math.sin(t * 0.9 + 1)), 14);
    hand(hx - hr * 0.4 + sway * 0.4, 2.5, sway * 0.5 - rub * 1.2 * S);
    hand(hx + hr * 0.46 - sway * 0.4, 2.6, -sway * 0.5 - rub * 1.2 * S);
  }

  // =====================================================================
  //  WAJAH — mata manik kecil yang lucu (pupil 80% kornea), hidung & mulut dekat dan tinggi
  // =====================================================================
  const openEye = (ex: number, sx: number) => {
    const r = Math.max(1.5, eyeR * sx);
    const ry = Math.max(1.9, eyeRy);
    const glow = shade(eyeCol, 0.4);
    const wide = eyes === "wide" || eyes === "sparkle" || viewer;
    const sad = eyes === "sad";
    const pxo = lg.x * r * 0.14;
    const pyo = lg.y * ry * 0.1 - 0.2;
    p.ellipse(ex, eyeY, r + 1, ry + 1, eyeLine);
    p.ellipse(ex, eyeY, r, ry, eyeCol);
    if (r > 2.6) {
      p.ellipseDither(ex, eyeY + ry * 0.5, r * 0.85, ry * 0.5, glow);
      p.px(ex, eyeY + ry - 1, glow);
    }
    // pupil hitam = 80% dari ukuran kornea
    p.ellipse(ex + pxo, eyeY + pyo, r * 0.8, ry * 0.8, "#150B14");
    // pantulan lembut di dasar mata: tampak basah & berkilau
    const rim = mix("#150B14", "#8A6A9A", 0.6);
    p.px(ex + pxo - 1, eyeY + pyo + ry * 0.8 - 0.5, rim);
    p.px(ex + pxo, eyeY + pyo + ry * 0.8 - 0.5, rim);
    // kilau besar 2x2 di kiri-atas + kilau kecil di kanan-bawah
    p.rect(ex - r * 0.5 + pxo * 0.5 - 0.5, eyeY - ry * 0.55 + pyo * 0.5, 2, 2, "#FFFFFF");
    p.px(ex + r * 0.45 + pxo * 0.5, eyeY + ry * 0.4 + pyo * 0.5, "#FFFFFF");
    if (wide && r > 2.2) p.px(ex + r * 0.05 + pxo * 0.4, eyeY + ry * 0.62, "rgba(255,255,255,0.7)");
    if (eyes === "sparkle" && Math.sin(t * 4 + ex) > 0.3) {
      const sxp = ex + r + 2;
      const syp = eyeY - ry - 1;
      p.px(sxp, syp, "#FFF6B0");
      p.px(sxp - 1, syp, "#FFFFFF");
      p.px(sxp + 1, syp, "#FFFFFF");
      p.px(sxp, syp - 1, "#FFFFFF");
      p.px(sxp, syp + 1, "#FFFFFF");
    }
    if (sad && ex > fx0) {
      p.px(ex + r * 0.5, eyeY + ry + 2, "#BFEAFF");
      p.px(ex + r * 0.5, eyeY + ry + 3, "#7CC8F5");
    }
  };

  const closedEye = (ex: number, kind: "happy" | "joy" | "sleep" | "blink") => {
    const w = Math.max(2, Math.round(eyeR * 1.3));
    const big = kind === "joy" ? 1 : 0;
    for (let i = -w; i <= w; i++) {
      const d = Math.round(Math.cos((i / w) * 1.25) * (1.6 + big * 0.8));
      const yy = kind === "happy" || kind === "joy" ? eyeY + 1.5 - d : eyeY - 1 + d;
      p.px(ex + i, yy, eyeLine);
      if (kind !== "blink" && Math.abs(i) < w * 0.6) p.px(ex + i, yy + (kind === "sleep" ? -1 : 1), eyeLine);
    }
    if (kind === "sleep") {
      p.px(ex + w + 1, eyeY + 1, eyeLine);
      p.px(ex + w + 2, eyeY + 2, eyeLine);
    }
    if (kind === "joy" && Math.sin(t * 6 + ex) > 0.4) p.px(ex + w + 1, eyeY - 2, "#FFF6B0");
  };

  const squeezeEye = (ex: number, left: boolean) => {
    const s = left ? 1 : -1;
    const w = Math.max(2, Math.round(eyeR * 1.2));
    p.line(ex - s * w, eyeY - w, ex + s * 1, eyeY, eyeLine);
    p.line(ex + s * 1, eyeY, ex - s * w, eyeY + w, eyeLine);
    p.line(ex - s * w + s, eyeY - w, ex + s * 2, eyeY, eyeLine);
    p.line(ex + s * 2, eyeY, ex - s * w + s, eyeY + w, eyeLine);
  };

  const spiralEye = (ex: number) => {
    const r = Math.max(eyeR, 2.6);
    const ry = Math.max(eyeRy, 3);
    p.ellipse(ex, eyeY, r + 1, ry + 1, eyeLine);
    p.ellipse(ex, eyeY, r, ry, "#FFFFFF");
    const turns = Math.PI * 4;
    for (let a = 0; a < turns; a += 0.3) {
      const k = a / turns;
      const ang = a + t * 9;
      p.px(ex + Math.cos(ang) * r * 0.9 * k, eyeY + Math.sin(ang) * ry * 0.9 * k, eyeLine);
    }
  };

  if (showFace) {
    const exL = fx0 - eyeDX;
    const exR = fx0 + eyeDX;
    const farR = 1 - clamp(look3d, 0, 1) * 0.3; // mata di sisi yang dituju tampak lebih sempit
    const farL = 1 - clamp(-look3d, 0, 1) * 0.3;
    if (eyes === "happy" || eyes === "joy" || eyes === "sleep" || eyes === "blink") {
      closedEye(exL, eyes);
      closedEye(exR, eyes);
    } else if (eyes === "squeeze") {
      squeezeEye(exL, true);
      squeezeEye(exR, false);
    } else if (eyes === "spiral") {
      spiralEye(exL);
      spiralEye(exR);
    } else {
      openEye(exL, farL);
      openEye(exR, farR);
    }

    if (tears) {
      for (const ex of [exL, exR]) {
        p.px(ex + dir * 0 - 3, eyeY + 2, "#BFEAFF");
        p.px(ex - 4, eyeY + 3, "#9EE0FF");
        p.px(ex - 5, eyeY + 4, "#7CC8F5");
      }
    }
    if (sweat) {
      p.sprite(hx + hr * 0.8, hy - hr * 0.5, [".a.", "aaa", "aaa", ".a."], { a: "#9EE0FF" });
      p.px(hx + hr * 0.8, hy - hr * 0.5 + 1, "#FFFFFF");
    }

    // rona pipi
    const blush = clamp(look.blush + blushBoost, 0, 1);
    if (blush > 0.05) {
      const bc = mix(pal.ear, "#FF5D8F", 0.3);
      const by0 = eyeY + Math.max(eyeRy, 2) + hr * 0.2;
      p.ellipseDither(fx0 + eyeDX + 4.8 * S, by0, 3.2 * S * (0.6 + blush * 0.55) + 0.5, 2 * S + 0.4, bc);
      p.ellipseDither(fx0 - eyeDX - 4.8 * S, by0, 3 * S * (0.6 + blush * 0.55) + 0.5, 1.9 * S + 0.4, bc, 1);
    }

    // hidung
    const noseWig = act === "sniff" || act === "idle" ? Math.round(Math.sin(t * (act === "sniff" ? 18 : 4)) * 0.6) : 0;
    const nx = fx0 + noseWig;
    p.px(nx - 1, noseY - 1, line);
    p.px(nx, noseY - 1, line);
    p.px(nx + 1, noseY - 1, line);
    p.rect(nx - 1, noseY, 3, 1, "#FF7FA0");
    p.px(nx, noseY + 1, "#E05C82");
    p.px(nx - 1, noseY, "#FFC2D4");

    // mulut
    if (mouth === "w") {
      p.px(mc - 2, my, line);
      p.px(mc - 1, my + 1, line);
      p.px(mc, my, line);
      p.px(mc + 1, my + 1, line);
      p.px(mc + 2, my, line);
    } else if (mouth === "cat3") {
      // :3 kucil dengan gigi taring mungil
      p.px(mc - 3, my, line);
      p.px(mc - 2, my + 1, line);
      p.px(mc - 1, my + 1, line);
      p.px(mc, my, line);
      p.px(mc + 1, my + 1, line);
      p.px(mc + 2, my + 1, line);
      p.px(mc + 3, my, line);
      p.px(mc + 1, my + 2, "#FFFFFF");
    } else if (mouth === "oh") {
      p.ellipse(mc, my + 1, 1.5, 1.8, line);
      p.px(mc, my + 1, "#FF8FA8");
    } else if (mouth === "scream") {
      p.ellipse(mc, my + 2, 3.3, 3.7, line);
      p.ellipse(mc, my + 2.6, 2.4, 2.6, "#E8587A");
      p.ellipse(mc, my + 3.6, 1.6, 1.1, "#FF9EB8");
      p.px(mc - 2, my, "#FFFFFF");
      p.px(mc + 2, my, "#FFFFFF");
    } else if (mouth === "frown") {
      p.px(mc - 2, my + 1, line);
      p.px(mc - 1, my, line);
      p.px(mc, my, line);
      p.px(mc + 1, my, line);
      p.px(mc + 2, my + 1, line);
    } else if (mouth === "chew") {
      if (Math.abs(Math.sin(at * 9)) > 0.5) {
        p.ellipse(mc, my + 1, 2.4, 2, line);
        p.ellipse(mc, my + 1.6, 1.4, 1, "#FF8FA8");
      } else {
        p.line(mc - 2, my, mc + 2, my, line);
      }
    } else if (mouth === "smile" || mouth === "lick") {
      p.px(mc - 3, my - 1, line);
      p.px(mc - 2, my, line);
      p.px(mc - 1, my + 1, line);
      p.px(mc, my + 1, line);
      p.px(mc + 1, my + 1, line);
      p.px(mc + 2, my, line);
      p.px(mc + 3, my - 1, line);
      if (mouth === "lick" && Math.sin(t * 13) > -0.2) {
        const tx = mc + lickSide * 2 + Math.round(Math.sin(t * 6.5) * 1.2);
        p.rect(tx - 1, my + 2, 2, 2, "#FF8FA8");
        p.px(tx - 1, my + 2, "#FFB4C4");
      }
    } else if (mouth === "grin") {
      p.ellipse(mc, my + 1, 3, 2.4, line);
      p.ellipse(mc, my + 1.4, 2, 1.5, "#E8587A");
      p.px(mc, my + 2, "#FF9EB8");
      p.px(mc - 1, my, "#FFFFFF");
      p.px(mc + 1, my, "#FFFFFF");
    } else if (mouth === "yawn") {
      p.ellipse(mc + 1, my + 1, 3 * S + 0.6, 3.4 * S + 0.6, line);
      p.ellipse(mc + 1, my + 2, 1.8 * S + 0.4, 1.8 * S + 0.4, "#FF8FA8");
    } else if (mouth === "tongue") {
      p.line(mc - 1, my, mc + 1, my, line);
      p.rect(mc, my + 1, 2, 2, "#FF8FA8");
    } else {
      p.px(mc - 1, my, line);
      p.px(mc, my + 1, line);
      p.px(mc + 1, my, line);
    }

    // kumis tipis yang bergoyang
    const whiskW = (act === "sniff" ? Math.sin(t * 16) * 1 : Math.sin(t * 2.4) * 0.5) + fw.y * 0.35;
    const wc = "rgba(255,255,255,0.62)";
    const wd = mix(pal.line, furBase, 0.45);
    for (let s = -1; s <= 1; s += 2) {
      for (let i = 0; i < 2; i++) {
        const y0 = noseY - 1 + i * 2.2;
        const x0 = fx0 + s * (hr * 0.5);
        const x1 = hx + s * (hr + 5 * S + 1.5) + fw.x * 0.4;
        const y1 = y0 + (i === 0 ? -2 : 2) + whiskW * s;
        p.line(x0, y0, x1, y1, i === 0 ? wc : wd);
      }
    }

  }

  if (act === "eat" && eatP >= 0.14 && eatP < 0.8 && Math.abs(Math.sin(at * 9)) > 0.6) {
    p.rect(mc - 1, my + 2, 1, 2, "#FFFFFF");
    p.rect(mc + 1, my + 2, 1, 2, "#FFFFFF");
  }
  if (act === "flop" || act === "tussle") {
    p.px(fx0 - eyeDX - 4, eyeY + 3, "#9EE0FF");
    p.px(fx0 + eyeDX + 4, eyeY + 3, "#9EE0FF");
  }

  if (v.sand > 0.02) {
    for (let i = 0; i < 16; i++) {
      const a = hash2(i, 21, 3) * Math.PI * 2;
      const rrr = hash2(i, 22, 5);
      const sx = bx + Math.cos(a) * brx * rrr;
      const sy = by + Math.sin(a) * bry * rrr;
      if (inEllipse(sx, sy, bodyClip) && hash2(i, 23, 6) < v.sand) p.px(sx, sy, "#FFF3D6");
    }
  }

  const ac = loc(ph?.acc);
  drawAccessory(p, look, hx, hy, hr, S, t, earY, eyeY, eyeDX, eyeR, ac.x, ac.y, fOx, showFace, crawl);

  // tangan yang harus di depan wajah (menjilat telapak)
  for (const f of late) f();

  if (showStars) {
    for (let i = 0; i < 3; i++) {
      const a = t * 5 + i * 2.09;
      const sx = hx + Math.cos(a) * hr * 0.95;
      const sy = hy - hr * 1.15 + Math.sin(a) * 3;
      star(p, sx, sy, ["#FFD84D", "#FF8FB0", "#8FD8FF"][i], "#FFFFFF");
    }
  }

  if (v.tint && v.clip) {
    ctx.fillStyle = `rgba(18,8,28,${v.tint.toFixed(2)})`;
    ctx.fillRect(v.clip.x0, v.clip.y0, v.clip.x1 - v.clip.x0, v.clip.y1 - v.clip.y0);
  }
  if (clipped) ctx.restore();
  p.reset();
}

function drawAccessory(
  p: Px, look: Look, hx: number, hy: number, hr: number, S: number, t: number,
  earY: number, eyeY: number, eyeDX: number, eyeR: number, jx: number, jy: number, fox: number, showFace: boolean, low = false,
) {
  const a = look.accessory;
  if (a === "none") return;
  const X = hx + jx;
  const Y = hy + jy;
  const EY = earY + jy;
  const top = Y - hr * 0.92;
  if (a === "pita") {
    const cx = X - hr * 0.78;
    const cy = EY + 2.5 * S;
    // pita: dua sayap segitiga yang menunjuk ke simpul, jelas terbaca meski kecil
    const c = "#FF4F87";
    const ww = 5.4 * S + 1.4;
    const hh = 3.1 * S + 1;
    const wing = (sg: number, w2: number, h2: number, col: string) => {
      for (let xi = 0; xi <= w2; xi++) {
        const half = Math.round(h2 * (xi / w2));
        p.rect(cx + sg * xi, cy - half, 1, half * 2 + 1, col);
      }
    };
    wing(-1, ww + 1, hh + 1, "#8E2246");
    wing(1, ww + 1, hh + 1, "#8E2246");
    p.ellipse(cx, cy, 1.4 * S + 1.4, 1.8 * S + 1.4, "#8E2246");
    wing(-1, ww, hh, c);
    wing(1, ww, hh, c);
    p.ellipse(cx, cy, 1.4 * S + 0.4, 1.8 * S + 0.4, "#C42B60");
    p.px(cx - ww * 0.55, cy - hh * 0.4, "#FF9EBB");
    p.px(cx + ww * 0.55, cy - hh * 0.4, "#FF9EBB");
  } else if (a === "jerami") {
    const cy = top - 1 * S;
    p.ellipse(X, cy, hr * 1.15, hr * 0.3, "#A8762F");
    p.ellipse(X, cy, hr * 1.08, hr * 0.24, "#E8C170");
    p.ellipse(X, cy - 3 * S, hr * 0.62, hr * 0.44, "#A8762F");
    p.ellipse(X, cy - 3 * S, hr * 0.55, hr * 0.38, "#F0CE84");
    p.rect(X - hr * 0.55, cy - 2 * S, hr * 1.1, 2 * S, "#FF5D8F");
    for (let i = -4; i <= 4; i++) p.px(X + i * 2.4 * S, cy + 1, "#C79B4E");
  } else if (a === "bunga") {
    const cx = X - hr * 0.88;
    const cy = EY + 3 * S;
    for (let i = 0; i < 5; i++) {
      const ang = (i / 5) * Math.PI * 2 + Math.sin(t) * 0.08;
      p.ellipse(cx + Math.cos(ang) * 3 * S, cy + Math.sin(ang) * 3 * S, 2.2 * S + 0.4, 2.2 * S + 0.4, "#FF85AE");
    }
    p.ellipse(cx, cy, 1.8 * S + 0.3, 1.8 * S + 0.3, "#FFE066");
    p.px(cx - 1, cy - 1, "#FFF6C0");
  } else if (a === "kacamata") {
    if (!showFace) return;
    const r = Math.max(eyeR, 2.4) + 2.4;
    for (const s of [-1, 1]) {
      p.arc(hx + fox + s * eyeDX, eyeY, r, 0, Math.PI * 2, "#FFD166", 28);
      p.arc(hx + fox + s * eyeDX, eyeY, r + 1, 0, Math.PI * 2, "rgba(90,60,20,0.5)", 28);
    }
    p.line(hx + fox - eyeDX + r, eyeY, hx + fox + eyeDX - r, eyeY, "#FFD166");
    p.line(hx + fox + eyeDX + r, eyeY, hx + hr, eyeY - 1, "#FFD166");
  } else if (a === "syal") {
    // saat berjalan dagu hampir di lantai: syal dinaikkan & tanpa ujung yang menjuntai
    const cy = hy + hr * (low ? 0.58 : 0.9);
    p.rect(hx - hr * 0.8, cy, hr * 1.6, 4 * S + 1, "#8E2246");
    p.rect(hx - hr * 0.75, cy, hr * 1.5, 3 * S + 1, "#E24B4B");
    for (let i = 0; i < 5; i++) p.rect(hx - hr * 0.75 + i * hr * 0.32, cy, 2 * S, 3 * S + 1, "#F7E7C8");
    if (!low) {
      p.rect(hx - hr * 0.7, cy + 3 * S, 4 * S + 1, 6 * S, "#8E2246");
      p.rect(hx - hr * 0.65, cy + 3 * S, 3 * S + 1, 5 * S, "#E24B4B");
      p.rect(hx - hr * 0.65, cy + 7 * S, 3 * S + 1, 1, "#F7E7C8");
    }
  } else if (a === "jamur") {
    const cy = top - 2 * S;
    p.ellipse(X, cy + 2 * S, hr * 0.95, hr * 0.24, "#F5E4C0");
    p.ellipse(X, cy, hr * 0.95, hr * 0.66, "#A32E20");
    p.ellipse(X, cy, hr * 0.88, hr * 0.58, "#FF5A47");
    p.ellipse(X - hr * 0.4, cy - hr * 0.16, 2.4 * S, 1.9 * S, "#FFF3E0");
    p.ellipse(X + hr * 0.34, cy - hr * 0.26, 2 * S, 1.6 * S, "#FFF3E0");
    p.ellipse(X + hr * 0.05, cy + hr * 0.16, 1.6 * S, 1.3 * S, "#FFF3E0");
  } else if (a === "mahkota") {
    const cy = top - 1 * S;
    const w = hr * 0.78;
    p.rect(X - w, cy - 2 * S, w * 2, 5 * S, "#9A6A10");
    p.rect(X - w + 1, cy - 1 * S, w * 2 - 2, 3 * S, "#FFD34D");
    for (let i = -1; i <= 1; i++) {
      const sx = X + i * w * 0.72;
      p.rect(sx - 1.5 * S, cy - 6 * S, 3 * S, 5 * S, "#9A6A10");
      p.rect(sx - 1 * S, cy - 5 * S, 2 * S, 4 * S, "#FFD34D");
      p.px(sx, cy - 6 * S, i === 0 ? "#FF4F87" : "#4FB8FF");
    }
    p.px(X - w + 2, cy, "#FFF3B0");
    p.px(X, cy + 1, "#FF4F87");
  } else if (a === "bintang") {
    star(p, X + hr * 0.82, EY + 3 * S, "#FFD84D", "#FFF6C0");
  }
}

/** Potret kecil untuk avatar UI. */
export function drawPortrait(ctx: CanvasRenderingContext2D, look: Look, size: number, t: number) {
  const p = new Px(ctx);
  ctx.clearRect(0, 0, size, size);
  const S = size / 66;
  drawHamster(
    p,
    {
      x: size / 2, y: size * 0.95, dir: 1, act: "idle", actT: t, cheek: 0.15,
      blink: t % 4 > 3.86 ? 1 : 0, mood: 1, hop: 0, scale: (S * 0.9) / HAMSTER_SIZE, sand: 0, shadow: false,
      gaze: { x: Math.sin(t * 0.9) * 0.6, y: Math.sin(t * 0.7) * 0.3 },
    },
    { ...look, scale: 1 },
    t,
  );
}

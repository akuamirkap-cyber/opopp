import { Px, clamp, rand, pick, lerp, smooth, wrapAngle } from "./pixel";
import {
  getTheme, getFood,
  type Look, type Settings, type Needs, type PetRec, type CageRec, type WeatherKind, type Food,
} from "./data";
import {
  makeLayout, buildBackdrop, buildFrame, buildRoom, drawHutBack, drawHutFront, drawMound, drawBowl,
  drawBottle, drawBath, drawWheelBack, drawWheelFront, drawBall, drawPoop, drawFood, drawParticle,
  drawFightCloud, drawNightOverlay, drawLadder, drawSlide, drawLights, drawGhostHand,
  slidePoint, HUT_HALF_DOOR, HUT_DOOR_H, TOWER_H, type Layout, type ParticleKind, type LadderGeo, type SlideGeo,
} from "./scene";
import { drawHamster, FurPhysics, HAMSTER_SIZE, heldHandDY, type HamsterVisual } from "./hamster";
import { WeatherFX } from "./weather";
import type { GameAudio } from "./audio";

export type Tool = { kind: "hand" } | { kind: "food"; id: string } | { kind: "broom" } | { kind: "ball" };

export type Hooks = {
  coin: (n: number, reason?: string) => void;
  xp: (n: number) => void;
  log: (text: string, emoji?: string) => void;
  achieve: (id: string) => void;
  stat: (kind: "tumble" | "fight" | "burrow" | "bonk") => void;
  event: (key: string, n?: number) => void;
  useFood: (id: string) => boolean;
  day: () => void;
  select: (id: string) => void;
};

export type PetBrief = { id: string; name: string; act: string; mood: number; cage: number; tier: number };

export type Snapshot = {
  needs: Needs;
  act: string;
  mood: number;
  cheek: number;
  poops: number;
  bowl: number;
  bottle: number;
  stash: number;
  clock: string;
  wheelSec: number;
  focus: number;
  zoomed: boolean;
  cages: number;
  cagePets: number;
  pets: PetBrief[];
  weather: WeatherKind;
  selectedId: string;
  tiers: number;
  tier: number;
};

type Particle = {
  x: number; y: number; vx: number; vy: number; life: number; max: number;
  kind: ParticleKind; size: number; color: string; g: number;
};

type Item = {
  uid: number; kind: "food" | "poop" | "ball"; food?: string;
  x: number; y: number; vy: number; tier: number;
};

type Plan = { tier: number; x: number; y: number; then: string; dur: number; sleepy: boolean };

interface Pet {
  id: string; name: string; look: Look; needs: Needs; cage: Cage;
  tier: number; plan: Plan | null;
  x: number; y: number; z: number; vx: number; vy: number; vz: number;
  dir: number; act: string; actT: number; actDur: number;
  tx: number; ty: number; next: string; nextDur: number; nextSleepy: boolean;
  cheek: number; pulse: number; blink: number; blinkT: number; sand: number; scale: number; vscale: number;
  phys: FurPhysics; gaze: { x: number; y: number };
  rot: number; spin: number; dizzy: number; sleepy: boolean; fear: number;
  eatItem: number; foodId: string; bites: number; eatStage: number; fromBowl: boolean; stashing: boolean;
  phi: number; tumT: number; landT: number; landRot: number; bounces: number; hitCd: number; power: number; rolling: boolean;
  locked: boolean; forceTumble: boolean; explore: boolean;
  climb: { g: LadderGeo; u: number; ph: number; pause: number; lookT: number; variant: string; lookDir: number; lastStep: number } | null;
  slide: { sl: SlideGeo; t: number; T: number; variant: string } | null;
  wall: { side: number; slipAt: number; h: number; phase: "climb" | "hang"; hangT: number; ph: number; lastStep: number } | null;
  glassVar: string; glassT: number; printCd: number; fogCd: number;
  heldT: number; lickT: number; lickLeft: number; squeezeV: number; lickCd: number;
  lookT: number; lookIdx: number; rollV: number;
  gait: number; faceT: number; faceTarget: number; faceSide: number;
  bubbleText: string; bubbleUntil: number; passiveCd: number;
}

type Fight = {
  a: Pet; b: Pet; Lp: Pet; Rp: Pet;
  phase: "chase" | "spar" | "tussle" | "flop" | "zoom";
  t: number; cx: number; cy: number; th: number; bop: number; bopN: number; puffCd: number; sqCd: number;
  tgt: { x: number; y: number }; tgtT: number;
};

const GRAV = 300;
const NEED_DECAY = { food: 0.09, water: 0.1, happy: 0.062, energy: 0.045, clean: 0.034 };
const BUSY = ["hide", "bury", "tumble", "fly", "knocked", "dizzy", "held", "pet", "scared", "climb", "slide", "skid", "wall", "roll"];
const RAGDOLL = ["tumble", "fly", "knocked"];
const LIMBS_FREE = [...RAGDOLL, "roll"];
const ROTATING = ["fly", "knocked", "dizzy", "tussle", "flop", "slide", "roll"];

const CHATTER: Record<string, string[]> = {
  idle: ["hihi~", "hmm hmm 🎵", "duk duk duk", "*endus endus*"],
  beg: ["lapaaar…", "camilan dong?", "pipi kosong :("],
  run: ["wuuush!", "aku cepat!", "lari terus!"],
  sleep: ["zzz…", "mimpi kuaci…", "hoaaam"],
  pet: ["sukaaa ♡", "purrr~", "lagi dong!"],
  held: ["hangat~", "pelan-pelan~", "hihi geli!"],
  bath: ["segeer!", "bulu wangi~"],
  dig: ["gali gali!", "harta karun!"],
  groom: ["rapi dulu~", "bulu halus ✨"],
  hop: ["YEAY!", "lompat!"],
  tumble: ["waaaa!!", "muter muter!!", "tolooong~ hihi"],
  dizzy: ["pusing… 😵", "bintang-bintang…", "dunia muter…"],
  scared: ["duar?!", "kaget!!", "uhuhu…"],
  spar: ["hiya!", "pok pok!", "ayo lagi!"],
  tussle: ["hihi!", "kena kamu!", "grrr~ 😝"],
  bury: ["hangat…", "gali gali~", "ssst, ngumpet"],
  hide: ["ssst…", "cilukba!", "di rumah aja"],
  climb: ["hup hup!", "naik naik~", "tinggi banget!"],
  slide: ["WHEEE!", "kyaaa!!", "meluncuuur!"],
  glass: ["halooo!", "hei kamu!", "main yuk?", "lihat aku!"],
  wall: ["bisa kok!", "dikit lagi…", "hup!"],
  lick: ["slurp~", "bersih-bersih"],
  look: ["hmm?", "ada apa ya?", "kanan… kiri…", "wah, tinggi!"],
  roll: ["gelinding~!", "wuuu~ muter!", "hihi, bola hamster!"],
};

function makePet(rec: PetRec, cage: Cage): Pet {
  const L = cage.L;
  const b = L.bands[0];
  return {
    id: rec.id, name: rec.name, look: rec.look, cage,
    needs: { food: rand(65, 85), happy: rand(75, 92), energy: rand(78, 95), clean: rand(82, 95), water: rand(65, 85) },
    tier: 0, plan: null,
    x: rand(L.minX + 20, L.maxX - 20), y: rand(b.minY, b.maxY), z: 0, vx: 0, vy: 0, vz: 0,
    dir: Math.random() < 0.5 ? 1 : -1, act: "idle", actT: 0, actDur: rand(1, 3),
    tx: 0, ty: 0, next: "", nextDur: 0, nextSleepy: false,
    cheek: 0.1, pulse: 0, blink: 0, blinkT: rand(1, 5), sand: 0, scale: 1, vscale: 1,
    phys: new FurPhysics(), gaze: { x: 0, y: 0 },
    rot: 0, spin: 0, dizzy: 0, sleepy: false, fear: 0,
    eatItem: 0, foodId: "kuaci", bites: 0, eatStage: 0, fromBowl: false, stashing: false,
    phi: 0, tumT: 0, landT: 0, landRot: 1.45, bounces: 0, hitCd: 0, power: 0, rolling: false,
    locked: false, forceTumble: false, explore: false,
    climb: null, slide: null, wall: null,
    glassVar: "tap", glassT: 0, printCd: 0, fogCd: 0,
    heldT: 0, lickT: rand(2, 4), lickLeft: 0, squeezeV: 0, lickCd: 0,
    lookT: 0, lookIdx: 0, rollV: 0,
    gait: 0, faceT: 0, faceTarget: 0, faceSide: 0,
    bubbleText: "", bubbleUntil: 0, passiveCd: rand(6, 12),
  };
}

// =====================================================================
//  CAGE = satu aquarium (1 tingkat atau menara 3 tingkat)
// =====================================================================
class Cage {
  eng: Engine;
  idx: number;
  rec: CageRec;
  W = 0;
  H = 0;
  L: Layout;
  cv: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  p: Px;
  bgA: HTMLCanvasElement | null = null;
  bgB: HTMLCanvasElement | null = null;
  fg: HTMLCanvasElement | null = null;
  bgKey = "";
  pets: Pet[] = [];
  items: Item[] = [];
  particles: Particle[] = [];
  bowl = 0.75;
  bottle = 0.9;
  stash = 2;
  wheel = { ang: 0, speed: 0, occ: null as Pet | null, turbo: 0, willTumble: false };
  fight: Fight | null = null;
  shake = 0;
  poopTimer = rand(30, 50);
  tickCd = 0;
  streakCd = 0;
  wob = 0;
  uid = 1;
  pointer = { x: 0, y: 0, inside: false };
  grab: { pet: Pet | null; mode: "none" | "pet" | "carry"; moved: number } = { pet: null, mode: "none", moved: 0 };
  private petCd = 0;
  private coinCd = 0;
  private brushCd = 0;

  constructor(eng: Engine, idx: number, rec: CageRec, W: number, H: number) {
    this.eng = eng;
    this.idx = idx;
    this.rec = rec;
    this.cv = document.createElement("canvas");
    this.ctx = this.cv.getContext("2d")!;
    this.p = new Px(this.ctx);
    this.W = W;
    this.H = H;
    this.cv.width = W;
    this.cv.height = H;
    this.ctx.imageSmoothingEnabled = false;
    this.L = makeLayout(W, H, rec.tiers === 3 ? 3 : 1);
  }

  get tall() { return this.L.tiers === 3; }

  resize(W: number, H: number) {
    this.W = W;
    this.H = this.tall ? TOWER_H : H;
    this.cv.width = W;
    this.cv.height = this.H;
    this.ctx.imageSmoothingEnabled = false;
    this.L = makeLayout(W, this.H, this.tall ? 3 : 1);
    this.bgKey = "";
    for (const pt of this.pets) {
      const [lo, hi] = this.xRange(pt.tier);
      const b = this.band(pt);
      pt.x = clamp(pt.x, lo, hi);
      pt.y = clamp(pt.y, b.minY, b.maxY);
    }
    for (const it of this.items) {
      const b = this.L.bands[it.tier] ?? this.L.bands[0];
      it.x = clamp(it.x, 12, W - 12);
      it.y = clamp(it.y, b.minY - 24, b.maxY);
    }
  }

  kBase(pet: Pet) {
    return pet.look.scale * pet.scale * HAMSTER_SIZE;
  }

  band(pet: Pet) {
    return this.L.bands[pet.tier] ?? this.L.bands[0];
  }

  /** Rentang x yang boleh diinjak pada suatu tingkat. */
  xRange(tier: number): [number, number] {
    const L = this.L;
    if (tier <= 0) return [L.x0 + 10, L.x1 - 10];
    const sh = L.shelves.find((s) => s.tier === tier);
    if (!sh) return [L.x0 + 10, L.x1 - 10];
    return sh.side === "R" ? [sh.x0 + 1, sh.x1 - 8] : [sh.x0 + 8, sh.x1 + 2];
  }

  tierFor(x: number, y: number) {
    const L = this.L;
    let t = L.tierAtY(y);
    while (t > 0) {
      const [lo, hi] = this.xRange(t);
      if (x >= lo - 4 && x <= hi + 4) break;
      t--;
    }
    return t;
  }

  // ---------- util ----------
  setAct(pet: Pet, a: string, dur: number) {
    if (this.wheel.occ === pet && a !== "run" && a !== "tumble") this.wheel.occ = null;
    pet.act = a;
    pet.actT = 0;
    pet.actDur = dur;
    if (a === "eat") {
      pet.bites = 0;
      pet.eatStage = 0;
    }
    if (a !== "hide") pet.vscale = 1;
    if (a !== "hide" && a !== "bury") pet.sleepy = false;
    if (a !== "climb") pet.climb = null;
    if (a !== "slide") pet.slide = null;
    if (a !== "wall") pet.wall = null;
    if (a !== "fly" && a !== "knocked") pet.rolling = false;
    if (!ROTATING.includes(a)) pet.rot = 0;
  }

  goTo(pet: Pet, x: number, y: number, then: string, dur = 3, sleepy = false, tier = pet.tier) {
    if (tier !== pet.tier && this.L.tiers > 1) {
      pet.plan = { tier, x, y, then, dur, sleepy };
      this.stepPlan(pet);
      return;
    }
    pet.plan = null;
    const [lo, hi] = this.xRange(pet.tier);
    const b = this.band(pet);
    pet.tx = clamp(x, lo, hi);
    pet.ty = clamp(y, b.minY - 4, b.maxY + 2);
    pet.next = then;
    pet.nextDur = dur;
    pet.nextSleepy = sleepy;
    this.setAct(pet, "walk", 14);
  }

  /** Menuju tangga / perosotan berikutnya sampai tingkat tujuan tercapai. */
  stepPlan(pet: Pet) {
    const pl = pet.plan;
    if (!pl) return;
    const L = this.L;
    if (pet.tier === pl.tier) {
      pet.plan = null;
      this.goTo(pet, pl.x, pl.y, pl.then, pl.dur, pl.sleepy, pl.tier);
      return;
    }
    if (pet.tier < pl.tier) {
      const g = L.ladders[pet.tier];
      if (!g) { pet.tier = pl.tier; this.stepPlan(pet); return; }
      pet.tx = g.xb;
      pet.ty = g.yb;
      pet.next = "climb";
    } else {
      const sl = L.slides.find((s) => s.from === pet.tier);
      if (!sl) { pet.tier = pl.tier; this.stepPlan(pet); return; }
      pet.tx = sl.xs;
      pet.ty = sl.ys;
      pet.next = "slide";
    }
    pet.nextDur = 99;
    pet.nextSleepy = false;
    this.setAct(pet, "walk", 18);
  }

  say(pet: Pet, key: string, force = false) {
    if (!force && this.eng.t < pet.bubbleUntil) return;
    const arr = CHATTER[key];
    if (!arr || !arr.length) return;
    pet.bubbleText = pick(arr);
    pet.bubbleUntil = this.eng.t + 2.4;
  }

  sayText(pet: Pet, text: string, dur = 2.4) {
    pet.bubbleText = text;
    pet.bubbleUntil = this.eng.t + dur;
  }

  burst(kind: ParticleKind, x: number, y: number, n: number, color: string, spread = 18, up = -22) {
    const count = Math.round(n * clamp(this.eng.settings.particles, 0, 2));
    for (let i = 0; i < count; i++) {
      if (this.particles.length > 280) break;
      this.particles.push({
        x: x + rand(-4, 4), y: y + rand(-4, 4),
        vx: rand(-spread, spread), vy: up + rand(-12, 8),
        life: 1, max: rand(0.7, 1.5), kind, size: rand(0.8, 1.7), color,
        g: kind === "heart" || kind === "zzz" || kind === "puff" ? -6 : kind === "hay" ? 30 : 46,
      });
    }
  }

  /** Partikel statis (jejak kaki di kaca, embun napas). */
  stamp(kind: ParticleKind, x: number, y: number, max: number) {
    if (this.particles.length > 280) return;
    this.particles.push({ x, y, vx: 0, vy: 0, life: 1, max, kind, size: 1, color: "#FFFFFF", g: 0 });
  }

  mate(pet: Pet): Pet | null {
    const list = this.pets.filter((o) => o !== pet && o.tier === pet.tier && !o.locked && !BUSY.includes(o.act) && o.act !== "run" && o.act !== "eat" && o.act !== "drink" && o.act !== "glass");
    return list.length ? pick(list) : null;
  }

  // ---------- keputusan ----------
  goProp(pet: Pet, prop: "bowl" | "bottle" | "bath" | "wheel" | "hut" | "mound", then: string, dur: number, sleepy = false) {
    const L = this.L;
    switch (prop) {
      case "bowl": return this.goTo(pet, L.bowl.x, L.bowl.y - 2, then, dur, sleepy, L.tierOf.bowl);
      case "bottle": return this.goTo(pet, L.bottle.drinkX, L.bottle.drinkY, then, dur, sleepy, L.tierOf.bottle);
      case "bath": return this.goTo(pet, L.bath.x, L.bath.y - 2, then, dur, sleepy, L.tierOf.bath);
      case "wheel": return this.goTo(pet, L.wheel.x, L.wheel.y - 5, then, dur, sleepy, L.tierOf.wheel);
      case "hut": return this.goTo(pet, L.hut.x, L.hut.y + 3, then, dur, sleepy, L.tierOf.hut);
      case "mound": return this.goTo(pet, L.mound.x, L.mound.y - 0.5, then, dur, sleepy, L.tierOf.mound);
    }
  }

  tierCost(pet: Pet, it: Item) {
    return Math.abs(it.x - pet.x) + Math.abs(it.tier - pet.tier) * 150;
  }

  chooseAction(pet: Pet) {
    const n = pet.needs;
    const L = this.L;
    const wk = this.eng.fx.kind;
    const foods = this.items.filter((i) => i.kind === "food");
    const wheelFree = !this.wheel.occ || this.wheel.occ === pet;
    if (pet.explore && pet.tier === 2 && L.tiers > 1) {
      // jelajah menara: sesampai di puncak, turun lagi lewat perosotan
      pet.explore = false;
      const [l0, h0] = this.xRange(0);
      const bb = L.bands[0];
      return this.goTo(pet, rand(l0 + 20, h0 - 20), rand(bb.minY, bb.maxY), "sniff", 2, false, 0);
    }
    if (n.energy < 16) {
      if (Math.random() < 0.6) return this.startHide(pet, 24, true);
      return this.startBury(pet, 22, true);
    }
    if (n.food < 34) {
      if (foods.length) {
        const f = foods.reduce((a, b) => (this.tierCost(pet, a) < this.tierCost(pet, b) ? a : b));
        return this.goEat(pet, f.food!, f.uid, f.x, f.y, false, f.tier);
      }
      if (this.bowl > 0.05) return this.goEat(pet, "kuaci", 0, L.bowl.x, L.bowl.y - 2, true, L.tierOf.bowl);
      this.setAct(pet, "beg", 3);
      this.say(pet, "beg");
      return;
    }
    if (n.water < 32 && this.bottle > 0.05) return this.goProp(pet, "bottle", "drink", 2.8);
    if (n.clean < 34) return this.goProp(pet, "bath", "bath", 5);
    if (n.happy < 40) {
      const ball = this.items.find((i) => i.kind === "ball");
      if (ball && Math.random() < 0.45) {
        pet.eatItem = ball.uid;
        return this.goTo(pet, ball.x - 10, ball.y, "play", 6, false, ball.tier);
      }
      if (wheelFree) return this.goWheel(pet, rand(9, 15));
    }
    if (wk === "storm" && Math.random() < 0.3) return this.startHide(pet, rand(8, 14), n.energy < 60);
    if ((wk === "rain" || wk === "snow") && Math.random() < 0.2) {
      return Math.random() < 0.5 ? this.startBury(pet, rand(8, 14), n.energy < 60) : this.startHide(pet, rand(8, 14), n.energy < 60);
    }
    const rl = Math.random();
    if (rl < 0.1) return this.setAct(pet, "look", rand(3.4, 5));
    if (rl < 0.17 && n.energy > 30) return this.startRoll(pet);
    const r = Math.random();
    const tower = L.tiers > 1;
    const [lo, hi] = this.xRange(pet.tier);
    const b = this.band(pet);
    if (r < 0.14) {
      this.goTo(pet, rand(lo + 8, hi - 8), rand(b.minY, b.maxY), Math.random() < 0.5 ? "sniff" : "idle", rand(1.6, 3.4));
    } else if (r < 0.25) this.setAct(pet, "groom", rand(3.2, 5.2));
    else if (r < 0.32) this.setAct(pet, "idle", rand(2, 4.5));
    else if (r < 0.37) this.setAct(pet, "sniff", rand(1.2, 2.2));
    else if (r < 0.42) this.setAct(pet, "dig", rand(2.5, 4));
    else if (r < 0.46) this.setAct(pet, "stretch", 2.2);
    else if (r < 0.5) this.setAct(pet, "shake", 1.2);
    else if (r < 0.57 && n.energy > 45 && wheelFree) this.goWheel(pet, rand(6, 11));
    else if (r < 0.61) this.hop(pet, 1.6);
    else if (r < 0.66) this.startBury(pet, rand(7, 12), n.energy < 55);
    else if (r < 0.7) this.startHide(pet, rand(6, 11), n.energy < 55);
    else if (r < 0.78) {
      // menyapa penonton lewat kaca depan
      this.goTo(pet, rand(lo + 12, hi - 12), b.maxY, "glass", rand(4.5, 7.5));
    } else if (r < 0.82 && pet.tier === 0) {
      this.goTo(pet, Math.random() < 0.5 ? L.x0 + 14 : L.x1 - 14, b.maxY - 4, "wall", 6);
    } else if (r < 0.9 && tower) {
      const tiers = [0, 1, 2].filter((t) => t !== pet.tier);
      const t = pick(tiers);
      const [l2, h2] = this.xRange(t);
      const bb = L.bands[t];
      this.goTo(pet, rand(l2 + 14, h2 - 14), rand(bb.minY, bb.maxY), Math.random() < 0.5 ? "sniff" : "idle", rand(1.6, 3), false, t);
    } else if (r < 0.94 && tower) {
      const sl = L.slides.filter((s) => s.to === pet.tier);
      if (sl.length) {
        const s = pick(sl);
        const side = s.xe < L.W / 2 ? 1 : -1;
        this.goTo(pet, s.xe + side * rand(10, 24), s.ye + rand(-3, 3), "idle", rand(4, 7.5));
      } else this.setAct(pet, "idle", rand(1.5, 3));
    } else if (r < 0.97 && n.energy > 35) {
      const m = this.mate(pet);
      if (m) this.startFight(pet, m);
      else this.setAct(pet, "idle", rand(1.5, 3));
    } else this.setAct(pet, "idle", rand(1.5, 3));
  }

  startRoll(pet: Pet) {
    this.setAct(pet, "roll", rand(2.2, 3.2));
    pet.rollV = (Math.random() < 0.5 ? -1 : 1) * rand(62, 86);
    pet.dir = pet.rollV >= 0 ? 1 : -1;
    pet.rot = 0;
    this.say(pet, "roll", true);
    this.eng.audio.play("whoosh");
  }

  goEat(pet: Pet, foodId: string, itemUid: number, x: number, y: number, fromBowl: boolean, tier: number) {
    pet.foodId = foodId;
    pet.eatItem = itemUid;
    pet.fromBowl = fromBowl;
    this.goTo(pet, x, y, "eat", 5.4, false, tier);
  }

  goWheel(pet: Pet, dur: number) {
    this.goProp(pet, "wheel", "run", dur);
  }

  startHide(pet: Pet, dur: number, sleepy: boolean) {
    this.goProp(pet, "hut", "hide", dur, sleepy);
  }

  startBury(pet: Pet, dur: number, sleepy: boolean) {
    this.goProp(pet, "mound", "bury", dur, sleepy);
  }

  hop(pet: Pet, power = 1) {
    this.setAct(pet, "hop", 2);
    pet.vz = 55 + 32 * power;
    pet.z = 0.01;
    pet.needs.happy = clamp(pet.needs.happy + 2.5 * power, 0, 100);
    pet.phys.squish(55);
    this.eng.audio.play("pop");
    this.burst("sparkle", pet.x, pet.y - 20 * this.kBase(pet), 5, "#FFE873");
  }

  exitHut(pet: Pet) {
    const L = this.L;
    this.burst("puff", L.hut.x, L.hut.y - 8, 3, "#FFFFFF", 14, -10);
    this.eng.audio.play("pop");
    pet.y = L.hut.y + 9;
    pet.x = L.hut.x;
    pet.vscale = 1;
    if (pet.sleepy) {
      this.setAct(pet, "stretch", 2.2);
      this.sayText(pet, "hoaaam… segar!");
      this.eng.hooks.xp(4);
    } else this.hop(pet, 1.2);
  }

  scare(pet: Pet) {
    if (pet.locked || BUSY.includes(pet.act) || pet.act === "run") return;
    pet.fear = 1;
    this.setAct(pet, "scared", 1.3);
    this.say(pet, "scared", true);
    this.eng.audio.play("squeak");
    this.burst("sweat", pet.x + 10 * this.kBase(pet), pet.y - 44 * this.kBase(pet), 1, "#9EE0FF", 6, -16);
    pet.phys.kick(0, -40);
  }

  // ---------- ragdoll ----------
  startFly(pet: Pet, vx: number, vz: number, vy: number, spin: number, kind: "fly" | "knocked") {
    if (this.grab.pet === pet) this.grab = { pet: null, mode: "none", moved: 0 };
    this.setAct(pet, kind, 99);
    pet.vx = vx;
    pet.vy = vy;
    pet.vz = vz;
    pet.spin = spin;
    pet.bounces = 0;
    pet.landT = 0;
    pet.rolling = false;
    pet.power = Math.hypot(vx, vz);
    pet.hitCd = 0.25;
    pet.locked = false;
    pet.plan = null;
  }

  startTumble(pet: Pet) {
    const w = this.wheel;
    w.occ = pet;
    w.willTumble = false;
    this.setAct(pet, "tumble", 99);
    w.occ = pet;
    pet.phi = 0;
    pet.tumT = 0;
    pet.dizzy = 0;
    const a = this.eng.audio;
    a.play("whoosh");
    a.play("boing");
    this.say(pet, "tumble", true);
    this.eng.hooks.achieve("tumble");
    this.eng.hooks.stat("tumble");
    this.eng.hooks.event("tumble");
    this.eng.hooks.log(`${pet.name} kebablasan di roda dan ikut berputar kencang!`, "🌀");
    pet.phys.kick(0, -50);
  }

  releaseTumble(pet: Pet) {
    const w = this.wheel;
    const L = this.L;
    const Rl = L.wheel.r - 4;
    const sp = Math.max(w.speed, 3.6);
    let vx = sp * Rl * Math.cos(pet.phi);
    let vz = sp * Rl * Math.sin(pet.phi);
    let vy = 0;
    const friends = this.pets.filter((o) => o !== pet && o.tier === pet.tier && !o.locked && !BUSY.includes(o.act) && o.act !== "run");
    if (friends.length && Math.random() < 0.72) {
      const f = pick(friends);
      const T = 0.95;
      vx = clamp((f.x - pet.x) / T, -270, 270);
      vy = clamp((f.y - pet.y) / T, -70, 70);
      vz = clamp(vz, 85, 190);
    } else {
      vx = Math.min(vx, -45);
      vz = clamp(vz, 40, 200);
    }
    const spin = -clamp(sp * 0.95, 5, 12);
    pet.rot = -pet.phi;
    this.startFly(pet, vx, vz, vy, spin, "fly");
    pet.power = Math.max(pet.power, 150);
    pet.dizzy = 1;
    this.eng.audio.play("whoosh");
    this.say(pet, "tumble", true);
  }

  bonk(a: Pet, b: Pet, crash = false) {
    this.shake = 1;
    this.eng.audio.play("bonk");
    const k = this.kBase(a);
    const mx = (a.x + b.x) / 2;
    const my = (a.y + b.y) / 2 - 26 * k;
    this.burst("star", mx, my, 8, "#FFD84D", 40, -30);
    this.burst("sparkle", mx, my, 6, "#FFFFFF", 30, -20);
    this.burst("puff", mx, my + 8, 3, "#FFFFFF", 22, -8);
    const sgn = b.x >= a.x ? 1 : -1;
    this.startFly(b, sgn * rand(95, 145), 100, rand(-14, 14), sgn * rand(7, 11), "knocked");
    b.dizzy = 1;
    b.power = 200;
    b.phys.kick(sgn * 80, -40);
    b.phys.squish(80);
    a.vx = -a.vx * 0.4;
    a.vz = Math.max(70, a.vz * -0.3);
    a.spin = -a.spin * 0.5 + rand(-4, 4);
    a.hitCd = 0.7;
    a.phys.squish(80);
    this.sayText(b, "aduuh!! 💫", 2.4);
    this.sayText(a, "maaf yaa!! 😵", 2.4);
    this.eng.hooks.achieve("bonk");
    this.eng.hooks.stat("bonk");
    this.eng.hooks.event("bonk");
    if (crash) {
      this.eng.hooks.achieve("crash");
      this.eng.hooks.event("crash");
      this.eng.hooks.log(`${a.name} meluncur dan menabrak ${b.name} yang sedang santai di ujung perosotan!`, "💥");
    } else {
      this.eng.hooks.log(`${a.name} menabrak ${b.name} sampai terpental. Dua-duanya pusing!`, "💫");
    }
  }

  private settleRot(pet: Pet) {
    const r = wrapAngle(pet.rot);
    const opts = [Math.PI, 1.45, -1.45];
    let best = opts[0];
    for (const o of opts) if (Math.abs(wrapAngle(r - o)) < Math.abs(wrapAngle(r - best))) best = o;
    pet.rot = r;
    pet.landRot = Math.random() < 0.3 ? pick(opts) : best;
  }

  updateFly(pet: Pet, dt: number) {
    const L = this.L;
    const b = this.band(pet);
    const [lo0, hi0] = this.xRange(pet.tier);
    const lo = pet.tier === 0 ? L.minX - 8 : lo0 - 6;
    const hi = pet.tier === 0 ? L.maxX + 8 : hi0 + 6;
    const k = this.kBase(pet);
    if (pet.landT > 0) {
      pet.landT -= dt;
      pet.rot += (pet.landRot - pet.rot) * Math.min(1, dt * 10);
      if (pet.landT <= 0) {
        this.setAct(pet, "dizzy", clamp(pet.power / 55, 2.2, 4.2));
        pet.dizzy = 1;
        this.say(pet, "dizzy", true);
        this.eng.audio.play("dizzy");
      }
      return;
    }
    if (pet.rolling) {
      // menggelinding di lantai seperti boneka kain
      pet.x += pet.vx * dt;
      pet.y = clamp(pet.y + pet.vy * dt, b.minY, b.maxY);
      pet.rot += (pet.vx * dt) / (11 * k);
      pet.vx *= Math.exp(-2.1 * dt);
      pet.vy *= Math.exp(-3 * dt);
      pet.z = Math.abs(Math.sin(pet.rot * 2)) * 2.4;
      if (Math.random() < dt * 16) this.burst("dust", pet.x, pet.y - 2, 1, "rgba(255,255,255,0.55)", 10, -8);
      if (pet.x < lo || pet.x > hi) {
        pet.x = clamp(pet.x, lo, hi);
        pet.vx *= -0.5;
        this.eng.audio.play("boing");
        pet.phys.squish(60);
      }
      if (Math.abs(pet.vx) < 12) {
        pet.rolling = false;
        pet.z = 0;
        pet.vx = 0;
        pet.vy = 0;
        this.settleRot(pet);
        pet.landT = 0.55;
        this.burst("dust", pet.x, pet.y, 4, "rgba(255,255,255,0.7)", 16, -8);
      }
      return;
    }
    pet.vz -= GRAV * dt;
    pet.x += pet.vx * dt;
    pet.y += pet.vy * dt;
    pet.z += pet.vz * dt;
    pet.rot += pet.spin * dt;
    pet.y = clamp(pet.y, b.minY, b.maxY);
    if (pet.x < lo) {
      pet.x = lo;
      pet.vx = Math.abs(pet.vx) * 0.66;
      pet.spin = pet.spin * -0.7 + rand(-2, 2);
      this.eng.audio.play("boing");
      this.shake = Math.max(this.shake, 0.4);
      pet.phys.squish(70);
      this.burst("puff", pet.x, pet.y - pet.z - 10, 2, "#FFFFFF", 10, -6);
    }
    if (pet.x > hi) {
      pet.x = hi;
      pet.vx = -Math.abs(pet.vx) * 0.66;
      pet.spin = pet.spin * -0.7 + rand(-2, 2);
      this.eng.audio.play("boing");
      this.shake = Math.max(this.shake, 0.4);
      pet.phys.squish(70);
      this.burst("puff", pet.x, pet.y - pet.z - 10, 2, "#FFFFFF", 10, -6);
    }
    const zMax = L.zMax[pet.tier] ?? 100;
    if (pet.z > zMax) {
      pet.z = zMax;
      if (pet.vz > 60) {
        this.eng.audio.play("bonk");
        this.burst("star", pet.x, pet.y - pet.z - 40 * k, 3, "#FFD84D", 14, -8);
      }
      pet.vz = -Math.abs(pet.vz) * 0.4;
    }
    if (pet.hitCd > 0) pet.hitCd -= dt;
    else if (Math.hypot(pet.vx, pet.vz) > 60) {
      for (const o of this.pets) {
        if (o === pet || o.tier !== pet.tier || o.locked || ["hide", "bury", "tumble", "fly", "knocked", "climb", "slide"].includes(o.act)) continue;
        if (Math.abs(pet.x - o.x) < 20 && Math.abs(pet.y - o.y) < 14 && pet.z < 36) {
          this.bonk(pet, o);
          break;
        }
      }
    }
    if (Math.random() < dt * 14) this.burst("sparkle", pet.x, pet.y - pet.z - 12, 1, "#FFFFFF", 8, -4);
    if (pet.z <= 0 && pet.vz < 0) {
      pet.z = 0;
      const impact = -pet.vz;
      if (impact > 48 && pet.bounces < 6) {
        pet.vz = impact * 0.56;
        pet.vx *= 0.78;
        pet.vy *= 0.6;
        pet.spin = pet.spin * 0.55 + pet.vx * 0.03;
        pet.bounces++;
        this.eng.audio.play("boing");
        this.burst("dust", pet.x, pet.y, 4, "rgba(255,255,255,0.7)", 20, -10);
        pet.phys.squish(40 + impact * 0.3);
        this.shake = Math.max(this.shake, Math.min(0.5, impact / 300));
      } else {
        pet.vz = 0;
        pet.vy = 0;
        this.burst("dust", pet.x, pet.y, 5, "rgba(255,255,255,0.7)", 24, -10);
        this.eng.audio.play("pop");
        if (Math.abs(pet.vx) > 22 && pet.power >= 100) {
          pet.rolling = true;
        } else if (pet.power < 100) {
          pet.vx = 0;
          pet.spin = 0;
          pet.rot = 0;
          pet.dizzy = 0;
          pet.rolling = false;
          this.setAct(pet, "idle", 1.2);
        } else {
          pet.vx = 0;
          pet.spin = 0;
          this.settleRot(pet);
          pet.landT = 0.55;
        }
      }
    }
  }

  // ---------- perosotan ----------
  startSlide(pet: Pet) {
    const sl = this.L.slides.find((s) => s.from === pet.tier);
    if (!sl) {
      this.setAct(pet, "idle", 1);
      return;
    }
    const r = Math.random();
    const variant = r < 0.38 ? "sit" : r < 0.62 ? "head" : r < 0.75 ? "back" : r < 0.88 ? "spin" : "roll";
    pet.slide = { sl, t: 0, T: rand(1.3, 1.75), variant };
    pet.x = sl.xs;
    pet.y = sl.ys;
    pet.z = 0;
    pet.dir = sl.xe >= sl.xs ? 1 : -1;
    this.eng.audio.play("zip");
    this.say(pet, "slide", true);
    this.burst("sparkle", pet.x, pet.y - 20, 4, "#FFFFFF", 14, -12);
    if (variant === "head") this.eng.hooks.event("slidehead");
  }

  updateSlide(pet: Pet, dt: number) {
    const s = pet.slide;
    if (!s) return;
    const k = this.kBase(pet);
    s.t += dt;
    const prog = Math.min(1, s.t / s.T);
    const u = Math.pow(prog, 1.35);
    const q = slidePoint(s.sl, u);
    pet.x = q.x;
    pet.y = q.y - 1;
    pet.dir = q.dx >= 0 ? 1 : -1;
    let nx = -q.dy;
    let ny = q.dx;
    if (ny > 0) { nx = -nx; ny = -ny; }
    const surf = Math.atan2(nx, -ny);
    switch (s.variant) {
      case "head": pet.rot = Math.atan2(q.dx, -q.dy); break;
      case "back": pet.rot = surf + Math.PI * 0.96; break;
      case "spin": pet.rot = surf + this.eng.t * 10; break;
      case "roll": pet.rot = this.eng.t * 7 * pet.dir; break;
      default: pet.rot = surf * 0.85; break;
    }
    if (Math.random() < dt * 22) this.burst("sparkle", pet.x - q.dx * 8, pet.y - 10 * k, 1, "#FFFFFF", 6, -4);
    if (Math.random() < dt * 14) this.particles.push({
      x: pet.x - q.dx * 14, y: pet.y - 8 * k, vx: -q.dx * 40, vy: 0, life: 1, max: 0.3, kind: "streak", size: 1.2, color: "#FFFFFF", g: 0,
    });
    if (prog >= 1) this.finishSlide(pet, s);
  }

  finishSlide(pet: Pet, s: NonNullable<Pet["slide"]>) {
    const L = this.L;
    const sl = s.sl;
    const dirx = sl.xe >= sl.xs ? 1 : -1;
    pet.tier = sl.to;
    pet.x = sl.xe;
    pet.y = clamp(sl.ye, L.bands[sl.to].minY - 2, L.bands[sl.to].maxY + 2);
    pet.z = 0.6;
    this.eng.hooks.event("slide");
    this.eng.hooks.achieve("slide_done");
    let vexit = 92 + rand(-10, 16);
    if (s.variant === "head") vexit += 26;
    if (s.variant === "spin") vexit += 14;
    const rough = s.variant !== "sit" || Math.random() < 0.3;
    // ada teman di ujung perosotan? tabrakan!
    const victim = this.pets.find((o) => o !== pet && o.tier === pet.tier && !o.locked && !["hide", "bury", "tumble", "fly", "knocked", "climb", "slide"].includes(o.act) && Math.abs(o.x - sl.xe) < 28 && Math.abs(o.y - pet.y) < 17);
    pet.vx = dirx * vexit;
    pet.vy = rand(-6, 6);
    pet.vz = 24;
    pet.phys.squish(60);
    if (victim) {
      pet.rot = pet.rot || 0;
      pet.vz = 70;
      this.setAct(pet, "fly", 99);
      pet.spin = dirx * rand(5, 9);
      pet.bounces = 0;
      pet.power = 120;
      this.bonk(pet, victim, true);
      pet.vx = dirx * 40;
      return;
    }
    if (rough) {
      this.startFly(pet, dirx * vexit, rand(56, 96), rand(-8, 8), dirx * rand(5, 10), "fly");
      pet.power = s.variant === "head" || s.variant === "spin" ? rand(104, 150) : rand(60, 99);
      pet.dizzy = pet.power >= 100 ? 1 : 0;
      this.eng.audio.play("whoosh");
      this.sayText(pet, pick(["WOAAH!!", "ups!!", "kyaaa~!", "ngeeeng!"]), 1.8);
    } else {
      this.setAct(pet, "skid", 3);
      pet.rot = 0;
      this.sayText(pet, "yeay, seru!", 1.6);
    }
  }

  // ---------- gulat ----------
  startFight(a: Pet, b: Pet) {
    if (this.fight) return false;
    a.locked = true;
    b.locked = true;
    a.next = "";
    b.next = "";
    this.setAct(a, "chase", 99);
    this.setAct(b, "alert", 99);
    this.fight = {
      a, b, Lp: a, Rp: b, phase: "chase", t: 0, cx: 0, cy: 0, th: 0, bop: 0, bopN: 0, puffCd: 0, sqCd: 0,
      tgt: { x: b.x, y: b.y }, tgtT: 0,
    };
    this.sayText(a, "kejar kamu! 😆");
    this.sayText(b, "eh?! 😳");
    this.eng.audio.play("squeak");
    return true;
  }

  endFight(done = false) {
    const f = this.fight;
    if (!f) return;
    for (const p of [f.a, f.b]) {
      p.locked = false;
      p.rot = 0;
      p.z = 0;
      p.vz = 0;
      if (["spar", "tussle", "flop", "chase", "alert"].includes(p.act)) this.setAct(p, "idle", 1.4);
      if (done) {
        p.needs.happy = clamp(p.needs.happy + 12, 0, 100);
        this.burst("heart", p.x, p.y - 40 * this.kBase(p), 3, "#FF6F9C", 12, -20);
      }
    }
    if (done) {
      this.eng.hooks.xp(6);
      this.eng.hooks.coin(4);
      this.eng.hooks.stat("fight");
      this.eng.hooks.event("fight");
      this.eng.hooks.achieve("wrestler");
      this.eng.hooks.log(`${f.a.name} dan ${f.b.name} main gulat-gulatan sampai ngakak. Tidak ada yang marah!`, "🤼");
      this.eng.audio.play("happy");
    }
    this.fight = null;
  }

  updateFight(dt: number) {
    const f = this.fight;
    if (!f) return;
    const { a, b } = f;
    const eng = this.eng;
    const bd = this.band(a);
    const [xlo, xhi] = this.xRange(a.tier);
    if (this.grab.pet === a || this.grab.pet === b || a.tier !== b.tier || ["tumble", "fly", "knocked", "held", "climb", "slide"].includes(a.act) || ["tumble", "fly", "knocked", "held", "climb", "slide"].includes(b.act)) {
      this.endFight();
      return;
    }
    f.t += dt;
    const sg = (v: number) => (v >= 0 ? 1 : -1);
    const ease = (p: Pet, tx: number, ty: number, r: number) => {
      p.x += (tx - p.x) * Math.min(1, dt * r);
      p.y += (ty - p.y) * Math.min(1, dt * r);
    };
    switch (f.phase) {
      case "chase": {
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const d = Math.hypot(dx, dy);
        const spd = 82 * eng.settings.speed;
        if (d > 26) {
          a.x += (dx / d) * spd * dt;
          a.y += (dy / d) * spd * dt;
          a.dir = sg(dx);
        }
        b.dir = sg(a.x - b.x);
        if (d <= 28 || f.t > 4) {
          f.phase = "spar";
          f.t = 0;
          f.cx = clamp((a.x + b.x) / 2, xlo + 20, xhi - 20);
          f.cy = clamp((a.y + b.y) / 2, bd.minY + 2, bd.maxY - 2);
          f.Lp = a.x <= b.x ? a : b;
          f.Rp = f.Lp === a ? b : a;
          this.setAct(a, "spar", 99);
          this.setAct(b, "spar", 99);
          this.sayText(a, "hiya! 🥊");
          this.sayText(b, "pok! 🥊");
        }
        break;
      }
      case "spar": {
        ease(f.Lp, f.cx - 16, f.cy, 6);
        ease(f.Rp, f.cx + 16, f.cy, 6);
        f.Lp.dir = 1;
        f.Rp.dir = -1;
        f.bop += dt;
        if (f.bop > 0.4) {
          f.bop = 0;
          f.bopN++;
          const att = f.bopN % 2 ? f.Lp : f.Rp;
          const vic = att === f.Lp ? f.Rp : f.Lp;
          const s = att === f.Lp ? 1 : -1;
          vic.phys.kick(s * 55, -26);
          vic.phys.squish(45);
          vic.vz = 34;
          vic.z = Math.max(vic.z, 0.01);
          this.burst("star", f.cx, f.cy - 24 * this.kBase(att), 2, "#FFD84D", 14, -18);
          eng.audio.play("squeak");
          if (f.bopN === 2) this.say(att, "spar", true);
        }
        if (f.t > 1.9) {
          f.phase = "tussle";
          f.t = 0;
          this.setAct(a, "tussle", 99);
          this.setAct(b, "tussle", 99);
          this.say(a, "tussle", true);
          eng.audio.play("whoosh");
        }
        break;
      }
      case "tussle": {
        f.th += 9.5 * dt;
        const c = Math.cos(f.th);
        const s = Math.sin(f.th);
        f.Lp.x = f.cx + c * 8;
        f.Rp.x = f.cx - c * 8;
        f.Lp.y = f.cy + s * 3;
        f.Rp.y = f.cy - s * 3;
        f.Lp.z = Math.abs(Math.sin(f.th * 1.5)) * 3.5 + 2;
        f.Rp.z = Math.abs(Math.cos(f.th * 1.5)) * 3.5 + 2;
        f.Lp.rot = f.th * 1.2;
        f.Rp.rot = f.th * 1.2 + 2.1;
        f.Lp.dir = 1;
        f.Rp.dir = -1;
        f.puffCd -= dt;
        f.sqCd -= dt;
        if (f.puffCd <= 0) {
          f.puffCd = 0.08;
          this.burst("puff", f.cx + rand(-12, 12), f.cy - 12 + rand(-6, 6), 1, "#FFFFFF", 14, -6);
          if (Math.random() < 0.4) this.burst("star", f.cx + rand(-14, 14), f.cy - 14 + rand(-6, 6), 1, ["#FFD84D", "#FF8FB0", "#8FD8FF"][Math.floor(Math.random() * 3)], 20, -14);
        }
        if (f.sqCd <= 0) {
          f.sqCd = 0.42;
          eng.audio.play(Math.random() < 0.5 ? "squeak" : "giggle");
          f.Lp.phys.kick(rand(-60, 60), -30);
          f.Rp.phys.kick(rand(-60, 60), -30);
          f.Lp.phys.squish(40);
          f.Rp.phys.squish(40);
        }
        if (f.t > 2.2) {
          f.phase = "flop";
          f.t = 0;
          f.Lp.rot = 0;
          f.Rp.rot = 0;
          this.setAct(a, "flop", 99);
          this.setAct(b, "flop", 99);
          this.sayText(a, "hahaha! 😂");
          this.sayText(b, "hihihi! 🤣");
          eng.audio.play("giggle");
        }
        break;
      }
      case "flop": {
        ease(f.Lp, f.cx - 16, f.cy, 8);
        ease(f.Rp, f.cx + 16, f.cy, 8);
        f.Lp.z = 0;
        f.Rp.z = 0;
        f.Lp.rot = 1.35 + Math.sin(f.t * 9) * 0.12;
        f.Rp.rot = -1.35 - Math.sin(f.t * 9 + 1) * 0.12;
        f.puffCd -= dt;
        if (f.puffCd <= 0) {
          f.puffCd = 0.3;
          this.burst("heart", f.cx + rand(-14, 14), f.cy - 22, 1, "#FF6F9C", 10, -16);
        }
        if (f.t > 1.5) {
          f.phase = "zoom";
          f.t = 0;
          f.Lp.rot = 0;
          f.Rp.rot = 0;
          this.setAct(a, "chase", 99);
          this.setAct(b, "chase", 99);
          f.tgtT = 0;
          this.sayText(b, "tangkap aku! 🏃", 2);
        }
        break;
      }
      case "zoom": {
        f.tgtT -= dt;
        if (f.tgtT <= 0) {
          f.tgtT = 0.9;
          f.tgt = { x: rand(xlo + 6, xhi - 6), y: rand(bd.minY, bd.maxY) };
        }
        const spB = 80 * eng.settings.speed;
        const dxb = f.tgt.x - b.x;
        const dyb = f.tgt.y - b.y;
        const db = Math.hypot(dxb, dyb) || 1;
        b.x += (dxb / db) * spB * dt;
        b.y += (dyb / db) * spB * dt;
        b.dir = sg(dxb);
        const dxa = b.x - a.x;
        const dya = b.y - a.y;
        const da = Math.hypot(dxa, dya) || 1;
        if (da > 16) {
          a.x += (dxa / da) * 72 * eng.settings.speed * dt;
          a.y += (dya / da) * 72 * eng.settings.speed * dt;
        }
        a.dir = sg(dxa);
        if (Math.random() < dt * 8) this.burst("dust", a.x - a.dir * 10, a.y - 2, 1, "rgba(255,255,255,0.5)", 10, -8);
        if (f.t > 2.4) this.endFight(true);
        break;
      }
    }
  }

  // ---------- update ----------
  update(dt: number) {
    const L = this.L;
    this.shake = Math.max(0, this.shake - dt * 3);
    this.tickCd = Math.max(0, this.tickCd - dt);
    this.streakCd = Math.max(0, this.streakCd - dt);
    this.petCd = Math.max(0, this.petCd - dt);
    this.coinCd = Math.max(0, this.coinCd - dt);
    this.brushCd = Math.max(0, this.brushCd - dt);
    this.wob = Math.max(0, this.wob - dt * 2.5);

    const w = this.wheel;
    if (!w.occ) w.speed *= Math.pow(0.15, dt);
    w.ang -= w.speed * dt;

    this.poopTimer -= dt;
    if (this.poopTimer <= 0) {
      this.poopTimer = rand(32, 58);
      const poops = this.items.filter((i) => i.kind === "poop").length;
      const src = this.pets.length ? pick(this.pets) : null;
      if (src && src.needs.food > 32 && poops < 6 && !BUSY.includes(src.act)) {
        this.items.push({ uid: this.uid++, kind: "poop", x: clamp(src.x - src.dir * 12 * this.kBase(src), 10, this.W - 10), y: src.y + 2, vy: 0, tier: src.tier });
      }
    }
    for (const it of this.items) {
      if (it.vy !== 0) {
        it.vy += 220 * dt;
        it.y += it.vy * dt;
        const b = L.bands[it.tier] ?? L.bands[0];
        const ground = clamp(it.y, b.minY, b.maxY);
        if (it.y >= ground && it.vy > 0) {
          it.y = ground;
          it.vy = 0;
        }
      }
    }

    for (const pet of this.pets) this.updatePet(pet, dt);
    this.separate(dt);
    this.updateFight(dt);
    this.updateParticles(dt);
  }

  separate(dt: number) {
    const ok = ["idle", "walk", "sniff", "groom", "beg", "stretch", "dig", "eat"];
    for (let i = 0; i < this.pets.length; i++) {
      for (let j = i + 1; j < this.pets.length; j++) {
        const a = this.pets[i];
        const b = this.pets[j];
        if (a.tier !== b.tier || a.locked || b.locked || !ok.includes(a.act) || !ok.includes(b.act)) continue;
        if (Math.abs(a.x - b.x) < 18 && Math.abs(a.y - b.y) < 7) {
          const s = a.x <= b.x ? -1 : 1;
          a.x += s * 20 * dt;
          b.x -= s * 20 * dt;
        }
      }
    }
  }

  private updateGaze(pet: Pet, dt: number) {
    const k = this.kBase(pet);
    const eng = this.eng;
    const ex = pet.x;
    const ey = pet.y - pet.z - 34 * k;
    let tx = 0;
    let ty = 0;
    const a = pet.act;
    if (a === "sleep" || (pet.sleepy && (a === "hide" || a === "bury"))) ty = 0.3;
    else if (a === "run" || a === "chase") {
      tx = 0.9 * pet.dir;
      ty = -0.1;
    } else if (a === "look") {
      const seq: [number, number][] = [[1, 0], [-1, 0.1], [0.2, -1], [0.1, 1], [0.8, -0.6], [-0.8, 0.5], [0, 0]];
      const i = Math.floor(pet.actT / 0.62) % seq.length;
      tx = seq[i][0];
      ty = seq[i][1];
    } else if (a === "glass") {
      tx = 0;
      ty = 0.05;
    } else if (a === "climb" && pet.climb) {
      const c = pet.climb;
      if (c.variant === "look" && c.lookDir !== 2) {
        tx = c.lookDir;
        ty = -0.1;
      } else if (c.variant === "look" || c.variant === "wave") {
        tx = 0;
        ty = 0.1;
      } else {
        tx = Math.sin(eng.t * 3) * 0.2;
        ty = -0.85;
      }
    } else if (a === "slide") {
      tx = pet.dir * 0.5;
    } else if (a === "held") {
      tx = clamp((this.pointer.x - ex) / 30, -1, 1) * 0.4;
      ty = 0.2;
    } else if (this.pointer.inside && eng.zoomedIn && eng.cages[eng.focus] === this) {
      tx = clamp((this.pointer.x - ex) / 45, -1, 1);
      ty = clamp((this.pointer.y - ey) / 38, -1, 1);
    } else {
      const f = this.items.find((i) => (i.kind === "food" || i.kind === "ball") && i.tier === pet.tier);
      if (f && pet.needs.food < 70) {
        tx = clamp((f.x - ex) / 45, -1, 1);
        ty = clamp((f.y - ey) / 38, -1, 1);
      } else if (a === "walk") {
        tx = clamp((pet.tx - pet.x) / 40, -1, 1);
        ty = clamp((pet.ty - pet.y) / 60, -0.4, 0.6);
      } else {
        tx = Math.sin(eng.t * 0.5 + this.idx) * 0.85;
        ty = Math.sin(eng.t * 0.37 + 1) * 0.45;
      }
    }
    const e = Math.min(1, dt * 9);
    pet.gaze.x += (tx - pet.gaze.x) * e;
    pet.gaze.y += (ty - pet.gaze.y) * e;
  }

  updatePet(pet: Pet, dt: number) {
    const eng = this.eng;
    const L = this.L;
    const n = pet.needs;
    const k = this.kBase(pet);
    const wk = eng.fx.kind;
    const wind = wk === "storm" ? Math.sin(eng.t * 0.9) * 35 : wk === "snow" ? 8 : 0;
    const ragOn = LIMBS_FREE.includes(pet.act);
    const spinNow = pet.act === "tumble" ? this.wheel.speed : pet.act === "roll" ? Math.abs(pet.rollV) / 8 : pet.spin;
    const rotNow = pet.act === "tumble" ? -pet.phi : ROTATING.includes(pet.act) ? pet.rot : 0;
    const ballistic = pet.z > 0.5 && ["fly", "knocked", "hop", "cheer"].includes(pet.act);
    const extraWind = (pet.act === "run" ? -pet.dir * 160 : 0) + (pet.act === "slide" ? -pet.dir * 200 : 0);
    pet.phys.update(dt, pet.x, pet.y - pet.z, extraWind + wind, { on: ragOn, spin: spinNow, rot: rotNow, air: ballistic });
    this.updateGaze(pet, dt);
    // arah wajah saat memanjat (0 = membelakangi kamera) dan posisi awal untuk fase langkah
    pet.faceT += (pet.faceTarget - pet.faceT) * Math.min(1, dt * 8);
    if (pet.act !== "climb" && pet.act !== "wall") pet.faceTarget = 0;
    const mvx0 = pet.x;
    const mvy0 = pet.y;

    const resting = pet.act === "sleep" || (pet.sleepy && (pet.act === "hide" || pet.act === "bury"));
    const mul = resting ? 0.45 : 1;
    n.food = clamp(n.food - NEED_DECAY.food * dt * mul, 0, 100);
    n.water = clamp(n.water - NEED_DECAY.water * dt * mul, 0, 100);
    n.happy = clamp(n.happy - NEED_DECAY.happy * dt * (n.food < 15 ? 2.2 : 1), 0, 100);
    n.energy = clamp(n.energy - NEED_DECAY.energy * dt * (resting ? 0 : 1), 0, 100);
    const poops = this.items.filter((i) => i.kind === "poop").length;
    n.clean = clamp(n.clean - (NEED_DECAY.clean + poops * 0.075) * dt, 0, 100);

    pet.blinkT -= dt;
    if (pet.blinkT <= 0) {
      pet.blink = 1;
      if (pet.blinkT < -0.14) {
        pet.blink = 0;
        pet.blinkT = Math.random() < 0.2 ? 0.18 : rand(2.2, 6);
      }
    }
    pet.sand = Math.max(0, pet.sand - dt * 0.05);
    pet.pulse = Math.max(0, pet.pulse - dt * 4);
    pet.fear = Math.max(0, pet.fear - dt * 0.7);
    const b = this.band(pet);
    const depth = clamp((pet.y - b.minY) / Math.max(1, b.maxY - b.minY), 0, 1);
    pet.scale = Math.round((0.88 + depth * 0.2) * 50) / 50;

    pet.passiveCd -= dt;
    if (pet.passiveCd <= 0) {
      pet.passiveCd = 11;
      if (eng.moodOf(pet) > 0.72) {
        eng.hooks.coin(1);
        this.burst("coin", pet.x, pet.y - 30 * k, 1, "#FFD34D", 6, -26);
      }
    }

    // fisika vertikal umum
    const airborne = ["fly", "knocked", "tumble", "tussle", "flop", "held", "wall", "slide", "climb", "roll"].includes(pet.act);
    if (!airborne && (pet.z > 0 || pet.vz !== 0)) {
      pet.vz -= GRAV * dt;
      pet.z += pet.vz * dt;
      if (pet.z <= 0) {
        if (pet.vz < -60) {
          this.burst("dust", pet.x, pet.y, 3, "rgba(255,255,255,0.6)", 16, -8);
          pet.phys.squish(40 + -pet.vz * 0.28);
        }
        pet.z = 0;
        pet.vz = 0;
      }
    }

    // ---- digendong seperti bayi di telapak tangan ----
    if (this.grab.pet === pet && this.grab.mode === "carry") {
      pet.act = "held";
      pet.actT += dt;
      pet.heldT += dt;
      const t = this.tierFor(this.pointer.x, this.pointer.y);
      pet.tier = t;
      const bb = L.bands[t];
      const [lo, hi] = this.xRange(t);
      const fy = this.pointer.y - heldHandDY(k) + Math.sin(pet.heldT * 2.2) * 0.8;
      const gy = clamp(fy, bb.minY, bb.maxY);
      const e = Math.min(1, dt * 14);
      pet.x += (clamp(this.pointer.x, lo - 20, hi + 20) - pet.x) * e;
      pet.y += (gy - pet.y) * e;
      pet.z += (gy - fy - pet.z) * e;
      pet.dir = this.pointer.x > pet.x + 1.5 ? 1 : this.pointer.x < pet.x - 1.5 ? -1 : pet.dir;
      n.happy = clamp(n.happy + dt * 1.2, 0, 100);
      // jilat tangan sesekali
      pet.lickT -= dt;
      if (pet.lickT <= 0 && pet.lickLeft <= 0) {
        pet.lickLeft = rand(1.7, 2.6);
        pet.lickT = rand(4.5, 8);
        pet.lickCd = 0;
        eng.hooks.event("lick");
        eng.hooks.achieve("lick");
        this.sayText(pet, pick(["slurp~", "bersih-bersih", "nyam, tangan~"]), 1.6);
      }
      if (pet.lickLeft > 0) {
        pet.lickLeft -= dt;
        pet.lickCd -= dt;
        if (pet.lickCd <= 0) {
          pet.lickCd = 0.3;
          eng.audio.play("lick");
        }
        if (Math.random() < dt * 5) this.burst("heart", pet.x + 8, pet.y - pet.z - 36 * k, 1, "#FF9EBB", 6, -14);
      }
      pet.squeezeV = 0.5 + 0.5 * Math.sin(pet.heldT * 2.3);
      if (Math.sin(pet.heldT * 2.3) > 0.97 && this.petCd <= 0) {
        this.petCd = 0.4;
        pet.phys.squish(30);
        eng.audio.play("wobble");
      }
      if (Math.random() < dt * 1.1) this.burst("heart", pet.x, pet.y - pet.z - 50 * k, 1, "#FF6F9C", 8, -14);
      return;
    }
    // dibelai
    if (this.grab.pet === pet && this.grab.mode === "pet") {
      if (pet.act !== "pet") this.setAct(pet, "pet", 99);
      pet.actT += dt;
      if (this.petCd <= 0) {
        this.petCd = 0.55;
        n.happy = clamp(n.happy + 3.4, 0, 100);
        this.burst("heart", pet.x + rand(-8, 8), pet.y - 42 * k, 2, "#FF6F9C", 10, -18);
        eng.audio.play("squeak");
        pet.phys.kick(rand(-30, 30), -26);
        pet.phys.squish(60);
        eng.hooks.xp(1);
        eng.hooks.event("pet");
        this.say(pet, "pet");
        if (this.coinCd <= 0) {
          this.coinCd = 1.6;
          eng.hooks.coin(1);
        }
        eng.hooks.achieve("first_pet");
      }
      return;
    }

    pet.actT += dt;
    if (pet.locked) return;
    pet.heldT = 0;
    if (pet.act !== "groom") pet.lickLeft = 0;
    pet.squeezeV = 0;

    switch (pet.act) {
      case "walk":
      case "stash": {
        const dx = pet.tx - pet.x;
        const dy = pet.ty - pet.y;
        const d = Math.hypot(dx, dy);
        const spd = (pet.act === "stash" ? 30 : n.food < 30 ? 46 : 34) * eng.settings.speed;
        if (d < 2 || pet.actT > 18) {
          if (pet.next) {
            const nx = pet.next;
            const nd = pet.nextDur;
            const sl = pet.nextSleepy;
            pet.next = "";
            if (nx === "run") {
              pet.x = L.wheel.x;
              pet.y = L.wheel.y - 5;
            }
            this.setAct(pet, nx, nd);
            if (nx === "hide" || nx === "bury") pet.sleepy = sl;
            this.onArrive(pet, nx);
          } else this.setAct(pet, "idle", 2);
        } else {
          pet.x += (dx / d) * spd * dt;
          pet.y += (dy / d) * spd * dt;
          if (Math.abs(dx) > 1.5) pet.dir = dx > 0 ? 1 : -1;
          if (pet.act === "stash") pet.cheek = Math.max(0.15, pet.cheek - dt * 0.05);
        }
        break;
      }
      case "eat":
        this.updateEat(pet);
        break;
      case "drink": {
        this.bottle = clamp(this.bottle - dt * 0.05, 0, 1);
        n.water = clamp(n.water + dt * 22, 0, 100);
        pet.x = L.bottle.drinkX;
        pet.y = L.bottle.drinkY;
        pet.dir = 1;
        if (Math.random() < dt * 3) this.burst("bubble", L.bottle.tipX, L.bottle.tipY + 3, 1, "#BEEBFF", 4, -10);
        if (this.tickCd <= 0) {
          eng.audio.play("drink");
          this.tickCd = 0.7;
        }
        if (pet.actT >= pet.actDur) {
          this.sayText(pet, "segar~ ✨");
          this.setAct(pet, "idle", 1.6);
          eng.hooks.xp(2);
          eng.hooks.event("drink");
        }
        break;
      }
      case "climb":
        this.updateClimb(pet, dt);
        break;
      case "slide":
        this.updateSlide(pet, dt);
        break;
      case "skid": {
        const [lo, hi] = this.xRange(pet.tier);
        pet.x += pet.vx * dt;
        const sgn = Math.sign(pet.vx) || 1;
        pet.vx -= sgn * 150 * dt;
        if (Math.sign(pet.vx) !== sgn) pet.vx = 0;
        if (Math.random() < dt * 14) this.burst("dust", pet.x - sgn * 8, pet.y - 2, 1, "rgba(255,255,255,0.6)", 10, -8);
        if (pet.x < lo || pet.x > hi) {
          pet.x = clamp(pet.x, lo, hi);
          pet.vx *= -0.35;
          pet.phys.squish(70);
          pet.phys.kick(-sgn * 40, -30);
          eng.audio.play("bonk");
          this.sayText(pet, "ups, tembok!", 1.4);
          pet.vz = 36;
          pet.z = 0.01;
          this.burst("star", pet.x, pet.y - 28 * k, 3, "#FFD84D", 14, -12);
        }
        if (Math.abs(pet.vx) < 5 || pet.actT > 3) {
          pet.vx = 0;
          if (!this.resume(pet)) this.setAct(pet, "idle", rand(1, 2));
        }
        break;
      }
      case "glass":
        this.updateGlass(pet, dt);
        break;
      case "wall":
        this.updateWall(pet, dt);
        break;
      case "run": {
        const w = this.wheel;
        w.occ = pet;
        if (pet.forceTumble && pet.actT > 1) {
          pet.forceTumble = false;
          w.turbo = 1.6;
          w.willTumble = true;
          this.sayText(pet, "kencang!! 🌪️", 1.6);
          eng.audio.play("spin");
        }
        if (w.turbo <= 0 && pet.actT > 3 && Math.random() < dt * 0.1 && eng.moodOf(pet) > 0.5) {
          w.turbo = 1.5;
          w.willTumble = Math.random() < 0.75;
          this.sayText(pet, "wiiiii!! 🌪️", 1.5);
          eng.audio.play("spin");
        }
        const target = w.turbo > 0 ? 11 : 5;
        w.turbo = Math.max(0, w.turbo - dt);
        w.speed += (target - w.speed) * Math.min(1, dt * (target > 6 ? 2.6 : 2.2));
        n.happy = clamp(n.happy + dt * 1.9, 0, 100);
        n.energy = clamp(n.energy - dt * 0.5, 0, 100);
        n.food = clamp(n.food - dt * 0.06, 0, 100);
        const before = Math.floor(eng.wheelSec);
        eng.wheelSec += dt;
        if (Math.floor(eng.wheelSec) > before) eng.hooks.event("wheel");
        pet.dir = -1;
        const drift = Math.sin(pet.actT * 1.9) * 3 * (w.speed / 5);
        pet.x = L.wheel.x + drift;
        pet.y = L.wheel.y - 5;
        if (Math.random() < dt * 9) this.burst("dust", pet.x + 14 * k, pet.y - 1, 1, "rgba(255,255,255,0.55)", 12, -8);
        if (this.streakCd <= 0 && w.speed > 2.5) {
          this.streakCd = 0.07;
          this.particles.push({
            x: pet.x + 22 * k, y: pet.y - rand(8, 38) * k, vx: rand(55, 85), vy: 0,
            life: 1, max: rand(0.28, 0.45), kind: "streak", size: rand(1, 2), color: "#FFFFFF", g: 0,
          });
        }
        if (pet.actT > 2.5 && Math.random() < dt * 1.6) this.burst("sweat", pet.x - 12 * k, pet.y - 46 * k, 1, "#9EE0FF", 10, -20);
        if (Math.random() < dt * 0.7) this.burst("note", pet.x + 6 * k, pet.y - 52 * k, 1, "#8BE0FF", 6, -14);
        if (this.tickCd <= 0) {
          eng.audio.play("tick");
          this.tickCd = 0.19;
        }
        if (eng.wheelSec > 60) eng.hooks.achieve("athlete");
        if (w.turbo > 0.2 && w.willTumble && w.speed > 8.4) {
          this.startTumble(pet);
          break;
        }
        if (pet.actT >= pet.actDur || n.energy < 12) {
          eng.hooks.coin(5);
          eng.hooks.log(`${pet.name} selesai olahraga di roda! Sepertinya bangga sekali.`, "🎡");
          this.goTo(pet, L.wheel.x - 44, clamp(pet.y + 12, b.minY, b.maxY), "hop", 0.7);
        }
        break;
      }
      case "tumble": {
        const w = this.wheel;
        const r = L.wheel.r;
        const Rc = r - 16;
        pet.tumT += dt;
        w.occ = pet;
        w.speed = Math.max(0, w.speed - (0.55 * w.speed + 0.5) * dt);
        pet.phi += w.speed * dt * 0.97;
        const cx = L.wheel.x;
        const cyw = L.wheel.y - r - 4;
        const px = cx + Rc * Math.sin(pet.phi);
        const py = cyw + Rc * Math.cos(pet.phi);
        const pivotUp = 14 * k;
        pet.x = px;
        pet.y = L.wheel.y - 5;
        pet.z = pet.y - (py + pivotUp);
        pet.dir = -1;
        n.happy = clamp(n.happy + dt * 1.2, 0, 100);
        if (pet.tumT > 1.1) pet.dizzy = 1;
        if (Math.random() < dt * 12) this.burst("sparkle", px, py, 1, "#FFFFFF", 14, -6);
        if (Math.random() < dt * 6) this.burst("streak", px + 12, py + rand(-10, 10), 1, "#FFFFFF", 0, 0);
        if (this.tickCd <= 0) {
          eng.audio.play("tick");
          this.tickCd = 0.1;
        }
        const cosP = Math.cos(pet.phi);
        const upper = cosP < -0.15;
        const hold = w.speed * w.speed * Rc >= GRAV * -cosP;
        if (upper && (!hold || (pet.tumT > 1 && w.speed > 5.5 && Math.random() < dt * 0.7))) {
          this.releaseTumble(pet);
        } else if (w.speed < 0.5 && pet.tumT > 1.2) {
          pet.x = L.wheel.x;
          pet.y = L.wheel.y - 5;
          pet.z = 0;
          pet.rot = -wrapAngle(pet.phi);
          w.occ = null;
          this.setAct(pet, "dizzy", 3.2);
          pet.dizzy = 1;
          this.say(pet, "dizzy", true);
          eng.audio.play("dizzy");
        }
        break;
      }
      case "fly":
      case "knocked":
        this.updateFly(pet, dt);
        break;
      case "dizzy": {
        pet.rot = wrapAngle(pet.rot);
        pet.rot += (0 - pet.rot) * Math.min(1, dt * 3.5);
        pet.dizzy = 1;
        const [lo, hi] = this.xRange(pet.tier);
        pet.x = clamp(pet.x + Math.sin(pet.actT * 2.2) * 10 * dt, lo, hi);
        pet.y = clamp(pet.y + Math.cos(pet.actT * 1.7) * 4 * dt, b.minY, b.maxY);
        if (Math.random() < dt * 2.5) this.burst("sparkle", pet.x, pet.y - 40 * k, 1, "#FFE873", 10, -6);
        if (pet.actT >= pet.actDur) {
          pet.dizzy = 0;
          pet.rot = 0;
          this.setAct(pet, "shake", 1.2);
          this.sayText(pet, "fuuh… oke! 😵‍💫");
        }
        break;
      }
      case "scared": {
        pet.fear = Math.max(pet.fear, 0.8);
        if (pet.actT >= pet.actDur) {
          if (Math.random() < 0.75) this.startHide(pet, rand(7, 12), false);
          else this.setAct(pet, "idle", 1.5);
        }
        break;
      }
      case "hide": {
        pet.x = L.hut.x;
        pet.y = L.hut.y + 3;
        pet.vscale = lerp(1, 0.74, smooth(pet.actT / 0.4));
        if (pet.sleepy) {
          n.energy = clamp(n.energy + dt * (eng.settings.night ? 4.6 : 3.1), 0, 100);
          n.happy = clamp(n.happy + dt * 0.14, 0, 100);
          if (Math.random() < dt * 0.9) this.burst("zzz", L.hut.x + 8, L.hut.y - 46, 1, "#FFFFFF", 4, -12);
        } else {
          n.happy = clamp(n.happy + dt * 0.3, 0, 100);
          if (Math.random() < dt * 0.6) this.burst("sparkle", L.hut.x + rand(-8, 8), L.hut.y - 28, 1, "#FFE9A0", 6, -8);
        }
        if (pet.actT >= pet.actDur || (pet.sleepy && n.energy > 97)) this.exitHut(pet);
        break;
      }
      case "bury": {
        pet.x = L.mound.x;
        pet.y = L.mound.y - 0.5;
        const T = pet.actT;
        if (T < 1.7) {
          this.wob = 1;
          if (Math.random() < dt * 14) this.burst("hay", L.mound.x + rand(-14, 14), L.mound.y - 8, 1, "#E8C77A", 20, -26);
          if (this.tickCd <= 0) {
            eng.audio.play("rustle");
            this.tickCd = 0.45;
          }
        }
        if (pet.sleepy) {
          n.energy = clamp(n.energy + dt * (eng.settings.night ? 4.6 : 3.1), 0, 100);
          n.happy = clamp(n.happy + dt * 0.14, 0, 100);
          if (Math.random() < dt * 0.9) this.burst("zzz", L.mound.x + 6, L.mound.y - 30, 1, "#FFFFFF", 4, -12);
          if (n.energy > 97 && pet.actDur - T > 1.3) pet.actDur = T + 1.2;
        } else {
          n.happy = clamp(n.happy + dt * 0.35, 0, 100);
          if (Math.random() < dt * 0.35) {
            this.wob = 1;
            this.burst("hay", L.mound.x + rand(-10, 10), L.mound.y - 10, 2, "#E8C77A", 14, -20);
            this.sayText(pet, "hihi~", 1.2);
          }
        }
        if (T >= pet.actDur) {
          this.burst("hay", L.mound.x, L.mound.y - 8, 10, "#E8C77A", 30, -34);
          this.burst("puff", L.mound.x, L.mound.y - 10, 3, "#FFFFFF", 14, -10);
          eng.audio.play("pop");
          pet.sand = 0.6;
          this.setAct(pet, "shake", 1.3);
          pet.vz = 80;
          pet.z = 0.01;
          this.sayText(pet, "tadaa! ✨");
          eng.hooks.xp(3);
        }
        break;
      }
      case "sleep": {
        n.energy = clamp(n.energy + dt * (eng.settings.night ? 4.6 : 3.1), 0, 100);
        n.happy = clamp(n.happy + dt * 0.14, 0, 100);
        if (Math.random() < dt * 0.9) this.burst("zzz", pet.x + 12 * k, pet.y - 26 * k, 1, "#FFFFFF", 4, -12);
        if (pet.actT >= pet.actDur || n.energy > 97) this.setAct(pet, "stretch", 2.2);
        break;
      }
      case "groom": {
        n.clean = clamp(n.clean + dt * 1.3, 0, 100);
        n.happy = clamp(n.happy + dt * 0.3, 0, 100);
        if (Math.random() < dt * 2) this.burst("sparkle", pet.x + rand(-10, 10) * k, pet.y - 34 * k, 1, "#FFFFFF", 6, -10);
        pet.lickCd -= dt;
        if (pet.lickCd <= 0 && pet.actT > 0.6) {
          pet.lickCd = 0.34;
          eng.audio.play("lick");
        }
        if (pet.actT > 1.1 && pet.lickLeft === 0) {
          pet.lickLeft = 1;
          eng.hooks.event("lick");
          eng.hooks.achieve("lick");
        }
        if (pet.actT >= pet.actDur) {
          pet.lickLeft = 0;
          this.setAct(pet, "idle", rand(1.5, 3));
        }
        break;
      }
      case "bath": {
        n.clean = clamp(n.clean + dt * 3.4, 0, 100);
        n.happy = clamp(n.happy + dt * 0.7, 0, 100);
        pet.sand = Math.min(1, pet.sand + dt * 0.5);
        if (Math.random() < dt * 12) this.burst("sand", pet.x + rand(-14, 14) * k, pet.y - 6, 1, "#FFF0CC", 22, -20);
        if (pet.actT >= pet.actDur) {
          this.sayText(pet, "kibas kibas!", 1.6);
          eng.hooks.event("bath");
          this.setAct(pet, "shake", 1.5);
        }
        break;
      }
      case "shake": {
        pet.phys.kick(Math.sin(pet.actT * 40) * 35, -Math.abs(Math.sin(pet.actT * 20)) * 6);
        pet.sand = Math.max(0, pet.sand - dt * 0.8);
        if (Math.random() < dt * 22) this.burst("sand", pet.x + rand(-12, 12) * k, pet.y - 26 * k, 1, "#FFF0CC", 40, -26);
        if (Math.random() < dt * 8) this.burst("sparkle", pet.x + rand(-16, 16) * k, pet.y - 36 * k, 1, "#FFFFFF", 14, -12);
        if (this.tickCd <= 0) {
          eng.audio.play("tick");
          this.tickCd = 0.07;
        }
        if (pet.actT >= pet.actDur) {
          if (n.clean > 60) {
            eng.hooks.xp(4);
            eng.hooks.coin(3);
            this.sayText(pet, "wangi sekali! ✨");
          }
          this.hop(pet, 1.2);
        }
        break;
      }
      case "dig": {
        n.happy = clamp(n.happy + dt * 0.6, 0, 100);
        if (Math.random() < dt * 16) this.burst("dust", pet.x + pet.dir * 16 * k, pet.y - 2, 1, "#E8D3A8", 26, -30);
        if (this.tickCd <= 0) {
          eng.audio.play("dig");
          this.tickCd = 0.34;
        }
        if (pet.actT >= pet.actDur) {
          if (Math.random() < 0.5) {
            eng.hooks.coin(3, "menemukan biji tersembunyi");
            this.burst("coin", pet.x + pet.dir * 14 * k, pet.y - 10, 2, "#FFD34D", 12, -30);
            this.sayText(pet, "dapat biji! 🌻", 2.2);
          }
          this.setAct(pet, "groom", 2.4);
        }
        break;
      }
      case "play": {
        const ball = this.items.find((i) => i.uid === pet.eatItem);
        n.happy = clamp(n.happy + dt * 1.5, 0, 100);
        if (ball) {
          const [lo, hi] = this.xRange(ball.tier);
          ball.x = clamp(ball.x + pet.dir * dt * 26, lo, hi);
          pet.x = clamp(ball.x - pet.dir * 16 * k, lo, hi);
          if (ball.x <= lo + 1 || ball.x >= hi - 1) pet.dir *= -1;
          if (Math.random() < dt * 3) this.burst("sparkle", ball.x, ball.y - 10, 1, "#FFD84D", 10, -14);
        }
        if (pet.actT >= pet.actDur || !ball) {
          eng.hooks.coin(3);
          eng.hooks.event("play");
          this.hop(pet, 1.1);
        }
        break;
      }
      case "hop": {
        if (pet.z <= 0 && pet.actT > 0.15) {
          if (!this.resume(pet)) this.setAct(pet, "idle", rand(1, 2.2));
        }
        break;
      }
      case "beg": {
        if (pet.actT >= pet.actDur) this.setAct(pet, "idle", 2);
        break;
      }
      case "look": {
        if (Math.random() < dt * 1.2) pet.phys.kick(rand(-8, 8), -14);
        if (pet.actT >= pet.actDur) this.setAct(pet, "idle", rand(1, 2));
        break;
      }
      case "roll": {
        const [lo, hi] = this.xRange(pet.tier);
        pet.x += pet.rollV * dt;
        pet.rot += (pet.rollV * dt) / (11 * k);
        pet.rollV *= Math.exp(-0.55 * dt);
        pet.z = Math.abs(Math.sin(pet.rot * 2)) * 2.6;
        if (pet.x < lo || pet.x > hi) {
          pet.x = clamp(pet.x, lo, hi);
          pet.rollV *= -0.7;
          pet.dir = pet.rollV >= 0 ? 1 : -1;
          eng.audio.play("boing");
          pet.phys.squish(60);
          this.burst("puff", pet.x, pet.y - 10, 2, "#FFFFFF", 10, -6);
        }
        if (Math.random() < dt * 12) this.burst("dust", pet.x, pet.y - 2, 1, "rgba(255,255,255,0.55)", 10, -8);
        if (this.tickCd <= 0) {
          eng.audio.play("tick");
          this.tickCd = 0.16;
        }
        n.happy = clamp(n.happy + dt * 1.4, 0, 100);
        if (pet.actT > pet.actDur - 0.5) {
          const tgt = Math.round(pet.rot / (Math.PI * 2)) * Math.PI * 2;
          pet.rot += (tgt - pet.rot) * Math.min(1, dt * 9);
          pet.rollV *= Math.exp(-4 * dt);
        }
        if (pet.actT >= pet.actDur) {
          pet.rot = 0;
          pet.rollV = 0;
          pet.z = 0;
          eng.hooks.event("roll");
          eng.hooks.achieve("roller");
          this.sayText(pet, "hihi, pusing seru!", 1.6);
          this.hop(pet, 1);
        }
        break;
      }
      case "alert":
        if (pet.actT > 6) this.setAct(pet, "idle", 1);
        break;
      default: {
        if (Math.random() < dt * 0.25) this.say(pet, "idle");
        if (eng.moodOf(pet) > 0.85 && Math.random() < dt * 0.35) {
          this.burst("note", pet.x + rand(-12, 12) * k, pet.y - 44 * k, 1, "#8BE0FF", 8, -14);
        }
        if (pet.actT >= pet.actDur) this.chooseAction(pet);
      }
    }

    // fase langkah merangkak mengikuti jarak tempuh, supaya kaki tidak "meluncur"
    if (pet.act === "walk" || pet.act === "stash" || pet.act === "play") {
      pet.gait += (Math.hypot(pet.x - mvx0, pet.y - mvy0) / 12.5) * Math.PI * 2;
    }
    if (pet.act !== "stash" && pet.act !== "eat" && pet.act !== "walk") {
      pet.cheek = Math.max(0, pet.cheek - dt * 0.12);
    }
    if (!["fly", "knocked", "tumble", "climb", "slide", "wall", "skid", "run", "held"].includes(pet.act)) {
      const [lo, hi] = this.xRange(pet.tier);
      pet.x = clamp(pet.x, lo, hi);
    }
  }

  /** Lanjutkan rencana lintas tingkat bila ada. */
  resume(pet: Pet) {
    if (!pet.plan) return false;
    this.stepPlan(pet);
    return true;
  }

  // ---------- tangga ----------
  startClimb(pet: Pet) {
    const g = this.L.ladders[pet.tier];
    if (!g) {
      this.setAct(pet, "idle", 1);
      return;
    }
    pet.climb = { g, u: 0, ph: 0, pause: 0, lookT: rand(1.1, 2.2), variant: "", lookDir: 0, lastStep: 0 };
    pet.x = g.xb;
    pet.y = g.yb;
    pet.z = 0;
    pet.dir = 1;
    this.say(pet, "climb", true);
  }

  updateClimb(pet: Pet, dt: number) {
    const c = pet.climb;
    if (!c) return;
    const g = c.g;
    const len = Math.max(1, g.yb - g.yt);
    const eng = this.eng;
    if (c.pause > 0) {
      c.pause -= dt;
      if (c.variant === "wave" && Math.random() < dt * 5) this.burst("sparkle", pet.x + 10, pet.y - 40, 1, "#FFFFFF", 6, -8);
      if (c.pause <= 0) c.variant = "";
    } else {
      c.lookT -= dt;
      if (c.lookT <= 0 && c.u > 0.14 && c.u < 0.88) {
        c.variant = pick(["look", "look", "wave"]);
        c.lookDir = pick([-1, 1, 2]);
        c.pause = rand(1.1, 2);
        c.lookT = rand(1.8, 3.6);
        if (c.variant === "wave" || c.lookDir === 2) this.sayText(pet, pick(["haii!", "lihat aku!", "tinggi ya?"]), 1.6);
      } else {
        const sp = 25 * eng.settings.speed * dt;
        c.u = Math.min(1, c.u + sp / len);
        c.ph += dt * 6.3 * eng.settings.speed;
        const step = Math.floor(c.ph / Math.PI);
        if (step !== c.lastStep) {
          c.lastStep = step;
          eng.audio.play("climb");
          pet.phys.squish(14);
        }
      }
    }
    // berhenti melihat sekitar: kepala menoleh (setengah ke samping, atau penuh ke kamera)
    const calmNow = c.variant === "look" || c.variant === "wave";
    pet.faceTarget = calmNow ? (c.variant === "wave" || c.lookDir === 2 ? 1 : 0.6) : 0;
    pet.faceSide = c.lookDir === 2 ? 0 : c.lookDir;
    pet.x = lerp(g.xb, g.xt, c.u);
    pet.y = lerp(g.yb, g.yt, c.u);
    if (c.u >= 1) {
      pet.tier = g.from + 1;
      pet.x = g.xt + (pet.tier > 0 ? 6 : 0);
      pet.y = g.yt;
      eng.hooks.event("climb");
      eng.hooks.achieve("climber_step");
      if (pet.tier === 2) eng.hooks.achieve("top");
      this.setAct(pet, "hop", 2);
      pet.vz = 50;
      pet.z = 0.01;
      pet.phys.squish(50);
      eng.audio.play("pop");
      this.burst("sparkle", pet.x, pet.y - 20, 4, "#FFE873", 14, -14);
    }
  }

  // ---------- kaca depan ----------
  updateGlass(pet: Pet, dt: number) {
    const eng = this.eng;
    const k = this.kBase(pet);
    const b = this.band(pet);
    const [lo, hi] = this.xRange(pet.tier);
    pet.glassT += dt;
    pet.dir = 1;
    pet.y += (b.maxY - pet.y) * Math.min(1, dt * 5);
    // mengikuti kursor
    const foc = eng.cages[eng.focus] === this;
    if (this.pointer.inside && foc && eng.zoomedIn) {
      const tx = clamp(this.pointer.x, lo + 8, hi - 8);
      const dx = tx - pet.x;
      pet.x += clamp(dx, -1, 1) * Math.min(Math.abs(dx), 34 * dt);
    }
    pet.printCd -= dt;
    pet.fogCd -= dt;
    if (pet.printCd <= 0) {
      pet.printCd = rand(0.55, 0.9);
      const side = Math.random() < 0.5 ? -1 : 1;
      this.stamp("print", pet.x + side * 13 * k, pet.y - 31 * k + rand(-2, 2), 3.8);
      eng.audio.play("tap");
      pet.phys.squish(18);
    }
    if (pet.fogCd <= 0) {
      pet.fogCd = rand(1.1, 1.7);
      this.stamp("fog", pet.x, pet.y - 36 * k, 1.5);
    }
    if (Math.random() < dt * 0.9) pet.glassVar = pick(["tap", "tap", "kiss"]);
    if (Math.random() < dt * 1.4) this.burst("heart", pet.x + rand(-8, 8), pet.y - 56 * k, 1, "#FF9EBB", 8, -14);
    if (pet.actT >= pet.actDur) {
      this.sayText(pet, "dadah! 💕", 1.8);
      this.hop(pet, 1.2);
    }
  }

  // ---------- manjat dinding ----------
  updateWall(pet: Pet, dt: number) {
    const w = pet.wall;
    if (!w) return;
    const eng = this.eng;
    const k = this.kBase(pet);
    const L = this.L;
    pet.dir = w.side;
    pet.faceTarget = w.phase === "hang" ? 1 : 0;
    pet.faceSide = 0;
    pet.x = w.side > 0 ? L.x1 - 15 * k - 3 : L.x0 + 15 * k + 3;
    if (w.phase === "climb") {
      w.h += (12 + Math.sin(pet.actT * 5) * 3) * dt * eng.settings.speed;
      w.ph += dt * 6.3;
      const step = Math.floor(w.ph / Math.PI);
      if (step !== w.lastStep) {
        w.lastStep = step;
        eng.audio.play("climb");
        pet.phys.squish(14);
        this.burst("dust", pet.x + w.side * 10 * k, pet.y - w.h - 6, 1, "rgba(255,255,255,0.6)", 8, -4);
      }
      if (w.h >= w.slipAt) {
        w.phase = "hang";
        w.hangT = 0;
        this.sayText(pet, pick(["hehe, nyangkut!", "aku bisa?!", "tinggi juga ya…"]), 1.8);
        eng.audio.play("wobble");
        eng.hooks.event("wall");
        eng.hooks.achieve("wall");
      }
    } else {
      w.hangT += dt;
      w.ph += dt * 2;
      if (Math.random() < dt * 2.5) this.burst("sweat", pet.x - w.side * 10 * k, pet.y - w.h - 44 * k, 1, "#9EE0FF", 6, -14);
      if (w.hangT > 1.9) {
        this.sayText(pet, pick(["WAAAH!", "huaaa~!", "licin!"]), 1.8);
        eng.audio.play("slip");
        this.startFly(pet, -w.side * rand(22, 40), 0, rand(-8, 8), w.side * rand(2, 4), "fly");
        pet.power = 70;
        pet.phys.squish(60);
        return;
      }
    }
    pet.z = w.h;
  }

  onArrive(pet: Pet, act: string) {
    const L = this.L;
    const eng = this.eng;
    if (act === "sleep") {
      eng.audio.play("sleep");
      this.say(pet, "sleep");
    } else if (act === "run") this.say(pet, "run");
    else if (act === "bath") this.say(pet, "bath");
    else if (act === "hop") this.hop(pet, 1);
    else if (act === "climb") this.startClimb(pet);
    else if (act === "slide") this.startSlide(pet);
    else if (act === "glass") {
      pet.glassT = 0;
      pet.printCd = 0.3;
      pet.fogCd = 0.8;
      pet.glassVar = "tap";
      pet.dir = 1;
      eng.hooks.event("glass");
      eng.hooks.achieve("glass");
      this.say(pet, "glass", true);
    } else if (act === "wall") {
      const side = pet.x < L.W / 2 ? -1 : 1;
      pet.wall = { side, slipAt: rand(32, 58), h: 0, phase: "climb", hangT: 0, ph: 0, lastStep: 0 };
      pet.dir = side;
      pet.z = 0;
      this.say(pet, "wall", true);
    } else if (act === "hide") {
      this.burst("puff", L.hut.x, L.hut.y - 6, 4, "#FFFFFF", 14, -8);
      eng.audio.play("whoosh");
      this.say(pet, "hide", true);
      eng.hooks.achieve("hideout");
      eng.hooks.event("hide");
      if (pet.stashing) {
        pet.stashing = false;
        this.stash = Math.min(9, this.stash + 1);
        pet.cheek = 0.08;
        eng.hooks.coin(2);
        eng.hooks.log(`${pet.name} menyimpan cadangan makanan di rumah mungilnya.`, "🏠");
      }
    } else if (act === "bury") {
      eng.audio.play("rustle");
      this.wob = 1;
      this.say(pet, "bury", true);
      eng.hooks.achieve("burrow");
      eng.hooks.stat("burrow");
      eng.hooks.event("burrow");
      eng.hooks.log(`${pet.name} menggali dan mengubur dirinya di tumpukan serbuk kayu. Cuma matanya yang mengintip!`, "🕳️");
    }
  }

  // ---------- makan yang memuaskan ----------
  onBite(pet: Pet, food: Food) {
    const k = this.kBase(pet);
    const n = pet.needs;
    this.eng.audio.play("crunch");
    pet.pulse = 1;
    pet.cheek = clamp(pet.cheek + food.cheek * 0.32, 0, 1);
    n.food = clamp(n.food + food.food / 5, 0, 100);
    n.happy = clamp(n.happy + food.happy / 5, 0, 100);
    const mx = pet.x + pet.dir * 4 * k;
    const my = pet.y - 22 * k;
    this.burst("crumb", mx, my, 4, food.crumb, 16, -14);
    if (pet.bites % 2 === 0) this.burst("heart", mx, my - 10 * k, 1, "#FF9EBB", 8, -16);
    pet.phys.kick(rand(-20, 20), -34);
    pet.phys.squish(36);
  }

  updateEat(pet: Pet) {
    const eng = this.eng;
    const L = this.L;
    const k = this.kBase(pet);
    const food = getFood(pet.foodId);
    const P = clamp(pet.actT / pet.actDur, 0, 1);
    if (P > 0.08 && pet.eatItem) {
      this.items = this.items.filter((i) => i.uid !== pet.eatItem);
      pet.eatItem = 0;
    }
    if (pet.fromBowl && P > 0.08) {
      this.bowl = clamp(this.bowl - 0.2, 0, 1);
      pet.fromBowl = false;
    }
    const total = 5;
    let done = 0;
    if (P >= 0.14 && P < 0.8) done = Math.min(total, Math.floor(((P - 0.14) / 0.66) * total) + 1);
    else if (P >= 0.8) done = total;
    while (pet.bites < done) {
      pet.bites++;
      this.onBite(pet, food);
    }
    if (P >= 0.8 && pet.eatStage < 1) {
      pet.eatStage = 1;
      eng.audio.play("gulp");
      pet.pulse = 1;
      pet.phys.kick(0, -30);
      this.burst("sparkle", pet.x, pet.y - 30 * k, 3, "#FFFFFF", 14, -14);
    }
    if (P >= 0.92 && pet.eatStage < 2) {
      pet.eatStage = 2;
      eng.audio.play("mmm");
      this.burst("sparkle", pet.x, pet.y - 34 * k, 6, "#FFE873", 26, -22);
      this.burst("heart", pet.x, pet.y - 40 * k, 3, "#FF6F9C", 14, -22);
      this.sayText(pet, "enak banget! ✨", 2.2);
    }
    if (pet.actT >= pet.actDur) {
      eng.hooks.xp(3);
      eng.hooks.coin(2);
      eng.hooks.event("feed");
      if (pet.cheek > 0.75) eng.hooks.achieve("full_cheek");
      if (pet.cheek > 0.4) {
        pet.stashing = true;
        this.goProp(pet, "hut", "hide", 2.8, false);
        if (pet.act === "walk") {
          pet.act = "stash";
          pet.actT = 0;
        }
      } else {
        this.hop(pet, 1);
      }
    }
    void L;
  }

  updateParticles(dt: number) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const q = this.particles[i];
      q.x += q.vx * dt;
      q.y += q.vy * dt;
      q.vy += q.g * dt;
      q.vx *= q.kind === "streak" ? 1 : 0.98;
      q.life -= dt / q.max;
      if (q.kind === "heart" || q.kind === "zzz") q.x += Math.sin(this.eng.t * 3 + q.y * 0.1) * 8 * dt;
      if (q.life <= 0) this.particles.splice(i, 1);
    }
  }

  // ---------- gambar ----------
  drawPet(pet: Pet, t: number) {
    const L = this.L;
    const eng = this.eng;
    const act = pet.act;
    const v: HamsterVisual = {
      x: pet.x, y: pet.y, dir: pet.dir, act, actT: pet.actT, cheek: pet.cheek,
      blink: pet.blink, mood: eng.moodOf(pet), hop: pet.z, scale: pet.scale * pet.vscale, sand: pet.sand,
      gaze: pet.gaze, phys: pet.phys, pulse: pet.pulse, dizzy: pet.dizzy > 0 ? 1 : 0, sleepy: pet.sleepy, fear: pet.fear,
      ragOn: RAGDOLL.includes(act),
    };
    if (act === "walk" || act === "stash" || act === "play") v.gait = pet.gait;
    switch (act) {
      case "eat":
        v.eatP = clamp(pet.actT / pet.actDur, 0, 1);
        v.food = pet.foodId;
        break;
      case "tumble":
        v.rot = -pet.phi;
        v.shadow = false;
        break;
      case "fly":
      case "knocked":
        v.rot = pet.rot;
        break;
      case "dizzy":
        v.rot = pet.rot + Math.sin(t * 3.1) * 0.2;
        break;
      case "tussle":
      case "flop":
        v.rot = pet.rot;
        break;
      case "held":
        v.shadow = false;
        v.lick = pet.lickLeft > 0 ? 1 : 0;
        v.squeeze = pet.squeezeV;
        break;
      case "groom":
        v.lick = pet.lickLeft;
        break;
      case "climb":
        v.shadow = false;
        v.variant = pet.climb?.variant ?? "";
        v.climbPh = pet.climb?.ph ?? 0;
        v.faceTurn = pet.faceT;
        v.faceSide = pet.faceSide;
        break;
      case "slide":
        v.shadow = false;
        v.variant = pet.slide?.variant ?? "sit";
        v.rot = pet.rot;
        break;
      case "wall":
        v.shadow = false;
        v.variant = pet.wall?.phase === "hang" ? "hang" : "";
        v.climbPh = pet.wall?.ph ?? 0;
        v.faceTurn = pet.faceT;
        v.faceSide = 0;
        break;
      case "roll":
        v.rot = pet.rot;
        break;
      case "glass":
        v.variant = pet.glassVar;
        v.viewer = true;
        break;
      case "bury": {
        const T = pet.actT;
        const D = pet.actDur;
        const base = pet.sleepy ? 23 : 14 + Math.sin(T * 1.7) * 2;
        let s = base;
        if (T < 1.7) s = base * smooth(T / 1.7);
        else if (T > D - 1.2) s = lerp(base, 0, smooth((T - (D - 1.2)) / 1.2));
        v.sink = s;
        v.clipY = L.mound.y - 4;
        v.shadow = false;
        break;
      }
      case "hide": {
        const enter = smooth(pet.actT / 0.4);
        v.sink = lerp(0, 9, enter) + (pet.sleepy ? 1 : Math.max(0, Math.sin(pet.actT * 1.3)) * -3);
        v.clip = { x0: L.hut.x - HUT_HALF_DOOR, y0: L.hut.y - HUT_DOOR_H, x1: L.hut.x + HUT_HALF_DOOR, y1: L.hut.y - 1 };
        v.tint = 0.3 * enter;
        v.shadow = false;
        break;
      }
    }
    drawHamster(this.p, v, pet.look, t);
  }

  sortKey(pet: Pet) {
    const L = this.L;
    const act = pet.act;
    if (act === "hide") return L.hut.y - 1;
    if (act === "bury") return L.mound.y - 1;
    if (act === "tumble") return L.wheel.y - 6;
    if (act === "held") return this.H + 99;
    if ((act === "fly" || act === "knocked") && pet.landT <= 0 && !pet.rolling) return this.H + 90;
    if (act === "climb" && pet.climb) return pet.climb.g.yb + 0.5;
    if (act === "slide" && pet.slide) return pet.slide.sl.ye + 0.5;
    return pet.y;
  }

  render(t: number) {
    const eng = this.eng;
    const L = this.L;
    const p = this.p;
    const ctx = this.ctx;
    const th = getTheme(this.rec.theme);
    const env = { night: eng.settings.night, weather: eng.fx.kind };
    const key = `${this.W}x${this.H}|${th.id}|${env.night}|${env.weather}`;
    if (key !== this.bgKey || !this.bgA || !this.bgB || !this.fg) {
      const bd = buildBackdrop(L, th, env);
      this.bgA = bd.a;
      this.bgB = bd.b;
      this.fg = buildFrame(L, th);
      this.bgKey = key;
    }
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.imageSmoothingEnabled = false;
    ctx.globalAlpha = 1;
    ctx.drawImage(this.bgA!, 0, 0);
    // cuaca hanya di luar kaca: langit & pemandangan, di belakang pagar, lantai, rak, dan hamster
    eng.fx.drawScene(ctx, { x0: L.x0, y0: L.y0, x1: L.x1, y1: L.floorY }, this.idx * 53);
    ctx.drawImage(this.bgB!, 0, 0);
    p.reset();
    drawLights(p, L, this.rec.lights ?? "bendera", t, env.night);
    drawBottle(p, L.bottle.x, L.bottle.y, th, this.bottle, t, L.bottle.h);
    const f = this.fight;
    if (f && f.phase === "tussle") drawFightCloud(p, f.cx, f.cy, t, false);

    type Draw = { y: number; f: () => void };
    const list: Draw[] = [
      { y: L.hut.y - 2, f: () => drawHutBack(p, L.hut.x, L.hut.y, th, t) },
      { y: L.hut.y - 0.5, f: () => drawHutFront(p, L.hut.x, L.hut.y, th, this.stash) },
      { y: L.mound.y, f: () => drawMound(p, L.mound.x, L.mound.y, th, this.wob, t) },
      { y: L.wheel.y - 7.5, f: () => drawWheelBack(p, L.wheel.x, L.wheel.y, L.wheel.r, this.wheel.ang, th) },
      { y: L.wheel.y + 1, f: () => drawWheelFront(p, L.wheel.x, L.wheel.y, L.wheel.r, this.wheel.ang, th) },
      { y: L.bowl.y, f: () => drawBowl(p, L.bowl.x, L.bowl.y, th, this.bowl) },
      { y: L.bath.y, f: () => drawBath(p, L.bath.x, L.bath.y, th) },
    ];
    for (const g of L.ladders) list.push({ y: g.yb, f: () => drawLadder(p, g, th) });
    for (const s of L.slides) {
      list.push({ y: s.ye, f: () => drawSlide(p, s, th, false) });
      list.push({ y: s.ye + 1, f: () => drawSlide(p, s, th, true) });
    }
    for (const it of this.items) {
      if (it.kind === "poop") list.push({ y: it.y, f: () => drawPoop(p, it.x, it.y) });
      else if (it.kind === "ball") list.push({ y: it.y, f: () => drawBall(p, it.x, it.y, 7, t) });
      else list.push({ y: it.y, f: () => drawFood(p, it.food!, it.x, it.y, 0) });
    }
    for (const pet of this.pets) {
      if (pet.act === "held") {
        const S = this.kBase(pet);
        const hx = pet.x;
        const hy = pet.y - pet.z + heldHandDY(S);
        list.push({ y: this.H + 98, f: () => drawGhostHand(p, hx, hy, t, false) });
        list.push({ y: this.H + 99, f: () => this.drawPet(pet, t) });
        list.push({ y: this.H + 100, f: () => drawGhostHand(p, hx, hy, t, true) });
      } else {
        list.push({ y: this.sortKey(pet), f: () => this.drawPet(pet, t) });
      }
    }
    list.sort((a, b) => a.y - b.y);
    for (const d of list) d.f();
    if (f && f.phase === "tussle") drawFightCloud(p, f.cx, f.cy, t, true);

    for (const q of this.particles) drawParticle(p, q.kind, q.x, q.y, q.life, q.size, q.color);

    if (env.night) drawNightOverlay(p, L, t);

    // kursor alat (hanya di aquarium yang difokuskan)
    if (this.pointer.inside && this.grab.mode === "none" && eng.zoomedIn && eng.cages[eng.focus] === this) {
      const px0 = Math.round(this.pointer.x);
      const py0 = Math.round(this.pointer.y);
      const tool = eng.tool;
      if (tool.kind === "food") {
        ctx.globalAlpha = 0.75;
        drawFood(p, tool.id, px0, py0, 0);
        ctx.globalAlpha = 1;
      } else if (tool.kind === "broom") {
        p.rect(px0 - 5, py0 - 8, 2, 9, "#C08F45");
        p.rect(px0 - 7, py0 + 1, 7, 4, "#FFE873");
        p.rect(px0 - 7, py0 + 4, 7, 1, "#E0A426");
      } else if (tool.kind === "ball") {
        ctx.globalAlpha = 0.7;
        drawBall(p, px0, py0, 7, t);
        ctx.globalAlpha = 1;
      } else {
        const pulse = Math.sin(t * 5) > 0 ? 1 : 0;
        const c = "rgba(255,255,255,0.85)";
        p.px(px0 - 4 - pulse, py0, c);
        p.px(px0 + 4 + pulse, py0, c);
        p.px(px0, py0 - 4 - pulse, c);
        p.px(px0, py0 + 4 + pulse, c);
      }
    }
    ctx.drawImage(this.fg, 0, 0);
  }

  // ---------- input (koordinat lokal aquarium) ----------
  hitPet(x: number, y: number): Pet | null {
    let best: Pet | null = null;
    for (const pt of this.pets) {
      if (["hide", "bury", "fly", "knocked", "tumble", "wall"].includes(pt.act)) continue;
      const k = this.kBase(pt);
      if (Math.abs(x - pt.x) < 38 * k && y < pt.y - pt.z + 6 && y > pt.y - pt.z - 68 * k) {
        if (!best || pt.y > best.y) best = pt;
      }
    }
    return best;
  }

  hitHidden(x: number, y: number): Pet | null {
    const L = this.L;
    for (const pt of this.pets) {
      if (pt.act === "hide" && Math.abs(x - L.hut.x) < 30 && y > L.hut.y - 52 && y < L.hut.y + 8) return pt;
      if (pt.act === "bury" && Math.abs(x - L.mound.x) < 30 && y > L.mound.y - 30 && y < L.mound.y + 16) return pt;
    }
    return null;
  }

  pointerDown(x: number, y: number, tool: Tool) {
    const L = this.L;
    const eng = this.eng;
    this.pointer.x = x;
    this.pointer.y = y;
    const hid = this.hitHidden(x, y);
    if (hid) {
      eng.select(hid.id);
      if (hid.act === "hide") this.exitHut(hid);
      else hid.actDur = Math.min(hid.actDur, hid.actT + 1.2);
      this.sayText(hid, "kaget! 😳", 1.8);
      return;
    }
    const hit = this.hitPet(x, y);
    if (hit) {
      eng.select(hit.id);
      if (hit.locked) this.endFight();
      this.grab = { pet: hit, mode: "pet", moved: 0 };
      this.petCd = 0;
      if (hit.act === "sleep") this.sayText(hit, "hmm…? 😴");
      hit.next = "";
      hit.plan = null;
      hit.climb = null;
      hit.slide = null;
      hit.wall = null;
      hit.stashing = false;
      return;
    }
    const tier = L.tierAtY(y);
    const bt = L.bands[tier] ?? L.bands[0];
    if (tool.kind === "food") {
      if (eng.hooks.useFood(tool.id)) {
        const fy = clamp(y, bt.minY, bt.maxY);
        const ft = this.tierFor(x, fy);
        const it: Item = { uid: this.uid++, kind: "food", food: tool.id, x: clamp(x, 12, this.W - 12), y: fy - 24, vy: 20, tier: ft };
        this.items.push(it);
        eng.audio.play("pop");
        const f = getFood(tool.id);
        eng.hooks.log(`Kamu menaruh ${f.name} di serbuk kayu.`, f.emoji);
        const free = this.pets.filter((o) => !o.locked && ["idle", "walk", "sniff", "groom", "beg", "stretch", "dig", "glass"].includes(o.act));
        if (free.length) {
          const ch = free.reduce((a, b) => (Math.abs(a.x - it.x) + Math.abs(a.tier - ft) * 150 < Math.abs(b.x - it.x) + Math.abs(b.tier - ft) * 150 ? a : b));
          this.goEat(ch, tool.id, it.uid, it.x, fy, false, ft);
          this.sayText(ch, "camilan! 😍", 1.8);
        }
      } else {
        eng.audio.play("nope");
        const pt = eng.pickPet(this);
        if (pt) this.sayText(pt, "habis… beli di toko ya", 2);
      }
      return;
    }
    if (tool.kind === "broom") {
      const target = this.items.find((i) => i.kind === "poop" && Math.hypot(i.x - x, i.y - y) < 16);
      if (target) {
        this.items = this.items.filter((i) => i.uid !== target.uid);
        this.burst("sparkle", target.x, target.y - 4, 6, "#8BE0FF", 20, -26);
        eng.audio.play("clean");
        eng.hooks.coin(3);
        eng.hooks.xp(2);
        eng.hooks.event("clean");
        for (const o of this.pets) o.needs.clean = clamp(o.needs.clean + 4, 0, 100);
        eng.hooks.achieve("poop_clean");
      } else if (this.brushCd <= 0) {
        this.brushCd = 0.5;
        this.burst("dust", x, y, 4, "#F3E3BE", 22, -18);
        eng.audio.play("clean");
        for (const o of this.pets) o.needs.clean = clamp(o.needs.clean + 1.5, 0, 100);
      }
      return;
    }
    if (tool.kind === "ball") {
      const bx = clamp(x, 16, this.W - 16);
      const by = clamp(y, bt.minY, bt.maxY);
      const btier = this.tierFor(bx, by);
      let ball = this.items.find((i) => i.kind === "ball");
      if (ball) {
        ball.x = bx;
        ball.y = by;
        ball.tier = btier;
      } else {
        ball = { uid: this.uid++, kind: "ball", x: bx, y: by, vy: 0, tier: btier };
        this.items.push(ball);
      }
      eng.audio.play("pop");
      this.burst("sparkle", bx, by - 8, 5, "#FFD84D", 18, -22);
      const pt = eng.pickPet(this);
      if (pt && !pt.locked && !BUSY.includes(pt.act)) {
        pt.eatItem = ball.uid;
        this.goTo(pt, bx - 14, by, "play", 7, false, btier);
        this.sayText(pt, "bola! 🎾", 1.8);
      }
      return;
    }
    const pt = eng.pickPet(this);
    if (pt && !pt.locked && !BUSY.includes(pt.act) && pt.act !== "run") {
      const tt = this.tierFor(x, y);
      this.goTo(pt, x, clamp(y, L.bands[tt].minY, L.bands[tt].maxY), "sniff", 1.6, false, tt);
    }
    this.burst("sparkle", x, y, 3, "#FFFFFF", 12, -14);
    eng.audio.play("ui");
  }

  pointerMove(x: number, y: number) {
    const dx = x - this.pointer.x;
    const dy = y - this.pointer.y;
    this.pointer.x = x;
    this.pointer.y = y;
    this.pointer.inside = true;
    const g = this.grab;
    if (g.mode !== "none" && g.pet) {
      g.moved += Math.hypot(dx, dy);
      if (g.mode === "pet" && g.moved > 7) {
        g.mode = "carry";
        this.setAct(g.pet, "held", 99);
        g.pet.heldT = 0;
        g.pet.lickT = rand(2, 3.5);
        g.pet.lickLeft = 0;
        this.eng.audio.play("squeak");
        this.say(g.pet, "held", true);
        this.eng.hooks.achieve("carry");
        this.eng.hooks.event("carry");
      }
      if (g.mode === "pet" && !this.hitPet(x, y) && g.moved > 14) {
        this.setAct(g.pet, "idle", 1.2);
        this.grab = { pet: null, mode: "none", moved: 0 };
      }
    }
  }

  pointerUp() {
    const g = this.grab;
    const pt = g.pet;
    if (pt && g.mode === "carry") {
      this.burst("dust", pt.x, pt.y, 5, "rgba(255,255,255,0.7)", 22, -10);
      this.grab = { pet: null, mode: "none", moved: 0 };
      pt.lickLeft = 0;
      if (pt.z > 14) {
        this.startFly(pt, 0, 0, 0, rand(-3, 3), "fly");
        pt.power = pt.z * 3.2;
        pt.rot = 0;
        pt.dizzy = pt.power > 100 ? 1 : 0;
        this.eng.audio.play("whoosh");
      } else {
        this.setAct(pt, "hop", 2);
        pt.vz = 70;
        pt.z = Math.max(pt.z, 0.01);
        pt.phys.squish(60);
        this.eng.audio.play("pop");
        pt.needs.happy = clamp(pt.needs.happy + 3, 0, 100);
        this.sayText(pt, "mendarat! ✨", 1.8);
      }
    } else if (pt && g.mode === "pet") {
      this.setAct(pt, "idle", 1.4);
      pt.cheek = Math.max(pt.cheek, 0.12);
    }
    this.grab = { pet: null, mode: "none", moved: 0 };
  }
}

// =====================================================================
//  ENGINE = dunia: banyak aquarium, kamera, cuaca, input
// =====================================================================
export class Engine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  P = 3;
  W = 320;
  H = 180;
  TW = 312;
  TH = 172;
  GAP = 96;
  VM = 150;
  cages: Cage[] = [];
  settings: Settings;
  hooks: Hooks;
  audio: GameAudio;
  fx = new WeatherFX();
  t = 0;
  dayTime = 8 * 10;
  wheelSec = 0;
  focus = 0;
  zoomedIn = true;
  cam = { x: 0, y: 0, z: 1, tx: 0, ty: 0, tz: 1 };
  zOut = 0.5;
  zIn = 1;
  selectedId = "";
  tool: Tool = { kind: "hand" };
  paused = false;
  onSnapshot: ((s: Snapshot) => void) | null = null;
  stageEl: HTMLElement | null = null;
  flash = 0;

  private room: HTMLCanvasElement | null = null;
  private roomKey = "";
  private raf = 0;
  private last = 0;
  private snapT = 0;
  private frameN = 0;
  private bubbleEls: HTMLDivElement[] = [];
  private thunderQ: number[] = [];
  private seenWeather = new Set<string>();
  private ptr = {
    down: false, mode: "none" as "none" | "cage" | "pan", sx: 0, sy: 0, moved: 0,
    cage: null as Cage | null, cageIdx: -1,
  };

  constructor(canvas: HTMLCanvasElement, cfg: { cages: CageRec[]; pets: PetRec[] }, settings: Settings, hooks: Hooks, audio: GameAudio) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.settings = settings;
    this.hooks = hooks;
    this.audio = audio;
    for (let i = 0; i < cfg.cages.length; i++) {
      const rec = cfg.cages[i];
      this.cages.push(new Cage(this, i, rec, this.TW, rec.tiers === 3 ? TOWER_H : this.TH));
    }
    for (const pr of cfg.pets) {
      const c = this.cages[clamp(pr.cage, 0, this.cages.length - 1)];
      c.pets.push(makePet(pr, c));
    }
    this.selectedId = cfg.pets[0]?.id ?? "";
    this.fx.onThunder = (d) => {
      this.audio.thunder(d);
      this.thunderQ.push(d);
    };
    this.applyWeather(true);
  }

  // ================= ukuran & dunia =================
  resize(cssW: number, cssH: number) {
    let P = clamp(Math.round(this.settings.pixel), 2, 6);
    while (P > 1 && (cssW / P < 190 || cssH / P < 140)) P--;
    const W = Math.max(150, Math.ceil(cssW / P));
    const H = Math.max(110, Math.ceil(cssH / P));
    this.P = P;
    this.W = W;
    this.H = H;
    this.TW = Math.max(W - 8, 300);
    this.TH = H - 8;
    this.canvas.width = W * P;
    this.canvas.height = H * P;
    this.canvas.style.width = "100%";
    this.canvas.style.height = "100%";
    for (const c of this.cages) c.resize(this.TW, this.TH);
    this.fx.resize(this.TW + 120, this.THmax);
    this.layoutWorld(true);
  }

  get THmax() {
    let m = this.TH;
    for (const c of this.cages) m = Math.max(m, c.H);
    return m;
  }

  cageX(i: number) {
    return this.GAP + i * (this.TW + this.GAP);
  }

  cageY(i: number) {
    return this.VM + this.THmax - (this.cages[i]?.H ?? this.TH);
  }

  private layoutWorld(snap: boolean) {
    this.VM = Math.round(this.TH * 0.9);
    this.roomKey = "";
    this.zIn = Math.min(1, this.W / (this.TW + 10));
    this.zOut = clamp(this.H / (this.THmax + 44), 0.28, 0.55);
    this.focus = clamp(this.focus, 0, this.cages.length - 1);
    this.cam.tz = this.zoomedIn ? this.zIn : this.zOut;
    this.cam.tx = this.cageX(this.focus) + this.TW / 2;
    this.cam.ty = this.camTargetY();
    if (snap) {
      this.cam.x = this.cam.tx;
      this.cam.y = this.cam.ty;
      this.cam.z = this.cam.tz;
    }
  }

  private worldW() {
    return this.cages.length * this.TW + (this.cages.length + 1) * this.GAP;
  }

  /** Target y kamera: menaramenara tinggi diikuti hamster terpilih. */
  private camTargetY() {
    const c = this.cages[this.focus];
    if (!c) return this.VM + this.THmax / 2;
    if (!this.zoomedIn) return this.VM + this.THmax / 2 + 6;
    const top = this.cageY(this.focus);
    const viewH = this.H / Math.max(0.2, this.cam.tz);
    if (c.H <= viewH - 2) return top + c.H / 2;
    const pet = c.pets.find((p) => p.id === this.selectedId) ?? c.pets[0];
    let fy = c.H - viewH / 2;
    if (pet) fy = pet.y - pet.z - 26;
    return top + clamp(fy, viewH / 2, c.H - viewH / 2);
  }

  setSettings(s: Settings) {
    const wasWeather = this.settings.weather;
    const wasVol = this.settings.weatherVol;
    const wasNight = this.settings.night;
    this.settings = s;
    if (s.weather !== wasWeather) this.applyWeather(false);
    else if (s.weatherVol !== wasVol) this.audio.setWeather(s.weather, s.weatherVol);
    if (s.night !== wasNight) this.roomKey = "";
  }

  private applyWeather(initial: boolean) {
    const k = this.settings.weather;
    this.fx.setKind(k);
    this.audio.setWeather(k, this.settings.weatherVol);
    this.roomKey = "";
    this.seenWeather.add(k);
    if (!initial) this.hooks.event("weather");
    if (!initial && this.seenWeather.size >= 4) this.hooks.achieve("weather");
    if (!initial) {
      const pet = this.cages[this.focus]?.pets[0];
      if (pet) {
        const msg = k === "rain" ? "hujan deras… 🌧️" : k === "storm" ? "badai petir! ⛈️" : k === "snow" ? "salju turun! ❄️" : "cerah lagi ☀️";
        this.cages[this.focus].sayText(pet, msg, 2.4);
      }
    }
  }

  // ================= kamera =================
  focusCage(i: number, silent = false) {
    this.focus = clamp(i, 0, this.cages.length - 1);
    this.zoomedIn = true;
    this.cam.tz = this.zIn;
    this.cam.tx = this.cageX(this.focus) + this.TW / 2;
    this.cam.ty = this.camTargetY();
    const c = this.cages[this.focus];
    if (!silent) this.audio.play("whoosh");
    if (c && !c.pets.some((p) => p.id === this.selectedId) && c.pets[0]) this.select(c.pets[0].id);
  }

  zoomOut() {
    if (!this.zoomedIn && this.cam.tz < 0.9) return;
    this.zoomedIn = false;
    this.cam.tz = this.zOut;
    this.cam.tx = this.cageX(this.focus) + this.TW / 2;
    this.cam.ty = this.camTargetY();
    this.audio.play("whoosh");
    this.hooks.event("zoom");
    if (this.cages.length >= 2) this.hooks.achieve("curator");
  }

  toggleZoom() {
    if (this.zoomedIn) this.zoomOut();
    else this.focusCage(this.focus);
  }

  step(dir: number) {
    if (this.zoomedIn) {
      const n = clamp(this.focus + dir, 0, this.cages.length - 1);
      if (n !== this.focus) this.focusCage(n);
    } else {
      this.cam.tx = clamp(this.cam.tx + dir * (this.TW + this.GAP), 0, this.worldW());
      this.audio.play("ui");
    }
  }

  // ================= loop =================
  start() {
    if (this.raf) return;
    this.last = performance.now();
    const loop = (ts: number) => {
      this.raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (ts - this.last) / 1000);
      this.last = ts;
      if (!this.paused) this.update(dt);
      this.render();
      this.snapT += dt;
      if (this.snapT > 0.14) {
        this.snapT = 0;
        this.onSnapshot?.(this.snapshot());
      }
    };
    this.raf = requestAnimationFrame(loop);
  }

  stop() {
    if (this.raf) cancelAnimationFrame(this.raf);
    this.raf = 0;
  }

  moodOf(pet: Pet) {
    const n = pet.needs;
    return clamp((n.happy * 0.4 + n.food * 0.2 + n.energy * 0.15 + n.clean * 0.15 + n.water * 0.1) / 100, 0, 1);
  }

  allPets() {
    const out: Pet[] = [];
    for (const c of this.cages) for (const p of c.pets) out.push(p);
    return out;
  }

  findPet(id: string) {
    return this.allPets().find((p) => p.id === id) ?? null;
  }

  select(id: string) {
    if (this.selectedId === id) return;
    this.selectedId = id;
    this.hooks.select(id);
  }

  pickPet(cage: Cage): Pet | null {
    const sel = cage.pets.find((p) => p.id === this.selectedId);
    if (sel) return sel;
    return cage.pets[0] ?? null;
  }

  update(dt: number) {
    this.t += dt;
    const prevDay = Math.floor(this.dayTime / 240);
    this.dayTime += dt;
    if (Math.floor(this.dayTime / 240) > prevDay) this.hooks.day();
    this.fx.update(dt);
    this.flash = Math.max(0, this.flash - dt * 2.2);

    for (let i = this.thunderQ.length - 1; i >= 0; i--) {
      this.thunderQ[i] -= dt;
      if (this.thunderQ[i] <= 0) {
        this.thunderQ.splice(i, 1);
        for (const c of this.cages) for (const p of c.pets) if (Math.random() < 0.7) c.scare(p);
      }
    }
    for (const c of this.cages) c.update(dt);

    // kamera
    const cam = this.cam;
    const e = 1 - Math.exp(-dt * 8);
    cam.x += (cam.tx - cam.x) * e;
    cam.z += (cam.tz - cam.z) * e;
    if (this.zoomedIn) cam.ty = this.camTargetY();
    cam.y += (cam.ty - cam.y) * (1 - Math.exp(-dt * (this.zoomedIn ? 4.5 : 8)));
    if (!this.zoomedIn) {
      const half = this.W / 2 / Math.max(0.2, cam.z);
      const ww = this.worldW();
      const lo = Math.min(half, ww / 2);
      const hi = Math.max(ww - half, ww / 2);
      cam.tx = clamp(cam.tx, lo, hi);
      cam.x = clamp(cam.x, lo - 40, hi + 40);
      let best = 0;
      let bd = 1e9;
      for (let i = 0; i < this.cages.length; i++) {
        const d = Math.abs(this.cageX(i) + this.TW / 2 - cam.x);
        if (d < bd) {
          bd = d;
          best = i;
        }
      }
      this.focus = best;
    } else if (Math.abs(cam.z - this.zIn) < 0.02) {
      cam.tx = this.cageX(this.focus) + this.TW / 2;
    }
  }

  // ================= render =================
  render() {
    const ctx = this.ctx;
    const cw = this.canvas.width;
    const ch = this.canvas.height;
    const cam = this.cam;
    const sc = this.P * cam.z;
    this.frameN++;

    const env = { night: this.settings.night, weather: this.fx.kind };
    const key = `${this.cages.length}|${this.TW}x${this.THmax}|${env.night}|${env.weather}`;
    if (key !== this.roomKey || !this.room) {
      this.room = buildRoom(this.cages.length, this.TW, this.THmax, this.GAP, this.VM, env);
      this.roomKey = key;
    }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = env.night ? "#2A2038" : "#9A6034";
    ctx.fillRect(0, 0, cw, ch);
    const tx = Math.round(cw / 2 - cam.x * sc);
    const ty = Math.round(ch / 2 - cam.y * sc);
    ctx.setTransform(sc, 0, 0, sc, tx, ty);
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(this.room, 0, 0);

    for (const c of this.cages) {
      const cy0 = this.cageY(c.idx);
      const x = this.cageX(c.idx) * sc + tx;
      const y = cy0 * sc + ty;
      const w = this.TW * sc;
      const h = c.H * sc;
      if (x > cw || x + w < 0 || y > ch || y + h < 0) continue;
      const focused = c === this.cages[this.focus];
      if (focused || cam.z > 0.8 || this.frameN % 3 === c.idx % 3 || !c.bgA) c.render(this.t);
      let ox = 0;
      let oy = 0;
      if (c.shake > 0.02) {
        ox = Math.round(Math.sin(this.t * 80) * c.shake * 2);
        oy = Math.round(Math.cos(this.t * 70) * c.shake * 1.5);
      }
      ctx.drawImage(c.cv, this.cageX(c.idx) + ox, cy0 + oy);
    }

    this.drawLabels(sc, tx, ty, cw, ch);

    if (this.flash > 0) {
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = `rgba(255,255,255,${clamp(this.flash, 0, 1) * 0.9})`;
      ctx.fillRect(0, 0, cw, ch);
    }
    this.updateBubbles(sc, tx, ty, cw, ch);
  }

  private drawLabels(sc: number, tx: number, ty: number, cw: number, ch: number) {
    const a = clamp((0.85 - this.cam.z) / 0.3, 0, 1);
    if (a <= 0.02) return;
    const ctx = this.ctx;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = a;
    const fs = Math.max(9, Math.min(16, Math.round(sc * 5.2)));
    for (const c of this.cages) {
      const x = this.cageX(c.idx) * sc + tx;
      const y = this.cageY(c.idx) * sc + ty;
      const w = this.TW * sc;
      const h = c.H * sc;
      if (x > cw || x + w < 0 || y > ch || y + h < 0) continue;
      const on = c === this.cages[this.focus];
      if (on) {
        ctx.strokeStyle = "#FFD08A";
        ctx.lineWidth = Math.max(2, Math.round(sc * 1.4));
        ctx.strokeRect(x - 2, y - 2, w + 4, h + 4);
      }
      const label = c.tall ? `MENARA ${c.idx + 1}` : `AQUARIUM ${c.idx + 1}`;
      const names = c.pets.map((p) => p.name).join(" · ") || "kosong";
      ctx.font = `${fs}px "Silkscreen", monospace`;
      const tw = Math.max(ctx.measureText(label).width, ctx.measureText(names).width * 0.8) + 18;
      const px = x + w / 2 - tw / 2;
      const py = y - fs * 3.3;
      ctx.fillStyle = "rgba(27,16,38,0.92)";
      ctx.fillRect(px, py, tw, fs * 2.6);
      ctx.strokeStyle = on ? "#FFD08A" : "#563A70";
      ctx.lineWidth = 2;
      ctx.strokeRect(px, py, tw, fs * 2.6);
      ctx.textAlign = "center";
      ctx.fillStyle = on ? "#FFD08A" : "#E8D9F5";
      ctx.fillText(label, x + w / 2, py + fs * 1.05);
      ctx.font = `${Math.round(fs * 0.8)}px "Silkscreen", monospace`;
      ctx.fillStyle = "#FFF1DC";
      ctx.fillText(names, x + w / 2, py + fs * 2.1);
    }
    ctx.textAlign = "start";
    ctx.globalAlpha = 1;
  }

  private updateBubbles(sc: number, tx: number, ty: number, cw: number, ch: number) {
    if (!this.stageEl) return;
    const c = this.cages[this.focus];
    const show = this.zoomedIn && this.cam.z > this.zIn * 0.85 && c;
    let used = 0;
    if (show) {
      for (const pet of c.pets) {
        if (this.t >= pet.bubbleUntil) continue;
        let el = this.bubbleEls[used];
        if (!el) {
          el = document.createElement("div");
          el.className = "bubble";
          this.stageEl.appendChild(el);
          this.bubbleEls[used] = el;
        }
        used++;
        const k = c.kBase(pet);
        const wx = this.cageX(c.idx) + pet.x;
        const wy = this.cageY(c.idx) + pet.y - pet.z - 64 * k;
        const sx = clamp((wx * sc + tx) / cw, 0.12, 0.88) * 100;
        const sy = clamp((wy * sc + ty) / ch, 0.1, 0.92) * 100;
        el.style.left = `${sx}%`;
        el.style.top = `${sy}%`;
        el.style.opacity = "1";
        if (el.textContent !== pet.bubbleText) el.textContent = pet.bubbleText;
      }
    }
    for (let i = used; i < this.bubbleEls.length; i++) this.bubbleEls[i].style.opacity = "0";
  }

  // ================= snapshot =================
  snapshot(): Snapshot {
    const hh = Math.floor((this.dayTime / 240) * 24) % 24;
    const mm = Math.floor((((this.dayTime / 240) * 24) % 1) * 60);
    const pets = this.allPets();
    const sel = pets.find((p) => p.id === this.selectedId) ?? pets[0];
    const cage = sel ? sel.cage : this.cages[this.focus];
    return {
      needs: sel ? { ...sel.needs } : { food: 0, happy: 0, energy: 0, clean: 0, water: 0 },
      act: sel?.act ?? "idle",
      mood: sel ? this.moodOf(sel) : 0,
      cheek: sel?.cheek ?? 0,
      poops: cage ? cage.items.filter((i) => i.kind === "poop").length : 0,
      bowl: cage?.bowl ?? 0,
      bottle: cage?.bottle ?? 0,
      stash: cage?.stash ?? 0,
      clock: `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`,
      wheelSec: this.wheelSec,
      focus: this.focus,
      zoomed: this.zoomedIn,
      cages: this.cages.length,
      cagePets: cage ? cage.pets.length : 0,
      pets: pets.map((p) => ({ id: p.id, name: p.name, act: p.act, mood: this.moodOf(p), cage: p.cage.idx, tier: p.tier })),
      weather: this.fx.kind,
      selectedId: sel?.id ?? "",
      tiers: this.cages[this.focus]?.L.tiers ?? 1,
      tier: sel?.tier ?? 0,
    };
  }

  // ================= input =================
  private toStage(clientX: number, clientY: number) {
    const r = this.canvas.getBoundingClientRect();
    return {
      sx: (clientX - r.left) * (this.W / Math.max(1, r.width)),
      sy: (clientY - r.top) * (this.H / Math.max(1, r.height)),
    };
  }

  private toWorld(sx: number, sy: number) {
    const z = Math.max(0.1, this.cam.z);
    return { wx: this.cam.x + (sx - this.W / 2) / z, wy: this.cam.y + (sy - this.H / 2) / z };
  }

  private cageAt(wx: number, wy: number) {
    for (let i = 0; i < this.cages.length; i++) {
      const x = this.cageX(i);
      const y = this.cageY(i);
      if (wx >= x && wx <= x + this.TW && wy >= y && wy <= y + this.cages[i].H) return i;
    }
    return -1;
  }

  private interactive() {
    return this.zoomedIn && this.cam.z > this.zIn * 0.92;
  }

  pointerDown(clientX: number, clientY: number) {
    const { sx, sy } = this.toStage(clientX, clientY);
    const { wx, wy } = this.toWorld(sx, sy);
    const i = this.cageAt(wx, wy);
    this.ptr.down = true;
    this.ptr.sx = sx;
    this.ptr.sy = sy;
    this.ptr.moved = 0;
    if (this.interactive()) {
      const c = this.cages[this.focus];
      this.ptr.mode = "cage";
      this.ptr.cage = c;
      c.pointer.inside = true;
      if (i === this.focus) c.pointerDown(wx - this.cageX(i), wy - this.cageY(i), this.tool);
    } else {
      this.ptr.mode = "pan";
      this.ptr.cageIdx = i;
    }
  }

  pointerMove(clientX: number, clientY: number) {
    const { sx, sy } = this.toStage(clientX, clientY);
    if (this.ptr.down && this.ptr.mode === "pan") {
      const dx = (sx - this.ptr.sx) / Math.max(0.1, this.cam.z);
      this.ptr.moved += Math.abs(sx - this.ptr.sx) + Math.abs(sy - this.ptr.sy);
      this.cam.tx -= dx;
      this.cam.x -= dx;
      this.ptr.sx = sx;
      this.ptr.sy = sy;
      return;
    }
    if (this.interactive()) {
      const c = this.cages[this.focus];
      const { wx, wy } = this.toWorld(sx, sy);
      c.pointerMove(wx - this.cageX(c.idx), wy - this.cageY(c.idx));
    }
  }

  pointerUp() {
    if (this.ptr.down && this.ptr.mode === "pan" && this.ptr.moved < 8 && this.ptr.cageIdx >= 0) {
      this.focusCage(this.ptr.cageIdx);
    }
    if (this.ptr.mode === "cage" && this.ptr.cage) this.ptr.cage.pointerUp();
    this.ptr.down = false;
    this.ptr.mode = "none";
    this.ptr.cage = null;
  }

  pointerLeave() {
    for (const c of this.cages) {
      if (c.grab.mode === "none") c.pointer.inside = false;
    }
  }

  wheel(deltaY: number) {
    if (deltaY > 0) this.zoomOut();
    else if (!this.zoomedIn) this.focusCage(this.focus);
  }

  // ================= perintah =================
  setLook(id: string, look: Look) {
    const p = this.findPet(id);
    if (p) p.look = look;
  }

  rename(id: string, name: string) {
    const p = this.findPet(id);
    if (p) p.name = name;
  }

  setCageTheme(idx: number, theme: string) {
    const c = this.cages[idx];
    if (c) {
      c.rec.theme = theme;
      c.bgKey = "";
    }
  }

  setCageLights(idx: number, lights: string) {
    const c = this.cages[idx];
    if (c) c.rec.lights = lights;
  }

  addPet(rec: PetRec) {
    const c = this.cages[clamp(rec.cage, 0, this.cages.length - 1)];
    const p = makePet(rec, c);
    c.pets.push(p);
    c.burst("sparkle", p.x, p.y - 20, 8, "#FFE873", 24, -24);
    c.burst("heart", p.x, p.y - 30, 3, "#FF6F9C", 12, -20);
    c.sayText(p, "halo semua! 🐹", 2.6);
    this.audio.play("happy");
  }

  addCage(rec: CageRec) {
    const c = new Cage(this, this.cages.length, rec, this.TW, rec.tiers === 3 ? TOWER_H : this.TH);
    this.cages.push(c);
    this.layoutWorld(false);
    this.audio.play("happy");
    return c.idx;
  }

  moveTo(id: string, cageIdx: number) {
    const p = this.findPet(id);
    const dest = this.cages[cageIdx];
    if (!p || !dest || p.cage === dest) return;
    const src = p.cage;
    if (src.fight && (src.fight.a === p || src.fight.b === p)) src.endFight();
    if (src.wheel.occ === p) src.wheel.occ = null;
    if (src.grab.pet === p) src.grab = { pet: null, mode: "none", moved: 0 };
    src.pets = src.pets.filter((o) => o !== p);
    src.burst("puff", p.x, p.y - 20, 4, "#FFFFFF", 18, -10);
    p.cage = dest;
    dest.pets.push(p);
    p.tier = 0;
    p.plan = null;
    const b = dest.L.bands[0];
    p.x = rand(dest.L.minX + 20, dest.L.maxX - 20);
    p.y = rand(b.minY, b.maxY);
    p.z = 0;
    p.vz = 0;
    p.rot = 0;
    p.locked = false;
    p.dizzy = 0;
    p.stashing = false;
    dest.setAct(p, "idle", 1.5);
    dest.burst("puff", p.x, p.y - 20, 4, "#FFFFFF", 18, -10);
    dest.sayText(p, "rumah baru! ✨", 2.4);
    this.audio.play("whoosh");
  }

  command(cmd: string, petId?: string) {
    const pet = (petId ? this.findPet(petId) : null) ?? this.findPet(this.selectedId) ?? this.cages[this.focus]?.pets[0] ?? null;
    const cage = pet ? pet.cage : this.cages[this.focus];
    if (!cage) return;
    const L = cage.L;
    if (cmd === "photo") {
      this.flash = 1;
      this.audio.play("shutter");
      return;
    }
    if (cmd === "refillBowl") {
      cage.bowl = 1;
      this.audio.play("water");
      cage.burst("crumb", L.bowl.x, L.bowl.y - 10, 8, "#E8C98A", 22, -26);
      return;
    }
    if (cmd === "refillBottle") {
      cage.bottle = 1;
      this.audio.play("water");
      cage.burst("bubble", L.bottle.tipX, L.bottle.tipY, 6, "#BEEBFF", 12, -20);
      return;
    }
    if (!pet) return;
    if (["tumble", "fly", "knocked", "held", "climb", "slide", "skid", "wall", "roll"].includes(pet.act)) return;
    if (pet.locked) cage.endFight();
    cage.grab = { pet: null, mode: "none", moved: 0 };
    pet.stashing = false;
    pet.plan = null;
    const b = cage.band(pet);
    const [lo, hi] = cage.xRange(pet.tier);
    switch (cmd) {
      case "wheel":
        if (cage.wheel.occ && cage.wheel.occ !== pet) {
          cage.sayText(pet, "rodanya dipakai… 😅");
          return;
        }
        cage.goWheel(pet, rand(10, 16));
        cage.sayText(pet, "ayo lari! 🎡", 2);
        break;
      case "turbo":
        if (cage.wheel.occ && cage.wheel.occ !== pet) {
          cage.sayText(pet, "rodanya dipakai… 😅");
          return;
        }
        if (pet.act === "run") {
          cage.wheel.turbo = 1.6;
          cage.wheel.willTumble = true;
          this.audio.play("spin");
        } else {
          pet.forceTumble = true;
          cage.goWheel(pet, 14);
        }
        cage.sayText(pet, "siap turbo! 🌪️", 2);
        break;
      case "sleep":
        cage.startHide(pet, 24, true);
        cage.sayText(pet, "bobo di rumah ya… 😴", 2.4);
        break;
      case "hide":
        cage.startHide(pet, rand(9, 14), false);
        cage.sayText(pet, "cilukba! 🏠", 2);
        break;
      case "bury":
        cage.startBury(pet, rand(9, 14), pet.needs.energy < 60);
        cage.sayText(pet, "gali gali~ 🕳️", 2);
        break;
      case "bath":
        cage.goProp(pet, "bath", "bath", 5.5);
        cage.sayText(pet, "mandi pasir! 🏖️", 2);
        break;
      case "call":
        cage.goTo(pet, cage.W * 0.5, b.maxY - 6, "beg", 2.6);
        cage.sayText(pet, "iya? 🐹", 2);
        break;
      case "treat":
        cage.hop(pet, 1.4);
        cage.sayText(pet, "YEAY! ✨", 2);
        break;
      case "glass":
        cage.goTo(pet, clamp(cage.W * 0.5 + rand(-40, 40), lo + 12, hi - 12), b.maxY, "glass", rand(5, 8));
        cage.sayText(pet, "mau nyapa! 👋", 2);
        break;
      case "wall":
        if (pet.tier !== 0) {
          cage.sayText(pet, "tembok di bawah aja ya", 2);
          return;
        }
        cage.goTo(pet, Math.random() < 0.5 ? L.x0 + 14 : L.x1 - 14, b.maxY - 4, "wall", 6);
        cage.sayText(pet, "aku bisa manjat! 🕷️", 2);
        break;
      case "look":
        cage.setAct(pet, "look", rand(3.6, 5));
        cage.say(pet, "look", true);
        break;
      case "roll":
        cage.startRoll(pet);
        break;
      case "lick":
        cage.setAct(pet, "groom", 4);
        break;
      case "explore": {
        if (L.tiers < 3) {
          cage.sayText(pet, "butuh aquarium menara 🪜", 2.4);
          return;
        }
        const tt = pet.tier >= 2 ? 0 : 2;
        pet.explore = tt === 2;
        const [l2, h2] = cage.xRange(tt);
        const bb = L.bands[tt];
        cage.goTo(pet, rand(l2 + 16, h2 - 16), rand(bb.minY, bb.maxY), "idle", 2.5, false, tt);
        cage.sayText(pet, tt === 2 ? "naik ke atas! 🪜" : "turun lewat perosotan! 🛝", 2.2);
        break;
      }
      case "fight": {
        const m = cage.mate(pet);
        if (!m) cage.sayText(pet, "butuh teman main 🥺", 2.4);
        else cage.startFight(pet, m);
        break;
      }
    }
  }

  /** Ledakan perayaan di sekitar hamster terpilih. */
  celebrate(kind: "star" | "heart", text?: string) {
    const c = this.cages[this.focus];
    const p = c?.pets.find((o) => o.id === this.selectedId) ?? c?.pets[0];
    if (!c || !p) return;
    const k = c.kBase(p);
    c.burst(kind, p.x, p.y - 40 * k, 12, kind === "star" ? "#FFD84D" : "#FF6F9C", 36, -46);
    if (text) c.sayText(p, text, 2.4);
  }

  /** Belaian cepat lewat papan ketik. */
  tapSelected() {
    const c = this.cages[this.focus];
    const p = c?.pets.find((o) => o.id === this.selectedId) ?? c?.pets[0];
    if (!c || !p) return;
    c.pointerDown(p.x, p.y - p.z - 24 * c.kBase(p), { kind: "hand" });
    window.setTimeout(() => c.pointerUp(), 260);
  }

  // ================= simpan / muat =================
  serialize() {
    return {
      dayTime: this.dayTime,
      wheelSec: this.wheelSec,
      cages: this.cages.map((c) => ({
        bowl: c.bowl, bottle: c.bottle, stash: c.stash,
        poops: c.items.filter((i) => i.kind === "poop").slice(0, 6).map((i) => ({ x: i.x, y: i.y, tier: i.tier })),
      })),
      pets: this.allPets().map((p) => ({ id: p.id, needs: { ...p.needs }, cheek: p.cheek })),
    };
  }

  restore(d: Partial<ReturnType<Engine["serialize"]>> | undefined) {
    if (!d) return;
    if (typeof d.dayTime === "number") this.dayTime = d.dayTime;
    if (typeof d.wheelSec === "number") this.wheelSec = d.wheelSec;
    if (Array.isArray(d.cages)) {
      d.cages.forEach((s, i) => {
        const c = this.cages[i];
        if (!c || !s) return;
        if (typeof s.bowl === "number") c.bowl = s.bowl;
        if (typeof s.bottle === "number") c.bottle = s.bottle;
        if (typeof s.stash === "number") c.stash = s.stash;
        if (Array.isArray(s.poops)) {
          for (const q of s.poops) c.items.push({ uid: c.uid++, kind: "poop", x: q.x, y: q.y, vy: 0, tier: (q as { tier?: number }).tier ?? 0 });
        }
      });
    }
    if (Array.isArray(d.pets)) {
      for (const s of d.pets) {
        const p = this.findPet(s.id);
        if (p && s.needs) {
          p.needs = { ...p.needs, ...s.needs };
          if (typeof s.cheek === "number") p.cheek = s.cheek;
        }
      }
    }
  }

  /** Ekspor foto PNG: tampilan saat ini dalam bingkai polaroid. */
  photoDataURL() {
    const src = this.canvas;
    const sc = Math.max(1, Math.round(this.P / 2));
    const pad = Math.round(sc * 10);
    const foot = Math.round(sc * 34);
    const out = document.createElement("canvas");
    out.width = src.width + pad * 2;
    out.height = src.height + pad * 2 + foot;
    const c = out.getContext("2d")!;
    c.imageSmoothingEnabled = false;
    c.fillStyle = "#FFF6E4";
    c.fillRect(0, 0, out.width, out.height);
    c.drawImage(src, pad, pad);
    c.fillStyle = "#7A4A2A";
    c.font = `${Math.round(sc * 13)}px "Silkscreen", monospace`;
    c.textAlign = "center";
    const sel = this.findPet(this.selectedId);
    c.fillText(`${sel ? sel.name : "Hamsteru"} - Hari ke-${Math.floor(this.dayTime / 240) + 1}`, out.width / 2, src.height + pad + Math.round(sc * 22));
    return out.toDataURL("image/png");
  }
}

// ====== Tipe & data dunia Hamster ======

export type WeatherKind = "clear" | "rain" | "storm" | "snow";

export type PatternId = "polos" | "tuxedo" | "bercak" | "belang" | "panda" | "siam";

export type Look = {
  palette: string;
  pattern: PatternId;
  eye: string;
  fluff: number; // 0..1 kebuluan
  chub: number; // 0.85..1.3 kegemukan
  scale: number; // 0.78..1.3
  eyeSize: number; // 0.25..1.6 (default kecil seperti mata manik)
  cheek: number; // 0..1 pipi dasar
  blush: number; // 0..1
  earSize: number; // 0.7..1.45
  accessory: string;
  sparkle: boolean;
};

export type Settings = {
  pixel: number; // 2..5 ketebalan pixel
  speed: number; // 0.5..2 kecepatan hamster
  particles: number; // 0..1.6
  night: boolean;
  music: boolean;
  sfx: boolean;
  weather: WeatherKind;
  weatherVol: number; // 0..1.2
};

export type MissionState = {
  day: number;
  daily: { id: string; base: number; claimed: boolean }[];
  claimedCount: number;
  streak: number;
  lastClaimDay: number;
  chainClaimed: string[];
};

export type Profile = {
  coins: number;
  xp: number;
  level: number;
  day: number;
  owned: string[];
  inv: Record<string, number>;
  achievements: string[];
  pets: number;
  poops: number;
  wheelSec: number;
  meals: number;
  photos: number;
  styles: number;
  tumbles: number;
  fights: number;
  burrows: number;
  bonks: number;
  stats: Record<string, number>;
  missions: MissionState;
};

export type Needs = {
  food: number;
  happy: number;
  energy: number;
  clean: number;
  water: number;
};

export type PetRec = { id: string; name: string; look: Look; cage: number };
export type CageRec = { id: string; theme: string; tiers?: 1 | 3; lights?: string };

export type FurPalette = {
  id: string;
  name: string;
  base: string;
  light: string;
  dark: string;
  belly: string;
  ear: string;
  line: string;
};

export const PALETTES: FurPalette[] = [
  { id: "karamel", name: "Karamel", base: "#F0A860", light: "#FFCE96", dark: "#C87C3C", belly: "#FFF1DA", ear: "#FF9FB4", line: "#5C3220" },
  { id: "susu", name: "Krim Susu", base: "#F5E0BE", light: "#FFF6E8", dark: "#D6B187", belly: "#FFFBF2", ear: "#FFA8BC", line: "#7A5334" },
  { id: "awan", name: "Abu Awan", base: "#BAB7CE", light: "#E1DEF2", dark: "#8B87A4", belly: "#F5F3FF", ear: "#E7A6C0", line: "#4A4560" },
  { id: "bubuk", name: "Cokelat Bubuk", base: "#AC744C", light: "#D59E70", dark: "#7C4C2E", belly: "#F4DCC0", ear: "#E58C9E", line: "#40241A" },
  { id: "salju", name: "Salju", base: "#F1EFF6", light: "#FFFFFF", dark: "#CEC8DB", belly: "#FFFFFF", ear: "#FFB3C6", line: "#6B6478" },
  { id: "persik", name: "Persik", base: "#FFB9A0", light: "#FFDCCB", dark: "#E08A73", belly: "#FFF2E8", ear: "#FF8FA3", line: "#7A3E36" },
  { id: "matcha", name: "Matcha", base: "#C2DA8C", light: "#E4F3BA", dark: "#93B260", belly: "#F8FFE4", ear: "#FFA9B8", line: "#4B5A2A" },
  { id: "sakura", name: "Sakura", base: "#FFC2D6", light: "#FFE3EC", dark: "#E08FAC", belly: "#FFF4F8", ear: "#FF7FA0", line: "#7A3550" },
  { id: "langit", name: "Langit Biru", base: "#A9CFF5", light: "#DCEFFF", dark: "#7AA0D0", belly: "#F2F9FF", ear: "#FFA6BE", line: "#3E5578" },
  { id: "senja", name: "Ungu Senja", base: "#9E86C8", light: "#C6B0EC", dark: "#6F5A9B", belly: "#EDE2FF", ear: "#F09AC0", line: "#3A2C58" },
  { id: "madu", name: "Madu Emas", base: "#FFD066", light: "#FFE9A8", dark: "#DDA32E", belly: "#FFF7DC", ear: "#FF9AAE", line: "#6E4A12" },
  { id: "arang", name: "Arang Lembut", base: "#6E6480", light: "#948AA8", dark: "#4B435C", belly: "#D9D0E8", ear: "#D98FAE", line: "#2A2438" },
];

export const PATTERNS: { id: PatternId; name: string }[] = [
  { id: "polos", name: "Polos" },
  { id: "tuxedo", name: "Tuxedo" },
  { id: "bercak", name: "Bercak" },
  { id: "belang", name: "Belang" },
  { id: "panda", name: "Panda" },
  { id: "siam", name: "Siam" },
];

export const EYES: { id: string; name: string; c: string }[] = [
  { id: "hitam", name: "Manik Hitam", c: "#2A1E2C" },
  { id: "cokelat", name: "Cokelat Karamel", c: "#7A4A2A" },
  { id: "amber", name: "Amber Madu", c: "#E3A020" },
  { id: "malam", name: "Ungu Malam", c: "#5A4668" },
  { id: "biru", name: "Biru Langit", c: "#4A8BE0" },
  { id: "hijau", name: "Zamrud", c: "#3FB06A" },
  { id: "rubi", name: "Rubi", c: "#D8456A" },
];

export type Food = {
  id: string;
  name: string;
  emoji: string;
  price: number;
  food: number;
  happy: number;
  cheek: number;
  crumb: string;
  desc: string;
};

export const FOODS: Food[] = [
  { id: "kuaci", name: "Biji Kuaci", emoji: "🌻", price: 4, food: 14, happy: 4, cheek: 0.34, crumb: "#F6EEDC", desc: "Camilan wajib, pipi jadi gembung." },
  { id: "wortel", name: "Wortel Mini", emoji: "🥕", price: 8, food: 22, happy: 6, cheek: 0.2, crumb: "#FF9442", desc: "Kriuk manis, bagus untuk gigi." },
  { id: "brokoli", name: "Brokoli", emoji: "🥦", price: 9, food: 20, happy: 5, cheek: 0.16, crumb: "#4CAF50", desc: "Pohon mungil penuh vitamin." },
  { id: "jagung", name: "Jagung Manis", emoji: "🌽", price: 10, food: 26, happy: 8, cheek: 0.28, crumb: "#FFD84D", desc: "Favorit semua hamster sedunia." },
  { id: "stroberi", name: "Stroberi", emoji: "🍓", price: 14, food: 16, happy: 16, cheek: 0.18, crumb: "#F2465F", desc: "Manis sekali, bikin goyang bahagia." },
  { id: "keju", name: "Keju Kotak", emoji: "🧀", price: 16, food: 24, happy: 14, cheek: 0.22, crumb: "#FFD34D", desc: "Hadiah spesial, wangi banget." },
];

export type Accessory = { id: string; name: string; price: number; emoji: string };

export const ACCESSORIES: Accessory[] = [
  { id: "none", name: "Tanpa Aksesori", price: 0, emoji: "✨" },
  { id: "pita", name: "Pita Merah Muda", price: 20, emoji: "🎀" },
  { id: "jerami", name: "Topi Jerami", price: 35, emoji: "👒" },
  { id: "bunga", name: "Bunga Sakura", price: 28, emoji: "🌸" },
  { id: "kacamata", name: "Kacamata Bundar", price: 45, emoji: "👓" },
  { id: "syal", name: "Syal Rajut", price: 40, emoji: "🧣" },
  { id: "jamur", name: "Topi Jamur", price: 55, emoji: "🍄" },
  { id: "mahkota", name: "Mahkota Emas", price: 90, emoji: "👑" },
  { id: "bintang", name: "Jepit Bintang", price: 32, emoji: "⭐" },
];

// ---------- lampu hias ----------
export type LightDef = { id: string; name: string; emoji: string; price: number; desc: string };
export const LIGHTS: LightDef[] = [
  { id: "bendera", name: "Bendera Pesta", emoji: "🎏", price: 0, desc: "Bendera warna-warni yang berayun." },
  { id: "bintang", name: "Bintang Emas", emoji: "⭐", price: 0, desc: "Untaian bintang hangat berkelip." },
  { id: "bunga", name: "Bunga Sakura", emoji: "🌸", price: 40, desc: "Kelopak merah muda bercahaya lembut." },
  { id: "lentera", name: "Lentera Kertas", emoji: "🏮", price: 55, desc: "Lentera jingga yang hangat dan syahdu." },
  { id: "kunang", name: "Kunang-kunang", emoji: "✨", price: 65, desc: "Titik cahaya yang berdenyut pelan." },
  { id: "hati", name: "Hati Merah Muda", emoji: "💗", price: 60, desc: "Lampu berbentuk hati yang berdebar." },
  { id: "pelangi", name: "Bola Pelangi", emoji: "🌈", price: 80, desc: "Bola warna-warni yang berganti warna." },
];

export type Deco = "meadow" | "sakura" | "night" | "bay" | "forest" | "candy";

export type Theme = {
  id: string;
  name: string;
  price: number;
  wall: string;
  wall2: string;
  wallDot: string;
  bed: string;
  bed2: string;
  bed3: string;
  wood: string;
  wood2: string;
  accent: string;
  sky: string;
  sky2: string;
  hill: string;
  hill2: string;
  deco: Deco;
};

export const THEMES: Theme[] = [
  {
    id: "padang", name: "Padang Madu", price: 0,
    wall: "#F3C98B", wall2: "#E0AE6B", wallDot: "#F7DDAE",
    bed: "#F6E2BB", bed2: "#E4C694", bed3: "#CBA46E",
    wood: "#B87843", wood2: "#8C5530", accent: "#FF7FA8", sky: "#8FD8F5", sky2: "#CFEEFB",
    hill: "#8FD98A", hill2: "#6EC37C", deco: "meadow",
  },
  {
    id: "sakura", name: "Taman Sakura", price: 60,
    wall: "#F7C6D8", wall2: "#E5A2BE", wallDot: "#FFE0EC",
    bed: "#FCE7EC", bed2: "#EFC6D3", bed3: "#D79FB2",
    wood: "#C07A86", wood2: "#8E505F", accent: "#FF5D8F", sky: "#BFE6FF", sky2: "#FFE9F3",
    hill: "#B6E3A6", hill2: "#93D1A0", deco: "sakura",
  },
  {
    id: "malam", name: "Malam Berbintang", price: 80,
    wall: "#3B3468", wall2: "#2A2450", wallDot: "#5A4F94",
    bed: "#5C5288", bed2: "#463E6E", bed3: "#332C55",
    wood: "#6C5A94", wood2: "#463769", accent: "#8BE0FF", sky: "#3A2E7A", sky2: "#7A63C4",
    hill: "#4C4C9A", hill2: "#3A3A7E", deco: "night",
  },
  {
    id: "laut", name: "Teluk Biru", price: 80,
    wall: "#9FDCF0", wall2: "#6FBCDC", wallDot: "#CFF2FC",
    bed: "#E8F6EE", bed2: "#C2E4DC", bed3: "#95C4BE",
    wood: "#4FA3B8", wood2: "#2E7286", accent: "#25E0C0", sky: "#7FD3F7", sky2: "#DFF7FF",
    hill: "#58B8D8", hill2: "#3E9CC4", deco: "bay",
  },
  {
    id: "jamur", name: "Hutan Jamur", price: 100,
    wall: "#A8C98A", wall2: "#7FA766", wallDot: "#C8E3AC",
    bed: "#E7DCB6", bed2: "#C7B788", bed3: "#A08F62",
    wood: "#96603C", wood2: "#6B4028", accent: "#FF6B57", sky: "#BFE8F5", sky2: "#E8F7D9",
    hill: "#7FB36A", hill2: "#5E9A5A", deco: "forest",
  },
  {
    id: "permen", name: "Pabrik Permen", price: 120,
    wall: "#C9B4F5", wall2: "#A78BE0", wallDot: "#E7DBFF",
    bed: "#FFE6F4", bed2: "#F3C3E2", bed3: "#D199C4",
    wood: "#A874D8", wood2: "#7A4CA8", accent: "#FFD84D", sky: "#FFC9E8", sky2: "#E5D6FF",
    hill: "#F7A6D2", hill2: "#D98EE6", deco: "candy",
  },
];

export type Achievement = { id: string; name: string; desc: string; emoji: string };

export const ACHIEVEMENTS: Achievement[] = [
  { id: "first_pet", name: "Sentuhan Pertama", desc: "Belai hamstermu sekali", emoji: "🤍" },
  { id: "full_cheek", name: "Pipi Gembung", desc: "Isi kantong pipi sampai penuh", emoji: "🐹" },
  { id: "athlete", name: "Atlet Cilik", desc: "Lari di roda total 60 detik", emoji: "🎡" },
  { id: "cleaner", name: "Kandang Kinclong", desc: "Bersihkan 10 kotoran", emoji: "🧹" },
  { id: "chef", name: "Koki Mungil", desc: "Beri makan 15 kali", emoji: "🍓" },
  { id: "friend", name: "Sahabat Sejati", desc: "Capai level 5", emoji: "💖" },
  { id: "stylist", name: "Penata Gaya", desc: "Ubah penampilan 12 kali", emoji: "🎀" },
  { id: "photo", name: "Fotografer Hamster", desc: "Ambil foto pertamamu", emoji: "📸" },
  { id: "collector", name: "Kolektor Imut", desc: "Miliki 5 barang di toko", emoji: "🛍️" },
  { id: "carry", name: "Gendong Aku!", desc: "Angkat hamstermu seperti bayi", emoji: "🫧" },
  { id: "tumble", name: "Pusing Tujuh Keliling", desc: "Hamster terlempar dari roda", emoji: "🌀" },
  { id: "bonk", name: "Tabrakan Gemas", desc: "Hamster menabrak temannya", emoji: "💫" },
  { id: "wrestler", name: "Gulat Gemas", desc: "Hamster main gulat dengan teman", emoji: "🤼" },
  { id: "burrow", name: "Pertapa Serbuk Kayu", desc: "Hamster mengubur dirinya", emoji: "🕳️" },
  { id: "hideout", name: "Anak Rumahan", desc: "Hamster bersembunyi di rumah mungil", emoji: "🏠" },
  { id: "curator", name: "Kurator Aquarium", desc: "Lihat semua aquarium dari jauh", emoji: "🔭" },
  { id: "weather", name: "Ahli Cuaca", desc: "Coba cerah, hujan, badai, dan salju", emoji: "⛈️" },
  { id: "climber", name: "Pendaki Mungil", desc: "Hamster memanjat tangga 5 kali", emoji: "🪜" },
  { id: "top", name: "Puncak Menara", desc: "Hamster mencapai lantai 3", emoji: "🏔️" },
  { id: "slider", name: "Raja Perosotan", desc: "Hamster meluncur 8 kali", emoji: "🛝" },
  { id: "crash", name: "Tabrakan di Ujung", desc: "Perosotan menabrak teman di bawah", emoji: "💥" },
  { id: "glass", name: "Halo, Manusia!", desc: "Hamster menyapamu lewat kaca", emoji: "👋" },
  { id: "wall", name: "Hamster Spiderman", desc: "Hamster mencoba memanjat dinding", emoji: "🕷️" },
  { id: "lick", name: "Mandi Kucing", desc: "Lihat hamster menjilat tangannya", emoji: "👅" },
  { id: "missions", name: "Pemburu Misi", desc: "Klaim 5 misi", emoji: "🎯" },
  { id: "roller", name: "Bola Hamster", desc: "Lihat hamster menggelinding", emoji: "⚽" },
];

export const DEFAULT_LOOK: Look = {
  palette: "karamel",
  pattern: "tuxedo",
  eye: "#2A1E2C",
  fluff: 0.7,
  chub: 1.08,
  scale: 1.08,
  eyeSize: 0.25,
  cheek: 0.72,
  blush: 0.6,
  earSize: 1,
  accessory: "pita",
  sparkle: true,
};

export const DEFAULT_SETTINGS: Settings = {
  pixel: 3,
  speed: 1,
  particles: 1,
  night: false,
  music: true,
  sfx: true,
  weather: "clear",
  weatherVol: 0.8,
};

export const DEFAULT_MISSIONS: MissionState = {
  day: 1, daily: [], claimedCount: 0, streak: 0, lastClaimDay: 0, chainClaimed: [],
};

export const DEFAULT_PROFILE: Profile = {
  coins: 180,
  xp: 0,
  level: 1,
  day: 1,
  owned: ["none", "pita", "bunga", "bintang", "padang", "sakura", "bendera"],
  inv: { kuaci: 8, wortel: 3, brokoli: 2, jagung: 2, stroberi: 2, keju: 1 },
  achievements: [],
  pets: 0,
  poops: 0,
  wheelSec: 0,
  meals: 0,
  photos: 0,
  styles: 0,
  tumbles: 0,
  fights: 0,
  burrows: 0,
  bonks: 0,
  stats: {},
  missions: { ...DEFAULT_MISSIONS },
};

export const DEFAULT_CAGES: CageRec[] = [
  { id: "c1", theme: "padang", tiers: 3, lights: "bintang" },
  { id: "c2", theme: "sakura", tiers: 1, lights: "bunga" },
];

export const DEFAULT_PETS: PetRec[] = [
  { id: "p1", name: "Mochi", look: { ...DEFAULT_LOOK }, cage: 0 },
  {
    id: "p2", name: "Kumo", cage: 0,
    look: { ...DEFAULT_LOOK, palette: "awan", pattern: "polos", fluff: 0.82, chub: 1.18, scale: 1.0, cheek: 0.85, blush: 0.7, earSize: 1.1, accessory: "bunga", eyeSize: 0.25 },
  },
  {
    id: "p3", name: "Pipi", cage: 1,
    look: { ...DEFAULT_LOOK, palette: "susu", pattern: "bercak", eye: "#3A2A24", fluff: 0.7, chub: 1.05, scale: 1.05, cheek: 0.7, accessory: "bintang", eyeSize: 0.25 },
  },
];

export const PET_NAMES = ["Boba", "Tofu", "Kiki", "Nori", "Pudding", "Cookie", "Mimi", "Choco", "Lulu", "Bubu", "Momo", "Susu"];

export const PRICE_PET = 60;
export const PRICE_CAGE = 110;
export const PRICE_TOWER = 260;
export const PRICE_BOX = 50;
export const MAX_CAGES = 5;
export const MAX_PETS_PER_CAGE = 3;

export const xpForLevel = (lvl: number) => 40 + (lvl - 1) * 34;

export const getPalette = (id: string) => PALETTES.find((p) => p.id === id) ?? PALETTES[0];
export const getTheme = (id: string) => THEMES.find((t) => t.id === id) ?? THEMES[0];
export const getFood = (id: string) => FOODS.find((f) => f.id === id) ?? FOODS[0];

export const ACTIVITY_LABEL: Record<string, string> = {
  idle: "sedang santai",
  walk: "jalan-jalan kecil",
  eat: "makan lahap, nyam nyam",
  stash: "menyimpan biji di rumah",
  groom: "mandi bulu, jilat tangan",
  sleep: "tidur pulas… zzz",
  run: "lari di roda!",
  dig: "menggali terowongan",
  bath: "mandi pasir",
  drink: "minum segar",
  held: "diangkat tangan hantu",
  pet: "kesenangan dibelai",
  hop: "LOMPAT BAHAGIA!",
  stretch: "peregangan",
  beg: "minta camilan…",
  play: "main bola",
  sniff: "mengendus-endus",
  shake: "kibas-kibas bulu!",
  tumble: "ikut berputar di roda!!",
  fly: "TERLEMPAR!!",
  knocked: "terpental, aduh!",
  dizzy: "pusing tujuh keliling…",
  chase: "kejar-kejaran!",
  alert: "siaga, ada apa ya?",
  spar: "tinju-tinjuan main-main",
  tussle: "gulat gemas bareng teman",
  flop: "ngakak guling-guling",
  bury: "mengubur diri di serbuk kayu",
  hide: "sembunyi di rumah mungil",
  scared: "kaget, gemetar kecil…",
  climb: "memanjat tangga",
  slide: "meluncur di perosotan!",
  skid: "mendarat, masih meluncur",
  glass: "menyapamu lewat kaca",
  wall: "mencoba memanjat dinding",
  lickhand: "menjilat tangannya",
  look: "menoleh kanan-kiri, atas-bawah",
  roll: "menggelinding, bola hamster!",
};

export const TIPS = [
  "Angkat hamster dengan menekan dan menggesernya. Tangan hantu yang bening menopangnya, dan kadang ia menjilat tangannya sendiri!",
  "Hamster kadang menoleh kanan-kiri, melihat ke atas dan ke bawah, atau menggelinding seperti bola. Gemas!",
  "Aquarium Menara punya 3 tingkat: hamster naik lewat tangga, turun lewat perosotan. Lihat gaya meluncurnya yang kadang salah posisi!",
  "Kadang ada hamster yang menunggu di ujung perosotan. Siap-siap tabrakan gemas!",
  "Tekan TURBO RODA dan lihat hamster berputar lalu terlempar jadi ragdoll yang jungkir balik.",
  "Hamster kadang datang ke kaca depan dan mengikuti kursormu. Coba gerakkan mouse pelan-pelan.",
  "Taruh dua hamster di satu aquarium: mereka bisa gulat main-main sampai ngakak.",
  "Selesaikan misi harian untuk hadiah biji, camilan, dan item langka. Setiap 5 klaim membuka Peti Kejutan!",
  "Lampu hias di toko bikin malam hari jadi indah. Nyalakan mode malam dan lihat kilauannya.",
];

// =====================================================================
//  MISI
// =====================================================================
export type Reward = { coins?: number; xp?: number; food?: Record<string, number>; unlock?: string[] };
export type MissionDef = { id: string; title: string; desc: string; emoji: string; key: string; goal: number; reward: Reward; hard?: boolean };

export const DAILY_POOL: MissionDef[] = [
  { id: "d_pet", title: "Belaian Hangat", desc: "Belai hamster 6 kali", emoji: "🤍", key: "pet", goal: 6, reward: { coins: 14, xp: 6 } },
  { id: "d_feed", title: "Jam Makan Mewah", desc: "Beri camilan 2 kali", emoji: "🍓", key: "feed", goal: 2, reward: { coins: 16, food: { stroberi: 1 } } },
  { id: "d_climb", title: "Pendaki Cilik", desc: "Lihat hamster memanjat tangga 2 kali", emoji: "🪜", key: "climb", goal: 2, reward: { coins: 22, xp: 8 } },
  { id: "d_slide", title: "Seluncur Seru", desc: "Lihat hamster meluncur 3 kali", emoji: "🛝", key: "slide", goal: 3, reward: { coins: 24, xp: 8 } },
  { id: "d_head", title: "Kepala Duluan!", desc: "Lihat hamster meluncur kepala duluan", emoji: "🤸", key: "slidehead", goal: 1, reward: { coins: 32, xp: 10 }, hard: true },
  { id: "d_crash", title: "Tabrakan di Ujung", desc: "Perosotan menabrak teman di bawah", emoji: "💥", key: "crash", goal: 1, reward: { coins: 44, xp: 12, food: { keju: 1 } }, hard: true },
  { id: "d_wheel", title: "Lari Pagi", desc: "Total lari di roda 25 detik", emoji: "🎡", key: "wheel", goal: 25, reward: { coins: 20, xp: 6 } },
  { id: "d_tumble", title: "Hamster Terbang", desc: "Hamster terlempar dari roda", emoji: "🌀", key: "tumble", goal: 1, reward: { coins: 32, xp: 10 }, hard: true },
  { id: "d_glass", title: "Halo di Kaca", desc: "Hamster menyapamu di kaca 2 kali", emoji: "👋", key: "glass", goal: 2, reward: { coins: 26, xp: 8 } },
  { id: "d_wall", title: "Si Pemanjat Tembok", desc: "Hamster mencoba memanjat dinding", emoji: "🕷️", key: "wall", goal: 1, reward: { coins: 30, xp: 8 }, hard: true },
  { id: "d_hide", title: "Cilukba!", desc: "Hamster bersembunyi di rumah 2 kali", emoji: "🏠", key: "hide", goal: 2, reward: { coins: 18, xp: 6 } },
  { id: "d_burrow", title: "Ngumpet di Serbuk", desc: "Hamster mengubur dirinya", emoji: "🕳️", key: "burrow", goal: 1, reward: { coins: 22, xp: 6 } },
  { id: "d_fight", title: "Gulat Gemas", desc: "Hamster main gulat dengan teman", emoji: "🤼", key: "fight", goal: 1, reward: { coins: 36, xp: 10 }, hard: true },
  { id: "d_clean", title: "Kandang Kinclong", desc: "Sapu 3 kotoran", emoji: "🧹", key: "clean", goal: 3, reward: { coins: 18, xp: 6 } },
  { id: "d_photo", title: "Sesi Foto", desc: "Ambil foto 1 kali", emoji: "📸", key: "photo", goal: 1, reward: { coins: 15, xp: 5 } },
  { id: "d_carry", title: "Gendong Gemes", desc: "Angkat hamster 2 kali", emoji: "🫶", key: "carry", goal: 2, reward: { coins: 16, xp: 6 } },
  { id: "d_lick", title: "Jilat-Jilat Manis", desc: "Lihat hamster menjilat tangannya", emoji: "👅", key: "lick", goal: 2, reward: { coins: 22, xp: 8 } },
  { id: "d_weather", title: "Pawang Cuaca", desc: "Ganti cuaca 2 kali", emoji: "🌦️", key: "weather", goal: 2, reward: { coins: 16, xp: 5 } },
  { id: "d_bath", title: "Wangi Segar", desc: "Hamster mandi pasir", emoji: "🏖️", key: "bath", goal: 1, reward: { coins: 16, xp: 5 } },
  { id: "d_drink", title: "Minum Segar", desc: "Hamster minum 2 kali", emoji: "💧", key: "drink", goal: 2, reward: { coins: 14, xp: 5 } },
  { id: "d_roll", title: "Bola Hamster", desc: "Lihat hamster menggelinding", emoji: "⚽", key: "roll", goal: 1, reward: { coins: 24, xp: 8 } },
  { id: "d_play", title: "Main Bola", desc: "Hamster main bola 1 kali", emoji: "🎾", key: "play", goal: 1, reward: { coins: 18, xp: 6 } },
];

export const CHAIN: MissionDef[] = [
  { id: "c_pet", title: "Sentuhan Lembut", desc: "Belai hamster 5 kali", emoji: "🤍", key: "pet", goal: 5, reward: { coins: 20, xp: 8 } },
  { id: "c_feed", title: "Camilan Pertama", desc: "Beri makan 3 kali", emoji: "🍓", key: "feed", goal: 3, reward: { coins: 20, food: { keju: 2 } } },
  { id: "c_climb", title: "Pendaki Mungil", desc: "Lihat hamster memanjat tangga 3 kali", emoji: "🪜", key: "climb", goal: 3, reward: { coins: 30, xp: 12, unlock: ["kacamata"] } },
  { id: "c_slide", title: "Perosotan Seru", desc: "Lihat hamster meluncur 4 kali", emoji: "🛝", key: "slide", goal: 4, reward: { coins: 34, xp: 12 } },
  { id: "c_wheel", title: "Lari Maraton", desc: "Total lari di roda 60 detik", emoji: "🎡", key: "wheel", goal: 60, reward: { coins: 40, xp: 14, unlock: ["lentera"] } },
  { id: "c_tumble", title: "Hamster Terbang", desc: "Hamster terlempar dari roda 2 kali", emoji: "🌀", key: "tumble", goal: 2, reward: { coins: 44, xp: 14, unlock: ["jamur"] } },
  { id: "c_glass", title: "Menyapa Dunia", desc: "Hamster menyapamu di kaca 3 kali", emoji: "👋", key: "glass", goal: 3, reward: { coins: 40, xp: 14, unlock: ["kunang"] } },
  { id: "c_bonk", title: "Tabrakan Gemas", desc: "Hamster saling tabrak 2 kali", emoji: "💫", key: "bonk", goal: 2, reward: { coins: 50, xp: 16 } },
  { id: "c_fight", title: "Gulat Gemas", desc: "Hamster main gulat 2 kali", emoji: "🤼", key: "fight", goal: 2, reward: { coins: 56, xp: 18, unlock: ["malam"] } },
  { id: "c_wall", title: "Si Penjelajah", desc: "Hamster mencoba memanjat dinding 2 kali", emoji: "🕷️", key: "wall", goal: 2, reward: { coins: 60, xp: 18, unlock: ["hati"] } },
  { id: "c_weather", title: "Kolektor Cuaca", desc: "Ganti cuaca 5 kali", emoji: "⛈️", key: "weather", goal: 5, reward: { coins: 64, xp: 20, unlock: ["laut"] } },
  { id: "c_slidehead", title: "Aksi Kepala Duluan", desc: "Lihat hamster meluncur kepala duluan 3 kali", emoji: "🤸", key: "slidehead", goal: 3, reward: { coins: 90, xp: 30, unlock: ["mahkota", "pelangi"] } },
];

export function missionDef(id: string): MissionDef | undefined {
  return DAILY_POOL.find((m) => m.id === id) ?? CHAIN.find((m) => m.id === id);
}

export function pickDaily(stats: Record<string, number>, taken: string[], preferHard: boolean): { id: string; base: number; claimed: boolean } {
  const takenKeys = new Set(taken.map((id) => missionDef(id)?.key));
  let pool = DAILY_POOL.filter((m) => !taken.includes(m.id) && !takenKeys.has(m.key));
  const hardPool = pool.filter((m) => !!m.hard === preferHard);
  if (hardPool.length) pool = hardPool;
  if (!pool.length) pool = DAILY_POOL.filter((m) => !taken.includes(m.id));
  const m = pool[Math.floor(Math.random() * pool.length)] ?? DAILY_POOL[0];
  return { id: m.id, base: stats[m.key] ?? 0, claimed: false };
}

export function mProgress(stats: Record<string, number>, def: MissionDef, base: number) {
  return Math.max(0, Math.min(def.goal, (stats[def.key] ?? 0) - base));
}

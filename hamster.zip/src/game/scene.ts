import { Px, hash2, mix, shade, clamp } from "./pixel";
import type { Theme, WeatherKind } from "./data";

export type Env = { night: boolean; weather: WeatherKind };

export type Band = { backY: number; minY: number; maxY: number };
export type LadderGeo = { from: number; xb: number; yb: number; xt: number; yt: number };
export type SlideGeo = { from: number; to: number; xs: number; ys: number; xe: number; ye: number };
export type Shelf = { tier: number; x0: number; x1: number; y: number; side: "L" | "R" };

export type Layout = {
  W: number;
  H: number;
  floorY: number;
  x0: number;
  x1: number;
  y0: number;
  y1: number;
  tiers: number;
  bands: Band[];
  shelves: Shelf[];
  ladders: LadderGeo[];
  slides: SlideGeo[];
  zMax: number[];
  tierOf: { hut: number; mound: number; wheel: number; bowl: number; bath: number; bottle: number };
  hut: { x: number; y: number };
  mound: { x: number; y: number };
  wheel: { x: number; y: number; r: number };
  bowl: { x: number; y: number };
  bath: { x: number; y: number };
  bottle: { x: number; y: number; h: number; tipX: number; tipY: number; drinkX: number; drinkY: number };
  minX: number;
  maxX: number;
  minY: number;
  maxY: number;
  tierAtY: (y: number) => number;
};

export const HUT_HALF_DOOR = 11;
export const HUT_DOOR_H = 24;
export const SHELF_D = 24;
export const SHELF_T = 7;
export const TOWER_H = 316;

export function slidePoint(sl: SlideGeo, u: number) {
  const uu = clamp(u, 0, 1);
  const x = sl.xs + (sl.xe - sl.xs) * uu;
  const f = 1 - Math.pow(1 - uu, 1.7);
  const y = sl.ys + (sl.ye - sl.ys) * f;
  const dfdu = 1.7 * Math.pow(Math.max(0.0001, 1 - uu), 0.7);
  const dx = sl.xe - sl.xs;
  const dy = (sl.ye - sl.ys) * dfdu;
  const len = Math.hypot(dx, dy) || 1;
  return { x, y, dx: dx / len, dy: dy / len };
}

export function makeLayout(W: number, H: number, tiers: 1 | 3 = 1): Layout {
  const x0 = 7;
  const x1 = W - 7;
  const y0 = 7;
  const y1 = H - 9;
  if (tiers === 3) {
    const u = W / 326;
    const D = SHELF_D;
    const backY0 = y1 - 56;
    const s1 = y1 - 134;
    const s2 = s1 - 98;
    const bands: Band[] = [
      { backY: backY0, minY: backY0 + 20, maxY: y1 - 4 },
      { backY: s1, minY: s1 + 9, maxY: s1 + D - 2 },
      { backY: s2, minY: s2 + 9, maxY: s2 + D - 2 },
    ];
    const shelves: Shelf[] = [
      { tier: 1, x0: Math.round(98 * u), x1: x1, y: s1, side: "R" },
      { tier: 2, x0: x0, x1: Math.round(234 * u), y: s2, side: "L" },
    ];
    const ladders: LadderGeo[] = [
      { from: 0, xb: Math.round(114 * u), yb: bands[0].maxY - 6, xt: Math.round(124 * u), yt: bands[1].maxY - 3 },
      { from: 1, xb: Math.round(214 * u), yb: bands[1].maxY - 3, xt: Math.round(224 * u), yt: bands[2].maxY - 3 },
    ];
    const slides: SlideGeo[] = [
      { from: 1, to: 0, xs: shelves[0].x0 + 2, ys: bands[1].minY + 10, xe: Math.round(28 * u), ye: y1 - 22 },
      { from: 2, to: 1, xs: shelves[1].x1 + 2, ys: bands[2].minY + 10, xe: Math.round(298 * u), ye: bands[1].minY + 10 },
    ];
    const bt = s2 - 14;
    const L: Layout = {
      W, H, floorY: backY0, x0, x1, y0, y1, tiers: 3, bands, shelves, ladders, slides,
      zMax: [92, 110, 84],
      tierOf: { hut: 2, mound: 1, wheel: 0, bowl: 0, bath: 0, bottle: 2 },
      hut: { x: Math.round(122 * u), y: s2 + 20 },
      mound: { x: Math.round(172 * u), y: s1 + 9 },
      wheel: { x: Math.round(268 * u), y: y1 - 12, r: 28 },
      bowl: { x: Math.round(168 * u), y: y1 - 15 },
      bath: { x: Math.round(208 * u), y: y1 - 11 },
      bottle: { x: 24, y: bt, h: 34, tipX: 37, tipY: bt + 14, drinkX: 27, drinkY: bt + 35 },
      minX: x0 + 16, maxX: x1 - 16, minY: bands[0].minY, maxY: bands[0].maxY,
      tierAtY: (y: number) => (y < s2 + D + SHELF_T ? 2 : y < s1 + D + SHELF_T ? 1 : 0),
    };
    return L;
  }
  const floorY = Math.round(H * 0.5);
  const r = clamp(Math.round(H * 0.19), 22, 34);
  const bh = clamp(Math.round(H * 0.34), 38, 58);
  const by = floorY - 1;
  const band: Band = { backY: floorY, minY: floorY + 22, maxY: y1 - 4 };
  return {
    W, H, floorY, x0, x1, y0, y1, tiers: 1, bands: [band], shelves: [], ladders: [], slides: [], zMax: [120],
    tierOf: { hut: 0, mound: 0, wheel: 0, bowl: 0, bath: 0, bottle: 0 },
    hut: { x: Math.round(W * 0.26), y: floorY + 34 },
    mound: { x: Math.round(W * 0.52), y: floorY + 40 },
    wheel: { x: Math.round(W * 0.82), y: floorY + 38, r },
    bowl: { x: Math.round(W * 0.38), y: H - 24 },
    bath: { x: Math.round(W * 0.66), y: H - 19 },
    bottle: { x: 24, y: by, h: bh, tipX: 37, tipY: by + 14, drinkX: 27, drinkY: by + 35 },
    minX: x0 + 16, maxX: x1 - 16, minY: band.minY, maxY: band.maxY,
    tierAtY: () => 0,
  };
}

export function ring(p: Px, cx: number, cy: number, r: number, th: number, c: string) {
  for (let i = -Math.ceil(r); i < Math.ceil(r); i++) {
    const t = (i + 0.5) / r;
    if (Math.abs(t) > 1) continue;
    const out = Math.round(r * Math.sqrt(1 - t * t));
    const ri = r - th;
    const ti = (i + 0.5) / ri;
    const inn = ri > 0.5 && Math.abs(ti) < 1 ? Math.round(ri * Math.sqrt(1 - ti * ti)) : -1;
    if (inn < 0) p.rect(cx - out, cy + i, out * 2 + 1, 1, c);
    else {
      p.rect(cx - out, cy + i, out - inn, 1, c);
      p.rect(cx + inn + 1, cy + i, out - inn, 1, c);
    }
  }
}

function newCanvas(w: number, h: number) {
  const cv = document.createElement("canvas");
  cv.width = w;
  cv.height = h;
  const ctx = cv.getContext("2d")!;
  ctx.imageSmoothingEnabled = false;
  return { cv, ctx, p: new Px(ctx) };
}

function skyColors(th: Theme | null, env: Env): [string, string] {
  if (env.night) {
    if (env.weather === "storm") return ["#080620", "#1E1848"];
    if (env.weather === "rain") return ["#0C0A28", "#26205A"];
    return ["#0E0A2C", "#352A6E"];
  }
  switch (env.weather) {
    case "rain": return ["#74839E", "#B2BECE"];
    case "storm": return ["#363F58", "#677390"];
    case "snow": return ["#C4D4E8", "#F0F6FC"];
    default: return th ? [th.sky, th.sky2] : ["#8FD8F5", "#CFEEFB"];
  }
}

function modC(env: Env) {
  return (c: string, snowK = 0.6) => {
    let r = c;
    if (env.weather === "rain") r = mix(r, "#6C7A92", 0.3);
    else if (env.weather === "storm") r = mix(r, "#2F3850", 0.5);
    else if (env.weather === "snow") r = mix(r, "#F3F8FF", snowK);
    if (env.night) r = mix(r, "#1A1445", 0.45);
    return r;
  };
}

// =====================================================================
//  LATAR AQUARIUM (diorama berlatar cuaca) + serbuk kayu
// =====================================================================
export function buildBackdrop(L: Layout, th: Theme, env: Env): { a: HTMLCanvasElement; b: HTMLCanvasElement } {
  const A = newCanvas(L.W, L.H);
  const B = newCanvas(L.W, L.H);
  let p = A.p;
  const { W, H, floorY, x0, x1, y0, y1 } = L;
  const mod = modC(env);
  const [top, bot] = skyColors(th, env);
  const clear = env.weather === "clear";

  for (let y = y0; y < floorY; y += 3) {
    p.rect(x0, y, x1 - x0, Math.min(3, floorY - y), mix(top, bot, (y - y0) / Math.max(1, floorY - y0)));
  }

  // bintang
  if (env.night && env.weather !== "storm") {
    for (let i = 0; i < 44; i++) {
      const sx = x0 + hash2(i, 1, 91) * (x1 - x0);
      const sy = y0 + 4 + hash2(i, 2, 93) * (floorY - y0 - 26);
      p.px(sx, sy, i % 5 === 0 ? "#FFE98A" : "#FFFFFF");
      if (i % 7 === 0) {
        const c = "rgba(255,255,255,0.55)";
        p.px(sx - 1, sy, c); p.px(sx + 1, sy, c); p.px(sx, sy - 1, c); p.px(sx, sy + 1, c);
      }
    }
  }
  // matahari / bulan
  const sx = Math.round(W * 0.78);
  const sy = y0 + 30;
  if (env.night) {
    if (env.weather === "clear" || env.weather === "snow") {
      p.ellipseDither(sx, sy, 15, 15, "rgba(255,243,196,0.4)");
      p.ellipse(sx, sy, 9, 9, "#FFF3C4");
      p.ellipse(sx + 4, sy - 2, 8, 8, mix(top, bot, 0.3));
    }
  } else if (clear) {
    p.ellipseDither(sx, sy, 18, 18, "rgba(255,240,150,0.45)");
    p.ellipse(sx, sy, 12, 12, "#FFD85C");
    p.ellipse(sx, sy, 10, 10, "#FFE873");
    p.ellipse(sx - 2, sy - 2, 6, 6, "#FFF6C2");
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      p.line(sx + Math.cos(a) * 14, sy + Math.sin(a) * 14, sx + Math.cos(a) * 18, sy + Math.sin(a) * 18, "rgba(255,236,140,0.75)");
    }
  } else if (env.weather === "snow") {
    p.ellipse(sx, sy, 10, 10, "rgba(255,255,255,0.45)");
  }

  // awan
  const cloud = (cx: number, cy: number, s: number, c1: string, c2: string) => {
    p.ellipse(cx, cy + 2 * s, 14 * s, 5 * s, c2);
    p.ellipse(cx - 8 * s, cy, 8 * s, 5.5 * s, c1);
    p.ellipse(cx + 7 * s, cy - 1 * s, 9 * s, 6.5 * s, c1);
    p.ellipse(cx - 1 * s, cy - 3 * s, 8 * s, 6 * s, c1);
    p.px(cx - 4 * s, cy - 6 * s, "#FFFFFF");
  };
  if (env.weather === "rain" || env.weather === "storm") {
    const storm = env.weather === "storm";
    const c1 = storm ? "#4B5570" : "#8F9BB0";
    const c2 = storm ? "#333C54" : "#6F7B92";
    for (let i = 0; i < 9; i++) cloud(x0 + (i / 8) * (x1 - x0), y0 + 6 + (i % 3) * 7, 1.2 + (i % 2) * 0.3, c1, c2);
    for (let i = 0; i < 6; i++) cloud(x0 + 14 + (i / 5) * (x1 - x0 - 28), y0 + 24 + (i % 2) * 9, 1.0, mix(c1, c2, 0.4), c2);
  } else if (env.weather === "snow") {
    for (let i = 0; i < 6; i++) cloud(x0 + 18 + (i / 5) * (x1 - x0 - 36), y0 + 10 + (i % 3) * 9, 1.1, "#EAF1F9", "#C9D5E5");
  } else if (env.night) {
    cloud(W * 0.22, y0 + 20, 1, "#5A5090", "#463C78");
    cloud(W * 0.58, y0 + 14, 0.8, "#5A5090", "#463C78");
  } else {
    cloud(W * 0.2, y0 + 22, 1.1, "#FFFFFF", "#DDEBF7");
    cloud(W * 0.5, y0 + 14, 0.8, "#FFFFFF", "#DDEBF7");
    cloud(W * 0.92, y0 + 34, 0.7, "#FFFFFF", "#DDEBF7");
  }

  const hillFar = mod(th.hill2);
  const hillNear = mod(th.hill);
  const hillShade = (c: string) => shade(c, -0.12);

  const tri = (x: number, yTop: number, h: number, w: number, c: string) => {
    for (let r = 0; r < h; r++) {
      const hw = (r / h) * w;
      p.rect(x - hw, yTop + r, hw * 2 + 1, 1, c);
    }
  };
  const tree = (x: number, y: number, s: number, trunk: string, c1: string, c2: string, c3: string) => {
    p.rect(x - 1.5 * s, y - 9 * s, 3 * s, 10 * s, mod(trunk));
    p.ellipse(x, y - 14 * s, 10.5 * s, 9 * s, c2);
    p.ellipse(x - 1 * s, y - 15 * s, 9.5 * s, 8 * s, c1);
    p.ellipse(x - 3 * s, y - 18 * s, 4 * s, 3 * s, c3);
  };
  const pine = (x: number, y: number, s: number, c1: string, c2: string) => {
    p.rect(x - 1, y - 4 * s, 2, 5 * s, mod("#6B4028"));
    for (let i = 0; i < 4; i++) {
      tri(x, y - 8 * s - i * 6 * s, 9 * s, (11 - i * 2.2) * s * 0.5, i % 2 ? c1 : c2);
    }
  };

  // bukit jauh
  if (th.deco !== "bay") {
    p.ellipse(W * 0.2, floorY - 2, W * 0.3, 26, hillFar);
    p.ellipse(W * 0.62, floorY, W * 0.36, 30, hillFar);
    p.ellipse(W * 0.95, floorY - 4, W * 0.22, 22, hillFar);
    p.ellipse(W * 0.2, floorY - 18, W * 0.2, 6, hillShade(hillFar));
  }

  // dekor tema
  const green1 = mod("#5DB85A");
  const green2 = mod("#3F9444");
  const green3 = mod("#8EDB7C");
  switch (th.deco) {
    case "meadow":
      tree(W * 0.14, floorY + 1, 1.15, "#7A4A28", green1, green2, green3);
      tree(W * 0.9, floorY - 1, 0.95, "#7A4A28", green1, green2, green3);
      tree(W * 0.62, floorY - 3, 0.7, "#7A4A28", green1, green2, green3);
      break;
    case "sakura": {
      const pk1 = mod("#FFB6CF");
      const pk2 = mod("#F08AAE");
      const pk3 = mod("#FFE0EC");
      tree(W * 0.16, floorY + 1, 1.25, "#7A4A3A", pk1, pk2, pk3);
      tree(W * 0.86, floorY, 1.05, "#7A4A3A", pk1, pk2, pk3);
      for (let i = 0; i < 18; i++) {
        p.px(x0 + hash2(i, 1, 301) * (x1 - x0), y0 + 8 + hash2(i, 2, 303) * (floorY - y0 - 8), i % 3 ? "#FFC4D8" : "#FFFFFF");
      }
      break;
    }
    case "night":
      for (let i = 0; i < 6; i++) pine(W * (0.08 + i * 0.17) + hash2(i, 1, 311) * 8, floorY - 1 + (i % 2) * 2, 1 + (i % 3) * 0.12, mod("#3D6B58"), mod("#2E5848"));
      for (let i = 0; i < 6; i++) {
        const fx = x0 + 10 + hash2(i, 2, 313) * (x1 - x0 - 20);
        const fy = floorY - 22 + hash2(i, 3, 315) * 20;
        p.ellipseDither(fx, fy, 3, 3, "rgba(255,244,150,0.5)");
        p.px(fx, fy, "#FFF5A0");
      }
      break;
    case "bay": {
      for (let y = floorY - 18; y < floorY; y++) {
        p.rect(x0, y, x1 - x0, 1, mod(mix("#58C4EC", "#2E88C4", (y - (floorY - 18)) / 18)));
      }
      for (let i = 0; i < 16; i++) {
        const wx = x0 + hash2(i, 1, 321) * (x1 - x0);
        const wy = floorY - 16 + hash2(i, 2, 323) * 14;
        p.rect(wx, wy, 4, 1, mod("#BFEFFF"));
      }
      // perahu layar
      const bx = W * 0.3;
      const by2 = floorY - 12;
      p.rect(bx - 8, by2, 16, 3, mod("#8C5530"));
      p.rect(bx - 6, by2 + 3, 12, 1, mod("#6B4028"));
      p.rect(bx, by2 - 17, 1, 17, mod("#6B4028"));
      tri(bx + 1, by2 - 16, 14, 5, mod("#FFFFFF"));
      tri(bx - 1, by2 - 12, 10, 4, mod("#FF8FB0"));
      // mercusuar
      const lx = W * 0.86;
      for (let r = 0; r < 24; r++) {
        const hw = 4 - r * 0.07;
        p.rect(lx - hw, floorY - 22 + r, hw * 2, 1, Math.floor(r / 4) % 2 ? mod("#FF6B6B") : mod("#FFFFFF"));
      }
      p.rect(lx - 5, floorY - 25, 10, 3, mod("#4A4A5A"));
      p.rect(lx - 3, floorY - 29, 6, 4, "#FFE873");
      p.rect(lx - 4, floorY - 31, 8, 2, mod("#FF6B6B"));
      p.ellipse(W * 0.55, y0 + 18, 2, 1, "#FFFFFF");
      p.px(W * 0.55 - 3, y0 + 17, "#FFFFFF");
      p.px(W * 0.55 + 3, y0 + 17, "#FFFFFF");
      break;
    }
    case "forest": {
      const shroom = (x: number, y: number, s: number, c: string) => {
        p.rect(x - 2 * s, y - 8 * s, 4 * s, 9 * s, mod("#F2E4C2"));
        p.ellipse(x, y - 10 * s, 11 * s, 7 * s, shade(mod(c), -0.25));
        p.ellipse(x, y - 11 * s, 10 * s, 6 * s, mod(c));
        for (let i = 0; i < 4; i++) p.ellipse(x - 6 * s + i * 4 * s, y - 12 * s + (i % 2) * 2 * s, 1.8 * s, 1.4 * s, mod("#FFF3E0"));
      };
      pine(W * 0.38, floorY - 2, 1, mod("#3F8A55"), mod("#2E7040"));
      pine(W * 0.7, floorY - 3, 0.9, mod("#3F8A55"), mod("#2E7040"));
      shroom(W * 0.13, floorY + 2, 1.4, "#FF5A47");
      shroom(W * 0.9, floorY + 1, 1.1, "#FFB347");
      break;
    }
    case "candy": {
      const lolly = (x: number, y: number, s: number, c1: string, c2: string) => {
        p.rect(x - 1, y - 14 * s, 2, 16 * s, mod("#FFF1F7"));
        p.ellipse(x, y - 18 * s, 8 * s + 1, 8 * s + 1, mod("#D86AA8"));
        p.ellipse(x, y - 18 * s, 8 * s, 8 * s, mod(c1));
        p.ellipse(x, y - 18 * s, 5.5 * s, 5.5 * s, mod(c2));
        p.ellipse(x, y - 18 * s, 3 * s, 3 * s, mod(c1));
        p.px(x - 3 * s, y - 22 * s, "#FFFFFF");
      };
      lolly(W * 0.15, floorY + 1, 1.1, "#FF8FC4", "#FFFFFF");
      lolly(W * 0.88, floorY, 0.9, "#8FD8FF", "#FFFFFF");
      lolly(W * 0.66, floorY - 2, 0.7, "#FFD84D", "#FFFFFF");
      for (let i = 0; i < 10; i++) {
        p.rect(x0 + hash2(i, 1, 331) * (x1 - x0), floorY - 10 + hash2(i, 2, 333) * 8, 2, 1, ["#FF6BA8", "#FFD84D", "#6BD8FF", "#9B7BFF"][i % 4]);
      }
      break;
    }
  }

  // bukit dekat
  const nearA = th.deco === "bay" ? mod("#F3DFA8") : hillNear;
  p.ellipse(W * 0.05, floorY + 3, W * 0.3, 20, nearA);
  p.ellipse(W * 0.42, floorY + 6, W * 0.3, 15, nearA);
  p.ellipse(W * 0.8, floorY + 4, W * 0.35, 18, nearA);
  p.ellipse(W * 0.4, floorY - 7, W * 0.2, 4, shade(nearA, 0.1));
  if (th.deco === "meadow" || th.deco === "sakura") {
    for (let i = 0; i < 26; i++) {
      const fx = x0 + 4 + hash2(i, 1, 341) * (x1 - x0 - 8);
      const fy = floorY - 3 + hash2(i, 2, 343) * 5;
      p.px(fx, fy, mod(["#FFFFFF", "#FFE066", "#FF8FB0", "#B7A0FF"][i % 4], 0.5));
    }
  }

  // ---- lapis B: pagar, lantai serbuk kayu, rak (di depan cuaca) ----
  p = B.p;
  // ===== serbuk kayu =====
  p.rect(x0, floorY, x1 - x0, y1 - floorY, th.bed);
  for (let i = 0; i < 12; i++) p.rect(x0, floorY + i, x1 - x0, 1, mix(th.bed3, th.bed, i / 12));
  for (let y = floorY + 1; y < y1; y++) {
    for (let x = x0; x < x1; x++) {
      const n = hash2(x, y, 17);
      const depth = (y - floorY) / Math.max(1, y1 - floorY);
      if (n > 0.955) p.px(x, y, th.bed2);
      else if (n < 0.03) p.px(x, y, mix(th.bed3, th.bed, 0.35));
      else if (n > 0.93 && depth > 0.3) p.px(x, y, shade(th.bed, 0.12));
    }
  }
  for (let i = 0; i < 52; i++) {
    const x = x0 + Math.round(hash2(i, 3, 31) * (x1 - x0));
    const y = floorY + 5 + Math.round(hash2(i, 7, 33) * (y1 - floorY - 8));
    const len = 2 + Math.round(hash2(i, 11, 35) * 4);
    const dir = hash2(i, 13, 37) > 0.5 ? 1 : -1;
    const c = hash2(i, 17, 39) > 0.5 ? shade(th.bed2, 0.08) : shade(th.bed3, 0.18);
    p.line(x, y, x + len, y + dir, c);
    p.px(x + len, y + dir, shade(c, 0.15));
  }
  // pagar kayu pendek di tepi belakang
  p.rect(x0, floorY - 3, x1 - x0, 5, th.wood);
  p.rect(x0, floorY - 3, x1 - x0, 1, shade(th.wood, 0.3));
  p.rect(x0, floorY + 1, x1 - x0, 1, th.wood2);
  for (let x = x0 + 5; x < x1; x += 11) p.rect(x, floorY - 3, 1, 5, shade(th.wood, -0.2));
  p.rect(x0, floorY + 2, x1 - x0, 2, "rgba(60,30,20,0.28)");

  // hiasan lantai
  for (let i = 0; i < 18; i++) {
    const fx = x0 + 8 + hash2(i, 3, 111) * (x1 - x0 - 16);
    const fy = floorY + 7 + hash2(i, 4, 113) * 4;
    p.line(fx, fy, fx - 1, fy - 4, "#4FA855");
    p.line(fx, fy, fx + 1, fy - 5, "#7BC96F");
    p.line(fx + 1, fy, fx + 3, fy - 3, "#5FB45E");
  }
  for (let i = 0; i < 8; i++) {
    const fx = x0 + 14 + hash2(i, 5, 121) * (x1 - x0 - 28);
    const fy = floorY + 9 + hash2(i, 6, 123) * 8;
    p.rect(fx, fy - 4, 1, 4, "#4FA855");
    p.px(fx - 1, fy - 5, ["#FFFFFF", "#FFE066", th.accent][i % 3]);
    p.px(fx + 1, fy - 5, ["#FFFFFF", "#FFE066", th.accent][i % 3]);
    p.px(fx, fy - 6, ["#FFFFFF", "#FFE066", th.accent][i % 3]);
    p.px(fx, fy - 5, "#FFC93C");
  }
  for (let i = 0; i < 8; i++) {
    const fx = x0 + 10 + hash2(i, 7, 131) * (x1 - x0 - 20);
    const fy = floorY + 12 + hash2(i, 8, 133) * (y1 - floorY - 18);
    p.ellipse(fx, fy, 3, 1.8, "#9A9298");
    p.ellipse(fx - 0.5, fy - 0.5, 2.2, 1.2, "#BDB6BC");
    p.px(fx - 1, fy - 1, "#E8E3E8");
  }
  if (env.weather === "snow") {
    p.ellipseDither(x0 + 20, floorY + 3, 34, 6, "rgba(255,255,255,0.8)");
    p.ellipseDither(x1 - 20, floorY + 3, 34, 6, "rgba(255,255,255,0.8)");
    p.ellipse(x0 + 16, floorY - 1, 22, 4, "#F3F8FF");
    p.ellipse(x1 - 16, floorY - 1, 22, 4, "#F3F8FF");
    p.ellipse(W * 0.5, floorY - 3, 14, 2, "#FFFFFF");
  }
  if (L.tiers === 3) drawShelves(p, L, th, env);
  // vinyet halus di dasar
  for (let x = x0; x < x1; x += 2) p.px(x, y1 - 1, "rgba(60,30,20,0.18)");
  void H;
  return { a: A.cv, b: B.cv };
}

// =====================================================================
//  BINGKAI AQUARIUM + KILAU KACA
// =====================================================================
export function buildFrame(L: Layout, th: Theme): HTMLCanvasElement {
  const { cv, p } = newCanvas(L.W, L.H);
  const { W, H, x0, x1, y0, y1 } = L;
  const wood = th.wood;
  const wood2 = th.wood2;
  const board = (x: number, y: number, w: number, h: number, seed: number) => {
    p.rect(x, y, w, h, wood);
    for (let i = 0; i < (w * h) / 5; i++) {
      const gx = x + Math.floor(hash2(i, seed, 401) * w);
      const gy = y + Math.floor(hash2(i, seed, 403) * h);
      p.px(gx, gy, shade(wood, hash2(i, seed, 405) > 0.5 ? -0.14 : 0.1));
    }
  };
  board(0, 0, W, y0, 1);
  board(0, y1, W, H - y1, 2);
  board(0, 0, x0, H, 3);
  board(x1, 0, W - x1, H, 4);
  // bevel
  p.rect(0, 0, W, 1, shade(wood, 0.4));
  p.rect(0, 0, 1, H, shade(wood, 0.35));
  p.rect(0, y0 - 1, W, 1, wood2);
  p.rect(0, y1, W, 1, shade(wood, 0.3));
  p.rect(x0 - 1, 0, 1, H, wood2);
  p.rect(x1, 0, 1, H, shade(wood, 0.2));
  p.rect(0, H - 1, W, 1, wood2);
  p.rect(W - 1, 0, 1, H, wood2);
  // bayangan dalam
  const shd = ["rgba(30,16,40,0.34)", "rgba(30,16,40,0.2)", "rgba(30,16,40,0.1)"];
  for (let i = 0; i < 3; i++) {
    p.rect(x0, y0 + 1 + i, x1 - x0, 1, shd[i]);
    p.rect(x0 + i, y0, 1, y1 - y0, shd[i]);
    p.rect(x1 - 1 - i, y0, 1, y1 - y0, shd[i]);
  }
  // strip LED hangat di bawah rel atas
  p.rect(x0 + 1, y0, x1 - x0 - 2, 1, "rgba(255,246,206,0.9)");
  for (let i = 0; i < 4; i++) p.rect(x0 + 1, y0 + 1 + i, x1 - x0 - 2, 1, `rgba(255,236,170,${0.18 - i * 0.04})`);
  // siku logam
  const bracket = (bx: number, by: number) => {
    p.rect(bx, by, 9, 9, "#7C8794");
    p.rect(bx, by, 9, 1, "#D6DEE6");
    p.rect(bx, by, 1, 9, "#C3CCD6");
    p.rect(bx + 8, by, 1, 9, "#5A6470");
    p.rect(bx, by + 8, 9, 1, "#5A6470");
    p.px(bx + 2, by + 2, "#E8EEF4");
    p.px(bx + 6, by + 6, "#E8EEF4");
    p.px(bx + 2, by + 2, "#2A323C");
    p.px(bx + 6, by + 6, "#2A323C");
  };
  bracket(0, 0); bracket(W - 9, 0); bracket(0, H - 9); bracket(W - 9, H - 9);
  // pelat nama emas
  p.rect(Math.round(W / 2 - 18), y1 + 2, 36, 5, "#8A6A1C");
  p.rect(Math.round(W / 2 - 17), y1 + 2, 34, 4, "#E8C25A");
  p.rect(Math.round(W / 2 - 17), y1 + 2, 34, 1, "#FFF0A8");
  for (let i = 0; i < 6; i++) p.rect(Math.round(W / 2 - 12 + i * 4), y1 + 4, 2, 1, "#A97F18");

  // kilau kaca
  const strips = [
    { a: 0.2, w: 15, al: 0.05 },
    { a: 0.2 + 0.1, w: 4, al: 0.09 },
    { a: 0.64, w: 24, al: 0.04 },
    { a: 0.64 + 0.15, w: 3, al: 0.07 },
  ];
  for (const s of strips) {
    for (let y = y0 + 1; y < y1; y++) {
      const xs = Math.round(x0 + (x1 - x0) * s.a - (y - y0) * 0.55);
      const xa = Math.max(x0 + 1, xs);
      const xb = Math.min(x1 - 1, xs + s.w);
      if (xb > xa) p.rect(xa, y, xb - xa, 1, `rgba(255,255,255,${s.al})`);
    }
  }
  // kilau sudut
  const gx = x0 + 9;
  const gy = y0 + 12;
  const gc = "rgba(255,255,255,0.8)";
  p.rect(gx - 3, gy, 7, 1, gc);
  p.rect(gx, gy - 3, 1, 7, gc);
  p.px(gx, gy, "#FFFFFF");
  return cv;
}

// =====================================================================
//  RUANGAN: dinding, kaunter rak, dekor, jendela cuaca
// =====================================================================
export function buildRoom(n: number, TW: number, TH: number, GAP: number, VM: number, env: Env): HTMLCanvasElement {
  const RW = n * TW + (n + 1) * GAP;
  const RH = TH + VM * 2;
  const { cv, p, ctx } = newCanvas(RW, RH);
  const night = env.night;
  const wallA = night ? "#3B3054" : "#F1D2AA";
  const wallB = night ? "#34294C" : "#EAC89D";
  const yc = VM + TH;

  p.rect(0, 0, RW, RH, wallA);
  for (let x = 0; x < RW; x += 18) p.rect(x, 0, 9, yc, wallB);
  const heart = [".a.a.", "aaaaa", ".aaa.", "..a.."];
  for (let y = 22; y < yc - 10; y += 34) {
    for (let x = 12 + ((y / 34) % 2) * 18; x < RW; x += 36) {
      p.sprite(x, y, heart, { a: night ? "#4A3C66" : "#F6BFA0" });
    }
  }
  // balok langit-langit
  p.rect(0, 0, RW, 13, night ? "#2A2038" : "#7A4B2A");
  p.rect(0, 0, RW, 1, night ? "#5A4A70" : "#B07A4A");
  p.rect(0, 11, RW, 2, night ? "#1E1628" : "#5A3418");
  for (let x = 40; x < RW; x += 80) p.rect(x, 1, 1, 10, night ? "#241A30" : "#6A3E20");

  // lampu hias
  for (let x = 0; x < RW; x++) {
    const yy = 15 + Math.round(Math.sin((x / 90) * Math.PI) * 5);
    p.px(x, yy, night ? "#120D1C" : "#5A3A1E");
  }
  for (let x = 10; x < RW; x += 22) {
    const yy = 15 + Math.round(Math.sin((x / 90) * Math.PI) * 5) + 3;
    const c = ["#FF8FB0", "#FFD84D", "#8FD8FF", "#9BF0C0"][Math.floor(x / 22) % 4];
    p.ellipseDither(x, yy + 1, 5, 5, night ? "rgba(255,230,160,0.45)" : "rgba(255,240,190,0.28)");
    p.ellipse(x, yy + 1, 2, 2.6, c);
    p.px(x - 1, yy, "#FFFFFF");
  }

  // kaunter
  p.rect(0, yc, RW, 6, "#D39A5E");
  p.rect(0, yc, RW, 1, "#F0C48A");
  p.rect(0, yc + 5, RW, 1, "#8A5428");
  p.rect(0, yc + 6, RW, 30, "#A8703E");
  for (let x = 0; x < RW; x += 70) {
    p.rect(x, yc + 6, 1, 30, "#7C4C26");
    p.rect(x + 8, yc + 11, 54, 20, "#9A6034");
    p.rect(x + 8, yc + 11, 54, 1, "#C08850");
    p.rect(x + 8, yc + 30, 54, 1, "#7C4C26");
    p.ellipse(x + 35, yc + 21, 2.5, 2.5, "#E8C25A");
    p.px(x + 34, yc + 20, "#FFF0A8");
  }
  p.rect(0, yc + 36, RW, 3, "#6B4020");
  for (let y = yc + 39; y < RH; y += 7) {
    p.rect(0, y, RW, 7, ((y - yc) / 7) % 2 | 0 ? "#6E4527" : "#74492A");
    p.rect(0, y, RW, 1, "#563418");
  }
  p.rect(0, yc + 39, RW, 6, "rgba(0,0,0,0.25)");

  // bayangan akuarium di kaunter
  for (let i = 0; i < n; i++) {
    const tx = GAP + i * (TW + GAP);
    p.rect(tx - 3, yc, TW + 6, 3, "rgba(40,20,10,0.35)");
  }

  const pot = (x: number, y: number, s: number, c: string) => {
    p.rect(x - 7 * s, y - 9 * s, 14 * s, 3 * s, shade(c, -0.15));
    for (let r = 0; r < 8 * s; r++) {
      const hw = 6 * s - (r / (8 * s)) * 2 * s;
      p.rect(x - hw, y - 6 * s + r, hw * 2, 1, r % 5 === 0 ? shade(c, 0.12) : c);
    }
  };
  const leaf = (x: number, y: number, rx: number, ry: number) => {
    p.ellipse(x, y, rx + 1, ry + 1, "#2E7040");
    p.ellipse(x, y, rx, ry, "#4FB05C");
    p.px(x - rx * 0.4, y - ry * 0.4, "#8EDB7C");
  };
  const winSky = skyColors(null, env);

  for (let g = 0; g <= n; g++) {
    const cx = g * (TW + GAP) + GAP / 2;
    const type = g % 3;
    if (type === 0) {
      const wx = Math.round(cx - 26);
      const wy = VM + 4;
      const ww = 52;
      const wh = 78;
      p.rect(wx - 4, wy - 4, ww + 8, wh + 8, "#7A4B2A");
      p.rect(wx - 3, wy - 3, ww + 6, wh + 6, "#B87843");
      for (let i = 0; i < wh; i++) p.rect(wx, wy + i, ww, 1, mix(winSky[0], winSky[1], i / wh));
      if (!night && env.weather === "clear") {
        p.ellipse(wx + 38, wy + 14, 8, 8, "#FFE873");
        p.ellipse(wx + 18, wy + 22, 9, 4, "#FFFFFF");
        p.ellipse(wx + 24, wy + 20, 6, 3.4, "#FFFFFF");
      } else if (night && env.weather !== "storm") {
        for (let i = 0; i < 14; i++) p.px(wx + hash2(i, g, 501) * ww, wy + hash2(i, g, 503) * (wh - 20), "#FFFFFF");
        p.ellipse(wx + 38, wy + 14, 6, 6, "#FFF3C4");
      }
      p.ellipse(wx + 12, wy + wh - 4, 24, 10, "#6EC37C");
      p.ellipse(wx + 40, wy + wh - 2, 24, 10, "#58AE6A");
      if (env.weather === "rain" || env.weather === "storm") {
        for (let i = 0; i < 26; i++) {
          const rx = wx + hash2(i, g, 505) * ww;
          const ry = wy + hash2(i, g, 507) * (wh - 6);
          p.line(rx, ry, rx - 2, ry + 5, "rgba(225,240,255,0.75)");
        }
        p.rect(wx, wy, ww, wh, "rgba(40,50,90,0.2)");
      } else if (env.weather === "snow") {
        for (let i = 0; i < 24; i++) p.px(wx + hash2(i, g, 509) * ww, wy + hash2(i, g, 511) * (wh - 4), "#FFFFFF");
        p.ellipse(wx + 12, wy + wh - 4, 24, 6, "#F3F8FF");
      }
      p.rect(wx + ww / 2 - 1, wy, 2, wh, "#B87843");
      p.rect(wx, wy + wh / 2 - 1, ww, 2, "#B87843");
      // tirai
      for (let i = 0; i < 12; i++) {
        p.rect(wx - 3 + i, wy - 3, 1, wh * 0.74 + (i % 3), i % 3 ? "#FF9EBB" : "#E57A9E");
        p.rect(wx + ww + 2 - i, wy - 3, 1, wh * 0.74 + (i % 3), i % 3 ? "#FF9EBB" : "#E57A9E");
      }
      p.rect(wx - 6, wy - 6, ww + 12, 3, "#8C5530");
      p.rect(wx - 6, wy + wh + 3, ww + 12, 3, "#D39A5E");
      pot(cx, yc, 1, "#D8783A");
      leaf(cx - 4, yc - 16, 4, 6);
      leaf(cx + 4, yc - 18, 4, 7);
      leaf(cx, yc - 22, 3, 6);
    } else if (type === 1) {
      const sy = VM + 40;
      p.rect(cx - 30, sy, 60, 4, "#B87843");
      p.rect(cx - 30, sy, 60, 1, "#E8B070");
      p.rect(cx - 26, sy + 4, 3, 5, "#7A4B2A");
      p.rect(cx + 23, sy + 4, 3, 5, "#7A4B2A");
      const bk = ["#FF6B8A", "#4FB8FF", "#FFD84D", "#8FD98A", "#B38BFF"];
      for (let i = 0; i < 5; i++) {
        p.rect(cx - 28 + i * 5, sy - 14 + (i % 2) * 3, 4, 14 - (i % 2) * 3, bk[i]);
        p.rect(cx - 28 + i * 5, sy - 14 + (i % 2) * 3, 1, 14 - (i % 2) * 3, shade(bk[i], 0.3));
      }
      pot(cx + 16, sy, 0.7, "#F2B8C8");
      leaf(cx + 14, sy - 11, 3, 4);
      leaf(cx + 18, sy - 12, 3, 4);
      // bingkai foto
      const fx = Math.round(cx - 14);
      const fy = VM + 6;
      p.rect(fx - 2, fy - 2, 32, 28, "#7A4B2A");
      p.rect(fx, fy, 28, 24, "#FFF6E4");
      p.sprite(fx + 10, fy + 8, [".aa.aa.", "aaaaaaa", "aaaaaaa", ".aaaaa.", "..aaa..", "...a..."], { a: "#FF5D8F" });
      // lampu meja
      p.rect(cx - 5, yc - 4, 10, 4, "#8C5530");
      p.rect(cx - 1, yc - 20, 2, 17, "#8C5530");
      for (let r = 0; r < 10; r++) p.rect(cx - 4 - r * 0.5, yc - 30 + r, 8 + r, 1, night ? "#FFE9A0" : "#FFF0C4");
      if (night) p.ellipseDither(cx, yc - 22, 18, 14, "rgba(255,226,150,0.35)");
    } else {
      pot(cx, yc, 1.3, "#C9703A");
      leaf(cx - 9, yc - 22, 5, 9);
      leaf(cx + 9, yc - 24, 5, 10);
      leaf(cx, yc - 30, 5, 10);
      leaf(cx - 14, yc - 14, 4, 6);
      leaf(cx + 14, yc - 14, 4, 6);
      const ky = VM + 26;
      p.ellipse(cx, ky, 15, 15, "#7A4B2A");
      p.ellipse(cx, ky, 13, 13, "#FFF6E4");
      for (let i = 0; i < 12; i++) {
        const a = (i / 12) * Math.PI * 2;
        p.px(cx + Math.cos(a) * 11, ky + Math.sin(a) * 11, "#7A4B2A");
      }
      p.line(cx, ky, cx, ky - 8, "#5A3418");
      p.line(cx, ky, cx + 6, ky + 2, "#5A3418");
      p.px(cx, ky, "#FF5D8F");
    }
  }
  if (night) {
    ctx.fillStyle = "rgba(20,14,56,0.32)";
    ctx.fillRect(0, 0, RW, RH);
  }
  return cv;
}

// =====================================================================
//  PROPERTI
// =====================================================================
export function drawHutBack(p: Px, x: number, y: number, th: Theme, t: number) {
  p.push();
  p.origin(x, y);
  const wood = th.wood;
  const wood2 = th.wood2;
  p.ellipseDither(0, 1, 33, 5, "rgba(60,34,20,0.28)");
  p.ellipse(0, 0, 30, 4, "rgba(60,34,20,0.2)");
  p.rect(-27, -25, 54, 25, wood2);
  p.rect(-26, -24, 52, 24, wood);
  for (let i = -26; i < 26; i += 7) {
    p.rect(i, -24, 1, 24, shade(wood, -0.2));
    p.rect(i + 1, -24, 1, 24, shade(wood, 0.12));
  }
  for (let i = 0; i < 28; i++) {
    p.px(-25 + Math.floor(hash2(i, 1, 201) * 50), -23 + Math.floor(hash2(i, 2, 203) * 22), shade(wood, -0.14));
  }
  p.rect(-27, -4, 54, 4, "#9A9298");
  for (let i = -26; i < 26; i += 6) p.rect(i, -4, 1, 4, "#7C757C");
  p.rect(-27, -4, 54, 1, "#BDB6BC");
  // atap jerami
  const r1 = mix("#D9A85E", th.accent, 0.15);
  const r2 = mix("#B98338", th.accent, 0.15);
  for (let i = 0; i < 24; i++) {
    const hw = 34 - i * 1.4;
    const yy = -25 - i;
    p.rect(-hw, yy, hw * 2, 1, Math.floor(i / 3) % 2 ? r1 : r2);
    p.px(-hw, yy, shade(r2, -0.35));
    p.px(hw - 1, yy, shade(r2, -0.35));
  }
  for (let i = 0; i < 24; i += 3) {
    const hw = 34 - i * 1.4;
    p.rect(-hw, -25 - i, hw * 2, 1, shade(r2, -0.2));
    for (let k = -hw + 2; k < hw - 2; k += 5) p.px(k + (i % 2) * 2, -26 - i, shade(r1, 0.22));
  }
  for (let i = 0; i < 18; i++) p.px(-30 + i * 1.4 + hash2(i, 5, 207) * 2, -27 - i, shade(r1, 0.28));
  p.rect(-3, -50, 6, 3, shade(r2, -0.3));
  p.rect(0, -60, 1, 11, "#7A5530");
  for (let i = 0; i < 8; i++) p.rect(1 + i, -60 + Math.round(Math.sin(t * 5 + i * 0.8) * 1), 1, i > 5 ? 3 : 5, th.accent);
  // jendela hati
  p.rect(13, -21, 12, 10, wood2);
  p.rect(14, -20, 10, 8, "#FFE9A8");
  p.sprite(16, -19, [".aa.aa.", "aaaaaaa", ".aaaaa.", "..aaa..", "...a..."], { a: "#FF8F5A" });
  // pintu gelap
  for (let yy = -24; yy < 0; yy++) {
    const hw = yy < -13 ? Math.round(HUT_HALF_DOOR * Math.sqrt(Math.max(0, 1 - Math.pow((yy + 13.5) / 11, 2)))) : HUT_HALF_DOOR;
    p.rect(-hw, yy, hw * 2, 1, "#2A1824");
  }
  p.rect(-10, -4, 20, 4, "#4A3040");
  p.ellipseDither(0, -5, 9, 6, "rgba(255,190,120,0.22)");
  p.pop();
}

export function drawHutFront(p: Px, x: number, y: number, th: Theme, stash: number) {
  p.push();
  p.origin(x, y);
  const wood = th.wood;
  const wood2 = th.wood2;
  // topeng sudut persegi di atas lengkungan pintu
  for (let yy = -24; yy < -13; yy++) {
    for (let xx = -HUT_HALF_DOOR; xx < HUT_HALF_DOOR; xx++) {
      const dx = (xx + 0.5) / 11;
      const dy = (yy + 13.5) / 11;
      if (dx * dx + dy * dy > 1) p.px(xx, yy, (xx + 26) % 7 === 0 ? shade(wood, -0.2) : (xx + 26) % 7 === 1 ? shade(wood, 0.12) : wood);
    }
  }
  // bingkai lengkung
  for (let yy = -25; yy < 0; yy++) {
    for (let xx = -13; xx < 13; xx++) {
      let inRing = false;
      if (yy < -13) {
        const d = Math.hypot((xx + 0.5) / 1, yy + 13.5);
        inRing = d >= 9.3 && d <= 11.8;
      } else {
        const ax = Math.abs(xx + 0.5);
        inRing = ax >= 9.3 && ax <= 11.8;
      }
      if (inRing) p.px(xx, yy, xx < -4 && yy < -8 ? shade(wood2, 0.3) : wood2);
    }
  }
  // undakan batu & keset
  p.rect(-14, -2, 28, 3, "#C9C2C8");
  p.rect(-14, -2, 28, 1, "#E8E3E8");
  p.rect(-14, 0, 28, 1, "#9A939A");
  p.ellipse(0, 4, 10, 2.2, th.accent);
  p.ellipse(0, 4, 7, 1.2, shade(th.accent, 0.3));
  // kotak bunga
  p.rect(-26, -10, 13, 7, wood2);
  p.rect(-25, -9, 11, 5, wood);
  p.rect(-25, -9, 11, 1, shade(wood, 0.25));
  for (let i = 0; i < 5; i++) {
    const fx = -24 + i * 2.4;
    p.px(fx, -11, "#4FA855");
    p.px(fx, -12, "#4FA855");
    p.px(fx, -13, [th.accent, "#FFE066", "#FFFFFF", "#FF8FB0", "#B7A0FF"][i]);
    p.px(fx - 1, -12, [th.accent, "#FFE066", "#FFFFFF", "#FF8FB0", "#B7A0FF"][i]);
  }
  for (let i = 0; i < Math.min(9, stash); i++) {
    const sx = 13 + (i % 5) * 2;
    const sy = 3 + Math.floor(i / 5) * 2;
    p.px(sx, sy, "#4A3324");
    p.px(sx + 1, sy, "#E8DCC0");
  }
  p.pop();
}

export function drawMound(p: Px, x: number, y: number, th: Theme, wob: number, t: number) {
  p.push();
  p.origin(x, y);
  const dark = shade(th.bed3, -0.18);
  p.ellipseDither(0, 6, 36, 6, "rgba(60,34,20,0.25)");
  p.ellipse(0, 4, 31, 14, dark);
  p.ellipse(0, 4, 30, 13, th.bed2);
  p.ellipse(-2, 2, 26, 10, th.bed);
  p.ellipse(-9, -2, 12, 4, shade(th.bed, 0.25));
  for (let i = 0; i < 90; i++) {
    const a = hash2(i, 1, 601) * Math.PI * 2;
    const rr = Math.sqrt(hash2(i, 2, 603));
    const px0 = Math.cos(a) * 28 * rr;
    const py0 = 4 + Math.sin(a) * 11.5 * rr;
    p.px(px0, py0, hash2(i, 3, 605) > 0.5 ? shade(th.bed, 0.16) : shade(th.bed3, 0.08));
  }
  for (let i = 0; i < 26; i++) {
    const a = Math.PI * (1.06 + hash2(i, 4, 607) * 0.88);
    const sx = Math.cos(a) * 26;
    const sy = 4 + Math.sin(a) * 10.5;
    const len = 3 + hash2(i, 5, 609) * 4;
    const sw = Math.sin(t * 2 + i) * wob * 2;
    p.line(sx, sy, sx + Math.cos(a) * 2 + sw + (hash2(i, 6, 611) - 0.5) * 3, sy - len, i % 2 ? "#E8C77A" : "#CFA85A");
  }
  p.pop();
}

export function drawBowl(p: Px, x: number, y: number, th: Theme, fill: number) {
  p.push();
  p.origin(x, y);
  const c = th.accent;
  p.ellipseDither(0, 1, 17, 4, "rgba(60,34,20,0.24)");
  p.ellipse(0, -3, 15, 8, shade(c, -0.45));
  p.ellipse(0, -4, 14, 7, shade(c, -0.1));
  p.ellipse(0, -3, 12, 5, c);
  p.ellipse(0, -7, 12, 4.6, shade(c, 0.3));
  p.ellipse(0, -7, 10.5, 3.8, "#4A3326");
  p.sprite(-3, -4, [".a.a.", "aaaaa", ".aaa.", "..a.."], { a: "#FFF1F6" });
  p.px(-12, -8, "#FFFFFF");
  p.px(-11, -9, "rgba(255,255,255,0.7)");
  const f = clamp(fill, 0, 1);
  const n = Math.round(f * 24);
  for (let i = 0; i < n; i++) {
    const a = hash2(i, 5, 61) * Math.PI * 2;
    const r = Math.sqrt(hash2(i, 6, 63)) * 8.5;
    const heap = (1 - r / 9) * 3.2 * f;
    const sx = Math.cos(a) * r;
    const sy = -7 + Math.sin(a) * r * 0.36 - heap;
    p.px(sx, sy, "#3A2A1C");
    p.px(sx + 1, sy, "#F1E6C8");
    if (i % 3 === 0) p.px(sx, sy - 1, "#6B5442");
  }
  p.pop();
}

export function drawBottle(p: Px, x: number, y: number, th: Theme, level: number, t: number, hgt: number) {
  p.push();
  p.origin(x, y);
  const w = 12;
  // klip dinding
  p.rect(-w - 3, -hgt + 9, 2 * w + 6, 4, "#7C8794");
  p.rect(-w - 3, -hgt + 9, 2 * w + 6, 1, "#D6DEE6");
  p.rect(-w - 3, -Math.round(hgt * 0.35), 2 * w + 6, 4, "#7C8794");
  p.rect(-w - 3, -Math.round(hgt * 0.35), 2 * w + 6, 1, "#D6DEE6");
  // badan botol dengan sudut membulat
  for (let i = 0; i < hgt; i++) {
    const inset = i < 3 ? 3 - i : 0;
    p.rect(-w + inset, -hgt + i, 2 * w - inset * 2, 1, "#4F86A8");
    p.rect(-w + 1 + inset, -hgt + i, 2 * w - 2 - inset * 2, 1, "#E3F5FD");
  }
  // corong leher
  for (let i = 0; i < 6; i++) {
    const hw = w - 1 - i * 1.6;
    p.rect(-hw - 1, i, hw * 2 + 2, 1, "#4F86A8");
    p.rect(-hw, i, hw * 2, 1, "#CFEAF7");
  }
  // air
  const fillH = Math.round(clamp(level, 0, 1) * (hgt - 6));
  if (fillH > 0) {
    p.rect(-w + 1, -fillH, 2 * w - 2, fillH, "#5CC8F2");
    p.rect(-w + 1, -fillH, 2 * w - 2, 1, "#B5EBFF");
    p.rect(-w + 1, -fillH + 1, 2 * w - 2, 1, "#8EDCFA");
    for (let i = 0; i < fillH; i += 2) p.px(-w + 2 + ((i * 7) % (2 * w - 4)), -i, "#4AB4DE");
    p.rect(-w + 1, -2, 2 * w - 2, 2, "#3FA6D2");
    for (let i = 0; i < 4; i++) {
      const by = -((t * 9 + i * 13) % Math.max(4, fillH - 3)) - 2;
      p.px(-w + 4 + i * 5, by, "rgba(255,255,255,0.85)");
    }
  }
  // skala ukur
  for (let i = 1; i < 6; i++) p.rect(w - 6, -Math.round((i * (hgt - 8)) / 6) - 2, 4, 1, i % 2 ? "#8AB0C6" : "#6A96B0");
  // kilau
  p.rect(-w + 3, -hgt + 5, 2, Math.round(hgt * 0.5), "rgba(255,255,255,0.85)");
  p.rect(-w + 6, -hgt + 8, 1, Math.round(hgt * 0.22), "rgba(255,255,255,0.6)");
  // stiker tetes air
  p.sprite(-2, -Math.round(hgt * 0.62), ["..a..", ".aaa.", "aaaaa", "aaaaa", ".aaa."], { a: "#7CCBF0" });
  p.px(-1, -Math.round(hgt * 0.62) + 3, "#FFFFFF");
  // tutup
  p.rect(-w + 1, -hgt - 5, 2 * w - 2, 5, th.accent);
  p.rect(-w + 1, -hgt - 5, 2 * w - 2, 1, shade(th.accent, 0.4));
  p.rect(-w + 1, -hgt - 1, 2 * w - 2, 1, shade(th.accent, -0.3));
  for (let i = -w + 3; i < w - 2; i += 3) p.rect(i, -hgt - 4, 1, 3, shade(th.accent, -0.15));
  p.rect(-3, -hgt - 8, 6, 3, shade(th.accent, -0.2));
  p.rect(-2, -hgt - 7, 4, 1, "#150C1C");
  // pipa penyedot
  p.rect(-1, 6, 3, 8, "#B9C7D2");
  p.rect(-1, 12, 14, 3, "#B9C7D2");
  p.rect(-1, 6, 1, 8, "#EEF3F7");
  p.rect(-1, 12, 14, 1, "#EEF3F7");
  p.rect(-1, 14, 14, 1, "#8A9BA8");
  p.ellipse(13.5, 13.5, 2.7, 2.7, "#8A9BA8");
  p.ellipse(13.5, 13.5, 2.2, 2.2, "#E2EAF0");
  p.px(12, 12, "#FFFFFF");
  // tetesan
  const ph = (t % 2.4) / 2.4;
  if (ph < 0.55) {
    const s = ph / 0.55;
    p.px(13, 16, "#7CCBF0");
    if (s > 0.5) p.px(13, 17, "#5CC8F2");
  } else {
    const fy = 17 + (ph - 0.55) * 60;
    p.px(13, fy, "#7CCBF0");
    p.px(13, fy - 1, "rgba(124,203,240,0.6)");
  }
  p.pop();
}

export function drawBath(p: Px, x: number, y: number, th: Theme) {
  p.push();
  p.origin(x, y);
  p.ellipseDither(0, 2, 22, 5, "rgba(60,34,20,0.2)");
  p.ellipse(0, 0, 20, 8, shade(th.wood2, 0.05));
  p.ellipse(0, -1, 19, 7, "#F4E6C6");
  p.ellipse(0, -1, 16, 5.4, "#EBD7A6");
  for (let i = 0; i < 30; i++) {
    const a = hash2(i, 9, 71) * Math.PI * 2;
    const r = Math.sqrt(hash2(i, 10, 73)) * 14.5;
    p.px(Math.cos(a) * r, -1 + Math.sin(a) * r * 0.33, i % 3 ? "#FFF6DC" : "#D7BC86");
  }
  p.sprite(-9, -5, [".aa.", "abba", "aaaa"], { a: "#FFC2D6", b: "#FF8FB0" });
  p.sprite(7, -4, ["..a.", ".aaa", "aaaa"], { a: "#B8E4F0" });
  p.px(-14, -6, "#FFFFFF");
  p.pop();
}

export function drawWheelBack(p: Px, x: number, y: number, r: number, ang: number, th: Theme) {
  p.push();
  p.origin(x, y);
  const cy = -r - 4;
  p.ellipseDither(0, 2, r * 0.95, 4, "rgba(60,34,20,0.26)");
  // dudukan
  p.rect(-16, -3, 32, 4, th.wood2);
  p.rect(-16, -3, 32, 1, shade(th.wood2, 0.35));
  p.rect(-13, -4, 26, 1, shade(th.wood2, 0.15));
  p.rect(-3, cy, 6, -cy - 3, th.wood2);
  p.rect(-2, cy, 2, -cy - 3, th.wood);
  // pelat belakang pastel
  const pastel = mix(th.accent, "#FFFFFF", 0.7);
  p.ellipse(0, cy, r, r, mix(th.accent, "#2A1830", 0.45));
  p.ellipse(0, cy, r - 1, r - 1, pastel);
  ring(p, 0, cy, r - 2, 6, mix(th.accent, "#FFFFFF", 0.38));
  // anak tangga berputar
  const N = 26;
  for (let i = 0; i < N; i++) {
    const a = ang + (i / N) * Math.PI * 2;
    const c = Math.cos(a);
    const s = Math.sin(a);
    p.line(c * (r - 3), cy + s * (r - 3), c * (r - 7), cy + s * (r - 7), i % 2 ? shade(th.accent, -0.22) : shade(th.accent, 0.12));
  }
  for (let i = 0; i < 8; i++) {
    const a = ang + (i / 8) * Math.PI * 2;
    p.line(0, cy, Math.cos(a) * (r - 8), cy + Math.sin(a) * (r - 8), mix(th.accent, "#FFFFFF", 0.5));
  }
  p.ellipse(0, cy, 6.5, 6.5, shade(th.wood2, -0.25));
  p.ellipse(0, cy, 5.5, 5.5, th.wood);
  p.ellipse(0, cy, 3.6, 3.6, th.accent);
  for (let i = 0; i < 4; i++) {
    const a = ang + (i * Math.PI) / 2;
    p.px(Math.cos(a) * 2.4, cy + Math.sin(a) * 2.4, i === 0 ? "#FFFFFF" : shade(th.accent, 0.45));
  }
  p.pop();
}

export function drawWheelFront(p: Px, x: number, y: number, r: number, ang: number, th: Theme) {
  p.push();
  p.origin(x, y);
  const cy = -r - 4;
  // lapisan kaca bening
  for (let i = -(r - 3); i < r - 3; i++) {
    const half = Math.round(Math.sqrt(Math.max(0, (r - 3) * (r - 3) - (i + 0.5) * (i + 0.5))));
    p.rect(-half, cy + i, half * 2, 1, "rgba(255,255,255,0.08)");
  }
  ring(p, 0, cy, r + 1, 1, shade(th.accent, -0.55));
  ring(p, 0, cy, r, 3, th.accent);
  const N = 38;
  for (let i = 0; i < N; i++) {
    const a = ang + (i / N) * Math.PI * 2;
    const rx = Math.cos(a) * (r - 1.5);
    const ry = cy + Math.sin(a) * (r - 1.5);
    if (i % 2 === 0) p.rect(rx - 0.5, ry - 0.5, 2, 2, "rgba(255,255,255,0.9)");
    else p.px(rx, ry, shade(th.accent, -0.3));
  }
  for (let a = Math.PI * 1.05; a < Math.PI * 1.55; a += 0.05) {
    p.px(Math.cos(a) * (r - 4.5), cy + Math.sin(a) * (r - 4.5), "rgba(255,255,255,0.7)");
    p.px(Math.cos(a) * (r - 5.5), cy + Math.sin(a) * (r - 5.5), "rgba(255,255,255,0.35)");
  }
  p.line(-r * 0.6, cy - r * 0.22, -r * 0.3, cy - r * 0.58, "rgba(255,255,255,0.4)");
  p.line(-r * 0.52, cy - r * 0.12, -r * 0.2, cy - r * 0.5, "rgba(255,255,255,0.22)");
  p.pop();
}

export function drawBall(p: Px, x: number, y: number, r: number, t: number) {
  p.push();
  p.origin(x, y);
  p.ellipseDither(0, 1, r, 2.6, "rgba(60,34,20,0.22)");
  p.ellipse(0, -r, r + 1, r + 1, "#9E2A57");
  p.ellipse(0, -r, r, r, "#FF6F9C");
  p.ellipse(0, -r, r, r * 0.42, "#FFD84D");
  p.ellipse(0, -r, r * 0.5, r * 0.2, "#FFF1A8");
  p.ellipse(-r * 0.35, -r * 1.4, r * 0.28, r * 0.22, "#FFFFFF");
  p.px(r * 0.4, -r * 1.3, Math.sin(t * 3) > 0 ? "#FFF6C0" : "#FFE066");
  p.pop();
}

export function drawPoop(p: Px, x: number, y: number) {
  p.push();
  p.origin(x, y);
  p.ellipseDither(0, 0, 3.4, 1.6, "rgba(60,34,20,0.2)");
  p.ellipse(0, -2, 2.8, 2.4, "#3A281C");
  p.ellipse(0, -2, 2.2, 1.9, "#4A3324");
  p.ellipse(0, -2.4, 1.6, 1.3, "#6B4A32");
  p.px(-1, -3, "#8A6444");
  p.pop();
}

// =====================================================================
//  SPRITE MAKANAN (buatan tangan, dapat digigit)
// =====================================================================
type Spr = { rows: string[]; map: Record<string, string> };

const FOOD_SPR: Record<string, Spr> = {
  kuaci: {
    map: { o: "#3A2A22", w: "#F6EEDC", s: "#5E4A3E", c: "#D6C6A2" },
    rows: [
      "..oooo..",
      ".owswwo.",
      "owwswwso",
      "owwswcso",
      "owwswcso",
      "owwswcso",
      "owwswcso",
      ".owswcso",
      ".owswco.",
      "..owsco.",
      "...ooo..",
    ],
  },
  wortel: {
    map: { g: "#3F9B3A", G: "#6FCB52", d: "#B8561E", O: "#FF9442", h: "#FFC58A", r: "#E27526" },
    rows: [
      "..g.g.g..",
      ".gGgGgGg.",
      "..gGgGg..",
      "...gGg...",
      "..ddddd..",
      ".dOOOhOd.",
      ".dOhOOOd.",
      ".dOOOrOd.",
      "..dOOOd..",
      "..drOOd..",
      "..dOOOd..",
      "...dOrd..",
      "...dOOd..",
      "....dOd..",
      "....ddd..",
      ".....d...",
    ],
  },
  brokoli: {
    map: { g: "#2F7D32", G: "#4CAF50", h: "#8BDB7B", s: "#A5CF7E", S: "#C8E6A0", t: "#7FAF5A" },
    rows: [
      "...gggg....",
      ".gggGGGgg..",
      "ggGGhGGGGg.",
      "gGGhhGGGGgg",
      "gGGGGGGGGGg",
      "gGGGGgGGGgg",
      ".ggGGGGGgg.",
      "..gggGGgg..",
      ".....sS....",
      "....tsSs...",
      "....tsSS...",
      "...tssSSs..",
    ],
  },
  jagung: {
    map: { y: "#FFD84D", Y: "#F2B92E", l: "#6CBF4F", L: "#4B9A3A" },
    rows: [
      "..yyyy..",
      ".yYyyYy.",
      "yyYyyYyy",
      "yYyyYyyY",
      "yyYyyYyy",
      "yYyyYyyY",
      "yyYyyYyy",
      "lyYyyYyl",
      "llyYyyll",
      "lLllyllL",
      ".lLllllL",
      "..LllLL.",
      "...LlL..",
      "....L...",
    ],
  },
  stroberi: {
    map: { r: "#B3213B", R: "#F2465F", h: "#FF9DAE", y: "#FFE08A", g: "#3F8F32", G: "#69C04E" },
    rows: [
      "...gg.gg...",
      "..gGgGgGg..",
      "...gGGGg...",
      ".rrrrrrrrr.",
      "rRRRRRRRRRr",
      "rRhRyRRyRRr",
      "rRRRRyRRRRr",
      "rRyRRRRRyRr",
      ".rRRyRRRRr.",
      "..rRRRyRr..",
      "...rRRRr...",
      "....rRr....",
    ],
  },
  keju: {
    map: { o: "#B07A12", Y: "#FFD34D", h: "#FFF0A0", D: "#E8AE22", H: "#D99A1A" },
    rows: [
      "............o",
      "........oooYo",
      "....oooYYYhYo",
      "..oYYYhYYYYYo",
      ".oYYYYYYYHYYo",
      "oYYHYYYYYYYYo",
      "oYYYYYYHYYYYo",
      "oYYYYYYYYYYYo",
      "oDDDDDDDDDDDo",
      "ooooooooooooo",
    ],
  },
};

export function foodSize(id: string) {
  const s = FOOD_SPR[id] ?? FOOD_SPR.kuaci;
  return { w: s.rows[0].length, h: s.rows.length };
}

/** Gambar makanan; titik jangkar = tengah-bawah. bite 0..1 = bagian yang sudah digigit dari atas. */
export function drawFood(p: Px, id: string, x: number, y: number, bite = 0, relative = false) {
  const s = FOOD_SPR[id] ?? FOOD_SPR.kuaci;
  const W = s.rows[0].length;
  const H = s.rows.length;
  p.push();
  if (relative) p.local(x, y);
  else p.origin(x, y);
  const cut = bite * (H + 1.5);
  for (let r = 0; r < H; r++) {
    const row = s.rows[r];
    for (let c = 0; c < W; c++) {
      const ch = row[c];
      if (ch === ".") continue;
      if (bite > 0.001) {
        const notch = Math.sin(c * 1.9 + id.length) * 0.9 + (hash2(c, r, 5) - 0.5) * 0.7;
        if (r < cut + notch) continue;
      }
      const col = s.map[ch];
      if (col) p.px(c - Math.floor(W / 2), r - H, col);
    }
  }
  p.pop();
}

// =====================================================================
//  PARTIKEL, AWAN GULAT, MALAM
// =====================================================================
export type ParticleKind =
  | "heart" | "sparkle" | "crumb" | "dust" | "zzz" | "note" | "coin" | "star" | "bubble" | "sand"
  | "sweat" | "streak" | "puff" | "hay" | "print" | "fog";

export function drawParticle(p: Px, kind: ParticleKind, x: number, y: number, life: number, size: number, color: string) {
  p.push();
  p.origin(x, y);
  const a = clamp(life, 0, 1);
  if (kind === "heart") {
    const c = a > 0.35 ? color : mix(color, "#FFFFFF", 0.5);
    if (size < 1.3) p.sprite(-2, -2, ["a.a", "aaa", ".a."], { a: c });
    else {
      p.sprite(-3, -3, [".aa.aa.", "aaaaaaa", "aaaaaaa", ".aaaaa.", "..aaa..", "...a..."], { a: c });
      p.px(-2, -2, "#FFFFFF");
    }
  } else if (kind === "sparkle" || kind === "star") {
    const r = Math.max(1, Math.round(size * 2 * a));
    p.rect(-r, 0, r * 2 + 1, 1, color);
    p.rect(0, -r, 1, r * 2 + 1, color);
    p.px(0, 0, "#FFFFFF");
    if (r > 2) {
      p.px(-1, -1, "#FFFFFF");
      p.px(1, 1, "#FFFFFF");
    }
  } else if (kind === "crumb") {
    p.rect(0, 0, size > 1.2 ? 2 : 1, size > 1.2 ? 2 : 1, color);
  } else if (kind === "dust" || kind === "sand") {
    p.ellipse(0, 0, size * a + 0.6, size * a * 0.8 + 0.5, color);
  } else if (kind === "puff") {
    const r = 2 + size * 3 * (1.2 - a * 0.6);
    p.ellipseDither(0, 0, r + 1, r, "rgba(255,255,255,0.7)");
    p.ellipse(0, 0, r * 0.7, r * 0.6, `rgba(255,255,255,${(0.35 + a * 0.5).toFixed(2)})`);
  } else if (kind === "hay") {
    p.line(0, 0, 2, -3, color);
  } else if (kind === "print") {
    const c = `rgba(255,236,244,${(0.8 * Math.min(1, a * 1.6)).toFixed(2)})`;
    p.px(-2, -2, c); p.px(0, -3, c); p.px(2, -2, c);
    p.rect(-1, -1, 3, 2, c);
    p.px(0, 1, c);
  } else if (kind === "fog") {
    const r = 3 + (1 - a) * 6;
    p.ellipseDither(0, 0, r + 1, r * 0.8, `rgba(255,255,255,${(0.5 * a).toFixed(2)})`);
    p.ellipse(0, 0, r * 0.6, r * 0.45, `rgba(255,255,255,${(0.28 * a).toFixed(2)})`);
  } else if (kind === "zzz") {
    p.sprite(-1, -2, ["aaa", "..a", ".a.", "a..", "aaa"], { a: color });
    if (size > 1.2) p.sprite(1, -4, ["aaa", "..a", ".a.", "a..", "aaa"], { a: color });
  } else if (kind === "note") {
    p.sprite(-2, -4, ["..aa", "..a.", "..a.", "aaa.", "aa.."], { a: color });
  } else if (kind === "coin") {
    p.ellipse(0, 0, 3, 3.4, "#C98A16");
    p.ellipse(0, 0, 2.2, 2.8, "#FFD34D");
    p.px(-1, -1, "#FFF3B0");
  } else if (kind === "bubble") {
    ring(p, 0, 0, Math.max(1.5, size * 2), 1, color);
    p.px(-1, -1, "#FFFFFF");
  } else if (kind === "sweat") {
    p.sprite(-1, -3, [".a.", "aaa", "aaa", ".a."], { a: color });
    p.px(-1, -1, "#FFFFFF");
  } else if (kind === "streak") {
    const len = Math.round(3 + size * 3 * a);
    p.rect(-len, 0, len, 1, `rgba(255,255,255,${(0.75 * a).toFixed(2)})`);
  }
  p.pop();
}

/** Awan debu kartun saat gulat. front=false → bagian belakang (di balik hamster). */
export function drawFightCloud(p: Px, x: number, y: number, t: number, front: boolean) {
  p.push();
  p.origin(x, y);
  for (let i = 0; i < 9; i++) {
    const a = t * 5 + i * ((Math.PI * 2) / 9) + (i % 2) * 0.4;
    const rr = 15 + (i % 3) * 3 + Math.sin(t * 9 + i) * 2;
    const px0 = Math.cos(a) * rr;
    const py0 = Math.sin(a) * rr * 0.55 - 8;
    if (py0 + 8 > 0 !== front) continue;
    const r = 5 + (i % 3) * 1.6 + Math.sin(t * 7 + i * 2);
    p.ellipse(px0, py0, r + 1, r * 0.9 + 1, "#B9B1CC");
    p.ellipse(px0, py0, r, r * 0.9, i % 2 ? "#FFFFFF" : "#F1EEF8");
    p.px(px0 - r * 0.4, py0 - r * 0.4, "#FFFFFF");
  }
  if (front) {
    for (let i = 0; i < 3; i++) {
      const a = -t * 7 + i * 2.1;
      const sx = Math.cos(a) * 21;
      const sy = Math.sin(a) * 9 - 14;
      p.sprite(sx - 2, sy - 2, [".a.", "aaa", ".a."], { a: ["#FFD84D", "#FF8FB0", "#8FD8FF"][i] });
    }
  }
  p.pop();
}

export function drawNightOverlay(p: Px, L: Layout, t: number) {
  p.rect(L.x0, L.y0, L.x1 - L.x0, L.y1 - L.y0, "rgba(26,22,84,0.36)");
  const ctx = p.ctx;
  const g = ctx.createRadialGradient(L.hut.x, L.floorY - 6, 4, L.hut.x, L.floorY - 6, L.W * 0.55);
  g.addColorStop(0, "rgba(255,196,92,0.30)");
  g.addColorStop(1, "rgba(255,196,92,0)");
  ctx.fillStyle = g;
  ctx.fillRect(L.x0, L.y0, L.x1 - L.x0, L.y1 - L.y0);
  for (let i = 0; i < 8; i++) {
    const fx = L.x0 + (L.x1 - L.x0) * (0.08 + 0.84 * hash2(i, 1, 701)) + Math.sin(t * 0.6 + i) * 10;
    const fy = L.floorY + 8 + hash2(i, 2, 703) * (L.y1 - L.floorY - 24) + Math.sin(t * 0.9 + i * 2) * 5;
    if (Math.sin(t * 2.2 + i * 1.7) > -0.3) {
      p.ellipseDither(fx, fy, 3, 3, "rgba(255,244,150,0.5)");
      p.px(fx, fy, "#FFF5A0");
    }
  }
}

// =====================================================================
//  MENARA 3 TINGKAT: rak, tangga, perosotan
// =====================================================================
export function drawShelves(p: Px, L: Layout, th: Theme, env: Env) {
  const night = env.night;
  const D = SHELF_D;
  const T = SHELF_T;
  p.reset();
  for (const sh of L.shelves) {
    const { x0, x1, y } = sh;
    const pw = x1 - x0;
    const top = y - 90;
    const wallC = mix(th.wall, "#FFFFFF", night ? 0.05 : 0.32);
    const stripe = mix(wallC, th.wall2, 0.38);
    // panel wallpaper
    p.rect(x0, top, pw, y - top, wallC);
    for (let xx = x0 + 4; xx < x1; xx += 14) p.rect(xx, top, 7, y - top, stripe);
    const heart = [".a.a.", "aaaaa", ".aaa.", "..a.."];
    for (let yy = top + 14; yy < y - 18; yy += 22) {
      for (let xx = x0 + 10 + ((yy / 22) % 2) * 14; xx < x1 - 8; xx += 28) p.sprite(xx, yy, heart, { a: mix(th.wallDot, th.accent, 0.35) });
    }
    // bingkai & jendela kecil
    const fx = Math.round(x0 + pw * (sh.tier === 1 ? 0.62 : 0.5));
    p.rect(fx - 12, top + 22, 24, 22, th.wood2);
    p.rect(fx - 11, top + 23, 22, 20, "#FFF6E4");
    if (sh.tier === 1) p.sprite(fx - 3, top + 29, [".aa.aa.", "aaaaaaa", ".aaaaa.", "..aaa..", "...a..."], { a: th.accent });
    else {
      p.rect(fx - 11, top + 23, 22, 20, mix(th.sky, th.sky2, 0.5));
      p.ellipse(fx - 4, top + 32, 5, 2.6, "#FFFFFF");
      p.rect(fx - 1, top + 23, 2, 20, th.wood2);
      p.rect(fx - 11, top + 32, 22, 2, th.wood2);
    }
    // list atas & papan kaki
    p.rect(x0, top - 3, pw, 3, th.wood2);
    p.rect(x0, top - 3, pw, 1, shade(th.wood, 0.35));
    p.rect(x0, y - 5, pw, 5, th.wood);
    p.rect(x0, y - 5, pw, 1, shade(th.wood, 0.28));
    // sisi bebas panel
    const freeX = sh.side === "R" ? x0 : x1 - 2;
    p.rect(freeX, top - 3, 2, y - top + 3, th.wood2);
    // permukaan rak
    const surf = mix(th.wood, "#FFFFFF", 0.34);
    p.rect(x0, y, pw, D, surf);
    for (let i = 1; i < 4; i++) p.rect(x0, y + i * 6, pw, 1, shade(surf, -0.1));
    for (let i = 0; i < pw / 3; i++) {
      const gx = x0 + Math.floor(hash2(i, sh.tier, 801) * pw);
      const gy = y + 1 + Math.floor(hash2(i, sh.tier, 803) * (D - 2));
      p.px(gx, gy, hash2(i, sh.tier, 805) > 0.5 ? shade(surf, -0.14) : shade(surf, 0.12));
    }
    for (let i = 0; i < pw / 5; i++) {
      const gx = x0 + Math.floor(hash2(i, sh.tier, 811) * pw);
      const gy = y + 3 + Math.floor(hash2(i, sh.tier, 813) * (D - 6));
      p.px(gx, gy, th.bed2);
    }
    // papan depan
    p.rect(x0, y + D, pw, T, th.wood);
    p.rect(x0, y + D, pw, 1, shade(th.wood, 0.42));
    p.rect(x0, y + D + T - 1, pw, 1, th.wood2);
    p.rect(x0, y + D + T - 2, pw, 1, shade(th.wood, -0.18));
    for (let i = 0; i < pw / 6; i++) {
      p.px(x0 + Math.floor(hash2(i, sh.tier, 821) * pw), y + D + 2 + Math.floor(hash2(i, sh.tier, 823) * 3), shade(th.wood, -0.2));
    }
    for (let xx = x0 + 12; xx < x1 - 6; xx += 36) {
      p.px(xx, y + D + 3, shade(th.wood, 0.5));
      p.px(xx + 1, y + D + 3, th.wood2);
    }
    // ujung bulat
    const capX = sh.side === "R" ? x0 : x1;
    p.ellipse(capX, y + D + T / 2, 3.4, T / 2 + 1.2, th.wood2);
    p.ellipse(capX + (sh.side === "R" ? 0.6 : -0.6), y + D + T / 2, 2.6, T / 2 + 0.4, th.wood);
    // siku penyangga
    const brk = (bx: number, dir: number) => {
      for (let i = 0; i < 13; i++) {
        p.rect(bx, y + D + T + i, 3, 1, th.wood2);
        p.rect(bx + dir * Math.min(i, 12), y + D + T + 12 - i, 2, 1, th.wood2);
      }
      p.px(bx + 1, y + D + T + 1, shade(th.wood2, 0.5));
    };
    if (sh.side === "R") { brk(x1 - 16, -1); brk(x0 + 22, 1); }
    else { brk(x0 + 14, 1); brk(x1 - 24, -1); }
    // bayangan jatuh ke bawah
    p.ellipseDither((x0 + x1) / 2, y + D + T + 5, pw * 0.5, 4, "rgba(40,20,50,0.3)");
    p.rect(x0, y + D + T, pw, 3, "rgba(40,20,50,0.26)");
  }
}

export function drawLadder(p: Px, g: LadderGeo, th: Theme) {
  p.push();
  p.origin(0, 0);
  const len = g.yb - g.yt;
  const R = 11;
  const rx = (u: number, s: number) => g.xb + (g.xt - g.xb) * u + s * R;
  const ry = (u: number) => g.yb - len * u;
  const wood = mix(th.wood, "#FFFFFF", 0.12);
  // bayangan lantai
  p.ellipseDither(g.xb, g.yb + 1, 14, 2.6, "rgba(60,34,20,0.28)");
  // rel
  for (const s of [-1, 1]) {
    p.line(rx(0, s) - 2, g.yb, rx(1, s) - 2, g.yt, th.wood2);
    p.line(rx(0, s) + 2, g.yb, rx(1, s) + 2, g.yt, th.wood2);
    p.line(rx(0, s) - 1, g.yb, rx(1, s) - 1, g.yt, wood);
    p.line(rx(0, s), g.yb, rx(1, s), g.yt, wood);
    p.line(rx(0, s) + 1, g.yb, rx(1, s) + 1, g.yt, shade(wood, -0.15));
    p.line(rx(0, s) - 1, g.yb, rx(1, s) - 1, g.yt - 0, wood);
  }
  // anak tangga
  const n = Math.max(3, Math.floor(len / 9));
  for (let i = 1; i <= n; i++) {
    const u = i / (n + 1);
    const y = ry(u);
    const xa = rx(u, -1);
    const xb = rx(u, 1);
    const c = i % 2 ? th.accent : mix(th.accent, "#FFFFFF", 0.35);
    p.rect(xa, y - 1, xb - xa, 3, shade(c, -0.4));
    p.rect(xa, y - 1, xb - xa, 2, c);
    p.rect(xa, y - 1, xb - xa, 1, shade(c, 0.4));
    p.px(xa - 1, y, shade(c, -0.3));
    p.px(xb + 1, y, shade(c, -0.3));
  }
  // kaki karet & bola penutup
  for (const s of [-1, 1]) {
    p.rect(rx(0, s) - 3, g.yb, 7, 2, "#3A2A30");
    p.ellipse(rx(1, s), g.yt - 2, 3, 3, shade(th.accent, -0.35));
    p.ellipse(rx(1, s), g.yt - 2, 2.2, 2.2, th.accent);
    p.px(rx(1, s) - 1, g.yt - 3, "#FFFFFF");
  }
  // sulur daun
  for (let i = 0; i < 9; i++) {
    const u = 0.1 + i * 0.1;
    const lx = rx(u, -1) + (i % 2 ? -3 : 3);
    p.px(lx, ry(u), "#4FA855");
    p.px(lx + (i % 2 ? -1 : 1), ry(u) - 1, "#7BC96F");
  }
  // tanda hati
  p.sprite(Math.round((g.xb + g.xt) / 2) - 3, g.yt - 14, [".a.a.", "aaaaa", ".aaa.", "..a.."], { a: th.accent });
  p.pop();
}

export function drawSlide(p: Px, sl: SlideGeo, th: Theme, front: boolean) {
  p.push();
  p.origin(0, 0);
  const c1 = th.accent;
  const light = mix(c1, "#FFFFFF", 0.5);
  const dark = shade(c1, -0.4);
  const N = 240;
  const norm = (q: { dx: number; dy: number }) => {
    let nx = -q.dy;
    let ny = q.dx;
    if (ny > 0) { nx = -nx; ny = -ny; }
    return { nx, ny };
  };
  if (!front) {
    // tiang penyangga
    for (const u of [0.22, 0.52, 0.82]) {
      const q = slidePoint(sl, u);
      const base = sl.ye + 6;
      if (base > q.y + 4) {
        p.rect(q.x - 1, q.y + 3, 3, base - q.y - 3, th.wood2);
        p.rect(q.x - 1, q.y + 3, 1, base - q.y - 3, shade(th.wood, 0.2));
      }
    }
    for (let i = 0; i <= N; i++) {
      const u = i / N;
      const q = slidePoint(sl, u);
      const { nx, ny } = norm(q);
      // sisi bawah
      for (let k = -3; k <= -1; k++) p.px(q.x + nx * k, q.y + ny * k, k === -3 ? dark : shade(c1, -0.15));
      // dinding belakang
      for (let k = 1; k <= 8; k++) p.px(q.x + nx * k, q.y + ny * k, k === 8 ? light : mix(c1, "#2A1830", 0.18 + (8 - k) * 0.02));
      // lantai
      p.px(q.x, q.y, light);
      p.px(q.x + nx * 0.6, q.y + ny * 0.6, c1);
      if (i % 22 === 0) p.px(q.x + nx * 4, q.y + ny * 4, "#FFFFFF");
    }
    // papan start & pagar kecil
    const q0 = slidePoint(sl, 0);
    p.rect(q0.x - 2, q0.y - 12, 3, 12, th.wood2);
    p.ellipse(q0.x - 0.5, q0.y - 13, 2.4, 2.4, c1);
    p.px(q0.x - 1, q0.y - 14, "#FFFFFF");
  } else {
    for (let i = 0; i <= N; i++) {
      const q = slidePoint(sl, i / N);
      const { nx, ny } = norm(q);
      const cols = [dark, light, c1, c1, light];
      for (let k = -1; k <= 3; k++) p.px(q.x + nx * k, q.y + ny * k, cols[k + 1]);
    }
    const q1 = slidePoint(sl, 1);
    p.ellipse(q1.x, q1.y + 1, 3, 2, shade(c1, -0.3));
    p.ellipse(q1.x, q1.y, 2.4, 1.6, c1);
    p.px(q1.x - 1, q1.y - 1, "#FFFFFF");
  }
  p.pop();
}

// =====================================================================
//  LAMPU HIAS
// =====================================================================
const RAINBOW = ["#FF6B8A", "#FFB13D", "#FFE066", "#6BE29A", "#5CC8F2", "#B38BFF"];

export function drawLights(p: Px, L: Layout, kind: string, t: number, night: boolean) {
  p.push();
  p.origin(0, 0);
  type Str = { x0: number; x1: number; y: number; sag: number };
  const strs: Str[] = [{ x0: L.x0 + 2, x1: L.x1 - 2, y: L.y0 + 3, sag: 9 }];
  if (L.tiers === 3) for (const sh of L.shelves) strs.push({ x0: sh.x0 + 3, x1: sh.x1 - 3, y: sh.y + SHELF_D + SHELF_T + 2, sag: 4 });
  const wire = night ? "#120D1C" : "#5A3A1E";
  let idx = 0;
  for (const s of strs) {
    const len = s.x1 - s.x0;
    const swags = Math.max(1, Math.round(len / 74));
    const sw = len / swags;
    for (let k = 0; k < swags; k++) {
      const a = s.x0 + k * sw;
      const yAt = (x: number) => s.y + Math.round(Math.sin(((x - a) / sw) * Math.PI) * s.sag);
      for (let x = Math.round(a); x < a + sw; x++) p.px(x, yAt(x), wire);
      const nb = Math.max(2, Math.round(sw / 11));
      for (let i = 1; i < nb; i++) {
        const bx = Math.round(a + (i / nb) * sw);
        const by = yAt(bx);
        const seed = idx++;
        const tw = 0.55 + 0.45 * Math.sin(t * 2.4 + seed * 1.7);
        bulb(p, kind, bx, by + 1, t, seed, tw, night);
      }
    }
  }
  p.pop();
}

function bulb(p: Px, kind: string, x: number, y: number, t: number, seed: number, tw: number, night: boolean) {
  const g = (c: string, r: number, a: number) => p.ellipseDither(x, y + 3, r, r, `rgba(${c},${(a * tw * (night ? 1 : 0.55)).toFixed(2)})`, seed & 1);
  if (kind === "bendera") {
    const c = ["#FF8FB0", "#FFD84D", "#4FB8FF", "#3FE0B0"][seed % 4];
    const sway = Math.round(Math.sin(t * 2 + seed) * 1);
    for (let k = 0; k < 6; k++) p.rect(x - 3 + k + sway * (k > 3 ? 1 : 0), y + 1 + k, Math.max(1, 7 - k * 2), 1, c);
    return;
  }
  if (kind === "bintang") {
    g("255,224,120", night ? 8 : 5, 0.5);
    const c = tw > 0.7 ? "#FFE98A" : "#FFC93C";
    p.sprite(x - 2, y + 1, ["..a..", ".aaa.", "aaaaa", ".a.a."], { a: c });
    p.px(x, y + 2, "#FFFFFF");
  } else if (kind === "bunga") {
    g("255,150,190", night ? 8 : 5, 0.45);
    const c = tw > 0.7 ? "#FFB3CC" : "#FF8FB0";
    p.px(x, y + 1, c); p.px(x - 2, y + 3, c); p.px(x + 2, y + 3, c); p.px(x - 1, y + 5, c); p.px(x + 1, y + 5, c);
    p.rect(x - 1, y + 2, 3, 3, c);
    p.px(x, y + 3, "#FFE066");
  } else if (kind === "lentera") {
    g("255,170,70", night ? 9 : 5, 0.5);
    const sway = Math.round(Math.sin(t * 1.3 + seed) * 0.8);
    p.rect(x - 1 + sway, y + 1, 3, 1, "#7A3A12");
    p.ellipse(x + sway, y + 5, 3.4, 4.2, "#9A3A10");
    p.ellipse(x + sway, y + 5, 2.7, 3.5, tw > 0.7 ? "#FFB13D" : "#FF8F2A");
    p.px(x - 1 + sway, y + 4, "#FFE9A8");
    p.rect(x - 1 + sway, y + 9, 3, 1, "#7A3A12");
    p.px(x + sway, y + 10, "#FF5D5D");
  } else if (kind === "kunang") {
    const px0 = x + Math.round(Math.sin(t * 0.9 + seed * 2) * 1.5);
    const py0 = y + 3 + Math.round(Math.cos(t * 0.7 + seed) * 1.5);
    p.ellipseDither(px0, py0, night ? 7 : 4, night ? 7 : 4, `rgba(220,255,120,${(0.55 * tw).toFixed(2)})`, seed & 1);
    p.px(px0, py0, tw > 0.6 ? "#F6FFB0" : "#C8F060");
    p.px(px0 - 1, py0, "#9FD84A");
    p.px(px0 + 1, py0, "#9FD84A");
  } else if (kind === "hati") {
    g("255,110,150", night ? 8 : 5, 0.5);
    const pulse = Math.sin(t * 3 + seed) > 0.6;
    const spr = pulse ? [".aa.aa.", "aaaaaaa", "aaaaaaa", ".aaaaa.", "..aaa..", "...a..."] : [".a.a.", "aaaaa", "aaaaa", ".aaa.", "..a.."];
    p.sprite(x - Math.floor(spr[0].length / 2), y + 1, spr, { a: tw > 0.7 ? "#FF7FA0" : "#E8527E" });
    p.px(x - 1, y + 2, "#FFD0DE");
  } else if (kind === "pelangi") {
    const c = RAINBOW[(seed + Math.floor(t * 1.4)) % RAINBOW.length];
    p.ellipseDither(x, y + 3, night ? 8 : 5, night ? 8 : 5, c.replace("#", "rgba(") && "rgba(255,255,255,0.25)", seed & 1);
    p.ellipse(x, y + 4, 3.2, 3.2, shade(c, -0.4));
    p.ellipse(x, y + 4, 2.5, 2.5, c);
    p.px(x - 1, y + 3, "#FFFFFF");
    p.rect(x - 1, y + 1, 3, 1, "#8A8398");
  }
}

// =====================================================================
//  TANGAN PEMAIN (saat mengangkat hamster)
// =====================================================================
const SKIN = { o: "#8E4F34", s: "#F7C9A5", h: "#FFE3CC", d: "#E0A07C", n: "#FFF0E6" };

export function drawHandBack(p: Px, cx: number, cy: number, th: Theme) {
  p.push();
  p.origin(0, 0);
  const N = 44;
  const pt = (i: number) => ({ x: cx + 4 + i * 0.5, y: cy + 8 + i * 1.55, sleeve: i > 16, r: 7 + i * 0.04 });
  // lapis garis tepi dulu supaya lengan tidak belang
  for (let i = 0; i < N; i++) {
    const q = pt(i);
    p.ellipse(q.x, q.y, q.r + 1, q.r + 1, q.sleeve ? shade(th.accent, -0.55) : SKIN.o);
  }
  p.ellipse(cx + 2, cy + 4, 13, 10, SKIN.o);
  for (let i = 0; i < N; i++) {
    const q = pt(i);
    p.ellipse(q.x, q.y, q.r, q.r, q.sleeve ? th.accent : SKIN.s);
    if (q.sleeve) {
      p.px(q.x - q.r + 1, q.y, shade(th.accent, 0.4));
      p.px(q.x + q.r - 2, q.y, shade(th.accent, -0.25));
    }
  }
  // lipatan manset
  const cuff = pt(17);
  p.rect(cuff.x - cuff.r, cuff.y - 1, cuff.r * 2, 2, shade(th.accent, 0.5));
  // telapak
  p.ellipse(cx + 2, cy + 4, 12, 9, SKIN.s);
  p.ellipse(cx + 1, cy + 7, 9, 4, SKIN.d);
  p.pop();
}

export function drawHandFront(p: Px, cx: number, cy: number, sq: number, t: number) {
  p.push();
  p.origin(0, 0);
  const sh = Math.round(sq * 1.2);
  // tiga jari melingkar dari kiri
  for (let i = 0; i < 3; i++) {
    const y = cy - 5 + i * 4.6;
    const x = cx - 3 + i * 0.5 + sh * (i % 2 ? 0.4 : 0.9);
    const rx = 10.5 - i * 0.6;
    p.ellipse(x, y, rx + 1, 3.3, SKIN.o);
    p.ellipse(x, y, rx, 2.5, SKIN.s);
    p.rect(x - rx + 2, y - 2, rx * 1.2, 1, SKIN.h);
    p.rect(x - rx + 3, y + 1, rx * 1.3, 1, SKIN.d);
    p.ellipse(x - rx + 1.4, y, 1.8, 1.8, SKIN.n);
    p.px(x - rx + 1, y - 1, "#FFFFFF");
    p.px(x + rx - 3, y, SKIN.d);
  }
  // ibu jari menekan dari atas kanan
  p.ellipse(cx + 8 - sh * 0.4, cy - 9, 4.8, 3, SKIN.o);
  p.ellipse(cx + 8 - sh * 0.4, cy - 9, 3.9, 2.2, SKIN.s);
  p.px(cx + 5 - sh * 0.4, cy - 9, SKIN.n);
  p.px(cx + 9, cy - 10, SKIN.h);
  void t;
  p.pop();
}

// =====================================================================
//  TANGAN HANTU (saat mengangkat hamster): hanya siluet bening yang berkilau
// =====================================================================
export function drawGhostHand(p: Px, cx: number, cy: number, t: number, front: boolean) {
  p.push();
  p.origin(0, 0);
  const a = (v: number) => `rgba(255,238,248,${v.toFixed(2)})`;
  const pulse = 0.5 + 0.5 * Math.sin(t * 2.6);
  if (!front) {
    p.ellipseDither(cx + 1, cy + 4, 17, 11, a(0.2 + pulse * 0.06), 0);
    p.ellipse(cx + 1, cy + 5, 12, 7, a(0.15));
    p.ellipse(cx + 1, cy + 6, 8, 4, a(0.12));
  } else {
    for (let i = 0; i < 3; i++) {
      const y = cy - 4 + i * 4.4;
      const x = cx - 2 + i * 0.5;
      const rx = 10 - i * 0.6;
      p.ellipse(x, y, rx + 1, 3, a(0.17));
      p.ellipse(x, y, rx, 2.3, a(0.24));
      p.rect(x - rx + 2, y - 2, rx * 1.2, 1, a(0.42));
      p.ellipse(x - rx + 1.4, y, 1.6, 1.6, a(0.42));
    }
    p.ellipse(cx + 8, cy - 8, 4, 2.4, a(0.24));
    p.rect(cx + 6, cy - 9, 4, 1, a(0.4));
    for (let i = 0; i < 4; i++) {
      const ang = t * 1.8 + i * 1.6;
      const sx = cx + Math.cos(ang) * 14;
      const sy = cy - 2 + Math.sin(ang * 1.3) * 8;
      if (Math.sin(t * 5 + i * 2) > 0.2) {
        p.px(sx, sy, a(0.8));
        p.px(sx - 1, sy, a(0.4));
        p.px(sx + 1, sy, a(0.4));
        p.px(sx, sy - 1, a(0.4));
        p.px(sx, sy + 1, a(0.4));
      }
    }
  }
  p.pop();
}

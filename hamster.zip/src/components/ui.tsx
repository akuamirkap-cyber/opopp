import { useEffect, useRef, type ReactNode } from "react";
import { drawPortrait } from "../game/hamster";
import type { Look } from "../game/data";

export function Portrait({ look, size = 64, animate = true, className = "" }: { look: Look; size?: number; animate?: boolean; className?: string }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  const lookRef = useRef(look);
  lookRef.current = look;

  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let acc = 0;
    let last = performance.now();
    let t = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      const dt = (now - last) / 1000;
      last = now;
      acc += dt;
      if (acc < 1 / 18) return;
      t += acc;
      acc = 0;
      ctx.imageSmoothingEnabled = false;
      drawPortrait(ctx, lookRef.current, 68, t);
    };
    if (animate) raf = requestAnimationFrame(tick);
    else {
      ctx.imageSmoothingEnabled = false;
      drawPortrait(ctx, lookRef.current, 68, 0);
    }
    return () => cancelAnimationFrame(raf);
  }, [animate]);

  return <canvas ref={ref} width={68} height={68} style={{ width: size, height: size }} className={className} />;
}

export function Bar({ value, color, label, icon, compact = false }: { value: number; color: string; label: string; icon: string; compact?: boolean }) {
  const v = Math.max(0, Math.min(100, value));
  const low = v < 25;
  return (
    <div className="flex items-center gap-2">
      <span className={`text-[13px] leading-none ${low ? "animate-pulse" : ""}`} aria-hidden>{icon}</span>
      <div className="min-w-0 flex-1">
        {!compact && (
          <div className="mb-0.5 flex items-baseline justify-between gap-2">
            <span className="font-pixel text-[8px] tracking-wide text-cream/70">{label}</span>
            <span className="font-pixel text-[8px]" style={{ color: low ? "#FF5A5A" : color }}>{Math.round(v)}</span>
          </div>
        )}
        <div className="pixel-inset relative h-[10px] w-full overflow-hidden p-0">
          <div
            className="h-full transition-[width] duration-300 ease-out"
            style={{
              width: `${v}%`,
              background: `linear-gradient(180deg, ${color}, ${color}bb)`,
              boxShadow: `0 0 8px ${color}66`,
            }}
          />
          <div
            className="pointer-events-none absolute inset-0"
            style={{ backgroundImage: "repeating-linear-gradient(90deg, transparent 0 6px, rgba(0,0,0,.45) 6px 8px)" }}
          />
        </div>
      </div>
    </div>
  );
}

export function Slider({
  label, value, min, max, step = 0.01, onChange, format, hint,
}: {
  label: string; value: number; min: number; max: number; step?: number;
  onChange: (v: number) => void; format?: (v: number) => string; hint?: string;
}) {
  const pct = ((value - min) / (max - min)) * 100;
  return (
    <label className="block select-none">
      <div className="mb-1 flex items-baseline justify-between gap-2">
        <span className="font-pixel text-[9px] text-cream/80">{label}</span>
        <span className="font-pixel text-[9px] text-honey">{format ? format(value) : value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        className="cute"
        min={min}
        max={max}
        step={step}
        value={value}
        style={{ ["--pct" as string]: `${pct}%` }}
        onChange={(e) => onChange(parseFloat(e.target.value))}
      />
      {hint && <p className="mt-0.5 text-[11px] leading-tight text-cream/40">{hint}</p>}
    </label>
  );
}

export function Toggle({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="pixel-inset flex w-full items-center justify-between gap-3 px-2.5 py-2 text-left transition-colors hover:border-honey/60"
    >
      <span>
        <span className="block font-pixel text-[9px] text-cream/85">{label}</span>
        {hint && <span className="block text-[11px] leading-tight text-cream/40">{hint}</span>}
      </span>
      <span
        className="relative h-[18px] w-[34px] shrink-0 rounded-[4px] border-2 border-ink transition-colors"
        style={{ background: checked ? "linear-gradient(180deg,#3FE0B0,#22A98A)" : "#2C1A3C" }}
      >
        <span
          className="absolute top-[1px] h-[12px] w-[12px] rounded-[2px] border border-ink bg-cream transition-all"
          style={{ left: checked ? 17 : 1 }}
        />
      </span>
    </button>
  );
}

export function SectionTitle({ children, right }: { children: ReactNode; right?: ReactNode }) {
  return (
    <div className="mb-2 flex items-center gap-2">
      <h3 className="font-pixel text-[10px] tracking-wide text-honey text-shadow-pixel">{children}</h3>
      <div className="h-[2px] flex-1" style={{ backgroundImage: "repeating-linear-gradient(90deg,#563a70 0 4px,transparent 4px 8px)" }} />
      {right}
    </div>
  );
}

export function Pill({ children, tone = "#F5A65B", className = "" }: { children: ReactNode; tone?: string; className?: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-[5px] border-2 px-2 py-[3px] font-pixel text-[9px] ${className}`}
      style={{ borderColor: `${tone}66`, background: `${tone}1f`, color: tone }}
    >
      {children}
    </span>
  );
}

export function ActionButton({
  emoji, label, sub, onClick, tone = "#F5A65B", disabled, active,
}: {
  emoji: string; label: string; sub?: string; onClick: () => void; tone?: string; disabled?: boolean; active?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      data-active={active ? "true" : "false"}
      className="pixel-btn no-tap-highlight flex flex-col items-center gap-0.5 px-2 py-2"
      style={{ background: `linear-gradient(180deg, ${tone}dd, ${tone}88)` }}
    >
      <span className="text-[18px] leading-none drop-shadow" aria-hidden>{emoji}</span>
      <span className="font-pixel text-[8px] leading-tight text-ink">{label}</span>
      {sub && <span className="font-pixel text-[7px] leading-none text-ink/60">{sub}</span>}
    </button>
  );
}

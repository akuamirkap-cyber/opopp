import { useState } from "react";
import {
  PALETTES, PATTERNS, EYES, FOODS, ACCESSORIES, THEMES, ACHIEVEMENTS, ACTIVITY_LABEL, TIPS, getTheme, LIGHTS,
  PRICE_PET, PRICE_CAGE, PRICE_TOWER, PRICE_BOX, MAX_CAGES, MAX_PETS_PER_CAGE, DAILY_POOL, CHAIN, missionDef, mProgress,
  type Look, type Settings, type Profile, type PetRec, type CageRec, type WeatherKind, type Reward, type MissionDef,
} from "../game/data";
import type { Snapshot } from "../game/engine";
import { Bar, Pill, Portrait, SectionTitle, Slider, Toggle } from "./ui";

export type LogEntry = { id: number; text: string; emoji: string; time: string };

export const WEATHER_OPTS: { k: WeatherKind; e: string; l: string }[] = [
  { k: "clear", e: "☀️", l: "CERAH" },
  { k: "rain", e: "🌧️", l: "HUJAN" },
  { k: "storm", e: "⛈️", l: "BADAI" },
  { k: "snow", e: "❄️", l: "SALJU" },
];

const NEED_META = [
  { key: "food", label: "KENYANG", icon: "🍽️", color: "#FFB13D" },
  { key: "happy", label: "CERIA", icon: "💖", color: "#FF4F87" },
  { key: "energy", label: "ENERGI", icon: "⚡", color: "#FFD84D" },
  { key: "clean", label: "BERSIH", icon: "🫧", color: "#3FE0B0" },
  { key: "water", label: "SEGAR", icon: "💧", color: "#4FB8FF" },
] as const;

function advice(s: Snapshot) {
  const n = s.needs;
  const entries: [number, string][] = [
    [n.food, "Perutnya keroncongan. Jatuhkan camilan ke serbuk kayu!"],
    [n.water, "Tenggorokannya kering. Cek botol minumnya ya."],
    [n.energy, "Matanya berat… suruh tidur di rumah mungil atau kubur diri."],
    [n.clean, "Bulunya kusam. Mandi pasir bikin wangi lagi."],
    [n.happy, "Dia butuh bermain. Ajak lari di roda atau belai!"],
  ];
  entries.sort((a, b) => a[0] - b[0]);
  if (entries[0][0] > 68) return "Semua kebutuhannya terpenuhi. Hamster paling bahagia sedunia! ✨";
  return entries[0][1];
}

const ACTIONS: { cmd: string; e: string; l: string; s: string; cls: string; dark?: boolean }[] = [
  { cmd: "refillBowl", e: "🥣", l: "ISI MANGKUK", s: "6 biji", cls: "from-[#ffb13d] to-[#d9821f]" },
  { cmd: "refillBottle", e: "💧", l: "ISI BOTOL", s: "3 biji", cls: "from-[#4fb8ff] to-[#2a7fc4]" },
  { cmd: "wheel", e: "🎡", l: "AJAK LARI", s: "ceria +++", cls: "from-[#ff6f9c] to-[#d43b6d]" },
  { cmd: "turbo", e: "🌪️", l: "TURBO RODA!", s: "awas terlempar", cls: "from-[#ff8f5a] to-[#d4552a]" },
  { cmd: "explore", e: "🪜", l: "JELAJAH MENARA", s: "tangga + perosotan", cls: "from-[#8fd98a] to-[#4fa855]" },
  { cmd: "look", e: "👀", l: "LIHAT SEKITAR", s: "kanan-kiri-atas-bawah", cls: "from-[#ffd08a] to-[#e0a049]" },
  { cmd: "roll", e: "⚽", l: "GELINDING", s: "bola hamster", cls: "from-[#ffb0c8] to-[#e0608f]" },
  { cmd: "glass", e: "👋", l: "SAPA DI KACA", s: "ikuti kursormu", cls: "from-[#8be0ff] to-[#3f9fd0]" },
  { cmd: "wall", e: "🕷️", l: "MANJAT DINDING", s: "hati-hati licin", cls: "from-[#c8b0ff] to-[#8a64d8]" },
  { cmd: "lick", e: "👅", l: "MANDI KUCING", s: "jilat tangan", cls: "from-[#ffb0c8] to-[#e0608f]" },
  { cmd: "bath", e: "🏖️", l: "MANDI PASIR", s: "bersih +++", cls: "from-[#3fe0b0] to-[#22a98a]" },
  { cmd: "sleep", e: "😴", l: "TIDURKAN", s: "di rumah mungil", cls: "from-[#a66bff] to-[#7440c4]" },
  { cmd: "hide", e: "🏠", l: "SEMBUNYI", s: "cilukba", cls: "from-[#c9a46e] to-[#9a7040]" },
  { cmd: "bury", e: "🕳️", l: "KUBUR DIRI", s: "serbuk kayu", cls: "from-[#e8c77a] to-[#c29a44]" },
  { cmd: "fight", e: "🤼", l: "AJAK GULAT", s: "butuh teman", cls: "from-[#ff9ec0] to-[#e0608f]" },
  { cmd: "call", e: "🫶", l: "PANGGIL", s: "hampiri kamu", cls: "from-[#ffd08a] to-[#e0a049]" },
];

export function CarePanel({
  snap, pet, settings, onCommand, onNight, bowlPct, bottlePct,
}: {
  snap: Snapshot; pet: PetRec | null; settings: Settings;
  onCommand: (c: string) => void; onNight: (v: boolean) => void; bowlPct: number; bottlePct: number;
}) {
  const [tip] = useState(() => Math.floor(Math.random() * TIPS.length));
  const moodEmoji = snap.mood > 0.8 ? "🥰" : snap.mood > 0.55 ? "😊" : snap.mood > 0.32 ? "😐" : "🥺";
  return (
    <div className="space-y-4">
      <div className="pixel-inset flex items-center gap-3 p-3">
        <div className="shrink-0 rounded-[6px] border-2 border-edge bg-[#1b1026] p-1">
          {pet ? <Portrait look={pet.look} size={62} /> : <div className="h-[62px] w-[62px]" />}
        </div>
        <div className="min-w-0">
          <div className="truncate font-pixel text-[12px] text-honey">{pet?.name ?? "—"} {moodEmoji}</div>
          <div className="mt-1 text-[13px] leading-tight text-cream/75">{ACTIVITY_LABEL[snap.act] ?? "beraktivitas"}</div>
          <div className="mt-1.5 flex flex-wrap gap-1">
            <Pill tone="#FFD08A">{snap.tiers === 3 ? "MENARA" : "AQUARIUM"} {snap.focus + 1}</Pill>
            {snap.tiers === 3 && <Pill tone="#8FD98A">LANTAI {snap.tier + 1}</Pill>}
            <Pill tone="#4FB8FF">{snap.clock}</Pill>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <SectionTitle>Kondisi</SectionTitle>
        {NEED_META.map((m) => (
          <Bar key={m.key} label={m.label} icon={m.icon} color={m.color} value={snap.needs[m.key]} />
        ))}
        <p className="pixel-inset mt-2 p-2 text-[12.5px] leading-snug text-cream/70">{advice(snap)}</p>
      </div>

      <div>
        <SectionTitle>Aksi Cepat</SectionTitle>
        <div className="grid grid-cols-2 gap-2">
          {ACTIONS.map((a) => (
            <button
              key={a.cmd}
              onClick={() => onCommand(a.cmd)}
              className={`pixel-btn bg-gradient-to-b ${a.cls} px-2 py-2 text-left`}
            >
              <span className="block text-[16px] leading-none">{a.e}</span>
              <span className="mt-1 block font-pixel text-[8px] text-ink">{a.l}</span>
              <span className="font-pixel text-[7px] text-ink/70">
                {a.cmd === "refillBowl" ? `6 biji · ${bowlPct}%` : a.cmd === "refillBottle" ? `3 biji · ${bottlePct}%` : a.s}
              </span>
            </button>
          ))}
        </div>
      </div>

      <Toggle label="LAMPU MALAM" checked={settings.night} onChange={onNight} hint="Gelap = tidur lebih nyenyak & energi cepat pulih" />

      <div>
        <SectionTitle>Isi Aquarium {snap.focus + 1}</SectionTitle>
        <div className="grid grid-cols-3 gap-2 text-center">
          {[
            { l: "KOTORAN", v: snap.poops, e: "💩", tone: snap.poops > 2 ? "#FF5A5A" : "#8BE0FF" },
            { l: "SIMPANAN", v: snap.stash, e: "🌰", tone: "#FFD08A" },
            { l: "RODA", v: `${Math.floor(snap.wheelSec)}s`, e: "🎡", tone: "#FF9EBB" },
          ].map((x) => (
            <div key={x.l} className="pixel-inset px-1 py-2">
              <div className="text-[15px] leading-none">{x.e}</div>
              <div className="mt-1 font-pixel text-[11px]" style={{ color: x.tone }}>{x.v}</div>
              <div className="font-pixel text-[7px] text-cream/45">{x.l}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="rounded-[6px] border-2 border-honey/30 bg-honey/10 p-2.5">
        <div className="font-pixel text-[9px] text-honey">TAHUKAH KAMU?</div>
        <p className="mt-1 text-[12.5px] leading-snug text-cream/75">{TIPS[tip]}</p>
      </div>
    </div>
  );
}

export function StylePanel({
  look, petName, patchLook, settings, patchSettings, profile, cageTheme, cageIndex, onPickTheme,
  cageLights, onPickLight, onBuyAcc, onRandom, onReset, onExport,
}: {
  look: Look; petName: string; patchLook: (p: Partial<Look>) => void; settings: Settings; patchSettings: (p: Partial<Settings>) => void;
  profile: Profile; cageTheme: string; cageIndex: number; onPickTheme: (id: string) => void;
  cageLights: string; onPickLight: (id: string) => void;
  onBuyAcc: (id: string) => void; onRandom: () => void; onReset: () => void; onExport: () => void;
}) {
  return (
    <div className="space-y-4">
      <div className="pixel-inset flex items-center gap-3 p-3">
        <div className="shrink-0 rounded-[6px] border-2 border-edge bg-gradient-to-b from-[#3a2450] to-[#1b1026] p-1">
          <Portrait look={look} size={76} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate font-pixel text-[10px] text-honey">STUDIO · {petName.toUpperCase()}</div>
          <p className="mt-1 text-[12px] leading-tight text-cream/60">Perubahan langsung terlihat di aquarium.</p>
          <div className="mt-2 flex gap-2">
            <button onClick={onRandom} className="pixel-btn flex-1 bg-gradient-to-b from-[#ff6f9c] to-[#d43b6d] px-2 py-1.5 font-pixel text-[8px] text-ink">🎲 ACAK</button>
            <button onClick={onReset} className="pixel-btn flex-1 bg-gradient-to-b from-[#8b7aa8] to-[#5f4f7d] px-2 py-1.5 font-pixel text-[8px] text-cream">↺ RESET</button>
          </div>
        </div>
      </div>

      <div>
        <SectionTitle>Warna Bulu</SectionTitle>
        <div className="grid grid-cols-6 gap-1.5">
          {PALETTES.map((p) => (
            <button
              key={p.id}
              title={p.name}
              onClick={() => patchLook({ palette: p.id })}
              className="pixel-btn aspect-square"
              data-active={look.palette === p.id}
              style={{ background: `linear-gradient(150deg, ${p.light} 0%, ${p.base} 55%, ${p.dark} 100%)` }}
            >
              <span className="sr-only">{p.name}</span>
            </button>
          ))}
        </div>
        <p className="mt-1 text-center font-pixel text-[8px] text-cream/50">{PALETTES.find((p) => p.id === look.palette)?.name}</p>
      </div>

      <div>
        <SectionTitle>Pola Bulu</SectionTitle>
        <div className="flex flex-wrap gap-1.5">
          {PATTERNS.map((p) => (
            <button
              key={p.id}
              onClick={() => patchLook({ pattern: p.id })}
              className={`pixel-btn px-2.5 py-1.5 font-pixel text-[8px] ${look.pattern === p.id ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink" : "bg-surface2 text-cream/70"}`}
            >
              {p.name.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <div>
        <SectionTitle>Warna Mata</SectionTitle>
        <div className="flex flex-wrap gap-1.5">
          {EYES.map((e) => (
            <button
              key={e.id}
              title={e.name}
              onClick={() => patchLook({ eye: e.c })}
              data-active={look.eye === e.c}
              className="pixel-btn h-7 w-7 rounded-full"
              style={{ background: `radial-gradient(circle at 50% 50%, #140A12 0 46%, ${e.c} 50%, ${e.c} 100%)` }}
            >
              <span className="sr-only">{e.name}</span>
            </button>
          ))}
        </div>
        <p className="mt-1 text-[11px] leading-tight text-cream/40">Pupil hitam selalu 80% dari ukuran kornea berwarna.</p>
      </div>

      <div className="space-y-2.5">
        <SectionTitle>Bentuk Tubuh</SectionTitle>
        <Slider label="KEBULUAN" value={look.fluff} min={0} max={1} onChange={(v) => patchLook({ fluff: v })} format={(v) => `${Math.round(v * 100)}%`} />
        <Slider label="PIPI TEMBEM" value={look.cheek} min={0} max={1} onChange={(v) => patchLook({ cheek: v })} format={(v) => `${Math.round(v * 100)}%`} />
        <Slider label="GEMBUL" value={look.chub} min={0.85} max={1.3} onChange={(v) => patchLook({ chub: v })} format={(v) => `${v.toFixed(2)}x`} />
        <Slider label="UKURAN BADAN" value={look.scale} min={0.78} max={1.3} onChange={(v) => patchLook({ scale: v })} format={(v) => `${v.toFixed(2)}x`} />
        <Slider label="UKURAN MATA" value={look.eyeSize} min={0.25} max={1.6} onChange={(v) => patchLook({ eyeSize: v })} format={(v) => `${v.toFixed(2)}x`} hint="Default 0.25: manik kecil yang imut. Geser ke kanan untuk mata lebih besar." />
        <Slider label="DAUN TELINGA" value={look.earSize} min={0.7} max={1.45} onChange={(v) => patchLook({ earSize: v })} format={(v) => `${v.toFixed(2)}x`} />
        <Slider label="RONA PIPI" value={look.blush} min={0} max={1} onChange={(v) => patchLook({ blush: v })} format={(v) => `${Math.round(v * 100)}%`} />
        <Toggle label="KILAU MATA" checked={look.sparkle} onChange={(v) => patchLook({ sparkle: v })} hint="Bintang kecil saat sedang bahagia" />
      </div>

      <div>
        <SectionTitle right={<span className="font-pixel text-[8px] text-cream/40">{profile.owned.length} dimiliki</span>}>Aksesori</SectionTitle>
        <div className="grid grid-cols-3 gap-1.5">
          {ACCESSORIES.map((a) => {
            const owned = profile.owned.includes(a.id);
            const active = look.accessory === a.id;
            return (
              <button
                key={a.id}
                onClick={() => (owned ? patchLook({ accessory: a.id }) : onBuyAcc(a.id))}
                data-active={active}
                className={`pixel-btn flex flex-col items-center gap-0.5 px-1 py-1.5 ${active ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049]" : owned ? "bg-surface2" : "bg-[#241631]"}`}
              >
                <span className="text-[16px] leading-none">{a.emoji}</span>
                <span className={`text-center font-pixel text-[7px] leading-tight ${active ? "text-ink" : "text-cream/70"}`}>{a.name.split(" ")[0].toUpperCase()}</span>
                <span className={`font-pixel text-[7px] ${active ? "text-ink/60" : owned ? "text-mint" : "text-honey"}`}>
                  {owned ? (active ? "DIPAKAI" : "PAKAI") : `🌻${a.price}`}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <SectionTitle>Tema Aquarium {cageIndex + 1}</SectionTitle>
        <div className="grid grid-cols-2 gap-1.5">
          {THEMES.map((t) => {
            const owned = profile.owned.includes(t.id);
            const active = cageTheme === t.id;
            return (
              <button
                key={t.id}
                onClick={() => onPickTheme(t.id)}
                data-active={active}
                className="pixel-btn overflow-hidden bg-[#241631] p-0 text-left"
              >
                <span className="flex h-5 w-full">
                  <span className="flex-1" style={{ background: t.sky }} />
                  <span className="flex-1" style={{ background: t.hill }} />
                  <span className="flex-1" style={{ background: t.bed }} />
                  <span className="flex-1" style={{ background: t.accent }} />
                </span>
                <span className="block px-1.5 py-1">
                  <span className="block font-pixel text-[7.5px] leading-tight text-cream/80">{t.name.toUpperCase()}</span>
                  <span className={`font-pixel text-[7px] ${owned ? "text-mint" : "text-honey"}`}>{owned ? (active ? "DIPAKAI" : "PAKAI") : `🌻${t.price}`}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div>
        <SectionTitle>Lampu Hias {cageIndex + 1}</SectionTitle>
        <div className="grid grid-cols-2 gap-1.5">
          {LIGHTS.map((l) => {
            const owned = profile.owned.includes(l.id);
            const active = cageLights === l.id;
            return (
              <button
                key={l.id}
                onClick={() => onPickLight(l.id)}
                data-active={active}
                className={`pixel-btn flex items-center gap-2 px-2 py-1.5 text-left ${active ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049]" : owned ? "bg-surface2" : "bg-[#241631]"}`}
              >
                <span className="text-[16px] leading-none">{l.emoji}</span>
                <span className="min-w-0">
                  <span className={`block truncate font-pixel text-[7.5px] leading-tight ${active ? "text-ink" : "text-cream/80"}`}>{l.name.toUpperCase()}</span>
                  <span className={`font-pixel text-[7px] ${active ? "text-ink/60" : owned ? "text-mint" : "text-honey"}`}>{owned ? (active ? "DIPAKAI" : "PAKAI") : `🌻${l.price}`}</span>
                </span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="space-y-2.5">
        <SectionTitle>Cuaca & Suara</SectionTitle>
        <div className="grid grid-cols-4 gap-1.5">
          {WEATHER_OPTS.map((w) => (
            <button
              key={w.k}
              onClick={() => patchSettings({ weather: w.k })}
              data-active={settings.weather === w.k}
              className={`pixel-btn flex flex-col items-center gap-0.5 px-1 py-2 ${settings.weather === w.k ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049]" : "bg-surface2"}`}
            >
              <span className="text-[18px] leading-none">{w.e}</span>
              <span className={`font-pixel text-[7px] ${settings.weather === w.k ? "text-ink" : "text-cream/70"}`}>{w.l}</span>
            </button>
          ))}
        </div>
        <Slider label="VOLUME CUACA" value={settings.weatherVol} min={0} max={1.2} onChange={(v) => patchSettings({ weatherVol: v })} format={(v) => `${Math.round(v * 100)}%`} hint="Hujan deras, guruh petir, dan angin salju" />
      </div>

      <div className="space-y-2.5">
        <SectionTitle>Kamera & Dunia</SectionTitle>
        <Slider label="UKURAN PIXEL" value={settings.pixel} min={2} max={5} step={1} onChange={(v) => patchSettings({ pixel: v })} format={(v) => `${v}px`} hint="Pixel besar = nuansa 18-bit makin tebal" />
        <Slider label="KECEPATAN GERAK" value={settings.speed} min={0.5} max={2} onChange={(v) => patchSettings({ speed: v })} format={(v) => `${v.toFixed(2)}x`} />
        <Slider label="PARTIKEL" value={settings.particles} min={0} max={1.6} onChange={(v) => patchSettings({ particles: v })} format={(v) => `${Math.round(v * 100)}%`} />
        <Toggle label="MODE MALAM" checked={settings.night} onChange={(v) => patchSettings({ night: v })} hint="Lampu hangat, bintang, dan kunang-kunang" />
      </div>

      <button onClick={onExport} className="pixel-btn w-full bg-gradient-to-b from-[#3fe0b0] to-[#22a98a] px-3 py-2.5 font-pixel text-[9px] text-ink">
        📸 UNDUH POTRET PNG
      </button>
    </div>
  );
}

export function CollectionPanel({
  cages, pets, snap, profile, selectedId, onSelect, onFocus, onMove, onAdopt, onBuyCage, onBuyTower, onZoomOut,
}: {
  cages: CageRec[]; pets: PetRec[]; snap: Snapshot; profile: Profile; selectedId: string;
  onSelect: (id: string) => void; onFocus: (i: number) => void; onMove: (id: string, cage: number) => void;
  onAdopt: (cage: number) => void; onBuyCage: () => void; onBuyTower: () => void; onZoomOut: () => void;
}) {
  const brief = (id: string) => snap.pets.find((p) => p.id === id);
  return (
    <div className="space-y-4">
      <div className="pixel-inset p-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <div className="font-pixel text-[10px] text-honey">KOLEKSI AQUARIUM</div>
            <p className="mt-1 text-[12px] leading-tight text-cream/60">{cages.length} aquarium · {pets.length} hamster</p>
          </div>
          <button onClick={onZoomOut} className="pixel-btn bg-gradient-to-b from-[#4fb8ff] to-[#2a7fc4] px-2.5 py-2 font-pixel text-[8px] text-ink">🔭 LIHAT SEMUA</button>
        </div>
        <p className="mt-2 text-[11.5px] leading-snug text-cream/45">
          Zoom out untuk melihat semua aquarium, geser untuk berpindah, lalu klik satu untuk zoom in. Taruh dua hamster di aquarium yang sama agar mereka bisa main gulat dan bisa saling tabrak dari roda!
        </p>
      </div>

      {cages.map((c, ci) => {
        const here = pets.filter((p) => p.cage === ci);
        const th = getTheme(c.theme);
        const full = here.length >= MAX_PETS_PER_CAGE;
        return (
          <div key={c.id} className={`rounded-[7px] border-2 p-2.5 ${snap.focus === ci ? "border-honey/60 bg-honey/5" : "border-edge/60 bg-[#1b1026]/50"}`}>
            <div className="mb-2 flex items-center gap-2">
              <span className="flex h-6 w-6 overflow-hidden rounded-[4px] border-2 border-edge">
                <span className="flex-1" style={{ background: th.sky }} />
                <span className="flex-1" style={{ background: th.bed }} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="font-pixel text-[9px] text-cream/90">{c.tiers === 3 ? "MENARA 3 TINGKAT" : "AQUARIUM"} {ci + 1}</div>
                <div className="font-pixel text-[7px] text-cream/40">{th.name.toUpperCase()}</div>
              </div>
              <button onClick={() => onFocus(ci)} className="pixel-btn bg-gradient-to-b from-[#ffd08a] to-[#e0a049] px-2 py-1.5 font-pixel text-[8px] text-ink">
                {snap.focus === ci && snap.zoomed ? "DILIHAT" : "LIHAT"}
              </button>
            </div>
            <div className="space-y-1.5">
              {here.length === 0 && <p className="pixel-inset p-2 text-center text-[11.5px] text-cream/40">Aquarium kosong. Adopsi hamster atau pindahkan dari aquarium lain.</p>}
              {here.map((p) => {
                const b = brief(p.id);
                const mood = b?.mood ?? 0.8;
                const target = cages.length > 1 ? (ci + 1) % cages.length : -1;
                const targetFull = target >= 0 && pets.filter((q) => q.cage === target).length >= MAX_PETS_PER_CAGE;
                return (
                  <div key={p.id} className={`pixel-inset flex items-center gap-2 p-1.5 ${selectedId === p.id ? "!border-honey/70" : ""}`}>
                    <button onClick={() => onSelect(p.id)} className="shrink-0 rounded-[5px] border-2 border-edge bg-[#1b1026] p-0.5" title="Pilih hamster">
                      <Portrait look={p.look} size={44} />
                    </button>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <span className="truncate font-pixel text-[9px] text-honey">{p.name}</span>
                        {selectedId === p.id && <span className="font-pixel text-[7px] text-mint">DIPILIH</span>}
                      </div>
                      <div className="truncate text-[11px] leading-tight text-cream/50">{ACTIVITY_LABEL[b?.act ?? "idle"] ?? "santai"}</div>
                      <div className="mt-0.5 h-[5px] overflow-hidden rounded-[2px] bg-black/40">
                        <div className="h-full" style={{ width: `${Math.round(mood * 100)}%`, background: mood > 0.55 ? "#3FE0B0" : mood > 0.3 ? "#FFB13D" : "#FF5A5A" }} />
                      </div>
                    </div>
                    <button
                      onClick={() => target >= 0 && onMove(p.id, target)}
                      disabled={target < 0 || targetFull}
                      title={target >= 0 ? `Pindah ke aquarium ${target + 1}` : "Butuh aquarium lain"}
                      className="pixel-btn shrink-0 bg-surface2 px-1.5 py-1.5 font-pixel text-[7px] text-cream/80"
                    >
                      ➜ {target >= 0 ? target + 1 : "-"}
                    </button>
                  </div>
                );
              })}
            </div>
            <button
              onClick={() => onAdopt(ci)}
              disabled={full}
              className="pixel-btn mt-2 w-full bg-gradient-to-b from-[#ff6f9c] to-[#d43b6d] px-2 py-1.5 font-pixel text-[8px] text-ink"
            >
              {full ? "AQUARIUM PENUH" : `🐹 ADOPSI HAMSTER · 🌻${PRICE_PET}`}
            </button>
          </div>
        );
      })}

      <div className="grid grid-cols-1 gap-2">
        <button
          onClick={onBuyCage}
          disabled={cages.length >= MAX_CAGES}
          className="pixel-btn w-full bg-gradient-to-b from-[#3fe0b0] to-[#22a98a] px-3 py-2.5 font-pixel text-[9px] text-ink"
        >
          {cages.length >= MAX_CAGES ? "SEMUA SLOT TERISI" : `🏡 AQUARIUM BARU · 🌻${PRICE_CAGE}`}
        </button>
        <button
          onClick={onBuyTower}
          disabled={cages.length >= MAX_CAGES}
          className="pixel-btn w-full bg-gradient-to-b from-[#ffd08a] to-[#e0a049] px-3 py-2.5 font-pixel text-[9px] text-ink"
        >
          {cages.length >= MAX_CAGES ? "SEMUA SLOT TERISI" : `🪜 MENARA 3 TINGKAT · 🌻${PRICE_TOWER}`}
        </button>
      </div>
      <p className="text-center text-[11px] leading-snug text-cream/40">Menara punya tangga untuk naik dan perosotan untuk turun. Kadang ada yang menunggu di ujungnya!</p>
      <p className="text-center text-[11px] text-cream/35">Dompet: 🌻 {profile.coins} biji</p>
    </div>
  );
}

export function ShopPanel({
  profile, onBuyFood, onBuyAcc, onBuyTheme, onBuyLight, onBuyBox,
}: {
  profile: Profile; onBuyFood: (id: string, qty: number) => void; onBuyAcc: (id: string) => void; onBuyTheme: (id: string) => void;
  onBuyLight: (id: string) => void; onBuyBox: () => void;
}) {
  const [tab, setTab] = useState<"makan" | "gaya" | "kandang" | "lampu" | "kejutan">("makan");
  return (
    <div className="space-y-3">
      <div className="pixel-inset flex items-center justify-between p-2.5">
        <span className="font-pixel text-[9px] text-cream/70">DOMPET BIJI</span>
        <span className="font-pixel text-[13px] text-honey">🌻 {profile.coins}</span>
      </div>
      <div className="grid grid-cols-5 gap-1">
        {([["makan", "🍓", "MAKAN"], ["gaya", "🎀", "GAYA"], ["kandang", "🏡", "TEMA"], ["lampu", "💡", "LAMPU"], ["kejutan", "🎁", "KEJUTAN"]] as const).map(([k, e, l]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={`pixel-btn flex flex-col items-center gap-0.5 px-0.5 py-1.5 ${tab === k ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink" : "bg-surface2 text-cream/70"}`}
          >
            <span className="text-[14px] leading-none">{e}</span>
            <span className="font-pixel text-[6.5px] leading-none">{l}</span>
          </button>
        ))}
      </div>

      {tab === "makan" && (
        <div className="space-y-2">
          {FOODS.map((f) => (
            <div key={f.id} className="pixel-inset flex items-center gap-2.5 p-2.5">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[6px] border-2 border-edge bg-[#1b1026] text-[20px]">{f.emoji}</span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <span className="truncate font-pixel text-[9px] text-cream/90">{f.name.toUpperCase()}</span>
                  <span className="font-pixel text-[8px] text-mint">x{profile.inv[f.id] ?? 0}</span>
                </div>
                <p className="text-[11.5px] leading-tight text-cream/50">{f.desc}</p>
                <div className="mt-0.5 flex gap-2 font-pixel text-[7px] text-cream/40">
                  <span className="text-[#FFB13D]">+{f.food} KENYANG</span>
                  <span className="text-berry">+{f.happy} CERIA</span>
                </div>
              </div>
              <div className="flex shrink-0 flex-col gap-1">
                <button onClick={() => onBuyFood(f.id, 1)} className="pixel-btn bg-gradient-to-b from-[#ffb13d] to-[#d9821f] px-2 py-1 font-pixel text-[8px] text-ink">🌻{f.price}</button>
                <button onClick={() => onBuyFood(f.id, 5)} className="pixel-btn bg-gradient-to-b from-[#ff6f9c] to-[#d43b6d] px-2 py-1 font-pixel text-[8px] text-ink">x5 🌻{f.price * 5 - 2}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "gaya" && (
        <div className="grid grid-cols-2 gap-2">
          {ACCESSORIES.filter((a) => a.id !== "none").map((a) => {
            const owned = profile.owned.includes(a.id);
            return (
              <div key={a.id} className="pixel-inset flex flex-col items-center gap-1 p-2.5 text-center">
                <span className="text-[26px] leading-none">{a.emoji}</span>
                <span className="font-pixel text-[8px] leading-tight text-cream/85">{a.name.toUpperCase()}</span>
                <button
                  onClick={() => onBuyAcc(a.id)}
                  disabled={owned}
                  className={`pixel-btn mt-1 w-full px-2 py-1 font-pixel text-[8px] ${owned ? "bg-surface2 text-mint" : "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink"}`}
                >
                  {owned ? "✓ DIMILIKI" : `🌻 ${a.price}`}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {tab === "kandang" && (
        <div className="space-y-2">
          {THEMES.map((t) => {
            const owned = profile.owned.includes(t.id);
            return (
              <div key={t.id} className="pixel-inset flex items-center gap-2.5 p-2.5">
                <span className="flex h-10 w-10 shrink-0 flex-col overflow-hidden rounded-[6px] border-2 border-edge">
                  <span className="flex-1" style={{ background: t.sky }} />
                  <span className="flex-1" style={{ background: t.hill }} />
                  <span className="flex-1" style={{ background: t.bed }} />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="font-pixel text-[9px] text-cream/90">{t.name.toUpperCase()}</div>
                  <p className="text-[11.5px] leading-tight text-cream/50">Diorama lengkap dengan langit & dekorasi baru.</p>
                </div>
                <button
                  onClick={() => onBuyTheme(t.id)}
                  disabled={owned}
                  className={`pixel-btn shrink-0 px-2 py-1.5 font-pixel text-[8px] ${owned ? "bg-surface2 text-mint" : "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink"}`}
                >
                  {owned ? "✓ PUNYA" : `🌻 ${t.price}`}
                </button>
              </div>
            );
          })}
        </div>
      )}

      {tab === "lampu" && (
        <div className="space-y-2">
          {LIGHTS.map((l) => {
            const owned = profile.owned.includes(l.id);
            return (
              <div key={l.id} className="pixel-inset flex items-center gap-2.5 p-2.5">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[6px] border-2 border-edge bg-[#1b1026] text-[20px]">{l.emoji}</span>
                <div className="min-w-0 flex-1">
                  <div className="font-pixel text-[9px] text-cream/90">{l.name.toUpperCase()}</div>
                  <p className="text-[11.5px] leading-tight text-cream/50">{l.desc}</p>
                </div>
                <button
                  onClick={() => onBuyLight(l.id)}
                  className={`pixel-btn shrink-0 px-2 py-1.5 font-pixel text-[8px] ${owned ? "bg-surface2 text-mint" : "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink"}`}
                >
                  {owned ? "PASANG" : `🌻 ${l.price}`}
                </button>
              </div>
            );
          })}
          <p className="text-center text-[11.5px] leading-snug text-cream/40">Lampu dipasang di aquarium yang sedang kamu lihat. Nyalakan mode malam untuk kilau terbaik.</p>
        </div>
      )}

      {tab === "kejutan" && (
        <div className="space-y-3">
          <div className="pixel-inset flex flex-col items-center gap-2 p-4 text-center">
            <span className="bobble text-[44px] leading-none">🎁</span>
            <div className="font-pixel text-[10px] text-honey">KOTAK KEJUTAN</div>
            <p className="text-[12px] leading-snug text-cream/60">Isinya acak: biji, camilan langka, aksesori, lampu hias, atau tema aquarium yang belum kamu punya!</p>
            <button onClick={onBuyBox} className="pixel-btn w-full bg-gradient-to-b from-[#ff6f9c] to-[#d43b6d] px-3 py-2.5 font-pixel text-[9px] text-ink">
              🎁 BUKA SEKARANG · 🌻{PRICE_BOX}
            </button>
          </div>
        </div>
      )}
      <p className="text-center text-[11.5px] leading-snug text-cream/40">
        Biji didapat dari misi, membelai, makan, menyapu, menggali, gulat, dan menjaga hamster tetap bahagia.
      </p>
    </div>
  );
}

export function JournalPanel({ profile, log, snap }: { profile: Profile; log: LogEntry[]; snap: Snapshot }) {
  const stats = [
    { l: "BELAIAN", v: profile.pets, e: "🤍" },
    { l: "CAMILAN", v: profile.meals, e: "🍓" },
    { l: "SAPU", v: profile.poops, e: "🧹" },
    { l: "RODA", v: `${Math.floor(snap.wheelSec)}s`, e: "🎡" },
    { l: "TERLEMPAR", v: profile.tumbles, e: "🌀" },
    { l: "TABRAKAN", v: profile.bonks, e: "💫" },
    { l: "GULAT", v: profile.fights, e: "🤼" },
    { l: "KUBUR DIRI", v: profile.burrows, e: "🕳️" },
    { l: "TANGGA", v: profile.stats.climb ?? 0, e: "🪜" },
    { l: "PEROSOTAN", v: profile.stats.slide ?? 0, e: "🛝" },
    { l: "SAPA KACA", v: profile.stats.glass ?? 0, e: "👋" },
    { l: "FOTO", v: profile.photos, e: "📸" },
  ];
  return (
    <div className="space-y-4">
      <div>
        <SectionTitle>Statistik</SectionTitle>
        <div className="grid grid-cols-3 gap-1.5">
          {stats.map((s) => (
            <div key={s.l} className="pixel-inset px-1 py-2 text-center">
              <div className="text-[15px] leading-none">{s.e}</div>
              <div className="mt-1 font-pixel text-[11px] text-honey">{s.v}</div>
              <div className="font-pixel text-[7px] text-cream/45">{s.l}</div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <SectionTitle right={<span className="font-pixel text-[8px] text-cream/40">{profile.achievements.length}/{ACHIEVEMENTS.length}</span>}>Piala Imut</SectionTitle>
        <div className="space-y-1.5">
          {ACHIEVEMENTS.map((a) => {
            const got = profile.achievements.includes(a.id);
            return (
              <div
                key={a.id}
                className={`flex items-center gap-2.5 rounded-[6px] border-2 p-2 ${got ? "border-honey/50 bg-honey/10" : "border-edge/50 bg-[#1b1026]/60"}`}
              >
                <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-[5px] border-2 text-[15px] ${got ? "border-honey/60 bg-honey/20" : "border-edge/60 bg-black/30 grayscale"}`}>
                  {got ? a.emoji : "🔒"}
                </span>
                <div className="min-w-0">
                  <div className={`font-pixel text-[8.5px] ${got ? "text-honey" : "text-cream/50"}`}>{a.name.toUpperCase()}</div>
                  <div className="text-[11.5px] leading-tight text-cream/45">{a.desc}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div>
        <SectionTitle>Catatan Harian</SectionTitle>
        <div className="space-y-1.5">
          {log.length === 0 && <p className="pixel-inset p-3 text-center text-[12px] text-cream/40">Belum ada catatan. Ajak hamstermu bermain!</p>}
          {log.map((l) => (
            <div key={l.id} className="pixel-inset flex gap-2 p-2">
              <span className="text-[14px] leading-none">{l.emoji}</span>
              <div className="min-w-0 flex-1">
                <p className="text-[12.5px] leading-snug text-cream/80">{l.text}</p>
                <span className="font-pixel text-[7px] text-cream/35">{l.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// =====================================================================
//  MISI
// =====================================================================
function rewardChips(r: Reward): string[] {
  const out: string[] = [];
  if (r.coins) out.push(`🌻 ${r.coins}`);
  if (r.xp) out.push(`⭐ ${r.xp} XP`);
  if (r.food) for (const [id, n] of Object.entries(r.food)) out.push(`${FOODS.find((f) => f.id === id)?.emoji ?? "🍓"} x${n}`);
  if (r.unlock) {
    for (const u of r.unlock) {
      const nm = ACCESSORIES.find((a) => a.id === u)?.name ?? THEMES.find((t) => t.id === u)?.name ?? LIGHTS.find((l) => l.id === u)?.name ?? u;
      out.push(`🔓 ${nm}`);
    }
  }
  return out;
}

function MissionCard({
  def, progress, claimed, onClaim, accent,
}: { def: MissionDef; progress: number; claimed: boolean; onClaim: () => void; accent: string }) {
  const done = progress >= def.goal;
  const pct = Math.round((progress / def.goal) * 100);
  return (
    <div
      className={`rounded-[7px] border-2 p-2.5 transition-colors ${done && !claimed ? "pulse-glow border-honey/70 bg-honey/10" : claimed ? "border-mint/30 bg-mint/5 opacity-60" : "border-edge/60 bg-[#1b1026]/60"}`}
    >
      <div className="flex items-start gap-2.5">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-[6px] border-2 text-[20px]" style={{ borderColor: `${accent}77`, background: `${accent}22` }}>{def.emoji}</span>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="truncate font-pixel text-[9px] text-cream/90">{def.title.toUpperCase()}</span>
            {def.hard && <span className="rounded-[3px] border border-berry/50 bg-berry/15 px-1 font-pixel text-[6.5px] text-berry">SERU</span>}
          </div>
          <p className="text-[11.5px] leading-tight text-cream/55">{def.desc}</p>
          <div className="mt-1.5 flex items-center gap-2">
            <div className="pixel-inset relative h-[9px] flex-1 overflow-hidden p-0">
              <div className="h-full transition-[width] duration-500" style={{ width: `${pct}%`, background: `linear-gradient(180deg, ${accent}, ${accent}aa)` }} />
              <div className="pointer-events-none absolute inset-0" style={{ backgroundImage: "repeating-linear-gradient(90deg, transparent 0 6px, rgba(0,0,0,.4) 6px 8px)" }} />
            </div>
            <span className="font-pixel text-[8px] text-cream/70">{progress}/{def.goal}</span>
          </div>
          <div className="mt-1.5 flex flex-wrap gap-1">
            {rewardChips(def.reward).map((c) => (
              <span key={c} className="rounded-[4px] border border-honey/30 bg-honey/10 px-1.5 py-[1px] font-pixel text-[7px] text-honey">{c}</span>
            ))}
          </div>
        </div>
        <button
          onClick={onClaim}
          disabled={!done || claimed}
          className={`pixel-btn shrink-0 px-2 py-2 font-pixel text-[8px] ${done && !claimed ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink" : "bg-surface2 text-cream/50"}`}
        >
          {claimed ? "✓" : done ? "KLAIM!" : "…"}
        </button>
      </div>
    </div>
  );
}

export function MissionsPanel({
  profile, onClaim,
}: { profile: Profile; onClaim: (kind: "daily" | "chain", id: string) => void }) {
  const m = profile.missions;
  const stats = profile.stats;
  const chainOpen = CHAIN.filter((c) => !m.chainClaimed.includes(c.id));
  const chainDone = CHAIN.length - chainOpen.length;
  const chest = m.claimedCount % 5;
  const bonus = Math.min(m.streak, 5) * 10;
  return (
    <div className="space-y-4">
      <div className="pixel-inset p-3">
        <div className="flex items-center gap-3">
          <span className={`text-[34px] leading-none ${chest >= 4 ? "bobble" : ""}`}>🎁</span>
          <div className="min-w-0 flex-1">
            <div className="font-pixel text-[10px] text-honey">PETI KEJUTAN</div>
            <p className="text-[11.5px] leading-tight text-cream/55">Klaim 5 misi untuk membuka peti berisi hadiah langka.</p>
            <div className="mt-1.5 flex gap-1">
              {[0, 1, 2, 3, 4].map((i) => (
                <span key={i} className={`h-[10px] flex-1 rounded-[2px] border ${i < chest ? "border-honey bg-honey" : "border-edge bg-black/30"}`} />
              ))}
            </div>
          </div>
        </div>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          <Pill tone="#FF9E5A">🔥 BERUNTUN x{m.streak}</Pill>
          <Pill tone="#3FE0B0">BONUS +{bonus}%</Pill>
          <Pill tone="#A66BFF">TOTAL {m.claimedCount} KLAIM</Pill>
        </div>
      </div>

      <div>
        <SectionTitle>Misi Hari Ini</SectionTitle>
        <div className="space-y-2">
          {m.daily.map((d) => {
            const def = missionDef(d.id);
            if (!def) return null;
            return (
              <MissionCard
                key={d.id}
                def={def}
                progress={mProgress(stats, def, d.base)}
                claimed={d.claimed}
                accent={def.hard ? "#FF4F87" : "#F5A65B"}
                onClaim={() => onClaim("daily", d.id)}
              />
            );
          })}
        </div>
        <p className="mt-1.5 text-center text-[11px] leading-snug text-cream/40">Misi baru muncul tiap hari baru, dan misi yang sudah diklaim langsung diganti.</p>
      </div>

      <div>
        <SectionTitle right={<span className="font-pixel text-[8px] text-cream/40">{chainDone}/{CHAIN.length}</span>}>Petualangan</SectionTitle>
        <div className="space-y-2">
          {chainOpen.slice(0, 3).map((c) => (
            <MissionCard
              key={c.id}
              def={c}
              progress={Math.min(c.goal, stats[c.key] ?? 0)}
              claimed={false}
              accent="#4FB8FF"
              onClaim={() => onClaim("chain", c.id)}
            />
          ))}
          {chainOpen.length === 0 && (
            <p className="pixel-inset p-3 text-center text-[12px] text-cream/50">Semua petualangan tuntas! Kamu pawang hamster sejati. 🏆</p>
          )}
          {chainOpen.length > 3 && (
            <div className="pixel-inset flex items-center gap-2 p-2.5 opacity-70">
              <span className="text-[16px]">🔒</span>
              <span className="text-[11.5px] leading-tight text-cream/50">{chainOpen.length - 3} petualangan lagi menunggu, berisi aksesori, lampu, dan tema gratis.</span>
            </div>
          )}
        </div>
      </div>
      <div className="hidden">{DAILY_POOL.length}</div>
    </div>
  );
}

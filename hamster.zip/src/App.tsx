import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  DEFAULT_CAGES, DEFAULT_LOOK, DEFAULT_PETS, DEFAULT_PROFILE, DEFAULT_SETTINGS, DEFAULT_MISSIONS, FOODS, PALETTES, PATTERNS, EYES,
  ACCESSORIES, ACHIEVEMENTS, ACTIVITY_LABEL, PET_NAMES, PRICE_CAGE, PRICE_PET, PRICE_TOWER, PRICE_BOX, MAX_CAGES, MAX_PETS_PER_CAGE,
  THEMES, LIGHTS, getFood, getTheme, xpForLevel, missionDef, mProgress, pickDaily,
  type Look, type Settings, type Profile, type PetRec, type CageRec, type MissionState,
} from "./game/data";
import { Engine, type Snapshot, type Tool } from "./game/engine";
import { GameAudio } from "./game/audio";
import { drawPortrait } from "./game/hamster";
import {
  CarePanel, CollectionPanel, JournalPanel, MissionsPanel, ShopPanel, StylePanel, WEATHER_OPTS, type LogEntry,
} from "./components/Panels";
import { Bar, Portrait } from "./components/ui";
import { clamp, pick } from "./game/pixel";

const SAVE_KEY = "hamsteru.save.v5";
const OLD_KEYS = ["hamsteru.save.v4", "hamsteru.save.v3", "hamsteru.save.v2", "hamsteru.save.v1"];

type SaveData = {
  pets: PetRec[]; cages: CageRec[]; settings: Settings; profile: Profile;
  world: ReturnType<Engine["serialize"]>; log: LogEntry[]; selectedId: string;
};

const clonePets = () => DEFAULT_PETS.map((p) => ({ ...p, look: { ...p.look } }));
const cloneCages = () => DEFAULT_CAGES.map((c) => ({ ...c }));

/** Hadiah pembaruan: menara 3 tingkat + dua teman baru. */
function withTower(pets: PetRec[], cages: CageRec[]) {
  if (cages.some((c) => c.tiers === 3)) return { pets, cages };
  const idx = cages.length;
  const nc = [...cages, { id: "c-tower", theme: "padang", tiers: 3 as const, lights: "lentera" }];
  const np = [
    ...pets,
    { id: "p-boba", name: "Boba", cage: idx, look: { ...DEFAULT_LOOK, palette: "matcha", pattern: "panda" as const, accessory: "jamur", eyeSize: 0.25, cheek: 0.8 } },
    { id: "p-tofu", name: "Tofu", cage: idx, look: { ...DEFAULT_LOOK, palette: "salju", pattern: "polos" as const, accessory: "pita", eyeSize: 0.25, cheek: 0.9, chub: 1.2 } },
  ];
  return { pets: np, cages: nc };
}

function migrateLook(l: Look): Look {
  return { ...DEFAULT_LOOK, ...l, eyeSize: 0.25, cheek: Math.max(l.cheek ?? 0, 0.62) };
}

function loadSave(): Partial<SaveData> | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) return JSON.parse(raw) as Partial<SaveData>;
    for (const key of OLD_KEYS) {
      const old = localStorage.getItem(key);
      if (!old) continue;
      const d = JSON.parse(old) as Partial<SaveData> & { look?: Look; profile?: Profile & { name?: string }; settings?: Settings & { theme?: string } };
      let pets: PetRec[];
      let cages: CageRec[];
      if (d.pets?.length) {
        pets = d.pets.map((p) => ({ ...p, look: migrateLook(p.look) }));
        cages = (d.cages?.length ? d.cages : cloneCages()).map((c, i) => ({ ...c, lights: c.lights ?? (i % 2 ? "bunga" : "bintang") }));
      } else {
        pets = clonePets();
        if (d.look) pets[0].look = migrateLook({ ...pets[0].look, ...d.look });
        if (d.profile?.name) pets[0].name = d.profile.name;
        cages = cloneCages().map((c) => ({ ...c, tiers: 1 as const }));
        if (d.settings?.theme) cages[0].theme = d.settings.theme;
      }
      const t = withTower(pets, cages);
      return { pets: t.pets, cages: t.cages, profile: d.profile, settings: d.settings, log: d.log, world: d.world, selectedId: d.selectedId };
    }
  } catch {
    /* simpanan rusak diabaikan */
  }
  return null;
}

const EMPTY_SNAP: Snapshot = {
  needs: { food: 74, happy: 82, energy: 88, clean: 90, water: 76 },
  act: "idle", mood: 0.85, cheek: 0.1, poops: 0, bowl: 0.75, bottle: 0.9,
  stash: 2, clock: "08:00", wheelSec: 0, focus: 0, zoomed: true, cages: 2, cagePets: 2,
  pets: [], weather: "clear", selectedId: "", tiers: 1, tier: 0,
};

function randomLook(owned: string[]): Look {
  const accs = ACCESSORIES.filter((a) => owned.includes(a.id));
  return {
    palette: pick(PALETTES).id,
    pattern: pick(PATTERNS).id,
    eye: pick(EYES).c,
    fluff: 0.3 + Math.random() * 0.7,
    chub: 0.95 + Math.random() * 0.3,
    scale: 0.9 + Math.random() * 0.3,
    eyeSize: 0.25 + Math.random() * 0.3,
    cheek: 0.5 + Math.random() * 0.5,
    blush: 0.3 + Math.random() * 0.7,
    earSize: 0.8 + Math.random() * 0.6,
    accessory: pick(accs).id,
    sparkle: Math.random() > 0.25,
  };
}

/** Isi misi harian sampai 3; yang sudah selesai tapi belum diklaim dipertahankan. */
function fillDaily(p: Profile, keepDone: boolean): MissionState {
  const m = p.missions;
  const list = m.daily.filter((d) => {
    if (d.claimed) return false;
    const def = missionDef(d.id);
    return !!def && keepDone && mProgress(p.stats, def, d.base) >= def.goal;
  });
  while (list.length < 3) {
    list.push(pickDaily(p.stats, list.map((x) => x.id), list.length === 2 ? true : list.length === 0 ? false : Math.random() < 0.5));
  }
  return { ...m, daily: list, day: p.day };
}

type Toast = { id: number; title: string; desc?: string; emoji: string; tone: string };
type TabId = "rawat" | "gaya" | "koleksi" | "toko" | "misi" | "jurnal";

export default function App() {
  const saved = useMemo(loadSave, []);
  const [pets, setPets] = useState<PetRec[]>(() => (saved?.pets?.length ? saved.pets : withTower(clonePets(), cloneCages().map((c) => ({ ...c }))).pets));
  const [cages, setCages] = useState<CageRec[]>(() => (saved?.cages?.length ? saved.cages : withTower(clonePets(), cloneCages()).cages));
  const [settings, setSettings] = useState<Settings>({ ...DEFAULT_SETTINGS, ...(saved?.settings ?? {}) });
  const [profile, setProfile] = useState<Profile>(() => {
    const base: Profile = {
      ...DEFAULT_PROFILE, ...(saved?.profile ?? {}),
      inv: { ...DEFAULT_PROFILE.inv, ...(saved?.profile?.inv ?? {}) },
      owned: Array.from(new Set([...DEFAULT_PROFILE.owned, ...(saved?.profile?.owned ?? [])])),
      achievements: saved?.profile?.achievements ?? [],
      stats: { ...(saved?.profile?.stats ?? {}) },
      missions: { ...DEFAULT_MISSIONS, ...(saved?.profile?.missions ?? {}), chainClaimed: saved?.profile?.missions?.chainClaimed ?? [], daily: saved?.profile?.missions?.daily ?? [] },
    };
    return { ...base, missions: base.missions.daily.length >= 3 ? base.missions : fillDaily(base, true) };
  });
  const [selectedId, setSelectedId] = useState<string>(() => {
    const list = saved?.pets?.length ? saved.pets : DEFAULT_PETS;
    return list.some((p) => p.id === saved?.selectedId) ? (saved?.selectedId as string) : list[0].id;
  });
  const [snap, setSnap] = useState<Snapshot>(EMPTY_SNAP);
  const [tab, setTab] = useState<TabId>("rawat");
  const [tool, setTool] = useState<Tool>({ kind: "hand" });
  const [muted, setMuted] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmReset, setConfirmReset] = useState(false);
  const [hintDone, setHintDone] = useState(false);
  const [log, setLog] = useState<LogEntry[]>(
    saved?.log ?? [
      { id: 1, text: "Mochi & Kumo pindah ke Menara 3 Tingkat! Ada tangga untuk naik dan perosotan untuk turun.", emoji: "🪜", time: "Hari 1 · 08:00" },
      { id: 2, text: "Kamu menemukan sekarung biji bunga matahari di laci. Lumayan untuk mulai!", emoji: "🌻", time: "Hari 1 · 08:01" },
    ],
  );

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<Engine | null>(null);
  const audioRef = useRef<GameAudio | null>(null);
  if (!audioRef.current) audioRef.current = new GameAudio();
  const profileRef = useRef(profile);
  const petsRef = useRef(pets);
  const cagesRef = useRef(cages);
  const selectedRef = useRef(selectedId);
  const invRef = useRef({ ...profile.inv });
  const settingsRef = useRef(settings);
  const logRef = useRef(log);
  const logId = useRef(100);
  const toastId = useRef(0);
  const resetting = useRef(false);
  petsRef.current = pets;
  cagesRef.current = cages;
  selectedRef.current = selectedId;
  settingsRef.current = settings;
  logRef.current = log;

  const selectedPet = pets.find((p) => p.id === selectedId) ?? pets[0] ?? null;

  const applyProfile = useCallback((fn: (p: Profile) => Profile) => {
    const next = fn(profileRef.current);
    profileRef.current = next;
    setProfile(next);
  }, []);

  const pushToast = useCallback((t: Omit<Toast, "id">) => {
    const id = ++toastId.current;
    setToasts((list) => [...list.slice(-3), { ...t, id }]);
    window.setTimeout(() => setToasts((list) => list.filter((x) => x.id !== id)), 3800);
  }, []);

  const pushLog = useCallback((text: string, emoji = "🐹") => {
    const s = engineRef.current?.snapshot();
    const time = `Hari ${profileRef.current.day} · ${s?.clock ?? "08:00"}`;
    setLog((l) => [{ id: ++logId.current, text, emoji, time }, ...l].slice(0, 40));
  }, []);

  const petName = useCallback((id?: string) => petsRef.current.find((p) => p.id === (id ?? selectedRef.current))?.name ?? "Hamster", []);

  const unlock = useCallback((id: string) => {
    if (profileRef.current.achievements.includes(id)) return;
    const meta = ACHIEVEMENTS.find((a) => a.id === id);
    if (!meta) return;
    applyProfile((p) => ({ ...p, achievements: [...p.achievements, id], coins: p.coins + 15 }));
    audioRef.current?.play("level");
    pushToast({ title: `Piala: ${meta.name}`, desc: `${meta.desc} · +15 biji`, emoji: meta.emoji, tone: "#FFD08A" });
    pushLog(`Piala imut terbuka: ${meta.name}!`, meta.emoji);
    engineRef.current?.celebrate("star");
  }, [applyProfile, pushLog, pushToast]);

  const addXp = useCallback((n: number) => {
    const p = profileRef.current;
    let xp = p.xp + n;
    let level = p.level;
    let coins = p.coins;
    let up = false;
    while (xp >= xpForLevel(level)) {
      xp -= xpForLevel(level);
      level++;
      coins += 25;
      up = true;
    }
    applyProfile((q) => ({ ...q, xp, level, coins }));
    if (up) {
      audioRef.current?.play("level");
      pushToast({ title: `Level ${level}!`, desc: "Ikatan kalian makin erat · +25 biji", emoji: "💞", tone: "#FF4F87" });
      pushLog(`Level persahabatan naik ke ${level}.`, "💞");
      engineRef.current?.celebrate("heart", "level up! ♡");
      if (level >= 5) unlock("friend");
    }
  }, [applyProfile, pushLog, pushToast, unlock]);

  // ---------- event permainan → statistik & misi ----------
  const registerEvent = useCallback((key: string, n = 1) => {
    const before = profileRef.current;
    applyProfile((p) => ({ ...p, stats: { ...p.stats, [key]: (p.stats[key] ?? 0) + n } }));
    const p = profileRef.current;
    if (key === "climb" && (p.stats.climb ?? 0) >= 5) unlock("climber");
    if (key === "slide" && (p.stats.slide ?? 0) >= 8) unlock("slider");
    // pemberitahuan misi selesai
    const check = (def: ReturnType<typeof missionDef>, base: number, wasBase: number) => {
      if (!def || def.key !== key) return;
      const now = mProgress(p.stats, def, base);
      const was = mProgress(before.stats, def, wasBase);
      if (now >= def.goal && was < def.goal) {
        audioRef.current?.play("claim");
        pushToast({ title: "Misi selesai!", desc: `${def.title} · buka tab MISI untuk klaim`, emoji: def.emoji, tone: "#FFD08A" });
      }
    };
    for (const d of p.missions.daily) if (!d.claimed) check(missionDef(d.id), d.base, d.base);
    for (const c of CHAIN_IDS) if (!p.missions.chainClaimed.includes(c)) check(missionDef(c), 0, 0);
  }, [applyProfile, pushToast, unlock]);

  const claimMission = useCallback((kind: "daily" | "chain", id: string) => {
    const p = profileRef.current;
    const m = p.missions;
    const def = missionDef(id);
    if (!def) return;
    let progress = 0;
    if (kind === "daily") {
      const d = m.daily.find((x) => x.id === id);
      if (!d || d.claimed) return;
      progress = mProgress(p.stats, def, d.base);
    } else {
      if (m.chainClaimed.includes(id)) return;
      progress = Math.min(def.goal, p.stats[def.key] ?? 0);
    }
    if (progress < def.goal) return;
    const day = p.day;
    let streak = m.streak;
    if (m.lastClaimDay !== day) streak = m.lastClaimDay === day - 1 ? streak + 1 : 1;
    const bonus = kind === "daily" ? 1 + Math.min(streak, 5) * 0.1 : 1;
    const r = def.reward;
    let coins = Math.round((r.coins ?? 0) * bonus);
    const inv = { ...p.inv };
    for (const [fid, qty] of Object.entries(r.food ?? {})) inv[fid] = (inv[fid] ?? 0) + qty;
    const owned = [...p.owned];
    const unlocked: string[] = [];
    for (const u of r.unlock ?? []) if (!owned.includes(u)) { owned.push(u); unlocked.push(u); }
    const claimedCount = m.claimedCount + 1;
    let chestNote = "";
    if (claimedCount % 5 === 0) {
      const bonusCoins = 50 + Math.floor(Math.random() * 60);
      coins += bonusCoins;
      const fid = pick(FOODS).id;
      inv[fid] = (inv[fid] ?? 0) + 3;
      chestNote = `Peti Kejutan: +${bonusCoins} biji & 3 ${getFood(fid).name}!`;
      const pool = [...ACCESSORIES.filter((a) => a.id !== "none"), ...LIGHTS, ...THEMES].filter((x) => !owned.includes(x.id));
      if (pool.length && Math.random() < 0.5) {
        const it = pick(pool);
        owned.push(it.id);
        unlocked.push(it.id);
      }
    }
    invRef.current = { ...inv };
    let nextMissions: MissionState;
    if (kind === "daily") {
      const taken = m.daily.map((x) => x.id);
      const stats = p.stats;
      const daily = m.daily.map((x) => (x.id === id ? pickDaily(stats, taken, !def.hard && Math.random() < 0.4) : x));
      nextMissions = { ...m, daily, claimedCount, streak, lastClaimDay: day };
    } else {
      nextMissions = { ...m, chainClaimed: [...m.chainClaimed, id], claimedCount, streak, lastClaimDay: day };
    }
    applyProfile((q) => ({ ...q, coins: q.coins + coins, inv, owned, missions: nextMissions }));
    if (r.xp) addXp(r.xp);
    const chest = claimedCount % 5 === 0;
    audioRef.current?.play(chest ? "chest" : "claim");
    pushToast({ title: chest ? "PETI KEJUTAN!" : "Hadiah diklaim!", desc: chest ? chestNote : `${def.title} · +${coins} biji${bonus > 1 ? ` (bonus +${Math.round((bonus - 1) * 100)}%)` : ""}`, emoji: chest ? "🎁" : def.emoji, tone: chest ? "#FF4F87" : "#FFD08A" });
    for (const u of unlocked) {
      const nm = ACCESSORIES.find((a) => a.id === u)?.name ?? THEMES.find((t) => t.id === u)?.name ?? LIGHTS.find((l) => l.id === u)?.name ?? u;
      pushToast({ title: "Item terbuka!", desc: `${nm} masuk ke koleksimu`, emoji: "🔓", tone: "#3FE0B0" });
    }
    pushLog(`Misi "${def.title}" selesai. +${coins} biji${chest ? " dan Peti Kejutan terbuka" : ""}.`, def.emoji);
    engineRef.current?.celebrate(chest ? "star" : "heart", chest ? "peti ajaib! 🎁" : "hadiah! 🎉");
    if (claimedCount >= 5) unlock("missions");
  }, [addXp, applyProfile, pushLog, pushToast, unlock]);

  // ---------- inisialisasi mesin ----------
  useEffect(() => {
    const cv = canvasRef.current;
    const wrap = wrapRef.current;
    if (!cv || !wrap) return;
    const audio = audioRef.current!;
    audio.setMusic(settingsRef.current.music);
    audio.setSfx(settingsRef.current.sfx);

    const engine = new Engine(cv, { cages: cagesRef.current, pets: petsRef.current }, settingsRef.current, {
      coin: (n, reason) => {
        applyProfile((p) => ({ ...p, coins: p.coins + n }));
        if (reason) pushLog(`${petName()} ${reason}. +${n} biji`, "🌻");
      },
      xp: addXp,
      log: pushLog,
      achieve: (id) => {
        if (id === "first_pet") {
          applyProfile((p) => ({ ...p, pets: p.pets + 1 }));
          unlock("first_pet");
          setHintDone(true);
        } else if (id === "poop_clean") {
          applyProfile((p) => ({ ...p, poops: p.poops + 1 }));
          if (profileRef.current.poops >= 10) unlock("cleaner");
        } else unlock(id);
      },
      stat: (kind) => {
        applyProfile((p) => ({
          ...p,
          tumbles: p.tumbles + (kind === "tumble" ? 1 : 0),
          fights: p.fights + (kind === "fight" ? 1 : 0),
          burrows: p.burrows + (kind === "burrow" ? 1 : 0),
          bonks: p.bonks + (kind === "bonk" ? 1 : 0),
        }));
      },
      event: (key, n) => registerEvent(key, n ?? 1),
      useFood: (id) => {
        if ((invRef.current[id] ?? 0) <= 0) return false;
        invRef.current[id] -= 1;
        applyProfile((p) => ({ ...p, inv: { ...invRef.current }, meals: p.meals + 1 }));
        if (profileRef.current.meals >= 15) unlock("chef");
        return true;
      },
      day: () => {
        applyProfile((p) => {
          const next = { ...p, day: p.day + 1 };
          return { ...next, missions: fillDaily(next, true) };
        });
        pushLog("Hari baru dimulai. Misi harian diperbarui!", "🌅");
        pushToast({ title: "Misi baru!", desc: "Misi harian sudah diperbarui", emoji: "🎯", tone: "#4FB8FF" });
      },
      select: (id) => setSelectedId(id),
    }, audio);

    engine.stageEl = wrap;
    engine.selectedId = selectedRef.current;
    if (saved?.world) engine.restore(saved.world);
    engine.onSnapshot = (s) => {
      setSnap(s);
      if (s.wheelSec >= 60) unlock("athlete");
    };
    engineRef.current = engine;

    const doResize = () => {
      const r = wrap.getBoundingClientRect();
      engine.resize(r.width, r.height);
    };
    doResize();
    engine.start();
    const ro = new ResizeObserver(doResize);
    ro.observe(wrap);
    const onVis = () => { engine.paused = document.hidden; };
    document.addEventListener("visibilitychange", onVis);
    const onWheel = (ev: WheelEvent) => {
      ev.preventDefault();
      audioRef.current?.unlock();
      engine.wheel(ev.deltaY);
    };
    cv.addEventListener("wheel", onWheel, { passive: false });

    return () => {
      ro.disconnect();
      document.removeEventListener("visibilitychange", onVis);
      cv.removeEventListener("wheel", onWheel);
      engine.stop();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const e = engineRef.current;
    if (!e) return;
    const pxChanged = e.settings.pixel !== settings.pixel;
    e.setSettings(settings);
    audioRef.current?.setMusic(settings.music);
    audioRef.current?.setSfx(settings.sfx);
    if (pxChanged && wrapRef.current) {
      const r = wrapRef.current.getBoundingClientRect();
      e.resize(r.width, r.height);
    }
  }, [settings]);
  useEffect(() => { if (engineRef.current) engineRef.current.tool = tool; }, [tool]);
  useEffect(() => { if (engineRef.current) engineRef.current.selectedId = selectedId; }, [selectedId]);
  useEffect(() => { invRef.current = { ...profile.inv }; }, [profile.inv]);

  // ---------- audio ----------
  const firstGesture = useCallback(() => {
    audioRef.current?.unlock();
  }, []);

  // audio baru dibuka pada sentuhan / klik / tombol pertama di halaman
  useEffect(() => {
    const unlockOnce = () => {
      audioRef.current?.unlock();
      window.removeEventListener("pointerdown", unlockOnce, true);
      window.removeEventListener("keydown", unlockOnce, true);
      window.removeEventListener("touchstart", unlockOnce, true);
    };
    window.addEventListener("pointerdown", unlockOnce, true);
    window.addEventListener("keydown", unlockOnce, true);
    window.addEventListener("touchstart", unlockOnce, true);
    return () => {
      window.removeEventListener("pointerdown", unlockOnce, true);
      window.removeEventListener("keydown", unlockOnce, true);
      window.removeEventListener("touchstart", unlockOnce, true);
    };
  }, []);

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      const next = !m;
      const a = audioRef.current!;
      a.setMuted(next);
      if (next) a.stopMusic();
      else a.startMusic();
      return next;
    });
  }, []);

  // ---------- simpan ----------
  useEffect(() => {
    const save = () => {
      if (resetting.current) return;
      const e = engineRef.current;
      const data: SaveData = {
        pets: petsRef.current, cages: cagesRef.current, settings: settingsRef.current, profile: profileRef.current,
        world: e ? e.serialize() : (saved?.world as SaveData["world"]),
        log: logRef.current.slice(0, 20), selectedId: selectedRef.current,
      };
      try { localStorage.setItem(SAVE_KEY, JSON.stringify(data)); } catch { /* penyimpanan penuh */ }
    };
    const iv = window.setInterval(save, 5000);
    window.addEventListener("pagehide", save);
    return () => { window.clearInterval(iv); window.removeEventListener("pagehide", save); save(); };
  }, [saved]);

  // ---------- aksi ----------
  const updatePet = useCallback((id: string, fn: (p: PetRec) => PetRec) => {
    setPets((list) => list.map((p) => (p.id === id ? fn(p) : p)));
  }, []);

  const patchLook = useCallback((p: Partial<Look>) => {
    firstGesture();
    audioRef.current?.play("ui");
    const id = selectedRef.current;
    const cur = petsRef.current.find((x) => x.id === id);
    if (!cur) return;
    const look = { ...cur.look, ...p };
    updatePet(id, (x) => ({ ...x, look }));
    engineRef.current?.setLook(id, look);
    applyProfile((q) => ({ ...q, styles: q.styles + 1 }));
    if (profileRef.current.styles >= 12) unlock("stylist");
  }, [applyProfile, firstGesture, unlock, updatePet]);

  const patchSettings = useCallback((p: Partial<Settings>) => {
    firstGesture();
    audioRef.current?.play("ui");
    setSettings((s) => ({ ...s, ...p }));
  }, [firstGesture]);

  const spend = useCallback((amount: number) => {
    if (profileRef.current.coins < amount) {
      audioRef.current?.play("nope");
      pushToast({ title: "Biji belum cukup", desc: `Butuh ${amount} biji. Selesaikan misi atau belai hamstermu!`, emoji: "🌻", tone: "#FF5A5A" });
      return false;
    }
    applyProfile((p) => ({ ...p, coins: p.coins - amount }));
    return true;
  }, [applyProfile, pushToast]);

  const buyFood = useCallback((id: string, qty: number) => {
    firstGesture();
    const f = getFood(id);
    const cost = qty === 5 ? f.price * 5 - 2 : f.price * qty;
    if (!spend(cost)) return;
    invRef.current[id] = (invRef.current[id] ?? 0) + qty;
    applyProfile((p) => ({ ...p, inv: { ...invRef.current } }));
    audioRef.current?.play("coin");
    pushToast({ title: `${f.name} x${qty}`, desc: "Masuk ke kantong camilanmu", emoji: f.emoji, tone: "#FFB13D" });
  }, [applyProfile, firstGesture, pushToast, spend]);

  const buyAcc = useCallback((id: string) => {
    firstGesture();
    const a = ACCESSORIES.find((x) => x.id === id);
    if (!a) return;
    if (profileRef.current.owned.includes(id)) { patchLook({ accessory: id }); return; }
    if (!spend(a.price)) return;
    applyProfile((p) => ({ ...p, owned: [...p.owned, id] }));
    patchLook({ accessory: id });
    audioRef.current?.play("happy");
    pushToast({ title: `${a.name} dibeli!`, desc: "Langsung dipakai, makin menggemaskan", emoji: a.emoji, tone: "#FF4F87" });
    pushLog(`${petName()} memakai ${a.name} baru. Cantik sekali!`, a.emoji);
    if (profileRef.current.owned.length >= 5) unlock("collector");
  }, [applyProfile, firstGesture, patchLook, petName, pushLog, pushToast, spend, unlock]);

  const applyTheme = useCallback((id: string) => {
    const e = engineRef.current;
    const idx = e ? e.focus : 0;
    setCages((list) => list.map((c, i) => (i === idx ? { ...c, theme: id } : c)));
    e?.setCageTheme(idx, id);
  }, []);

  const buyTheme = useCallback((id: string) => {
    firstGesture();
    const t = THEMES.find((x) => x.id === id);
    if (!t) return;
    if (profileRef.current.owned.includes(id)) { applyTheme(id); return; }
    if (!spend(t.price)) return;
    applyProfile((p) => ({ ...p, owned: [...p.owned, id] }));
    applyTheme(id);
    audioRef.current?.play("happy");
    pushToast({ title: `Tema ${t.name}`, desc: "Dekorasi baru terpasang di aquarium ini", emoji: "🏡", tone: "#3FE0B0" });
    pushLog(`Aquarium disulap menjadi ${t.name}.`, "🏡");
    if (profileRef.current.owned.length >= 5) unlock("collector");
  }, [applyProfile, applyTheme, firstGesture, pushLog, pushToast, spend, unlock]);

  const applyLight = useCallback((id: string) => {
    const e = engineRef.current;
    const idx = e ? e.focus : 0;
    setCages((list) => list.map((c, i) => (i === idx ? { ...c, lights: id } : c)));
    e?.setCageLights(idx, id);
  }, []);

  const buyLight = useCallback((id: string) => {
    firstGesture();
    const l = LIGHTS.find((x) => x.id === id);
    if (!l) return;
    if (profileRef.current.owned.includes(id)) {
      applyLight(id);
      audioRef.current?.play("happy");
      return;
    }
    if (!spend(l.price)) return;
    applyProfile((p) => ({ ...p, owned: [...p.owned, id] }));
    applyLight(id);
    audioRef.current?.play("happy");
    pushToast({ title: `${l.name} dipasang!`, desc: "Aquarium makin indah, apalagi saat malam", emoji: l.emoji, tone: "#FFC53D" });
    pushLog(`Lampu hias ${l.name} dipasang.`, l.emoji);
  }, [applyLight, applyProfile, firstGesture, pushLog, pushToast, spend]);

  const buyBox = useCallback(() => {
    firstGesture();
    if (!spend(PRICE_BOX)) return;
    const owned = profileRef.current.owned;
    const pool = [
      ...ACCESSORIES.filter((a) => a.id !== "none").map((a) => ({ id: a.id, name: a.name, emoji: a.emoji })),
      ...LIGHTS.map((l) => ({ id: l.id, name: l.name, emoji: l.emoji })),
      ...THEMES.map((t) => ({ id: t.id, name: t.name, emoji: "🏡" })),
    ].filter((x) => !owned.includes(x.id));
    const r = Math.random();
    audioRef.current?.play("chest");
    if (r < 0.4 && pool.length) {
      const it = pick(pool);
      applyProfile((p) => ({ ...p, owned: [...p.owned, it.id] }));
      pushToast({ title: "Langka! Item baru", desc: `${it.name} terbuka`, emoji: it.emoji, tone: "#FF4F87" });
      pushLog(`Kotak Kejutan berisi ${it.name}!`, it.emoji);
    } else if (r < 0.75) {
      const f = pick(FOODS);
      invRef.current[f.id] = (invRef.current[f.id] ?? 0) + 4;
      applyProfile((p) => ({ ...p, inv: { ...invRef.current } }));
      pushToast({ title: "Camilan!", desc: `4 ${f.name} masuk kantong`, emoji: f.emoji, tone: "#FFB13D" });
    } else {
      const c = 60 + Math.floor(Math.random() * 80);
      applyProfile((p) => ({ ...p, coins: p.coins + c }));
      pushToast({ title: "Jackpot biji!", desc: `+${c} biji`, emoji: "🌻", tone: "#FFD08A" });
    }
    engineRef.current?.celebrate("star", "wuih! 🎁");
  }, [applyProfile, firstGesture, pushLog, pushToast, spend]);

  const command = useCallback((c: string) => {
    firstGesture();
    const e = engineRef.current;
    if (!e) return;
    if (c === "refillBowl") { if (!spend(6)) return; pushLog("Mangkuk diisi penuh dengan biji pilihan.", "🥣"); }
    if (c === "refillBottle") { if (!spend(3)) return; pushLog("Botol minum besar diisi air segar.", "💧"); }
    e.command(c, selectedRef.current);
  }, [firstGesture, pushLog, spend]);

  const takePhoto = useCallback(() => {
    firstGesture();
    const e = engineRef.current;
    if (!e) return;
    e.command("photo");
    window.setTimeout(() => {
      const url = e.photoDataURL();
      const a = document.createElement("a");
      a.href = url;
      a.download = `${petName()}-hamsteru.png`;
      a.click();
    }, 80);
    applyProfile((p) => ({ ...p, photos: p.photos + 1 }));
    registerEvent("photo");
    unlock("photo");
    pushToast({ title: "Foto tersimpan!", desc: "Momen imut masuk ke unduhanmu", emoji: "📸", tone: "#4FB8FF" });
  }, [applyProfile, firstGesture, petName, pushToast, registerEvent, unlock]);

  const exportPortrait = useCallback(() => {
    firstGesture();
    const cur = petsRef.current.find((p) => p.id === selectedRef.current);
    if (!cur) return;
    const small = document.createElement("canvas");
    small.width = 68;
    small.height = 68;
    drawPortrait(small.getContext("2d")!, cur.look, 68, 0);
    const big = document.createElement("canvas");
    big.width = 544;
    big.height = 544;
    const bc = big.getContext("2d")!;
    bc.imageSmoothingEnabled = false;
    const g = bc.createLinearGradient(0, 0, 544, 544);
    g.addColorStop(0, "#3A2450");
    g.addColorStop(1, "#1B1026");
    bc.fillStyle = g;
    bc.fillRect(0, 0, 544, 544);
    bc.drawImage(small, 0, 0, 544, 544);
    const a = document.createElement("a");
    a.href = big.toDataURL("image/png");
    a.download = `${cur.name}-potret.png`;
    a.click();
    audioRef.current?.play("shutter");
    pushToast({ title: "Potret diunduh", desc: "544×544 pixel, siap dipajang", emoji: "🖼️", tone: "#3FE0B0" });
  }, [firstGesture, pushToast]);

  const randomize = useCallback(() => {
    firstGesture();
    patchLook(randomLook(profileRef.current.owned));
    audioRef.current?.play("happy");
  }, [firstGesture, patchLook]);

  const selectPet = useCallback((id: string) => {
    firstGesture();
    const e = engineRef.current;
    const rec = petsRef.current.find((p) => p.id === id);
    setSelectedId(id);
    if (e) {
      e.selectedId = id;
      const live = e.snapshot().pets.find((p) => p.id === id);
      if (live && (live.cage !== e.focus || !e.zoomedIn)) e.focusCage(live.cage);
    }
    if (rec) audioRef.current?.play("ui");
  }, [firstGesture]);

  const focusCage = useCallback((i: number) => {
    firstGesture();
    engineRef.current?.focusCage(i);
  }, [firstGesture]);

  const adopt = useCallback((cageIdx: number) => {
    firstGesture();
    const here = petsRef.current.filter((p) => p.cage === cageIdx).length;
    if (here >= MAX_PETS_PER_CAGE) return;
    if (!spend(PRICE_PET)) return;
    const used = new Set(petsRef.current.map((p) => p.name));
    const name = PET_NAMES.find((n) => !used.has(n)) ?? `${pick(PET_NAMES)}${petsRef.current.length + 1}`;
    const rec: PetRec = { id: `p${Date.now() % 1000000}`, name, look: randomLook(profileRef.current.owned), cage: cageIdx };
    setPets((l) => [...l, rec]);
    engineRef.current?.addPet(rec);
    registerEvent("adopt");
    pushToast({ title: `${name} bergabung!`, desc: `Hamster baru di aquarium ${cageIdx + 1}`, emoji: "🐹", tone: "#FF4F87" });
    pushLog(`${name} diadopsi dan tinggal di aquarium ${cageIdx + 1}. Selamat datang!`, "🐹");
    selectPet(rec.id);
  }, [firstGesture, pushLog, pushToast, registerEvent, selectPet, spend]);

  const buildCage = useCallback((tiers: 1 | 3) => {
    firstGesture();
    if (cagesRef.current.length >= MAX_CAGES) return;
    if (!spend(tiers === 3 ? PRICE_TOWER : PRICE_CAGE)) return;
    const usedThemes = new Set(cagesRef.current.map((c) => c.theme));
    const theme = profileRef.current.owned.find((o) => THEMES.some((t) => t.id === o) && !usedThemes.has(o)) ?? "padang";
    const lights = profileRef.current.owned.includes("lentera") && tiers === 3 ? "lentera" : "bintang";
    const rec: CageRec = { id: `c${Date.now() % 1000000}`, theme, tiers, lights };
    setCages((l) => [...l, rec]);
    const idx = engineRef.current?.addCage(rec) ?? cagesRef.current.length;
    engineRef.current?.focusCage(idx);
    pushToast({ title: tiers === 3 ? "Menara baru!" : "Aquarium baru!", desc: `Slot ${idx + 1} siap dihuni`, emoji: tiers === 3 ? "🪜" : "🏡", tone: "#3FE0B0" });
    pushLog(`${tiers === 3 ? "Menara 3 tingkat" : "Aquarium"} ${idx + 1} dipasang di rak. Koleksimu makin besar!`, tiers === 3 ? "🪜" : "🏡");
  }, [firstGesture, pushLog, pushToast, spend]);

  const movePet = useCallback((id: string, cageIdx: number) => {
    firstGesture();
    updatePet(id, (p) => ({ ...p, cage: cageIdx }));
    engineRef.current?.moveTo(id, cageIdx);
    pushLog(`${petName(id)} pindah ke aquarium ${cageIdx + 1}.`, "🚚");
  }, [firstGesture, petName, pushLog, updatePet]);

  const resetAll = useCallback(() => {
    resetting.current = true;
    localStorage.removeItem(SAVE_KEY);
    for (const k of OLD_KEYS) localStorage.removeItem(k);
    window.location.reload();
  }, []);

  const cycleWeather = useCallback(() => {
    const i = WEATHER_OPTS.findIndex((w) => w.k === settingsRef.current.weather);
    patchSettings({ weather: WEATHER_OPTS[(i + 1) % WEATHER_OPTS.length].k });
  }, [patchSettings]);

  // ---------- papan ketik ----------
  useEffect(() => {
    const onKey = (ev: KeyboardEvent) => {
      const el = ev.target as HTMLElement | null;
      if (el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA")) return;
      if (ev.metaKey || ev.ctrlKey || ev.altKey) return;
      const k = ev.key.toLowerCase();
      const idx = parseInt(k, 10);
      if (idx >= 1 && idx <= FOODS.length) { setTool({ kind: "food", id: FOODS[idx - 1].id }); firstGesture(); return; }
      switch (k) {
        case "q": setTool({ kind: "hand" }); break;
        case "w": setTool({ kind: "broom" }); break;
        case "e": setTool({ kind: "ball" }); break;
        case "n": setSettings((s) => ({ ...s, night: !s.night })); break;
        case "m": toggleMute(); break;
        case "p": takePhoto(); break;
        case "r": command("wheel"); break;
        case "u": command("turbo"); break;
        case "t": command("sleep"); break;
        case "y": command("bath"); break;
        case "c": command("call"); break;
        case "b": command("bury"); break;
        case "g": command("hide"); break;
        case "f": command("fight"); break;
        case "j": command("explore"); break;
        case "l": command("look"); break;
        case "o": command("roll"); break;
        case "k": command("glass"); break;
        case "v": command("wall"); break;
        case "h": cycleWeather(); break;
        case "z": firstGesture(); engineRef.current?.toggleZoom(); break;
        case "arrowleft": engineRef.current?.step(-1); break;
        case "arrowright": engineRef.current?.step(1); break;
        case " ":
          ev.preventDefault();
          firstGesture();
          engineRef.current?.tapSelected();
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [command, cycleWeather, firstGesture, takePhoto, toggleMute]);

  // ---------- pointer ----------
  const onDown = (ev: React.PointerEvent<HTMLCanvasElement>) => {
    firstGesture();
    const e = engineRef.current;
    if (!e) return;
    ev.currentTarget.setPointerCapture(ev.pointerId);
    e.pointerDown(ev.clientX, ev.clientY);
  };
  const onMove = (ev: React.PointerEvent<HTMLCanvasElement>) => engineRef.current?.pointerMove(ev.clientX, ev.clientY);
  const onUp = (ev: React.PointerEvent<HTMLCanvasElement>) => {
    try { ev.currentTarget.releasePointerCapture(ev.pointerId); } catch { /* sudah dilepas */ }
    engineRef.current?.pointerUp();
  };

  const needMeta = [
    { key: "food", icon: "🍽️", color: "#FFB13D" },
    { key: "happy", icon: "💖", color: "#FF4F87" },
    { key: "energy", icon: "⚡", color: "#FFD84D" },
    { key: "clean", icon: "🫧", color: "#3FE0B0" },
    { key: "water", icon: "💧", color: "#4FB8FF" },
  ] as const;

  const xpNeed = xpForLevel(profile.level);
  const moodLabel = snap.mood > 0.8 ? "Bahagia" : snap.mood > 0.55 ? "Senang" : snap.mood > 0.32 ? "Biasa" : "Butuh kamu";
  const moodTone = snap.mood > 0.8 ? "#3FE0B0" : snap.mood > 0.55 ? "#FFD08A" : snap.mood > 0.32 ? "#FFB13D" : "#FF5A5A";
  const focusCageRec = cages[clamp(snap.focus, 0, cages.length - 1)] ?? cages[0];
  const wx = WEATHER_OPTS.find((w) => w.k === settings.weather) ?? WEATHER_OPTS[0];
  const readyMissions = profile.missions.daily.filter((d) => {
    const def = missionDef(d.id);
    return !d.claimed && def && mProgress(profile.stats, def, d.base) >= def.goal;
  }).length + CHAIN_IDS.filter((id) => {
    const def = missionDef(id);
    return !profile.missions.chainClaimed.includes(id) && def && (profile.stats[def.key] ?? 0) >= def.goal;
  }).length;

  return (
    <div className="relative min-h-screen">
      <div className="world-bg" />
      <div className="world-grid" />
      <div className="aurora" style={{ left: "-6%", top: "8%", width: 420, height: 420, background: "rgba(245,166,91,.22)" }} />
      <div className="aurora" style={{ right: "-8%", top: "22%", width: 460, height: 460, background: "rgba(255,79,135,.18)", animationDelay: "-8s" }} />
      <div className="aurora" style={{ left: "35%", bottom: "-14%", width: 520, height: 380, background: "rgba(63,224,176,.14)", animationDelay: "-14s" }} />
      <div className="world-grain" />

      {/* ================= HEADER ================= */}
      <header className="fixed inset-x-0 top-0 z-40 border-b-2 border-edge/70 bg-[#1b1026]/90 backdrop-blur-md">
        <div className="mx-auto flex h-[68px] max-w-[1480px] items-center gap-3 px-3 lg:px-5">
          <div className="flex shrink-0 items-center gap-2">
            <div className="grid h-11 w-11 place-items-center rounded-[7px] border-2 border-honey/50 bg-gradient-to-b from-[#3a2450] to-[#1b1026] shadow-[0_3px_0_rgba(0,0,0,.5)]">
              {selectedPet && <Portrait look={selectedPet.look} size={38} />}
            </div>
            <div className="hidden sm:block">
              <h1 className="font-pixel text-[15px] leading-none text-shadow-pixel" style={{ color: "#FFD08A" }}>HAMSTERU</h1>
              <p className="mt-1 text-[11px] leading-none text-cream/45">koleksi aquarium 18-bit</p>
            </div>
          </div>

          <div className="mx-1 hidden h-9 w-[2px] bg-edge/60 md:block" />

          <div className="flex min-w-0 flex-1 items-center gap-3">
            <div className="min-w-0">
              <label className="sr-only" htmlFor="petname">Nama hamster</label>
              <input
                id="petname"
                value={selectedPet?.name ?? ""}
                maxLength={14}
                onChange={(e) => {
                  const name = e.target.value;
                  if (!selectedPet) return;
                  updatePet(selectedPet.id, (p) => ({ ...p, name }));
                  engineRef.current?.rename(selectedPet.id, name || "Hamster");
                }}
                className="w-[110px] rounded-[5px] border-2 border-edge/70 bg-[#150c1c]/70 px-2 py-1 font-pixel text-[11px] text-honey outline-none transition-colors focus:border-honey sm:w-[140px]"
              />
              <div className="mt-1 flex items-center gap-1.5">
                <span className="font-pixel text-[7px] text-cream/50">LV{profile.level}</span>
                <div className="pixel-inset h-[7px] w-[80px] overflow-hidden p-0 sm:w-[110px]">
                  <div className="h-full bg-gradient-to-r from-[#FF4F87] to-[#FFD08A] transition-[width] duration-500" style={{ width: `${clamp((profile.xp / xpNeed) * 100, 0, 100)}%` }} />
                </div>
                <span className="hidden font-pixel text-[7px] text-cream/35 sm:inline">{profile.xp}/{xpNeed}</span>
              </div>
            </div>
            <div className="hidden items-center gap-1 lg:flex">
              {pets.map((p) => (
                <button
                  key={p.id}
                  onClick={() => selectPet(p.id)}
                  title={p.name}
                  className={`rounded-[6px] border-2 p-0.5 transition-colors ${p.id === selectedId ? "border-honey bg-honey/15" : "border-edge/60 bg-[#150c1c]/60 hover:border-honey/50"}`}
                >
                  <Portrait look={p.look} size={30} animate={false} />
                </button>
              ))}
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
            <button
              onClick={() => { setTab("misi"); firstGesture(); }}
              title="Misi"
              className={`pixel-btn flex items-center gap-1.5 px-2.5 py-2 ${readyMissions > 0 ? "pulse-glow" : ""}`}
              style={{ background: readyMissions > 0 ? "linear-gradient(180deg,#FFD08A,#E0A049)" : "linear-gradient(180deg,#3a2450,#241631)" }}
            >
              <span className="text-[14px] leading-none">🎯</span>
              <span className={`font-pixel text-[9px] ${readyMissions > 0 ? "text-ink" : "text-cream/70"}`}>{readyMissions > 0 ? `${readyMissions} KLAIM` : "MISI"}</span>
            </button>
            <div className="hidden items-center gap-1.5 rounded-[6px] border-2 border-edge/70 bg-[#150c1c]/60 px-2.5 py-1.5 md:flex">
              <span className="text-[13px]">{wx.e}</span>
              <span className="font-pixel text-[10px] text-cream/70">{snap.clock}</span>
              <span className="font-pixel text-[8px] text-cream/35">H{profile.day}</span>
            </div>
            <div className="flex items-center gap-1.5 rounded-[6px] border-2 border-honey/40 bg-honey/10 px-2.5 py-1.5">
              <span className="text-[13px]">🌻</span>
              <span className="font-pixel text-[11px] text-honey">{profile.coins}</span>
            </div>
            <button
              onClick={() => { firstGesture(); toggleMute(); }}
              title="Suara (M)"
              className="pixel-btn flex items-center gap-1.5 px-2.5 py-2"
              style={{ background: muted ? "linear-gradient(180deg,#5f4f7d,#3a2450)" : "linear-gradient(180deg,#3FE0B0,#22A98A)" }}
            >
              <span className="text-[14px] leading-none">{muted ? "🔇" : "🔊"}</span>
              <span className={`hidden font-pixel text-[8px] sm:inline ${muted ? "text-cream/70" : "text-ink"}`}>{muted ? "BISU" : "SUARA"}</span>
            </button>
            <button onClick={takePhoto} title="Foto (P)" className="pixel-btn bg-gradient-to-b from-[#4fb8ff] to-[#2a7fc4] px-2.5 py-2">
              <span className="text-[14px] leading-none">📸</span>
            </button>
          </div>
        </div>
      </header>

      {/* ================= ISI ================= */}
      <main className="relative z-10 mx-auto max-w-[1480px] px-3 pb-8 pt-[80px] lg:px-5">
        <div className="grid min-w-0 grid-cols-[minmax(0,1fr)] gap-4 lg:grid-cols-[minmax(0,1fr)_366px]">
          {/* ---------- panggung ---------- */}
          <section className="rise-in min-w-0 space-y-3">
            <div className="pixel-card overflow-hidden p-2">
              <div
                ref={wrapRef}
                className="relative w-full overflow-hidden rounded-[5px] border-2 border-[#150c1c] bg-[#1b1026]"
                style={{ height: "clamp(320px, 62vh, 620px)" }}
              >
                <canvas
                  ref={canvasRef}
                  className={`no-tap-highlight absolute inset-0 h-full w-full ${snap.zoomed ? (tool.kind === "hand" ? "stage-cursor-hand" : "stage-cursor-tool") : "cursor-move"}`}
                  onPointerDown={onDown}
                  onPointerMove={onMove}
                  onPointerUp={onUp}
                  onPointerCancel={onUp}
                  onPointerLeave={() => engineRef.current?.pointerLeave()}
                />

                {/* HUD kebutuhan */}
                <div className="pointer-events-none absolute left-2 top-2 w-[132px] space-y-[5px] rounded-[6px] border-2 border-[#150c1c]/70 bg-[#1b1026]/70 p-2 backdrop-blur-[2px] sm:w-[150px]">
                  <div className="truncate font-pixel text-[8px] text-honey">{selectedPet?.name ?? ""}{snap.tiers === 3 ? ` · LT ${snap.tier + 1}` : ""}</div>
                  {needMeta.map((m) => (
                    <Bar key={m.key} compact label={m.key} icon={m.icon} color={m.color} value={snap.needs[m.key]} />
                  ))}
                </div>

                {/* HUD suasana */}
                <div className="pointer-events-none absolute right-2 top-2 flex flex-col items-end gap-1.5">
                  <span className="rounded-[6px] border-2 px-2 py-1 font-pixel text-[9px]" style={{ borderColor: `${moodTone}88`, background: "#1b1026cc", color: moodTone }}>
                    {moodLabel.toUpperCase()}
                  </span>
                  <span className="hidden max-w-[170px] rounded-[6px] border-2 border-edge/60 bg-[#1b1026]/80 px-2 py-1 text-right text-[12px] font-semibold leading-tight text-cream/80 sm:block">
                    {ACTIVITY_LABEL[snap.act] ?? "beraktivitas"}
                  </span>
                  {snap.poops > 0 && (
                    <span className="rounded-[6px] border-2 border-bad/60 bg-[#1b1026]/80 px-2 py-1 font-pixel text-[8px] text-bad">
                      💩 {snap.poops} BERSIHKAN
                    </span>
                  )}
                </div>

                {/* kontrol tampilan */}
                <div className="absolute bottom-2 right-2 flex items-center gap-1 rounded-[7px] border-2 border-[#150c1c]/80 bg-[#1b1026]/85 p-1 backdrop-blur-[2px]">
                  <button onClick={() => engineRef.current?.step(-1)} title="Aquarium sebelumnya (←)" className="pixel-btn bg-surface2 px-2 py-1.5 font-pixel text-[9px] text-cream">◀</button>
                  {cages.map((c, i) => (
                    <button
                      key={c.id}
                      onClick={() => focusCage(i)}
                      title={c.tiers === 3 ? `Menara ${i + 1}` : `Aquarium ${i + 1}`}
                      className={`pixel-btn px-2 py-1.5 font-pixel text-[9px] ${snap.focus === i ? "bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink" : "bg-surface2 text-cream/70"}`}
                    >
                      {c.tiers === 3 ? "🪜" : ""}{i + 1}
                    </button>
                  ))}
                  <button onClick={() => engineRef.current?.step(1)} title="Aquarium berikutnya (→)" className="pixel-btn bg-surface2 px-2 py-1.5 font-pixel text-[9px] text-cream">▶</button>
                  <button
                    onClick={() => { firstGesture(); engineRef.current?.toggleZoom(); }}
                    title="Zoom out / in (Z)"
                    className={`pixel-btn px-2.5 py-1.5 font-pixel text-[9px] ${snap.zoomed ? "bg-gradient-to-b from-[#4fb8ff] to-[#2a7fc4] text-ink" : "bg-gradient-to-b from-[#3fe0b0] to-[#22a98a] text-ink"}`}
                  >
                    {snap.zoomed ? "🔭 SEMUA" : "🔍 MASUK"}
                  </button>
                </div>

                {!hintDone && snap.zoomed && (
                  <div className="pointer-events-none absolute bottom-2 left-2 hidden max-w-[52%] rounded-[6px] border-2 border-honey/40 bg-[#1b1026]/85 px-3 py-1.5 text-[12px] text-cream/80 sm:block">
                    <span className="font-pixel text-[8px] text-honey">TIPS</span> · tekan &amp; geser hamster untuk mengangkatnya dengan tangan hantu
                  </div>
                )}
                {!snap.zoomed && (
                  <div className="pointer-events-none absolute bottom-2 left-2 hidden max-w-[52%] rounded-[6px] border-2 border-mint/40 bg-[#1b1026]/85 px-3 py-1.5 text-[12px] text-cream/80 sm:block">
                    <span className="font-pixel text-[8px] text-mint">MODE JAUH</span> · geser untuk melihat aquarium lain, klik satu untuk zoom in
                  </div>
                )}
              </div>
            </div>

            {/* ---------- strip misi ---------- */}
            <div className="pixel-card p-2">
              <div className="flex items-stretch gap-1.5 overflow-x-auto scroll-cute pb-1">
                <button onClick={() => { setTab("misi"); firstGesture(); }} className="pixel-btn flex shrink-0 flex-col items-center justify-center gap-0.5 bg-gradient-to-b from-[#4fb8ff] to-[#2a7fc4] px-2.5 py-1.5">
                  <span className="text-[16px] leading-none">🎯</span>
                  <span className="font-pixel text-[7px] text-ink">MISI</span>
                </button>
                {profile.missions.daily.map((d) => {
                  const def = missionDef(d.id);
                  if (!def) return null;
                  const pr = mProgress(profile.stats, def, d.base);
                  const done = pr >= def.goal && !d.claimed;
                  return (
                    <button
                      key={d.id}
                      onClick={() => { if (done) claimMission("daily", d.id); else setTab("misi"); firstGesture(); }}
                      className={`flex min-w-[148px] flex-1 items-center gap-2 rounded-[6px] border-2 px-2 py-1.5 text-left transition-colors ${done ? "pulse-glow border-honey/70 bg-honey/15" : "border-edge/60 bg-[#1b1026]/60 hover:border-honey/40"}`}
                    >
                      <span className="text-[17px] leading-none">{def.emoji}</span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate font-pixel text-[7.5px] leading-tight text-cream/85">{def.title.toUpperCase()}</span>
                        <span className="mt-1 block h-[5px] overflow-hidden rounded-[2px] bg-black/40">
                          <span className="block h-full" style={{ width: `${(pr / def.goal) * 100}%`, background: def.hard ? "#FF4F87" : "#F5A65B" }} />
                        </span>
                      </span>
                      <span className={`font-pixel text-[7px] ${done ? "text-honey" : "text-cream/50"}`}>{done ? "KLAIM!" : `${pr}/${def.goal}`}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* ---------- dock alat ---------- */}
            <div className="pixel-card p-2">
              <div className="scroll-cute flex gap-1.5 overflow-x-auto pb-1.5">
                <DockBtn active={tool.kind === "hand"} onClick={() => { setTool({ kind: "hand" }); firstGesture(); }} emoji="🖐️" label="TANGAN" sub="Q" tone="#FFD08A" />
                {FOODS.map((f, i) => (
                  <DockBtn
                    key={f.id}
                    active={tool.kind === "food" && tool.id === f.id}
                    onClick={() => { setTool({ kind: "food", id: f.id }); firstGesture(); audioRef.current?.play("ui"); }}
                    emoji={f.emoji}
                    label={f.name.split(" ")[0].toUpperCase()}
                    sub={`${i + 1}`}
                    count={profile.inv[f.id] ?? 0}
                    tone="#FFB13D"
                  />
                ))}
                <DockBtn active={tool.kind === "broom"} onClick={() => { setTool({ kind: "broom" }); firstGesture(); }} emoji="🧹" label="SAPU" sub="W" tone="#3FE0B0" />
                <DockBtn active={tool.kind === "ball"} onClick={() => { setTool({ kind: "ball" }); firstGesture(); }} emoji="🎾" label="BOLA" sub="E" tone="#FF4F87" />
                <div className="mx-1 w-[2px] shrink-0 self-stretch bg-edge/50" />
                <DockBtn onClick={() => command("wheel")} emoji="🎡" label="LARI" sub="R" tone="#FF9EBB" />
                <DockBtn onClick={() => command("turbo")} emoji="🌪️" label="TURBO" sub="U" tone="#FF8F5A" />
                <DockBtn onClick={() => command("explore")} emoji="🪜" label="JELAJAH" sub="J" tone="#8FD98A" />
                <DockBtn onClick={() => command("look")} emoji="👀" label="LIHAT" sub="L" tone="#FFD08A" />
                <DockBtn onClick={() => command("roll")} emoji="⚽" label="GELINDING" sub="O" tone="#FF9EC0" />
                <DockBtn onClick={() => command("glass")} emoji="👋" label="KACA" sub="K" tone="#8BE0FF" />
                <DockBtn onClick={() => command("wall")} emoji="🕷️" label="DINDING" sub="V" tone="#C8B0FF" />
                <DockBtn onClick={() => command("hide")} emoji="🏠" label="SEMBUNYI" sub="G" tone="#C9A46E" />
                <DockBtn onClick={() => command("bury")} emoji="🕳️" label="KUBUR" sub="B" tone="#E8C77A" />
                <DockBtn onClick={() => command("fight")} emoji="🤼" label="GULAT" sub="F" tone="#FF9EC0" />
                <DockBtn onClick={() => command("bath")} emoji="🏖️" label="MANDI" sub="Y" tone="#8BE0FF" />
                <DockBtn onClick={() => command("sleep")} emoji="😴" label="BOBO" sub="T" tone="#A66BFF" />
                <div className="mx-1 w-[2px] shrink-0 self-stretch bg-edge/50" />
                {WEATHER_OPTS.map((w) => (
                  <DockBtn
                    key={w.k}
                    active={settings.weather === w.k}
                    onClick={() => patchSettings({ weather: w.k })}
                    emoji={w.e}
                    label={w.l}
                    sub="H"
                    tone="#8BC8FF"
                  />
                ))}
                <DockBtn onClick={() => patchSettings({ night: !settings.night })} emoji={settings.night ? "🌙" : "💡"} label="LAMPU" sub="N" tone="#FFC53D" active={settings.night} />
              </div>
              <p className="px-1 pt-1 text-[11.5px] leading-tight text-cream/40">
                {!snap.zoomed && "Mode jauh: geser untuk melihat aquarium lain, klik satu aquarium untuk zoom in."}
                {snap.zoomed && tool.kind === "hand" && "Klik lantai untuk memanggil · tekan & geser hamster untuk mengangkatnya dengan tangan hantu · klik rumah/tumpukan untuk membangunkan."}
                {snap.zoomed && tool.kind === "food" && `Klik aquarium untuk menaruh ${getFood(tool.id).name}. Perhatikan cara makannya yang puas!`}
                {snap.zoomed && tool.kind === "broom" && "Klik kotoran untuk menyapunya. Setiap kotoran memberi 3 biji bonus."}
                {snap.zoomed && tool.kind === "ball" && "Klik untuk menaruh bola, hamster akan mendorongnya keliling aquarium."}
              </p>
            </div>
          </section>

          {/* ---------- panel samping ---------- */}
          <aside className="pixel-card rise-in flex min-w-0 flex-col overflow-hidden lg:sticky lg:top-[80px] lg:h-[calc(100vh-100px)]">
            <div className="grid shrink-0 grid-cols-6 gap-1 border-b-2 border-edge/60 bg-[#1b1026]/60 p-1.5">
              {([["rawat", "💗", "RAWAT"], ["misi", "🎯", "MISI"], ["gaya", "🎀", "GAYA"], ["koleksi", "🏠", "KOLEKSI"], ["toko", "🛒", "TOKO"], ["jurnal", "📖", "JURNAL"]] as const).map(([k, e, l]) => (
                <button
                  key={k}
                  onClick={() => { setTab(k); firstGesture(); audioRef.current?.play("ui"); }}
                  className={`tab-btn relative flex flex-col items-center gap-0.5 rounded-[5px] border-2 px-0.5 py-1.5 ${tab === k ? "border-honey/70 bg-gradient-to-b from-[#ffd08a] to-[#e0a049] text-ink" : "border-transparent bg-surface2/60 text-cream/60 hover:text-cream"}`}
                >
                  <span className="text-[13px] leading-none">{e}</span>
                  <span className="text-[6.5px] leading-none">{l}</span>
                  {k === "misi" && readyMissions > 0 && (
                    <span className="absolute -right-1 -top-1 min-w-[15px] rounded-[4px] border-2 border-[#150c1c] bg-berry px-[2px] font-pixel text-[7px] leading-[11px] text-white">{readyMissions}</span>
                  )}
                </button>
              ))}
            </div>
            <div className="scroll-cute max-h-[62vh] flex-1 overflow-y-auto p-3 lg:max-h-none">
              {tab === "gaya" && selectedPet && (
                <StylePanel
                  look={selectedPet.look} petName={selectedPet.name} patchLook={patchLook}
                  settings={settings} patchSettings={patchSettings} profile={profile}
                  cageTheme={focusCageRec?.theme ?? "padang"} cageIndex={snap.focus}
                  onPickTheme={(id) => (profile.owned.includes(id) ? applyTheme(id) : buyTheme(id))}
                  cageLights={focusCageRec?.lights ?? "bendera"} onPickLight={buyLight}
                  onBuyAcc={buyAcc} onRandom={randomize}
                  onReset={() => patchLook({ ...DEFAULT_LOOK })} onExport={exportPortrait}
                />
              )}
              {tab === "rawat" && (
                <CarePanel
                  snap={snap} pet={selectedPet} settings={settings} onCommand={command}
                  onNight={(v) => patchSettings({ night: v })}
                  bowlPct={Math.round(snap.bowl * 100)} bottlePct={Math.round(snap.bottle * 100)}
                />
              )}
              {tab === "misi" && <MissionsPanel profile={profile} onClaim={claimMission} />}
              {tab === "koleksi" && (
                <CollectionPanel
                  cages={cages} pets={pets} snap={snap} profile={profile} selectedId={selectedId}
                  onSelect={selectPet} onFocus={focusCage} onMove={movePet} onAdopt={adopt}
                  onBuyCage={() => buildCage(1)} onBuyTower={() => buildCage(3)}
                  onZoomOut={() => { firstGesture(); engineRef.current?.zoomOut(); }}
                />
              )}
              {tab === "toko" && <ShopPanel profile={profile} onBuyFood={buyFood} onBuyAcc={buyAcc} onBuyTheme={buyTheme} onBuyLight={buyLight} onBuyBox={buyBox} />}
              {tab === "jurnal" && <JournalPanel profile={profile} log={log} snap={snap} />}
            </div>
          </aside>
        </div>

        {/* ---------- footer ---------- */}
        <footer className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-[8px] border-2 border-edge/50 bg-[#1b1026]/60 px-3 py-2.5">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11.5px] text-cream/45">
            <span className="font-pixel text-[8px] text-honey">PINTASAN</span>
            <span><b className="text-cream/70">1–6</b> camilan</span>
            <span><b className="text-cream/70">Q/W/E</b> tangan·sapu·bola</span>
            <span><b className="text-cream/70">Z</b> zoom</span>
            <span><b className="text-cream/70">←/→</b> aquarium</span>
            <span><b className="text-cream/70">H</b> cuaca</span>
            <span><b className="text-cream/70">U</b> turbo</span>
            <span><b className="text-cream/70">J</b> jelajah menara</span>
            <span><b className="text-cream/70">K</b> sapa kaca</span>
            <span><b className="text-cream/70">V</b> manjat dinding</span>
            <span><b className="text-cream/70">B/G/F</b> kubur·sembunyi·gulat</span>
            <span><b className="text-cream/70">N</b> lampu</span>
            <span><b className="text-cream/70">M</b> suara</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="hidden text-[11.5px] text-cream/35 sm:inline">Progres tersimpan otomatis di perangkat ini</span>
            {confirmReset ? (
              <span className="flex items-center gap-1.5">
                <span className="font-pixel text-[8px] text-bad">YAKIN?</span>
                <button onClick={resetAll} className="pixel-btn bg-gradient-to-b from-[#ff5a5a] to-[#c43030] px-2 py-1 font-pixel text-[8px] text-cream">YA</button>
                <button onClick={() => setConfirmReset(false)} className="pixel-btn bg-surface2 px-2 py-1 font-pixel text-[8px] text-cream/70">BATAL</button>
              </span>
            ) : (
              <button onClick={() => setConfirmReset(true)} className="pixel-btn bg-surface2 px-2.5 py-1.5 font-pixel text-[8px] text-cream/60">↺ MULAI ULANG</button>
            )}
          </div>
        </footer>
      </main>

      {/* ---------- toast ---------- */}
      <div className="pointer-events-none fixed bottom-4 right-4 z-50 flex w-[290px] flex-col gap-2">
        {toasts.map((t) => (
          <div key={t.id} className="toast-in pixel-card flex items-start gap-2.5 p-2.5" style={{ borderColor: `${t.tone}88` }}>
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-[5px] border-2 text-[17px]" style={{ borderColor: `${t.tone}66`, background: `${t.tone}22` }}>{t.emoji}</span>
            <div className="min-w-0">
              <div className="font-pixel text-[9px] leading-tight" style={{ color: t.tone }}>{t.title}</div>
              {t.desc && <div className="mt-0.5 text-[12px] leading-snug text-cream/65">{t.desc}</div>}
            </div>
          </div>
        ))}
      </div>
      <span className="sr-only">{getTheme(focusCageRec?.theme ?? "padang").name}{PRICE_CAGE}{PRICE_TOWER}</span>
    </div>
  );
}

const CHAIN_IDS = ["c_pet", "c_feed", "c_climb", "c_slide", "c_wheel", "c_tumble", "c_glass", "c_bonk", "c_fight", "c_wall", "c_weather", "c_slidehead"];

function DockBtn({
  emoji, label, sub, onClick, tone, active, count,
}: {
  emoji: string; label: string; sub?: string; onClick: () => void; tone: string; active?: boolean; count?: number;
}) {
  const empty = count !== undefined && count <= 0;
  return (
    <button
      onClick={onClick}
      data-active={active ? "true" : "false"}
      className="pixel-btn no-tap-highlight relative flex w-[62px] shrink-0 flex-col items-center gap-0.5 px-1 py-1.5"
      style={{
        background: active ? `linear-gradient(180deg, ${tone}, ${tone}bb)` : "linear-gradient(180deg,#3a2450,#241631)",
        opacity: empty ? 0.55 : 1,
      }}
    >
      <span className="text-[19px] leading-none">{emoji}</span>
      <span className={`font-pixel text-[7px] leading-tight ${active ? "text-ink" : "text-cream/70"}`}>{label}</span>
      {sub && <span className={`font-pixel text-[6px] leading-none ${active ? "text-ink/50" : "text-cream/30"}`}>{sub}</span>}
      {count !== undefined && (
        <span
          className="absolute -right-1 -top-1 min-w-[17px] rounded-[4px] border-2 border-[#150c1c] px-[2px] font-pixel text-[7px] leading-[12px]"
          style={{ background: empty ? "#FF5A5A" : "#FFD08A", color: "#2A1608" }}
        >
          {count}
        </span>
      )}
    </button>
  );
}
